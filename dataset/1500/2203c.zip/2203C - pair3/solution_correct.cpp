#include <bits/stdc++.h>

#ifdef LOCAL
#include <debug.h>
#else
#define debug(...)
#define debug_arr(...)
#define debug_endl(...)
#endif

using i64 = long long;

void solve() {
	i64 s, m;
	std::cin >> s >> m;

	if (s % (m & -m) != 0) {
		std::cout << -1 << "\n";
		return;
	}

	std::cout << *std::ranges::partition_point(std::views::iota(1ll, s), [&](i64 n) -> bool {
		i64 last = s;
		for (int i = 59; i >= 0; i--) {
			if (m >> i & 1) {
				last -= std::min(last >> i, n) << i;
			}
		}
		return last;
	}) << "\n";
}

int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	std::cout.setf(std::ios::fixed);
	std::cout.precision(10);

	int t;
	std::cin >> t;

	while (t--) {
		solve();
		debug_endl(std::endl);
	}

	return 0;
}