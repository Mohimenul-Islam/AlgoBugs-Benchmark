#include <bits/stdc++.h>

#ifdef LOCAL
#include <debug.h>
#else
#define debug(...)
#define debug_arr(...)
#define debug_endl(...)
#endif

using i64 = long long;

void solve() {
	i64 s, m;
	std::cin >> s >> m;

	std::cout << (s % (m & -m) == 0 ? (s + m - 1) / m : -1) << "\n";
}

int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	std::cout.setf(std::ios::fixed);
	std::cout.precision(10);

	int t;
	std::cin >> t;

	while (t--) {
		solve();
		debug_endl(std::endl);
	}

	return 0;
}