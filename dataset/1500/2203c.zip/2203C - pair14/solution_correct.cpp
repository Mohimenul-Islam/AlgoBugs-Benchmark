#include <bits/stdc++.h>
using namespace std;

#pragma GCC optimize("O3,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")

#define PI 3.14159265358979323846
#define int long long int
#define f(i, n) for (int i = 0; i < n; i++)
#define fb(i, n) for (int i = n - 1; i >= 0; i--)
#define fbb(i, n, x) for (int i = n - 1 - x; i >= 0; i--)
#define fx(i, n, a) for (int i = a; i < n; i++)
#define inp(i, v)                           \
    for (int i = 0; i < (int)v.size(); i++) \
        cin >> v[i];
#define inpp(v)       \
    for (auto &x : v) \
        print(x);     \
    cout << endl;
#define mod 1000000007
#define vint vector<int>
#define vch vector<char>
#define vbo vector<bool>
#define no cout << "No" << endl;
#define yes cout << "Yes" << endl;
#define all(a) (a).begin(), (a).end()
#define rall(a) (a).rbegin(), (a).rend()
#define last(a) *((a).end() - 1)
#define print(a)       \
    for (auto x : (a)) \
        cout << x << ' ';
#define printp(a)      \
    for (auto x : (a)) \
        cout << x.first << ' ' << x.second << endl;
#define ret return;
#undef exit
#define pb push_back
#define pii pair<int, int>
#define vp vector<pair<int, int>>
#define endll cout << endl;
#define vid(a, n, m, x) vector<vector<int>> a(n, vector<int>(m, x));
#define pipb pair<int, pair<int, bool>>
#define pip pair<int, pair<int, int>>
#define ppi pair<pii, int>
#define op cout << ans << endl;
#define vchard(n, m) vector<vector<char>> v(n, vector<char>(m));
#define alice cout << "Alice" << endl;
#define bob cout << "Bob" << endl;
#define fr first
#define sc second
#define vvi vector<vint>
#define vvp vector<vp>
#define vst vector<string>
#define vus vector<unordered_set<int>>
#define vpp vector<pip>
#define ll long long
#define umap unordered_map<int, int>
#define space << " " <<
#undef exit
const int inf = LLONG_MAX / 4;
const int neginf = LLONG_MIN / 4;
const int MOD = 998244353;

// struct SegTree
// {
//     int n;
//     vector<pair<int, int>> tree;

//     SegTree(int sz)
//     {
//         n = sz;
//         tree.resize(4 * n + 1);
//     }

//     void build(const vector<int> &v, int node, int start, int end)
//     {
//         if (start == end)
//         {
//             tree[node] = {v[start], start};
//         }
//         else
//         {
//             int mid = (start + end) / 2;
//             build(v, 2 * node, start, mid);
//             build(v, 2 * node + 1, mid + 1, end);
//             if (tree[2 * node].first > tree[2 * node + 1].first)
//                 tree[node] = tree[2 * node];
//             else
//                 tree[node] = tree[2 * node + 1];
//         }
//     }

//     void build(const vector<int> &v)
//     {
//         build(v, 1, 0, n - 1);
//     }

//     pair<int, int> query(int node, int start, int end, int l, int r)
//     {
//         if (r < start || end < l)
//             return {-1e18, -1};
//         if (l <= start && end <= r)
//             return tree[node];
//         int mid = (start + end) / 2;
//         pair<int, int> p1 = query(2 * node, start, mid, l, r);
//         pair<int, int> p2 = query(2 * node + 1, mid + 1, end, l, r);
//         if (p1.first > p2.first)
//             return p1;
//         return p2;
//     }

//     pair<int, int> query(int l, int r)
//     {
//         return query(1, 0, n - 1, l, r);
//     }
// };
int s, m;
int check(int n)
{
    int sum = s;
    for (int i = 60; i >= 0; i--)
    {
        // take as many as poss, max n
        if (!(m >> i & 1))
            continue;
        int contri = (1ll << i);
        int freq = min(sum / contri, n);
        sum -= freq * contri;
    }
    return (sum == 0);
}

void solve()
{
    cin >> s >> m;
    if (s == 0)
    {
        cout << 0 << endl;
        ret
    }
    int l = 1, r = s;
    int ans = -1;
    while (l <= r)
    {
        int mid = l + (r - l) / 2;
        if (check(mid))
        {
            ans = mid;
            r = mid - 1;
        }
        else
            l = mid + 1;
    }
    op
}

int32_t main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--)
        solve();
    return 0;
}