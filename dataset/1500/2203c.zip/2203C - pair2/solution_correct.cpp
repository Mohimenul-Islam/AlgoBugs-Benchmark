#include<iostream>
#include<bits/stdc++.h>
using namespace std;
#define int long long 
#define IOS ios::sync_with_stdio(0),cin.tie(0),cout.tie(0)
#define endl '\n'

void solve()
{
    int s, m;
    cin >> s >> m;

    int low = m & -m;
    if(s % low != 0)
    {
        cout << -1 << endl;
        return;
    }

    vector<int> g;
    int res = m, cnt = 0;

    while(res)
    {
        if(res & 1)
        {
            g.push_back(1LL << cnt);
        }
        cnt++;
        res >>= 1;
    }

    reverse(g.begin(), g.end());

    auto check = [&](int n)->bool {
        int sum = s;

        for(auto t : g)
        {
            int num = min(n, sum / t);
            sum -= num * t;
        }

        return sum == 0;
    };

    int l = 1, r = s;

    while(l < r)
    {
        int mid = (l + r) / 2;

        if(check(mid)) r = mid;
        else l = mid + 1;
    }

    cout << l << endl;
}

signed main()
{
    IOS;

    int t;
    cin >> t;

    while(t--) solve();

    return 0;
}