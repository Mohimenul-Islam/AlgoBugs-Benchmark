#include "bits/stdc++.h"
#define slow ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0)
#define ed "\n"
#define int long long
#define yes cout <<"YES\n"
#define no cout <<"NO\n"
#define all(x) x.begin(),x.end()
#define rall(x) x.rbegin(),x.rend()
#define pb push_back
using namespace std;

void slt(){
  int n,m; cin >> n >> m;
  int  INF = 1.01e18;

  int l = 0, r = INF;

  while (l <= r){
    int mid = l + (r-l)/2 , x = n;

    for(int i = 62; i >= 0 ; i--){
       if((m >> i) & 1) x -= min (x >> i , mid) << i;
    }

    if (x == 0) r = mid-1;

    else l = mid+1;
  }

  cout << (r == INF ? -1 : r+1) << ed;


}

int32_t main()
{
    slow;
    int t = 1; cin >> t;
    while(t--) slt();
}
