#include "bits/stdc++.h"
#define slow ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0)
#define ed "\n"
#define int long long
#define yes cout <<"YES\n"
#define no cout <<"NO\n"
#define all(x) x.begin(),x.end()
#define rall(x) x.rbegin(),x.rend()
#define pb push_back
using namespace std;
bool parity( int a, int b){
    return (((a % 2) && (b % 2)) || (!(a % 2) && !(b % 2)));
}

void slt(){
    int n,m; cin >> n >> m;
    
    if(!parity(n,m)) cout << -1 <<ed;

    else cout << (n+m-1) / m << ed;

  
}

int32_t main()
{
    slow;
    int t = 1; cin >> t;
    while(t--) slt();
}
