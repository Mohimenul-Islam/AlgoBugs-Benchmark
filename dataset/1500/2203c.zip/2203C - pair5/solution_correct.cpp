#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
bool f(ll s, ll mid,ll m){
    ll rem = s;
    for(ll i=62;i>=0;i--){
        if(((m>>i) & 1) == 1){
            ll x = min((rem/(1LL<<i)),mid);
            rem-=(x*(1LL<<i));
        }
        if(rem==0) return true;
    }
    if(rem==0) return true;
    return false;
}
void solve()
{
    ll s,m;
    cin >> s >> m;
    
    ll l = 1;
    ll h = s;
    ll ans = 0;
    while(l<=h){
        ll mid = (l+h)/2;

        if(f(s,mid,m)){
            ans = mid;
            h=mid-1;
        }
        else{
            l=mid+1;
        }
    }
    if(ans==0){
        cout << -1 << endl;
    }
    else{
        cout << ans << endl;
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    ll t;
    cin >> t;
    while (t--)
    {
        solve();
    }
}