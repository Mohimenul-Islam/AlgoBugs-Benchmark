#include <bits/stdc++.h>
using namespace std;
#define int long long
const int INF = 1e18;
const int M = 1e9 + 7;

/*Explanation :


*/

void Hi() {
    int sum,mask; cin>>sum >>mask;

    int valid = 0;

    //checking for invalid case
    for(int i= 63; i>= 0; i--) {
        if(sum & (1LL<<i)) {
           bool b = true;
            for(int j = i; j >= 0; j--) {
                if(mask & (1LL << j)) {
                    b = false;
                    break;
                }
            }
            if(b) {
                cout<<-1 <<endl;
                return;
            }
        }
        if(mask & (1LL << i)) valid += (1LL << i);
    }

    int ans = -1, l = 1, r = 1e18;

    while(l <= r) {
        int m = l + (r - l) / 2;

        __int128 tmp = (__int128) m * valid;

        if(tmp >= sum) {
            ans = m;
            r = m - 1;
        }
        else l = m+1;
    }

    cout<<ans <<endl;


}

int32_t main() {
    int t = 1; 
    cin>>t;

    for(int i=1; i<=t; i++) {
        Hi();
    }
     
    return 0;

}