#include<bits/stdc++.h>
using namespace std;
#define ll long long

void solve()
{
    ll s, m;
    cin>>s>>m;

    if((s & 1) && m % 2 == 0) {
        cout << -1 << endl;
        return ;
    }

    long double a = s;
    long double b = m;

    ll ans = ceil(a / b);

    cout << (ll)ans << endl;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);

    int t = 1;
    cin >> t;
    while(t--) solve();

    return 0;
}