#include<bits/stdc++.h>
using namespace std;
#define ll long long

bool check(ll s, ll m, ll mid){
	ll f = 0;
	for (int i = 59; i >= 0; i--){
		f <<= 1;
		if (((s >> i) & 1) == 1){
			f++;
		} 
		if (((m >> i) & 1) == 1){
			f -= min(mid, f);
		}
	}
	return (f == 0);
}

void solve()
{
    ll s, m;
    cin>>s>>m;

    if (!check(s, m, 1ll << 60)){
		cout << -1 << endl;
		return;
	}

    ll low = 0, high = 1LL << 60;
    ll ans = -1;
    while(low <= high) {
        ll mid = low + (high - low) / 2;

        if(check(s, m, mid)) {
            ans = mid;
            high = mid - 1;
        } else low = mid + 1;
    }

    cout << ans << endl;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);

    int t = 1;
    cin >> t;
    while(t--) solve();

    return 0;
}