#include<bits/stdc++.h>
using namespace std;
using ll= long long;
#define rep(s,n) for(int i=s;i<=n;i++)
void solve()
{
	long long m,s;
	cin>>s>>m;
	//m为偶数
	if(!(m%2))
	{
		if(s%(m&-m))cout<<-1<<endl;
		else cout<<s/m+1<<endl;
	}
	//m为奇数
	else 
	{
		if (!s)cout<<1<<endl;
		else
		{
			long long left,right;
			left=1;right=s;
			ll ans;ans=s;long long mid;ll rem;ll take;
			while(left<=right)
			{
				mid=(left+right)/2;
				rem=s;
				for(int i=60;i>=0;i--)
				{
					if((m>>i)&1)
					{
						take=min(mid,rem>>i);
						rem-=take<<i;
					}
				}
				if(!rem)
				{
					ans=mid;right=mid-1;
				}
				else left=mid+1;
			}
			cout<<ans<<endl;
		}
	}
}
int main()
{
	int t;cin>>t;
	while(t--)solve();
}