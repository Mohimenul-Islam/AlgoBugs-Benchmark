#include <iostream>
#include <algorithm>

using namespace std;

typedef long long ll;

/**
 * 检查长度为 n 的数组是否能凑出总和 s
 * 每个位（如果 m 中该位为 1）最多可以使用 n 次
 */
bool check(ll n, ll s, ll m) {
	ll rem = s;
	// 从最高位（10^18 约为 2^60）向低位遍历
	for (int i = 62; i >= 0; --i) {
		if ((m >> i) & 1) {
			// 在当前第 i 位，我们最多可以消耗掉的数值是 n * (2^i)
			// 取 min(n, rem >> i) 是为了防止乘法溢出，并计算最多能用多少个 2^i
			ll take = min(n, rem >> i);
			rem -= (take << i);
		}
	}
	return rem == 0;
}

void solve() {
	ll s, m;
	if (!(cin >> s >> m)) return;
	
	// 首先判断是否可能凑出 s
	// 如果即使把 m 中所有的位都用到极限（每个位用 s 次）都无法凑出，则无解
	if (!check(s, s, m)) {
		cout << -1 << "\n";
		return;
	}
	
	ll left = 1, right = s, ans = s;
	
	// 二分查找最小的 n
	while (left <= right) {
		ll mid = left + (right - left) / 2;
		if (check(mid, s, m)) {
			ans = mid;
			right = mid - 1;
		} else {
			left = mid + 1;
		}
	}
	
	cout << ans << "\n";
}

int main() {
	// 优化输入输出
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	
	int t;
	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
}