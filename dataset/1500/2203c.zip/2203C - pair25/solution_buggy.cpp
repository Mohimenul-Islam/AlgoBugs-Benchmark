#include<bits/stdc++.h>
using namespace std;
#define int long long
#define double long double
const int mod=998244353;
#ifndef LOCAL
#pragma GCC optimize(2)
#endif
int lowbit(int n){
    return n&(-n);
}
map<int,int>mp;
int hibit(int n){
    if(mp.find(n)!=mp.end())return mp[n];
    int n1=n,n2=n;
    stack<int>st;
    while(n){
        st.push(lowbit(n));
        n-=lowbit(n);
    }
    while(st.empty()==0){
        mp[n1]=st.top();
        n1-=st.top();
        st.pop();
    }
    return mp[n2];
}
void solve(){
    int s,m;
    cin>>s>>m;
    int lb=lowbit(m);
    if(s%lb){
        cout<<"-1\n";
        return;
    }
    int l=1,r=s/lb;
    int ans=-1;
    while(l<=r){
        int md=l+r>>1;
        int res=0;
        int tm=m,ts=s;
        while(tm){
            int hb=hibit(tm);
            int cst=ts/hb;
            ts%=hb;
            res=max(0ll,cst-(md-res));
            tm-=hibit(tm);
            if(tm)res*=hb/hibit(tm);
        }
        if(res==0){
            ans=md;
            r=md-1;
        }
        else l=md+1;
    }
    cout<<ans<<"\n";
}




signed main(){
    ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
    #ifdef LOCAL
    freopen("in","r",stdin);
    freopen("out","w",stdout);
    #endif
    cout<<fixed<<setprecision(16);
    int t=1;
    //test();
    cin>>t;
    while(t--){
        solve();
    }
    cout.flush();
    #ifdef LOCAL
    fclose(stdin);
    fclose(stdout);
    #endif
    return 0;
}