#include<bits/stdc++.h>
using namespace std;
#define int long long
#define double long double
const int mod=998244353;
int lowbit(int n){
    return n&(-n);
}
int hibit(int n){
    while(n!=lowbit(n))n-=lowbit(n);
    return n;
}
void solve(){
    int s,m;
    cin>>s>>m;
    int lb=lowbit(m);
    if(s%lb){
        cout<<"-1\n";
        return;
    }
    int tm=m;
    vector<int>am;
    while(tm){
        am.push_back(lowbit(tm));
        tm-=lowbit(tm);
    }
    
    int l=1,r=1e18;
    int ans=-1;
    while(l<=r){
        int md=l+r>>1;
        int res=0;
        int ts=s;
        for(int i=am.size()-1;i>=0;i--){
            int hb=am[i];
            int cst=ts/hb;
            ts%=hb;
            res=max(0ll,cst-(md-res));
            if(i!=0)res*=hb/am[i-1];
        }
        if(res==0){
            ans=md;
            r=md-1;
        }
        else l=md+1;
    }
    cout<<ans<<"\n";
}




signed main(){
    ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
    #ifdef LOCAL
    freopen("in","r",stdin);
    freopen("out","w",stdout);
    #endif
    cout<<fixed<<setprecision(16);
    int t=1;
    //test();
    cin>>t;
    while(t--){
        solve();
    }
    cout.flush();
    #ifdef LOCAL
    fclose(stdin);
    fclose(stdout);
    #endif
    return 0;
}