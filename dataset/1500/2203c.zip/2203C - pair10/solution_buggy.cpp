#include <bits/stdc++.h>
using namespace std;
#define int long long

int lowbit(int x)
{
   return x & -x;
}

void solve()
{
   int s, m;
   cin >> s >> m;
   // cout << s % 2 << " " << m % 2 << '\n';
   if (lowbit(s) < lowbit(m))
   {
      cout << -1 << "\n";
   }
   else
   {
      int t = (s + m - 1) / m * m - s;
      if (t == 0)
      {
         cout << (s + m - 1) / m << "\n";
         return;
      }
      t |= m;
      t ^= m;
      if (t == 0)
      {
         cout << (s + m - 1) / m << "\n";
         return;
      }
      vector<int> t2(64, 0), m2(64, 0);
      vector<int> id;
      for (int i = 0; i < 64; i++)
      {
         if (t >> i & 1)
            t2[i] = 1, id.push_back(i);
         if (m >> i & 1)
            m2[i] = 1;
      }
      int bit = 0;
      for (int i = 0; i < id.size(); i++)
      {
         for (int j = id[i] - 1; j >= 0; j--)
         {
            if (m2[j])
            {
               bit = max(bit, id[i] - j);
               break;
            }
         }
      }
      // for (int i = 0; i <= 32; i++)
      //    cout << t2[i] << " " << m2[i] << "\n";
      // cout << s / m << "\n";
      cout << max((1ll << bit), (s + m - 1) / m) << "\n";
   }
}
signed main()
{
   ios::sync_with_stdio(0);
   cin.tie(0);
   int T = 1;
   cin >> T;
   while (T--)
   {
      solve();
   }
   return 0;
}