#include <bits/stdc++.h>
using namespace std;
#define int long long

int lowbit(int x)
{
   return x & -x;
}

void solve()
{
   int s, m;
   cin >> s >> m;
   // cout << s % 2 << " " << m % 2 << '\n';
   if (lowbit(s) < lowbit(m))
   {
      cout << -1 << "\n";
   }
   else
   {
      int res = 0;
      for (int i = 1; i <= 61; i++)
      {
         int t = (1ll << i) - 1;
         int md = m & t;
         int sd = s & t;
         if (md > 0)
            res = max(res, (sd + md - 1) / md);
      }
      // for (int i = 0; i <= 32; i++)
      //    cout << t2[i] << " " << m2[i] << "\n";
      // cout << s / m << "\n";
      cout << res << "\n";
   }
}
signed main()
{
   ios::sync_with_stdio(0);
   cin.tie(0);
   int T = 1;
   cin >> T;
   while (T--)
   {
      solve();
   }
   return 0;
}