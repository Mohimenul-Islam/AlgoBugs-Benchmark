#include <bits/stdc++.h>
using namespace std;
#define int long long
#define oo 1e18
#define pii pair<int, int>
#define fi first
#define se second
#define for1(i, a, b) for (register int i = (a); i <= (b); i++)
#define for2(i, a, b) for (register int i = (a); i >= (b); i--)
#define pr(x) cout << #x << " = " << (x) << "\n"
const int N = 2e5 + 5;
int TT = 1, s, m;

bool check(int x)
{
	int ss = s;
	for2(j, 60, 0)
		if (m >> j & 1)
			ss -= min(x, ss >> j) << j;
	return ss == 0;
}

void solve()
{
	cin >> s >> m;
	int l = 1, r = s, ans = -1;
	while (l <= r){
		int mid = l + r >> 1;
		if (check(mid)) ans = mid, r = mid - 1;
		else l = mid + 1;
	}
	cout << ans << "\n";
}

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);
    //freopen(".in", "r", stdin);
    //freopen(".out", "w", stdout);
    cin >> TT;
    while (TT--)
        solve();

    return 0;
}