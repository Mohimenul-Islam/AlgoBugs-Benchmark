#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
void solve() {
   ll s,m;cin >> s >> m;
   auto check = [&](ll x) -> bool{
       ll p = s;
        for(ll i = 63;i >= 0;i--){
            if((m >> i) & 1){
                ll k = p / (1ll << i);
                if(k <= x){
                    p -= k * (1ll << i);
                }
                else{
                    p -= x * (1ll << i);
                }
            }
        }
        //如果s被消耗完了就说明合法
        if(p == 0) return true;
        else return false;
   };
   //先判断是否能构成
   if(!check(1e18)){
       cout << -1 << endl;
       return;
   }
   ll l = 1, r = 1e18 + 1;
   while(l < r){
       ll mid = (l + r) >> 1;
       if(check(mid)) r = mid;
       else l = mid + 1;
   }
   cout << l << endl;

}
int main() {
    int T = 1;
    cin >> T;
    while (T--) {
        solve();
    }
    return 0;
}