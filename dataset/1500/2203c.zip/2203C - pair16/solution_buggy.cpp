#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
void solve() {
    ll s,m;cin >> s >> m;
    if((s & 1) == 1 && (m & 1) != 1) {
        cout << -1 << endl;
        return;
    }
    ll ans = s / m;
    if(s % m) ans++;
    cout << ans << endl;
}
int main() {
    int T = 1;
    cin >> T;
    while (T--) {
        solve();
    }
    return 0;
}