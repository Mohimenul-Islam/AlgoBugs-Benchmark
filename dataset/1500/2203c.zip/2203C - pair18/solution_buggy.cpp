#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define lowbit(x) (x) & (-x)
using ll = long long; using PII = pair<int, int>;

const ll mod = 1e9 + 7, MOD = 998244353;
const ll N = 2e5 + 5, inf = 0x3f3f3f3f, INF = 0x3f3f3f3f3f3f3f3f;

int lenof(ll n)
{
  int ans = 0;
  while(n > 0) ++ ans, n >>= 1;
  return ans;
}

bool check(ll n, ll m, ll c, int mk)
{
  for(ll k = (1LL << (mk - 1)); n && k; k >>= 1)
  {
    if((k & m) == 0) continue;
    if(n >= k * c) n -= k * c;
    else n %= k;
  }
  return (n == 0);
}

void solve()
{
  ll n, m; cin >> n >> m;
  ll low = lowbit(m);
  if(n % low != 0)
  {
    cout << -1 << endl;
    return;
  }

  ll l = 1, r = n; int mk = lenof(m);
  while(l < r)
  {
    ll mid = (l + r >> 1);
    if(check(n, m, mid, mk)) r = mid;
    else l = mid + 1;
  }
  cout << l << endl;
}

signed main()
{
  ios::sync_with_stdio(false);
  cin.tie(nullptr);

  int t; cin >> t;
  while (t--) solve();

  return 0;
}