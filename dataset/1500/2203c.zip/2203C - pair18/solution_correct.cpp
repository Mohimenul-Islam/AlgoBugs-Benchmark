#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define lowbit(x) (x) & (-x)
using ll = long long;

void solve() {
    ll s, m;
    cin >> s >> m;
    
    ll low = lowbit(m);
    // 可行性判断：s 必须是 lowbit(m) 的倍数
    if (s % low != 0) {
        cout << -1 << endl;
        return;
    }
    
    // 优化：将 s 和 m 都除以 lowbit(m)，使 m 变为奇数，简化计算
    s /= low;
    m /= low;
    
    ll ans = 0;
    ll sum_s = 0, sum_m = 0;
    
    // 从低位到高位遍历每一位（最多60位足够处理 1e18）
    for (int i = 0; i < 60; ++i) {
        ll bit = 1LL << i;
        // 累加当前位，得到低 i+1 位的数值
        if (s & bit) sum_s += bit;
        if (m & bit) sum_m += bit;
        
        // 如果 m 的低 i+1 位是 0，跳过（因为之前已经除过 lowbit，所以 m 最低位是 1，这里 sum_m 不会为 0）
        if (sum_m == 0) continue;
        
        // 计算当前位需要的最小 n：ceil(sum_s / sum_m)
        // 向上取整公式：(a + b - 1) / b
        ll need = (sum_s + sum_m - 1) / sum_m;
        ans = max(ans, need);
    }
    
    cout << ans << endl;
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t;
    cin >> t;
    while (t--) solve();
    return 0;
}