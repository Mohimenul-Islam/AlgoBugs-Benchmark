#include <bits/stdc++.h>
using namespace std;
#include <bits/extc++.h>

#define rep(i, a, b) for(ll i = a; i < (b); ++i)
#define all(x) begin(x),end(x)
#define sz(x) (int)(x).size()

typedef unsigned long long ull;
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef pair<ll, ll> pll;
typedef double ld;

void solve() {
    ll s, m;
    cin >> s >> m;
    ll b = 0;
    while (1) {
        if ((1LL<<b) & m) break;
        if ((1LL<<b) & s) {
            cout << "-1\n";
            return;
        }
    }

    const ll LOGN = 61;
    ll base = 0;
    vll bits;
    {
        ll curs = s;
        for (ll j = LOGN; j >= 0; --j) {
            if ((1LL<<j) & m) {
                ll cnt = (curs>>j);
                curs -= (cnt<<j);
                base = max(base, cnt);
                if (base > 0) bits.push_back(j);
            }
        }
    }

    ll ans = 0;
    ll lo = 0, hi = base;
    while (hi-lo>1) {
        ll mid = (lo+hi)/2;
        ll curs = s;
        for (ll j : bits) {
            if ((1LL<<j) & m) {
                ll cnt = (curs>>j);
                cnt = min(cnt, mid);
                curs -= (cnt<<j);
            }
        }
        if (curs == 0) hi = mid;
        else lo = mid;
    }
    cout << hi << '\n';
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    cin.exceptions(cin.failbit);
    // cout << setprecision(10) << fixed;
    ll tt = 1; cin >> tt;
    while(tt--) solve();
}
