//*  ----------------------------------------------------------------------
//                    ██████╗ ██████╗ ██████╗ ███████╗
//                   ██╔════╝██╔═══██╗██╔══██╗██╔════╝
//                   ██║     ██║   ██║██║  ██║█████╗
//                   ██║     ██║   ██║██║  ██║██╔══╝
//                   ╚██████╗╚██████╔╝██████╔╝███████╗
//                    ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝
//* ----------------------------------------------------------------------
//?                        UTKARSH'S CP TEMPLATE
//^                      "Think twice, code once."
//* ----------------------------------------------------------------------
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;

#define ll long long
#define int long long
#define INT_MAX LLONG_MAX
#define INT_MIN LLONG_MIN
#define MOD 1000000007
#define pb push_back
#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define sz(x) (int)(x).size()
#define srt(v) sort(v.begin(), v.end())
#define Rsrt(v) sort(v.begin(), v.end(), greater<int>())
#define yes cout << "YES" << endl; return;
#define no  cout << "NO" << endl; return;
#define endl "\n"
#define vi vector<int>
#define vc vector<char>
#define vb vector<bool>
#define vvi vector<vector<int>>
#define pii pair<int, int>
#define mii map<int, int>
#define fr(i, a, b) for (int i = a; i < b; i++)
#define frr(i, a, b) for (int i = a; i > b; i--)
#define mxe(v) *max_element(v.begin(), v.end())
#define mne(v) *min_element(v.begin(), v.end())
#define SUM(v) accumulate(all(v),0LL);

typedef tree<int, null_type, less<int>, rb_tree_tag,tree_order_statistics_node_update> ordered_set;

//* Debugger
#ifndef ONLINE_JUDGE
#define debug(x)          \
    cerr << #x << " -> "; \
    _print(x);            \
    cerr << endl << "\n";
#define TIMER_START auto _st = chrono::high_resolution_clock::now();
#define TIMER_END                                    \
    auto _en = chrono::high_resolution_clock::now(); \
    cerr << "Time: " << chrono::duration_cast<chrono::milliseconds>(_en - _st).count() << " ms" << endl;
#else
#define debug(x)
#define TIMER_START
#define TIMER_END
#endif
void _print(ll t) { cerr << t; }void _print(bool t) { cerr << t; }void _print(string t) { cerr << t; }void _print(char t) { cerr << t; }void _print(double t) { cerr << t; }void _print(long double t) { cerr << t; }void _print(unsigned long long t) { cerr << t; }
template <class T, class V>void _print(pair<T, V> p);template <class T>void _print(vector<T> v);template <class T>void _print(set<T> v);template <class T, class V>void _print(map<T, V> v);template <class T>void _print(multiset<T> v);
template <class T, class V>void _print(pair<T, V> p){ cerr << "{"; _print(p.first); cerr << ","; _print(p.second); cerr << "}";}template <class T>void _print(vector<T> v){ cerr << "[ "; for (size_t i = 0; i < v.size(); ++i) { _print(v[i]); if (i != v.size() - 1) cerr << ", "; } cerr << " ]";}template <class T>void _print(set<T> v){ cerr << "[ "; for (auto it = v.begin(); it != v.end(); ++it) { _print(*it); if (next(it) != v.end()) cerr << ", "; } cerr << " ]\n";}template <class T>void _print(multiset<T> v){ cerr << "[ "; for (auto it = v.begin(); it != v.end(); ++it) { _print(*it); if (next(it) != v.end()) cerr << ", "; } cerr << " ]\n";}template <class T, class V>void _print(map<T, V> v){ cerr << "\n"; for (auto it = v.begin(); it != v.end(); ++it) { cerr << " "; _print(*it); if (next(it) != v.end()) cerr << ", "; cerr << "\n"; }}

const vector<int> twoPowMinusOne = {1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535, 131071, 262143, 524287, 1048575, 2097151, 4194303, 8388607, 16777215, 33554431, 67108863, 134217727, 268435455, 536870911};
const string works = "Chal Gya";
const vector<pair<int,int>> dir = {{1,0},{-1,0},{0,1},{0,-1}};

//TODO -------------------------< Main Logic >----------------------------

void solve(int TestCase)
{
    int s,m;
    cin>>s>>m;
    int lol = s;
    int mx = 0;
    frr(i,60,-1){
        if((m >> i) & 1){
            int cnt = lol/(1LL<<i);
            lol -= cnt*(1LL<<i);
            mx = max(mx,cnt);
            debug(i);
            debug(cnt);
        }
    }
    if(lol != 0){
        cout<<-1<<endl;
        return;
    }
    int st = 0;
    int e = mx;
    while(st < e){
        int mid = (st + e)/2;
        lol = s;
        frr(i,60,-1){
            if((m >> i) & 1){
                lol -= min(lol/(1LL<<i),mid)*(1LL<<i);
            }
        }
        if(lol == 0){
            e = mid;
        }
        else{
            st = mid + 1;
        }
    }
    cout<<e<<endl;
}
int32_t main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    // TIMER_START
    int t = 1;
    cin >> t;
    int temp = 1;
    while (t--)
    {
        solve(temp);
        temp++;
    }
    // TIMER_END
    return 0;
}