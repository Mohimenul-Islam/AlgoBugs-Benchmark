#include <bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'
#define pb push_back
#define pii pair<int,int>
#define vi vector<int> 
#define vvi vector<vector<int>>
template <typename T>
istream& operator>>(istream& in, vector<T>& vec) {
    for (T &x : vec) in >> x;
    return in;
}
template <typename T>
ostream& operator<<(ostream& out, vector<T>& vec) {
    for (T &x : vec) out << x << " ";
    return out;
}
int check(int x, int a, int lim){
    int f = 0;
    for(int i = 59; i >= 0; i--){
        f <<= 1;
        if(((x >> i) & 1) == 1){
            f++;
        }
        if(((a >> i) & 1) == 1){
            f -= min(f,lim);
        }
    }
    return (f == 0);
}
void solve(){
    int x,a;
    cin >> x >> a;
    int l = 0, r = 1e18;
    while(l <= r){
        int m = (l + r) / 2;
        if(check(x,a,m)){
            r = m-1;
        }
        else{
            l = m + 1;
        }
    }
    if(l <= 1000000000000000000){
        cout << l << endl;
    }
    else cout << -1 << endl;
    // cout << l << endl;
}

int32_t main() {
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t = 1; 
    cin >> t; 
    while(t--){
        solve();
    }
    return 0;
}