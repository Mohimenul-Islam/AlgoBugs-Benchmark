//########

//WhySoSerious16 ;)

//########

#include <vector>
using namespace std;
#include <iostream>
#include <string>
#include <bits/stdc++.h>
#include <map>
#include <algorithm>
#include <cmath>
#include <queue>
#define pb push_back
#define pbk pop_back
#define bk back
#define lbb lower_bound
#define ubb upper_bound
#define sz(x) lli(x.size())
#define precision(x) fixed << setprecision(x)
#define fast ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
#define all(a) (a).begin(), (a).end()
#define sortf(x) sort(all(x))
#define rall(a) (a).rbegin(), (a).rend()

#define rep0(i, n) for (int i = 0; i < (n); i++)
#define rep1(i, n) for (int i = 1; i <= (n); i++)
#define rep2(i, n) for (int i = 2; i <= (n); i++)
#define repr(i, n) for (int i = (n); i >= 1; i--)
#define repr0(i, n) for (int i = (n)-1; i >= 0; i--)
#define repmf(i, a, b) for (int i = (a); i<=(b); i++)
#define repmb(i, a, b) for (int i = (b); i>=(a); i--)
#define repmfk(i, a, b, k) for (int i = (a); i<=(b); i+=k)
#define repmbk(i, a, b, k) for (int i = (b); i>=(a); i-=k)

#define rep0l(i, n) for (lli i = 0; i < (n); i++)
#define rep1l(i, n) for (lli i = 1; i <= (n); i++)
#define rep2l(i, n) for (lli i = 2; i <= (n); i++)
#define reprl(i, n) for (lli i = (n); i >= 1; i--)
#define repr0l(i, n) for (lli i = (n)-1; i >= 0; i--)
#define repmfl(i, a, b) for (lli i = (a); i<=(b); i++)
#define repmbl(i, a, b) for (lli i = (b); i>=(a); i--)
#define repmfkl(i, a, b, k) for (lli i = (a); i<=(b); i+=k)
#define repmbkl(i, a, b, k) for (lli i = (b); i>=(a); i-=k)

#define fi first
#define se second
#define lmao(v,n,m) v.resize(n+1); fill(all(v),m);
#define inra() cout << "!" << ' '
#define inrq() cout << "?" << ' '
#define chop(x) cout << ((x) ? "Yes" : "No") << endl
#define chopc(x) cout << ((x) ? "YES" : "NO") << endl
#define opn(x) cout << (x) << endl
#define ops(x) cout << (x) << ' '
#define opnt(x) cout << (x)
#define opx() cout << endl
 
using lli = long long;
using ull = unsigned long long;
using ld = long double;
 
using vi = vector<int>;
using vl = vector<lli>;
using vpi = vector<pair<int, int>>;
using vpl = vector<pair<lli,lli>>;
using vvi = vector<vi>;
using vvl = vector<vl>;

lli xx = lli(1e9+7);
lli xxx = 998244353;
 
template<class T> void ckmin(T& a, T& b){if (b < a) swap(a,b);}
template<class T> void ckmax(T& a, T& b){if (b > a) swap(a,b);}
template<class T> void chmin(T& a, T b) {if (b < a) a = b;}
template<class T> void chmax(T& a, T b) {if (b > a) a = b;}
template<class T> T mag(T a) {if (a > 0) return a; return -1*a;}

template<class T> T mymax(T a, T b) {return max(a,b);}
template<class T> T mymin(T a, T b) {return min(a,b);}
template<class T> T mygcd(T a, T b) {return gcd(a,b);}
template<class T> T mysum(T a, T b) {return a+b;}

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

// u can only use bits in m thats all
// 1 1 0 1
// 0 1 0 1
// 0 0 1 1

lli s,m;
vl pw2;
vl dp;

void solve(){
  
  cin >> s >> m;

  if (__builtin_ctzll(s) < __builtin_ctzll(m)) {opn(-1); return;}

  /*lli prv = -1;
  lmao(dp,65,0);

  rep0(i,61) {

    if (m & pw2[i]) prv = i;

    if (s & pw2[i]) {

      if (prv == -1) {opn(-1); return;}
      dp[prv] += pw2[i]/pw2[prv];

    }

  }

  //rep0(i,61) ops((pw2[i] & m) > 0); opx();
  //rep0(i,61) ops((pw2[i] & s) > 0); opx();
  //rep0(i,61) ops(dp[i]); opx();
  //opn(*max_element(all(dp)));*/

  lli start = 1;
  lli end = 1e18;
  lli mid;
  lli result;
  while (end-start>0){

    mid = (start+end)/2;
    lli ch = 1;
    lli tot = 0;

    rep0(i,61) {

      if (m & pw2[i]) {

        if (2e18/pw2[i] <= mid) tot = 5e18;
        if (tot < 1e18) tot += mid * pw2[i];

      }

      if (s & pw2[i]) {ch = ch && (tot >= pw2[i]); tot -= pw2[i];}

    }

    if (ch){
      end = mid;
    }
    else{
      start = mid+1;
    }
  }//ans is either start or end

  opn(start);
  
}


int main(){

  fast;

  int t; cin>>t;

  lmao(pw2,65,1);
  rep1(i,65) pw2[i] = 2*pw2[i-1];

  while(t--){

    solve();

  }
  
}
