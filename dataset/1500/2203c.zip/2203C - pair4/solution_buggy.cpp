#include<bits/stdc++.h>
#define mk std::make_pair

using namespace std;
using pii = pair<int, int>;

const int N = 2e5+7;

typedef long long LL;

void solve()
{
    LL s,m;
    cin >> s >> m;
    for(int i = 0; i <= 64; i++){
        if((m>>i) & 1) break;
        if(((s>>i)&1) && (((m>>i)&1) == 0)){
            cout << -1 << '\n';
            return;
        }
    }
    LL l = 1;
    LL r = 1e18;
    LL ans = 1e18;
    while(l <= r){
        LL mid= l + (r - l) / 2;
        if(mid >= s / m && mid * m >= s || mid > s / m){
            ans = mid;
            r = mid-1;
        }
        else{
            l = mid+1;
        }
    }
    cout <<  ans <<'\n';
}

int main()
{
    int T = 1;
    cin >> T;
    while(T--){
        solve();
    }
    return 0;
}