#include<bits/stdc++.h>
#define mk std::make_pair

using namespace std;
using pii = pair<int, int>;

const int N = 2e5+7;

typedef long long LL;

LL s,m;

bool check(LL now, vector<LL> have){
    LL x = s;
    for(int i = 0; i < have.size(); i++){
        LL num = x / have[i];
        x -= min(num, now) * have[i];
    }
    if(x != 0) return 0;
    return 1;
}

void solve()
{
    cin >> s >> m;
    vector<LL> have;
    for(int i = 63; i >= 0; i--){
        if((m>>i) & 1) {
            have.push_back(1LL<<i);
        }
    }
    for(int i = 0; i < 64; i++){
        if((m>>i) & 1) break;
        if(((s>>i)&1) && (((m>>i)&1) == 0)){
            cout << -1 << '\n';
            return;
        }
    }
    LL l = 1;
    LL r = 1e18;
    LL ans = 1e18;
    while(l <= r){
        LL mid= l + (r - l) / 2;
        if(check(mid,have)){
            ans = mid;
            r = mid-1;
        }
        else{
            l = mid+1;
        }
    }
    cout << ans <<'\n';
}

int main()
{
    int T = 1;
    cin >> T;
    while(T--){
        solve();
    }
    return 0;
}
//1 4
//1 2
//4 2