#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;

    while (t--) {
        long long s, m;
        cin >> s >> m;

        while (m % 2 == 0) {
            if (s % 2) {
                break;
            }

            s /= 2;
            m /= 2;
        }

        if (m % 2 == 0) {
            cout << "-1\n";
            continue;
        }

        long long l = 0, r = 1e18;

        while (l + 1 < r) {
            long long mid = (l + r) / 2, sum = s;

            for (int j = 60; j >= 0; j--) {
                if (m & (1LL << j)) {
                    sum -= min(mid, sum / (1LL << j)) * (1LL << j);
                }
            }

            if (sum > 0) {
                l = mid;
            } else {
                r = mid;
            }
        }

        cout << r << '\n';
    }
}