#include <bits/stdc++.h>
using namespace std;
#define PB push_back
#define MP make_pair
#define fst first
#define scd second
 
typedef __int128_t i128;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const ll INF = 1e15 + 7;
const int N = 1e6 + 7;
const int modN = 998244353;
const double PI = acos(-1);
mt19937_64 rng(time(0));

ll a[N];
void solve(){
    ll s, m;
    cin >> s >> m;
    
    auto check = [&](ll mid) {
        ll res = 0;
        for (int i = 60; i >= 0;i--){
            int bts = s >> i & 1, btm = m >> i & 1;
            if(bts)
                res += 1ll << i;
            if(btm){
                if(res / mid < (1ll << i))
                    res = 0;
                else
                    res = max(0ll, res - (1ll << i) * mid);
            }
        }
        // cerr << res << "\n";
        if(!res)
            return true;
        else
            return false;
    };
    ll l = 1, r = ll(1e18) + 7;
    while(l < r){
        ll mid = l + r >> 1;
        if(check(mid))
            r = mid;
        else
            l = mid + 1;
    }
    if(l == ll(1e18) + 7)
        cout << "-1\n";
    else
        cout << l << "\n";
}
 
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
 
    int T = 1;
    cin >> T;
    while (T--)
        solve();
 
    return 0;
}