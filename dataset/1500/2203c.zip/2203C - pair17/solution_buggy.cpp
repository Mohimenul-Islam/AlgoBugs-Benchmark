#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

void solve() {
	ll s, m;
	cin >> s >> m;
	
	vector<ll> a(65), b(65);
	for (int i = 0; i < 64; i++) {
		if (s >> i & 1) {
			a[i] = 1;
		}
		if (m >> i & 1) {
			b[i] = 1;
		}
	}
	
	auto check = [&] (ll mid) {
		vector<ll> c = a;
		for (int i = 64; i > 0; i--) {
			if (b[i] == 0) {
				c[i - 1] += c[i] * 2;
			} else if (c[i] > mid) {
				c[i - 1] += (c[i] - mid) * 2;
			}
		}	
		
		if (c[0] == 0) {
			return true;
		}
		
		if (c[0] <= mid && m % 2) {
			return true;
		}
		
		return false;
	};
	
	ll l = 1, r = 1e18 + 1;
	while (l < r) {
		ll mid = l + r >> 1;
		if (check(mid)) {
			r = mid;
		} else {
			l = mid + 1;
		}
	}
	
	cout << (l == 1e18 + 1 ? -1 : l) << "\n";
}	

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);

	int T = 1;
	cin >> T;

	while (T--) {
		solve();
	}

	return 0;
}
