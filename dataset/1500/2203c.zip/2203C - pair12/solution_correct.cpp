#include <iostream>
#include <vector>
#include <map>
#include <cmath>
#include <algorithm>

using namespace std;

int main() {
    long long t1;
    cin >> t1;

    while (t1--) {
        long long s, m;
        cin >> s >> m;
        
        // Binary representation as strings
        string k = "", m1 = "";
        long long temp_s = s, temp_m = m;

        // Get the binary representation in reverse order
        while (temp_s > 0) {
            k += (temp_s % 2) ? '1' : '0';
            temp_s /= 2;
        }
        
        while (temp_m > 0) {
            m1 += (temp_m % 2) ? '1' : '0';
            temp_m /= 2;
        }

        int c = 0;
        // Count leading zeros in the reversed binary of s
        for (char i : k) {
            if (i == '0') c++;
            else break;
        }

        // Count leading zeros in the reversed binary of m
        for (char i : m1) {
            if (i == '0') c--;
            else break;
        }

        if (c < 0) {
            cout << -1 << endl;
            continue;
        }

        int k1 = m1.length();
        vector<int> lst;
        
        // Collect indices where m1 has '1'
        for (int i = 0; i < k1; i++) {
            if (m1[i] == '1') {
                if (pow(2, i) > s) {
                    break;
                }
                lst.push_back(i);
            }
        }

        reverse(lst.begin(), lst.end());
        map<int, long long> dict, dict_ph;

        // Calculate initial values of dict and dict_ph
        for (int i : lst) {
            long long k = s / (1LL << i);
            dict[i] = k;
            dict_ph[i] = k;
            s -= k * (1LL << i);
        }

        long long l = 0, r = 1e18;

        // Binary search to find the maximum valid value
        while (l + 1 < r) {
            for (int i : lst) {
                dict[i] = dict_ph[i];
            }

            long long n = (l + r) / 2;
            long long mCheck = 0;

            // Adjust the dictionary based on the current value of n
            for (int i = 0; i < lst.size(); i++) {
                dict[lst[i]] -= n;
                dict[lst[i]] = max(0LL, dict[lst[i]]);
                
                if (i != lst.size() - 1) {
                    dict[lst[i + 1]] += dict[lst[i]] * (1LL << (lst[i] - lst[i + 1]));
                    dict[lst[i]] = 0;
                }
            }

            // Check if there's any non-zero value in dict
            for (const auto& d : dict) {
                if (d.second != 0) {
                    mCheck = 1; // Found a non-zero
                    break;
                }
            }

            if (mCheck) {
                l = n; // Move left
            } else {
                r = n; // Move right
            }
        }
        
        cout << r << endl; // Output the result
    }

    return 0;
}
