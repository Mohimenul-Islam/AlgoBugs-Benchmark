#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <cmath>
#include <bitset>

using namespace std;

int main() {
    int t1;
    cin >> t1;

    for (int i = 0; i < t1; ++i) {
        long long s, m; // Use long long for larger numbers
        cin >> s >> m;

        string k = bitset<32>(s).to_string(); // Convert to binary string
        string m1 = bitset<32>(m).to_string(); // Convert to binary string

        reverse(k.begin(), k.end());
        reverse(m1.begin(), m1.end());

        int c = 0;

        for (char bit : k) {
            if (bit == '0') {
                c++;
            } else {
                break;
            }
        }

        for (char bit : m1) {
            if (bit == '0') {
                c--;
            } else {
                break;
            }
        }

        if (c < 0) {
            cout << -1 << endl;
            continue;
        }

        vector<int> lst;
        for (int j = 0; j < m1.size(); ++j) {
            if (m1[j] == '1') {
                if (pow(2, j) > s) {
                    break;
                }
                lst.push_back(j);
            }
        }

        reverse(lst.begin(), lst.end());
        map<int, long long> dict; // Use long long for larger numbers
        for (int j : lst) {
            long long k = s / (1LL << j); // Use bit shifting instead of pow
            dict[j] = k;
            s -= k * (1LL << j); // Update s using bit-shift as well
        }

        for (int j = 0; j < 20; ++j) {
            int k = lst.size();
            for (int idx = 0; idx < k - 1; ++idx) {
                long long u = dict[lst[idx]];
                long long l1 = dict[lst[idx + 1]];

                long long h = u;
                long long l = 0;

                while (l + 1 != h) {
                    long long mid = (h + l) / 2;
                    long long ph = dict[lst[idx]] - mid;
                    long long ph1 = dict[lst[idx + 1]] + mid * (1LL << (lst[idx] - lst[idx + 1]));
                    if (ph1 <= ph) {
                        l = mid;
                    } else {
                        h = mid;
                    }
                }

                dict[lst[idx]] -= l;
                dict[lst[idx + 1]] += l * (1LL << (lst[idx] - lst[idx + 1]));
            }
        }

        long long max_ = 0;
        long long summ = 0;
        for (const auto& entry : dict) {
            summ += (1LL << entry.first) * entry.second; // Use bit-shifting
            max_ = max(max_, entry.second);
        }

        cout << max_ << endl;
    }

    return 0;
}