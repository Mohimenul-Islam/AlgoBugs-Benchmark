 
#include <bits/stdc++.h>
using namespace std;
#define ll long long
const int N = 1e5 + 10;
int masks[N] , ans[N];
 
int main(){
    int t;
    cin >> t;
    while(t --){
        int l, r;
        cin >> l >> r;
        cout << (ll)r * (r + 1) << endl;
        for (int i = l; i <= r; i ++)
            masks[i] = 0;
        for (int i = r; i > 0; i--)
        {
            if (!masks[i])
            {
                int j = ((1 << (32 - __builtin_clz(i))) - 1) ^ i;
                // 统计出来0的个数
                ans[i] = j;
                ans[j] = i;
                masks[i] = 1;
                masks[j] = 1;
            }
        }
        if(!masks[0]) // 如果前面没有数字配对 就代表自己和自己配对
            ans[0] = 0;
        for (int i = l; i <= r; i++){
            cout << ans[i] << " ";
        }
        cout << endl;
    }
 
    return 0;
}