#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int ans[N];
void solve(int r);
int main(){
	int t;
	cin>>t;
	while(t--){
		int l,r,l1,r1;
		cin>>l>>r;
		cout<<1ll*(r+1)*r<<"\n";
		solve(r);
		for(int i=0;i<=r;i++) cout<<ans[i]<<" ";
		cout<<"\n";
		for(int i=0;i<=r;i++) ans[i]=0;
	}
	return 0;
}
void solve(int r){
	int maxbit=(1<<(int)log2(r));//最大的小于r的2的整数次幂
	if(r==1){//特判
		ans[0]=1,ans[1]=0;return;
	}
	int l1=maxbit-1,r1=maxbit;//以2^k-1与2^k中间为轴，对称匹配
	while(l1>=0&&r1<=r){
		ans[l1]=r1,ans[r1]=l1;
		l1--,r1++;
	}
	if(maxbit==0) ans[0]=0;
	if(l1>0) solve(l1);//匹配剩余部分
}
