#include <bits/stdc++.h>
using namespace std;

#define int long long


void solve() {
    int a,b;
    cin >> a >> b;
    int msb = 0;
    int maxm = 0;
    for (int i = 31; i >=0; --i)
    {
        if(((1LL << i) & b) != 0){
            msb = i;
            //cout << msb << endl;
            maxm =  (1LL << (msb+1))-1 ;
            break;
        }
    }
    vector<int>ans(b+1,0);
    vector<bool>used(b+1,false);
    // for (int i = b; i >=0; --i)
    // {
    //     if( maxm-i <= b && !used[maxm - i]){
    //         used[maxm-i] = true;
    //         ans[i] = maxm-i;
    //     }else{
    //         msb--;
    //         maxm = (1LL << (msb+1))-1;
    //         if(!used[maxm - i]){
    //         used[maxm-i] = true;
    //         ans[i] = maxm-i;
    //     }
    //     }
    // }
    int i = b;
    while(i>=0){
        int k=0;
        while((1LL << k) <= i) k++;

         maxm = (1LL << (k))-1 ;
        int complement = maxm -i; 
        for (int j = complement; j <= i; ++j) {
            ans[j] = (maxm ^ j);
        }
        i = complement - 1;
    }

    int answer = 0;
    for (int i = 0; i < ans.size(); ++i)
    {
        answer += (i|ans[i]);
    }
    cout << answer << endl;
    for (int i = 0; i < ans.size(); ++i)
    {
        cout << ans[i] << " ";
    }
    cout << endl;

}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);


    int t_cases=1 ;
    cin >> t_cases;
    while (t_cases--) solve();

    return 0;
}