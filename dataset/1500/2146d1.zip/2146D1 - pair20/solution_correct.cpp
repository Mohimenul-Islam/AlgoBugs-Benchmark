#include <iostream>
#include <cmath>
#include <algorithm>
#include <set>
#include <unordered_set>
#include <map>
#include <unordered_map>
#include <climits>
#include <vector>
#include <string>
#include <iomanip>
#include <cctype>
#include <numeric>
#include <queue>
#include <deque>
#include <stack>
#include <tuple>
#include <random>

#define ll long long
#define ld long double
#define str string
#define pb push_back
#define all(x) x.begin(), x.end() 
#define rall(x) x.rbegin(), x.rend()
#define ff first
#define ss second
#define pqu priority_queue
#define sz(x) (int)(x).size()
#define ull unsigned long long

using namespace std;

void solve() {
    ll l, r; cin >> l >> r;
    ll n = r - l + 1;
    int pw = 1;
    while (pw < r){
        pw = (pw << 1) | 1;
    }
    set<int> s;
    for (int i = l; i <= r; ++i) s.insert(i);
    vector<int> vec(r + 1);
    ll ans = 0;
    for (int i = r; i >= l; --i){
        while (s.find(pw - i) == s.end()){
            pw >>= 1;
        }
        vec[i] = pw - i;
        s.erase(pw - i);
    }
    cout << n*r << "\n";
    for (int i = l; i <= r; ++i){
        cout << vec[i] << " ";
    }
    cout << "\n";
}


int main(){
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
    int t = 1; cin >> t;
    while (t--){
        solve();
    }
    return 0;
}