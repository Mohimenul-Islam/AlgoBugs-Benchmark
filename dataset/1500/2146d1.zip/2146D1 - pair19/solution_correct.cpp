//  ╔══════╗           ╔╗   ╔╗           ╔══════╗
//  ║      ║           ║║   ║║           ║      ║
//  ║      ║           ║║   ║║           ║      ║
//  ║      ║           ║║   ║║           ║      ║
//  ║      ╚══════╗    ║╚═══╝║    ╔══════╝      ║
//  ║             ║    ║     ║    ║             ║
//  ║             ║    ║     ║    ║             ║
//  ║             ║    ║     ║    ║             ║
//  ║             ║    ║     ║    ║             ║
//  ╚═════════════╝    ╚═════╝    ╚═════════════╝

//____________________ crybaby___________________

#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ll long long
#define int long long
const int MOD = 998244353;
const int mod = 1e9 + 7;   
const int inf = 0x3f3f3f3f;

//发现很难做的时候要回溯
//看看在转化题意时是否漏掉条件
//记得控温

void solve()
{
	int l,r; cin >> l >> r;
	vector<int> a(r+1);
	// for(int i = 0; i <= r; i++)
	// {
	// 	cin >> a[i];
	// }
	int mx = 0;
	for(int i = 0; i < 30; i++)
	{
		if((r>>i)&1) mx = i;
	}
	vector<bool> vis(r+1,0);
	vector<int> ans(r+1);
	int res = (1<<(mx+1))-1;
	for(int i = r; i >= 0; i--)
	{
		// int cnt = (res^i);
		while((res^i) > r||vis[res^i]) 
		{
			res >>= 1;
			if(res == 0) break;
		}
		ans[i] = res^i;
		vis[res^i] = 1;
	}
	cout << 1LL*r*(r+1) << endl;
	for(int i : ans) cout << i << " ";
	cout << endl;
	
}
//注意数据范围尤其是负数
//取模时注意除法 除法要用逆元
//没过第一时间去向会不会是数组越界

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);
	
	int T = 1;
	cin >> T;
	while(T--) solve();

	return 0;
}
