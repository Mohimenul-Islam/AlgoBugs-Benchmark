#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define FOR(i,a,b) for (ll i = (a); i < (b); i++)
using vll = vector<ll>;
#define pb push_back
#define ff first
#define ss second

ll msb(ll x) {
    if (x == 0) return 0;
    return 63 - __builtin_clzll(x);
}

void solve(){
    ll l , r;
    cin>>l>>r;

    cout<<r*(r+1)<<endl;

    if(r == 0){
        cout<<0<<endl;
        return;
    }

    vll ans(r+1 , -1);

    set<ll> s;

    FOR(i,0,r+1)s.insert(i);

    for(ll i = r ; i>= 1 ; i--){
        if(ans[i] != -1)continue;

        ll val = i;

        for(ll j = msb(i) ; j>= 0 ; j--){
            val ^= (1LL << j);
        }

        ans[i] = val;
        if(val<=r)ans[val] = i;

        s.erase(i);
        s.erase(val);

    }

    if(ans[0] == -1)ans[0] = *s.begin();

    for(auto &x : ans)cout<<x<<" ";
    cout<<endl;
    cout<<endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    ll t;
    cin >> t;
    while(t--){
        solve();
    }
    return 0;
}