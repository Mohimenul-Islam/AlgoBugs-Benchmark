#include <iostream>
#include <cstdint>
#include <cstring>
#include <vector>
#include <algorithm>
#include <functional>
#include <queue>
#include <numeric>
#include <array>
#include <iomanip> // cout << fixed << setprecision(n);
#include <cmath>
#include <set>

using namespace std;
const bool TEST_CASE = true;

template<typename T>
typename std::enable_if<std::is_integral<T>::value>::type
Debug(const char* name, T value) {
    std::cout << name << " : " << value << '\n';
}

template<typename T, typename... Args>
typename std::enable_if<std::is_integral<T>::value>::type
Debug(const char* names, T value, Args... args){
    const char* comma = strchr(names, ',');
    std::cout.write(names, comma - names) << " : " << value << " | ";
    Debug(comma + 1, args...);
}
template<typename T> 
ostream& operator<<(ostream& out, vector<T> &a){
    for (auto &x : a) out << x << ' '; 
    return out;
};

#ifdef DORMON
    #define debug(...) Debug(#__VA_ARGS__, __VA_ARGS__)
#else
    #define debug(...) 
#endif

void solve(){
    int l, r;
    cin >> l >> r;
    set<int> s;
    for (int i = l;i <= r;i++) s.insert(i);
    vector<int> ans(r + 1);
    int mx_bit = 0, sum = 0;
    while (mx_bit < r) mx_bit = (mx_bit << 1) | 1;
    for (int i = r;i >= l;i--){
        int now = mx_bit;
        while (s.find(now ^ i) == s.end()) now >>= 1;
        ans[i] = now ^ i;
        sum += i | (now ^ i);
        s.erase(now ^ i);
    }
    cout << sum << '\n';
    cout << ans << '\n';
}


int main()
{
    #ifndef DORMON
        ios_base::sync_with_stdio(false); 
    #endif
    cin.tie(0);
    int q = 1; 
    if (TEST_CASE) cin >> q;
    while (q--){
        solve();
    }
}