// Copyright (C) since 2025 hanziwei
// All rights reserved

#include <bits/stdc++.h>

using u32 = unsigned;
using i64 = long long;
using u64 = unsigned long long;

using i128 = __int128;
using u128 = unsigned __int128;

constexpr int LN = 30;

int32_t main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int t;
    std::cin >> t;

    auto solve = [&]() -> void {
        int l, r;
        std::cin >> l >> r;

        std::vector<int> a(r + 1);
        int x = r;
        std::iota(a.begin(), a.end(), 0);
        while (x > 0) {
            int k = std::__lg(x) + 1; // (2 ** k - 1) - x <= i <= x
            std::reverse(a.begin() + ((1 << k) - 1) - x, a.begin() + x + 1);
            x = ((1 << k) - 1) - x - 1;
        }

        std::cout << 1LL * r * (r + 1) << "\n";
        for (int i = 0; i <= r; i++) {
            std::cout << a[i] << " \n"[i == r];
        }
    };

    for (int i = 0; i < t; i++) {
        solve();
    }

    return 0;
}

/*
题型 ： 构造
错因码 ： I
首错点 ： 
致命原因 ： 没有开 i64
改对关键 ： 
下次提醒 ： 做对题的时候，不要激动，检查一些 corner

错因码：
T 题意理解错
M 模型判断错
S 状态设计错
R 转移/递推错
G 贪心依据错
P 证明/转化错
D 数据结构或算法选型错
B 边界/特判错
C 复杂度判断错
I 实现细节错
*/