// Copyright (C) since 2025 hanziwei
// All rights reserved

#include <bits/stdc++.h>

using u32 = unsigned;
using i64 = long long;
using u64 = unsigned long long;

using i128 = __int128;
using u128 = unsigned __int128;

constexpr int LN = 30;

int32_t main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int t;
    std::cin >> t;

    auto solve = [&]() -> void {
        int l, r;
        std::cin >> l >> r;

        std::vector<int> a(r + 1);
        int x = r;
        std::iota(a.begin(), a.end(), 0);
        while (x > 0) {
            int k = std::__lg(x) + 1; // (2 ** k - 1) - x <= i <= x
            std::reverse(a.begin() + ((1 << k) - 1) - x, a.begin() + x + 1);
            x = ((1 << k) - 1) - x - 1;
        }

        std::cout << r * (r + 1) << "\n";
        for (int i = 0; i <= r; i++) {
            std::cout << a[i] << " \n"[i == r];
        }
    };

    for (int i = 0; i < t; i++) {
        solve();
    }

    return 0;
}