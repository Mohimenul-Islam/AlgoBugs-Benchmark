#include<bits/stdc++.h>
#define int long long
using namespace std;
using VI = vector<int>;
using PII = pair<int, int>;
using VePII = vector<PII>;
using i128 = __int128;
//priority_queue<int,vector<int>,greater<int>> q;
//<<fixed<<setprecision(10)
const int INF=1e18;
const int NINF = -1e18; 
const int MD=998244353;

int lcm(int a,int b){
    return a*b/__gcd(a,b);
}

int qp(int x){
    int sum=1;
    x>>=1;
    while(x){
        sum=(sum<<1)+1;
        x>>=1;
    }
    return sum;
}



void solve(){
    int l,r;
    cin>>l>>r;
    if(r==0){
        cout<<0<<'\n'<<0<<'\n';
        return;
    }
    VI a(r+1);
    for(int i=r;i>=0;i--){
        int x=qp(i);
        if(a[i]!=0)continue;
        if(a[x^i]!=0){
            a[i]=i;
            continue;
        }
        //cout<<x<<'\n';
        a[i]=x^i;
        a[x^i]=i;
    }
    int sum=0;
    for(int i=0;i<=r;i++)sum+=(i|a[i]);
    cout<<sum<<'\n';
    for(int i=0;i<=r;i++){
        
        cout<<a[i]<<' ';

    }
    cout<<'\n';
}

signed main(){
	ios_base::sync_with_stdio(false);
    cin.tie(NULL);
	cout.tie(NULL);
	int t;
    cin>>t;
    while(t--){
        solve();
    }
	
	return 0;
}