#include "bits/stdc++.h"
using namespace std;

#ifndef DeBuG
    #define dbg(...)
#endif

#define sz(x) (int)(x).size()
#define all(x) begin(x), end(x)

using ll = long long;
const int MOD = 1e9 + 7, N = 2e5 + 5;


int flipMSB(int n) {
    int msb = 1;

    while (msb <= n) {
        msb <<= 1;
    }

    msb >>= 1; // actual MSB position

    return n ^ msb;
}

void solve() {
    int l, r; cin >> l >> r;

    vector<int> tkn(r + 1, 0), ans(r + 1);

    int pw = log(r)/log(2) + 1;
    for(int i = r ; i >= 0 ; i--) {
        int nw = i, gt = 0;
        for(int j = 0 ; j < pw ; j++) {
            if(!((nw >> j) & 1)) gt |= (1LL<<j); 
        }
       // dbg(i, gt);

        while(gt) {
            if(gt <= r && !tkn[gt]) {
                ans[i] = gt;
                tkn[gt] = 1;
                break;
            }
            gt = flipMSB(gt);
        }
    }
    
    cout<<r * (r + 1)<<'\n';
    for(auto &x : ans) {
        cout<<x<<' ';
    }
    cout<<'\n';
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int T = 1;
    cin >> T;
    for (int ti = 1; ti <= T; ti++) {
        solve();
    }
}