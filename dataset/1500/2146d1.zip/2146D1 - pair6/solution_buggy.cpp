#include <type_traits>
#include <bits/stdc++.h>
using namespace std;
#define eee '\n'
#define rv(x) return void(cout << x << '\n')
#define all(arr) arr.begin(), arr.end()
#define allr(arr) arr.rbegin(), arr.rend()
#define fill(arr) for (auto &e: arr) cin >> e;
typedef long long ll; const string yes = "YES", no = "NO";
constexpr ll MOD = 676767677, N = 1e5, M = 1e5, INF = 1e9;

struct BinaryTrie {
private:
    struct Node {
        Node *child[2];
        int frq[2];
        Node(){
            child[0] = child[1] = 0;
            frq[0] = frq[1] = 0;
        }
    };

    Node *root = new Node();
    void del(int n, int i, Node *cur) {
        if(i == -1) return;
        bool idx = (n>>i)&1;
        del(n, i-1, cur->child[idx]);
        cur->frq[idx]--;
        if(cur->frq[idx] == 0) {
            delete cur->child[idx];
            cur->child[idx] = 0;
        }
    }

public:
    void insert(int n) {
        Node *cur = root;
        for(int i = 29;i >= 0; i--) {
            bool idx = (n>>i)&1;
            if(cur->child[idx] == 0) cur->child[idx] = new Node();
            cur->frq[idx]++;
            cur=cur->child[idx];
        }
    }

    void del(int n) {
        del(n, 29, root);
    }

    int query(int n) {
        int ret = 0; Node *cur = root;
        for(int i = 29; i >= 0; i--) {
            bool idx = (n>>i)&1;
            if(cur->child[idx^1] != 0) {
                ret |= (idx^1) << i;
                cur = cur->child[idx^1];
            } else {
                ret |= idx << i;
                cur = cur->child[idx];
            }
        }
        return ret;
    }
};

void singleTestCase(int tc) {
    int l, r; cin >> l >> r;

    BinaryTrie br;
    for (int i = l; i <= r; ++i) {
        br.insert(i);
    }

    int ansVal = 0;
    vector<int> ansArr;
    for (int i = l; i <= r; ++i) {
        int x = br.query(i);
        br.del(x);
        ansArr.emplace_back(x);
        ansVal += i | x;
    }

    cout << ansVal << eee;
    for (auto i: ansArr) {
        cout << i << " ";
    }   cout << eee;
}

int main() {
    ios::sync_with_stdio(false);cin.tie(nullptr);
    cout.tie(nullptr);istream::sync_with_stdio(false);

#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
#endif
    int tc = 1;
    cin >> tc;
    for(int i = 0; i < tc; ++i){
        singleTestCase(i);
    }

    return 0;
}
