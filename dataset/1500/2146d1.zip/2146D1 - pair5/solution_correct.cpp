#include <bits/stdc++.h>

typedef long long ll;

using namespace std;

ll gcd(ll a, ll b){
    if(b == 0)
        return a;
    return gcd(b, a % b);
}

int pw(int a,int b, int mod){
    if(b == 0)
        return 1;
    int c = 1ll * pw(a,b / 2,mod);
    if(b % 2){
        return 1ll * c * c % mod * a % mod;
    }
    else{
        return 1ll * c * c % mod;
    }
}


void solve(){
    int l, r;
    cin >> l >> r;
    vector<int> ans(r + 1,-1);

    for(int i = r;i >= 0;--i){
        if(ans[i] != -1)
            continue;
        int num = 0;
        for(int j = log2(i);j > 0;--j){
            if((i & (1 << j - 1)) != 0)
                continue;
            num += (1 << j - 1);
        }
        ans[i] = num;
        ans[num] = i;
    }

    cout << 1ll * r * (r + 1) << endl;
    for(auto it : ans)
        cout << it << " ";
    cout << endl;
}


int main()
{
    int t = 1;
    cin >> t;
    while(t--)
        solve();
}
