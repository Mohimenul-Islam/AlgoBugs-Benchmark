#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
using namespace std;

#ifndef ONLINE_JUDGE
    #define _GLIBCXX_DEBUG
#endif

const int MOD=1e9+7;
int INF= 1e9;
#define ll long long
const double PI = acos(-1.0);
const double EPS= 1e-11;

void solve(){
    int x, n; cin>>x>>n; 
    cout<<1LL*n*(n+1)<<"\n"; 
    if (n!=0){
    vector <int> arr(n+1);
    int maxpow=0;
    for (int i = 0; i<=n; i++) {
        arr[i]=i;
        if (__builtin_popcount(i)==1) maxpow=i;
    }
    maxpow*=2;
    vector <int> brr(n+1); 
    set <int> used;
    for (int i=n; i>=0; i--) {
        if (maxpow-1-i<=n && used.find(maxpow-1-i)==used.end()) brr[i]=maxpow-1-i;
        else {
            while (!(maxpow-1-i<=n && used.find(maxpow-1-i)==used.end())){
            maxpow/=2; }
            brr[i]=maxpow-1-i;
        }
        used.insert(brr[i]);
        // cout<<brr[i]<<"*";
    }

    for (int i = 0; i<=n; i++) {
        cout<<brr[i]<<" ";
    }}
    else {cout<<0;}



}


void fastio(){
    #ifndef ONLINE_JUDGE
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
    #endif
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
}

int main() {
    fastio();
    int t; cin>>t;
    // int t=1; 
    while (t--) {solve(); cout<<"\n"; }
}