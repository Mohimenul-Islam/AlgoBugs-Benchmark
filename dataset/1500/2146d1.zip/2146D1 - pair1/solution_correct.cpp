/* ❀ Apeiron Coding ❀ */
#include<bits/stdc++.h>
using namespace std;
#define Apeiron main
#define endl '\n'
#define int long long

int f(int x){
    int y = 0;
    int p = 0;
    while((1<<p)<=x){
        int t = (x>>p) & 1;
        y |= (t^1)<<p;
        p++;
    }
    return y;
}

void solve(){
    int l, r; cin>>l>>r;
    vector<int> v(r+1);
    // cout<<bitset<8>(r)<<endl;
    // cout<<bitset<8>(f(r))<<endl;

    int tt = r;
    int t = f(r);
    for(int i=r;i>=0;i--){
        if(t > tt){
            t = f(i);
            tt = i;
        }
        v[i] = t++;
    }
    int sum = 0;
    for(int i=0;i<=r;i++) sum += i|v[i];
    cout<<sum<<endl;
    for(int i=0;i<=r;i++) cout<<v[i]<<" ";
    cout<<endl;
}

signed Apeiron(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int A=1;
    cin>>A;
    while(A--){
        solve();
    }
    cout.flush();
    return 0;
}