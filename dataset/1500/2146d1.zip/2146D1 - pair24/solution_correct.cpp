#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#pragma GCC optimize("Ofast,unroll-loops")

#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define rev(v) reverse(v.begin(),v.end())
#define soi(v) sort(all(v))
#define sod(v) sort(all(v),greater<>())
#define soc(v,comp) sort(all(v),comp)
#define pb push_back
#define int long long

using namespace std;
using namespace __gnu_pbds;

using ll = long long;
using ld = long double;
using vi = vector<int>;
using vvi = vector<vi>;

template<class T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

const int mod1 = 1e9+7;
const int mod2 = 998244353;
const int INF = 1e18;

struct node{
    node* chld[2];
    int count;

    node(){
        chld[0] = chld[1] = nullptr;
        count = 0;
    }
};

class tri{
private:
    node* root;
public:
    tri(){
        root = new node();
    }

    void insert(int num){
        node* curr = root;
        curr->count++;
        for (int i = 30; i >= 0; i--)
        {
            int bit = (num>>i)&1;
            if(curr->chld[bit]==nullptr){
                node* newnode = new node();
                curr->chld[bit] = newnode;
            }
            curr = curr->chld[bit];
            curr->count++;
        }
    }

    void find(int num, int &res){
        node* curr = root;
        curr->count--;
        for (int i = 30; i >= 0; i--)
        {
            int bit = (num>>i)&1;
            int bitn = !bit;
            if(curr->chld[bitn] == nullptr || curr->chld[bitn]->count == 0){
                res |= (bit<<i);
                curr = curr->chld[bit];
            }else{
                res |= (bitn<<i);
                curr = curr->chld[bitn];
            }
            curr->count--;
        }
    }

    ~tri(){
        delete root;
    }
};

void solve(){
    int l,r;
    cin>>l>>r;
    tri t;
    for (int i = l; i <= r; i++)
    {
        t.insert(i);
    }
    int res = 0;
    vi ans(r-l+1);
    int f = 0;
    for (int i = r; i >= l; i--)
    {
        res = 0;
        t.find(i, res);
        // ans.pb(res);
        ans[i-l] = res;
        f+=(i|res);
        // res |= i;
    }

    cout<<f<<"\n";
    for(auto x: ans){
        cout<<x<<" ";
    }cout<<endl;
}

signed main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int t = 1;
    cin >> t;
    while(t--){
        solve();
    }

    return 0;
}