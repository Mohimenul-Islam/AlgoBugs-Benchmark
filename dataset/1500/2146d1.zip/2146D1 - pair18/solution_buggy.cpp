#include <iostream>
#include <vector>
using namespace std;
void solve()
{
    int l,r;
    cin >> l >> r;
    int ffff = r;
    cout << r * (r + 1) << '\n';
    int cnt = 0;
    vector<int> res(r + 1);
    for(int temp = r;temp;temp /= 2)
        cnt++;
    for(int i = 0;i <= r;i++)
        res[i] = i;
    while(r)
    {
        for(int i = 0;i + (1 << (cnt - 1)) <= r;i++)
            swap(res[(1 << (cnt - 1)) - 1 - i],res[(1 << (cnt - 1)) + i]);
        r -= 2 * (r - (1 << (cnt - 1)) + 1);
        if(r <= 0)
            break;
        cnt--;
    }
    for(int i = 0;i <= ffff;i++)
        cout << res[i] << ' ';
    cout << '\n';
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cout.unsetf(ios::fixed);
    cout.precision(20);
    int t;
    cin >> t;
    while(t--)
        solve();
}