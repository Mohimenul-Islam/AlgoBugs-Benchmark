#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N = 300030;
int T;
int l, r;
int a[N];

void solve() {
    cin >> l >> r;
    cout << r * (r + 1) << endl;
    int x = r;
    for (int i = 30; i >= 0; i--) {
        if (x >> i & 1) {
            int j = (1 << i);
            int k = 0;
            for (; j + k <= x; k++) {
                a[j + k] = j - k - 1;
                a[j - k - 1] = j + k;
            }
            x -= 2 * k;
        }
    }
    for (int i = 0; i <= r; i++) {
        cout << a[i] << ' ';
    }
    cout << endl;
}
signed main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> T;
    while (T--) {
        solve();
    }
    return 0;
}

