#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;
    
#define ll long long
#define ld long double
#define f first
#define s second
#define pi pair<ll,ll>
#define pb push_back
#define bpc __builtin_popcount
#define rf __builtin_ctz
#define ub upper_bound
#define lb lower_bound
#define tos accumulate
#define mae max_element
#define mie min_element
    
typedef tree<ll, null_type, less<ll>, rb_tree_tag, tree_order_statistics_node_update> Oset;
    
#define ve vector
#define vi ve<ll>
#define vb ve<bool>
#define vvi ve<vi>
    
#define all(v) v.begin(),v.end()
#define sortv(v) sort(all(v))  
#define sortrv(v) sort(all(v),greater<ll>())
#define rv(v) reverse(all(v))
    
#define l(i,a,b) for (ll i=a;i<b;i++)
#define lr(i,b,a) for (ll i=b-1;i>=a;i--)
    
#define inp(a)           \
    ll a;                \
    cin>>a;
    
#define inps(a)           \
    string a;                \
    cin>>a;
    
#define getv(a)          \
    for(auto i:a)        \
        cout<<i<<" ";    \
    cout<<"\n";
    
#define inpv(v,n)        \
    vi v(n);             \
    l(i,0,n) cin>>v[i];
    
#define tc               \
    inp(t);              \
    while(t--) solve();
    
void fast(){                                 
    ios_base::sync_with_stdio(false);        
    cin.tie(NULL);                           
    cout.tie(NULL);                          
}
    
#define yes cout<<"YES\n"
#define no cout<<"NO\n"
    
const ll mod = 1e9+7;
    
ll bex(ll ba,ll bp){
    ll res=1;
    while(bp){
        if(bp&1) res=(res*ba)%mod;
        bp>>=1;
        ba=(ba*ba)%mod;
    }
    return res;
}
    
vi findDiv(ll n){
    vi div;
    for(int i=1;i*i<=n;i++){
        if(n%i==0){
            div.pb(i);
            if(i!=(n/i)) div.pb(n/i);
        }
    }
    sortv(div);
    return div;
}
    
ll gcd(ll a,ll b) {return (b==0)? a:gcd(b,a%b);}
ll lcm(ll a,ll b) {return (a/gcd(a,b))*b;}
    
void solve(){
    inp(le);inp(r);
    
    if(le==r){
        cout<<le<<"\n";
        cout<<le<<"\n";
        return;
    }
    
    ll d=log2(r)+1;
    ll cur=(1LL<<d)-1;
    ll ans=0;
    vi v;
    
    set<ll> s;
    l(i,le,r+1) s.insert(i);
    
    for(int i=r;i>=le;i--){
        while(s.find(cur-i)==s.end()) cur>>=1;
        
        ans+=(i)|(cur-i);
        v.pb(cur-i);
        s.erase(cur-i);
    }
    
    cout<<ans<<"\n";
    lr(i,v.size(),0){
        cout<<v[i]<<" ";
    }
    cout<<"\n";
}
    
int main(){
    fast();
    tc;
    return 0;
}