#include <bits/stdc++.h>
#define Sandevistan   ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define int long long int
#define double long double
#define py {cout << "YES" << endl; return;}
#define pn {cout << "NO" << endl; return;}
#define px {cout << -1 << endl; return;}
#define fr(i, n) for (int i = 0; i < n; i++)
#define test() cout<<"OK!"<<endl;
#define pb push_back
#define sze(x) x.size()
#define all(v) v.begin(), v.end()
#define gcd(a, b) __gcd(a, b)
#define lcm(a, b) (a * b) / gcd(a, b)
#define comb(n,a,b) (n-a+1)*(n-b+1)
#define ff first
#define ss second
#define MX(x) *max_element(all(x));
#define MN(x) *min_element(all(x));
#define nobits(x) __builtin_popcountll(x)
#define print(x) for(auto &it:x) cout<<it<<" ";
const int INF = 1e18;
const int NN = 1e6 + 10;
const int MOD = 1e9+7;
const int dx[8] = {1, -1, 0, 0, 1, 1, -1, -1};
const int dy[8] = {0, 0, 1, -1, 1, -1, 1, -1};
using namespace std;
using namespace __gnu_pbds;
template <typename T>
using ordered_set = tree<T,null_type,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

void printQ(int r){
    cout<<r<<endl;
    cout.flush();
}

int binPow(int a, int b, int mod) {
    a %= mod;
    int res = 1;
    while (b > 0) {
        if (b & 1) res = (res * a) % mod;
        a = (a * a) % mod;
        b >>= 1;
    }
    return res;
}
 
//--- -----,---

void solve(){
    int l,r; cin>>l>>r;
    int n = r+1;
    vector<int>arr(r+1);
    int mx = 1;
    while(mx<<1 <= n){
        mx<<=1;
    }
    for(int i=mx-1;i>-1;i--){
        int idx = (mx-1) - i;
        arr[idx] = i;
    }
    for(int i=mx;i<n;i++){
        arr[i]=i;
        swap(arr[i],arr[i-mx]);
    }
    int len = n-mx;
    while(len>1){
        int tempmx =1;
        while(tempmx<<1 <=len){
            tempmx<<=1;
        }
        for(int i=0;i<tempmx/2;i++){
            swap(arr[i],arr[tempmx-1-i]);
        }
        for(int i=tempmx;i<len;i++){
            swap(arr[i],arr[i-tempmx]);
        }
        //test();
        len = len-tempmx;
    }
    int res = 0;
    for(int i=0;i<n;i++){
        res += i | arr[i];
    }
    cout<<res<<endl;
    print(arr); cout<<endl;
}



#undef int
signed main()
{
    Sandevistan
    int TT = 1;
    cin >> TT;
    while (TT--) { //cout<<TT+1<<endl;
         solve();}
    return 0;
}
