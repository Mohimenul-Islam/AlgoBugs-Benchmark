#include <bits/stdc++.h>
#define ll long long
#define INF 0x3f3f3f3f
#define LINF 0x3f3f3f3f3f3f3f3f
#define int long long
#define pii pair<int, int>
#define ai2 array<int, 2>
#define ai3 array<int, 3>
#define ai4 array<int, 4>
#define ai26 array<int, 26>
#define popcount __builtin_popcount
#define Mod 998244353
// #define Mod 1000000007
#define endl "\n"
using namespace std;

int highbit(int x)
{
    x |= x >> 1;
    x |= x >> 2;
    x |= x >> 4;
    x |= x >> 8;
    x |= x >> 16;
    return x - (x >> 1);
}

void solve()
{
    int z, n;
    cin >> z >> n;
    vector<int> a;
    cout << n * (n + 1) << endl;
    while (n >= 0)
    {
        if (n == 0)
        {
            a.push_back(0);
            break;
        }
        int hb = highbit(n);
        int dif = n - hb + 1;
        for (int i = hb - dif; i <= n; i++)
        {
            a.push_back(i);
        }
        n = hb - dif - 1;
    }
    reverse(a.begin(), a.end());
    for (auto i : a)
    {
        cout << i << ' ';
    }
    cout << endl;
}

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    // cout << fixed << setprecision(10) << endl;
    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}