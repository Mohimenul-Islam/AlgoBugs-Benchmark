#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
#include <queue>
#include <stack>
#include <deque>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <numeric>
#include <limits>
#include <iomanip>

using namespace std;

/* ===================== TYPES ===================== */
using ll = long long;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using vi = vector<int>;
using vll = vector<ll>;

/* ===================== MACROS ===================== */
#define pb push_back
#define ff first
#define ss second
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define sz(x) (int)(x).size()

/* ===================== I/O HELPERS ===================== */
template<typename T>
void read_vector(vector<T> &v) {
    for (auto &x : v) cin >> x;
}

template<typename T>
void print_vector(const vector<T> &v, char sep = ' ') {
    for (int i = 0; i < (int)v.size(); i++) {
        cout << v[i] << (i + 1 == (int)v.size() ? '\n' : sep);
    }
}
int complement(int n){
    bool first=false;
    int res=0;
    for (int i=31;i>=0;i--){
        int bit = n&(1<<i);
        if (bit!=0){
            if (!first)first=true;
        }
        else{
            if(first){
                res+=(1<<i);
            }
        }
    }
    return res;
}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin>>t;
    while(t--){
        ll l,r;
        cin>>l>>r;
        vll ans(r+1,-1);
        for (int i=r;i>=0;i--){
            if (ans[i]==-1){
                ll res = complement(i);
                ans[i]=res;
                ans[res]=i;
            }
        }
        cout<<(r*(r+1))<<endl;
        print_vector(ans);
        // ll s=0;
        // for (int i=0;i<=r;i++){
        //     s+=(i|ans[i]);
        // }
        // cout<<s<<endl;
    }

    return 0;
}