#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
//والله ولي التوفيق
#define int long long
#define AbdoMO ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);cin.sync_with_stdio(0);
#define ld long double
#define el '\n'
#define rv return void
#define all(v) v.begin(),v.end()
#define allr(v) v.rbegin(),v.rend()
#define popcount(x) (__builtin_popcountll(x))
#define intCeil(x, y) (x+y-1)/y
#define msb(x) 63ll - __builtin_clzll(x)
using namespace __gnu_pbds;
using namespace std;
template<class T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

template<class T>
using ordered_multiset = tree<pair<T, int>, null_type, less<
        pair<T, int>>, rb_tree_tag, tree_order_statistics_node_update>;

typedef long long ll;

// بسم الله ربي ووكيلي
// -Take it easy- <3

const int dx[] = {0, 0, 1, -1};
const int dy[] = {1, -1, 0, 0};

const string di = "RLDU";

const ll N = 101, M = 1e5 + 1, OO = 1e18, shift = 1e5, MOD = 1e9 + 7;
int non = 5002;

// You just can't beat the person who never gives up

void Solve(int tc) {

    int l, r, tot = 0;
    cin >> l >> r;
    vector<int> res(r + 1);
    int cur = r;
    while (cur > 0) {
        int mask = (1ll << (msb(cur) + 1)) - 1;
        int comp = cur ^ mask;
        for (int i = comp; i <= cur; ++i) {
            res[i] = mask ^ i;
            tot += mask;
        }
        cur = comp - 1;
    }
    cout << tot << el;
    for (int i = 0; i <= r; ++i) {
        cout << res[i] << " ";
    }
    cout << el;


}


signed main() {
    AbdoMO
#ifndef ONLINE_JUDGE
    freopen("in.txt", "r", stdin);
#endif
    int tc = 1;
    cin >> tc;
    cout << fixed << setprecision(6);
    for (int i = 1; i <= tc; ++i) {
        Solve(i);
    }

}