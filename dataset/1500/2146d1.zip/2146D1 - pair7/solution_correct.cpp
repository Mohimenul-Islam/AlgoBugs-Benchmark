#include <bits/stdc++.h>
using namespace std;
#define int long long
#define el '\n'
#define M0waleed ios_base::sync_with_stdio(false); cin.tie(NULL);
#define F first
#define S second
#define pi pair<int, int>
#define vvi vector<vector<int>>
#define all(obj) obj.begin(), obj.end()
#define rall(obj) obj.rbegin(), obj.rend()
#define no cout << "NO\n"
#define yes cout << "YES\n"
constexpr int OO = LLONG_MAX, MOD = 998244353;
int dx[] = {0, 0, 1, -1, 1, 1, -1, -1};
int dy[] = {1,-1, 0, 0, 1, -1, 1, -1};


void solve() {
    int l, r;cin >> l >> r;

    vector<int> ans(r - l + 1);
    long long total = 0;

    int cur = r;
    while (cur >= l) {
        if (cur == 0) {
            if (0 >= l) ans[0 - l] = 0;
            break;
        }

        int msb = 63 - __builtin_clzll(cur);
        int mask = (1LL << (msb + 1)) - 1;
        int comp = mask ^ cur;

        int start = max(l, comp);
        total += (cur - start + 1) * mask;

        for (int j = start; j <= cur; j++) {
            ans[j - l] = mask ^ j;
        }

        if (comp <= l) break;
        cur = comp - 1;
    }

    cout << total << el;
    for (int i = 0; i < ans.size(); i++) {
        cout << ans[i] << (i == ans.size() - 1 ? "" : " ");
    }
    cout << el;
}

signed main() {
    M0waleed
    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}