#include <iostream>
#include <sstream>
#include <bits/stdc++.h>
using namespace std;
#define int long long

void solve()
{
	int n;
	cin>>n;
	vector<vector<int>> v(n);
	vector<set<int>> s(n);
	set<int> tot;
	for(int i=0;i<n;i++)
	{
		int sz; cin>>sz;
		for(int j=0;j<sz;j++)
		{
			int x; cin>>x;
			if(s[i].find(x) != s[i].end()) continue;
			v[i].push_back(x);
			s[i].insert(x);
			tot.insert(x);
		}
		reverse(v[i].begin(), v[i].end());
	}
	vector<int> ans;
	set<int> unseen;
	for(int i=0;i<n;i++) unseen.insert(i);
	for(int st=0;st<n;st++)
	{
		if(unseen.size() == 0) break;
		int min_idx = *(unseen.begin());
		for(auto i : unseen)
		{
			if(v[i] < v[min_idx]) min_idx = i;
		}
		
		for(auto x : v[min_idx])
		{
			ans.push_back(x);
			for(int i=0;i<n;i++)
			{
				s[i].erase(x);
			}
		}
		unseen.erase(min_idx);

		for(int i=0;i<n;i++)
		{
			vector<int> temp;
			for(int j=0;j<v[i].size();j++)
			{
				if(s[i].count(v[i][j])) temp.push_back(v[i][j]);
			}
			v[i] = temp;
		}
	}

	for(auto x : ans) cout<<x<<" ";
	cout<<endl;
}

int32_t main() 
{
  ios_base::sync_with_stdio(0);	
  cin.tie(0); cout.tie(0);
  int T;
  cin>>T;
  //T = 1;
  while(T--)
  {
    solve();
  }
  return 0;
}