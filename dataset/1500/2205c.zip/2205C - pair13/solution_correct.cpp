#include <bits/stdc++.h>
using namespace std;

#define all(x) begin(x),end(x)
using ll = long long;
using pll = pair<ll,ll>;


void solve()
{
    ll n;
    cin>>n;
    vector<vector<ll>>a(n);
    unordered_map<ll,ll>mp;
    for(ll i=0;i<n;i++)
    {
        ll num;
        cin>>num;
        for(ll j=0;j<num;j++)
        {
            ll x;cin>>x;
            a[i].push_back(x);
        }
        reverse(all(a[i]));
    }
    for(ll i=0;i<n;i++)
    {
        unordered_map<ll,ll>t;
        for(auto it=a[i].begin();it!=a[i].end();)
        {
            if(t[*it])a[i].erase(it);
            else
            {
                t[*it]=1;
                it++;
            }
        }
    }
    auto cmp=[&](vector<ll>&x,vector<ll>&y)->bool
    {
        for(ll i=0;i<min(x.size(),y.size());i++)
        {
            if(x[i]!=y[i])
            {
                return x[i]<y[i];
            }
        }
        return x.size()<y.size();
    };
    auto get=[&]()->ll
    {
        ll pr=0;
        for(ll i=0;i<a.size();i++)
        {
            if(cmp(a[i],a[pr]))pr=i;
        }
        return pr;
    };
    auto out=[&](vector<ll>x)->void
    {
        for(auto &it:x){cout<<it<<" ";mp[it]=1;}
    };
    ll pr=get();
    while(!a.empty())
    {
        out(a[pr]);
        a.erase(a.begin()+pr);
        for(auto &q:a)
        {
            for(auto it=q.begin();it!=q.end();)
            {
                if(mp[*it])
                {
                    q.erase(it);
                }
                else it++;
            }
        }
        pr=get();
    }
    cout<<"\n";
}

signed main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    ll t;cin >> t;while (t--)
    solve();
}