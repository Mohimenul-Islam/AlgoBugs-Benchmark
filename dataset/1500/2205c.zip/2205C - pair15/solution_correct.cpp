#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

#define vi vector<ll>
#define vvi vector<vi>
#define endl '\n'

void solve()
{
   int n;
   cin >> n;

   priority_queue<vector<ll>, vector<vi>, greater<vi>> pq;

   for(int i = 0; i < n; i++)
   {
        set<int> s;
        vi t;
        int l;cin>>l;
        for(int j = 0; j <l; j++)
        {
            int x;
            cin >> x;

            // if(s.find(x) == s.end())
                t.push_back(x);

            // s.insert(x);
        }

        reverse(t.begin(), t.end());
        vi t2;
        for(auto x:t)
        {
        	if(s.find(x)==s.end())t2.push_back(x);
        	s.insert(x);
        }
        pq.push(t2);
   }

   vi res;
   set<int> s1;

   while(pq.size())
   {
   	// cout<<"-------------------------"<<endl;
        vi t = pq.top();
        vi t2;
        // for(auto x:t)cout<<x<<" ";
        // reverse(t.begin(), t.end());
        for(auto x:t)
        {
        	res.push_back(x);
		s1.insert(x);
	    }
        	

        pq.pop();
   		priority_queue<vector<ll>, vector<vi>, greater<vi>> pq1;

     	while(pq.size()>0)
     	{
     		vi t3 = pq.top();
     		pq.pop();
     		vi t4;
     		for(auto x:t3)
     		{
     			if(s1.find(x)==s1.end())t4.push_back(x);
     		}
     		if(t4.size()>0)
     		 pq1.push(t4);
     	}	
    	while(pq1.size()>0)
     	{
     		vi t3 = pq1.top();
     		pq1.pop();
     	
     		 pq.push(t3);
     	}
        
   }

   set<int> s2;

   for(auto x : res)
   {
        if(s2.find(x) == s2.end())
            cout << x << " ";

        s2.insert(x);
   }

   cout << endl;
}

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int t;
    cin >> t;

    while(t--)
        solve();

    return 0;
}