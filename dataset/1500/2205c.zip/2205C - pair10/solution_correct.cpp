#include <bits/stdc++.h>
#define ll long long
#define ld long double
using namespace std;

struct custom_hash {
    static uint64_t splitmix64(uint64_t x) {
        // http://xorshift.di.unimi.it/splitmix64.c
        x += 0x9e3779b97f4a7c15;
        x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;
        x = (x ^ (x >> 27)) * 0x94d049bb133111eb;
        return x ^ (x >> 31);
    }

    size_t operator()(uint64_t x) const {
        static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();
        return splitmix64(x + FIXED_RANDOM);
    }
};

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    ll t;
    cin >> t;

    while(t--) {
        ll n;
        cin >> n;

        vector <vector <ll>> a(n);
        for(auto &vec : a) {
            ll l;
            cin >> l;
            vec.resize(l);
            
            for(auto &val : vec) {
                cin >> val;
            }
        }

        for(auto &vec : a) {
            reverse(vec.begin(), vec.end());

            unordered_set <ll, custom_hash> st;
            vector <ll> v;
            for(auto &val : vec) {
                if(st.find(val) == st.end()) {
                    v.push_back(val);
                }

                st.insert(val);
            }

            vec = v;
        }

        vector <ll> ans;
        unordered_set <ll, custom_hash> st;
        while(!a.empty()) {
            ll sz = a.size();
            vector <vector <ll>> ansTemp(sz);
            for(ll i = 0; i < sz; ++i) {
                for(auto &val : a[i]) {
                    if(st.find(val) == st.end()) {
                        ansTemp[i].push_back(val);
                    }
                }
            }

            auto it = min_element(ansTemp.begin(), ansTemp.end());
            a.erase(a.begin() + distance(ansTemp.begin(), it));
            
            for(auto &val : *it) {
                ans.push_back(val);
                st.insert(val);
            }
        }

        for(auto &val : ans) {
            cout << val << ' ';
        }

        cout << '\n';
    }
}