/* ❀ Apeiron Coding ❀ */
#include<bits/stdc++.h>
using namespace std;
#define Apeiron main
#define endl '\n'
#define ll long long

void solve(){
    int n; cin>>n;
    vector<vector<int>> v(n, vector<int>());
    for(int i=0;i<n;i++){
        int t; cin>>t;
        while(t--){
            int tmp; cin>>tmp;
            v[i].push_back(tmp);
        }
    }
    for(int i=0;i<n;i++) reverse(v[i].begin(), v[i].end());
    
    auto cmp = [](vector<int> v1, vector<int> v2) -> bool{
        for(int i=0;i<min(v1.size(),v2.size());i++){
            if(v1[i]!=v2[i]) return v1[i]>v2[i];
        }
        return v1.size()>v2.size();
    };

    set<int> st;
    vector<int> ans;
    for(int i=0;i<n;i++){
        for(vector<int> &vt:v){
            set<int> stt;
            vector<int> tmp;
            for(int i=0;i<vt.size();i++){
                if(st.count(vt[i]) || stt.count(vt[i])) continue;
                else stt.insert(vt[i]);
                tmp.push_back(vt[i]);
            }
            vt = tmp;
        }

        sort(v.begin(), v.end(), cmp);

        for(int it:v.back()){
            ans.push_back(it); st.insert(it);
        }
        v.pop_back();
    }

    for(int it:ans) cout<<it<<' ';
    cout<<endl;
}

signed Apeiron(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int A=1;
    cin>>A;
    while(A--){
        solve();
    }
    cout.flush();
    return 0;
}