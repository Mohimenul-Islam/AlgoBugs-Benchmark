#include<bits/stdc++.h>
using namespace std;
const int INF=0x3f3f3f3f;
typedef long long ll;
typedef unsigned long long ull;
const ll LINF=9223372036854775807;

inline int read()
{
    int x=0,f=1;char ch=getchar();
    while (ch<'0'||ch>'9'){if (ch=='-') f=-1;ch=getchar();}
    while (ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
    return x*f;
}


void solve(){
    int n,m=0;
    cin>>n;
    vector<vector<int>>a(n+1);
    map<int,int>mp,vis;
    for(int i=1;i<=n;i++){
        int x;
        cin>>x;
        a[i].resize(x);
        for(int j=0;j<x;j++){
            cin>>a[i][j];
            if(!mp[a[i][j]]) mp[a[i][j]]++,m++;
        }
        reverse(a[i].begin(),a[i].end());
    }
    // sort(a.begin()+1,a.end());
    vector<int>res;
    vector<bool>b(n+1);
    while(res.size()<m){
        vector<int>tmp; 
        int pos=0;
        for(int i=1;i<=n;i++){
            if(b[i]) continue;
            vector<int>now;
            map<int,int>vised;
            for(int j=0;j<a[i].size();j++){
                if(!vis[a[i][j]]&&!vised[a[i][j]]){
                    vised[a[i][j]]++;
                    now.push_back(a[i][j]);
                }
            }
            // for(int j=0;j<a[i].size();j++) vised[a[i][j]]=0;
            if(!tmp.size()) tmp=now,pos=i;
            if(tmp>now) tmp=now,pos=i;
        }
        b[pos]=1;
        // cerr<<pos<<"\n";
        for(auto i:tmp) {
            // cerr<<i<<' ';
            if(!vis[i]) res.push_back(i),vis[i]++;
        }
        // cerr<<"\n";
    }
    for(auto i:res) cout<<i<<" ";
    cout<<'\n';
    // cerr<<'\n';
}

signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int t=1;
    cin>>t;
    while(t--){
        solve();
    }
}
//Can you hear me?