#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <map>
#include <stack>
#include <set>
#include <queue>
#include <utility>
#include <numeric>
#include <map>

using namespace std;
typedef long long ll;

void solve() {
    int n; cin >>n;
    vector<string> list;
    for (int i =0; i < n; ++i) {
        string s;
        int m; cin >> m;
        vector<int> v(m);
        for (int j = 0; j < m; ++j) {
            cin >> v[j];
        }
        set<int> se;
        for (int j =  m -1; j >= 0; --j) {
            if (!se.count(v[j])) {
                s = s + to_string(v[j]);
                se.insert(v[j]);
            }
        }
        list.push_back(s);
    }
    string answer = "";
    set<char> used = set<char>();
    int i =0;
    while (i < list.size()) {
        sort(list.begin() + i, list.end());
        for (int j = 0; j < list[i].size(); ++j) {
            if (!used.count(list[i][j])) {
                answer = answer + list[i][j] + " ";
                used.insert(list[i][j]);
            }
        }
        for (int j = i + 1; j < n; ++j){
            int flag = -1;
            string ns = "";
            for (int k = 0; k < list[j].size(); ++k) {
                if (flag != -1) {
                    if (!used.count(list[j][k])) {
                        ns = ns + list[j][k];
                    }
                } else {
                if (!used.count(list[j][k])) {
                    flag = k;
                    ns = list[j][k];
                }
                }
            }
            if (flag == -1) {
                list[j] = "";
            } else {
                list[j] = ns;
            }
        }
        ++i;
    }
    cout << answer << "\n";
}

int main() {
    int t; cin >> t;
    while (t--) {
        solve();
    }
}
