#include <iostream>
#include <vector>
#include <algorithm>
#include <set>

using namespace std;

void solve() {
    int n; cin >> n;
    vector<vector<int> > list;
    for (int i = 0; i < n; ++i) {
        int m; cin >> m;
        vector<int> v(m);
        for (int j = 0; j < m; ++j) cin >> v[j];
        set<int> se;
        vector<int> cur;
        for (int j = m - 1; j >= 0; --j) {
            if (!se.count(v[j])) {
                cur.push_back(v[j]);
                se.insert(v[j]);
            }
        }
        list.push_back(cur);
    }
    vector<int> answer;
    set<int> used;
    int i = 0;
    while (i < list.size()) {
        sort(list.begin() + i, list.end());
        for (int x : list[i]) {
            if (!used.count(x)) {
                answer.push_back(x);
                used.insert(x);
            }
        }
        for (int j = i + 1; j < n; ++j) {
            vector<int> ns;
            for (int x : list[j]) {
                if (!used.count(x)) ns.push_back(x);
            }
            list[j] = ns;
        }
        ++i;
    }
    for (int x : answer) cout << x << ' ';
    cout << '\n';
}

int main() {
    int t; cin >> t;
    while (t--) solve();
    return 0;
}