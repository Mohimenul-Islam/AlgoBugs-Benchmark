#include <bits/stdc++.h>

using namespace std;

int n;

bool isSmaller(vector<int> a, vector<int> b, set<int> cache) {
    int i = a.size()-1;
    int j = b.size()-1;
    int trueSizeA = a.size();
    int trueSizeB = b.size();
    while (i >= 0 && j >= 0) {
        while (i >= 0 && cache.count(a[i])) {
            --i;
            --trueSizeA;
        };
        while (j >= 0 && cache.count(b[j])) {
            --j;
            --trueSizeB;
        };

        if (i < 0 || j < 0) break;

        if (a[i] == b[j]) {
            --i;
            --j;
        } else {
            return a[i] < b[j];
        }
    }

    return trueSizeA < trueSizeB;
}

void solve() {
    cin >> n;
    vector<vector<int>> arr(n);
    for (int i = 0; i < n; ++i) {
        int length; cin >> length;
        vector<int> temp(length);
        map<int, int> lastOccurrences;
        for (int j = 0; j < length; ++j) {
            int x; cin >> x;
            lastOccurrences[x] = j;
            temp[j] = x;
        }
        for (int j = 0; j < length; ++j) {
            if (lastOccurrences[temp[j]] == j) {
                arr[i].push_back(temp[j]);
            }
        }
    }

    set<int> cache;
    vector<int> result;
    while (arr.size() > 0) {
        int chosenIndex = 0;
        for (int i = 1; i < arr.size(); ++i) {
             if (isSmaller(arr[i], arr[chosenIndex], cache)) {
                chosenIndex = i;
             }
        };

        for (int i = arr[chosenIndex].size()-1; i >= 0; --i) {
            if (!cache.count(arr[chosenIndex][i])) {
                result.push_back(arr[chosenIndex][i]);
                cache.insert(arr[chosenIndex][i]);
            }
        }
        swap(arr[chosenIndex], arr.back());
        arr.pop_back();
    }
    for (int i = 0; i < result.size(); ++i) {
        cout << result[i] << ' ';
    }
    cout << endl;
}

int main() {
    int t; cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
