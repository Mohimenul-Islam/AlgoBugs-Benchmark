#include <bits/stdc++.h>

using namespace std;

int n;

void solve() {
    cin >> n;

    vector<vector<int>> arr(n);

    bool marker[(int)1e6];
    memset(marker, false, sizeof(marker));

    for (int i = 0; i < n; ++i) {
        int length; cin >> length;
        vector<int> temp(length);
        map<int, int> lastOccurrences;
        for (int j = 0; j < length; ++j) {
            int x; cin >> x;
            lastOccurrences[x] = j;
            temp[j] = x;
        }
        for (int j = length-1; j >= 0; --j) {
            if (lastOccurrences[temp[j]] == j) {
                arr[i].push_back(temp[j]);
            }
        }
    }

    while (arr.size() > 0) {
        int chosenIndex = 0;
        for (int i = 1; i < arr.size(); ++i) {
             if (arr[i] < arr[chosenIndex]) {
                chosenIndex = i;
             }
        };

        for (int val : arr[chosenIndex]) {
            cout << val << ' ';
            marker[val-1] = true;
        }

        swap(arr[chosenIndex], arr.back());
        arr.pop_back();

        for (int i = 0; i < arr.size(); ++ i) {
            vector<int> newBlog;
            for (int val : arr[i]) {
                if (!marker[val-1]) {
                    newBlog.push_back(val);
                };
            }
            arr[i] = newBlog;
        }
    }
    cout << endl;
}

int main() {
    int t; cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
