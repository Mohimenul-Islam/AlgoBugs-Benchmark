#include <bits/stdc++.h>
#define all(x) (x).begin(), (x).end()
#define pb push_back
#define pf push_front
using namespace std;
using ll = long long;
using ull = unsigned long long;
typedef pair<int, int> P;
const int mod = 998244353;
const int MOD = 1e9 + 7;

void solve()
{
    int n;
    cin >> n;
    vector<vector<int>> nums;
    for (int i = 0; i < n; i++)
    {
        int l;
        cin >> l;
        vector<int> a(l);
        for (int j = 0; j < l; j++)
        {
            cin >> a[j];
        }
        map<int, bool> vis;
        vector<int> add;
        for (int j = l - 1; j >= 0; j--)
        {
            if (!vis.count(a[j]))
            {
                add.pb(a[j]);
                vis[a[j]] = true;
            }
        }
        nums.pb(add);
    }
    map<int, bool> vis;
    for (int i = 0; i < n; i++)
    {
        vector<vector<int>> temp = nums, chg;
        if (temp.empty())
            break;
        sort(all(temp));
        for (int j = 0; j < temp[0].size(); j++)
        {
            cout << temp[0][j] << ' ';
            vis[temp[0][j]] = true;
        }
        for (int j = 1; j < temp.size(); j++)
        {
            vector<int> add;
            for (int k = 0; k < temp[j].size(); k++)
            {
                if (!vis.count(temp[j][k]))
                    add.pb(temp[j][k]);
            }
            if (!add.empty())
                chg.pb(add);
        }
        nums = chg;
    }
    cout << endl;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}