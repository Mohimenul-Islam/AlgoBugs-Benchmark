#include <bits/stdc++.h>
#define all(x) x.begin(), x.end()
#define pb push_back
#define pf push_front
using namespace std;
using ull = unsigned long long;
using ll = long long;
const int mod = 1e9 + 7;
const int MOD = 998244353;
const int INF = 0x3f3f3f3f;

void solve()
{
    int n;
    cin >> n;
    vector<vector<string>> box(n);
    for (int i = 0; i < n; ++i)
    {
        int li;
        cin >> li;
        vector<string> pos(li);
        for (int j = 0; j < li; ++j)
            cin >> pos[j];
        reverse(all(pos));
        map<string, bool> seen;
        vector<string> tmp;
        for (auto s : pos)
        {
            if (!seen[s])
            {
                seen[s] = true;
                tmp.push_back(s);
            }
        }
        box[i] = tmp;
    }
    map<string, bool> vis;
    vector<bool> done(n);
    for (int r = 1; r <= n; r++)
    {
        int best = -1;
        for (int i = 0; i < n; i++)
        {
            if (!done[i])
            {
                if (best == -1 || box[i] < box[best])
                {
                    best = i;
                }
            }
        }
        for (auto x : box[best])
        {
            cout << x << ' ';
            vis[x] = true;
        }
        done[best] = true;
        for (int i = 0; i < n; i++)
        {
            if (!done[i])
            {
                vector<string> temp;
                for (auto x : box[i])
                {
                    if (!vis.count(x))
                        temp.pb(x);
                }
                box[i] = temp;
            }
        }
    }
    cout << endl;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}