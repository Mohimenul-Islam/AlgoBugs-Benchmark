#include<bits/stdc++.h>
#define int long long
using namespace std;
const int t = 1e6 + 6;
const int MAX = 1e18;
struct node {
	int l;
	vector<int>v;
}a[t],b[t];
int c[t];
bool cmp(node a, node b) {
	int n1 = a.v.size();
	int n2 = b.v.size();
	if (n1 < 1 || n2 < 1)return n1 < n2;
	while (n1 >= 1 && n2 >= 1) {
		if (n1 < 1 || n2 < 1)return n1 < n2;
		if (a.v[n1 - 1] == b.v[n2 - 1]) {
			n1--;
			n2--;
		}
		else return a.v[n1 - 1] < b.v[n2 - 1];
	}
	return n1 < n2;
}
void solve() {
	int n;
	cin >> n;
	for (int i = 0; i <= n + 2; i++) {
		a[i].v.clear();
	}
	for (int i = 1; i <= n; i++) {
		cin >> a[i].l;
		map<int, int>mp;
		for (int j = 1; j <= a[i].l; j++) {
			cin >> c[j];
		}
		for (int j = a[i].l; j >= 1; j--) {
			if (mp[c[j]]==0) {
				a[i].v.push_back(c[j]);
				mp[c[j]]++;
			}
		}
		reverse(a[i].v.begin(), a[i].v.end());
	}
	sort(a + 1, a + 1 + n, cmp);
	//for (int i = 1; i <= n; i++) {
	//	for (auto j : a[i].v)cout << j << " ";
	//	cout << endl;
	//}
	set<int>s;
	for (int i = 1; i <= n; i++) {
		int m = a[i].v.size();
		for (int j = m - 1; j >= 0; j--) {
			if (s.find(a[i].v[j]) == s.end()) {
				s.insert(a[i].v[j]);
				cout << a[i].v[j] << " ";
			}
		}
		for (int k = i + 1; k <= n; k++) {
			vector<int>ex;
			for (int j = 0; j <=a[k].v.size() - 1 ; j++) {
				if (a[k].v.size() == 0)break;
				if (s.find(a[k].v[j]) == s.end()) {
					ex.push_back(a[k].v[j]);
				}
			}
			a[k].v = ex;
			//cout << "k "<<k << endl;
			//for (auto j : ex)cout << j << " "; cout << endl;
		}
		sort(a + 1 + i, a + 1 + n, cmp);
		/*cout << "i " << i << endl;
		for (int k = i + 1; k <= n; k++) {
			cout << "k " << k << endl;
			for (auto j : a[k].v)cout << j << " ";
			cout << endl;
		}*/
	}
	cout << endl;
}
signed main() {
	
	int _;
	_ = 1;
	cin >> _;
	while (_--) {
		solve();
	}
	return 0;
}