#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>
using namespace std;
const int N = 1e6 + 10;
bool vis[N];

void solve() {
    int n;
    cin >> n;
    vector<vector<int>> nums(n);

    // 1. 预处理：对每个博客逆序去重
    for (int i = 0; i < n; ++i) {
        int c;
        cin >> c;
        vector<int> a(c);
        for (int j = 0; j < c; ++j) {
            cin >> a[j];
        }

        vector<int> add;
        memset(vis, 0, sizeof vis); // 每个博客单独去重
        // 逆序遍历：保留该元素最后一次出现的位置
        for (int j = c - 1; j >= 0; --j) {
            if (!vis[a[j]]) {
                add.push_back(a[j]);
                vis[a[j]] = true;
            }
        }
        nums[i] = add;
    }

    memset(vis, 0, sizeof vis); // 全局去重用的标记
    while (!nums.empty()) {
        vector<vector<int>> tmp = nums;
        nums.clear();

        // 使用默认的字典序排序 (vector 自带的 < 运算符)
        sort(tmp.begin(), tmp.end());

        // 输出当前最优的第一个序列
        for (int x : tmp[0]) {
            cout << x << " ";
            vis[x] = true; // 标记为已输出
        }

        // 3. 生成下一轮的序列：剔除已输出的元素
        for (int j = 1; j < tmp.size(); ++j) {
            vector<int> a;
            for (int x : tmp[j]) {
                if (!vis[x]) {
                    a.push_back(x);
                }
            }
            if (!a.empty()) {
                nums.push_back(a);
            }
        }
    }
    cout << endl;
}

int main() {

    ios::sync_with_stdio(false);
    cin.tie(0);

    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}