#include <bits/stdc++.h>
using namespace std;

int main() {
    int t;
    cin >> t;
    while(t--) {
        int n;cin>>n;

        vector<vector<int>> all(n);
        for(int i=0;i<n;i++) {
            int l; cin >> l;
            vector<int> a(l);
            for(int j=l-1;j>=0;j--) {
                cin >> a[j];
            }
            unordered_set<int> used;
            vector<int> b;
            for(int j=0;j<l;j++) {
                if(!used.count(a[j])) {
                    used.insert(a[j]);
                    b.push_back(a[j]);
                }
            }
            all[i] = b;
        }
        vector<int> q;
        unordered_set<int> contain;
        // run n times
        less<vector<int>> cmp;
        vector<bool> used(n, false);
        for(int i=0;i<n;i++) {
            int s=-1;
            for(int j=0;j<n;j++) {
                if(!used[j] && all[j].size() && (s == -1 || cmp(all[j], all[s]))) {
                    s = j;
                }
            }
            if(s == -1) break;

            used[s] = true;
            for(int j=0;j<all[s].size();j++) {
                contain.insert(all[s][j]);
                q.push_back(all[s][j]);
            }
            // clear other elements of this
            for(int j=0;j<n;j++) {
                vector<int> b;
                for(int& z : all[j]) {
                    if(!contain.count(z)) {
                        b.push_back(z);
                    }
                }
                all[j] = b;
            }
        }
        
        for(int i=0;i<q.size();i++) {
            cout << q[i] << " ";
        }
        cout << "\n";
        
    }
    return 0;
}