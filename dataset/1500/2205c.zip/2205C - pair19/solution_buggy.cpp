#include<bits/stdc++.h>
#define ll long long
#define lc id<<1
#define rc id<<1|1
#define lowbit(x) x&-x
#define pii pair<int, int>
#define aii array<int,3>
using namespace std;
const int N=2e5+100;
vector<ll>a[3010];
ll n;
bool cmp(ll x,ll y){
    ll len=min(a[x].size(),a[y].size());
    for(int i=0;i<len;i++){
        if(a[x][i]<a[y][i]){
            return 1;
        }
        else if(a[y][i]<a[x][i]){
            return 0;
        }
    }
    return a[x].size()<a[y].size();
}
void solve(){
    cin>>n;
    for(int i=1;i<=n;i++){
        a[i].clear();
        ll l;
        cin>>l;
        stack<ll>s;
        map<ll,bool>mp;
        for(int j=1;j<=l;j++){
            ll x;
            cin>>x;
            if(mp[x])continue;
            mp[x]=1;
            s.push(x);
        }
        while(s.size()){
            a[i].push_back(s.top());
            s.pop();
        }
    }
    vector<ll>id(n+1);
    for(int i=1;i<=n;i++){
        id[i]=i;
    }
    ll p=1;
    while(p<n){
      sort(id.begin()+p,id.end(),cmp);
      map<ll,bool>vis;
      for(auto x:a[id[p]]){
        vis[x]=1;
      }
      for(int i=p+1;i<=n;i++){
          vector<ll>b;
          for(auto x:a[id[i]]){
            if(vis[x])continue;
            b.push_back(x);
          }
          a[id[i]]=b;
       }
        p++;
    }
    for(int i=1;i<=n;i++){
        for(auto x:a[id[i]]){
            cout<<x<<" ";
        }
    }
    cout<<endl;
}
int main(){
    ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
    int T=1;
    cin>>T;
    while(T--){
        solve();
    }
}