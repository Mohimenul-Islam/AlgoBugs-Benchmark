#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
typedef vector<int> vint;
typedef pair<int,int> pint;
typedef vector<ll> vll;
typedef pair<ll,ll> pll;

#include <ext/pb_ds/assoc_container.hpp>
using namespace __gnu_pbds;

template <typename T>
using indexed_set =
    tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

struct custom_hash {
    static uint64_t splitmix64(uint64_t x) {
        // http://xorshift.di.unimi.it/splitmix64.c
        x += 0x9e3779b97f4a7c15;
        x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;
        x = (x ^ (x >> 27)) * 0x94d049bb133111eb;
        return x ^ (x >> 31);
    }

    size_t operator()(uint64_t x) const {
        static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();
        return splitmix64(x + FIXED_RANDOM);
    }
};

int main() {
    cin.tie(nullptr) -> sync_with_stdio(false);
    
    int t;
    cin >> t;
    for (int testnum {0}; testnum < t; testnum++) {
        int n;
        cin >> n;

        vector<vint> a(n,vint{});
        for (int i {0}; i < n; i++) {
            int l;
            cin >> l;
            while (l--) {
                int ai;
                cin >> ai;
                if (count(a[i].begin(),a[i].end(),ai) == 0) {
                    erase(a[i],ai);
                    a[i].push_back(ai);
                }
            }
            reverse(a[i].begin(),a[i].end());
        }
        
        vint q {};
        for (int i {0}; i < n; i++) {
            int best {-1};
            for (int j {0}; j < n; j++) {
                if (!a[j].empty() && (best == -1 || a[j] < a[best])) best = j;
            }
            if (best == -1) break;
            for (int x : a[best]) q.push_back(x);
            for (int j {0}; j < n; j++) {
                if (j != best) {
                    for (int x : a[best]) {
                        erase(a[j],x);
                    }
                }
            }
            a[best].clear();
        }
        for (int x : q) cout << x << " ";
        cout << "\n";
    }
}
