#include <algorithm>
#include <bits/stdc++.h>
#define fastio() ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
#define all(v) v.begin(),v.end()
#define pb push_back
#define F first
#define S second
typedef long long ll;
typedef long double ld;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
const int MOD = 1e9+7;

void solve() {
    int n;
    cin >> n;
    
    vector<vi> vs(n);
    vector<bool> ex(1000001);
    
    for(int i = 0; i < n; i++) {
        int l; cin >> l;
        
        vi v(l);
        for(int j = l-1; j >= 0; j--) {
            cin >> v[j];
            ex[v[j]] = true;
        }
        
        set<int> s;
        vi u;
        
        for(int i = 0; i < l; i++) {
            if(!s.count(v[i])) {
                s.insert(v[i]);
                u.pb(v[i]);
            }
        }
        
        vs[i] = u;
    }
    
    sort(all(vs));
    
    vi ans;
    vector<bool> b(1000001);
    
    for(int i = 0; i < n; i++) {
        if(b[vs[i][0]]) continue;
        for(int j = 0; j < vs[i].size(); j++) {
            if(!b[vs[i][j]]) {
                b[vs[i][j]] = true;
                ans.pb(vs[i][j]);
            }
        }
    }
    
    for(int i = 1; i < ex.size(); i++) {
        if(ex[i] && !b[i]) ans.pb(i);
    }
    
    for(auto x: ans) cout << x << " ";
    cout << endl;
}

int main() {
    fastio();
    int t = 1;
    cin >> t;
    while(t--) solve();
}
