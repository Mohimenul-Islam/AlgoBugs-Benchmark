#include <bits/stdc++.h>
#define fastio() ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
#define all(v) v.begin(),v.end()
#define pb push_back
#define F first
#define S second
typedef long long ll;
typedef long double ld;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
const int MOD = 1e9+7;

void solve() {
    int n;
    cin >> n;
    
    vector<vi> vs(n);
    
    for(int i = 0; i < n; i++) {
        int l; cin >> l;
        
        vi v(l);
        for(int j = l-1; j >= 0; j--) {
            cin >> v[j];
        }
        
        vi u;
        set<int> s;
        
        for(int i = 0; i < l; i++) {
            if(!s.count(v[i])) {
                s.insert(v[i]);
                u.pb(v[i]);
            }
        }
        
        vs[i] = u;
    }
    
    vi ans;
    vector<bool> b(1000001);
    vector<bool> used(n+1);
    
    for(int i = 0; i < n; i++) {
        
        int curr = -1;
        
        for(int j = 0; j < n; j++) {
            if(used[j]) continue;
            vi nw;
            for(auto x: vs[j]) {
                if(!b[x]) {
                    nw.pb(x);
                }
            }
            swap(vs[j], nw);
            
            if(curr == -1 || vs[j] < vs[curr]) curr = j;
        }
        
        for(auto x: vs[curr]) {
            if(!b[x]) {
                ans.pb(x);
                b[x] = true;
            }
        }
        
        used[curr] = true;
    }
    
    for(auto x: ans) cout << x << " ";
    cout << endl;
}

int main() {
    fastio();
    int t = 1;
    cin >> t;
    while(t--) solve();
}
