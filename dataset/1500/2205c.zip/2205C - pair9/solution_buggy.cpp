/* Author :- 
             Nikhil Joshi 
             बलिदान परम धर्म                   
                                */
#include<bits/stdc++.h>
using namespace std; 
using i64 = long long;
using ld = long double;
#define all(v) v.begin(),v.end()
#define F first
#define S second
#define state pair<i64, i64>
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);

const i64 N = 1e6 + 25, inf = 1e18, mod = 1e9 + 7;

i64 gcd(i64 a, i64 b) {
    return b == 0 ? a : gcd(b, a % b);
}
 
i64 lcm(i64 A, i64 B) {
    return A * (B / gcd(A, B));
}
 
i64 modexp(i64 a, i64 b) {               
    i64 res = 1;
    while(b) {
        if(b & 1) res = (res * a) % mod;
        a = (a * a) % mod;
        b >>= 1;
    }
    return res;
}
 
i64 nCr(i64 n, i64 r) {
    if(r > n)
        return 0;
    if(r > n - r)
        r = n - r;
    i64 res = 1;
    for(i64 i = 1; i <= r; i++) {
        res = (res * (n - i + 1)) % mod;              
        res = (res * modexp(i, mod - 2)) % mod;       
    }
    return res;
}

void solve() {
    i64 n;     cin >> n;
    deque<deque<i64>> v;
    for(i64 i = 0; i < n; i++) {
        deque<i64> dq;   i64 l;   cin >> l;
        for(i64 j = 0; j < l; j++) {
            i64 x;   cin >> x;   dq.push_front(x);
        }
        v.push_back(dq);
    }
    sort(all(v));   deque<i64> dq;   set<i64> st;
    while(v.size()) {
        for(i64 i = 0; i < v[0].size(); i++) {
            if(st.find(v[0][i]) != st.end()) continue;
            dq.push_back(v[0][i]);   st.insert(v[0][i]);
        }
        v.pop_front();
        for(i64 i = 0; i < v.size(); i++) {
            while(v[i].size() > 0) {
                if(st.find(v[i].front()) != st.end()) {
                    v[i].pop_front();
                } else {
                    break;
                }
            }
        }
        sort(all(v));
    }
    for(auto i : dq) cout << i << " ";  cout << '\n';
}

int32_t main() {
    IOS 
    i64 tc = 1;
    cin >> tc;
    while(tc--) {
        solve();
    }
}