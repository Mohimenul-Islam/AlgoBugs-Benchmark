/* Author :- 
             Nikhil Joshi 
             बलिदान परम धर्म                   
                                */
#include<bits/stdc++.h>
using namespace std; 
using i64 = long long;
using ld = long double;
#define all(v) v.begin(),v.end()
#define F first
#define S second
#define state pair<i64, i64>
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);

const i64 N = 1e6 + 25, inf = 1e18, mod = 998244353;

i64 gcd(i64 a, i64 b) {
    return b == 0 ? a : gcd(b, a % b);
}
 
i64 lcm(i64 A, i64 B) {
    return A * (B / gcd(A, B));
}
 
i64 modexp(i64 a, i64 b) {               
    i64 res = 1;
    while(b) {
        if(b & 1) res = (res * a) % mod;
        a = (a * a) % mod;
        b >>= 1;
    }
    return res;
}
 
i64 nCr(i64 n, i64 r) {
    if(r > n)
        return 0;
    if(r > n - r)
        r = n - r;
    i64 res = 1;
    for(i64 i = 1; i <= r; i++) {
        res = (res * (n - i + 1)) % mod;              
        res = (res * modexp(i, mod - 2)) % mod;       
    }
    return res;
}
vector<i64> trans(vector<i64> &v, set<i64> &st) {
    vector<i64> ans;     set<i64> s;
    for(i64 i = 0; i < v.size(); i++) {
        if(s.count(v[i]) || st.count(v[i])) continue;
        ans.push_back(v[i]);
        s.insert(v[i]);
    }
    return ans;
}
void solve() {
    i64 n;     cin >> n;
    vector<vector<i64>> v;
    for (i64 i = 0; i < n; i++) {
        i64 m;  cin >> m;  vector<i64> temp(m);
        for(auto &x : temp) cin >> x;   reverse(all(temp));
        v.push_back(temp);
    }
    vector<i64> ans;   set<i64> st;
    for (i64 i = 0; i < n; i++) {
        for(i64 j = i; j < n; j++) v[j] = trans(v[j], st);
        for(i64 j = i + 1; j < n; j++) {
            if(v[i] > v[j]) swap(v[i], v[j]);
        }
        for(auto x : v[i]) {
            ans.push_back(x);   st.insert(x);
        }
    }
    for(auto i : ans) cout << i << " ";  cout << '\n';
}

int32_t main() {
    IOS 
    i64 tc = 1;
    cin >> tc;
    while(tc--) {
        solve();
    }
}