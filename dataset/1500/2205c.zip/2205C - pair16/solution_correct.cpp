#include <bits/stdc++.h>

using namespace std;

using ll = long long;

bool compare(const unordered_set<ll> &used, const vector<ll> &a, const vector<ll> &b) {
    ll a_p = a.size() - 1;
    ll b_p = b.size() - 1;
    unordered_set<ll> local_used;

    while (true) {
        while (a_p >= 0 && (used.contains(a[a_p]) || local_used.contains(a[a_p]))) {
            a_p--;
        }

        while (b_p >= 0 && (used.contains(b[b_p]) || local_used.contains(b[b_p]))) {
            b_p--;
        }

        if (a_p == -1 || b_p == -1) break;

        if (a[a_p] < b[b_p]) {
            return true;
        }
        if (a[a_p] > b[b_p]) {
            return false;
        }
        local_used.insert(a[a_p]);
        a_p--;
        b_p--;
    }

    if (a_p == -1) {
        return true;
    }
    return false;
}

vector<ll> solve(vector<vector<ll>> &a) {
    unordered_set<ll> used;
    vector<ll> result;
    for (ll i = 0; i < a.size(); ++i) {
        auto it = max_element(a.begin() + i, a.end(), [&used](const vector<ll> &l, const vector<ll> &r) {
            return !compare(used, l, r);
        });
        swap(*it, a[i]);
        for (ll j = a[i].size() - 1; j >= 0 ; --j) {
            if (!used.contains(a[i][j])) {
                result.push_back(a[i][j]);
            }
            used.insert(a[i][j]);
        }
    }
    return result;
}

int main() {
    int t;
    cin >> t;
    while (t--) {
        ll n;
        cin >> n;
        vector<vector<ll>> a(n);
        for (ll i = 0; i < n; ++i) {
            ll l;
            cin >> l;
            a[i].resize(l);
            for (ll j = 0; j < l; ++j) {
                cin >> a[i][j];
            }
        }

        auto result = solve(a);

        for (ll i = 0; i < result.size(); ++i) {
            cout << result[i] << ' ';
        }
        cout << endl;
    }
}
