#include <bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'
const int N = 1e6 + 10;
const int MAXN = 1e17 + 100;
vector<int> v[3010];
vector<int> a[3010];
void solve()
{
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        int l;
        cin >> l;
        vector<int> v1;
        map<int, int> mp;
        for (int j = 1; j <= l; j++)
        {
            int x;
            cin >> x;

            a[i].push_back(x);
            // v[i].push_back(x);
        }
        for (int j = a[i].size() - 1; j >= 0; j--)
        {
            if (!mp[a[i][j]])
            {
                mp[a[i][j]] = 1;
                v[i].push_back(a[i][j]);
            }
        }
        // for(auto it:v[i])
        // {
        //     cout<<it<<" ";
        // }
        // cout<<endl;
    }
    sort(v + 1, v + 1 + n);
    vector<int> ans;
    map<int, int> vis;
    for (int i = 1; i <= n; i++)
    {
        for (int j = 0; j < v[i].size(); j++)
        {
            if (!vis[v[i][j]])
            {
                vis[v[i][j]] = 1;
                ans.push_back(v[i][j]);
                // cout<<v[i][j]<<" ";
            }
        }
        for (int j = 1; j <= n; j++)
        {
            v[j].clear();
        }
        
        for (int j = 1; j <= n; j++)
        {
            map<int, int> mp;
            for (int k = a[j].size() - 1; k >= 0; k--)
            {
                if (!vis[a[j][k]]&&!mp[a[j][k]])
                {
                    mp[a[j][k]]=1;
                    // vis=1;
                    v[j].push_back(a[j][k]);
                }
            }
        }
        sort(v + 1, v + 1 + n);
    }
    for (auto it : ans)
    {
        cout << it << " ";
    }
    cout << endl;
    for (int i = 1; i <= n; i++)
    {
        v[i].clear();
        a[i].clear();
    }
}
signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}