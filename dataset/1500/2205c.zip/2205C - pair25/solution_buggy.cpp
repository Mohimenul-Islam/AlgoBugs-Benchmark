#include <iostream>
#include <vector>
#include <unordered_set>
#include <algorithm>

using namespace std;

void solve() {
    int n;
    if (!(cin >> n)) return;
    vector<vector<int>> blogs(n);
    for (int i = 0; i < n; ++i) {
        int l;
        cin >> l;
        vector<int> a(l);
        for (int j = 0; j < l; ++j) cin >> a[j];
        
        unordered_set<int> seen;
        vector<int> unique_elements;
        for (int j = l - 1; j >= 0; --j) {
            if (seen.find(a[j]) == seen.end()) {
                seen.insert(a[j]);
                unique_elements.push_back(a[j]);
            }
        }
        reverse(unique_elements.begin(), unique_elements.end());
        blogs[i] = unique_elements;
    }

    vector<int> q;
    unordered_set<int> global_seen;
    vector<bool> posted(n, false);

    for (int i = 0; i < n; ++i) {
        int best_idx = -1;
        for (int j = 0; j < n; ++j) {
            if (posted[j]) continue;
            
            vector<int> current_new;
            for (int val : blogs[j]) {
                if (global_seen.find(val) == global_seen.end()) {
                    current_new.push_back(val);
                }
            }
            
            if (current_new.empty()) {
                posted[j] = true;
                best_idx = -2;
                break;
            }

            if (best_idx < 0) {
                best_idx = j;
            } else {
                vector<int> best_new;
                for (int val : blogs[best_idx]) {
                    if (global_seen.find(val) == global_seen.end()) {
                        best_new.push_back(val);
                    }
                }
                if (!current_new.empty() && !best_new.empty() && current_new[0] < best_new[0]) {
                    best_idx = j;
                }
            }
        }

        if (best_idx == -2) { i--; continue; }
        if (best_idx == -1) break;

        posted[best_idx] = true;
        for (int val : blogs[best_idx]) {
            if (global_seen.find(val) == global_seen.end()) {
                global_seen.insert(val);
                q.push_back(val);
            }
        }
    }

    for (int i = 0; i < q.size(); ++i) {
        cout << q[i] << (i == q.size() - 1 ? "" : " ");
    }
    cout << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    if (!(cin >> t)) return 0;
    while (t--) {
        solve();
    }
    return 0;
}
