#include <bits/stdc++.h>
using namespace std;
#define int long long 
#define fio ios::sync_with_stdio(0),cin.tie(0),cout.tie(0)
const int N=5e6+10;
vector<int>ad[N];
int a[N];
int ans[N];
void solve()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		ad[i].clear();
	}
	for(int i=1;i<=n;i++){
		int x;
		cin>>x;
		int cnt=0;
		int la=-1;
		for(int j=1;j<=x;j++){
			int y;
			cin>>y;
			if(y!=la){
				la=y;
				cnt++;
				a[cnt]=y;
			}
		}
		for(int j=cnt;j>=1;j--){
			ad[i].push_back(a[j]);
		}
	}
	sort(ad+1,ad+n+1);
	map<int,int>mp;
	int now=0;
	for(int i=1;i<=n;i++){
		for(int j=0;j<ad[i].size();j++){
			int x=ad[i][j];
			if(mp.count(x)==0){
				mp[x]++;
				now++;
				ans[now]=x;
			}
		}
		for(int j=i+1;j<=n;j++){
			vector<int>t;
			for(int k=0;k<ad[j].size();k++){
				int x=ad[j][k];
				if(mp.count(x)==0){
					t.push_back(x);
				}
			}
			ad[j]=t;
		}
		sort(ad+i+1,ad+n+1);
		mp.clear();
	}  
	for(int i=1;i<=now;i++){
		cout<<ans[i]<<" ";
	}
	cout<<"\n";
}
signed main()
{
	fio;
	int ti=1;
	cin>>ti;
	while(ti--){
		solve();
	}
}
/*
1
5
4 2 3 1 4
5 2 5 5 6 5
5 3 4 7 5 5
8 3 6 4 3 1 1 5 4
2 1 1

1 3 3
1 3 4 2 1
1 4
2 2 2 3 4
4 3 3 2
*/