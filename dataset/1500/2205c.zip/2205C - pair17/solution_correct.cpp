#include <bits/stdc++.h>
using namespace std;
 
#define int long long
#define vi vector<int>
#define vvi vector<vector<int>>
#define endl "\n"
#define ff first
#define ss second
#define pb push_back
#define mkp make_pair
#define py cout<<"YES"<<endl
#define pn cout<<"NO"<<endl
#define srt(v) sort(v.begin(), v.end())
#define srtdec(v) sort(v.begin(), v.end(),greater<int>())
 
#define mxe(v) *max_element(v.begin(), v.end())
#define mne(v) *min_element(v.begin(), v.end())
 
 
// Operator overloads
template <typename T1, typename T2> // cin >> pair<T1, T2>
istream &operator>>(istream &istream, pair<T1, T2> &p)
{
    return (istream >> p.first >> p.second);
}
template <typename T> // cin >> vector<T>
istream &operator>>(istream &istream, vector<T> &v)
{
    for (auto &it : v)
        cin >> it;
    return istream;
}
template <typename T1, typename T2> // cout << pair<T1, T2>
ostream &operator<<(ostream &ostream, const pair<T1, T2> &p)
{
    return (ostream << p.first << " " << p.second);
}
template <typename T> // cout << vector<T>
ostream &operator<<(ostream &ostream, const vector<T> &c)
{
    for (auto &it : c)
        cout << it << " ";
    return ostream;
}
 
#ifndef ONLINE_JUDGE
#define debug(x) cerr << #x <<" "; _print(x); cerr << endl;
#else
#define debug(x)
#endif
 
 
void _print(int t) {cerr << t;}
void _print(string t) {cerr << t;}
void _print(char t) {cerr << t;}
 
void _print(double t) {cerr << t;}
 
 
template <class T, class V> void _print(pair <T, V> p);
template <class T> void _print(vector <T> v);
template <class T> void _print(set <T> v);
template <class T, class V> void _print(map <T, V> v);
template <class T> void _print(multiset <T> v);
template <class T, class V> void _print(pair <T, V> p) {cerr << "{"; _print(p.first); cerr << ","; _print(p.second); cerr << "}";}
template <class T> void _print(vector <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(set <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(multiset <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T, class V> void _print(map <T, V> v) {cerr << "[ "; for (auto i : v) {_print(i); cerr << " ";} cerr << "]";}
 
int ceil2(int a, int b){ return (a + b - 1) / b;}
int gcd(int a,int b){if (a==0||b==0){return a|b;}return __gcd(a,b);}
int lcm(int a,int b){return (a*b)/gcd(a,b);}
int power(int a, int b, int m) { int ans = 1; while (b) { if (b & 1) ans = (ans * a) % m; b /= 2; a = (a * a) % m; } return ans; }
int modInverse(int a, int m) { return power(a, m - 2, m); }


 
void solve(){
    
    int n;
    cin>>n;
    vector<vector<int>>vt;
    vector<int>ind(n);
    for (int i = 0; i <n; ++i)
    {
        int a;
        cin>>a;
        ind[i]=a-1;
        vi kt(a);
        cin>>kt;
        vt.push_back(kt);
    }
    vector<int>ans;
    map<int,int>mp;
    while(true){
        int mini=INT_MAX;
        for(int i=0;i<n;i++){
            while(ind[i]>=0){
                    int ele=vt[i][ind[i]];
                    if(mp.find(ele)==mp.end()){
                        mini=min(mini,ele);
                        break;
                    }
                    ind[i]--;
            }
        }
        debug(mini);
        if (mini==INT_MAX)
        {
            break;
        }
        vi minind;
        for (int i = 0; i <n; ++i)
        {
            if(ind[i]>=0&&vt[i][ind[i]]==mini){
                minind.push_back(i);
            }
        }
        debug(minind);
        if(minind.size()>1){
            vector<pair<vector<int>,int>>pt;
            for(auto it:minind){
                vi qt;
                for(int j=ind[it];j>=0;j--){
                    if (j!=ind[it]&&vt[it][j]!=vt[it][j+1]&&mp.find(vt[it][j])==mp.end())
                    {
                        qt.push_back(vt[it][j]);
                    }
                }
                pt.push_back({qt,it});
            }
            sort(pt.begin(),pt.end());
            int j=pt[0].ss;
            while(ind[j]>=0){
                if(mp.find(vt[j][ind[j]])==mp.end()){
                    ans.push_back(vt[j][ind[j]]);
                    mp[vt[j][ind[j]]]++;
                }
                ind[j]--;
            }
        }
        else{
            int j=minind[0];
            while(ind[j]>=0){
                if(mp.find(vt[j][ind[j]])==mp.end()){
                    ans.push_back(vt[j][ind[j]]);
                    mp[vt[j][ind[j]]]++;
                }
                ind[j]--;
            }
            
        }
    }
    cout<<ans<<endl;

}
 
 
 
 
signed main()
{
 
    #ifndef ONLINE_JUDGE
    freopen("Error.txt", "w", stderr);
    #endif
 
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
 
    int t;
    cin>>t;  
    while(t--){
        solve();
    }
    // solve();
    
 
}