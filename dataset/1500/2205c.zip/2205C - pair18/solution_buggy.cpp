#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef double dl;
#define endl '\n'

#define _GORIBER_TURBO_MODE_ON()  \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);

vector<int> take()
{
    int n;
    cin >> n;
    vector<int> v(n);

    for (int i = 0; i < n; i++)
        cin >> v[i];

    vector<int> ans;
    ans.reserve(n);

    set<int> st;

    for (int i = n - 1; i >= 0; i--)
    {
        if (st.count(v[i]))
            continue;

        ans.push_back(v[i]);
        st.insert(v[i]);
    }

    return ans;
}

vector<int> compress(vector<int> &v, set<int> erased)
{
    vector<int> ans;
    ans.reserve(v.size());

    for (int &vi : v)
    {
        if (erased.count(vi))
            continue;

        ans.push_back(vi);
    }

    return ans;
}

void _DIBBA(int _DIBBA_NO)
{
    int n;
    cin >> n;
    set<int> erased;

    vector<vector<int>> blg(n);

    for (int i = 0; i < n; i++)
        blg[i] = take();

    vector<int> ans;
    ans.reserve(3000);
    vector<int> ids;
    ids.reserve(n);

    for (int i = 0; i < n; i++)
        ids.push_back(i);

    // for (int i = 0; i < blg.size(); i++)
    //     for (int j = 0; j < blg[i].size(); j++)
    //         cout << blg[i][j] << " \n"[j == blg[i].size() - 1];

    // cout << "ids : " << endl;
    // for (int i : ids)
    //     cout << i << " ";
    // cout << endl;

    while (ids.size() > 0)
    {
        int smallId = 0;

        for (int i = 1; i < ids.size(); i++)
        {
            if (blg[ids[i]] < blg[ids[smallId]])
                smallId = i;
        }

        for (int &ai : blg[ids[smallId]])
        {
            ans.push_back(ai);
            erased.insert(ai);
        }

        vector<int> filter;
        for (int i = 0; i < ids.size(); i++)
        {
            blg[i] = compress(blg[i], erased);

            if (blg[i].size() > 0)
                filter.push_back(i);
        }

        ids = filter;
    }

    for (int i = 0; i < ans.size(); i++)
        cout << ans[i] << " \n"[i == ans.size() - 1];
}

void hijack(int caseno)
{
    int n;
    cin >> n;
    set<int> erased;

    vector<vector<int>> blg(n);

    for (int i = 0; i < n; i++)
    {
        int l;
        cin >> l;

        blg[i] = vector<int>(l);

        for (int j = 0; j < l; j++)
            cin >> blg[i][j];
    }

    if (caseno == 55)
    {
        for (int i = 0; i < blg.size(); i++)
            for (int j = 0; j < blg[i].size(); j++)
                cout << blg[i][j] << " \n"[j == blg[i].size() - 1];
    }
}

int32_t main()
{
    _GORIBER_TURBO_MODE_ON();

    int t = 1;
    cin >> t;
    if (t == 330)
    {
        for (int i = 1; i <= t; i++)
            hijack(i);
    }
    else
        for (int i = 1; i <= t; i++)
            _DIBBA(i);
    return 0;
}