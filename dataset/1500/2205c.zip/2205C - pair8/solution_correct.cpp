#include <bits/stdc++.h>
#define ll long long 
#define ld long double 
using namespace std;
const int N=1000010,M=1e9+7;
ll MM=LLONG_MAX;
ll n;
ll f[N];
auto cmp = [](const vector<ll>& a, const vector<ll>& b) {
    return a > b;
};
priority_queue<vector<ll>, vector<vector<ll>>, decltype(cmp)> pq(cmp);
void solve()
{
	cin >> n;
	stack<ll> q;
	vector<ll> ff(n+1,0);
	vector<vector<ll>> a(n+1);
	for(int i=1;i<=n;i++)
	{
		memset(f,0,sizeof f);
		ll l;
		cin >> l;
		while(l--)
		{
			ll x;
			cin >> x;
			q.push(x);
		}
		while(!q.empty())
		{
			if(!f[q.top()])
			{
				a[i].push_back(q.top());
				f[q.top()]=1;
			}
			q.pop();
		}
		//for(auto m:a[i]) cout << m << ' ';
		//pq.push(a[i]);
	}
	//for(auto m:a[5]) cout << m << ' ';
	//cout << endl;
	vector<ll> ans;
	for(int i=1;i<=n;i++)
	{
		ll f=0,p=0;
		for(int j=1;j<=n;j++)
		{
			if(!ff[j])
			{
				if(f==0)
				{
					ans=a[j];
					p=j;
					f=1;
				}
				else
				{
					if(a[j]<ans)
					{
						ans=a[j];
						p=j;
					}
				}
			}
		}
		//cout << p << endl;
		if(f==0) break;
		ff[p]=1;
		for(auto m:a[p]) cout << m << ' ';
		//cout << endl;
		for(int k=1;k<=n;k++)
		{
			for(auto& m:a[p])
			{
				if(k!=p) a[k].erase(remove(a[k].begin(),a[k].end(),m),a[k].end());
			}
		}
	}
	cout << endl;
}
signed main()
{   
	ll t=1;
    cin>>t;
	while(t--) solve();
	return 0;
}