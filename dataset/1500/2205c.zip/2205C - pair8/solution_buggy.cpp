#include <bits/stdc++.h>
#define ll long long 
#define ld long double 
using namespace std;
const int N=1000010,M=1e9+7;
ll MM=LLONG_MAX;
ll n;
ll f[N];
auto cmp = [](const vector<ll>& a, const vector<ll>& b) {
    return a > b;
};
priority_queue<vector<ll>, vector<vector<ll>>, decltype(cmp)> pq(cmp);
void solve()
{
	cin >> n;
	stack<ll> q;
	vector<vector<ll>> a(n+1);
	for(int i=1;i<=n;i++)
	{
		memset(f,0,sizeof f);
		ll l;
		cin >> l;
		while(l--)
		{
			ll x;
			cin >> x;
			q.push(x);
		}
		while(!q.empty())
		{
			if(!f[q.top()])
			{
				a[i].push_back(q.top());
				f[q.top()]=1;
			}
			q.pop();
		}
		//for(auto m:a[i]) cout << m << ' ';
		pq.push(a[i]);
	}
	queue<vector<ll>> p;
	while(!pq.empty())
	{
		auto m=pq.top(); pq.pop();
		while(!pq.empty())
		{
			p.push(pq.top()); pq.pop();
		}
		for(auto mm:m)
		{
			cout << mm << ' ';
		}
		while(!p.empty())
		{
			auto x=p.front(); p.pop();
            for(auto mm:m)
            {
            	x.erase(remove(x.begin(),x.end(),mm),x.end());
            }
            pq.push(x);
		}
	}
	cout << endl;
}
signed main()
{   
	ll t=1;
    cin>>t;
	while(t--) solve();
	return 0;
}