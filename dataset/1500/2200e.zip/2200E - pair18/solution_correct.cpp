#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define endl '\n'
const int N=1e5+10;
const ll MOD=1e9+7;

int gcd(int a,int b){
  return a%b==0?b:gcd(b,a%b);
}

ll gcd(ll a,ll b){
  return a%b==0?b:gcd(b,a%b);
}

// struct dsu{
//     vector<int> v1,size1;
//     dsu(int n){
//         size1.resize(n,1);
//         v1.resize(n);
//         for(int i=0;i<n;i++){
//             v1[i]=i;
//         }
//     }

//     int find(int a){
//         if(v1[a]!=a)return find(v1[a]);
//         return v1[a];
//     }

//     void unt(int a,int b){
//         int pos1=find(a);
//         int pos2=find(b);
//         if(pos1==pos2)return;
//         else if(size1[pos1]>size1[pos2]){
//             v1[pos1]=pos2;
//             size1[pos2]+=size1[pos1];
//         }
//         else{
//             v1[pos2]=pos1;
//             size1[pos1]+=size1[pos2];
//         }
//     }
// };

// int d[N],a[N];
// void build(int s, int t, int p) {
//   // 对 [s,t] 区间建立线段树,当前根的编号为 p
//   if (s == t) {
//     d[p] = a[s];
//     return;
//   }
//   int m = s + ((t - s) >> 1);
//   // 移位运算符的优先级小于加减法，所以加上括号
//   // 如果写成 (s + t) >> 1 可能会超出 int 范围
//   build(s, m, p * 2), build(m + 1, t, p * 2 + 1);
//   // 递归对左右区间建树
//   d[p] = d[p * 2] + d[(p * 2) + 1];
// }
ll pow1(ll a,ll b){
  ll ans=1;
  while(b){
    if(b&1){
      ans=ans*a%MOD;
    }
    a=a*a%MOD;
    b/=2;
  }
  return ans;
}

ll niyuan(ll a,ll b){
  return pow1(a,b-2)%MOD;
}


void solve() {
  int n;cin>>n;
  vector<int> v1(n,0);
  // set<int>s1[n];
  int flag1=1;
  for(int i=0;i<n;i++){
    cin>>v1[i];
    if(i!=0){
      if(v1[i-1]>v1[i])flag1=0;
    }
  }
  // cout<<flag1<<endl;
  if(flag1){
    cout<<"Bob"<<endl;return;
  }
  for(int i=0;i<n;i++){
    set<int>s1;
    for(int j=2;j*j<=v1[i];j++){
      while(v1[i]%j==0&&v1[i]/j!=1){
        s1.insert(j);
        v1[i]/=j;
      }
    }
    // cout<<v1[i]<<endl;
    if(v1[i]>1)s1.insert(v1[i]);
      // for(auto i:s1){
      //   cout<<i<<' ';
      // }cout<<endl;    
    if((i!=n-1&&v1[i]>v1[i+1])||s1.size()>1||(i!=0&&v1[i-1]>v1[i])){

      cout<<"Alice"<<endl;
      return;
    }
  }
  cout<<"Bob"<<endl;
}



int main() {
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
  int t=1;
  cin>>t;
  while(t--){
     solve();
  }
  return 0;
}
/*
      ┏┓　　┏┓+ +
　　　┏┛┻━━━┛┻┓ + +
　　　┃　　　　　　　┃ 　
　　　┃　　　━　　　┃ ++ + + +
　　 ████━████ ┃+
　　　┃　　　　　　　┃ +
　　　┃　　　┻　　　┃
　　　┃　　　　　　　┃ + +
　　　┗━┓　　　┏━┛
　　　　　┃　　　┃　　　　　　　　　　　
　　　　　┃　　　┃ + + + +
　　　　　┃　　　┃　　　　Codes are far away from bugs with the animal protecting　　　
　　　　　┃　　　┃ + 　　　　神兽保佑,代码大概率无bug(不过神兽偶尔也会休息哦~)　　
　　　　　┃　　　┃        Blessed by the mythical beast, may bugs stay far away
　　　　　┃　　　┃　　+　　　　　　　　　
　　　　　┃　 　　┗━━━┓ + +
　　　　　┃ 　　　　　　　┣┓
　　　　　┃ 　　　　　　　┏┛
　　　　　┗┓┓┏━┳┓┏┛ + + + +
　　　　　　┃┫┫　┃┫┫
　　　　　　┗┻┛　┗┻┛+ + +++
*/
 
/*******************************************
............................................
............................................
............................................
............................................
............................,1ffLf1.........
.....................,,,,,,GGGGGGGC.........
...................;8CCCftCCCCC1;LLG,.......
..................;CC8CCC.CCCCCCii,.........
................,CC88CCCC.CCCCCCC,..........
...............,CC88CCCCC .8.:8CCC,.........
...............,888 CCCCC.88888G;;,.........
................,888CC88.888888888,.........
.................,CCC888.888888888,.........
................,Gi1tC8f888888C88,..........
...............,111tttfffffLG8888,..........
.............,ii111ttttttfffttG,............
...........,i111tttffffffffffttt,...........
.........,11tttttfff....fffffftt,...........
........;1Lf1tff;..........fffff1,..........
.......;iiftG................LLGtL..........
.......;i11t:.................f1ii!.........
.......;i11t:.................:f111;........
.......;111:..................:t111;........
......;i1if:...................:i111;.......
,,,,,,,;8G;,,,,,,,,,,,,,,,,,,,,,,tL1;,,,,,,,
,,,,,,;LGL;,,,,,,,,,,,,,,,,,,,,,,,CLf,,,,,,,
,,,,,;LGGG;,,,,,,,,,,,,,,,,,,,,,,,LGCG,,,,,,
*******************************************/