#include<iostream>
#include<algorithm>
#include<vector>
#include<unordered_set>
using namespace std;
bool sorted(vector<int>a,int n){
    for(int i=0;i<n-1;i++){
if(a[i]>a[i+1]){
return false;
}
    }return true;
}
bool prime(int j){if(j==1){return false;}
    if(j==2||j==3){return true;}
    for(int i=2;i*i<=j;i++){
        if(j%i==0){
            return false;
        }
    }
    return true;
}
int count_distinct_prime_factors(int x) {
    int cnt = 0;
    for (int j = 2; j * j <= x; j++) {
        if (x % j == 0) {
            cnt++;
            while (x % j == 0) x /= j;
        }
    }
    if (x > 1) cnt++;
    return cnt;
}
signed main(){
int t;
cin>>t;
while(t--){
    int n;
    cin>>n;
    vector<int>a(n);
    for(int i=0;i<n;i++){
cin>>a[i];
    }
    if(sorted(a,n)){
        cout<<"Bob\n";
    }
    else{int flag=0;for(int i=0;i<n;i++){if(count_distinct_prime_factors(a[i])>=2){flag=1;break;}}
        int g=0;
for(int i=0;i<n;i++){
if(prime(a[i])){g++;}
}if(g==n){cout<<"Alice\n";}
else{
    if(flag){cout<<"Alice\n";}
    else{cout<<"Bob\n";}
}
    }}
 

    

}
