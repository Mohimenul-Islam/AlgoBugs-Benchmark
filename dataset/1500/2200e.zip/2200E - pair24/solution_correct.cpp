#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;

bool sorted(vector<int>a,int n){
    for(int i=0;i<n-1;i++){
        if(a[i]>a[i+1]) return false;
    }
    return true;
}

signed main(){
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;

        vector<int>a(n), base(n);

        for(int i=0;i<n;i++){
            cin>>a[i];
        }

        if(sorted(a,n)){
            cout<<"Bob\n";
            continue;
        }

        int flag = 0;

        for(int i=0;i<n;i++){
            int x = a[i];
            int cnt = 0, p = 0;

            for(int j=2;j*j<=x;j++){
                if(x%j==0){
                    cnt++;
                    if(cnt==1) p=j;
                    while(x%j==0) x/=j;
                }
            }

            if(x>1){
                cnt++;
                if(cnt==1) p=x;
            }

            if(cnt>=2){
                flag = 1; // has multiple distinct primes
            }

            if(cnt==0) base[i]=1;       // x = 1
            else if(cnt==1) base[i]=p;  // prime or prime power
            else base[i]=-1;            // not needed actually
        }

        if(flag){
            cout<<"Alice\n";
        }
        else{
            if(sorted(base,n)) cout<<"Bob\n";
            else cout<<"Alice\n";
        }
    }
}