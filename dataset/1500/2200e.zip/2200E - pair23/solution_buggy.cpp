#include <bits/stdc++.h>
#define endl '\n'
#define ll long long
#define ii pair<int,int>
#define forn(i, n) for (int i = 0; i < n; ++i)
using namespace std;

int fator;

int fact(int n) {
    int primes = 0;
    for (int i = 2; i * i <= n; i++) {
        bool ok = false;
        while (n % i == 0) {
            n /= i;
            ok = true;
            fator = i;
        }

        if (ok) primes++;
    }
    if (n > 1) primes = -1; // Se retornar -1, n é primo
    return primes;
}

void solve() {
    int n; cin >> n;
    vector<int> v(n);

    forn(i, n) {
        int a; cin >> a;
        v[i] = a;
    }

    int ult = 0;
    bool alice = false;
    if (is_sorted(begin(v), end(v))) {
        cout << "Bob" << endl;
    }

    
    else {
        for (auto el : v) {

            int ans = fact(el);
            //cout << el << " " << ans << endl;

            if (ans > 1) {
                alice = true;
                break;
            }

            else if (ans == -1 || ans == 0) {
                if (ult > el) { alice = true; break; }
                else ult = el;
            }

            else {
                if (ult > fator) { alice = true; break; }
                else ult = fator;
            }
        }

        if (!alice) cout << "Bob" << endl;
        else cout << "Alice" << endl;
    }
}

int main() {
    ios::sync_with_stdio(false);cin.tie(nullptr);
    cout << setprecision(10) << fixed;
    
    int tc; cin >> tc;
    while(tc--) solve();
    
    return 0;
}




