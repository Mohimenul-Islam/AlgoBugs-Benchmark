#include <bits/stdc++.h>
#define endl '\n'
#define ll long long
#define ii pair<int,int>
#define forn(i, n) for (int i = 0; i < n; ++i)
using namespace std;

int fator;

pair<int, bool> fact(int n) {
    int primes = 0;
    bool primo = true;
    for (int i = 2; i * i <= n; i++) {
        bool ok = false;
        while (n % i == 0) {
            n /= i;
            ok = true;
            fator = i;
            primo = false;
        }

        if (ok) primes++;
    }
    if (n > 1) primes++;

    return {primes, primo};
}

void solve() {
    int n; cin >> n;
    vector<int> v(n);

    forn(i, n) {
        int a; cin >> a;
        v[i] = a;
    }

    int ult = 0;
    bool alice = false;
    if (is_sorted(begin(v), end(v))) {
        cout << "Bob" << endl;
    }

    
    else {
        for (auto el : v) {

            auto ans = fact(el);
            //cout << el << " " << ans.first << endl;

            if (ans.first > 1) {
                alice = true;
                break;
            }

            else if (ans.second) {
                if (ult > el) { alice = true; break; }
                else ult = el;
            }

            else {
                if (ult > fator) { alice = true; break; }
                else ult = fator;
            }
        }

        if (!alice) cout << "Bob" << endl;
        else cout << "Alice" << endl;
    }
}

int main() {
    ios::sync_with_stdio(false);cin.tie(nullptr);
    cout << setprecision(10) << fixed;
    
    int tc; cin >> tc;
    while(tc--) solve();
    
    return 0;
}



/*

1 1 8 6

1 1 8 6


*/
