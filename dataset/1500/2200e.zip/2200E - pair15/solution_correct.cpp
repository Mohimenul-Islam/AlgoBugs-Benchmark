#include <bits/stdc++.h>
using namespace std;

int main() {

  ios::sync_with_stdio(0);
  cin.tie(0);

  int ts;
  cin >> ts;

  for (int t = 0; t < ts; t++) {
    int n;
    cin >> n;
    vector<int> a;
    for (int i = 0; i < n; i++) {
      int in;
      cin >> in;
      a.push_back(in);
    }

    bool nondec = true;
    int last = 0;
    for (int num : a) {
      if (num < last)
        nondec = false;
      last = num;
    }
    if (nondec) {
      cout << "Bob\n";
      continue;
    }

    bool alice = false;

    bool sive[2000];
    for (int i = 0; i < 2000; i++) {
      sive[i] = true;
    }
    int i = 0;
    while (i < 2000) {
      sive[i] = true;
      int step = i + 2;
      int mult = 2;
      while (step * mult - 2 < 2000) {
        sive[step * mult - 2] = false;
        mult++;
      }
      i++;
      while (i < 2000 && !sive[i]) {
        i++;
      }
    }
    vector<int> primes;
    for (int i = 0; i < 2000; i++) {
      if (sive[i])
        primes.push_back(i + 2);
    }

    last = 0;
    for (int &num : a) {
      bool not_prime = false;
      int pindex = 0;
      while (num > primes[pindex] / 2 && pindex < primes.size()) {
        if (num % primes[pindex] == 0) {
          int copy = num;
          while (copy > 1 && copy % primes[pindex] == 0) {
            copy = copy / primes[pindex];
          }
          if (copy > 1) {
            not_prime = true;
            break;
          } else {
            num = primes[pindex];
            break;
          }
        }
        pindex++;
      }
      if (num < last || not_prime) {
        alice = true;
      }
      last = num;
    }
    if (alice) {
      cout << "Alice\n";
    } else {
      cout << "Bob\n";
    }
  }
}
