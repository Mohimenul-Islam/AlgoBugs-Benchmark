#include<bits/stdc++.h>
using namespace std;

const int N = 1e5+5;
int n;
int a[N];
int maxin[N];
int minin[N];

int main()
{
    int T;
    cin>>T;
    while(T--)
    {
        cin>>n;
        bool cna = 1;
        for(int i=1;i<=n;i++)
        {
            int ops;
            cin>>ops;
            a[i] = ops;
            if(a[i] < a[i-1])   cna = 0;
            maxin[i] = 0;
            minin[i] = 0x3f3f3f3f;
            for(int j=2;j<=ops;j++)
            {
                if(ops % j == 0)
                {
                    maxin[i] = max(j,maxin[i]);
                    minin[i] = min(minin[i],j);
                    while(ops % j == 0)
                    {
                        ops /= j;
                    }
                }
            }
            if(minin[i] == 0x3f3f3f3f)  minin[i] = ops;
            if(maxin[i] == 0)   maxin[i] = ops;
        }
        if(cna)
        {
            cout<<"Bob"<<endl;
            continue;
        }
        int curmin = 0x3f3f3f3f;
        bool tmp = 1;
        for(int i=n;i>=1;i--)
        {
            curmin = min(curmin,minin[i]);
            if(maxin[i] > curmin)
            {
                tmp = 0;
                break;
            }
        }
        if(tmp) cout<<"Bob"<<endl;
        else    cout<<"Alice"<<endl;
    }
    return 0;
}