#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
#define pii pair<int, int>
#define ff first
#define ss second

int a[200100], p[1000100];

void solve(){
    int n, l, r;
    cin>>n;
    int ok = 0;
    for(int i=1; i<=n; i++){
        cin>>a[i];
        if(a[i] < a[i-1]) ok = 1;
    }
    if(!ok){
        cout<<"Bob";
        return;
    }
    int mx = 0;
    for(int i=1; i<=n; i++){
        if(a[i] < mx) {
            cout<<"Alice";
            return;
        }
        int h = p[a[i]];
        int x = a[i] / h;
        mx = max(mx, h);
        while(x != 1){
            if(h != p[x]){
                cout<<"Alice";
                return;
            }
            x /= p[x];
        }
    } 
    cout<<"Bob";
}

signed main(){
    p[1] = 1;
    int MAX = 1000000;
    for(int i=2; i<=MAX; i++){
        if(p[i]) continue;
        p[i] = i;
        for(ll j=i*1ll*i; j<=MAX; j+=i){
            p[j] = i;
        }
    }

    int t=1;
    cin>>t;
    while(t--){
        solve();
        cout<<'\n';
    }
}
