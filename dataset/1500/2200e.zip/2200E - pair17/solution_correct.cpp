#include<bits/stdc++.h>
using namespace std;
void solve(){
    int n;cin>>n;
    vector<int>b(n);
    int flg=1;
    for(int i=0;i<n;i++){
        cin>>b[i];
        if(i>0&&b[i]<b[i-1])flg=0;
    }
    if(flg){
        cout<<"Bob"<<endl;

        return;
    }
    vector<int>cf;
    for(int i=0;i<n;i++){
        int num=b[i];
        vector<int>a;int tmp=num;
        for(int i=2;i<=sqrt(num);i++){

               while(num>1){
                   if(num%i==0){a.push_back(i); num/=i;}
                   else break;

               }
        }
        if(num!=1)a.push_back(num);
        if(a.size()>1&&a[0]!=a.back()){
            cout<<"Alice"<<endl;return;
        }
        else{
            if(tmp!=1)cf.push_back(a[0]);
            else cf.push_back(1);
        }
    }

    for(int i=1;i<cf.size();i++){
        if(cf[i]<cf[i-1]){
            cout<<"Alice"<<endl;return;
        }
    }
    cout<<"Bob"<<endl;
}
int main(){
   int t;
   cin>>t;
   while(t--){
       solve();
   }

}