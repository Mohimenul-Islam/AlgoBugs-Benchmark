#include <bits/stdc++.h>
using namespace std;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	vector chk(1000001, 0);
	chk[1] = 1;
	for (int i = 2; i <= 1000; i++) {
		int cur = i;
		while (cur <= 1e6) {
			chk[cur] = i;
			cur *= i;
		}
	}

	vector p(1000001, 0);
	for (int i = 2; i * i <= 1e6; i++) {
		if (!p[i]) {
			for (int j = i * i; j <= 1e6; j += i) {
				p[j] = 1;
			}
		}
	}

	for (int i = 2; i <= 1e6; i++) {
		if (!p[i])
			chk[i] = i;
	}

	int T;
	cin >> T;
	while (T--) {
		int N;
		cin >> N;
		vector A(N, 0);
		for (auto &x : A)
			cin >> x;
		if (ranges::is_sorted(A)) {
			cout << "Bob" << "\n";
			continue;
		}

		int pre = 0;
		bool ok = true;
		for (int x : A) {
			if (p[x] && !chk[x]) {
				ok = false;
				break;
			}
			if (pre > chk[x]) {
				ok = false;
				break;
			}
			pre = chk[x];
		}

		cout << (ok ? "Bob" : "Alice") << "\n";
	}
}