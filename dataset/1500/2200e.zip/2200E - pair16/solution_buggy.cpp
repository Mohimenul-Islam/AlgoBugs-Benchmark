#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define F first
#define S second
#define ii pair <int, int>

const int N = 100100;

bool p[N*10];
int T,n,a[N],cnt[N*10];

void _clear()
{

}

void sieve()
{
    memset(p,1,sizeof p);

    p[0] = p[1] = 0;
    cnt[1] = 1;

    for(int i=0;i<N*10;i++)
        if( p[i] )
        {
            for(int j=i*2;j<N*10;j+=i)
            {
                p[j] = 0;
                cnt[j]++;
            }
            cnt[i]++;
        }
}

int main()
{
    sieve();

    scanf("%d", &T);
    while(T--)
    {
        _clear();

        scanf("%d",&n);
        for(int i=1;i<=n;i++)
            scanf("%d",&a[i]);

        if( is_sorted(a+1,a+n+1) )
        {
            printf("Bob\n");
            continue;
        }

        bool q = 0;
        for(int i=1;i<=n;i++)
            if( cnt[a[i]] != 1 )
                q = 1;

        if( q )
            printf("Alice\n");
        else
            printf("Bob\n");
    }
}
