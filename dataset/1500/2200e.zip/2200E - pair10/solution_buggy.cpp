#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
bool isprime(ll n){
    if(n<=1)return false;
    if(n==2)return true;
    for(ll i=2;i*i<=n;++i){
        if(n % i==0){
            return false;
        }
    }
    return true;
}
bool fenjie(ll n){
    ll cur=2;
    for(int i=2;i<=n;++i){
        if( n%i==0 &&isprime(i) ){
            cur=i;
            break;
        }
    }
    while(n>1){
        if(n % cur==0){
            // cout << cur <<" ";
            n/=cur;
        }else{
            return false;
        }
    }
    return true;
    // cout <<"\n";
}
void solve(){
    
    ll n=0;
    cin >> n;
    vector<ll> a(n+1);
    for(int i=1;i<=n;++i){
        cin >> a[i];

    }
    bool flag=true;
    for(int i=1;i<n;++i){
        if(a[i]<=a[i+1]){

        }else{
            flag=false;
            break;
        }
    }
    // cout <<"\n\n";
    if(flag){
        cout << "Bob" <<"\n";
        return;
    }
    for(int i=1;i<=n;++i){
        if(a[i]==1)continue;
        if(isprime(a[i]))continue;
        if(!fenjie(a[i])){
            cout <<"Alice" <<"\n";
            return;
        }
    }
    cout <<"Bob" <<"\n";
}
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int T=1;
    cin >> T;
    while(T--){
        solve();
    }
    return 0;
}