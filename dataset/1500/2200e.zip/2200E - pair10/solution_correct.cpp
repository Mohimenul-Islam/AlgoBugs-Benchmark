#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
bool isprime(ll n){
    if(n<=1)return false;
    if(n==2)return true;
    for(ll i=2;i*i<=n;++i){
        if(n % i==0){
            return false;
        }
    }
    return true;
}
ll fenjie(ll n){
    if(n==1)return 1;
    ll cur=2;
    for(int i=2;i<=n;++i){
        if( n%i==0 &&isprime(i) ){
            cur=i;
            break;
        }
    }
    while(n>1){
        if(n % cur==0){
            // cout << cur <<" ";
            n/=cur;
        }else{
            return -1;
        }
    }
    return cur;
    // cout <<"\n";
}
void solve(){
    
    ll n=0;
    cin >> n;
    vector<ll> a(n+1);
    for(int i=1;i<=n;++i){
        cin >> a[i];

    }
    bool flag=true;
    for(int i=1;i<n;++i){
        if(a[i]<=a[i+1]){

        }else{
            flag=false;
            break;
        }
    }
    // cout <<"\n\n";
    if(flag){
        cout << "Bob" <<"\n";
        return;
    }
    vector<ll> tmp;
    for(int i=1;i<=n;++i){
        if(isprime(a[i])){
            tmp.push_back(a[i]);
            continue;
        }
        ll t=fenjie(a[i]);
        if(t==-1){
            cout <<"Alice" <<"\n";
            return;
        }else{
            tmp.push_back(t);
        }
    }
    flag=true;
    // for(auto&num:tmp){
    //     cout << num <<" ";
    // }
    // cout <<"\n";
    for(int i=0;i<tmp.size()-1;++i){
        if(tmp[i]<=tmp[i+1]){

        }else{
            flag=false;
            break;
        }
    }
    if(flag){
        cout <<"Bob" <<"\n";
    }else{
        cout <<"Alice" <<"\n";
    }
    
}
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int T=1;
    cin >> T;
    while(T--){
        solve();
    }
    return 0;
}