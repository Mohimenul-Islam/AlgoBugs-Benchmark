#include <bits/stdc++.h>
#define ll long long
using namespace std;

   vector<ll>spf(1e6+1,-1);
   
   void build(){
      spf[1]=1;
      for(int i=2;i*i<=1e6;i++){
        if(spf[i]== (-1)){
        for(int j=i;j<=1e6;j+=i){
          if(spf[j]== (-1))spf[j]=i;
        }
      }
        
      }
      
   }

    
    void solve()
    {
        ll n;
        cin>>n;
        vector<ll>a(n);for(int i=0;i<n;i++)cin>>a[i];
        bool ok=false;
        
        if(n!=1){
        for(int i=0;i<n-1;i++){
          if(a[i]>a[i+1])ok=true;
        }
        if(!ok){
          cout<<"Bob"<<endl;return;
        }
       }
        
        for(int i=0;i<n;i++){
          ll j=spf[a[i]];
           
          ll temp=a[i];
          
          while(temp>1 && temp%j ==0)temp/=j;
          if(temp!=1){
            cout<<"Alice"<<endl;return;
          }
        }
        ll maxi=LLONG_MAX;
        for(int i=n-1;i>=0;i--){
          ll j=spf[a[i]];
          
          if(j > maxi){
            cout<<"Alice"<<endl;return;
          }
          maxi=min(maxi,j);
        }
        cout<<"Bob"<<endl;
        // for(int i=0;i<10;i++)cout<<spf[i]<<" ";
    } 

    int main()
    {
        build();
        ll t;
        cin>>t;
        while(t--)solve();
        return 0;
    }