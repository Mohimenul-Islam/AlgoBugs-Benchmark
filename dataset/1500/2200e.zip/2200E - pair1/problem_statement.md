# E. Divisive Battle

**Time limit:** 3 seconds
**Memory limit:** 256 megabytes

## Problem Statement

Alice and Bob are playing game on array $$$a$$$ initially containing $$$n$$$ positive integers, with Alice going first.

On each player's turn, if $$$a$$$ is non-decreasing$$$^{\\text{∗}}$$$, the game immediately ends. Otherwise, the player can choose an element $$$x$$$ from the array and positive integers $$$1 \\lt y,z \\lt x$$$ such that $$$x=yz$$$ and replace $$$x$$$ in the array with two elements $$$y$$$ and $$$z$$$ (in any order at the original location of $$$x$$$). If no such move is possible, the game ends.

Once the game ends, if $$$a$$$ is non-decreasing, then Bob wins. Otherwise, Alice wins. Determine who will win the game if both players play optimally.

$$$^{\\text{∗}}$$$$$$a$$$ is non-decreasing if $$$a\_i\\leq a\_{i+1}$$$ for all $$$1\\leq i\\leq m-1$$$, where $$$m$$$ is the length of $$$a$$$.

## Input

The first line contains an integer $$$t$$$ ($$$1 \\leq t \\leq 10^4$$$), the number of test cases.

The first line of each test case contains an integer $$$n$$$ ($$$1 \\leq n \\leq 10^5$$$).

The second line of each test case contains $$$n$$$ integers $$$a\_1, a\_2, \\dots, a\_n$$$ ($$$1 \\leq a\_i \\leq 10^6$$$).

The sum of $$$n$$$ over all test cases does not exceed $$$10^5$$$.

## Output

For each test case, output a line containing "Alice" if Alice wins or "Bob" if Bob wins. The grader is case-sensitive.

## Sample Tests

### Input
```
4
10
10 9 8 7 6 5 4 3 2 1
3
1 8192 677
2
6 5
2
6 7
```

### Output
```
Alice
Bob
Alice
Bob
```

## Note

In the first test case, Alice will win if both players play optimally.

In the second test case, Bob can always win no matter what moves Alice makes.

In the third test case, Alice can win by replacing $$$6$$$ with $$$3$$$ and $$$2$$$.

In the fourth test case, the game ends immediately and Bob wins.