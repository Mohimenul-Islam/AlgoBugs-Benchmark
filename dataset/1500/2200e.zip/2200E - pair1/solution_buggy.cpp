// Sunshine, sunshine, ladybugs awake!
// Clap your hooves and do a little shake!
#include <bits/stdc++.h>
#define int long long
#define endl '\n'
using namespace std;

using PII = pair<int, int>;
const int MAXN = 200010;
const int mod = 998244353;
const int INF = 0x3f3f3f3f3f3f3f3f;

vector<int> min_primes(MAXN, 0);
vector<int> max_primes(MAXN, 0);

void init(int n) {
    for (int i = 2; i <= n; i++) {
        if (min_primes[i] == 0) {
            for (int j = i; j <= n; j += i) {
                if (min_primes[j] == 0)
                    min_primes[j] = i;
                max_primes[j] = i;
            }
        }
    }

    min_primes[0] = max_primes[0] = 0;
    min_primes[1] = max_primes[1] = 1;
}

void solve() {
    int n;
    cin >> n;
    vector<int> a(n);
    for (int& i : a) cin >> i;

    if (is_sorted(a.begin(), a.end())) {
        cout << "Bob" << endl;
        return;
    }

    for (int i = 0; i < n; i++) {
        if (max_primes[a[i]] != min_primes[a[i]]) {
            cout << "Alice" << endl;
            return;
        }

        if (i > 0) {
            if (min_primes[a[i]] < max_primes[a[i - 1]]) {
                cout << "Alice" << endl;
                return;
            }
        }
    }

    cout << "Bob" << endl;
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    init(200000);
    int t;
    cin >> t;
    while (t--)
        solve();

    return 0;
}
