#include <bits/stdc++.h>

#define X first
#define Y second
#define PI acos(-1)
using namespace std;
#define int long long
typedef vector<int> vi;
typedef pair<int, int> pii;
#define sz(v) (int)v.size()
#define OO 0x3f3f3f3f3f3f3f3fLL
#define all(v) v.begin(), v.end()
#define allr(v) v.rbegin(), v.rend()
#define NO() return void(cout << "NO")
#define YES() return void(cout << "YES")
#define clr(v, d) memset(v, d, sizeof(v))
#define lp(i, n) for(int i = 0 ; i < n ; i++)
#define lpi(i, a, b) for(int i = a ; i < b ; i++)
#define lpd(i, a, b) for(int i = a ; i >= b ; i--)
#define watch(x) cout << (#x) << " = " << x << "\n"
#define rep(it, v) for(auto it = v.begin(); it != v.end(); ++it)
#define show(v) {for(auto _x : v) cout << _x << " "; cout << '\n';}
#define OSAMA_ASHRAF {ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0); cout << fixed << setprecision(10);}
int dx[] = {0, 0, 1, -1, 1, -1, 1, -1};
int dy[] = {1, -1, 0, 0, -1, 1, 1, -1};

const int N = 1e6 + 10;
int spf[N];


void pre() { // O(n log(n))
    lp(i, N) spf[i] = i;

    for (int i = 2; i * i <= N; i++) {
        if (spf[i] != i) continue;
        for (int j = i * i; j < N; j += i) {
            if (spf[j] == j)
                spf[j] = i;
        }
    }
}

void break_limits() {
    int n;
    cin >> n;

    vi v(n);
    lp(i, n) cin >> v[i];
    if (is_sorted(all(v)))
        return void(cout << "Bob");

    int g=0;
    lp(i, n) {
        int cnt=0;

        while (v[i]!=1) {
            int s = spf[v[i]];
            g = max(g, s);
            cnt++;

            if (s<g or cnt>1)
                return void(cout << "Alice");

            while (v[i]%s==0)
                v[i]/=s;
            s = spf[v[i]];
            g = max(g, s);
        }
    }

    cout << "Bob";
}


signed main() {
    OSAMA_ASHRAF
#ifndef ONLINE_JUDGE
    freopen("../in.txt", "r", stdin);
    freopen("../out.txt", "w", stdout);
#endif
    pre();
    int tt = 1;
    cin >> tt;

    while (tt--) {
        break_limits();
        cout << "\n";
    }

    return 0;
}
