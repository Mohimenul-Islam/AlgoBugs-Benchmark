#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N = 1e6;

int vis[N + 1];

void init() {
	for (int i = 2; i <= N; i++) {
		if (!vis[i]) {
			for (int j = i + i; j <= N; j += i) {
				vis[j] = 1;
			}
		}
	}	
}

void solve() {
	int n;
	cin >> n;
	
	vector<int> a(n), v, p(n), cnt(n);
	for (int i = 0; i < n; i++) {
		cin >> a[i];
		if (!vis[a[i]]) {
			v.push_back(a[i]);
		}
		int t = a[i];
		for (int j = 2; j <= t / j; j++) {
			if (t % j == 0) {
				cnt[i]++;
				while (t % j == 0) {
					t /= j;
				}
				p[i] = j;
			}
		}
		if (t > 1) {
			cnt[i]++;
			p[i] = t;
		}
	}
	
	bool ok = true;
	for (int i = 1; i < n; i++) {
		if (a[i] < a[i - 1]) {
			ok = false;
			break;
		}
	}
	
	if (ok || n == 1) {
		cout << "Bob" << "\n";
		return;
	}
	
	if (a[n - 1] == 1 && a[n - 2] != 1) {
		cout << "Alice" << "\n";
		return;
	}
	
	for (int i = 1; i < n - 1; i++) {
		if (a[i] == 1 && (a[i] != a[i - 1] || a[i] != a[i + 1])) {
			cout << "Alice" << "\n";
			return;
		}
	}
	
	int mx = 0;
	for (int i = 0; i < v.size(); i++) {
		if (v[i] < mx) {
			cout << "Alice" << "\n";
			return;
		}
		mx = max(v[i], mx);
	}
	
	for (int i = 0; i < n; i++) {
		if (cnt[i] > 1) {
			cout << "Alice" << "\n";
			return;
		}
	}
	
	for (int i = 1; i < n; i++) {
		if (p[i] < p[i - 1]) {
			cout << "Alice" << "\n";
			return;
		}
	}
	
	cout << "Bob" << "\n";
}

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);

	init();
	int T = 1;
	cin >> T;

	while (T--) {
		solve();
	}

	return 0;
}
