﻿#include <iostream>
#include <vector>
#include <cmath>
#include <set>
#include <algorithm>
using namespace std;
using ll = long long;

int func(int x) {
    set<int> s;
    for (int i = 2; i * i <= x; i++) {
        if (x % i == 0)s.insert(i);
        while (x % i == 0) {
            x /= i;
        }
    }

    if (x > 1)s.insert(x);
    if (s.size() > 1)return -1;
    if (s.size() == 0)return 1;
    return *s.begin();
}

void solve() {
    int n; cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i++)cin >> a[i];
    vector<int> b(n);
    for (int i = 0; i < n; i++)b[i] = func(a[i]);

    if (is_sorted(a.begin(), a.end())) {
        cout << "Bob\n";
    }
    else if (*min_element(b.begin(), b.end()) == -1) {
        cout << "Alice\n";
    }
    else if (is_sorted(b.begin(), b.end())) {
        cout << "Bob\n";
    }
    else {
        cout << "Alice\n";
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--) {
        solve();
    }

    return 0;
}