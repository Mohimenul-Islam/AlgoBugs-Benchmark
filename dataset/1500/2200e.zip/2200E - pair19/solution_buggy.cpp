﻿#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
using ll = long long;
vector<int> p;
int maxn = 1e6 + 10;
vector<bool> is_p;
void init() {
    is_p.resize(maxn, true);
    is_p[1] = false;
    for (int i = 2; i < maxn; i++) {
        if (is_p[i]) {
            p.push_back(i);
            if (1LL * i * i < maxn) {
                for (int j = i * i; j < maxn; j += i)is_p[j] = false;
            }
        }
    }
}
int n;
bool func(vector<int>& a) {
    for (int i = 1; i < n; i++) {
        if (a[i] < a[i - 1])return false;
    }

    return true;
}

void solve() {
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i++)cin >> a[i];

    if (func(a)) {
        cout << "Bob\n";
        return;
    }

    vector<vector<int>> b(n);
    for (int i = 0; i < n; i++) {
        for (const int& x : p) {
            if (x * 2 > a[i])break;
            if (is_p[a[i]]) continue;
            int t = sqrt(a[i]);
            if (t * t == a[i] && is_p[t]) {
                b[i].push_back(t);
                continue;
            }

            if (a[i] % x == 0) {
                b[i].push_back(x);
            }
            if (b[i].size() >= 2) {
                cout << "Alice\n";
                return;
            }
        }
    }

    vector<int> c(n);
    for (int i = 0; i < n; i++) {
        if (b[i].size()) {
            c[i] = b[i][0];
        }
        else {
            c[i] = a[i];
        }
    }

    if (func(c)) {
        cout << "Bob\n";
        return;
    }

    cout << "Alice\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    init();
    while (t--) {
        solve();
    }

    return 0;
}