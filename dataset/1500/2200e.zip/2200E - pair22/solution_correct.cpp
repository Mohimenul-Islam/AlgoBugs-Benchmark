#include <algorithm>
#include <cmath>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <vector>

using namespace std;

using ll = long long;

const int MAX = 1e6 + 2;
vector<int> min_prime_factor(MAX, 0);
vector<int> primes;
vector<int> a(1e5);
vector<int> after(1e5);
int n = 0;
int ans = 0;

int is_sorted(const vector<int> &a, int n) {
    for (int i = 0; i < n - 1; ++i) {
        if (a[i] > a[i + 1]) {
            return 0;
        }
    }
    return 1;
}

void euler_sieve() {
    for (int i = 2; i < MAX; ++i) {
        if (min_prime_factor[i] == 0) {
            min_prime_factor[i] = i;
            primes.push_back(i);
        }
        for (int j : primes) {
            if (i * j >= MAX || j > min_prime_factor[i])
                break;
            min_prime_factor[i * j] = j;
        }
    }
}

vector<int> factors(int x) {
    vector<int> _factors;
    if (x == 1) {
        _factors.push_back(1);
        return _factors;
    }
    while (x > 1) {
        _factors.push_back(min_prime_factor[x]);
        x /= min_prime_factor[x];
    }
    return _factors;
}

bool has_different_factors(int x) {
    if (x <= 1)
        return false;
    int min_prime_factor_of_input = min_prime_factor[x];
    while (x > 1) {
        if (min_prime_factor[x] != min_prime_factor_of_input)
            return true;
        x /= min_prime_factor[x];
    }
    return false;
}

void solve() {
    if (is_sorted(a, n)) {
        ans = 0;
        return;
    }
    for (int i = 0; i < n; ++i) {
        if (has_different_factors(a[i])) {
            ans = 1;
            return;
        }
        after[i] = factors(a[i]).front();
    }
    if (is_sorted(after, n)) {
        ans = 0;
        return;
    } else {
        ans = 1;
        return;
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t = 1;
    cin >> t;
    euler_sieve();
    // cout << factors(8).front();
    while (t--) {
        cin >> n;
        for (int i = 0; i < n; ++i)
            cin >> a[i];
        solve();
        cout << (ans ? "Alice" : "Bob") << '\n';
    }
    return 0;
}