#include <bits/stdc++.h>
#define ll long long
using namespace std;

const int MAXN = 1e6 + 5;

int spf[MAXN];          // smallest prime factor
int unique_cnt[MAXN];   // number of DISTINCT prime factors

void precompute() {
    // Step 1: SPF
    for (int i = 1; i < MAXN; i++) spf[i] = i;

    for (int i = 2; i < MAXN; i++) {
        if (spf[i] == i) { // prime
            for (int j = i; j < MAXN; j += i) {
                if (spf[j] == j) spf[j] = i;
            }
        }
    }

    // Step 2: unique prime factor count
    unique_cnt[1] = 0;

    for (int i = 2; i < MAXN; i++) {
        int p = spf[i];
        int reduced = i / p;

        if (spf[reduced] == p) {
            // same prime continues → don't count again
            unique_cnt[i] = unique_cnt[reduced];
        } else {
            // new distinct prime
            unique_cnt[i] = unique_cnt[reduced] + 1;
        }
    }
}

void solve() {
    ll n; cin>>n;
    vector<ll> arr(n);

    for(ll i=0;i<n;i++) cin>>arr[i];

    bool flag = true;
    for(ll i=1;i<n;i++){
        if(arr[i] < arr[i-1]){
            flag = false;
        }
    }
    if(flag){
        cout<<"Bob\n";
        return;
    }

    for(ll i=0;i<n;i++){
        ll val = arr[i];
        ll prime = unique_cnt[val];
        if(prime > 1 || (i>0 && spf[arr[i-1]]>spf[arr[i]])){
            cout<<"Alice\n";
            return;
        }
    }
    cout<<"Bob\n";

}

     
int main(){
    #ifndef ONLINE_JUDGE
        freopen("input.txt","r",stdin);
        freopen("output.txt","w",stdout);
    #endif

    ll t=1;
    cin>>t;
    precompute();
    while(t--){
        solve();
    }
}
