#include<bits/stdc++.h>
using namespace std;
const int MAX = 1e6;
int main(){
  int t;
  cin>>t;
vector<vector<int>> prime(MAX);
  for(int i=2;i<MAX;i++){
    if(prime[i].size()==0){

      for(int j=i;j<MAX;j+=i)
      prime[j].push_back(i);
    }
  }
  while(t--){
    int n;
    cin>>n;
    vector<int>arr(n);
    bool sorted = true;

    for(int i=0;i<n;i++){
      cin>>arr[i];
      if(i>0 && arr[i]<arr[i-1]) sorted =false;
    }
    if(sorted){
      cout<<"Bob"<<endl;
      continue;
    }
    
    bool ans =false;
    for(int i=0;i<n;i++){
      vector<int> &temp = prime[arr[i]];
      if(temp.size()>=2) ans =true;
      if(!temp.empty()) arr[i]=temp[0]; 
  
      if(ans)break;
    }
    
    if(ans){
      cout<<"Alice"<<endl;
    }
    else {
     for(int i=1;i<n-1;i++){

     if(arr[i]<arr[i-1]) sorted =true;
     }
      if(!sorted)cout<<"Bob";
      else cout<<"Alice";
      cout<<endl;
    }
}
}