#include<bits/stdc++.h>
using namespace std;


int prime_factor(int x){
	if(x==1) return x;
	int p=-1;
	int temp=x;
	for(int i=2;i*i<=x;i++){
		if(temp%i==0){
			if(p!=-1) return -1;
			p=i;
			while(temp%i==0) temp/=i;
		}
	}
	
	if(temp>1){
		if(p!=-1)return -1;
		return temp;
	}
	return p;
}

void solve(){
	int n;cin>>n;
	vector<int>a(n);
	for(int i=0;i<n;i++) cin>>a[i];
	
	bool flag=true;
	for(int i=0;i<n-1;i++){
		if(a[i]>a[i+1]) flag=false;
		
	}
	if(flag){
		cout<<"Bob\n";
		return ;
	}
	flag=true;
	vector<int>b;
	for(int i=0;i<n;i++){
		int x=prime_factor(a[i]);
		
		if(x==-1){
			cout<<"Alice\n";
			return;
		}
		
		b.push_back(x);
	}
	for(int i=0;i<n-1;i++){
		if(b[i]>b[i+1]) flag=false;
	}
	if(flag)  cout<<"Bob\n";
	else cout<<"Alice\n";
}

int main(){
	  int  t;cin>>t;
	  while(t--) solve();
}
