#include <bits/stdc++.h>
#ifdef LOCAL
#include "debug.cpp"
#define TIME_BLOCK(name, t) \
    if (bool _once = false) \
    {                       \
    }                       \
    else                    \
        for (__DEBUG_UTIL__::LabeledTimer _t(name, t); !_once; _once = true)
#else
#define debug(...) void(0)
#define debugArr(...) void(0)
#define TIME_BLOCK(name, t) if (true)
#endif // Debugging locally
using namespace std;
#define ll long long int
#define endl "\n"

vector<int> Prime, LPF, MPF;
bitset<1000001> isPrime;
void linearSieveOfEratosthenes(int N)
{
    isPrime.set(); // Initially Assuming all numbers to be primes
    LPF.resize(N + 1);
    MPF.resize(N + 1);
    isPrime[0] = isPrime[1] = 0; // 0 and 1 are NOT primes
    for (long long i{2}; i <= N; i++)
    {
        if (isPrime[i])
        {
            Prime.push_back(i);
            LPF[i] = MPF[i] = i; // The least & maximum prime factor of a prime number is itself
        }
        for (long long j{}; j < (int)Prime.size() && i * Prime[j] <= N && Prime[j] <= LPF[i]; j++)
        {
            isPrime[i * Prime[j]] = 0; // Crossing out all the multiples of prime numbers
            LPF[i * Prime[j]] = Prime[j];
            MPF[i * Prime[j]] = MPF[i];
        }
    }
}
static int autoCall = (linearSieveOfEratosthenes(1000000), 0);

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("Output.txt", "w", stdout);
#endif
    int t = 1;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        vector<ll> vc(n);
        for (int i{}; i < n; i++)
            cin >> vc[i];
        if (is_sorted(vc.begin(), vc.end()))
        {
            cout << "Bob\n";
            continue;
        }
        if (find_if(vc.begin(), vc.end(), [&](const int &x)
                    { return x > 1 && !isPrime[x]; }) == vc.end())
        {
            cout << "Alice\n";
            continue;
        }
        bool chk = false;
        ((vc[0] > 1) && (chk |= (LPF[vc[0]] != MPF[vc[0]])));
        for (int i = 1; i < n; i++)
        {
            if (vc[i] == 1 || isPrime[vc[i]])
                chk |= (vc[i] < LPF[vc[i - 1]]);
            else
                chk |= (LPF[vc[i]] != MPF[vc[i]]);
        }
        cout << (chk ? "Alice\n" : "Bob\n");
    }
    return 0;
}
