#include <bits/stdc++.h>
#include <algorithm>

using namespace std;

void solve()
{
  int n;
  cin >> n;
  vector<int> v(n);
  for (int i = 0; i < n; i++)
    cin >> v[i];

  // check non-desc
  bool isAsc = true;
  for (int i = 1; i < n; i++)
  {
    if (v[i] < v[i - 1])
    {
      isAsc = false;
      break;
    }
  }
  if (isAsc)
  {
    cout << "Bob" << endl;
    return;
  }

  // check factorization
  bool aliceWins = false;
  for (int j = 0; j < n; j++)
  {
    int c = v[j];
    if (!aliceWins && c != 1)
    {
      vector<int> pf;
      for (int i = 2; i * i <= c; i++)
      {
        if (c % i == 0)
        {
          pf.push_back(i);
          while (c % i == 0)
            c /= i;
        }
      }
      if (c != 1)
        pf.push_back(c);
      int l = *min_element(pf.begin(), pf.end());
      int h = *max_element(pf.begin(), pf.end());
      aliceWins = (l != h);
    }
    if (aliceWins)
      break;
  }
  if (aliceWins)
  {
    cout << "Alice" << endl;
  }
  else
  {
    cout << "Bob" << endl;
  }
}

int main()
{
  ios::sync_with_stdio(false);
  cin.tie(0);

  int t;
  cin >> t;
  while (t--)
    solve();
}