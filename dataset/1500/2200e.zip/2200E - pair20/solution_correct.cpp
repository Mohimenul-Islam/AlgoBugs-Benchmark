#include <bits/stdc++.h>
#include <algorithm>

using namespace std;

void solve()
{
  int n;
  cin >> n;
  vector<int> v(n);
  for (int i = 0; i < n; i++)
    cin >> v[i];

  // check non-desc
  bool isAscBefore = true;
  for (int i = 1; i < n; i++)
  {
    if (v[i] < v[i - 1])
    {
      isAscBefore = false;
      break;
    }
  }
  if (isAscBefore)
  {
    cout << "Bob" << endl;
    return;
  }

  // check factorization
  vector<int> vn;
  for (int j = 0; j < n; j++)
  {
    int c = v[j];
    if (c != 1)
    {
      vector<int> pf;
      for (int i = 2; i * i <= c; i++)
      {
        if (c != i && c % i == 0)
        {
          pf.push_back(i);
          while (c % i == 0)
            c /= i;
        }
      }
      if (c != 1 && c != v[j])
        pf.push_back(c);
      if (pf.size() > 1)
      {
        int l = *min_element(pf.begin(), pf.end());
        int h = *max_element(pf.begin(), pf.end());
        vn.push_back(h);
        vn.push_back(l);
      }
      else if (pf.size() == 1)
      {
        vn.push_back(pf[0]);
      }
      else
      {
        vn.push_back(c);
      }
    }
    else
    {
      vn.push_back(c);
    }
  }

  // check non-desc
  bool isAsc = true;
  for (int i = 1; i < vn.size(); i++)
  {
    if (vn[i] < vn[i - 1])
    {
      isAsc = false;
      break;
    }
  }

  if (isAsc)
  {
    cout << "Bob" << endl;
    return;
  }
  else
  {
    cout << "Alice" << endl;
  }
}

int main()
{
  ios::sync_with_stdio(false);
  cin.tie(0);

  int t;
  cin >> t;
  while (t--)
    solve();
}