#include "bits/stdc++.h"

#define endl '\n'

#define F first

#define S second

#define pb push_back

#define all(x) x.begin() , x.end()

#define mm(dp , val) memset (dp , val , sizeof dp)

#define mid ((r+l)>>1)  

#define lx (n<<1)

#define rx ((n<<1)|1)

#define low (i&(-i))

#define lb lower_bound

#define ub upper_bound

#define no void (cout << "NO" << endl)

#define one void (cout << "-1" << endl)

#define zer void (cout << "0" << endl)

#define yes void (cout << "YES" << endl)

typedef long long ll;

using namespace std;

const int logn = 26 ;

const int N = 1e6+5;

const int mod = 1e9+7;

const long long oo = 4557430888798830399 ;

ll dx[] = {0 , 0 , 1 , -1};
ll dy[] = {1 , -1 , 0 , 0};

ll n , m , a[N] , sum , ans , mn , mx , x , y , p , q , k;

string s ;

map <ll,ll> mp ;

vector <ll> v ;

bool is ;

bool ch (ll x) 
{
    for (int i = 1 ; i + x - 1 <= n ; i++) 
    {
        ll cur = 0 ; 
        if (i + x - 1 < k) cur = (x-1) + k - i ;
        else if (i > k) cur = (x-1) + ((i+x-1) - k) ;
        else 
        {
            ll l = k - i , r = (i+x-1) - k ;
            cur = 2*max(l , r) - 1 + min(l , r) ; 
        }
        
        if (cur <= m) return true ;
    }
    
    return false ; 
}

inline void solve () 
{
    cin >> n >> m >> k ;
    
    ll l = 1 , r = n+1 ; 
    while (r - l > 1) 
    {
        if (ch(mid)) l = mid ; 
        else r = mid ; 
    } 
    
    cout << l << endl ; 

}

int main()
{
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    
    ll t = 1 ; cin >> t ;
    while (t--)
    {
        ans = 0 ; sum = 0 ; mn = oo ; mx = 0 ;
        v.clear(); mp.clear() ;
        is = false ;
        solve();
    }

    return 0;
}

