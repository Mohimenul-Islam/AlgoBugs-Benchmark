#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
typedef long long ll;
typedef long double ld;
typedef string ss;
template<class T> using ordered_multiset = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>;
#define Omar_G ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
#define all(x) x.begin(), x.end()
#define endl "\n"
random_device rd;
mt19937 mt(rd());
int rnd(int l, int r) {
    return uniform_int_distribution<int>(l, r)(mt);
}
#define Y(x) ss((x) ? "Yes" : "No")
const ll mod = 998244353, inf = 5e18, N = 2e5 + 5, M = 500+5;
void solve() {
    ll n, m, k;
    cin >> n >> m >> k;
    ll a = 0, b = 0, l = min(k-1, n-k), r = max(k-1, n-k);
    while (1) {
        if (a < l && a + b + max(a+1, b) <= m) a++;
        if (b < r && a + b + max(a, b+1) <= m) b++;
        else break;
    }
    cout << a + b + 1 << endl;
}   
int main() {
    Omar_G
    // freopen("a.in", "r", stdin);
    // freopen("a.out", "w", stdout);
    ll t = 1;
    cin >> t;
    for (ll i = 1; i <= t; i++) {
        solve();
    }
    return 0;
}