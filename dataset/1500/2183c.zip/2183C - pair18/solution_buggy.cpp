//Bismillah
/*
The world rewards those who are willing to be bad at something long enough to become
great at it!
*/
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
template <typename T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
#define hazrat ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);int tt = 1;
#define int long long int
#define vi vector<int>
#define vb vector<bool>
#define vc vector<char>
#define vs vector<string>
#define vvi vector<vi>
#define iv(vec) for(auto &value: vec) cin>>value;
#define pr(vec) {for(auto &value: vec) cout<<value<<" ";} nl;
#define pb push_back
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define pii pair<int,int>
#define vpii vector<pii>
#define ld long double
#define nl cout<<"\n";
#define yes cout << "YES\n"
#define no cout << "NO\n"
#define file_read(filepath) freopen(filepath, "r", stdin);
#define file_write(filepath) freopen(filepath, "w", stdout);

// I am a loser
void solve(){
    int n,m,k;cin>>n>>m>>k;
    auto func=[&](int x)->bool{
        int left=k,right=n-k,wait;
        if(left>right){
            right=min(n,k+(x/2));
            left=k+1-(x-(right-k));
            wait=max(0LL,k-left-1);
        }else{
            left=max(k+1-((x+1)/2),1LL);
            right=k+x-(k-left+1);
            wait=max(right-k-1,0LL);
        }
        // cout<<left<<' '<<right<<' '<<wait<<"\n";
        return wait+(k-left)+(right-k)<=m;
    };

    // cout<<func(3)<<"\n";
    int lo=1,hi=n,res=1;
    while(lo<=hi){
        int mid=lo+(hi-lo)/2;
        if(func(mid)){
            res=mid;
            lo=mid+1;
        }else{
            hi=mid-1;
        }
    }
    cout<<res<<"\n";
}

signed main(){
    hazrat;
    cin>>tt;
    while(tt--)
    {
        solve();
    }
    return 0;
}