//Bismillah
/*
The world rewards those who are willing to be bad at something long enough to become
great at it!
*/
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
template <typename T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
#define hazrat ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);int tt = 1;
#define int long long int
#define vi vector<int>
#define vb vector<bool>
#define vc vector<char>
#define vs vector<string>
#define vvi vector<vi>
#define iv(vec) for(auto &value: vec) cin>>value;
#define pr(vec) {for(auto &value: vec) cout<<value<<" ";} nl;
#define pb push_back
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define pii pair<int,int>
#define vpii vector<pii>
#define ld long double
#define nl cout<<"\n";
#define yes cout << "YES\n"
#define no cout << "NO\n"
#define file_read(filepath) freopen(filepath, "r", stdin);
#define file_write(filepath) freopen(filepath, "w", stdout);

// I am a loser
void solve(){
    int n,m,k;cin>>n>>m>>k;
    // do I fortify x bases in m seconds?
    auto func=[&](int x)->bool{
        int l=k-1,r=n-k,rem=x-1;
        int time=0;
        if(l>=r){
            r=max(r-rem/2,0LL);
            l=l-(rem-((n-k)-r));
            time=2*((k-1)-l)-1;
            time=time+(n-k)-r;
        }else{
            l=max(l-rem/2,0LL);
            r=r-(rem-((k-1)-l));
            time=(k-1)-l;
            time=time+2*((n-k)-r)-1;
        }
        return time<=m;
    };
    // cout<<func(3)<<"\n";
    int lo=1,hi=n,res=1;
    while(lo<=hi){
        int mid=lo+(hi-lo)/2;
        if(func(mid)){
            res=mid;
            lo=mid+1;
        }else{
            hi=mid-1;
        }
    }
    cout<<res<<"\n";
}

signed main(){
    hazrat;
    cin>>tt;
    while(tt--)
    {
        solve();
    }
    return 0;
}