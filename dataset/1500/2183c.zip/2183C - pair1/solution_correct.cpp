#include <bits/stdc++.h>

using namespace std;

#define int long long
#define inf 1e18
#define pii pair<int, int>
#define fi first
#define se second
#define vi vector<int>
#define vpi vector<pii>
#define vvi vector<vi>
#define pb push_back
#define sz(x) (int) (x).size()
#define all(x) x.begin(), x.end()
#define fore(i, a, b) for (int i = a; i < (b); ++i)
#define forn(i, n) for (int i = 0; i < (n); ++i)
#define endl '\n'

template <typename T>
ostream& operator << (ostream& os, const vector<T>& v) {
    for (const auto& x : v) os << x << ' '; return os;
}
template <typename T>
istream& operator >> (istream& is, vector<T>& v) {
    for (auto &x : v) is >> x; return is;
}

void solve() {
    int n, m, k; cin >> n >> m >> k;
    if (m >= 2 * max(n - k, k - 1) + min(n - k, k - 1) - 1) {
        cout << n << endl;
    } else {
        int ans = 1;
        for (int l = 0; l < k; l++) {
            int r1 = min(n - k, (m - l + 1) / 2);
            int r2 = min(n - k, m - 2 * l + 1);
            if (r1 >= l) ans = max(ans, l + r1 + 1);
            if (l >= r2) ans = max(ans, l + r2 + 1);
        } cout << ans << endl;
    }
}

signed main() {
    cin.tie(0)->sync_with_stdio(0);
    cin.exceptions(cin.failbit);
    int T = 1;
    cin >> T;
    while(T--) {
        solve();
    }
}