#include<bits/stdc++.h>
using namespace std;
#define int long long
#define fastio ios::sync_with_stdio(false); cin.tie(nullptr);


int32_t main(){
    fastio;
    /*
      c c  c  c c c say if you have more values does it makes anyhting no becuase its adjacent matters only 
      4 4 3 2 1 

      3+4=7
      1+2+3+4=7 wrong right so whats best thing here is that store first values at base maxmimum on each day then send maximum-1
      store one side then thats the greedy  idea right here 
      how much you should store here if m days there 
      okay the thing here is that 
         1 1 2 1 1
             
           1 2 2 2 1

         3 3 3 3 3 2 1 
         move to right  side first with pos as 2*pos-1 i want to fill upto this right here then i will do like min(pos-1,m) on right
         side here 
                you move one side and preserve for the right side also here 
        can you calc directly for both side and one side here 
         1 2 3 4 5
         better things i have right here 
         pos-1+pos+pos
         3*pos-1 moves i can do things here up right on both side here 
         pos values right here at base when one side finished up 
         2*pos-1<=m
         you need at each step two moves right here one for that inc and one for that moving 
         c 3 2  

   7  6  5  4 5 6 7
        

        
        

    */
    int t;
    cin>>t;
    while(t--){
        int n,m,k;
        cin>>n>>m>>k;
        if(n==1){
            cout<<"1"<<"\n";
            continue;
        }
         if(m==1){
            cout<<"2"<<"\n";
            continue;
         }
         if(k==1||k==n){
               int vl= (m+1)/2;
               int rem= n-1;
               int temp=min(vl,rem);
               cout<<temp+1<<"\n";
               continue;
         }
        int ans=0;
        int lo=k-1;
        int hi=k+1;
        int flag=0;
        while(lo>=1&&hi<=n){
            int pos=k-lo;
            if(m>=3&&pos>1){
                ans+=2;
                m-=3;
            }
            else if(m>=2&&pos==1){
                ans+=2;
                m-=2;
            }
           else{
              flag=1;
              break;
           }
           lo--,hi++;
        }
            if(lo>=1){
              int vl=m/2;
              int temp=min(vl,lo);
              ans+=temp;
              m-=temp;
            }
            if(hi<=n){
                int vl=m/2;
                int rem=( n-hi+1);
                int temp=min(vl,rem);
                ans+=temp;
                m-=temp;
            }
        cout<<ans+1<<'\n';
        
        
       
    }
    return 0;
}