#include <iostream>
#include <algorithm>

using namespace std;

void solve() {
    long long n, m, k;
    cin >> n >> m >> k;

    long long C = m + 1;       // Cost limit
    long long A = k - 1;       // Max limit for left side (L)
    long long B = n - k;       // Max limit for right side (R)

    long long max_fortified = 0;

    // Iterate over all possible left expansions
    for (long long L = 0; L <= A; ++L) {
        
        // Strategy 1: Assume Right sweep is smaller or equal to Left sweep (R <= L)
        // Formula bounds to: 2L + R <= C => R <= C - 2L
        long long R1 = -1;
        if (C >= 2 * L) {
            R1 = min(B, min(L, C - 2 * L));
        }

        // Strategy 2: Assume Right sweep is strictly strictly larger (R >= L)
        // Formula bounds to: 2R + L <= C => 2R <= C - L => R <= (C - L) / 2
        long long R2 = -1;
        if (C >= L) {
            long long max_R = (C - L) / 2;
            if (max_R >= L) {
                R2 = min(B, max_R);
            }
        }

        // Take the best valid right-side configuration for the current 'L'
        long long R = max(R1, R2);
        if (R != -1) {
            max_fortified = max(max_fortified, L + R + 1);
        }
    }

    cout << max_fortified << "\n";
}

int main() {
    // Optimize standard I/O operations for performance
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int t;
    if (cin >> t) {
        while (t--) {
            solve();
        }
    }
    return 0;
}