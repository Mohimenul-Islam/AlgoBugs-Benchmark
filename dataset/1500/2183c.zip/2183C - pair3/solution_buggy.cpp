#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
void solve()
{
    ll n,m,k;
    cin >> n >> m >> k;
    ll left = min(n-k,k-1);
    ll right = max(n-k,k-1);
    
    ll val = left+2*right-1;
    if(m>=val){
        cout << n << endl;
        return;
    }
    else{
        ll maxi = min((m+1)/2,right)+1;
        for(ll i=1;i<=left;i++){
            ll day = m-(2*i-1);
            
            ll r = min((day+i)/2,right);
            maxi  = max(i+r+1,maxi);
        }
        cout << maxi <<endl;
        return;
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    ll t;
    cin >> t;
    while (t--)
    {
        solve();
    }
}