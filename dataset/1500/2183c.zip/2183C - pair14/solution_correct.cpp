#include<bits/stdc++.h>
 
using namespace std;
 
#define _ ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
typedef long long int ll;
typedef pair<int,int> pii;
 
ll n,m,k;
int t;

int main(){  _ 
	
	cin >> t;

	while(t--){
		cin >> n >> m >> k;
		
		ll nl = k-1;
		ll nr = n-k;

		ll ans = 1;
		
		for(int i=1;i<=nl;i++){
			ll ml = m -  (i + (i-1));
			if(ml < 0) break;
			ll j = (ml + i) / 2;
			j = min(nr,j);
			j = min(ml,j);
			ans = max(ans, i+j+1);
		}
		for(int i=1;i<=nr;i++){
			ll ml = m -  (i + (i-1));
			if(ml < 0) break;
			ll j = (ml + i) / 2;
			j = min(nl,j);
			j = min(ml,j);
			ans = max(ans, i+j+1);
		}

		cout << min(ans,n) << "\n";
	
	}
}


