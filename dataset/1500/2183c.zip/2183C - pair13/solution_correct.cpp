#include <bits/stdc++.h>
using namespace std;

int main(){
    int round;
    cin >> round;
    for(int p = 0; p < round; p++){
        int n;
        int m;
        int k;
        cin >> n >> m >> k;

        int day = 0;
        int count = 0;
        
        int minReach = min(k - 1, n - k);
        if(minReach * 3 - 1 >= m){
            for(int i = 0; i <= minReach; i++){
                if(i*3 - 1 <= m){
                    count = 2 * i + 1;
                }
                else{
                    if((i-1)*3 + 1 <= m){
                        count++;
                    }
                }
            }
        }
        else{
            int extend = minReach + 1;
            day = max(0, minReach*3 - 1);
            count = 2 * minReach + 1;
            while(k - extend >= 1){
                int oldCount = count;
                if(extend == 1) {
                    if(day + 1 <= m){
                        count++;
                        day++;
                    }
                }
                else{
                    if(day + 2 <= m){
                        count++;
                        day += 2;
                    }
                }
                if(count == oldCount) break;
                extend++;
            }

            while(k + extend <= n){
                int oldCount = count;
                if(extend == 1) {
                    if(day + 1 <= m){
                        count++;
                        day++;
                    }
                }
                else{
                    if(day + 2 <= m){
                        count++;
                        day += 2;
                    }
                }
                if(count == oldCount) break;
                extend++;
            }
        }
        
        cout << count << "\n";
    }
}