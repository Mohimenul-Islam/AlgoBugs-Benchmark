#include <bits/stdc++.h>
using namespace std;
#define ull unsigned long long
#define int long long
#define INT_MAX LLONG_MAX
#define INT_MIN LLONG_MIN
#define ll long long
#define F first
#define S second
#define vi vector<int>
#define pii pair<int, int>
#define getset __builtin_popcountll
#define vec vector
#define input(a)                       \
    for (int i = 0;i<a.size(); i++) \
    cin >> a[i]
#define print(a)     \
    for (int i=0;i<a.size();i++) \
    cout << a[i] << ' '
#define all(a) a.begin(), a.end()
int fact[100];
vi build_spf(int n)
{
    vector<long long> spf(n + 1, -1);
    spf[0] = 0;
    spf[1] = 1;
    for (ll i = 2; i <= n; i++)
    {
        if (spf[i] == -1)
        {
            for (ll j = i; j <= n; j += i)
                if (spf[j] == -1)
                    spf[j] = i;
        }
    }
    return spf;
}
vector<long long> prime_factorization(long long n, vi &spf)
{
    vector<long long> pf;
    while (n > 1)
    {
        pf.push_back(spf[n]);
        n /= spf[n];
    }
    return pf;
}
long long gcd_by_mod(long long a, long long b)
{
    if (b == 0)
        return a;
    return gcd_by_mod(b, a % b);
}
long long gcd_by_subs(long long a, long long b)
{
    if (b == 0)
        return a;
    if (a < b)
        swap(a, b);
    return gcd_by_subs(b, a - b);
}
long long lcm(long long a, long long b)
{
    long long prod = (a * b);
    long long hcf = gcd_by_mod(a, b);
    return prod / hcf;
}
long long mod_add(long long a, long long b, ll m) { return ((a % m) + (b % m)) % m; }
ll mod_subs(ll a, ll b, ll m) { return ((a % m) - (b % m) + m) % m; }
ll mod_mul(ll a, ll b, ll m) { return ((a % m) * (b % m)) % m; }
ll mod_expo(ll a, ll b, ll m)
{
    if (b == 0)
        return 1;
    ll res = mod_expo(a, b / 2, m);
    res = mod_mul(res, res, m);
    if (b & 1)
        res = mod_mul(res, a, m);
    return res;
}
ll mod_inv(ll a, ll m) { return mod_expo(a, m - 2, m); }
ll mod_div(ll a, ll b, ll m) { return mod_mul(a, mod_inv(b, m), m); }
ll nCr(ll n, ll r, ll m) { return mod_div(fact[n], mod_mul(fact[r], fact[n - r], m), m); }
class DSU
{
    vector<int> parent, size;

public:
    DSU(int n)
    {
        parent.resize(n);
        iota(parent.begin(), parent.end(), 0);
        size.resize(n, 1);
    }
    void unite(int u, int v)
    {
        int upu = findP(u), upv = findP(v);
        if (upu == upv)
            return;
        if (size[upu] > size[upv])
        {
            parent[upv] = upu;
            size[upu] += size[upv];
        }
        else
        {
            parent[upu] = upv;
            size[upv] += size[upu];
        }
    }
    int findP(int u)
    {
        if (u == parent[u])
            return u;
        return parent[u] = findP(parent[u]);
    }
};

// void f(int lvl,vector<int>&par, map<int,set<int>>&m,int lk)
// {
//     if(m.empty() || lvl>m.rbegin()->first)return ; 
//     if(!m.count(lvl))
//     {
//         f(lvl+1, par,m,lk); 
//         return; 
//     }
//     set<int>&st=m[lvl]; 
//     auto it=st.begin() ;
//     for(; it!=st.end(); it++)
//     {
//         if(par[*it]!=lk)
//         {
//             break; 
//         }
//     }
//     if(it!=st.end())
//     {
//         int ck=*it; 
//         st.erase(it); 
//         if(st.empty())m.erase(lvl); 
//         lk=ck; 
//     }
//     f(lvl+1, par,m,lk); 
// }

int bs(vector<int>&price, int s,int e,int tar,int x)
{
    //s=1, e=k-1 
    //decreasing hain
    int res=-1; 
    while(s<=e)
    {
        int md=s+(e-s)/2; 
        int t; 
        if(price[md]>1){
        int d= ((price[md]+1)/2); 
        t=max(1LL,d-x)+(d-1);}
        else t= 1; 
        //cout<<md<<' '<<t<<'\n'; 
        if(t<=tar)
        {
            res=md; 
            e=md-1; 
        }
        else s=md+1; 
    }
    return res; 
}

int bss(vector<int>&price,int s,int e,int tar,int x)
{
    int res=-1; 
    while(s<=e)
    {
        int md=s+(e-s)/2;
        int t; 
        if(price[md]>1){
        int d= ((price[md]+1)/2); 
        t=max(1LL,d-x)+(d-1);}
        else t= 1; 
        if(t<=tar)
        {
            res=md;
            s=md+1; 
        }
        else e=md-1; 
    }
    return res; 
}

void solve(int ii,int tt)
{
    int n,m,k;
    cin>>n>>m>>k;
    // if(ii==292)
    // {
    //     string s = ""; 
    //     s+= to_string(n)+"$"+to_string(m)+"$"+to_string(k); 
    //     cout<<s<<'\n'; 
    //     return; 
    // }
    vi price(n+1); 
    price[k]=0; 
    for(int i=k-1;i>=1;i--)
    {
        int d=k-i; 
        price[i]=d*2-1; 
    }
    for(int i=k+1; i<=n;i++)
    {
        int d=i-k;
        price[i]=d*2-1; 
    }
    // cout<<"Price: \n" ;
    // for(int i=1;i<=n;i++)cout<<price[i]<<' '; 
    // cout<<'\n'; 
    int res=0;
    int ls=k-1;
    int rs=n-k;
//m-=5;
        for(int i=k;i<=n;i++)
        {
                int d=i-k; 
                int x=price[i]; 
            if(x>m)break; 
            // if(x==m)
            // {
            //     res=max(res,i-k+1);
            //     continue; 
            // }
            //cout<<"x:"<<x<<'\n'; 
                int li=bs(price,1,k-1,m-x,max(0LL,d-1)); 
                if(li==-1)li=k;
            int z= k-li + i-k + 1; 
                res=max(res,z); 
            //cout<<li<<' '<<i<<' '<<z<<'\n'; 
        }
    //cout<<"\n\n"; 
        for(int i=k;i>0;i--)
        {
          int d=k-i; 
          int x=price[i]; 
            if(x>m)break; 
            // if(x==m){
            //     res=max(res,k-i+1); 
            //     continue; 
            // }
            //cout<<d<<' '<<x<<'\n'; 
          int ri=bss(price,k+1,n,m-x,max(0LL,d-1));
          if(ri==-1)ri=k; 
            int z = ri-k+ k - i + 1;
            res=max(res,z); 
            //cout<<i<<' '<<ri<<' '<<z<<'\n'; 
        }
    
    cout<<res<<'\n'; 
}
int32_t main()
{
    // ios_base::sync_with_stdio(0);
    // cin.tie(0);
    // cout.tie(0);
    int t = 1;
    cin >> t;
    // if(primes.size()=0)
    //     sieve(10000000); 
    for(int i=1;i<=t;i++)
        solve(i,t);
    return 0;
}