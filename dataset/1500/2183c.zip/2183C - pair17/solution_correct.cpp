#include<bits/stdc++.h>
using namespace std;
using ll=long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    ll z;
    cin >> z;
    while (z--) {
        ll n,m,k;
        cin >> n >> m >> k;

        ll ans=0;

        if (k==1 || k==n) {
            ans=min(n,(m+1)/2+1);
        }
        else {
            ll s=min(k-1,n-k);

            if (m<=3*s-1) {
                ans=min(n,(2*(m+1))/3+1);
            }
            else {
                ans=min(n,(m+s+1)/2+1);
            }
        }

        cout << ans << '\n';
    }
}