#include<bits/stdc++.h>
using namespace std;
using ll=long long;
int main() {
    ll z;
    cin >> z;
    while (z--) {
        ll n,m,k;
        cin >> n >> m >> k;
        ll t=max(n-k,k-1);
        ll ans=0;
        if (k!=1 && k!=n){
            if (m>=2*t) {
                m=m-2*t+1;
                ans+=t;
                ans=ans+min(m,min(n-k,k-1));
                ans++;
                ans=min(ans,n);
            }
            else {
                ll s=min(n-k,k-1);
                ans=min(n,(2*(m+1))/3+1);
            }
        }
        else {
            if (m%2==0) {
                ans=min(n,m/2+1);
            }
            else {
                ans=min(n,m/2+2);
            }
        }
        cout << ans << '\n';
    }
}