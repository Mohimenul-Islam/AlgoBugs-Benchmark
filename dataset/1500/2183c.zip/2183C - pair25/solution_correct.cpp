#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ull = unsigned long long;
using ld = long double;
using pii = pair<int, int>;
using vi = vector<int>;
using vll = vector<ll>;

// I/O overloads for ranges (vector, array, ...) and tuple-likes (pair, tuple).
// Excludes strings to avoid conflicting with existing overloads.
template <typename T>
concept MultiIOable = !is_convertible_v<decay_t<T>, string> &&
                      (ranges::range<T> || requires { tuple_size<decay_t<T>>::value; });

template <MultiIOable T> istream& operator>>(istream& is, T& v) {
    if constexpr (ranges::range<T>)
        for (auto& x : v) is >> x;
    else // tuple-like: unpack all elements
        apply([&](auto&... x) { ((is >> x), ...); }, v);
    return is;
}

template <MultiIOable T> ostream& operator<<(ostream& os, T const& v) {
    if constexpr (ranges::range<T>)
        for (auto const& x : v) os << x << ' ';
    else // tuple-like: unpack all elements
        apply([&](auto const&... x) { ((os << x << ' '), ...); }, v);
    return os;
}

// Prints variable name and value to stderr. Only active when compiled with -DLOCAL.
#ifdef LOCAL
#define debug(x) cerr << "[" << #x << "] = " << (x) << '\n'
#else
#define debug(x)
#endif

const int INF = 1e9 + 5;
const ll INFLL = 1e18 + 5;

void solveCase() {
    int n, m, k;
    cin >> n >> m >> k;

    if (n == 1) {
        cout << 1 << endl;
        return;
    }

    int mx = max(k - 1, n - k);
    int mn = min(k - 1, n - k);

    int best = (mx * 2 - 1) + mn;
    int diff = best - m;

    while (best > m) {
        // alt 1: decrease mx
        int a1 = INF;
        if (mx > mn) a1 = ((mx - 1) * 2 - 1) + mn;

        // alt 2: decrease mn
        int a2 = INF;
        if (mn > 0) a2 = (mx * 2 - 1) + (mn - 1);

        // debug(mn + mx + 1);
        // debug(a1);
        // debug(a2);

        if (a1 < a2) {
            mx--;
            best = a1;
        } else {
            mn--;
            best = a2;
        }
    }

    // debug(mx);
    // debug(mn);
    // debug(best);

    cout << mx + mn + 1 << endl;
}

int main() {
    // note: don't mix with scanf/printf
    ios::sync_with_stdio(0), cin.tie(0);
    cin.exceptions(cin.failbit);

    int tc;
    cin >> tc;
    for (int cs = 1; cs <= tc; cs++) {
        solveCase();
    }
    return 0;
}
