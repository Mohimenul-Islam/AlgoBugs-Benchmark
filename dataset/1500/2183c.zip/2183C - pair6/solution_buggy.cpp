#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int t; cin >> t;
    while (t--)
    {
        int n, m, k;
        cin >> n >> m >> k;
        int L = k - 1, R = n - k;
        int a = 0, b = 0;
        while (1)
        {
            if (b < R && a + b + 1 + max(a, b+1) - 1 <= m) b++;
            else if (a < L && a + 1 + b + max(a+1, b) - 1 <= m) a++;
            else break;
        }
        cout << a + b + 1 << '\n';
    }
    return 0;
}