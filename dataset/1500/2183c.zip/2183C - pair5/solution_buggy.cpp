// #pragma GCC optimize("O3, unroll-loops")
// #pragma GCC target("avx")
#include<iostream>
#include<string>
#include<vector>
#include<set>
#include<algorithm>
#include <map>
#include<queue>
#include<stack>
#include<random>
#include<iomanip>
#include <regex>
#include<cstring>
#include<fstream>
#include <math.h>

using namespace std;

typedef long long ll;
typedef long double ld;

#define all(x) x.begin(),x.end()
#define rall(x) x.rbegin(), x.rend()
#define int long long

constexpr int mod = 998244353,
        logn = 20,
        inf = 1e9L + 1
        , maxn = 5e3L + 1
        , maxm = 5e3L + 1;
;

void solve() {
    int n, m, k;
    cin >> n >> m >> k;
    --k;
    if (m >= 5 * n) {
        cout << n;
        return;
    }
    int ans = 1;
    for (int lef = 0; lef <= min(m, k); ++lef) {
        if (lef == 0) {
            int l = 0, r = n - k + 1;
            while (r - l > 1) {
                int mid = l + (r - l) / 2;
                if (max(0ll, mid - lef - 1) + mid <= m) l = mid;
                else r = mid;
            }
            ans = max(ans, l + 1 + lef);
            continue;
        }
        int left_time = m - 2 * lef + 1;
        if (left_time < 0) break;
        int l = 0, r = n - k + 1;
        while (r - l > 1) {
            int mid = l + (r - l) / 2;
            if (max(0ll, mid - lef) + mid <= left_time) l = mid;
            else r = mid;
        }
        ans = max(ans, l + 1 + lef);
    }
    for (int l = 0; l <= k; ++l) {
        int lx = k, rx = n;
        while (rx - lx > 1) {
            int mid = lx + (rx - lx) / 2;
            if (m < lx - l) rx = mid;
            int left_time = m - max((mid - 2 * k + l - 1), 0ll);
            if (left_time <= 2 * l + mid - 3 * k) lx = mid;
            else rx = mid;
        }
        int left_time = m - max((lx - 2 * k + l - 1), 0ll);
        if (left_time <= 2 * l + lx - 3 * k) ans = max(ans, lx - l + 1);
    }
    cout << min(ans, n);
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int test_case = 1;
    cin >> test_case;
    while (test_case--) {
        solve();
        cout << '\n';
    }
    return 0;
}
