// #pragma GCC optimize("O3, unroll-loops")
// #pragma GCC target("avx")
#include<iostream>
#include<string>
#include<vector>
#include<set>
#include<algorithm>
#include <map>
#include<queue>
#include<stack>
#include<random>
#include<iomanip>
#include <regex>
#include<cstring>
#include<fstream>
#include <math.h>

using namespace std;

typedef long long ll;
typedef long double ld;

#define all(x) x.begin(),x.end()
#define rall(x) x.rbegin(), x.rend()
#define int long long

constexpr int mod = 998244353,
        logn = 20,
        inf = 1e9L + 1
        , maxn = 5e3L + 1
        , maxm = 5e3L + 1;
;

void solve() {
    int n, m, k;
    cin >> n >> m >> k;
    --k;
    int ans = 1;
    for (int lef = 0; lef <= k; ++lef) {
        int l = k, r = n;
        while (r - l != 1) {
            int mid = l + (r - l) / 2;
            bool f = false;
            {
                int left_time = min(m - 2 * (k - lef) + 1, m);
                if (left_time >= max(0ll, mid - k - k + lef) + mid - k && left_time >= 0) f = true;
            }
            {
                int left_time = min(m - 2 * (mid - k) + 1, m);
                if (left_time >= max(0ll, k - lef - mid + k) + k - lef && left_time >= 0) f = true;
            }
            if (f) l = mid;
            else r = mid;
        }
        bool f = false;
        {
            int left_time = min(m - 2 * (k - lef) + 1, m);
            if (left_time >= max(0ll, l - k - k + lef) + l - k && left_time >= 0) f = true;
        }
        {
            int left_time = min(m - 2 * (l - k) + 1, m);
            if (left_time >= max(0ll, k - lef - l + k) + k - lef && left_time >= 0) f = true;
        }
        if (f) ans = max(ans, l - lef + 1);
    }
    cout << min(ans, n);
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int test_case = 1;
    cin >> test_case;
    while (test_case--) {
        solve();
        cout << '\n';
    }
    return 0;
}
