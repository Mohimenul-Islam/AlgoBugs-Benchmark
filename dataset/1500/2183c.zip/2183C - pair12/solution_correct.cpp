#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <assert.h>
#include <random>
#include <climits>
#include <numeric>
#include <queue>
#include <array>
#define rep(i,s,e) for(int i=(s); i<=(e); i++)
#define ll long long
#define db double
#define int ll
#define i128 __int128_t
#define vi vector<int>
#define pii pair<int,int>
#define pll pair<ll,ll>
#define vii vector<pll>
#define ub(x) upper_bound((x))
#define lb(x) lower_bound((x))
#define bg begin()
#define ed end()
#define arr2 array<int,2>
#define arr3 array<int,3>
using namespace std;

const int LM=500100;
int N,M,k;

int F(int l, int m, int r){
    int L=m-l, R=r-m;
    return min(max(L*2-1, L+R-1)+R, max(R*2-1, L+R-1)+L);
}

void solve(){
    cin>>N>>M>>k;
    if(N*2 < M ){
        cout<<N<<"\n";
        return;
    }
    
    int l=1, r=k, ans=0;
    
    for(; l<=k; l++){
        while(r<N && F(l,k,r+1)<=M) r++;
        if(F(l,k,r)>M) continue;
        ans = max(ans, r-l+1);
        //printf("%d %d\n", l, r);
    }
    cout<<ans<<"\n";
}

signed main(){
    ios_base::sync_with_stdio(0);cin.tie(0);
    int tc;cin>>tc;while(tc--)solve();
}
