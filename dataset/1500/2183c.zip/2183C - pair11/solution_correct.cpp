#include <iostream>
#include <algorithm>
using namespace std;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--) {
        ll n, m, k;
        cin >> n >> m >> k;
        // 对称处理，保证左侧空间 ≥ 右侧空间
        if (k - 1 < n - k) {
            k = n + 1 - k;
        }
        ll a = 0, b = 0;
        ll max_left = k - 1;
        ll max_right = n - k;
        while (true) {
            bool updated = false;
            // 优先扩展右侧
            if (b < max_right) {
                ll new_b = b + 1;
                ll need = a + new_b + max(a, new_b) - 1;
                if (need <= m) {
                    b = new_b;
                    updated = true;
                }
            }
            // 再扩展左侧
            if (a < max_left) {
                ll new_a = a + 1;
                ll need = new_a + b + max(new_a, b) - 1;
                if (need <= m) {
                    a = new_a;
                    updated = true;
                }
            }
            if (!updated) break;
        }
        cout << a + b + 1 << '\n';
    }
    return 0;
}