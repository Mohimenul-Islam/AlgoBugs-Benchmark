#include <bits/stdc++.h>
using namespace std;
using ll = long long;using i64 = long long;using u32 = unsigned;using u64 = unsigned long long;using ull = unsigned long long;using db = double;using ld = long double;using u128 = unsigned __int128;using ulll = unsigned __int128;using i128 = __int128;using lll = __int128;template <typename T>using pii = pair<T, T>;template <typename T, typename T1>using ppi = pair<T, T1>;template <typename T>using vpii = vector<pair<T, T>>;template <typename T, typename T1>using vppi = vector<pair<T, T1>>;template <typename T>using vi = vector<T>;template <typename T>using vvi = vector<vector<T>>;template <typename T, typename U>using umap = unordered_map<T, U>;template <typename T>using uset = unordered_set<T>;template <typename T>using pqmin = priority_queue<T, vector<T>, greater<T>>;template <typename T>using pqmax = priority_queue<T, vector<T>, less<T>>;template <typename T>using mset = multiset<T>;template <typename T>using umset = unordered_multiset<T>;
#define endl '\n'
#define pb push_back
#define eb emplace_back
#define fi first
#define se second
#define sz(x) (int)x.size()
#define all(a) a.begin(), a.end()
#define alll(a) a.begin() + 1, a.end()
#define rall(a) a.rbegin(), a.rend()
#define rep(i, l, r) for (int i = (l); i <= (r); ++i)
#define per(i, r, l) for (int i = (r); i >= (l); --i)
#define ps(y) cout << fixed << setprecision(y)
#define mem(a, x) memset(a, x, sizeof(a));
#define uniq(x) sort(x.begin(), x.end()), x.erase(unique(x.begin(), x.end()), x.end())
#define popcount(x) __builtin_popcount(x)
#define popcountll(x) __builtin_popcountll(x)
// const long long MOD = 1e9 + 7;
const long long MOD = 998244353;
const long long INF = 0x3f3f3f3f3f3f3f3f, mod = MOD;const long double PI = 3.141592653589793238462643383279502884L, eps = 1e-10;const string yes = "yes", yes1 = "Yes", yes2 = "YES", no = "no", no1 = "No", no2 = "NO";const int dx[] = {-1, 0, 0, 1}, dy[] = {0, -1, 1, 0}, dx1[] = {-1, -1, -1, 0, 1, 0, 1, 1, 0}, dy1[] = {-1, 0, 1, -1, 1, 1, -1, 0, 0}, dx2[] = {-2, -2, -1, -1, 1, 1, 2, 2, 0}, dy2[] = {-1, 1, -2, 2, -2, 2, -1, 1, 0}, inf = 0x3f3f3f3f;
template <typename T>inline bool read(T &x){x = 0;int f = 1;char c = getchar();bool ret = false;while (c < '0' || c > '9'){if (c == '-')f = -1;c = getchar();}while (c <= '9' && c >= '0'){x = (x << 1) + (x << 3) + (c ^ 48);c = getchar();ret = true;}x = x * f;return ret;}
template <typename T, typename... Args>inline bool read(T &a, Args &...args) { return read(a) && read(args...); }
template <typename T, typename Type>inline void print(T x, const Type type){if (x < 0)putchar('-'), x = -x;if (x > 9)print(x / 10, 0);putchar(x % 10 ^ 48);if (type == 1)putchar(' ');else if (type == 2)putchar('\n');}
template <typename T, typename Type, typename... Args>inline void print(T x, const Type type, Args... args){print(x, type);print(args...);}
inline void printstr(const string &s, bool flg = true){for (char c : s){putchar(c);}if (flg){putchar('\n');}}
constexpr long long safemod(long long x, long long m = MOD){x %= m;if (x < 0){x += m;}return x;}
template <typename T>T gcd(T a, T b) { return __gcd(a, b); }
template <typename T>T lcm(T a, T b) { return a / __gcd(a, b) * b; }
string szr(long long n, long long r){if (n == 0)return "0";string s;bool f = n < 0;if (f)n = -n;while (n > 0){long long ans = n % r;s += (ans < 10) ? (char)(ans + '0') : (char)(ans - 10 + 'A');n /= r;}reverse(s.begin(), s.end());return f ? '-' + s : s;}
long long rzs(string s, long long r) { return stoll(s, nullptr, r); }
long long ksm(long long a, long long b, long long mod = MOD){a %= mod;long long s = 1;while (b){if (b & 1)s = (s * a) % mod;a = (a * a) % mod;b >>= 1;}return s;}
long long inv(long long x, long long mod = MOD) { return ksm(x, mod - 2); }
vector<int> olprime(int n){vector<bool> isprime(n + 1, true);vector<int> primes;primes.reserve(n / 4);isprime[0] = isprime[1] = false;for (int i = 2; i <= n; ++i){if (isprime[i])primes.push_back(i);for (auto x : primes){if (i * x > n)break;isprime[i * x] = 0;if (i % x == 0)break;}}return primes;}
vector<int> olprime(int n, vector<int> &mp){vector<bool> isprime(n + 1, true);vector<int> primes;primes.reserve(n / 4);mp.resize(n + 1, 0);isprime[0] = isprime[1] = false;for (int i = 2; i <= n; ++i){if (isprime[i]){primes.push_back(i);mp[i] = i;}for (auto x : primes){if (i * x > n)break;mp[i * x] = mp[x];isprime[i * x] = 0;if (i % x == 0)break;}}return primes;}
/*

*///===================================================================================//
void init() {

}
void solve() {
     ll n, m, k; cin >> n >> m >> k;
     ll l = k - 1, r = n - k;
     if (n == 1 || m == 0) cout << 1;
     else {
        if (l > r) swap(l, r);
        if (l == 0) cout << min((m + 1) / 2 + 1, n);
        else {
            ll ans = 2;
            --l, --m;
            if (m == 1) {
                --r; --m;
                ++ans;
            }
            while (l > 0 && m >= 3 && r > 0) {
                --l; --r;
                m -= 3;
                ans += 2;
            }
            while (l > 0 && m >= 2) {
                --l; m -= 2;
                ans ++;
            }
            while (r > 0 && m >= 2) {
                --r; m -= 2;
                ans ++;
            }
            cout << ans;
        }
     }
     cout << endl;
}
//===================================================================================//
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    init();
    int viiiix = 1;
    cin >> viiiix;
    while (viiiix--) solve();
}
