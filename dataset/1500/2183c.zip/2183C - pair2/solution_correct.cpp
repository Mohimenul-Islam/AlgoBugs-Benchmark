﻿#include <iostream>
#include <algorithm>
using namespace std;
using ll = long long;

void solve() {
    ll n, m, k;
    cin >> n >> m >> k;

    if (k - 1 < n - k) {
        k = n + 1 - k;  // 对称化
    }

    ll left_max = k - 1;
    ll right_max = n - k;

    // 二分查找最优的a
    ll ans = 0;
    ll l = 0, r = min(left_max, right_max);

    // 先尝试对称扩展
    while (l <= r) {
        ll mid = (l + r) / 2;
        if (mid + mid + mid - 1 <= m) {  // 对称扩展mid格
            ans = 2 * mid + 1;
            l = mid + 1;
        }
        else {
            r = mid - 1;
        }
    }

    // 尝试不对称扩展
    for (ll a = 0; a <= left_max; a++) {
        // 计算对应的最大b
        ll max_b = min(right_max, m - a - max(a, 0ll) + 1);
        if (a + max_b + max(a, max_b) - 1 <= m) {
            ans = max(ans, a + max_b + 1);
        }
    }

    cout << min(ans, n) << "\n";
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);

    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}