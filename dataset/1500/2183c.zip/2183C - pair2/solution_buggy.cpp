﻿#include <iostream>
#include <algorithm>
using namespace std;

typedef long long ll;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--) {
        ll n, m, k;
        cin >> n >> m >> k;

        // 对称化处理：让k更靠近左边
        if (k - 1 < n - k) {
            k = n + 1 - k;
        }

        ll a = 0, b = 0;  // a向左扩展的格子数，b向右扩展的格子数

        while (true) {
            // 尝试向右扩展
            if (b < n - k && a + (b + 1) + max(a, b + 1) - 1 <= m) {
                b++;
                continue;
            }
            // 尝试向左扩展
            if (a < k - 1 && (a + 1) + b + max(a + 1, b) - 1 <= m) {
                a++;
                continue;
            }
            break;  // 都不能扩展
        }

        cout << a + b + 1 << "\n";
    }

    return 0;
}