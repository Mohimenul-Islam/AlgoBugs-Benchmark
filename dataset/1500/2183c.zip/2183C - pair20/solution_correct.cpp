#include <bits/stdc++.h>
using namespace std;
#define int long long

void solve(){
    int n,m,k;
    cin>>n>>m>>k;
    int mx=max(k-1,n-k);
    int mn=n-mx-1;
    int p=min(mx,(m+1)/2);
    int l=min(mn,m+1-2*p);
    int ans=l+p+1;
    int r=min(mn,(m+1)/2)+1,mid;
    while(r-l>1){
        mid=(l+(r-l)/2);
        int temp=((m+1)-mid)/2;
        if(temp<mid){
            r=mid;
        }
        else{
            l=mid;
            ans=temp+l+1;
        }
    }
    cout<<ans<<"\n";
}
int32_t main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin>>t;
    while(t--){
         solve();
    }
}