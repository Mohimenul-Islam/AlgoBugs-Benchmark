#include <iostream>
using namespace std;

int main(){
    int t;
    cin >>t;
    while(t>0){
        int n,m,k;
        cin >>n;
        cin >>m;
        cin >>k;
        if(k-1< n-k)  k = n-k+1;
        int a=0 , b =0;
        while(1){
            if(a+1+b+max(a,b+1)-1 <= m && b<n-k) b=b+1;
            else if(a+1+b+max(a+1,b) -1 <=m && a <k-1) a=a+1;
            else break;
        }
        cout << a+b+1 <<endl;
        t--;
    }
}