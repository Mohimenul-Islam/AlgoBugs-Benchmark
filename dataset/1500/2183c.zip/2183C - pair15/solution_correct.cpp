#include <bits/stdc++.h>
using namespace std;

#define int long long
#define mod 1000000007
int n, m, k, p;
int a[200005];
int b[200005];
void solve()
{
    cin >> n >> m >> k;
    if ((k << 1) > n)
    {
        k = n - k + 1;
    }
    if (m % 3 == 1)
    {
        if ((m + 2) / 3 - 1 < k)
        {
            cout << min((m + 2) / 3 << 1, n) << endl;
            return;
        }
    }
    else
    {
        if ((m + 2) / 3 < k)
        {
            cout << ((m + 2) / 3 << 1) + 1 << endl;
            return;
        }
    }
    cout << min(k + (m - k + 2 >> 1), n) << endl;
}
signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
}