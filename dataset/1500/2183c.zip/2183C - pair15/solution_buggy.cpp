#include <bits/stdc++.h>
using namespace std;

#define int long long
#define mod 1000000007
int n, m, k, p;
int a[200005];
int b[200005];
void solve()
{
    cin >> n >> m >> k;
    int l = k - 1;
    int r = n - k;
    int ans = 0;
    int t = m;
    if(m<=2*l-1)
    {
        ans = (m + 1) / 2;
        ans++;
    }
    else
    {
        ans = l + 1;
        m = m - 2 * l + 1;
        if (m <= 2 * r - l)
        {
            ans += (m + l) / 2;
        }
        else
        {
            ans = n;
        }
    }
    int h = ans;
    m = t;
    swap(l, r);
    if (m <= 2 * l - 1)
    {
        ans = (m + 1) / 2;
        ans++;
    }
    else
    {
        ans = l + 1;
        m = m - 2 * l + 1;
        if (m <= 2 * r - l)
        {
            ans += (m + l) / 2;
        }
        else
        {
            ans = n;
        }
    }
    h = max(ans, h);
    cout << h << endl;
}
signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
}