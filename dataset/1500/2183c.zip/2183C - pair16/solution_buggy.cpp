#include<bits/stdc++.h>
using namespace std ;

bool isPossible(int fort,int &n,int &m,int &k){
    int x= fort-1;
    int left= min(k-1,(x+1)/2);
    int right= x-left;
    
    //right simulation
    int temp=0;
    
    if(right>0){
       temp+= right;
       temp+= (right-1);
    }
    
    if(left>0){
        int rc= max(1,right);
        int more= max(0,left-rc);
        
        temp+= (more+1);
        temp+= (left-1);
    }
   
    
    
    
    
   
    
    return temp<= m;
}
int main(){
    int t ;
    cin>>t;
    
    while(t--){
        int n ,m , k;
        cin>>n>>m>>k;
        
        int low= 1;
        int high= n;
        int ans =1;
        while(low<=high){
            int mid= low+(high-low)/2;
            if(isPossible(mid,n,m,k)){
                ans= mid;
                low=mid+1;
            }
            else{
                high= mid-1;
            }
        }
        
        cout<<ans<<endl;
    }
}