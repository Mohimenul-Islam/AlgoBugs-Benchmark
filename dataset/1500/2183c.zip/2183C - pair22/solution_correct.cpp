//             ⢀⣀⣀⣀⣀⡀⠀ ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    
//⠀⠀⠀⠀⠀⠀⠀⠀⣠⣴⣾⣿⣿⣿⣿⣿⣿⣿⣿⣶⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡅⠀⠀ ⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣹⣣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⣀⣀⣤⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣄⠀⠀⠀⠀⠀
//⠀⠀⢰⣾⣿⣿⣿⣿⣿⠿⠟⠛⠛⠉⠉⠉⠉⠉⠙⠛⢻⣿⣿⣿⣿⡿⠋⠀⠀⠀⠀⠀
//⠀⠀⠈⠻⣿⣿⣿⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⢘⣸⡿⠛⠉⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⠁⠑⠒⠀⢄⠂⠭⣿⠛⠣⠒⣯⡯⠭⣝⡏⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⠀⠰⠀⠀⠀⠀⠀⠀⢠⠁⠀⣽⡷⡀⠈⠡⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀⠈⠉⠁⢀⣀⠀⣨⣷⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣄⣴⣶⣮⣿⣿⡧⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⠀⢀⣠⡆⠀⠀⢸⡿⠉⠉⣋⣉⣿⣿⡂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⢀⣿⣿⡇⠀⠀⣿⣿⣜⣿⣿⣿⣿⣿⢠⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⢀⣠⣴⣿⣿⣿⣿⣆⠀⠘⠿⣿⣿⣿⣿⢿⠋⣾⡧⢦⡀⠀⠀⠀⠀⠀⠀⠀⠀
//⣶⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⣨⣽⣻⣿⠋⢠⣿⣿⢼⣿⣶⣶⣠⢀⠀⠀⠀⠀
//⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡈⣁⣤⣽⡆⣿⣿⣿⡞⣿⣿⣿⣿⣿⣦⣤⣀⡀
#include <bits/stdc++.h>
using namespace std;

using str = string;
using ll  = long long;
using ull = unsigned long long;
using ld  = long double;
using pii = pair<int,int>;
using pll = pair<ll,ll>;

using vi  = vector<int>;
using vll = vector<ll>;
using vpi = vector<pii>;
using vpl = vector<pll>;

// ───────────── CONSTANTS ─────────────
const ll INF  = 1e18;
const int MOD = 1000000007;

// ───────────── MACROS ─────────────
#define pb push_back
#define mp make_pair
#define fi first
#define se second


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    // Ready....................
// ⚠️ IMPORTANT:
// Always handle the LAST segment after the loop!
    ll t;
    cin>>t;
    while(t--){

    ll n,m,k; cin>>n>>m>>k;
    ll ans = 1;
    if(k==1 or k==n){
        if(m >= (2*n-1)){
            cout<<n<<endl;
        }
        else {
           ll tdays = 2*n-1;
           ll dif = tdays - m;
           ll tdif = (dif/2)+(dif%2);
           cout<<n+1- tdif<<endl;
            }
            
        
        continue;
    }
    ll tdays = n-2 + max(n-k+1,k-1);
    if(m<=2){
        cout<<m+1<<endl;
        continue;
    }
    ll p = min(n-k,k-1);
    ll d = 3*p-1;
    if(m<= d){
        ll z = (m+1)/3;
        ll zz = (m+1-z)/2;
        cout<<z+zz+1<<endl;

    }
    else {
        ll xx = 2*p+1;
        ll yy = m-d;
        ll mb = xx+(yy/2);
        cout<<min(n,mb)<<endl;
    }

   }
    return 0;
}