//             ⢀⣀⣀⣀⣀⡀⠀ ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    
//⠀⠀⠀⠀⠀⠀⠀⠀⣠⣴⣾⣿⣿⣿⣿⣿⣿⣿⣿⣶⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡅⠀⠀ ⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣹⣣⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⣀⣀⣤⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣄⠀⠀⠀⠀⠀
//⠀⠀⢰⣾⣿⣿⣿⣿⣿⠿⠟⠛⠛⠉⠉⠉⠉⠉⠙⠛⢻⣿⣿⣿⣿⡿⠋⠀⠀⠀⠀⠀
//⠀⠀⠈⠻⣿⣿⣿⡟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⢘⣸⡿⠛⠉⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⠁⠑⠒⠀⢄⠂⠭⣿⠛⠣⠒⣯⡯⠭⣝⡏⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⠀⠰⠀⠀⠀⠀⠀⠀⢠⠁⠀⣽⡷⡀⠈⠡⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀⠈⠉⠁⢀⣀⠀⣨⣷⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣄⣴⣶⣮⣿⣿⡧⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⠀⢀⣠⡆⠀⠀⢸⡿⠉⠉⣋⣉⣿⣿⡂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⠀⠀⠀⢀⣿⣿⡇⠀⠀⣿⣿⣜⣿⣿⣿⣿⣿⢠⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
//⠀⠀⠀⢀⣠⣴⣿⣿⣿⣿⣆⠀⠘⠿⣿⣿⣿⣿⢿⠋⣾⡧⢦⡀⠀⠀⠀⠀⠀⠀⠀⠀
//⣶⣶⣾⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⣨⣽⣻⣿⠋⢠⣿⣿⢼⣿⣶⣶⣠⢀⠀⠀⠀⠀
//⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡈⣁⣤⣽⡆⣿⣿⣿⡞⣿⣿⣿⣿⣿⣦⣤⣀⡀
#include <bits/stdc++.h>
using namespace std;

using str = string;
using ll  = long long;
using ull = unsigned long long;
using ld  = long double;
using pii = pair<int,int>;
using pll = pair<ll,ll>;

using vi  = vector<int>;
using vll = vector<ll>;
using vpi = vector<pii>;
using vpl = vector<pll>;

// ───────────── CONSTANTS ─────────────
const ll INF  = 1e18;
const int MOD = 1000000007;

// ───────────── MACROS ─────────────
#define pb push_back
#define mp make_pair
#define fi first
#define se second


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    // Ready....................
// ⚠️ IMPORTANT:
// Always handle the LAST segment after the loop!
    ll t;
    cin>>t;
    while(t--){

    ll n,m,k; cin>>n>>m>>k;
    ll ans = 1;
    if(k==1 or k==n){
        if(m >= (2*n-1)){
            cout<<n<<endl;
        }
        else {
            if(m==1){
                cout<<"2"<<endl;
            }
            else {

                    ll b = m/2;
                    cout<<b+1<<endl;
            }   
            
        }
        continue;
    }
    for(ll i=0; i<= min(n,m); i++){
        ll in = i+1;
        ll check = m-2*i-1;
        ll a = i + 2 + min(in,check);
        if(check >= 0){
            ans = max(ans,a);
        }
        else break;
    }
    cout<<ans<<endl;

   }
    return 0;
}