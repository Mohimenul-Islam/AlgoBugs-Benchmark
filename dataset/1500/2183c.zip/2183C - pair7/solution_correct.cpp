#include <bits/stdc++.h>
using namespace std;
using ll = long long;


void solve(){
    ll n, m, k;
    cin >> n >> m >> k;
    vector<ll> a(n);
    for(ll i=0; i<n; i++){
        a[i] = abs(i+1 - k);
    }
    sort(a.begin(), a.end());
    ll mini = min(k-1, n-k);
    ll maxi = max(k-1, n-k);
    ll ans = 1;
    for(ll i=1; i<=maxi; i++){
        ll m2 = m;
        m2 -= i;
        m2 -= i-1;
        if(m2 < 0) break;
        ans = max(ans, i+1+min({mini, m2, i}));
        
    }
    cout << ans << "\n";
}

int main(){
    ll t;
    cin >> t;
    while(t--){
        solve();
    }
}