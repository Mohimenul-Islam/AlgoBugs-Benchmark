#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef pair<int, int> pii;

#define pb push_back
#define all(x) (x).begin(), (x).end()
#define sz(x) ((int)(x).size())
#define ff first
#define ss second

const int N = 200009;
vector<int> arr[N];

ll gcd(ll a, ll b) {
    return b == 0 ? a : gcd(b, a % b);
}

void solve() {
    int n; cin >> n;
    vi a(n); for (int i=0; i<n; i++) cin >> a[i];
    vi b(n); for (int i=0; i<n; i++) cin >> b[i];
    int cnt=0;
    ll ans=LLONG_MAX;
    int minind=0;
    
    for (int i=0; i<n; i++) {
        if (a[i]%2==0) cnt++;
    }
    
    if (cnt>1){
        cout << 0 << endl;
        return;
    } else if (cnt==1){
        for (int i=0; i<n; i++){
            if (b[i]<=b[minind]) minind=i;
        }
        
        if (a[minind]%2!=0){
            ans=b[minind];
        }
    } else{
        int minind2=0;
        
        if (b[1]>b[0]){
            minind=0;
            minind2=1;
        } else {
            minind=1;
        }
        
        for (int i=2; i<n; i++){
            if (b[i]<b[minind]){
                minind2=minind;
                minind=i;
            } else if (b[i]<b[minind2]){
                minind2=i;
            }
        }
        
        ans=b[minind]+b[minind2];
    }
    
    set<int> s;
    
    for (int i=0; i<n; i++){
        if (i==minind) continue;
        for (int j: arr[a[i]]){
            if (s.find(j)!=s.end()){
                cout << 0 << endl;
                return;
            }
            s.insert(j);
        }
    }
    
    auto it = s.begin();
    int d=1;
    
    while (it!=s.end()){
        if (a[minind]%*it==0){
            cout << 0 << endl;
            return;
        }
        
        ans = min(ans, 1LL*(*it*(a[minind]/(*it)+1)-a[minind])*b[minind]);
        it++;
    }
    

    for (int i=0; i<n; i++){
        if (i==minind) continue;
        if (gcd(a[minind], a[i]+1)>1){
            ans=min(ans, 1LL*b[i]);
            continue;
        }
        
        for (int j: arr[a[i]+1]){
            it=s.find(j);
            if (it!=s.end()){ 
                ans=min(ans, 1LL*b[i]);
                break;
            }
        }
        
    }
    
    cout << ans << endl;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    for (int i=2; i<N; i++){
        if (sz(arr[i])) continue;
        for (int j=i; j<N; j+=i){
            arr[j].pb(i);
        }
    }
    
    int t; cin >> t;
    while ((t--)>0){
        solve();
    }

    return 0;
}
