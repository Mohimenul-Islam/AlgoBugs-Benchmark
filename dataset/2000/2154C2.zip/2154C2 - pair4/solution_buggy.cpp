#include<bits/stdc++.h>
using namespace std;
#define M 200005
#define ll long long
#define mod 998244353
#define INF 0x3f3f3f3f3f3f3f3f
#define f first
#define s second
int main(){
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int t;
    cin>>t;
    vector<vector<int>>pr(2*M+1);
    for(int j=2;j<2*M+1;j++){
    	if(!pr[j].empty())continue;
    	for(int i=j;i<2*M+1;i+=j){
    		pr[i].push_back(j);
		}
	}
    while(t--){
    	int n;
    	cin>>n;
    	vector<pair<ll,ll>>ma(n);
    	for(int i=0;i<n;i++){
    		int u;
			cin>>u;
			ma[i].s=u;
		}
		for(int i=0;i<n;i++){
			int u;
			cin>>u;
			ma[i].f=u;
		}
		vector<int>cnt(2*M+1);
		ll ans=INF;
		sort(ma.begin(),ma.end());
		for(int i=0;i<n;i++){
			for(int &x:pr[ma[i].s]){
				if(cnt[x]>0)
				ans=0;
				cnt[x]++;
			}
		}
		if(ans==0){
			cout<<ans<<'\n';
			continue;
		}
		ans=min(ans,ma[0].f+ma[1].f);//two
		int flag=0;
		for(int i=0;i<n;i++){
			for(int &x:pr[ma[i].s])cnt[x]--;
			for(int &x:pr[ma[i].s+1]){
				if(cnt[x]>0){
					ans=min(ans,ma [i].f);
					flag=1;
					break;
				}
			}
			for(int &x:pr[ma[i].s])cnt[x]++;
			if(flag==1)break;
		}//ans=1
		int ind=0;
		ll tmp=INF;
			for(int &x:pr[ma[0].s])cnt[x]--;
			while(ma[0].s+ind<=2*M ){
				for(int &x:pr[ma[0].s+ind]){
					if(cnt[x]>0){
						tmp=ind*ma[0].f;
						break;
					}
				}
				if(tmp!=INF)break;
				ind++;
			}//limitless
		ans=min(ans,tmp);
		cout<<ans<<'\n';
	}
    return 0;
}