// ConsoleApplication3.cpp : This file contains the 'main' function. Program execution begins and ends there.
//


#include <iostream>
#include <string>
#include<stack>
#include <algorithm>
#include <map>
#include <vector>
#include<cmath>
#include<queue>
#include<set>
#include<fstream>
#include <bitset>
#include<iomanip>
#include<numeric>
#include<climits>
#include<unordered_map>
/*#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
typedef long long ll;
using namespace std;
using namespace __gnu_pbds;
template<typename T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;*/

#define ll long long
using namespace std;

ll p(ll n, ll k, ll MOD = (ll)(1e9 + 7LL)) {
    if (n == 0)return 0;
    if (k == 0)return 1;
    ll base = n;
    ll ans = 1;
    while (k > 0) {
        if (k % 2 == 0) {
            base *= base;
            base %= MOD;
            k /= 2;
        }
        else {
            ans *= base;
            ans %= MOD;
            k--;
        }
    }
    return ans;
}

void dfs(vector<vector<char>>&vec,vector<vector<ll>>& vis, ll x,ll y,ll comp) {
        vis[x][y] = comp;
    for (ll i = x - 1; i <= x + 1; i++) {
        for (ll j = y - 1; j <= y + 1; j++) {
            if (i < vec.size() && j < vec[0].size() && i >= 0 && j >= 0) {
                ll dist = abs(i - x) + abs(j - y);
                if (dist == 1) {
                    if (vis[i][j]==0 && vec[i][j] == '#') {
                        dfs(vec, vis, i, j, comp);
                    }
                }
            }
        }
    }
}
struct cmp {
    bool operator()(const pair<int, int>& a, const pair<int, int>& b) const {
        if (a.first == b.first)
            return a.second < b.second;  
        return a.first > b.first;
    }
};



int main() {
    ll t;
    cin >> t;
    vector<vector<ll>>primes((ll)1e5 + 1);
    vector<ll>ch((ll)1e5 + 1, 0);
    for (ll i = 2; i < (ll)1e5; i++) {
        if (ch[i] == 0) {
            primes[i].push_back(i);
            for (ll j = 2 * i; j < (ll)1e5; j += i) {
                ch[j] = 1;
                primes[j].push_back(i);
            }
        }
    }
    while (t--) {
        ll n; cin >> n;
        vector<ll>vec(n);
        for (ll i = 0; i < n; i++)cin >> vec[i];
        vector<ll>cost(n);
        for (ll i = 0; i < n; i++)cin >> cost[i];
        map<ll, ll>mp1, mp2;
        for (ll i = 0; i < n; i++) {
            for (auto div : primes[vec[i]]) {
                mp1[div]++;
            }
        }
        int flag = 0;
        for (auto it : mp1) {
            if (it.second > 1) {
                flag = 1; break;
            }
        }
        if (flag == 1) {
            cout << 0 << endl;
            continue;
        }
        ll mini = INT_MAX;
        for (ll i = 0; i < n; i++) {
            for (auto div : primes[vec[i]]) {
                mp1[div]--;
            }
            for (auto div : primes[vec[i] + 1]) {
                if (mp1[div] > 0) {
                    mini = min(mini, cost[i]);
                }
            }
            for (auto div : primes[vec[i]]) {
                mp1[div]++;
            }
        }
        ll mm = cost[0];
        ll curr = vec[0];
        for (ll i = 0; i < n; i++) {
            if (cost[i] < mm) {
                mm = cost[i];
                curr = vec[i];
            }
        }
        for (auto prime : primes[curr]) {
            mp1[prime]--;
        }
        for (auto div : mp1) {
            if (div.second > 0) {
                ll add = curr % div.first;
                if (add != 0)add = div.first - add;
                mini = min(mini, add * mm);
            }
        }
            sort(cost.begin(), cost.end());
            mini = min(mini, cost[0] + cost[1]);
            cout << mini << endl;
        
    }
    return 0;
}