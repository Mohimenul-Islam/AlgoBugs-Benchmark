# C2. No Cost Too Great (Hard Version)

**Time limit:** 3 seconds
**Memory limit:** 256 megabytes

## Problem Statement

This is the hard version of the problem. The difference between the versions is that in this version, $$$1 \\le b\_i \\le 10^9$$$ for all $$$i$$$ ($$$1 \\le i \\le n$$$). You can hack only if you solved all versions of this problem.

You find yourself with two arrays of positive integers $$$a$$$ and $$$b$$$, both of length $$$n$$$. You will perform the following operation any number of times (possibly none):

*   select an integer $$$i$$$ ($$$1 \\le i \\le n$$$) and increase $$$a\_i$$$ by $$$1$$$. This has a cost of $$$b\_i$$$.

Determine the minimum total cost to make it so that there exists two integers $$$i, j$$$ where $$$1 \\le i \\lt j \\le n$$$ and $$$\\gcd(a\_i, a\_j)$$$$$$^{\\text{∗}}$$$$$$ \\gt 1$$$.

$$$^{\\text{∗}}$$$$$$\\gcd(x, y)$$$ denotes the [greatest common divisor (GCD)](https://en.wikipedia.org/wiki/Greatest_common_divisor) of integers $$$x$$$ and $$$y$$$.

## Input

Each test contains multiple test cases. The first line contains the number of test cases $$$t$$$ ($$$1 \\le t \\le 10^4$$$). The description of the test cases follows.

The first line of each testcase contains an integer $$$n$$$ ($$$2 \\le n \\le 2 \\cdot 10^5$$$) — the length of the array $$$a$$$.

The second line of each testcase contains $$$n$$$ integers $$$a\_1,a\_2,\\ldots,a\_n$$$ ($$$1 \\le a\_i \\le 2 \\cdot 10^5$$$).

The third line of each testcase contains $$$n$$$ integers $$$b\_1,b\_2,\\ldots,b\_n$$$ ($$$\\color{red}{1 \\le b\_i \\le 10^9}$$$).

The sum of $$$n$$$ across all testcases does not exceed $$$2 \\cdot 10^5$$$.

## Output

For each testcase, output the minimum cost.

## Sample Tests

### Input
```
6
2
1 1
1 2
2
4 8
41 67
5
1 1 727 1 1
1 1 1000 1 1
2
3 11
1 1
3
2 7 11
1 6 6
3
2 7 11
100 1 2
```

### Output
```
3
0
2
1
5
1
```

## Note

In the first testcase we can do the following: $$$\[\\color{red}1, 1\] \\xrightarrow{x = 1} \[2, \\color{red}1\] \\xrightarrow{x = 2} \[2, 2\]$$$, this has cost $$$1 + 2 = 3$$$. Now $$$\\gcd(a\_1, a\_2) = \\gcd(2, 2) = 2$$$ and so $$$\\gcd(a\_1, a\_2) \\gt 1$$$. It can be proven that this is the minimum cost required.

In the second testcase it is already true that $$$\\gcd(a\_1, a\_2) = 4$$$ and so $$$\\gcd(a\_1, a\_2) \\gt 1$$$. So no operations are required.