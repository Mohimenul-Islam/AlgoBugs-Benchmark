#include <bits/stdc++.h>
#define int long long
using namespace std;
#define endl '\n'

const int MAXN=2e5+5;

void solve() {
    int n;
    cin>>n;
    vector<int> a(n+1),b(n+1);
    int cnto=0;
    int idx;
    int mi=1e9;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    for(int i=1;i<=n;i++){
        cin>>b[i];
        if(b[i]<mi){
            idx=i;
            mi=b[i];
        }
    }
    vector<bool> vis(MAXN);
    set<int> zz;
    bool isq=false;
    for(int i=1;i<=n;i++){
        int x=a[i];
        for(int j=2;j*j<=x;j++){
            if(x%j==0){
                while(x%j==0){
                    x/=j;
                }
                if(vis[j]){
                    isq=true;
                }
                zz.insert(j);
                vis[j]=true;
            }
        }
        if(isq) break;
        if(x>1){
            if(vis[x]){
                isq=true;
            }
            zz.insert(x);
            vis[x]=true;
        }
    }
    if(isq){
        cout<<0<<endl;
        return;
    }
    int ans=1e9;
    bool ok;
    for(int i=1;i<=n;i++){
        int x=a[i]+1;
        ok=false;
        for(int j=2;j*j<=x;j++){
            if(x%j==0){
                while(x%j==0){
                    x/=j;
                }
                if(vis[j]){
                    ok=true;
                    break;
                }
            }
        }
        if(x>1){
            if(vis[x]){
                ok=true;
            }
        }
        if(ok){
            ans=min(ans,b[i]);
        }
    }
    sort(b.begin()+1,b.end());
    ans=min(ans,b[1]+b[2]);
    for(auto xx:zz){
        if(a[idx]%xx==0) continue;
        int k=xx-a[idx]%xx;
        ans=min(ans,k*b[1]);
    }
    cout<<ans<<endl;
    
    
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t = 1;
    cin>>t;
    while (t--) solve();
    return 0;
}