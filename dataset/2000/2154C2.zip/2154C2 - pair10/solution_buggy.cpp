#include<bits/stdc++.h>

using namespace std;

#define fastio() ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL)
#define MOD 1000000007
#define MOD1 998244353
#define INF 1e18
#define nline "\n"
#define pb push_back
#define ppb pop_back
#define mp make_pair
#define eb emplace_back
#define ff first
#define ss second
#define PI 3.141592653589793238462
#define set_bits __builtin_popcountll
#define sz(x) ((int)(x).size())
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define input(v) for(auto&x:v)cin>>x
#define fo(i,n) for(i=0;i<n;i++)
#define Fo(i,k,n) for(i=k; (k<n ? i<n : i>n); (k<n ? i++ : i--))

typedef long long ll;
typedef unsigned long long ull;
typedef long double lld;
typedef pair<int, int>	pii;
typedef pair<ll, ll>	pl;
typedef vector<int>		vi;
typedef vector<ll>		vl;
typedef vector<pii>		vpii;
typedef vector<pl>		vpl;
typedef vector<vi>		vvi;
typedef vector<vl>		vvl;
// typedef tree<pair<int, int>, null_type, less<pair<int, int>>, rb_tree_tag, tree_order_statistics_node_update > pbds;

#ifndef ONLINE_JUDGE
#define debug(x) cerr << #x <<" "; _print(x); cerr << endl;
#else
#define debug(x)
#endif

void _print(ll t) {cerr << t;}
void _print(int t) {cerr << t;}
void _print(string t) {cerr << t;}
void _print(char t) {cerr << t;}
void _print(lld t) {cerr << t;}
void _print(double t) {cerr << t;}
void _print(ull t) {cerr << t;}

template <class T, class V> void _print(pair <T, V> p);
template <class T> void _print(vector <T> v);
template <class T> void _print(set <T> v);
template <class T, class V> void _print(map <T, V> v);
template <class T> void _print(multiset <T> v);
template <class T, class V> void _print(pair <T, V> p) {cerr << "{"; _print(p.ff); cerr << ","; _print(p.ss); cerr << "}";}
template <class T> void _print(vector <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(set <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(multiset <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T, class V> void _print(map <T, V> v) {cerr << "[ "; for (auto i : v) {_print(i); cerr << " ";} cerr << "]";}

ll N = 4e5 + 1;
vvi pfac(N+1);

void solve(){
    int n; cin >> n;
    vi a(n), b(n);
    input(a); input(b);

    vector<pair<ll, ll>> v(n);
    for(int i = 0; i < n; i++) v[i] = {b[i], a[i]};

    sort(all(v));

    map<ll, ll> cnt;
    ll mn = v[0].ff + v[1].ff;
    for(auto& x : a){
        for(auto& p : pfac[x]){
            if(cnt[p] > 0){
                cout << 0 << endl;
                return;
            }
            cnt[p]++;
        }
    }

    for(auto& [c, x] : v){
        for(auto& p : pfac[x]) cnt[p]--;

        for(auto& p : pfac[x+1]){
            if(cnt[p] > 0) mn = min(mn, c);
        }

        for(auto& p : pfac[x]) cnt[p]++;
    }


    for(auto& p : pfac[v[0].ss]) cnt[p]--;

    for(int i = 1; i < n; i++){
        ll cost = v[0].ff;
        int val = v[0].ss;

        for(int j = val+1; cost < 1LL*(v[0].ff + v[i].ff) && j <= N; j++){
            for(auto& p : pfac[j]){
                if(cnt[p] > 0){
                    mn = min(mn, cost);
                    break;
                }
            }
            cost += v[0].ff;
        }
    }

    cout << mn << endl;
}

int main() {

// #ifndef ONLINE_JUDGE
//     freopen("input.txt", "r", stdin);
//     freopen("error.txt", "w", stderr);
//     freopen("output.txt", "w", stdout);
// #endif

    fastio();
    int t = 1;
    cin >> t;

    // N loglogN
    for(int i = 2; i <= N; i++){
        if(!pfac[i].empty()) continue;
        for(int j = i; j <= N; j += i) pfac[j].pb(i);
    }

    for(int tc = 1; tc <= t; tc++){
        debug(tc);
        solve();
    }
}