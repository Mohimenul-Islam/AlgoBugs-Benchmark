#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define F first
#define S second
#define endl "\n"
#define all(v) v.begin(),v.end()
#define rall(v) v.rbegin(),v.rend()
#define fast ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define no cout<<"NO"<<endl;
#define yes cout<<"YES"<<endl;

template <typename T>
std::ostream& operator<<(std::ostream& out, const std::vector<T>& vec)
{
    if (vec.empty())
    {
        out << "[]";
        return out;
    }
    for (int i = 0; i < vec.size() - 1; i++)
    {
        out << vec[i] << " ";
    }
    return out << vec.back();
}
bool isPalindrome(int num) {
    if (num < 0) return false; //                    Palindrome

    int original = num;
    int reversed = 0;

    while (num != 0) {
        reversed = reversed * 10 + (num % 10);
        num /= 10;
    }

    return original == reversed;
}
string decimalToBinary(long long n) {
    string binary = "";

    while (n > 0) {
        binary += (n % 2) + '0';
        n /= 2;
    }

    reverse(binary.begin(), binary.end());

    while (binary.length() < 64) {
        binary = "0" + binary;
    }

    return binary;
}

// Binary -> Decimal
long long binaryToDecimal(string binary) {
    long long result = 0;

    for (char bit : binary) {
        result = result * 2 + (bit - '0');
    }

    return result;
}
const ll N = 2*1e5 + 5;
ll spf[N]; // ���� ���� ���� ��� ���
// ���� ������ SPF
void build_spf() {
    for (ll i = 0; i < N; i++)
        spf[i] = i;

    for (ll i = 2; i * i < N; i++) {
        if (spf[i] == i) { // i ����
            for (ll j = i * i; j < N; j += i) {
                if (spf[j] == j)
                    spf[j] = i;
            }
        }
    }
}
map<ll,ll> getPrimeFactors(ll x)
{
    map<ll,ll>primes1;
    while(x>1)
    {
        primes1[spf[x]]++;
        x/=spf[x];
    }
    return primes1;
}
set<ll> getPrimeFactors1(ll x) {
    set<ll> primes2;

    while (x > 1) {
        primes2.insert(spf[x]);
        x /= spf[x];
    }

    return primes2;
}
const ll MAXN = 1e6;
const ll mod = 998244353;
const ll MOD = 1e9+7;
ll fac[MAXN + 1];
ll inv[MAXN + 1];
ll exp(ll x, ll n, ll m) {
	x %= m;
	ll res = 1;
	while (n > 0) {
		if (n % 2 == 1) { res = res * x % m;
		 }
		x = x * x % m;
		n /= 2;
	}
	return res;
}
void factorial() {
	fac[0] = 1;
	for (ll i = 1; i <= MAXN; i++) { fac[i] = fac[i - 1] * i % mod; }
}
void inverses() {
	inv[MAXN] = exp(fac[MAXN], mod - 2, mod);
	for (ll i = MAXN; i >= 1; i--) { inv[i - 1] = inv[i] * i % mod; }
}
int sumOfDigits(int num) {
    int sum = 0;

    while (num != 0) {
        sum += num % 10; //
        num /= 10;       //
    }

    return sum;
}
ll modpow(ll a, ll e) {
    ll r = 1;
    while (e) {
        if (e & 1) r = r * a % mod;
        a = a * a % mod;
        e >>= 1;
    }
    return r;
}
ll inv1(ll x) {
    return modpow(x, mod - 2);
}
ll choose(ll n, ll r) { return fac[n] * inv[r] % mod * inv[n - r] % mod; }
long long maxSubArray(const vector<long long>& v) {
    long long current_sum = v[0];
    long long max_sum = v[0];

    for (size_t i = 1; i < v.size(); i++) {
        current_sum = max(v[i], current_sum + v[i]);
        max_sum = max(max_sum, current_sum);
    }

    return max_sum;
}
set<int> generatePrimes(int n) {
    vector<bool> isPrime(n + 1, true);
    set<int> primes;

    isPrime[0] = isPrime[1] = false;

    for (int i = 2; i * i <= n; i++) {
        if (isPrime[i]) {
            for (int j = i * i; j <= n; j += i) {
                isPrime[j] = false;
            }
        }
    }

    for (int i = 2; i <= n; i++) {
        if (isPrime[i]) {
            primes.insert(i);
        }
    }

    return primes;
}
/**
cout<<fixed<<setprecision (9);
*/
//----------|------------------------------
void solve()
{
    ll n;
    cin>>n;
    vector<ll>v,b;
    vector<pair<ll,ll>>v1;
    for(ll i=0;i<n;i++)
    {
        ll x;
        cin>>x;
        v.push_back(x);
    }
    for(ll i=0;i<n;i++)
    {
        ll x;
        cin>>x;
        b.push_back(x);
        v1.push_back({x,v[i]});

    }
    sort(all(v1));
    map<ll,ll>mp;
    ll mn=1e18+7;
    for(ll i=0;i<n;i++)
    {
        ll x=v[i];
        map<ll,ll>mp1=getPrimeFactors(x);
        for(auto j:mp1)
        {
            if(mp[j.F]>0)
            {
                cout<<0<<endl;
                return;
            }
            mp[j.F]+=mp1[j.F];
        }
    }
    mp.clear();
    for(ll i=n-1;i>=0;i--)
    {
        ll x=v[i];
        map<ll,ll>mp1=getPrimeFactors(x);
        for(auto j:mp1)
        {
            if(mp[j.F]>0)
            {
                cout<<0<<endl;
                return;
            }
            mp[j.F]+=mp1[j.F];
        }
    }
    mp.clear();
    for(ll i=0;i<n;i++)
    {
        ll x=v[i]+1;
        map<ll,ll>mp1,mp2;
        mp1=getPrimeFactors(x-1);
        mp2=getPrimeFactors(x);
         for(auto j:mp2)
        {
            if(mp[j.F]>0)
            {
                mn=min(mn,b[i]);
            }
        }
        for(auto j:mp1)
            mp[j.F]+=mp1[j.F];
    }
    mp.clear();
    for(ll i=n-1;i>=0;i--)
    {
       ll x=v[i]+1;
        map<ll,ll>mp1,mp2;
        mp1=getPrimeFactors(x-1);
        mp2=getPrimeFactors(x);
         for(auto j:mp2)
        {
            if(mp[j.F]>0)
            {
                mn=min(mn,b[i]);
            }
        }
        for(auto j:mp1)
            mp[j.F]+=mp1[j.F];
    }
    //////////////////////
    /////// / // / / /
    ll x1=v1[0].S;
    ll cst=v1[0].F;
    for(int i=1;i<n;i++)
    {
        ll x=v1[i].S;
        set<ll>a=getPrimeFactors1(x);
        for(ll j:a)
        {
             ll y=x1/j;
            if(x1%j!=0)
                y++;
            ll dis=(y*j)-x1;
            mn=min(mn,dis*cst);
        }
    }
    sort(all(b));
    mn=min(mn,b[0]+b[1]);

    cout<<mn<<endl;

}
int main()
{
   fast;
   build_spf();
   //factorial();
   //inverses();
//    freopen("input.txt ", "r", stdin);  // input
//    freopen("output.txt", "w", stdout);  // output
    ll t=1;
   cin>>t;
    while(t--)
        solve();

    return 0;


}
