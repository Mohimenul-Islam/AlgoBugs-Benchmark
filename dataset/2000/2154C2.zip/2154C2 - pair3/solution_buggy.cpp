#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

const int MAXA = 200005;
int min_prime[MAXA + 1];

// Precompute smallest prime factor for fast factorization
void sieve() {
    iota(min_prime, min_prime + MAXA + 1, 0);
    for (int i = 2; i * i <= MAXA; ++i) {
        if (min_prime[i] == i) {
            for (int j = i * i; j <= MAXA; j += i) {
                if (min_prime[j] == j) min_prime[j] = i;
            }
        }
    }
}

inline void get_prime_factors(int n, vector<int>& factors) {
    while (n > 1) {
        int p = min_prime[n];
        factors.push_back(p);
        while (n % p == 0) n /= p;
    }
}

int freq_tail[MAXA + 1]; 

void solve() {
    int n;
    if (!(cin >> n)) return;
    vector<int> a(n);
    for (int i = 0; i < n; ++i) cin >> a[i];
    vector<long long> b(n);
    for (int i = 0; i < n; ++i) cin >> b[i];

    // Sort indices by the cost of incrementing them (b_i)
    vector<int> idx(n);
    iota(idx.begin(), idx.end(), 0);
    sort(idx.begin(), idx.end(), [&](int i, int j) {
        return b[i] < b[j];
    });

    // K=100 is sufficient to find the optimal prime factor
    int K = min(n, 100);
    vector<int> used_vals;
    for (int i = K; i < n; ++i) {
        if (freq_tail[a[idx[i]]] == 0) used_vals.push_back(a[idx[i]]);
        freq_tail[a[idx[i]]]++;
    }

    vector<int> candidates = {2, 3};
    for (int i = 0; i < K; ++i) {
        get_prime_factors(a[idx[i]], candidates);
        get_prime_factors(a[idx[i]] + 1, candidates);
    }
    sort(candidates.begin(), candidates.end());
    candidates.erase(unique(candidates.begin(), candidates.end()), candidates.end());

    long long total_min_cost = 4e18; 

    for (int p : candidates) {
        if (p < 2) continue;
        long long m1 = 2e18, m2 = 2e18;
        auto update = [&](long long v) {
            if (v < m1) { m2 = m1; m1 = v; }
            else if (v < m2) { m2 = v; }
        };

        for (int i = 0; i < K; ++i) {
            long long cost = (1LL * (p - a[idx[i]] % p) % p) * b[idx[i]];
            update(cost);
        }

        int tail_zeros = 0;
        if (n > K) {
            // Optimization: iterate tail or multiples of p based on which is smaller
            if (n - K < MAXA / p) {
                for (int i = K; i < n; ++i) {
                    if (a[idx[i]] % p == 0) { if (++tail_zeros >= 2) break; }
                }
            } else {
                for (int mult = p; mult <= MAXA; mult += p) {
                    tail_zeros += freq_tail[mult];
                    if (tail_zeros >= 2) break;
                }
            }
        }

        if (tail_zeros >= 2) { update(0); update(0); }
        else if (tail_zeros == 1) { update(0); }

        total_min_cost = min(total_min_cost, m1 + m2);
    }

    for (int val : used_vals) freq_tail[val] = 0; // Reset global array
    cout << total_min_cost << "\n";
}

int main() {
    ios::sync_with_stdio(false); cin.tie(nullptr);
    sieve();
    int t; cin >> t;
    while (t--) solve();
    return 0;
}