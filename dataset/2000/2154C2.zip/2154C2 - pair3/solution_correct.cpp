#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

const int MAXA = 200005;
int min_prime[MAXA + 5];
vector<int> relevant[MAXA + 5]; // Global to avoid reallocation overhead

// Precompute smallest prime factor for fast factorization
void sieve() {
    iota(min_prime, min_prime + MAXA + 5, 0);
    for (int i = 2; i * i <= MAXA + 2; ++i) {
        if (min_prime[i] == i) {
            for (int j = i * i; j <= MAXA + 2; j += i) {
                if (min_prime[j] == j) min_prime[j] = i;
            }
        }
    }
}

// Extract unique prime factors of n
void get_unique_factors(int n, vector<int>& factors) {
    while (n > 1) {
        int p = min_prime[n];
        factors.push_back(p);
        while (n % p == 0) n /= p;
    }
}

void solve() {
    int n;
    if (!(cin >> n)) return;
    
    vector<int> a(n);
    for (int i = 0; i < n; ++i) cin >> a[i];
    
    // Read b array and find the index 'm' of the minimum cost element
    int m = 0;
    vector<long long> b(n);
    for (int i = 0; i < n; ++i) {
        cin >> b[i];
        if (b[i] < b[m]) m = i;
    }

    vector<int> used_primes;
    
    // Find all candidate primes
    for (int i = 0; i < n; ++i) {
        vector<int> factors;
        get_unique_factors(a[i], factors);
        get_unique_factors(a[i] + 1, factors);
        
        sort(factors.begin(), factors.end());
        factors.erase(unique(factors.begin(), factors.end()), factors.end());
        
        for (int p : factors) {
            if (relevant[p].empty()) {
                used_primes.push_back(p);
            }
            relevant[p].push_back(i);
        }
    }

    long long ans = 4e18; // Safe upper bound

    for (int p : used_primes) {
        long long m1 = 4e18, m2 = 4e18;
        
        // Helper lambda to track the two minimum costs for the current prime
        auto update = [&](long long c) {
            if (c < m1) {
                m2 = m1;
                m1 = c;
            } else if (c < m2) {
                m2 = c;
            }
        };
        
        bool m_seen = false;
        
        // 1. Process all elements that only need +0 or +1
        for (int idx : relevant[p]) {
            long long cost = (a[idx] % p == 0) ? 0 : b[idx];
            update(cost);
            if (idx == m) m_seen = true;
        }
        
        // 2. If the absolute cheapest element hasn't been evaluated, calculate its cost to reach p
        if (!m_seen) {
            long long cost = 1LL * ((p - a[m] % p) % p) * b[m];
            update(cost);
        }
        
        // If we found at least two valid elements, update the global answer
        if (m1 != 4e18 && m2 != 4e18) {
            ans = min(ans, m1 + m2);
        }
        
        // Clean up global array for the next test case
        relevant[p].clear();
    }

    cout << ans << "\n";
}

int main() {
    // Fast I/O
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    sieve();
    
    int t;
    cin >> t;
    while (t--) solve();
    
    return 0;
}