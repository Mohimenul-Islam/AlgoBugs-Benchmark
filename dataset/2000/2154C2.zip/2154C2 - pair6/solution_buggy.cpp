#include <bits/stdc++.h>
#define int long long
#define N 202020
using namespace std;
int a[N], b[N], cnt[N], f[N], r[N], v[N];
vector<int> primes;
int n; 

int someFactor(int x) {
  map<int, int> s;
  map<int, int> c;
  int ans = INT_MAX;
  for (int i = 1; i <= n; i++) {
    int y = a[i] + x;
    while (y > 1) {
      if (s.count(f[y])) ans = min(ans, b[i]);
      y /= f[y];
    }
    int k = a[i];
    while (k > 1) {
      if (c.count(f[k])) ans = min(ans, c[f[k]]);
      if (s.count(f[k])) s[f[k]] = min(s[f[k]], b[i]);
      else s[f[k]] = b[i];
      k /= f[k];
    }
    y = a[i] + x;
    while (y > 1) {
      if (c.count(f[y])) c[f[y]] = min(c[f[y]], b[i]);
      else c[f[y]] = b[i];
      y /= f[y];
    }
  }
  return ans;
}

int factorUp() {
  int ans = INT_MAX;
  for (int i = 1; i <= n; i++) {
    int y = a[i];
    while (y > 1) {
      v[f[y]]++;
      y /= f[y];
    }
  }
  for (int i = 1; i <= n; i++) {
    int y = a[i];
    while (y > 1) {
      v[f[y]]--;
      y /= f[y];
    }
    for (int p: primes) {
      if (v[p] == 0) continue;
      ans = min((a[i] % p == 0) ? 0 : (p - (a[i] % p)) * b[i], ans);
    }
    y = a[i];
    while (y > 1) {
      v[f[y]]++;
      y /= f[y];
    }
  }
  for (int i = 1; i <= n; i++) {
    int y = a[i];
    while (y > 1) {
      v[f[y]] = 0;
      y /= f[y];
    }
  }
  return ans;
}

int solve() {
  cin >> n;
  for (int i = 1; i <= n; i++) cin >> a[i];
  for (int i = 1; i <= n; i++) cin >> b[i];
  for (int i = 1; i <= n; i++) r[i] = b[i];
  sort(r + 1, r + n + 1, less<int>());
  int pos0 = (someFactor(0) != INT_MAX) ? 0 : INT_MAX;
  int pos1 = someFactor(1);
  int pos2 = factorUp();
  int pos3 = r[1] + r[2];
  int ans = min({pos0, pos1, pos2, pos3});
  cout << ans << endl;
cleanup: 
  for (int i = 1; i <= n; i++) {
    cnt[a[i]] = 0;
  }
  return 0;
}

void sieve(int n) {
  for (int i = 2; i * i <= n; i++) {
    if (f[i]) continue;
    for (int j = i * i; j <= n; j += i) {
      f[j] = i;
    }
  }
  for (int i = 1; i <= n; i++) {
    if (!f[i]) f[i] = i;
  }
  for (int i = 2; i <= n; i++) {
    if (f[i] == i) primes.push_back(i);
  }
}

signed main() {
  sieve(N - 1);
  int T; cin >> T;
  while (T--) solve();
  return 0;
}
