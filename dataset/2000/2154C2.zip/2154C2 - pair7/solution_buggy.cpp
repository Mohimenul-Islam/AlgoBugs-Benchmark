#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;
typedef long long ll;
#define FAST_IO ios_base::sync_with_stdio(false); cin.tie(NULL);
#define yes cout << "Yes\n"
#define no cout << "No\n"
#define Oset tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update>
ll const inf = 1e17+1;
ll const M = 1e5+10;
ll const N = 1e6;
const int mod = 1e9+7;
ll dx[8]={-1,0,1,0,1,-1,-1,1};
ll dy[8]={0,1,0,-1,1,-1,1,-1};

ll gcd(ll a, ll b)
{
    return b==0 ? a : gcd(b,a%b);
}  

ll const MAX = 200005;
vector<vector<ll>> divs(MAX);
void precompute() {
    for(ll i=2;i<MAX;i++) {
        for(ll j=i;j<MAX;j+=i) {
            divs[j].push_back(i);
        }
    }
}

ll fr[MAX];

void solve(int te) {
    // cout << "Case #" << te << ": ";
    ll n; cin>>n;
    vector<ll> a(n), b(n);
    for(ll i=0;i<n;i++) {
        cin>>a[i];
        for(auto c : divs[a[i]])fr[c]++;
    }
    for(ll i=0;i<n;i++) {
        cin>>b[i];
    }
    ll ans = inf;
    for(ll i = 0;i<n;i++) {
        for(auto c : divs[a[i]]) {
            if(fr[c] > 1)ans = 0;
        }
    }
    ll min1 = inf, min2 = inf;
    for(ll i=0;i<n;i++) {
        ll cost = (a[i]%2 == 0 ? 0 : b[i]);

        if(cost < min1) {
            min2 = min1;
            min1 = cost;
        } else if(cost < min2) {
            min2 = cost;
        }
    }

    ans =  min(ans, min1 + min2);

    for(ll i=0;i<n;i++) {
        ll x = a[i];
        fr[x]--;

        for(auto c : divs[x + 1]) {
            if(fr[c] > 0) {
                ans = min(ans, b[i]);
                break;
            }
        }
        fr[x]++;
    }

    ll mim = 0;
    for(ll i=0;i<n;i++) {
        if(b[mim] > b[i])mim = i;
    } 
    
    for(ll i=0;i<n;i++) {
        if(i == mim)continue;
        ll x = a[i];
        ll dist = inf;
        for(auto d : divs[x]) {
           ll req = d - (a[mim]%d);

           if(dist > 0)dist = min(dist, req);
        }

        ans = min(ans, b[mim]*dist);
    }

    for(ll i=0;i<n;i++) {
        for(auto d : divs[a[i]])fr[d]--;
    }
    cout<<ans<<endl;
};      
        
int main()
{
    FAST_IO
    // #ifndef ONLINE_JUDGE
    // freopen("input.txt","r",stdin);
    // freopen("output.txt","w",stdout);
    // // #endif
    precompute();
    int T;
    cin >> T ;
    for(int t = 1; t <= T; t++)solve(t);
    // solve(1);
}














