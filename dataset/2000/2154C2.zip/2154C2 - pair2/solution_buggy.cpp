#pragma G++ optimize(3);
#include <bits/stdc++.h>
#define rep(i,from,to)	for (i = (from);i <= (to);i++)
#define per(i,from,to)	for (i = (from);i >= (to);i--)
#define ll long long
#define int long long 
#define ull unsigned long long
#define pii pair<int, int> 
#define lowbit(x) (x&-x) 
#define equal	==
#define endl '\n'
inline int read() { int s = 0, w = 1;char c = getchar();while (c < 48 || c>57) { if (c == '-') w = -1;c = getchar(); }while (c >= 48 && c <= 57)s = (s << 1) + (s << 3) + c - 48, c = getchar();return s * w; }
inline void print(int x) { if (x < 0) putchar('-'), x = -x;if (x > 9)print(x / 10);putchar(x % 10 + 48); }
const int mod = 998244353;
const int inf = 1e9;
const int llf = 4e18;
using namespace std;

const int maxn = 2e5 + 5;
int n, m, k, q;

vector<int>vec[maxn];
bool is_prime[maxn];
int coe[maxn];
int cnt[maxn];
void init()
{
	int i, j;
	rep(i, 2, maxn - 1)
		is_prime[i] = 1;
	rep(i, 2, maxn - 1)
	{
		if (is_prime[i])
		{
			for (j = i * i;j <= maxn - 1;j += i)
			{
				if (is_prime[j])
				{
					is_prime[j] = 0;
					coe[j] = i;
				}
			}
			coe[i] = i;
		}
	}
}

vector<int> cal(int x)
{
	vector<int>res;
	while (x != 1)
	{
		int temp = coe[x];
		res.push_back(temp);
		while (x % temp == 0)
			x /= temp;
	}
	return res;
}

struct node
{
	int a, b;
}no[maxn];

bool cmpb(node a, node b)
{
	return a.b < b.b;
}
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	int i, j;
	init();
	int tt = 1;
	cin >> tt;
	while (tt--)
	{
		cin >> n;
		rep(i, 1, n)cin >> no[i].a;
		rep(i, 1, n)cin >> no[i].b;
		sort(no + 1, no + 1 + n, cmpb);
		//1+1
		int ans = no[1].b + no[2].b;

		//0
		set<int>myset;
		rep(i, 1, n)
		{
			vec[i] = cal(no[i].a);
			for (auto v : vec[i])
			{
				if (cnt[v])
					ans = 0;
				cnt[v]++;
				if (i != 1) 
				{
					myset.insert(v);
				}
			}
		}

		//1
		rep(i, 1, n)
		{
			//先删除
			for (auto v : vec[i])
				cnt[v]--;

			vector<int>vec1 = cal(no[i].a + 1);
			for (auto v : vec1)
			{
				if (cnt[v])
					ans = min(ans, no[i].b);
			}

			//加回去
			for (auto v : vec[i])
				cnt[v]++;
		}

		//1:n times;
		for (auto x : myset)
		{
			ans = min(ans, (x - no[1].a % x) % x);
		}
		cout << ans << endl;

		rep(i, 1, n)
			for (auto v : vec[i])
				cnt[v]--;
	}
	//assert(0);	//debug修改数据上限maxn时使用，或者提醒自己需要init
}