#include <bits/stdc++.h>
#define int long long
using namespace std;
int t, n;
int a[200005], b[200005], _a[200005], _b[200005];
int bs[200005];
int ct[200005];
int ord[200005];
vector<int> mod;
vector<int> p;
int cmp(int x, int y){
    return _b[x] < _b[y];
}
main(){
    for (int i = 2; i <= 200000; i++){
        if (bs[i] == 0){
            p.push_back(i);
            for (int j = 2*i; j <= 200000; j+=i) bs[i] = 1;
        }
    }
    
    scanf("%lld",&t);
    
    while (t--){
        scanf("%lld",&n);
        for (int i = 1; i <= n; i++) scanf("%lld",&_a[i]);
        for (int i = 1; i <= n; i++) scanf("%lld",&_b[i]);
        iota(ord+1, ord+n+1, 1);
        sort(ord+1, ord+n+1, cmp);
        for (int i = 1; i <= n; i++){
            a[i] = _a[ord[i]];
            b[i] = _b[ord[i]];
        }
        int ans = b[1] + b[2];
        for (int i = 1; i <= n; i++) {
            int tmp = a[i];
            for (auto x : p){
                if (x*x > tmp) break;
                if (tmp % x == 0){
                    if (ct[x] >= 1) ans = 0;
                    else mod.push_back(x);
                    ct[x]++;
                    while (tmp%x == 0) tmp /= x;
                }
            }
            if (tmp != 1){
                if (ct[tmp] >= 1) ans = 0;
                else mod.push_back(tmp);
                ct[tmp]++;
            }
        }

        if (ans == 0) {
            printf("0\n", ans);
            for (auto x : mod){
                ct[x] = 0;
            }
            mod.clear();
            continue;
        }
        for (int i = 1; i <= n; i++) {
            int tmp = a[i]+1;
            for (auto x : p){
                if (x*x > tmp) break;
                if (tmp % x == 0){
                    if (ct[x] >= 1) ans = min(ans, b[i]);
                    while (tmp%x == 0) tmp /= x;
                }
            }
            if (tmp != 1){
                if (ct[tmp] >= 1) ans = min(ans, b[i]);
            }
        }

        for (auto x : mod){
            if (a[1] % x) ans = min(ans, b[1] * (x-a[1]%x));
            ct[x] = 0;
        }
        printf("%lld\n", ans);
        mod.clear();
    }
    
}