#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <algorithm>
#include <unordered_map>
#include <cmath>
#include <set>
#include <map>
#include <queue>
#include <random>
#include <ctime>
#include <list>
#include <stack>
#include <bitset>
#include <chrono>
#define N 500005
#define M 110
#define eps 1e-7
using namespace std;
typedef long long ll;
const ll mod = 1000000007LL;
const ll mod2 = 998244353LL;
const ll mod3 = 676767677;
const ll base1 = 13331LL;
const ll base2 = 23333LL;
const int inf = 1000000010;
//const __int128 hmod = 212370440130137957LL;
//srand((unsigned)time(0));
const int base=337;
int n, m, q;
int k, w;
int t;
int a[N];
int a2[N];
ll cc[N];
int b[N];
map<ll, ll> res;
vector<string> v;
int main() {
  // cin>>t;
  // for (int cas=1; cas<=t; ++cas) {
  // }
  // ll ans=1LL;
  // for (int i =1; i <= 500; ++i) {
  //   ans=ans*5813LL%9422LL;
  // }
  // cout<<ans<<endl;
  cin>>t;
  for (int cas=1; cas<=t; ++cas) {
    int x, y;
    scanf("%d%d", &n, &q);
    int ans=0;
    for (int i = 1; i <= n; ++i) {
      scanf("%d", &a[i]);
    }
    sort(a+1, a+n+1);
    int l = 1, r = n;
    while(l < r) {
      swap(a[l], a[r]);
      l++,r--;
    }
    res.clear();
    while(q-->0) {
      int c;
      scanf("%d", &c);
      // if (res.find(c) != res.end()) {
      //   printf("%lld\n", res[c]);
      //   continue;
      // }
      ll tot=0LL;
      for (int j = 1; j <= n; ++j) {
       // a2[j] = a[j];
        cc[j] = 0;
        b[j] = 0;
      }
      for (int i = 29; i >= 0; --i) {
        if (!((1<<i) & c)) continue;
        ll mn = (1LL<<61)-1;
        int id=0;
        for (int j = 1; j <= min(n, 30); ++j) {
          int dt = (b[j] | (1<<i)) - a[j];
          if (dt < mn) {
            mn = dt;
            id = j;
          }
        }
        if (mn < 0) {
          b[id] |= (1<<i);
        } else {
          b[id] |= (1<<i);
          cc[id] = mn;
          // 不能把a[id]改掉，因为会出现：
          // 第i位dt[j1]>dt1[j2],第i+1位dt[j1]>dt2[j2]但是dt[j1]<dt1[j2]+dt2[j2]。
          // a2[id] = b[id];
        }
      }
      for (int i = 1; i <= min(n, 30); ++i) {
        tot += cc[i];
      }
     // res[c] = tot;
      printf("%lld\n", tot);
    }
  }
  return 0;
}

