#include <bits/stdc++.h>

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

typedef long long ll;
typedef long double ld;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef tuple<int, int, int> iii;
typedef pair<ll, ll> pll;
typedef vector<ii> vii;
typedef vector<ll> vll;

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define LSOne(S) ((S) & -(S))

template <class T>
using ordered_set = tree<T, null_type, greater<T>, rb_tree_tag, tree_order_statistics_node_update>;

template <class T>
bool chmin(T& a, const T& b) { return b < a ? a = b, 1 : 0; }
template <class T>
bool chmax(T& a, const T& b) { return a < b ? a = b, 1 : 0; }

void solve() {
    int n, q;
    cin >> n >> q;

    vi a(n);
    multiset<int> pq;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
        pq.insert(a[i]);
    }

    while (q--) {
        int c;
        cin >> c;
        vii ops;
        int add = 0;
        for (int j = 29; j >= 0; j--) {
            if ((1 << j) & c) {
                int x = *pq.rbegin();
                pq.extract(x);
                ops.push_back({0, x});

                if (x < (1 << j)) {
                    add += (1 << j) - x;
                    x = 1 << j;
                }
                x -= 1 << j;
                pq.insert(x);
                ops.push_back({1, x});

                c ^= 1 << j;
            }
        }
        for (auto [t, x] : ops) {
            if (t == 0)
                pq.insert(x);
            else
                pq.extract(x);
        }
        cout << add << '\n';
    }
}

int main() {
    ios_base::sync_with_stdio(0), cin.tie(0);

    int tc = 1;
    cin >> tc;

    while (tc--) {
        solve();
    }

    return 0;
}