#include<bits/stdc++.h>
using namespace std;

const int N=5e5+5;
int n,q,a[N],b[N];

void solve(){
	cin>>n>>q;
	for(int i=1;i<=n;i++) cin>>a[i];
	sort(a+1,a+n+1,greater<int>());
	n=min(n,30);
	while(q--){
		int c,ans=0;cin>>c;
		for(int i=1;i<=n;i++) b[i]=a[i];
		for(int bit=29;bit>=0;bit--){
			int cnt=0;
			for(int i=1;i<=n;i++) if((b[i]>>bit)&1) cnt++;
			if(cnt>(c>>bit&1)) break;
			if(cnt==(c>>bit&1)){
				for(int i=1;i<=n;i++) if(b[i]&(1<<bit)) b[i]^=(1<<bit);
			}
			else{
				int id=1;
				for(int i=1;i<=n;i++) if(b[i]>b[id]) id=i;
				ans+=(1<<bit)-b[id];
				b[id]=0;
			}
		}
		cout<<ans<<endl;
	}
}

signed main(){
	ios::sync_with_stdio(0);cin.tie(0);
	int T;cin>>T;while(T--) solve();
	return 0;
}
