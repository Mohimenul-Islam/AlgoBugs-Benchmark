#include <bits/stdc++.h>
#define int long long
using namespace std;
#define all(x) x.begin(), x.end()
const int kk = 2e5 + 7;
using ll = long long;
const int inf = 1e8;
#define me(a, b) memset(a, b, sizeof(a))
#define lowbit(x) x & (-x)
#define mid l + (r - l) / 2
// #define lson l,mid,rt<<1
#define rson mid + 1, r, rt << 1 | 1
#define xf 0x3f3f3f3f
#define endl "\n"
int dy[4] = {0, 0, 1, -1};
int dx[4] = {1, -1, 0, 0};

int dy1[8] = {0, 0, 1, -1, 1, 1, -1, -1};
int dx1[8] = {1, -1, 0, 0, 1, -1, 1, -1};
int n, q;
int a[500005];
int b[500005];
void solve()
{
	cin >> n >> q;
	int ans = 0;
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i];
	}
	sort(a + 1, a + 1 + n, greater<int>());
	int c;

	for (int i = 1; i <= q; i++)
	{
		cin >> c;
		ans = 0;
		for (int o = 1; o <= n; o++)
		{
			b[o] = a[o];
		}
		for (int j = 30; j >= 0; j--)
		{
			int p = 0;
			for (int l = 1; l <= n; l++)
			{
				if ((b[l] >> j) & 1)
					p++;
			}

			if (p > ((c >> j) & 1))
			{
				break;
			}
			if (p == ((c >> j) & 1))
			{
				for (int i = 1; i <= n; i++)
					if (b[i] & (1 << j))
						b[i] ^= (1 << j);
			}
			else
			{
				int id = 1;
				for (int i = 1; i <= n; i++)
					if (b[i] > b[id])
						id = i;
				ans += (1 << j) - b[id];
				b[id] = 0;
			}
		}
		cout << ans << endl;
	}
}

signed main()
{
	int t = 1;
	cin >> t;
	while (t--)
	{
		solve();
	}
	return 0;
}