#include <bits/stdc++.h>
using namespace std;
#define int long long
//
const int maxn = 5e5 + 10;
//
int n, q;
int a[maxn], b[maxn];
void solve () {
    cin >> n >> q;
	for(int i = 1; i <= n; i++) cin >> a[i];
	sort(a + 1, a + n + 1, greater<int>());
	//
	int x;
	while(q--) {
		cin >> x;
		//
		if(x <= a[1]) {
			cout << "0\n";
			continue;
		}
		int mx = 0;
		while((1ll << (mx + 1)) <= x) mx++;
		//
		priority_queue<int> qq;
		for(int i = 1; i <= min(n, mx + 5); i++) qq.push(a[i]);
		//
		int ans = 0;
		for(int i = mx; i >= 0; i--) {
			if(qq.empty()) {
				ans += x;
				break;
			} 
			if(qq.top() >= x) break;
			//
			int aim = (1ll << i);
			int u = (x & aim) ? 1 : 0;
			int v = (qq.top() & aim) ? 1 : 0;
			//
			if(u) {
				int tmp = qq.top();
				qq.pop();
				if(v) {
					tmp ^= aim;
					qq.push(tmp);
				}//
				else ans += aim - tmp;
				x ^= aim;
			}
		}
		cout << ans << '\n';
	}
}

signed main() {
	std :: ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int T = 1;
	cin >> T;
	while(T--) solve();
	return 0;
}

