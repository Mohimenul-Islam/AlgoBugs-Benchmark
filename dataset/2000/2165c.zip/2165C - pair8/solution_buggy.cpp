#include <bits/stdc++.h>
#define int long long
using namespace std;

void solve() {
	int n, q;
	cin >> n >> q;
	vector<int> a(n);
	for (int i = 0; i < n; i++) cin >> a[i];
	
	sort(a.begin(), a.end());
	if (a.size() > 60) a.resize(60);
	
	while (q--) {
		int c;
		cin >> c;
		if (c == 0) {
			cout << 0 << "\n";
			continue;
		}
		
		priority_queue<int> pq;
		for (int x : a) pq.push(x);
		
		int ans = 2e18;
		int current_cost = 0;
		int curr_c = c;
		
		while (curr_c > 0) {
			int m1 = pq.top();
			if (m1 >= curr_c) {
				ans = min(ans, current_cost);
				break;
			}
			ans = min(ans, current_cost + curr_c - m1);
			
			int k = 63 - __builtin_clzll(curr_c);
			int p = 1LL << k;
			
			int cost = max(0LL, p - m1);
			int rem = max(0LL, m1 - p);
			
			current_cost += cost;
			pq.pop();
			pq.push(rem); 
			curr_c -= p;
		}
		
		if (curr_c == 0) ans = min(ans, current_cost);
		cout << ans << "\n";
	}
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int t;
	cin >> t;
	while (t--) solve();
	return 0;
}