#include <bits/stdc++.h>
using namespace std;

void solve() {
    int n, q;
    cin >> n >> q;
    vector<long long> a(n);
    for (int i = 0; i < n; i++) cin >> a[i];
    
    // 降序排序，只保留最大的60个足矣 (因为 c < 2^30，递归至多30层)
    sort(a.rbegin(), a.rend());
    if (a.size() > 60) a.resize(60);
    
    while (q--) {
        long long c;
        cin >> c;
        if (c == 0) {
            cout << 0 << "\n";
            continue;
        }
        
        priority_queue<long long> pq;
        for (long long x : a) pq.push(x);
        
        long long ans = 2e18; // 设置极大值防溢出
        long long current_cost = 0;
        long long curr_c = c;
        
        while (curr_c > 0) {
            long long m1 = pq.top();
            // 如果最大值已经可以覆盖当前的 c，直接0成本完成当前及后续位
            if (m1 >= curr_c) {
                ans = min(ans, current_cost);
                break;
            }
            // Option 1: 强行将 m1 提升到 curr_c
            ans = min(ans, current_cost + curr_c - m1);
            
            // Option 2: 让 m1 负责 curr_c 的最高位
            long long k = 63 - __builtin_clzll(curr_c);
            long long p = 1LL << k;
            
            long long cost = max(0LL, p - m1);
            long long rem = max(0LL, m1 - p); // 剥离最高位后的残余价值
            
            current_cost += cost;
            pq.pop();
            pq.push(rem); // 永远弹1压1，堆永远不会为空
            curr_c -= p;
        }
        
        if (curr_c == 0) ans = min(ans, current_cost);
        cout << ans << "\n";
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--) solve();
    return 0;
}