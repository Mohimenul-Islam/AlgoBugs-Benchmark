#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#ifdef NYEMOT
    #define db(v) cerr << "Line(" << __LINE__ << ") -> " << #v << " = " << (v) << endl;
    constexpr bool debug_mode = true;
#else
    #define db(v)
    constexpr bool debug_mode = false;
    #define cerr if constexpr (false) cerr
#endif
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define fs first
#define sd second

#ifndef NYEMOT_UNPACK 
namespace Competitive_Programming{
#endif
    using namespace std;
    using namespace __gnu_pbds;
    using ll = long long;
    using ull = unsigned long long;
    using ui = unsigned int;
    // size is int because easier to work with and competitive prog rarely (never?) need anything > `max_int`
    using my_size_type = int;

    template<typename T>
    using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
    template<typename T>
    using os = ordered_set<T>;
    template<typename T>
    using v = vector<T>;
    template<typename A, typename B>
    using p = pair<A,B>;
    template<typename T, typename container = v<T>, typename comparator = less<T>>
    using pq = priority_queue<T, container, comparator>;
    template<typename T, typename container = v<T>, typename comparator = greater<T>>
    using pqg = priority_queue<T, container, comparator>;
    template<typename T>
    using mset = multiset<T>;

    template<typename T>
    concept Container = requires(T a) {
        typename T::value_type;
        typename T::iterator;
        a.begin();
        a.end();
    };

    // common useful values in Codeforces
    namespace Constants{
        constexpr int inf32 = 1.05e9;
        constexpr ll inf64 = 4.05e18;
        // modulo
        constexpr ll m97 = 1'000'000'007;
    }

    // useful data structures in Codeforces that aren't availabe in c++ stl
    namespace Data_Structures{
        // automatic mod the value each operation, handles mod up to prime INT_MAX(?)
        template <ll T_mod = 0>
        class modint{
        public:
            ll value;
            
            // constructor
            modint(ll value=0);

            // operations

            modint& operator+=(const modint& oth);
            modint& operator-=(const modint& oth);
            modint& operator*=(const modint& oth);
            modint& operator/=(const modint& oth);
            friend modint operator+(modint a, const modint& b) {return a += b;}
            friend modint operator-(modint a, const modint& b) {return a -= b;}
            friend modint operator*(modint a, const modint& b) {return a *= b;}
            friend modint operator/(modint a, const modint& b) {return a /= b;}
            
        private:
            // runtime mod as static to allow smaller data
            static ll runtime_mod;
            // get runtime mod
            static ll mod();
        public:
            // set runtime mod
            static void set_mod(ll new_mod);

        //friends:

            // output
            friend ostream& operator<<(ostream& os, const modint& self){
                return os << self.value;
            }
        };
        
        // Disjoint Set Union, O(1) amortized operation
        class DSU{
        // currently every member is public for convenience
        public:
            v<int> par, sizes;
            // creates [0, n] array, total of (n+1), index=0 is ignored
            DSU(int n);
            // find which group/head `node` belongs to
            int find(int node);
            // try to combine group a and group b
            // returns false when group is equal before function call
            bool unite(int node_a, int node_b);
            // check whether a and b belong in the same group
            bool same(int a, int b);
            // return the group size which a belongs to
            int group_size(int node);
        };

        // sparse table with custom functions
        // custom function should take 2 number
        // 0-based indexing
        template<typename T, typename F>
        class sparse_table{
        private:
            my_size_type n;
            v<v<T>> table;
            F combine_func;
        public:
            sparse_table(v<T>& data, F&& func, my_size_type sz = 0);
            // queries func[l,r] (inclusive)
            T query(my_size_type l, my_size_type r);
        };

        // binary lift class, takes adjacency and root as constructor
        // supports O(1) ancestry check
        // O(log(n)) lowest common ancestor (LCA)
        class binary_lift{
        private:
            int timer, lg;
            v<int> timer_in, timer_out;
            v<v<int>> up;
        public:
            binary_lift(v<v<int>>& adjacency, int root, int n = 0);
            // return true when lhs is ancetor of rhs, in O(1) time
            bool is_ancestor(int try_parent, int node);
            // returns lowet common ancestor, log(n) worst case
            int lca(int node_a, int node_b);
            // create simple path in O(log(dis) + dis)
            v<int> path(int node_a, int node_b);
        private:
            // helper setup function
            void dfs(v<v<int>>& adjacency, int node, int par);
        };
    }

    // Type less on input output
    namespace IO{
        // CIN

        // break pair
        template<typename TA, typename TB> istream& operator>>(istream& in, pair<TA, TB>& p);
        // open container
        template<Container C>
        requires (!std::is_same_v<C, std::string>)
        istream& operator>>(istream& in, C& con);
        // input using  `,` instead of `>>`
        template<typename T> istream& operator,(istream& in, T& t);
        // inputs tree
        template<typename T=int > v<v<T>> tree_in(my_size_type n);
        // inputs tree, but uses set<int> as container
        template<typename T=int > v<set<T>> tree_in_set(my_size_type n);

        // COUT

        // break pair
        template<typename TA, typename TB> ostream& operator<<(ostream& out, const pair<TA, TB>& p);
        // open container
        template<Container C> 
        requires (!std::is_same_v<C, std::string>)
        ostream& operator<<(ostream& out, const C& c);
        // output using `,` instead of `<<`
        template<typename T> ostream& operator,(ostream& out, const T& t);
        // endl
        ostream& operator,(ostream& out, ostream& (*func)(ostream&));
        // modint output
        template <ll T_mod> ostream& operator<<(ostream& out, const Data_Structures::modint<T_mod>& self);
    }

    // some bitwise functions, renamed and/or remapped to fit better to most question
    namespace Bits{
        // returns number of active bits
        constexpr int popcnt(int x);
        // returns number of active bits
        constexpr int popcnt(ll x);
        // returns floor(log2(x)), negative number always 31
        constexpr int topbit(int x);
        // returns floor(log2(x)), negative number always 63
        constexpr int topbit(ll x);
        // returns lowest_bit position
        constexpr int lowbit(int x);
        // returns lowest_bit position
        constexpr int lowbit(ll x);
    }

    // contains useful math function + classes
    namespace Math{
        /**calculate (base^exp) % mod in O(log(exp)) time.
         * may overflow if mod > int_max.
         * may overflow if base > int_max.
         */
        ll modexp(ll base, ll exp, ll mod);
        // returns `base` to the power of (-1) % mod, mod must be prime
        ll modinv(ll base, ll mod);
        /**solves up to 1e18, in log(num)
         * returns floor(sqrt(num))
         */ 
        ll sqbig(ll num);

        
        /**smallest prime factor (SPF) table, 
         * Special cases:
         * - spf[0] = 1    (0 is not prime)
         * - spf[1] = 1    (1 is not prime, treated as 1 for convenience, doesn't exist in `get_primes()`)
         */
        class prime_table{
        public:
            // make size +1, [0, n]
            prime_table(int size);
            // get spf of `number`
            int operator[](int number) const;
            // check whether `number` is prime
            bool is_prime(int number) const;
            // borrow result primes
            const vector<int>& get_primes() const;
            // create prime factor array, each element is [Pi, count] format
            vector<pair<int,int>> prime_factors(int val) const;
            // returns unsorted array of factors
            vector<int> factorize(int val) const;
            // this function should be called before using cache
            void begin_cached_factorize();
            // returns unsorted array of factors, call `begin_cached_factorize` beforehand
            // works best with many calls
            vector<int>& cached_factorize(int val);
        private:
            // store SPF[value]
            vector<int> min_prime;
            // store all primes up to [size+50], inclusive
            vector<int> primes;
            // cache for factorize, empty before `begin_cached_factorize` is called
            vector<vector<int>> factors;
        };

        // factorial, inverse, combinatoric
        // maximum of 1 mod value
        // remodding uses O(2*n) time
        // return value is long long for convenience, but everything is < mod
        class factorial{
        public:
            factorial(my_size_type n, int mod);
            // if (idx>=0) returns factorial(idx) else returns modinv(factorial(idx))
            ll operator[](int idx) const;
            // returns Choose(total, choose), aka nCr
            ll comb(my_size_type total, my_size_type choose) const;
            // stars and bars shorthand
            ll starbar(my_size_type stars, my_size_type bars) const;
        private:
            int mod;
            v<int> fact;
            v<int> inverse_fact;
        };
    }

    // common operations and miscellaneous
    namespace Utility{
        // shorter remove item multiset (1 item)
        template<typename T> multiset<T>::iterator operator-=(multiset<T>& mp, const T& val);
        // shorter add item multiset (1 item)
        template<typename T> multiset<T>::iterator operator+=(multiset<T>& mp, const T& val);
        // set lhs = max(lhs, rhs)
        template<typename T> T& setmax(T &x, const T& y);
        // set lhs = min(lhs, rhs)
        template<typename T> T& setmin(T &x, const T& y);
        // set lhs, rhs = min(lhs, rhs), max(lhs, rhs)
        template<typename T> void setless(T &x, T& y);
        // set lhs, rhs = max(lhs, rhs), min(lhs, rhs)
        template<typename T> void setmore(T &x, T& y);
        // calculate mex of a sorted container, O(n) time
        template<typename Container> my_size_type mex_sorted(const Container& c);
        // calculate mex of a unsorted container, O(n) time, but slower than sorted
        template<typename Container> my_size_type mex_general(const Container& c);
        // calculate lps array, do (n-lps.back()) for period
        template<typename Container> v<my_size_type> make_lps(const Container& c);
        // compress_value
        v<int> compress_value(const v<int>& ar);
        // count occurence of each value
        map<int,int> count_occ(const v<int>& ar);

        // Class for managing multiple return result branch
        class return_message{
        // currently everything is public for user's convenience
        public:
            // current message number
            my_size_type value;
            // collection of message
            v<string> msgs{"NO", "YES"};
            // decide sending
            bool will_send = true;
            // 0 = "NO", 1 = "YES"
            return_message(my_size_type start_value = 0, bool autosend = true);
            // (if enabled) prints message on destruction
            ~return_message();
            // pick message index
            void setval(my_size_type new_value);
            // set/renew message at index
            void setmsg(my_size_type value, const string& new_msg);
            // (if enabled) prints message and disable this instance
            void flush();
        };

        // enumerate containers
        // each position returns [int index, T& value]
        template<Container C>
        class enumerate{
        private:
            // reference to actual container being enumerated
            C& ref;
        public:
            enumerate(C& c);
            class Iterator{
            private:
                my_size_type index;
                typename C::iterator it;
            public:
                Iterator(my_size_type, typename C::iterator it);
                p<my_size_type, typename C::value_type&> operator*() const;
                Iterator& operator++();
                bool operator!=(const Iterator&other) const;
            };
        Iterator begin();
        Iterator end();
        };

        // creates N-dimensional vector<decltype(last_arg)>
        template<class... Args> auto ndim(size_t n, Args&&... args);
        // cant separate, auto keyword
        template<class... Args> auto ndim(size_t n, Args&&... args){
            if constexpr (sizeof...(Args) == 1) {
                return v(n, args...);
            } else {
                return v(n, ndim(args...));
            }
        }
    }

    // use all
    namespace Unpack{
    #ifndef NYEMOT_UNPACK 
        using namespace Competitive_Programming;
    #endif
        using namespace Constants;
        using namespace Data_Structures;
        using namespace IO;
        using namespace Bits;
        using namespace Math;
        using namespace Utility;
        template <Container C>
        using en = enumerate<C>;
    }
#ifndef NYEMOT_UNPACK 
}
#endif

// END OF DECLARATION










// START OF DEFINITION

#ifndef NYEMOT_UNPACK 
namespace Competitive_Programming{
#endif
    namespace IO{
        // break pair
        template<typename TA, typename TB> istream& operator>>(istream& in, pair<TA, TB>& p){
            return in>>p.first>>p.second;
        }
        // open container
        template<Container C>
        requires (!std::is_same_v<C, std::string>)
        istream& operator>>(istream& in, C& con){
            for(auto&ci:con){
                in>>ci;
            }
            return in;
        }
        // input using  `,` instead of `>>`
        template<typename T> istream& operator,(istream& in, T& t){
            return in>>t;
        }
        // inputs tree
        template<typename T> v<v<T>> tree_in(my_size_type n){
            v<v<T>> res(n+1);
            for(int i=1,na,nb;i<n;++i){
                cin,na,nb;
                res[na].push_back(nb);
                res[nb].push_back(na);
            }
            return res;
        }
        // inputs tree, but uses set<int> as container
        template<typename T> v<set<T>> tree_in_set(my_size_type n){
            v<set<T>> res(n+1);
            for(int i=1,na,nb;i<n;++i){
                cin,na,nb;
                res[na].push_back(nb);
                res[nb].push_back(na);
            }
            return res;
        }
        // break pair
        template<typename TA, typename TB> ostream& operator<<(ostream& out, const pair<TA, TB>& p){
            return out<<' '<<p.first<<' '<<p.second<<' ';
        }
        // open container
        template<Container C> 
        requires (!std::is_same_v<C, std::string>)
        ostream& operator<<(ostream& out, const C& c){
            for(auto&ci:c){
                out<<' '<<ci;
            }
            return out<<'\n';
        }
        // output using `,` instead of `<<`
        template<typename T> ostream& operator,(ostream& out, const T& t){
            return out<<t;
        }
        // endl
        ostream& operator,(ostream& out, ostream& (*func)(ostream&)){
            return out<<func;
        }
        // modint output
        template <ll T_mod> ostream& operator<<(ostream& out, const Data_Structures::modint<T_mod>& self){
            return out<<self.value;
        }
    }
    namespace Data_Structures{
        template <ll T_mod> modint<T_mod>::modint(ll value){
            value %= this->mod();
            if(value<0)value += this->mod();
            this->value = value;
        }
        template <ll T_mod> modint<T_mod>& modint<T_mod>::operator+=(const modint& oth){
            this->value += oth.value;
            if(this->value >= this->mod()) this->value -= this->mod();
            return *this;
        }
        template <ll T_mod> modint<T_mod>& modint<T_mod>::operator-=(const modint& oth){
            this->value -= oth.value;
            if(this->value < 0) this->value += this->mod();
            return *this;
        }
        template <ll T_mod> modint<T_mod>& modint<T_mod>::operator*=(const modint& oth){
            this->value = this->value * oth.value % this->mod();
            return *this;
        }
        template <ll T_mod> modint<T_mod>& modint<T_mod>::operator/=(const modint& oth){
            return *this *= Math::modinv(oth.value, this->mod());
        }
        template <ll T_mod> ll modint<T_mod>::mod(){
            if constexpr (T_mod != 0) return T_mod;
            else return runtime_mod;
        }
        template <ll T_mod> void modint<T_mod>::set_mod(ll new_mod){
            runtime_mod = new_mod;
        }
        // creates [0, n] array, total of (n+1), index=0 is ignored
        DSU::DSU(int n): par(n+1), sizes(n+1, 1){
            iota(this->par.begin(), this->par.end(), 0);
        }
        // find which group/head `node` belongs to
        int DSU::find(int node){
            if (this->par[node] == node) return node;
            return this->par[node] = this->find(this->par[node]);
        }
        // try to combine group a and group b
        // returns false when group is equal before function call
        bool DSU::unite(int a, int b){
            a = this->find(a);
            b = this->find(b);
            if (a==b) return false;
            if(this->sizes[a]<this->sizes[b])swap(a,b);
            this->par[b] = a;
            this->sizes[a] += this->sizes[b];
            return true;
        }
        // check whether a and b belong in the same group
        bool DSU::same(int a, int b){
            return this->find(a) == this->find(b);
        }
        // return the group size which a belongs to
        int DSU::group_size(int node){
            return this->sizes[find(node)];
        }
        template<typename T, typename F>
        sparse_table<T,F>::sparse_table(vector<T>& data, F&& func, my_size_type sz)
            :combine_func(func){
            if(sz==0){
                sz = data.size();
            }
            this->n = sz;
            my_size_type depth = std::bit_width((unsigned)this->n) + 1;
            this->st.resize(depth);
            this->st[0] = data;
            for(my_size_type di = 1; di < depth; ++di){
                this->st[di].resize(this->n); // - ((1<<di)-1);
                for(my_size_type idx = 0; idx + (1<<di) <=n; ++idx){
                    this->st[di][idx] = this->combine_func(this->st[di-1][idx], this->st[di-1][idx+(1<<(di-1))]);
                }
            }
        }
        template<typename T, typename F>
        T sparse_table<T,F>::query(my_size_type l, my_size_type r){
            my_size_type depth = std::bit_width((unsigned)(r-l+1))-1;
            return this->combine_func(this->st[depth][l], this->st[depth][r-((1<<depth)-1)]);
        }
        binary_lift::binary_lift(v<v<int>>& adjacency, int root, int n){
            if(n==0){
                n = (int)adjacency.size();
            }else{
                n++;
            }
            if(root>=n){
                using namespace IO;
                cerr,"BINARY_LIFT: ROOT >= N\n";
            }
            this->timer_in.resize(n);
            this->timer_out.resize(n);
            this->timer = 0;
            this->lg = Bits::topbit(n);
            this->up.assign(n, v<int>(this->lg+1));
            this->dfs(adjacency, root, root);
        }
        bool binary_lift::is_ancestor(int node_a, int node_b){
            return this->timer_in[node_a] <= this->timer_in[node_b] && this->timer_out[node_b] <= this->timer_out[node_a];
        }
        int binary_lift::lca(int node_a, int node_b){
            if(this->is_ancestor(node_a, node_b)){
                return node_a;
            }
            if(this->is_ancestor(node_b, node_a)){
                return node_b;
            }
            for(int i=lg; i>=0; --i){
                if(!this->is_ancestor(this->up[node_a][i], node_b)){
                    node_a = this->up[node_a][i];
                }
            }
            return this->up[node_a][0];
        }
        v<int> binary_lift::path(int node_a, int node_b){
            int ances = this->lca(node_a, node_b);
            v<int> path_a, path_b;
            while(node_a!=ances){
                path_a.push_back(node_a);
                node_a = this->up[node_a][0];
            }
            path_a.push_back(ances);
            while(node_b!=ances){
                path_b.push_back(node_b);
                node_b = this->up[node_b][0];
            }
            reverse(path_b.begin(), path_b.end());
            path_a.insert(path_a.end(), path_b.begin(), path_b.end());
            return path_a;
        }
        void binary_lift::dfs(v<v<int>>& adjacency, int node, int par){
            this->timer_in[node] = ++timer;
            this->up[node][0] = par;
            for(int i=1; i<=this->lg;++i){
                this->up[node][i] = this->up[this->up[node][i-1]][i-1];
            }
            for(auto nb:adjacency[node]){
                if(nb==par)continue;
                this->dfs(adjacency, nb, node);
            }
            this->timer_out[node] = ++timer;
        }
    }
    namespace Bits{
        constexpr int popcnt(int x) { return __builtin_popcount(x); };
        constexpr int popcnt(ll x) { return __builtin_popcountll(x); };
        constexpr int topbit(int x) { return (x == 0 ? -1 : 31 - __builtin_clz(x)); }
        constexpr int topbit(ll x) { return (x == 0 ? -1 : 63 - __builtin_clzll(x)); }
        constexpr int lowbit(int x) { return (x == 0 ? -1 : __builtin_ctz(x)); }
        constexpr int lowbit(ll x) { return (x == 0 ? -1 : __builtin_ctzll(x)); }
    }
    namespace Math{
        ll modexp(ll base, ll exp, ll mod){
            ll result = 1;
            while(exp){
                if(exp&1){
                    result = result * base % mod;
                }
                base = base * base % mod;
                exp >>= 1;
            }
            return result;
        }
        ll modinv(ll base, ll mod){
            return modexp(base, mod-2, mod);
        }
        ll sqbig(ll num){
            ll l = 0, r = min((ll)Constants::inf32, num);
            ll ans = 0;
            while(l<=r){
                ll m = l+(r-l)/2;
                if(m*m<=num){
                    ans = m;
                    l = m+1;
                }else{
                    r = m-1;
                }
            }
            return ans;
        }
        prime_table::prime_table(int size){
            size+=1;
            this->min_prime.assign(size+1, 0);
            this->min_prime[0] = this->min_prime[1] = 1;
            this->primes.reserve(sqrt(size+1));
            for(int i=2; i<=size; ++i) { // euler sieve
                if(this->min_prime[i] == 0) {
                    this->min_prime[i] = i;
                    this->primes.push_back(i);
                }
                for(int p:primes) {
                    if(p > this->min_prime[i] || 1ll*i*p > size) break;
                    this->min_prime[i*p] = p;
                }
            }
        }
        int prime_table::operator[](int number) const {return this->min_prime[number];}
        bool prime_table::is_prime(int number) const {return this->min_prime[number] == number;}
        const vector<int>& prime_table::get_primes() const {return this->primes;}
        vector<int> prime_table::factorize(int val) const {
            if(val==1)return{1};
            int div = (*this)[val], count = 0;
            while(val%div==0){
                val/=div;
                count++;
            }
            vector<int> res = this->factorize(val);
            for(int i=1,ori_sz=(int)res.size(),mult=1;i<=count;++i){
                mult*=div;
                for(int j=0;j<ori_sz;++j){
                    res.push_back(res[j]*mult);
                }
            }
            return res;
        }
        vector<pair<int,int>> prime_table::prime_factors(int val) const {
            v<p<int,int>> res;
            if(val<1)return res;
            while(val!=1){
                int div = (*this)[val];
                int count = 0;
                while(val%div==0){
                    val/=div;
                    count++;
                }
                res.push_back({div,count});
            }
            return res;
        }
        void prime_table::begin_cached_factorize(){
            if(this->factors.empty()){
                this->factors.resize(this->min_prime.size());
                this->factors[1] = {1};
            }
        }
        // returns unsorted array of factors, call `begin_cached_factorize` beforehand
        // works best with many calls
        vector<int>& prime_table::cached_factorize(int val){
            if(!this->factors[val].empty())return this->factors[val];
            vector<int> &self = this->factors[val];
            int div = (*this)[val], count = 0;
            while(val%div==0){
                val/=div;
                count++;
            }
            vector<int> &ch = this->cached_factorize(val);
            for(int i=0,mult=1;i<=count;++i){
                for(int j=0;j<(int)ch.size();++j){
                    self.push_back(ch[j]*mult);
                }
                mult*=div;
            }
            return self;
        }
        factorial::factorial(my_size_type n, int mod):mod(mod){
            if (mod <= 0) {
                cerr << "Error factorial class init: Mod value must be positive, mod = " << mod << '\n';
            }
            this->fact.resize(n+1);
            this->inverse_fact.resize(n+1);
            this->fact[0] = 1;
            for (my_size_type i=1; i<(my_size_type)fact.size(); ++i) {
                fact[i] = (ll) fact[i-1] * i % mod;
            }
            inverse_fact.back() = Math::modexp(fact.back(), mod-2, mod);
            for (my_size_type i = inverse_fact.size()-2; i>=0; --i) {
                inverse_fact[i] = (ll) inverse_fact[i+1] * (i+1) % mod;
            }
        }
        ll factorial::operator[](int idx) const {
            if (idx>=0) return this->fact[idx];
            else return this->inverse_fact[-idx];
        }
        ll factorial::comb(my_size_type total, my_size_type choose) const {
            return (ll)(*this)[total] * (*this)[-choose] % this->mod * (*this)[-(total-choose)] % this->mod;
        }
        ll factorial::starbar(my_size_type stars, my_size_type bars) const {
            return this->comb(stars+bars, stars);
        }
    }
    namespace Utility{
        template<typename T> multiset<T>::iterator operator-=(multiset<T>& mp, const T& val){
            auto it = mp.find(val);
            if(it!=mp.end()){
                it = mp.erase(it);
            }
            return it;
        }
        template<typename T> multiset<T>::iterator operator+=(multiset<T>& mp, const T& val){
            return mp.insert(val);
        }
        template<typename T> T& setmax(T &x, const T& y){return x=(x>y?x:y);}
        template<typename T> T& setmin(T &x, const T& y){return x=(x<y?x:y);}
        template<typename T> void setless(T &x, T& y){if(x>y)swap(x,y);}
        template<typename T> void setmore(T &x, T& y){if(x<y)swap(x,y);}
        // // calculate mex of a sorted container, O(n) time
        // template<typename Container> my_size_type mex_sorted(const Container& c);
        // // calculate mex of a unsorted container, O(n) time, but slower than sorted
        // template<typename Container> my_size_type mex_general(const Container& c);
        // // calculate lps array, do (n-lps.back()) for period
        // template<typename Container> v<my_size_type> make_lps(const Container& c);
        v<int> compress_value(const v<int>& ar){
            v<int> b = ar;
            sort(b.begin(),b.end());
            b.erase(unique(b.begin(),b.end()), b.end());
            v<int> res(ar.size());
            for(ui i = 0; i<ar.size(); ++i){
                res[i] = lower_bound(b.begin(), b.end(), ar[i]) - b.begin();
            }
            return res;
        }
        // // count occurence of each value
        // map<int,int> count_occ(const v<int>& ar);

        // // Class for managing multiple return result branch
        // class return_message{
        // // currently everything is public for user's convenience
        // public:
        //     // current message number
        //     my_size_type value;
        //     // collection of message
        //     v<string> msgs{"NO", "YES"};
        //     // decide sending
        //     bool will_send = true;
        //     // 0 = "NO", 1 = "YES"
        //     return_message(my_size_type start_value = 0, bool autosend = true);
        //     // (if enabled) prints message on destruction
        //     ~return_message();
        //     // pick message index
        //     void setval(my_size_type new_value);
        //     // set/renew message at index
        //     void setmsg(my_size_type value, const string& new_msg);
        //     // (if enabled) prints message and disable this instance
        //     void flush();
        // };

        template<Container C> enumerate<C>::enumerate(C& c):ref(c){}
        template<Container C> enumerate<C>::Iterator::Iterator(my_size_type index, typename C::iterator it):index(index), it(it){}
        template<Container C> p<my_size_type, typename C::value_type&> enumerate<C>::Iterator::operator*() const {
            return {this->index, *it};
        }
        template<Container C> enumerate<C>::Iterator& enumerate<C>::Iterator::operator++() {
            this->index++;
            this->it++;
            return *this;
        }
        template<Container C> bool enumerate<C>::Iterator::operator!=(const Iterator& other) const {
            return this->index!=other.index;
        }
        template<Container C> enumerate<C>::Iterator enumerate<C>::begin(){
            return Iterator(0, ref.begin());
        }
        template<Container C> enumerate<C>::Iterator enumerate<C>::end(){
            return Iterator(ref.size(), ref.end());
        }
    }
#ifndef NYEMOT_UNPACK 
}
#endif

// END OF DEFINITION










// START OF SOLUTION

void solve();
void precompute();
enum TESTCASE{SINGLE = false, MULTIPLE = true};
bool multiple_testcase = TESTCASE::MULTIPLE;
int main(){
    auto start = std::chrono::high_resolution_clock::now(), prev=start, current=start;
    std::ios::sync_with_stdio(0); std::cin.tie(0); //cout.tie(0);
    precompute();
    if constexpr (debug_mode) {
        current = std::chrono::high_resolution_clock::now();
        auto time = current-prev;
        std::clog << "Precompute time: "<< std::chrono::duration_cast<std::chrono::milliseconds>(time).count() << " miliseconds\n";
        prev = current;
    }
    int t = 1;
    if (multiple_testcase == TESTCASE::MULTIPLE) std::cin>>t;
    if constexpr (debug_mode) {
        prev = current;
    }
    for (int tc = 1; tc <= t; ++tc) {
        solve();
        if constexpr (debug_mode) {
            current = std::chrono::high_resolution_clock::now();
            auto time = current-prev;
            std::clog << "Tescase #" << tc << " time: "<< std::chrono::duration_cast<std::chrono::milliseconds>(time).count() << " miliseconds\n";
            prev = current;
        }
    }
    if constexpr (debug_mode) {
        current = std::chrono::high_resolution_clock::now();
        auto time = current-start;
        // setup time (not precompute) wasn't printed, but included here
        std::clog << "Total time: "<< std::chrono::duration_cast<std::chrono::milliseconds>(time).count() << " miliseconds\n";
        prev = current;
    }
}
#ifndef NYEMOT_UNPACK 
    using namespace Competitive_Programming::Unpack;
#else
    using namespace Unpack;
#endif

// STARTCODINGHERE SCH

void precompute(){
    multiple_testcase = true;
}

void solve(){
    int n,q;
    cin,n,q;
    v<int> a(n);
    cin,a;
    sort(all(a),greater<int>());
    while(q--){
        int x;
        cin,x;
        int ans = 0;
        pq<int> leftover;
        int aidx = 0;
        while(x){
            int aval = aidx>=n?0:a[aidx];
            int lval = leftover.empty()?0:leftover.top();
            if(aval>=lval){
                aidx++;
            }else{
                leftover.pop();
            }
            int wval = max(aval,lval);
            int tbv = topbit(wval), tbx = topbit(x);
            if(tbv<tbx){
                ans += (1<<tbx) - wval;
                x -= (1<<tbx);
            }else if(tbv==tbx){
                wval -= 1<<tbx;
                x -= (1<<tbx);
                leftover.push(wval);
            }else{
                x = 0;
                break;
            }
        }
        cout,ans,'\n';
    }
    cout,'\n';
}