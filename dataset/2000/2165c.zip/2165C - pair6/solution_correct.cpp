#include <bits/stdc++.h>
#define int int64_t
#define f first
#define s second
#define opt1 ios_base::sync_with_stdio(false)
#define opt2 cin.tie(NULL)
#define optimize opt1; opt2
#define pb push_back
#define endl "\n"
#define sz(v) (int)v.size()
using namespace std;
typedef pair<int, int> ii;
typedef pair<int, ii> i3;
typedef pair<ii, ii> i4;
typedef pair<int, i4> i5;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<i3> vi3;
typedef vector<i4> vi4;
const int inf = 0x6f6f6f6f;
const int MAX = 500005;
const int LOG = 21;
const int mod = 998244353;

int a[MAX];

int32_t main () {
    optimize;
    int t;
    cin >> t;
    while (t--) {
        int n, q;
        cin >> n >> q;
        for (int i = 1; i <= n; i++)
            cin >> a[i];
        sort(a+1, a+n+1, greater<int>());
        for (int i = 1; i <= q; i++) {
            priority_queue <int> pq;
            for (int j = 1; j <= min(n, 40LL); j++)
                pq.push(a[j]);
            int c, ans = 0;
            cin >> c;
            for (int bit = 29; bit >= 0; bit--) {
                if ((1LL<<bit) & c) {
                    int x = pq.top();
                    pq.pop();
                    if ((1LL<<bit) > x) {
                        ans += (1LL<<bit) - x;
                        pq.push(0LL);
                    } else pq.push(x - (1LL<<bit));
                }
            }
            cout << ans << endl;
        }
    }
    return 0;
}
/*

1001001
1100011

*/