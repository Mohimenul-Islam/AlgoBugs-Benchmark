#include <bits/stdc++.h>
#include "ext/pb_ds/tree_policy.hpp"
#include "ext/pb_ds/assoc_container.hpp"
using namespace __gnu_pbds;
using namespace std;
//#define int long long
#define double long double
#define ordered_set tree<pair<int,int>, null_type, less<pair<int,int>>, rb_tree_tag, tree_order_statistics_node_update>

void solve();

signed main() {
    cout<<fixed<<setprecision(10);
#ifdef LOCAL
    freopen("in.txt", "r", stdin);
    freopen("out.txt", "w", stdout);
#else
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
#endif
    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
}

multiset<int> intersect(multiset<int> st1,multiset<int> st2){
    multiset<int> ans;
    while(!st1.empty()){
        if(st2.find(*st1.begin())!=st2.end()){
            st2.erase(st2.find(*st1.begin()));
            ans.insert(*st1.begin());
            
        }
        st1.erase(st1.begin());
    }
    return ans;
}

void solve() {
    int n,q;
    cin>>n>>q;
    vector<int> a(n);
    for(int i=0;i<n;i++) cin>>a[i];
    sort(a.rbegin(),a.rend());
    while(a.size()>70){
        a.pop_back();
        n--;
    }
    multiset<int,greater<>> st;
    for(auto i:a) st.insert(i);
    multiset<int,greater<>> ST=st;
    while(q--){
        int c;
        cin>>c;
        vector<int> pw;
        for(int j=0;j<32;j++){
            if(c%2==1){
                pw.push_back((1ll<<j));
            }
            c/=2;
        }
        reverse(pw.begin(),pw.end());
        int ans=0;
        for(auto i:pw){
            if(st.empty()){
                st.insert(0);
            }
            if(*st.begin()>i){
                int x=*st.begin()-i;
                st.erase(st.begin());
                st.insert(x);
                
            }
            else{
                ans+=(i-*st.begin());
                st.erase(st.begin());
                
            }
        }
        st=ST;
        cout<<ans<<' ';
    }
    cout<<"\n";
}