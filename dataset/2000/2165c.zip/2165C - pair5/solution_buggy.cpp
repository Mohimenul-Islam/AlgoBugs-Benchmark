#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=5e5+10,mod=998244353;
int n,q,t;
int a[N],cnt[N];
int b[32][N];
int f[5010][5010];
char s[N];
int col[N*2];
bool vis[N];
int que[N],r; 

signed main()
{
	cin>>t;
	while(t--)
	{
		cin>>n>>q;
		for(int i=1;i<=n;i++)
		{
			cin>>a[i];
		}
		for(int j=0;j<=n;j++) b[0][j]=j; 
		for(int i=1;i<=30;i++)
		{
			int v=(1<<i-1),lb=0;
			for(int j=1;j<=n;j++)
			{
				int k=b[i-1][j];
				if(a[k]&v) b[i][++lb]=k;
			}
//			cerr<<"\n";
			for(int j=1;j<=n;j++)
			{
				int k=b[i-1][j];
				if(!(a[k]&v)) b[i][++lb]=k;
			}
//			for(int j=1;j<=n;j++)
//			{
//				cerr<<a[b[i][j]]<<" ";
//			}
//			cerr<<"\n";
		}
		for(int i=1;i<=q;i++)
		{
			int ans=0;
			int x;
			cin>>x;
			for(int j=30;j;j--)
			{
				int v=(1<<j-1);
				int pos=0,pos1=0,pd=1;
				for(int k=1;k<=n;k++)
				{
					if(vis[b[j][k]]) continue;
					if(!pos)pos=b[j][k];
					else
					{
						pos1=b[j][k];
						break;
					}
				}
				if(!(x&v) && (a[pos]&v))
				{
					break;
				}
				if(!(x&v)) continue;
				if(!pos)
				{
					ans=ans+v;
					continue;
				}
				if(a[pos1]&v) break;
				if(a[pos]&v) continue;
				vis[pos]=1;
				ans+=v-a[pos];
				que[++r]=pos;
			}
			cerr<<" ";
			cout<<ans<<"\n";
			while(r)
			{
				vis[que[r]]=0;
				r--;
			}
		}
	}
}
