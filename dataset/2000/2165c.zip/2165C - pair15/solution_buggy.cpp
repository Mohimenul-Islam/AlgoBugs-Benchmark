#include "bits/stdc++.h"

#ifdef LOCAL
#include "dbg.h"
#else
#define dbg(...) 0
#endif

using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;

mt19937 rng(1);
int randInt(int L, int R) {
    uniform_int_distribution<int> dis(L, R);
    return dis(rng);
}

void solve(string testType, int testCase) {
    int n, q;
    cin >> n >> q;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    sort(a.begin() + 1, a.end());
    vector<vector<int>> vals(31);
    for (int i = 1; i <= n; i++) {
        int h = bit_width((unsigned int)a[i]);
        vals[h].push_back(a[i]);
    }
    vector<vector<int>> used(31), extra(31);
    for (int _ = 1, c; _ <= q; _++) {
        cin >> c;
        auto count = [&](int i) {
            return vals[i].size() + extra[i].size();
        };
        auto get = [&](int i) {
            int res = 0;
            if (vals[i].empty() || (!extra[i].empty() && extra[i].back() > vals[i].back())) {
                res = extra[i].back();
                extra[i].pop_back();
            } else {
                res = vals[i].back();
                vals[i].pop_back();
                used[i].push_back(res);
            }
            return res;
        };
        auto insert = [&](int x) {
            int i = bit_width((unsigned int)x);
            extra[i].insert(lower_bound(extra[i].begin(), extra[i].end(), x), x);
        };
        int ans = 0;
        for (int i = 30, j = 30; i >= 1; i--) {
            int bit = c >> (i - 1) & 1;
            if (count(i) > bit) break;
            if (!bit) continue;
            if (count(i)) {
                int x = get(i);
                x ^= 1 << i;
                insert(x);
            } else {
                while (j >= 1 && !count(j)) {
                    j--;
                }
                if (j == 0) {
                    ans += (1 << (i - 1));
                } else {
                    int x = get(j);
                    ans += (1 << (i - 1)) - x;
                }
            }
        }
        for (int i = 1; i <= 30; i++) {
            while (!used[i].empty()) {
                vals[i].push_back(used[i].back());
                used[i].pop_back();
            }
            extra[i].clear();
        }
        cout << ans << '\n';
    }
}

signed main() {
    cin.sync_with_stdio(0);
    cin.tie(0);
    cin.exceptions(cin.failbit);
#ifdef LOCAL
    ifstream in("in");
    if (!in) {
        std::cerr << "Could not open in\n";
        return 1;
    }
    cin.rdbuf(in.rdbuf());
#endif
    string testType;
    int numTests = 1;
    cin >> numTests;
    // cin >> testType >> numTests;
    for (int i = 1; i <= numTests; i++) {
        solve(testType, i);
    }
    return 0;
}