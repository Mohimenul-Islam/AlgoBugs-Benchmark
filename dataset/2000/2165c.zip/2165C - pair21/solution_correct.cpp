#include<bits/stdc++.h>
#define PII pair<int,int>
#define int long long
using namespace std;
const int N=5e5+10;
int a[N],vis[N];
signed main(){
	int T;
	cin>>T;
	while(T--){
		int n,m;
		cin>>n>>m;
		for(int i=1;i<=n;i++)cin>>a[i];
		multiset<PII>s;
		for(int i=1;i<=n;i++)s.insert({a[i],i}),vis[i]=-1;
		while(m--){
			int x,ans=0;
			cin>>x;
			vector<int>v;
			for(int i=30;i>=0;i--){
				PII t=*(--s.end());
				if(x>>i&1){
					s.erase(t);
					v.push_back(t.second);
					if(t.first>(1<<i)){
						vis[t.second]=t.first-(1<<i);
						s.insert({t.first-(1<<i),t.second});
					}
					else{
						s.insert({0,t.second});
						vis[t.second]=0;
						ans+=(1<<i)-t.first;
					}
				}
				else if(t.first>(1<<i))break;
			}
			for(int i:v)if(vis[i]!=-1){
				s.insert({a[i],i});
				s.erase(s.lower_bound({vis[i],i}));
				vis[i]=-1;
			}
			cout<<ans<<'\n';
		}
	}
	return 0;
}
