#include <bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'
typedef pair<int, int> pii;
const int INF = 1e18;
const int N = 5e5 + 5, mod = 998244353;
int n, m;
int a[N];

int query(int x)
{
	priority_queue<int> q;
	for (int i = 1; i <= n && i <= 60; i++)
		q.push(a[i]);
	int res = 0;
	while (x)
	{
		int t = log2(x);
		int num = q.top();
		q.pop();
		if (num >= x)
			return res;
		else if (num >= (1 << t))
		{
			num -= 1 << t;
			x -= 1 << t;
			if (num)
				q.push(num);
		}
		else
		{
			x -= 1 << t;
			res += (1 << t) - num;
		}
	}
	return res;
}
void solve()
{
	cin >> n >> m;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	sort(a + 1, a + n + 1, greater<int>());
	while (m--)
	{
		int x;
		cin >> x;
		cout << query(x) << endl;
	}
}
signed main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int _ = 1;
	cin >> _;
	while (_--)
		solve();
}
