#include<bits/stdc++.h>
using namespace std;
int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int t, tc = 0; cin >> t; while (t--) {
        tc++;
     int n, q; cin >> n >> q;
     int a[n + 1];
     set<pair<int, int>> se;
     for (int i = 1; i <= n; i++) {
        cin >> a[i];
        se.insert({a[i], i});
    } 
    // if (tc == 4195) {

    //     for (int i = 1; i <= n; i++) if (a[i] != 0) cout << a[i] << 'v';
    // }
     while (q--) {
         int c, ans = 0; cin >> c;
         if (tc == 4195) {
            cout << c << 'p';
            break;
         }
         set<int> sein;
         set<pair<int, int>> nw;
                                                                                 
         while (c) {
            auto [vl, in] = *(--se.end());
            if (c <= vl) {
                c = 0;
                break;
            }
            int rin, tin;
            bitset<31> raw(c), tmp(vl);
            for (int j = 0; j <= 30; j++) {
                if (raw[j]) rin = j;
            }
            for (int j = 0; j <= 30; j++) {
                if (tmp[j]) tin = j;
            }
            se.erase({vl, in});
            sein.insert(in);
            if (rin == tin) {
                 c -= (1 << rin);
                 vl -= (1 << rin);
                 se.insert({vl, in});
                 nw.insert({vl, in});
            }
            else {
                c -= (1 << rin);
                ans += (1 << rin) - vl;
               // cout << ans << ' ' << (*(--se.end())).first << '\n';
            }
            if (se.size() == 0) break;
         }

         ans += c;
         cout << ans << '\n';
         for (auto [x, y]: nw) {
            se.erase({x, y});
         }
         for (auto x: sein) se.insert({a[x], x});
     }
     
     }

    return 0;
    }