#include <bits/stdc++.h>
using namespace std;

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
template<class T> using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template<class T> using ordered_multiset = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>; 
#define ll          long long
#define int         long long
#define lld         long double
#define ull         unsigned long long
#define endl        '\n'
#define sp          ' '
#define pb          push_back
#define vi          vector<int>
#define vvi         vector<vi>
#define vll         vector<ll>
#define vvll        vector<vll>
#define s           second
#define f           first
#define all(c)      c.begin(),c.end()
#define rall(c)     c.rbegin(),c.rend()
#define print(a)    for(auto it : a){cout << it << sp;}cout << endl;
#define print2(a)   for(auto list : a){print(list)}
#define ai(sz)      array<int,sz> 
#define vai(sz)     vector<ai(sz)>
#define vvai(sz)    vector<vai(sz)>
#define len(x)      (int)x.size()
#define input(a)    for(auto &ele:a) cin>>ele;
#define vnpt(a,n)   vi a(n);input(a);
#define sum(a)      accumulate(all(a),0);

#define forn(i, n, step)        for(i=0;i<n;i+=step)
#define possible(condition)     cout << (condition ? "YES" : "NO") << endl;
#define printmp(dictionary)     for(auto it : dictionary){cout << it.f << ":" << it.s << ", ";}cout << endl;

#ifndef ONLINE_JUDGE
#define startTimer std::chrono::time_point<std::chrono::high_resolution_clock> start, end;start = std::chrono::high_resolution_clock::now();
#define endTimer end = std::chrono::high_resolution_clock::now(); long long elapsed_time = std::chrono::duration_cast<std::chrono::milliseconds>(end-start).count();cerr << "Elpased Time : " << elapsed_time << "ms"<< endl;
#else
#define debug(x)
#define startTimer
#define endTimer
#endif
 
constexpr int mod = 1e9 + 7;

void solve() {
    int n,qry;
    cin >> n >> qry;
    vnpt(a,n);
    sort(rall(a));
    while(len(a) > 30)
        a.pop_back();
    for(int q = 0;q<qry;q++){
        int x;
        cin >> x;
        vi temp = a;
        int total = 0;
        for(int i = 30;i>=0;i--){
            int bit = (1<<i);
            if((bit&x) == 0)continue;
            int mx = 0;
            int idx = -1;
            bool fl = false;
            for(int j = 0;j<len(temp);j++){
                if(bit <= temp[j]){
                    temp[j] -= bit;
                    fl = true;
                    break;
                }
                if(temp[j] > mx){
                    mx = temp[j];
                    idx = j;
                }
            }
            if(fl)continue;
            total += bit-mx;
            temp[idx] = 0;
        }
        cout << total << endl;
    }

}

int32_t main () {
    startTimer
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int tt=1;
    cin>>tt;     
    while (tt--) {                
        solve();
    }
    endTimer
    return 0;
}