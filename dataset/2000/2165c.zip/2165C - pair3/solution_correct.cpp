//UPDATERA ARRAY STORLEKEN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
 
const ll INF=1e15;
const ll MAXN=200006;//UPDATERA ARRAY STORLEKEN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
ll t,n,ans,q;

void solve(){
    cin>>n>>q;
    multiset<ll> S;
    for(int i=1;i<=n;i++){
        ll a;
        cin>>a;
        S.insert(a);//S,only need to store greatest 30 ish

        if(S.size()>60){
            S.erase(S.begin());
        }
    }

    while(q--){
        ans=0;
        ll x;
        cin>>x;
        multiset<ll> removed,added;

        for(int i=30;i>=0;i--){
            if(x&(1<<i)){
                ll maxi=*(--S.end());
                S.erase(S.find(maxi));
                removed.insert(maxi);

                if(maxi<(1<<i)){
                    ans+=(1<<i)-maxi;
                    maxi+=(1<<i)-maxi;
                }

                maxi-=(1<<i);
                added.insert(maxi);
                S.insert(maxi);
            }
        }
        cout<<ans<<'\n';

        for(auto& i:removed){
            if(added.find(i)!=added.end()){
                added.erase(added.find(i));
            }else{
                S.insert(i);
            }
        }
        for(auto& i:added){
            S.erase(S.find(i));
        }
    }
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>t;
    while(t--){
        solve();
    }
}