//UPDATERA ARRAY STORLEKEN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
 
const ll INF=1e15;
const ll MAXN=200006;//UPDATERA ARRAY STORLEKEN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
ll t,n,ans,q;

void solve(){
    cin>>n>>q;
    multiset<ll> S;
    for(int i=1;i<=n;i++){
        ll a;
        cin>>a;
        S.insert(a);
    }

    while(q--){
        ans=0;
        ll x;
        cin>>x;

        multiset<ll> removed,added;

        for(int i=30;i>=0;i--){
            if(x&(1<<i)){
                ll maxi=*(--S.end());
                S.erase(S.find(maxi));
                removed.insert(maxi);

                if(maxi<(1<<i)){
                    ans+=(1<<i)-maxi;
                    maxi+=(1<<i)-maxi;
                }

                maxi-=(1<<i);
                added.insert(maxi);
                S.insert(maxi);
            }
        }

        cout<<ans<<'\n';

        for(auto it = removed.begin(), end = removed.end(); it != end; ++it){
            if(added.find(*it)!=added.end()){
                added.erase(it);
            }else{
                S.insert(*it);
            }
        }
        for(auto it = added.begin(), end = added.end(); it != end; ++it){
            S.erase(S.find(*it));
        }
    }
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>t;
    while(t--){
        solve();
    }
}