#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
//#pragma GCC optimize("Ofast")
//#pragma GCC target("avx,avx2,fma")
using namespace std;
using namespace __gnu_pbds;
#define ll long long
#define ordered_set tree<long long, null_type, less<long long>, rb_tree_tag, tree_order_statistics_node_update>
#define sped_up ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define pb push_back
#define S second
#define F first
const ll INF = (ll)1e9 + 1, INFL = (ll)1e18 + 1;
const ll mod = (ll)1e9 + 7, MAXN = (ll)1e6 + 1;
ll a[MAXN];
int main() {
    sped_up;
    ll t;
    cin >> t;
    while (t--) {
        ll n, q;
        cin >> n >> q;
        stack <ll> del, add;
        multiset <ll> m;
        for (int i = 1; i <= n; i++) cin >> a[i], m.insert(a[i]);
        while (q--) {
            ll c;
            cin >> c;
            ll orr = 0, cnt = 0;
            for (int i = 29; i >= 0; i--) {
                if (!((orr >> i) & 1)) {
                    if (((c >> i) & 1)) {
                        ll x = *m.rbegin();
                        if (x >= (1 << (i + 1))) break;
                        cnt += max(0ll, (1 << i) - x);
                        orr |= (1 << i);
                        m.insert(max(0ll, x - (1 << i)));
                        del.push(max(0ll, x - (1 << i)));
                        add.push(x);
                        m.erase(m.find(x));
                    }
                }
            }
            while (!add.empty()) {
                ll v = add.top();
                m.insert(v);
                add.pop();
            }
            while (!del.empty()) {
                ll v = del.top();
                m.erase(m.find(v));
                del.pop();
            }
            cout << cnt << '\n';
        }
    }
}