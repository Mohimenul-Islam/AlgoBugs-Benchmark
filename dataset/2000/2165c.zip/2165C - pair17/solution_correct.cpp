#include <vector>
#include <algorithm>
#include <string>
#include <iostream>
#include <cmath>
#include <tuple>
#include <set>
#include <functional>
#include <numeric>
#include <queue>
#include <iomanip>
#define int long long
using namespace std;
const int inf = numeric_limits<int>::max();

signed main() {
    // ios_base::sync_with_stdio(0);
    // cin.tie(0);
    int t;
    cin>>t;
    while(t--){
        int n,q;
        cin>>n>>q;
        vector<int> ar(n);
        for(auto &e : ar){
            cin>>e;
        }
        sort(ar.rbegin(), ar.rend());
        multiset<int> a;
        for(int i = 0; i<min(n, (long long)40); i++){
            a.insert(ar[i]);
        }
        queue<int> add;
        queue<int> remove;
        int c;
        while(q--){
            cin>>c;
            int ans = 0;
            for(int i = 30; i>=0; i--){
                if((c&(1<<i)) == 0) continue;
                auto it = a.lower_bound((1<<i));
                if(it == a.end()){
                    //add
                    int el = *(a.rbegin());
                    ans += ((1<<i)-el);
                    remove.push(el);
                    add.push(0);
                    a.erase(a.find(el));
                    a.insert(0);
                }
                else{
                    int el = *(it);
                    a.erase(it);
                    remove.push(el);
                    add.push(el-(1<<i));
                    a.insert(el-(1<<i));
                }
            }

            while(!remove.empty()){
                a.insert(remove.front());
                remove.pop();
            }

            while(!add.empty()){
                a.erase(a.find(add.front()));
                add.pop();
            }


            cout<<ans<<"\n";
        }
    }
}