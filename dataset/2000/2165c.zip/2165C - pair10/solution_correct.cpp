#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#include <ext/pb_ds/hash_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define int long long
//#define endl '\n'
#define N 500005
#define INF (int)1e18
#define MOD 998244353
typedef tree<pair<int, int>, null_type, less<pair<int, int>>, 
             rb_tree_tag, tree_order_statistics_node_update> ordered_multiset;
int qpow(int a,int b){
	int ans=1;a%=MOD;
	while(b){
		if(b&1){
			ans*=a;ans%=MOD;
		}
		a*=a;a%=MOD;
		b>>=1; 
	}
	return ans;
}
int gcd(int a, int b) {
    while (b) {
        a %= b;swap(a, b);
    }
    return a;
}
int lcm(int a,int b){
	return a/gcd(a,b)*b;
}
int heighestbit(int a){
	if(a==0)return a;
	a|=a>>1;
	a|=a>>2;
	a|=a>>4;
	a|=a>>8;
	a|=a>>16;
	return (a+1)>>1;
}
//ordered_multiset oms;
//oms.insert({-INF,-INF});
//int val=(*oms.find_by_order(k)).first;(查询第k小)
//int kth=oms.order_of_key({x, -1});
//gp_hash_table<int,int> mp;(不能count 要find)
int v[N];
void solve(void){
	priority_queue<int>que;
	int n,q;cin>>n>>q;
	for(int i=1;i<=n;i++)cin>>v[i];
	sort(v+1,v+1+n,[](int a,int b){
		return a>b;
	});
	for(int i=1;i<=q;i++){
		int a;cin>>a;
		if(v[1]==0){
			cout<<a<<endl;
			continue;
		}
		int sum=0;
		priority_queue<int>que;
		for(int j=1;j<=n;j++){
			//cout<<a<<' '<<sum<<endl;
			que.push(v[j]);
			if(que.top()>=a){
				cout<<sum<<endl;
				break;
			}
			else{
				int b=heighestbit(a);
				//cout<<b<<endl;
				int c=que.top();
				if(b>c){
					que.pop();
					//cout<<b<<' '<<c<<endl;
					sum+=b-c;
					a-=b;
				}
				else{
					que.pop();
					c-=b;
					a-=b;
					if(c>0)que.push(c);
				}
			}
			//cout<<a<<' '<<sum<<endl;
			if(j==n){
				while(!que.empty()){
					if(que.top()>=a){
						cout<<sum<<endl;
						break;
					}
					else{
						int b=heighestbit(a);
						//cout<<b<<endl;
						int c=que.top();
						if(b>c){
							que.pop();
							//cout<<b<<' '<<c<<endl;
							sum+=b-c;
							a-=b;
						}
						else{
							que.pop();
							c-=b;
							a-=b;
							if(c>0)que.push(c);
						}
					}
				}
				sum+=a;
				cout<<sum<<endl;
			}
		}
		//cout<<1<<endl;
	}
}
signed main() {
    ios::sync_with_stdio(false);
	cin.tie(nullptr); 
    int T=1;cin>>T;
    while(T--)solve();
    return 0;
}