#include <bits/stdc++.h>
using namespace std;

int main(){
    int TT;
    cin>>TT;
    while(TT--){
        int N,Q;
        cin>>N>>Q;
        multiset<int> st;
        vector<int> Ans = {};
        for(int i=0;i<N;i++){
            int a;
            cin>>a;
            Ans.push_back(a);
        }
        sort(Ans.rbegin(),Ans.rend());
        while(Ans.size() > 30) Ans.pop_back();
        for(int x:Ans) st.insert(x);
        while(Q--){
            int C;
            cin>>C;
            vector<int> dl = {}, in = {};
            int ans = 0;
            for(int i=29;i>=0;i--)if(C&(1<<i)){
                auto it = st.lower_bound(1<<i);
                if(it == st.end()) it--;
                int a = *it;
                dl.emplace_back(a);
                st.erase(it);
                ans += max(0,(1<<i)-a);
                a = max(0,a-(1<<i));
                in.emplace_back(a);
                st.insert(a);
            }
            cout<<ans<<'\n';
            for(int i=in.size()-1;i>=0;i--){
                int a = in[i], b = dl[i];
                st.insert(b);
                st.erase(st.find(a));
            }
        }
    }
}
