#include<bits/stdc++.h>
#define rep(i,a,b) for(int i=(a);i<=(int)(b);i++)
#define per(i,a,b) for(int i=(a);i>=(int)(b);i--)
#define clz __builtin_clz
#define lg(x) (clz(1)-clz(x))
#define inf 2e9
#define pb emplace_back
using namespace std;
using vii=vector<int>;

void solve()
{
    int n,q;
    cin>>n>>q;
    vii a(n+1,0);
    rep(i,1,n) cin>>a[i];
    sort(a.begin()+1,a.end(),[](int x,int y){return x>y;});
    rep(_,1,q)
    {
        int c,res=2e9,sum=0; cin>>c;
        rep(i,1,n)
        {
            int cur=(1<<lg(c));
            if(c<=a[i])
            {
                res=min(res,sum);
                break;
            }
            res=min(res,sum+c-a[i]);
            if(cur<=a[i])
            {
                int tt=cur;
                per(j,lg(c)-1,0) if(((c>>j)&1)&&(tt|(1<<j))<=a[i]) tt|=(1<<j);
                c^=tt;
            }
            else
            {
                sum+=cur-a[i];
                c^=cur;
            }
        }
        cout<<res<<'\n';
    }
}
signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int T;
    cin>>T;
    while(T--) solve();
    return 0;
}