#include<bits/stdc++.h>
#define rep(i,a,b) for(int i=(a);i<=(int)(b);i++)
#define per(i,a,b) for(int i=(a);i>=(int)(b);i--)
#define mkp make_pair
#define clz __builtin_clz
#define lg(x) (clz(1)-clz(x))
#define inf 2e9
#define pb emplace_back
using namespace std;
using vii=vector<int>;

void solve()
{
    int n,q;
    cin>>n>>q;
    vii a(n+1,0),b(n+1,0);
    rep(i,1,n) cin>>a[i];
    set<pair<int,int>> ss;
    rep(i,1,n) ss.insert(mkp(a[i],i));
    rep(_,1,q)
    {
        vii usd;
        int c,res=0; cin>>c;
        per(i,29,0)
            if((c>>i)&1)
            {
                int cur=(1<<i);
                auto [val,x]=(*--ss.end());
                if(a[x]==val) usd.pb(x);
                ss.erase(mkp(val,x));
                if(val<cur) res+=cur-val;
                val=max(0,val-cur);
                b[x]=val;
                ss.insert(mkp(val,x));
            }
        for(auto x:usd) ss.erase(mkp(b[x],x)),ss.insert(mkp(a[x],x)),b[x]=0;
        cout<<res<<'\n';
    }
}
signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int T;
    cin>>T;
    while(T--) solve();
    return 0;
}