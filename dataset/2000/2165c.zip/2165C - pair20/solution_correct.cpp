#include <bits/stdc++.h>


using namespace std;
using ll = long long;
using vi = vector<int>;


void init(){

}


void solve(){
    int n = 0; cin >> n;
    int q = 0; cin >> q;
    vi a(n); for (int& x: a) { cin >> x; }
    vi ct(30);
    for (int x: a){
        for (int b = 0; b != 30; ++b){
            ct[b] += (x >> b) % 2;
        }
    }
    sort(a.begin(), a.end(), greater<int>());
    int m = min(n, 31);
    vi aa(m);

    for (int t = 0; t != q; ++t){
        for (int i = 0; i != m; ++i){
            aa[i] = a[i];
        }
        vi ctnew = ct;
        int c = 0; cin >> c;
        int res = 0;
        for (int b = 29; b >= 0; --b){
            int t = ((c >> b) & 1);
            if (ctnew[b] > t){
                break;
            } else if (ctnew[b] == t){
                continue;
            } else {
                int minadd = 1e9 + 5;
                int argmin = 0;
                int tmp = 1 << b;
                for (int i = 0; i != m; ++i){
                    if (tmp - aa[i] % tmp < minadd){
                        minadd = tmp - aa[i] % tmp;
                        argmin = i;
                    }
                }
                for (int d = 0; d != b; ++d){
                    ctnew[d] -= (aa[argmin] >> d) % 2;
                }
                aa[argmin] = 0;
                res += minadd;
            }
        }
        cout << res << "\n";
    }
}


int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    init();
    int t = 1; cin >> t;
    while (t--) { solve(); }
}