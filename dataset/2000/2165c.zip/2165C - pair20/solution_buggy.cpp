#include <bits/stdc++.h>


using namespace std;
using ll = long long;
using vi = vector<int>;


void init(){

}


void solve(){
    int n = 0; cin >> n;
    int q = 0; cin >> q;
    vi a(n); for (int& x: a) { cin >> x; }
    vi ct(30);
    for (int x: a){
        for (int b = 0; b != 30; ++b){
            if ((x >> b) & 1){
                ++ct[b];
            }
        }
    }
    vector<set<pair<int, int>>> vst(30);
    for (int b = 0; b != 30; ++b){
        int t = (1 << b);
        vector<pair<int, int>> vp(n);
        for (int i = 0; i != n; ++i){
            int x = a[i];
            vp[i] = pair<int, int>(x % t, i);
        }
        sort(vp.begin(), vp.end(), greater<pair<int, int>>());
        for (int i = 0; i < min(n, 32); ++i){
            vst[b].insert(vp[i]);
        }
    }

    for (int t = 0; t != q; ++t){
        vi ctnew = ct;
        vector<set<pair<int, int>>> vst_copy = vst;
        int c = 0; cin >> c;
        ll res = 0;
        vector<pair<int, int>> removed_ib;
        for (int b = 29; b >= 0; --b){
            if (ctnew[b] >= 2){
                break;
            }
            if ((c >> b) % 2 != ctnew[b] % 2){
                if (ctnew[b]){
                    break;
                }
                if ((int)removed_ib.size() == n){
                    res += (1 << b);
                    continue;
                }
                assert(!vst_copy[b].empty());
                int i = vst_copy[b].rbegin() -> second;
                // erase i
                for (int d = 0; d != b; ++d){
                    int t = (1 << d);
                    vst_copy[d].erase(pair<int, int>(a[i] % t, i));
                    ctnew[d] -= (a[i] >> d) % 2;
                }
                int t = 1 << b;
                res += t - a[i] % t;
            }
        }
        cout << res << "\n";
    }
}


int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    init();
    int t = 1; cin >> t;
    while (t--) { solve(); }
}