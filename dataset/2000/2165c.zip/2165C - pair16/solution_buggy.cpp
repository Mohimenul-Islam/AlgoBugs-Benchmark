#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;

#define int long long

constexpr long long INF  = 1e18;
constexpr long long MOD  = 1'000'000'007;
constexpr long double PI = 3.14159265358979323846L;
constexpr int N = 2e5 + 5;

using ll  = long long;
using ld  = long double;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using vi  = vector<int>;
using vll = vector<ll>;
using vpi = vector<pii>;
using vpl = vector<pll>;

#define all(x)  begin(x), end(x)
#define rall(x) rbegin(x), rend(x)
#define ff      first
#define ss      second
#define pb      push_back
#define eb      emplace_back
#define mp      make_pair
#define nl      cout << "\n"

#define rep(i,a,b)   for (ll i = (a); i < (b); i++)
#define rrep(i,a,b)  for (ll i = (a); i >= (b); i--)
#define fr(i,n)      for (ll i = 0; i < (n); i++)
#define each(x, a)   for (auto &x : a)

#define fastio ios::sync_with_stdio(false); cin.tie(nullptr)

#ifdef LOCAL
    #define dbg(x) cerr << #x << " = " << (x) << "\n"
#else
    #define dbg(x)
#endif

ll mod_add(ll a, ll b, ll m = MOD) { return (a % m + b % m) % m; }
ll mod_sub(ll a, ll b, ll m = MOD) { return (a % m - b % m + m) % m; }
ll mod_mul(ll a, ll b, ll m = MOD) { return (a % m * b % m) % m; }
ll mod_pow(ll a, ll e, ll m = MOD) {
    ll res = 1;
    while (e > 0) {
        if (e & 1) res = mod_mul(res, a, m);
        a = mod_mul(a, a, m);
        e >>= 1;
    }
    return res;
}
ll mod_inv(ll a, ll m = MOD) { return mod_pow(a, m - 2, m); }

// Sieve of Eratosthenes
vi pr;
bitset<N> is_prime;
void sieve(int mx = N - 1) {
    is_prime.set();
    is_prime[0] = is_prime[1] = 0;
    for (int i = 2; i <= mx; i++) {
        if (is_prime[i]) {
            pr.pb(i);
            for (int j = i * i; j <= mx; j += i) is_prime[j] = 0;
        }
    }
}

// nCr with precomputation
ll fact[N], inv_fact[N];
void pre_ncr() {
    fact[0] = 1;
    rep(i, 1, N) fact[i] = mod_mul(fact[i-1], i);
    inv_fact[N-1] = mod_inv(fact[N-1]);
    rrep(i, N-2, 0) inv_fact[i] = mod_mul(inv_fact[i+1], i+1);
}
ll ncr(ll n, ll r) {
    if (r < 0 || r > n) return 0;
    return mod_mul(fact[n], mod_mul(inv_fact[r], inv_fact[n-r]));
}

// Precompute all factors
vector<int> factors[N];
void pre_factors() {
    rep(i, 1, N) {
        for (int j = i; j < N; j += i) {
            factors[j].pb(i);
        }
    }
}

// Ordered Set (uncomment when needed)
// template <class T>
// using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

struct DSU {
    vector<int> parent, sz;
    DSU(int n) {
        parent.resize(n);
        sz.assign(n, 1);
        iota(all(parent), 0);
    }
    int find(int x) {
        return parent[x] == x ? x : parent[x] = find(parent[x]);
    }
    bool unite(int a, int b) {
        a = find(a); b = find(b);
        if (a == b) return false;
        if (sz[a] < sz[b]) swap(a, b);
        parent[b] = a;
        sz[a] += sz[b];
        return true;
    }
};
/*
if ith bit of c is set it can use the msb of any a[i] or if any msb is left unused then no need to check further as it can be made if any msb is not
available i can add the cost of the biggest number of a certain msb
*/
void solve() {
    int n,q;
    cin>>n>>q;
    vector<vi> m(31);
    int z=0;
    fr(i,n){
        int a;
        cin>>a;
        if(a==0) z++;
        else m[__lg(a)].pb(a);
    }
    fr(i,31) sort(all(m[i]));
    fr(i,q){
        int c;
        cin>>c;
        int ans=0;
        vector<vi> g=m;
        int cz=z;
        rrep(j,29,0){
            if((c>>j)&1){
                if(g[j].size()){
                    g[j].pop_back(); 
                }else{
                    int mx=-1,mb=-1;
                    rrep(k,j-1,0){
                        if(g[k].size()&&g[k].back()>mx){
                            mx=g[k].back();
                            mb=k;
                        }
                    }
                    if(mb!=-1){
                        ans+=(1LL<<j)-mx;
                        g[mb].pop_back();
                    }else if(cz){
                        ans+=(1LL<<j);
                        cz--;
                    }
                }
            }else{
                if(g[j].size()) break;
            }
        }
        cout<<ans;nl;
    }
}

signed main() {
    fastio;
    int t = 1;
    cin >> t;
    while (t--) solve();
    return 0;
}