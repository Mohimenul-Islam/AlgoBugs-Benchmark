#include<bits/stdc++.h>
using namespace std;
int n,q,a[500005],b[35];
bool cmp(int x,int y){ return x>y; }
void work(){
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	sort(a+1,a+n+1,cmp);
	int m=min(n,31);
	while(q--){
		int c;
		scanf("%d",&c);
		for(int i=1;i<=m;i++) b[i]=a[i];
		int ans=0;
		for(int i=29;i>=0;i--){
			int val=c&(1<<i);
			if(!val) continue;
			int id=0,flag=0;
			for(int j=1;j<=m;j++){
				if(b[j]>=val){
					b[j]-=val,flag=1;
					break;
				}
				id=(b[j]>=b[id]?j:id);
			}
			if(flag) continue;
			ans+=val-b[id],b[id]=0;
		}
		printf("%d\n",ans);
	}
}
int main(){
	int _;
	scanf("%d",&_);
	while(_--) work();
}