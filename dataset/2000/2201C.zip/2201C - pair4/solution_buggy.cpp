#pragma GCC optimize("Ofast")
#pragma GCC optimize("O3,unroll-loops")
#include <bits/stdc++.h>
#define int long long

using namespace std;

constexpr int mod = 998244353;
int sp[20][500000];
int lg[500001];

int get(int l,int r){
    int x = lg[r-l+1];
    return min(sp[x][l],sp[x][r-(1<<x)+1]);
}

struct seg_tree{
    vector<int>tree;
    void update(int l,int r,int v,int ps,int vl){
        if(l > ps || r < ps){
            return;
        }
        if(l == r){
            tree[v] = vl;
            return;
        }
        int m = (l+r)/2;
        update(l,m,v*2,ps,vl);
        update(m+1,r,v*2+1,ps,vl);
        tree[v] = tree[v*2]+tree[v*2+1];
        tree[v] %= mod;
    }
    int get(int l,int r,int v,int ql,int qr){
        if(l > qr || r < ql){
            return 0;
        }
        if(l >= ql && r <= qr){
            return tree[v];
        }
        int m = (l+r)/2;
        return (get(l,m,v*2,ql,qr)+get(m+1,r,v*2+1,ql,qr))%mod;
    }
};

int bp(int a,int p){
    if(p == 0){
        return 1;
    }
    if(p&1){
        return (a*bp(a,p-1))%mod;
    }
    int x = bp(a,p/2);
    return (x*x)%mod;
}

int32_t main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    lg[0] = 0;
    lg[1] = 0;
    for(int i = 2;i<=500000;i++){
        lg[i] = lg[i/2]+1;
    }

    int t = 1;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        string s;
        cin>>s;
        seg_tree t;
        t.tree.resize(n*4);
        int a[n];
        a[0] = 1;
        sp[0][0] = 1;
        for(int i = 1;i<n;i++){
            a[i] = a[i-1];
            if(s[i] == '('){
                a[i]++;
            }
            else{
                a[i]--;
            }
            sp[0][i] = a[i];
        }
        for(int i = 1;i<19;i++){
            for(int j = 0;j<n;j++){
                if(j+(1<<(i-1)) >= n){
                    sp[i][j] = sp[i-1][j];
                }
                else{
                    sp[i][j] = min(sp[i-1][j],sp[i-1][j+(1<<(i-1))]);
                }
            }
        }
        int ans = 0;
        int x = 1;
        for(int i = 0;i<n;i++){
            if(s[i] == '('){
                ans += x;
            }
            x *= 2;
            x %= mod;
        }
        for(int i = n-1;i>=0;i--){
            int ansi = 0;
            if(s[i] == ')'){
                ansi = 1;
                ansi += t.get(0,n-1,1,i+1,n-1);
            }
            else{
                int l = i-1,r = n-1;
                while(r-l > 1){
                    int m = (l+r)/2;
                    if(get(i,m) > 1){
                        l = m;
                    }
                    else{
                        r = m;
                    }
                }
                ansi = t.get(0,n-1,1,i,l+1);
            }
            t.update(0,n-1,1,i,ansi);
            ans += ansi;
            //cout<<i<<' '<<ansi<<endl;
        }
        cout<<ans<<endl;
    }
}

