#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define all(a) a.begin(), a.end()
#define allr(a) a.rbegin(), a.rend()
#define Yes cout << "Yes\n"
#define No cout << "No\n"
#define YES cout << "YES\n"
#define NO cout << "NO\n"
#define check cout << "CHECK\n";
const ll Nm = 1e17, MOD = 1e9+7;
const ll ze = 0, mod = 998244353;

/* Observations
        
***/

void printBinary(ll n, ll c){
        for(ll i = c; i >= 0; --i)
                cout << ((n>>i)&1);
        cout << endl;
}

ll binExpo(ll a, ll n){
        ll res = 1;
        while(n > 0){
                if(n & 1) res = (res * a) % mod;
                a = (a * a) % mod;
                n >>= 1;
        }
        return res;
}

void main_sol(){
        ll n; cin >> n;
        string s; cin >> s;
        ll ans = 0, preR = 0, preL = 0;
        ll ct = 0, cnt = 0;
        for(ll i = 0; i < n; ++i){
                ll temp = 0;
                if(s[i] == ')'){
                        if(i > 0 && s[i-1] == ')'){
                                temp = (preR + preL + 1 + temp) % mod;
                        }else{
                                // sLast = ((binExpo(2, ct - (ct == cnt ? 1 : 0)) - 1) * (last + 1)) % mod;
                                temp = ( preR + preL + 1) % mod;
                        }
                        preL += temp;
                        cnt--;
                        if(cnt <= 1) preR = 0;
                }else{
                        temp = binExpo(2, i);
                        cnt++;
                        preR += preL + preR + 1;
                        if(cnt <= 1) preR = 0;
                }
                ans += temp;
                ans %= mod;
        }
        cout << ans << endl;
}

int main(){
        ios_base :: sync_with_stdio ( false );
        cin.tie ( NULL );
        ll testcase = 1;
        cin >> testcase;
        while ( testcase -- )
                main_sol ();
        return 0;
}