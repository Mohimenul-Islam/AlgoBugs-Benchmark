//UPDATERA ARRAY STORLEKEN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;

const ll MOD=998244353;
const ll INF=1e15;
const ll MAXN=200006;//UPDATERA ARRAY STORLEKEN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
ll t,n,lst[MAXN],ans,pre_sum[MAXN],dp[MAXN];
char bracket[MAXN];

void init(){
    for(int i=0;i<=n;i++){
        lst[i]=0;
        dp[i]=0;
    }
}

void solve(){
    cin>>n;
    init();
    ans=0;
    for(int i=1;i<=n;i++){
        cin>>bracket[i];
        if(bracket[i]=='(') pre_sum[i]=1;
        else pre_sum[i]=-1;
        pre_sum[i]+=pre_sum[i-1];
    }

    ll pre_high=0,pre=0,pw=1;
    //f0 is pre_high,f1 is pre
    for(int i=1;i<=n;i++){
        ll tot=(pre_high+pre)%MOD;
        if(bracket[i]=='('){
            ans+=pw;
            ans%=MOD;
            pre_high+=tot+1;
            pre_high%=MOD;
        }else{
            pre+=tot+1;
            pre%=MOD;
            ans+=tot+1;
            ans%=MOD;
        }
        
        if(pre_sum[i]<2){
            pre_high=0;
        }
        pw*=2;
        pw%=MOD;
    }
    cout<<ans<<'\n';
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>t;
    while(t--){
        solve();
    }
}