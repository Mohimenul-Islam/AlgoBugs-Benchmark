#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

#define _TheVinh_ signed main
#define ll long long
#define fi first
#define se second
#define pb push_back
#define pf push_front
#define pii pair<int, int>
#define all(x) x.begin(), x.end()
#define rep(x, y, z) for (int x = (y); x <= (z); x++)
#define per(x, z, y) for (int x = (z); x >= (y); x--)
#define sz(x) (int)x.size()
#define ordered_set tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update>
#define TIME (1.0 * clock() / CLOCKS_PER_SEC)
#define int ll
#define Fix(x) (x % mod + mod) % mod

const int maxn = 3e5 + 5;
const int inf = 1e9 + 13;
const ll linf = (ll)1e18 + 7;
const ll mod = 998244353;

const int dx[] = {1, 0, -1, 0}, dy[] = {0, 1, 0, -1};

void add(int &a, int b) { if ((a += b) >= mod) a -= mod; }
void sub(int &a, int b) { if ((a -= b) < 0) a += mod; }

template<typename T> void chkmin(T &a, T b) { if (a > b) a = b; }
template<typename T> void chkmax(T &a, T b) { if (a < b) a = b; }

int dp[maxn], pref[maxn], F[maxn];

void solve() {
    int n; cin >> n;
    string s; cin >> s;
    s = ' ' + s;

    int ans = 0, p2 = 1;
    rep(i, 1, n) {
        if (s[i] == '(') add(ans, p2);
        add(p2, p2);
    }

    int lastP = -1, sumCl = 0;
    rep(i, 1, n) {
        pref[i] = pref[i - 1] + (s[i] == ')' ? -1 : 1);
        F[i] = F[i - 1]; int sum; if (lastP != -1) sum = Fix(F[i] - F[lastP]); 
        if (s[i] == '(') {
            add(dp[i], sum); add(dp[i], 1); add(dp[i], sumCl);
            add(F[i], dp[i]);
        } else {
            add(dp[i], sum); add(dp[i], 1); add(dp[i], sumCl);
            add(sumCl, dp[i]);
        }
        if (pref[i] < 2) lastP = i;
    }

    add(ans, sumCl);
    cout << ans << '\n';
    rep(i, 1, n) dp[i] = 0;
}

_TheVinh_() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    int test = 1;
    cin >> test;
    while (test--)
        solve();
    
    cerr << "Time elapsed: " << TIME << "s" << '\n';
}
