#include <iostream>
#include <vector>
#include <algorithm>

#define int long long
using namespace std;
const int cMod = 998244353;

struct ModInt {
  int value;

  ModInt(int v) : value(v) {
    ToMod();
  }

  ModInt operator+(const ModInt& other) const {
    return ModInt(value + other.value);
  }

  ModInt operator*(const ModInt& other) const {
    return ModInt(value * other.value);
  }

  ModInt operator-(const ModInt& other) const {
    return ModInt(value - other.value);
  }

  void ToMod() {
    value %= cMod;
    if (value < 0) {
      value += cMod;
    }
  }
};

ostream& operator<<(ostream& out, ModInt value) {
  out << value.value;
  return out;
}

void Solve() {
  int n;
  cin >> n;
  string s;
  cin >> s;
  vector<int> pot(n, 0);
  for (int i = 0; i < n; ++i) {
    if (i != 0) {
      pot[i] = pot[i - 1];
    }
    pot[i] += (s[i] == '(' ? 1 : -1);
  }

  ModInt total = 0;
  ModInt tmp = 1;
  for (int i = 0; i < n; ++i) {
    if (s[i] == '(') {
      total = total + tmp;
    }
    tmp = tmp * ModInt(2);
  }

  vector<ModInt> dp(n, 1);
  ModInt closed = 0;
  ModInt addition = 0;
  for (int i = 1; i < n; ++i) {
    bool blocked = false;
    dp[i] = closed + dp[i];
    dp[i] = addition + dp[i];
    if (pot[i] <= 1) {
      addition = 0;
    } else if (s[i] == '(') {
      addition = addition + dp[i];
    }
    if (s[i] == ')') {
      closed = closed + dp[i];
    }
  }

  for (int i = 0; i < n; ++i) {
    if (s[i] == ')') {
      total = total + dp[i];
    }
  }

  cout << total << '\n';
}

signed main() {
  ios::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);

  int t;
  cin >> t;
  while (t--) {
    Solve();
  }
  return 0;
}