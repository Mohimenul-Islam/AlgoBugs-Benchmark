#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#ifdef LOCAL
#include "debug.hpp"
#else
#define debug(...) 2901
#endif

using namespace __gnu_pbds;
using namespace std;

#define rep(i,a,b) for(int i=a;i<b;i++)
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
typedef vector<int> vi;
#define vll vector<ll>
#define all(v) v.begin(),v.end()
#define vii vector<pair<int,int>>
#define pi pair<int,int>
#define pll pair<ll,ll>
#define lb lower_bound  
#define ub upper_bound
#define pb push_back
#define ff first
#define ss second

template<typename T>
bool chmax(T &a, const T &b) {
    return (b > a) ? a = b, true : false;
}

template<typename T>
bool chmin(T &a, const T &b) {
    return (b < a) ? a = b, true : false;
}

template<typename T>
using ordered_set = tree< T,null_type,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

const int N=1e6+1;
const int MOD=998244353;
#pragma GCC optimize("Ofast") // For GCC 15 auto-vectorization

template<int id> struct mint {
    int val;
    static inline int MOD = 998244353;

    static void set_mod(int m) { MOD = m; }
    static int get_mod() { if constexpr (id >= 0) return id; return MOD; }

    mint(long long v = 0) {
        if (v < 0) v = v % get_mod() + get_mod();
        if (v >= get_mod()) v %= get_mod();
        val = (int)v;
    }

    static int mod_inv(int a, int m = get_mod()) {
        int g = m, r = a, x = 0, y = 1;
        while (r != 0) {
            int q = g / r;
            g %= r; std::swap(g, r);
            x -= q * y; std::swap(x, y);
        }
        return x < 0 ? x + m : x;
    }

    
    static unsigned fast_mod(uint64_t x) {
        #if defined(__SIZEOF_INT128__)
            return (unsigned)(x % get_mod());
        #elif !defined(_WIN32) || defined(_WIN64)
            return (unsigned)(x % get_mod());
        #else
            unsigned x_high = x >> 32, x_low = (unsigned)x;
            unsigned quot, rem;
            unsigned m = get_mod();
            asm("divl %4\n" : "=a" (quot), "=d" (rem) : "d" (x_high), "a" (x_low), "r" (m));
            return rem;
        #endif
    }

    explicit operator int() const { return val; }

    mint& operator+=(const mint &other) {
        val += other.val;
        if (val >= get_mod()) val -= get_mod();
        return *this;
    }

    mint& operator-=(const mint &other) {
        val -= other.val;
        if (val < 0) val += get_mod();
        return *this;
    }

    mint& operator*=(const mint &other) {
        val = fast_mod((uint64_t)val * other.val);
        return *this;
    }

    mint& operator/=(const mint &other) { return *this *= other.inv(); }

    mint operator-() const { return val == 0 ? 0 : get_mod() - val; }
    mint& operator++() { val = (val == get_mod() - 1 ? 0 : val + 1); return *this; }
    mint& operator--() { val = (val == 0 ? get_mod() - 1 : val - 1); return *this; }
    mint operator++(int) { mint before = *this; ++*this; return before; }
    mint operator--(int) { mint before = *this; --*this; return before; }

    bool operator==(const mint &other) const { return val == other.val; }
    bool operator!=(const mint &other) const { return val != other.val; }
    
    // C++23 Spaceship operator for free comparisons
    auto operator<=>(const mint &other) const = default;

    mint inv() const { return mod_inv(val); }
    mint pow(long long p) const {
        mint a = *this, res = 1;
        while (p > 0) { if (p & 1) res *= a; a *= a; p >>= 1; }
        return res;
    }

    friend mint operator+(mint a, const mint &b) { return a += b; }
    friend mint operator-(mint a, const mint &b) { return a -= b; }
    friend mint operator*(mint a, const mint &b) { return a *= b; }
    friend mint operator/(mint a, const mint &b) { return a /= b; }

    friend std::ostream& operator<<(std::ostream &os, const mint &m) { return os << m.val; }
    friend std::istream& operator>>(std::istream &is, mint &m) { long long v; is >> v; m = mint(v); return is; }
};

using modint = mint<MOD>;
using d_mint = mint<-1>; // Dynamic mod
void solve(int t){
    int n;
    cin>>n;
    string s;
    cin>>s;
    modint ans=0;
    int sum=0;
    vi pre(n);
    rep(i,0,n){
        if(s[i]=='('){
            ans+=modint(2).pow(i);
            sum++;
        }
        else sum--;
        pre[i]=sum;
    }
    vector<modint>dp(n,0);
    int l=n;
    for(int i=n-1;i>=0;i--){
        if(pre[i]<=1) {
            if(s[i]==')') l=i+1;
            else l=i;
        }
        if(s[i]==')'){
            dp[i]=1;
            if(i+1<n) dp[i]+=dp[i+1]*2;
        }
        else{
            
            if(l>i+1) dp[i]=dp[i+1]-(l==n?0:dp[l]);
            dp[i]+=dp[i+1];
        }
        debug(dp);
    }
    modint f =ans+dp[0];
    cout<<f<<'\n';
}
int main(){

    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t = 1;
    cin>>t;
    rep(i,0,t) {
        //cout <<"Case #" <<i+1 <<": ";
        debug(i+1);
        solve(i+1);
    }       
    return 0;
}