#include<bits/stdc++.h>
using namespace std;
#define MOD 998244353
#define AD(x,y) (( (x)+(y) )%MOD)
#define MU(x,y) (( (x)*(y) )%MOD)
#define REPEAT0 if(0){}
using LL=long long;
using UC=unsigned char;
struct Q{
int n; string s; LL c,o,r,t,p; int f;
inline LL nd(){return (1LL+c+o)%MOD;}
void calc(){
c=o=r=t=0; p=1; f=0;
int i=0;
while(i<n){
char ch=s[i];
if(ch=='(') t=AD(t,p);
p=MU(p,2);
LL d=nd();
if(ch==')'){
r=AD(r,d);
c=AD(c,d);
f-=1;
}else{
o=AD(o,d);
f+=1;
}
if(f<=1) o=0;
i+=1;
}
}
LL ans(){return AD(r,t);}
};
int main(){
int T; scanf("%d",&T);
while(T--){
int n; static char buf[2000005];
scanf("%d %s",&n,buf);
Q q; q.n=n; q.s=string(buf);
q.calc();
printf("%lld\n",q.ans());
}
return 0;
}