#include<iostream>
#include<cstring>
#include<algorithm>
#include<cmath>
#define int long long
using namespace std;
const int N=200010,mod=998244353;

char a[N];
int n,dp[N][2];

signed main() {
	int t;
	cin>>t;
	while (t--) {
		cin>>n;
		cin>>a+1;
		int base=1,ans=0,now=0;
		for (int i=1;i<=n;++i) {
			if (a[i]=='(') now++;
			else now--;
			
			if (a[i]=='(') ans+=base,ans%=mod;
			else ans+=dp[i-1][0]+dp[i-1][1]+1,ans%=mod;
			
			if (a[i]=='(') {
				if (now>=2) {
					dp[i][0]+=dp[i-1][0]+dp[i-1][1];
					dp[i][0]++;
				}
			} else {
				dp[i][1]+=dp[i-1][0]+dp[i-1][1];
				dp[i][1]++;
			}
			if (now>=2) dp[i][0]+=dp[i-1][0];
			dp[i][1]+=dp[i-1][1];
			dp[i][0]%=mod,dp[i][1]%=mod;
			
			base*=2;
			base%=mod;
		}
		cout<<ans<<endl;
		
		for (int i=1;i<=n;++i) dp[i][0]=dp[i][1]=0;
	}

	return 0;
}