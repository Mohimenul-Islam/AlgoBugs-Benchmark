#include<bits/stdc++.h>
using namespace std;

#define test cout << "***" << endl;

const int MAX = 5e3 + 1;
const int mod = 998244353;

int quickPow(int base, int coe, int mod){
	int res = 1;
	while(coe){
		if(coe&1)res = res * base % mod;
		coe >>= 1;
		base = base * base % mod;
	}
	return res;
}

void solve(){
	int n;
	cin >> n;
	string s;
	cin >> s;

	vector<int>dp(n); 
	int ans = 0;
	int v = 0, p = 0, sum1 = 0, sum2 = 0;
	for(int i = 0; i < n; i++){
		dp[i] = (sum1 + sum2 + 1) % mod;
		if(s[i] == '(') ans = (ans + quickPow(2, i, mod)) % mod, sum1 = (sum1 + dp[i]) % mod, v++;
		else ans = (ans + dp[i]) % mod, sum2 = (sum2 + dp[i]) % mod, v--;
		if(v < 2) sum1 = 0;
	}
	cout << ans % mod << endl;
}

signed main(){
    int t = 1;
    cin >> t;
    while(t--){
        solve();
    }
    return 0;
}