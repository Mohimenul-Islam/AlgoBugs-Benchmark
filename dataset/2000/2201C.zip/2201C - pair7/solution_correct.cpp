// #pragma GCC optimize("Ofast")
// #pragma GCC target("avx,avx2,fma")
// #pragma GCC optimization("unroll-loops")
#include <iostream>      // cin, cout
#include <vector>        // vector
#include <algorithm>     // sort, max, min, lower_bound
#include <cmath>         // sqrt, pow, abs
#include <map>           // map
#include <unordered_map> // unordered_map
#include <set>           // set
#include <unordered_set> // unordered_set
#include <queue>         // queue, priority_queue
#include <stack>         // stack
#include <deque>         // deque
#include <string>        // string
#include <cstring>       // memset
#include <climits>       // INT_MAX, LLONG_MAX
#include <numeric>       // accumulate, gcd
#include <functional>    // function, greater, less
#include <iomanip>       // setprecision
#include <cassert>       // assert
using namespace std;
#define PRINT(x)                         \
    if (debug)                           \
    {                                    \
        cout << #x << ": " << x << endl; \
    }
#define PRINTARR(x)           \
    if (debug)                \
    {                         \
        cout << #x << ": ";   \
        for (auto i : x)      \
        {                     \
            cout << i << ' '; \
        }                     \
        cout << endl;         \
    }
#define MODP(a, b) (((a) % b + b) % b)
#define divideCeil(a, b) ((a + b - 1) / b)
#define all(x) begin(x), end(x)
#define rall(x) rbegin(x), rend(x)
// 1000000007
#define INF 998244353
#define EPS 1e-9
typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
bool debug;

// libraries
/**
 * Utility class for modulo related operations.
 */
struct ModuloUtil
{
    ll MOD;
    // takes the modulo value to be used for all operations
    ModuloUtil(ll MOD) : MOD(MOD) {}

    /**
     * ====Bezout's Theorem====
     * a*x + b*y = gcd(a, b)
     * x is modular inverse of a
     * y is moduler inverse of b
     * @return tuple of <gcd(a,b), x, y>
     */
    tuple<ll, ll, ll> exEuclid(ll a, ll b)
    {
        ll x, y;
        ll gcd = gcdExtended(a, b, x, y);
        return make_tuple(gcd, x, y);
    }
    ll add(ll a, ll b) { return modp((a % MOD) + (b % MOD)); }
    ll add(ll a, ll b, ll mod) { return modp((a % mod) + (b % mod), mod); }

    ll sub(ll a, ll b) { return modp((a % MOD) - (b % MOD)); }
    ll sub(ll a, ll b, ll mod) { return modp((a % mod) - (b % mod), mod); }

    ll mult(ll a, ll b) { return modp((a % MOD) * (b % MOD)); }
    ll mult(ll a, ll b, ll mod) { return modp((a % mod) * (b % mod), mod); }

    ll div(ll a, ll b) { return modp((a % MOD) * invMod(b)); }
    ll div(ll a, ll b, ll mod) { return modp((a % mod) * invMod(b, mod), mod); }

    /**
     * Calculates the inverse modulo of a.
     * x: the inverse modulo a under modulo m an integer such that (x*a)%m == 1
     * uses extended euclidean gcd => O(log n)
     */
    ll invMod(ll a)
    {
        auto gcd = exEuclid(a, MOD);
        assert(get<0>(gcd) == 1);
        return modp(get<1>(gcd));
    }
    /**
     * Calculates the inverse modulo of a.
     * x: the inverse modulo a under modulo m an integer such that (x*a)%m == 1
     * uses extended euclidean gcd => O(log n)
     */
    ll invMod(ll a, ll mod)
    {
        auto gcd = exEuclid(a, mod);
        assert(get<0>(gcd) == 1);
        return modp(get<1>(gcd), mod);
    }
    ll gcdExtended(ll a, ll b, ll &x, ll &y)
    {
        if (a == 0)
        {
            x = 0;
            y = 1;
            return b;
        }
        ll x1, y1;
        ll gcd = gcdExtended(b % a, a, x1, y1);

        x = y1 - (b / a) * x1;
        y = x1;

        return gcd;
    }
    /**
     * Modulo that always return positive result.
     * @return r where x = q*d + r and 0 <= r < mod
     */
    ll modp(ll x, ll mod) { return (x % mod + mod) % mod; }
    /**
     * Modulo that always return positive result.
     * @return r where x = q*d + r and 0 <= r < MOD
     */
    ll modp(ll x) { return (x % MOD + MOD) % MOD; }
};

ModuloUtil modHelper(INF);

/**
 * Binary Exponentiaion library.
 * Calculates the value of (a^b)%mod in O(log b)
 */
ll binPow(ll a, ll b, ll mod)
{
    ll res = 1;
    while (b > 0)
    {
        if (b & 1)
            res = (res * a) % mod;
        a = (a * a) % mod;
        b >>= 1;
    }
    return res;
}

/**
 * Returns the prefix sum of an array
 * prefixSum[i] = sum of elements in array from the beginning until before i => sum( array[0,i) )
 */
template <typename T>
vector<T> prefixSum(vector<T> &arr)
{
    vector<T> pref(arr.size() + 1);
    pref[0] = 0;
    for (int i = 0; i < arr.size(); i++)
        pref[i + 1] = pref[i] + arr[i];

    return pref;
}

vector<ll> memo3;
// prefixSum of opening bracket count from start until index (inclusive)
ll prefixOpeningBracket(string &brackets, int index)
{
    if (index < 0)
        return 0;
    if (memo3[index] != -1)
        return memo3[index];

    return memo3[index] = prefixOpeningBracket(brackets, index - 1) + (brackets[index] == '(' ? 1 : 0);
}

ll prefixDp(string &brackets, vi &prefSum, vi &indexOfSafeZoneBorder, int index);
ll prefixDpClosingBracket(string &brackets, vi &prefSum, vi &indexOfSafeZoneBorder, int index);

// number of subsequences ending in ')' in prefix [0, i]
vector<ll> memo;
ll dp(string &brackets, vi &prefSum, vi &indexOfSafeZoneBorder, int index)
{
    if (index < 0)
        return 0;

    if (memo[index] != -1)
        return memo[index];

    ll sum = brackets[index] == ')' ? 1 : 0;
    PRINT(index)

    int safeIndex = indexOfSafeZoneBorder[index];
    PRINT(safeIndex)

    int countOpeningBracketInSafeZone = prefixOpeningBracket(brackets, index - 1) - prefixOpeningBracket(brackets, safeIndex);
    PRINT(countOpeningBracketInSafeZone)

    sum = modHelper.add(sum, countOpeningBracketInSafeZone);

    ll prefixDpIndex = prefixDp(brackets, prefSum, indexOfSafeZoneBorder, index - 1);
    PRINT(prefixDpIndex)
    ll prefixDpSafeIndex = prefixDp(brackets, prefSum, indexOfSafeZoneBorder, safeIndex);
    PRINT(prefixDpSafeIndex)

    sum = modHelper.add(sum, prefixDpIndex - prefixDpSafeIndex);

    ll prefixDpClosingBracketSafeIndex = prefixDpClosingBracket(brackets, prefSum, indexOfSafeZoneBorder, safeIndex);
    PRINT(prefixDpClosingBracketSafeIndex)

    sum = modHelper.add(sum, prefixDpClosingBracket(brackets, prefSum, indexOfSafeZoneBorder, safeIndex));

    return memo[index] = sum;
}

vector<ll> memo4;
// prefixSum of the DP, but count the closing bracket only
ll prefixDpClosingBracket(string &brackets, vi &prefSum, vi &indexOfSafeZoneBorder, int index)
{
    if (index < 0)
        return 0;
    if (memo4[index] != -1)
        return memo4[index];

    return memo4[index] = (prefixDpClosingBracket(brackets, prefSum, indexOfSafeZoneBorder, index - 1) +
                           (brackets[index] == ')'
                                ? dp(brackets, prefSum, indexOfSafeZoneBorder, index)
                                : 0)) %
                          INF;
}

vector<ll> memo2;
// prefixSum of the DP.
ll prefixDp(string &brackets, vi &prefSum, vi &indexOfSafeZoneBorder, int index)
{
    if (index < 0)
        return 0;
    if (memo2[index] != -1)
        return memo2[index];

    return memo2[index] = (prefixDp(brackets, prefSum, indexOfSafeZoneBorder, index - 1) + dp(brackets, prefSum, indexOfSafeZoneBorder, index)) % INF;
}

void moveIndexBelow2(int &index, vi &prefSum)
{
    int n = prefSum.size() - 1;
    do
    {
        index++;
    } while (index < n && prefSum[index + 1] >= 2);
}

int main(int argc, char *argv[])
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    debug = argc > 1; // set to 1 to disable debug mode

    int t;
    cin >> t;

    while (t--)
    {
        int n;
        cin >> n;
        memo.assign(n, -1);
        memo2.assign(n, -1);
        memo3.assign(n, -1);
        memo4.assign(n, -1);

        string brackets;
        cin >> brackets;
        vi arr;
        for (char c : brackets)
        {
            arr.push_back(c == '(' ? 1 : -1);
        }
        vi prefSum = prefixSum(arr);
        vi indexOfSafeZoneBorder(n, -1);
        int indexBelow2 = -1;
        ll answer = 0;
        for (int i = 0; i < n; i++)
        {
            if (i > indexBelow2)
            {
                indexOfSafeZoneBorder[i] = indexBelow2;
                moveIndexBelow2(indexBelow2, prefSum);
            }
            else
            {
                indexOfSafeZoneBorder[i] = indexOfSafeZoneBorder[i - 1];
            }

            // PRINTARR(indexOfSafeZone)

            if (brackets[i] == '(')
            {
                answer = (answer + binPow(2, i, INF)) % INF;
            }
            else
            {
                answer = (answer + dp(brackets, prefSum, indexOfSafeZoneBorder, i)) % INF;
            }
        }

        cout << answer << endl;
    }

    return 0;
}