// #pragma GCC optimize("Ofast")
// #pragma GCC target("avx,avx2,fma")
// #pragma GCC optimization("unroll-loops")
#include <iostream>      // cin, cout
#include <vector>        // vector
#include <algorithm>     // sort, max, min, lower_bound
#include <cmath>         // sqrt, pow, abs
#include <map>           // map
#include <unordered_map> // unordered_map
#include <set>           // set
#include <unordered_set> // unordered_set
#include <queue>         // queue, priority_queue
#include <stack>         // stack
#include <deque>         // deque
#include <string>        // string
#include <cstring>       // memset
#include <climits>       // INT_MAX, LLONG_MAX
#include <numeric>       // accumulate, gcd
#include <functional>    // function, greater, less
#include <iomanip>       // setprecision
#include <cassert>       // assert
using namespace std;
#define PRINT(x)                         \
    if (debug)                           \
    {                                    \
        cout << #x << ": " << x << endl; \
    }
#define PRINTARR(x)           \
    if (debug)                \
    {                         \
        cout << #x << ": ";   \
        for (auto i : x)      \
        {                     \
            cout << i << ' '; \
        }                     \
        cout << endl;         \
    }
#define MODP(a, b) (((a) % b + b) % b)
#define divideCeil(a, b) ((a + b - 1) / b)
#define all(x) begin(x), end(x)
#define rall(x) rbegin(x), rend(x)
// 1000000007
#define INF 998244353
#define EPS 1e-9
typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
bool debug;

// libraries
/**
 * Binary Exponentiaion library.
 * Calculates the value of (a^b)%mod in O(log b)
 */
ll binPow(ll a, ll b, ll mod)
{
    ll res = 1;
    while (b > 0)
    {
        if (b & 1)
            res = (res * a) % mod;
        a = (a * a) % mod;
        b >>= 1;
    }
    return res;
}

bool isProperBracket(string &brackets)
{
    stack<char> ms;
    for (char s : brackets)
    {
        if (s == '(')
        {
            ms.push(s);
        }
        else
        {
            if (ms.empty())
            {
                return false;
            }
            else
            {
                ms.pop();
            }
        }
    }
    return ms.empty();
}

bool isSafe(string originalBrackets, int mask)
{
    string brackets = originalBrackets;
    int n = brackets.size();

    vi indices;
    for (int i = 0; i < n; i++)
    {
        if (mask & (1 << i))
        {
            indices.push_back(i);
        }
    }
    // PRINTARR(indices)

    char last = brackets[indices.back()];
    for (int i = indices.size() - 1; i > 0; i--)
    {
        int currIdx = indices[i];
        int prevIdx = indices[i - 1];
        brackets[currIdx] = brackets[prevIdx];
    }
    brackets[indices.front()] = last;
    // PRINT(brackets)
    bool result = isProperBracket(brackets);
    if (result)
    {
        for (int i = 0; i < n; i++)
        {
            if (mask & (1 << i))
            {
                cout << originalBrackets[i];
            }
            else
            {
                cout << 'x';
            }
        }
        cout << " -> " << brackets << endl;
    }
    return result;
}

/**
 * Returns the prefix sum of an array
 * prefixSum[i] = sum of elements in array from the beginning until before i => sum( array[0,i) )
 */
template <typename T>
vector<T> prefixSum(vector<T> &arr)
{
    vector<T> pref(arr.size() + 1);
    pref[0] = 0;
    for (int i = 0; i < arr.size(); i++)
        pref[i + 1] = pref[i] + arr[i];

    return pref;
}
/**
 * Calculates the range sum of a 1D array
 * @param ps 1D Prefix sum array
 * @param l Left bound
 * @param r Right bound
 * @return The sum of elements from array[left] until array[right] inclusive
 */
template <typename T>
inline T getSum(vector<T> &ps, int l, int r) { return ps[r + 1] - ps[l]; }

vector<ll> memo2;
// prefixSum of the DP.
ll prefixDp(string &brackets, vi &prefSum, int index)
{
}

// number of subsequences ending in ')' in prefix [0, i]
vector<ll> memo;
ll dp(string &brackets, vi &prefSum, int index)
{
    if (index < 0)
        return 0;

    if (memo[index] != -1)
        return memo[index];

    ll sum = brackets[index] == ')' ? 1 : 0;

    int safeIndex = index - 1;
    int countOpeningBracketInSafeZone = 0;
    while (safeIndex > 0 && prefSum[safeIndex + 1] >= 2)
    {
        if (brackets[safeIndex] == '(')
        {
            countOpeningBracketInSafeZone++;
        }
        safeIndex--;
    }
    sum = (sum + countOpeningBracketInSafeZone) % INF;

    for (int i = index - 1; i > 0; i--)
    {
        if (brackets[i] == ')')
        {
            sum = (sum + dp(brackets, prefSum, i)) % INF;
        }
        else if (i > safeIndex)
        {
            sum = (sum + dp(brackets, prefSum, i)) % INF;
        }
    }
    return memo[index] = sum;
}

int main(int argc, char *argv[])
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    debug = argc > 0; // set to 1 to disable debug mode

    int t;
    cin >> t;

    while (t--)
    {
        int n;
        cin >> n;
        memo.assign(n, -1);

        string brackets;
        cin >> brackets;
        vi arr;
        for (char c : brackets)
        {
            arr.push_back(c == '(' ? 1 : -1);
        }
        vi prefSum = prefixSum(arr);
        // vi indexOfSafeZone(n);

        ll answer = 0;
        for (int i = 0; i < n; i++)
        {
            if (brackets[i] == '(')
            {
                answer = (answer + binPow(2, i, INF)) % INF;
            }
            else
            {
                answer = (answer + dp(brackets, prefSum, i)) % INF;
            }
            // PRINT(answer)
        }

        cout << answer << endl;
    }

    return 0;
}