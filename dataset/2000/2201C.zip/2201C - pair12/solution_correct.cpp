#include <bits/stdc++.h>
#define endl '\n'
#define ll long long
#define int ll

using namespace std;

const int N = 2e5 + 7;
const int inf = 1e18 + 7;
const int mod = 998244353;

void solve()
{
    int n;
    cin >> n;
    string s;
    cin >> s;
    vector<int> a(n + 7, 0);
    for (int i = 1; i <= n; i++)
    {
        if (s[i - 1] == '(')
            a[i] = 1;
        else
            a[i] = -1;
    }
    int sum = 0, L = 0, R = 0, mi2 = 1, ans = 0;
    for (int i = 1; i <= n; i++)
    {
        if (a[i] == 1)
        {
            ans = (ans + mi2) % mod;
            L = (2 * L + R + 1) % mod;
        }
        else
        {
            ans = (ans + L + R + 1) % mod;
            R = (L + R + R + 1) % mod;
        }
        mi2 = mi2 * 2 % mod;
        sum += a[i];
        if (sum <= 1)
            L = 0;
    }
    cout << ans << '\n';
}

signed main()
{
    ios ::sync_with_stdio(false), cin.tie(nullptr), cout.tie(nullptr);
    int TT = 1;
    cin >> TT;
    while (TT--)
    {
        solve();
    }
    return 0;
}