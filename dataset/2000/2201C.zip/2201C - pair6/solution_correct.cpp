//#undef NDEBUG
//#undef _GLIBCXX_DEBUG
//#include <bits/extc++.h>
#include <bits/stdc++.h>
using namespace std;
//using namespace __gnu_pbds;
//using namespace __gnu_cxx;
//template <typename T> using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
//template <typename T> using ordered_multiset = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>;
#define int long long
//#define double long double
#define YES(x) cout << (x?"YES\n":"NO\n")
#define ALICE(x) cout << (x?"Alice\n":"Bob\n")
#define BOB(x) cout << (x?"Bob\n":"Alice\n")
#define NO(x) cout << (x?"No\n":"Yes\n")
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define uniqueaftersorted(x) x.resize(unique(all(x))-x.begin())
#ifndef LO
#pragma GCC optimize("Ofast,unroll-loops")
#endif
constexpr int MOD = (119<<23)+1;
//constexpr int MOD = 967276608647009887ll;
//constexpr int MOD = 1e9+7;
constexpr int INF = 1e18;
signed main() {
#ifndef LO
    clog << "FIO\n";
    ios::sync_with_stdio(0);
    cin.tie(0);
#endif
#ifdef LO
    cout << unitbuf;
#endif
    int N = 2e6;
    vector<int> _2(N, 1);
    for (int i = 1; i < N; i += 1) {
        _2[i] = _2[i-1]*2%MOD;
    }
    int T=1;
    cin >> T;
    for (int tt = 0; tt < T; tt += 1) {
        int n;
        cin >> n;
        string s;
        cin >> s;
        vector<int> b(n);
        for (int i = 0; i < n; i += 1) {
            b[i] += s[i] == '(';
            b[i] -= s[i] == ')';
            if (i) {
                b[i] += b[i-1];
            }
        }
        vector<int> dp(n);
        for (int i = 0, su = 0, sum_closing = 0; i < n; i += 1) {
            dp[i] = (1+sum_closing)%MOD;
            if (i) {
                if (b[i-1] < 2) {
                    su = 0;
                } else {
                    (su += s[i-1]==')'?0:dp[i-1]) %= MOD;
                }
            }
            (dp[i] += su) %= MOD;
            if (s[i] == ')') {
                (sum_closing += dp[i]) %= MOD;
            }
            //cout << dp[i] << " ";
        }//cout << "\n";
        int ans = 0;
        for (int i = 0; i < n; i += 1) {
            if (s[i] == '(') {
                (ans += _2[i]) %= MOD;
            } else {
                (ans += dp[i]) %= MOD;
            }
        }
        cout << ans << "\n";
    }
}