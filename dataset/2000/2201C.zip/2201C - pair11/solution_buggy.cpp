// Source: https://usaco.guide/general/io

#include <bits/stdc++.h>
using namespace std;

long long int exp2(int e){
    if (e == 0)
        return 1;
    else if (e % 2 == 0){
        long long int sqrt = exp2(e / 2);
        return (sqrt * sqrt) % 998244353;
    }
    else {
        long long int sqrt = exp2(e / 2);
        return (2 * sqrt * sqrt) % 998244353;
    }
}

int main() {
	int t;
    cin >> t;

    for (int i = 0; i < t; i++){

        vector<int> values;
        int n;
        cin >> n;
        int sum = 0;
        vector<int> breaks;
        vector<int> breakPrefixSum = {0};
        vector<long long int> safe;
        long long int counter = 0;
        int pos = 0;

        for(int j = 0; j < n; j++){
            char ch;
            cin >> ch;
            if (ch == '(') {
                ++sum;
                values.push_back(1);
                counter += exp2(pos);
                counter %= 998244353;
            }
            else {
                --sum;
                values.push_back(-1);
            }
            
            ++pos;

            if (sum <= 1){
                breaks.push_back(pos);
                breakPrefixSum.push_back(pos + breakPrefixSum.back());
                safe.push_back(counter);
                pos = 0;
                counter = 0;
            }

        }

        long long int total = 0;
        long long int c = 1;

        for(int j = 0; j < safe.size(); j++){
            total += (c * (exp2(breaks[j]) - 1 - safe[j]));
            total += (safe[j] * exp2(breakPrefixSum[j]));
            total %= 998244353;
            c *= (exp2(breaks[j]) - safe[j]);
            c %= 998244353;
        }

        cout << total << endl;

    }
}
