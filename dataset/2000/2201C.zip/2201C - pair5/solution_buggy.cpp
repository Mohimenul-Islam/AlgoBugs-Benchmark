#include <bits/stdc++.h>

// start: 3:30
// idea:
// solved:

using namespace std;
using vi = vector<int>;
using ll = long long;
using vll = vector<long long>;
#define sz(x) ((int)((x).size()))
const double pi = numbers::pi;

template<class T> bool chmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<class T> bool chmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }

ll mod= 998244353;
ll base=-1;
ll p[300001]={};
ll inv[300001]={};
ll getp(int i){
    if(i==0){
        p[0]=1;
        return 1;
    }
    if(p[i]!=0)return p[i];
    ll out;
    if(i%2==0){
        out=getp(i>>1);
        out=(out*out)%mod;
    }else{
        out=getp(i>>1);
        out=(out*out)%mod;
        out=(out*2)%mod;
    }
    p[i]=out;
    return out;
}

ll invp(int i){
    if(i==0){
        inv[0]=1;
        return 1;
    }
    if(inv[i]!=0)return inv[i];
    ll out;
    if(base==-1){
        base=1;
        ll exp=mod-2;
        ll cur=2;
        while(exp>0){
            if(exp%2==1){
                base*=cur;
                base%=mod;
            }
            cur=(cur*cur)%mod;
            cur%=mod;
            exp>>=1;
        }
    }
    if(i%2==0){
        out=invp(i>>1);
        out=(out*out)%mod;
    }else{
        out=invp(i>>1);
        out=(out*out)%mod;
        out=(out*base)%mod;
    }
    inv[i]=out;
    return out;
}

void solve() {
    ll n;cin>>n;
    vi s(n+1);
    vi plus(n+1);
    plus[0]=0;
    int plus_cnt=0;
    for(int i=1;i<=n;++i){
        char c;cin>>c;
        int x;
        if(c=='(')x=1;
        else x=-1;
        s[i]=x;
        if(x==1)plus_cnt++;
        plus[i]=plus_cnt;
    }

    int sum=0;
    int ind=0;
    vi k(n+1);
    for(int i=1;i<=n;++i){
        k[i]=ind;
        sum+=s[i];
        if(sum<2)ind=i;
    }

    vll dp(n+1,0);
    vll pre(n+1,0);
    vll pre2(n+1,0);
    dp[0]=1;
    pre[0]=dp[0];
    pre2[0]=dp[0];
    ll ans=0;
    for(int i=1;i<=n;++i){
        if(s[i]==1){
            ans+=getp(i-1);
            ans%=mod;
            dp[i]=0;
        }else{
            int cur_k=k[i];
            ll cur_dp=0;
            cur_dp+=pre[cur_k];
            cur_dp*=getp(plus[i-1]-plus[cur_k]);
            cur_dp%=mod;
            cur_dp+=((pre2[i-1]-pre2[cur_k])*getp(plus[i-1]))%mod;
            /*
            for(int j=cur_k+1;j<i;++j){
                ll t=dp[j];
                int plus_cnt2=plus[i-1]-plus[j];
                t*=getp(plus_cnt2);
                t%=mod;
                cur_dp+=t;
                cur_dp%=mod;
            }
            */

            dp[i]=cur_dp;
            ans+=cur_dp;
            ans%=mod;
        }
        pre[i]=pre[i-1]+dp[i];
        pre[i]%=mod;
        pre2[i]=pre2[i-1]+((dp[i]*invp(plus[i]))%mod);
    }
    cout<<ans<<endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    int t = 1;
    cin >> t;
    while (t--) solve();
}

