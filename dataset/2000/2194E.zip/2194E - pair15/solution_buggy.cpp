#include<bits/stdc++.h>
using namespace std;

#define vi vector<int>
#define vvi vector<vector<int>>
#define vvvi vector<vector<vector<int>>>

#define vpi vector<pair<int,int>>
#define vvpi vector<vector<pair<int,int>>>

const long long int SEED=chrono::steady_clock::now().time_since_epoch().count();
mt19937_64 rng(SEED);
inline long long int rnd(long long int l=0,long long int r=0xFFFFFFFFFFFFFFFLL)
{return uniform_int_distribution<long long int>(l,r)(rng);}

#define yes cout<<"YES\n";
#define no cout<<"NO\n";


#define MOD 1000000007
#define MOD1 998244353
#define int long long int

#define INF 1e18
#define pb push_back
#define ppb pop_back
#define mp make_pair
#define ss second
#define ff first
#define PI 3.141592653589793238462
#define set_bits __builtin_popcountll
#define sz(x) ((int)(x).size())
#define all(x) (x).begin(), (x).end()
#define v(_x) vector<_x>
#define pii pair<int,int>
#define FOR(i,j,k) for(int i=j;i<k;i++)

typedef long long ll;
typedef unsigned long long ull;
typedef long double lld;

void read(vi &arr){for(auto &i:arr){cin>>i;}}
void read(vvi &arr){for(auto &i:arr){for(auto &j:i){ cin>>j;}}}
void read(vpi & arr){for(auto &i:arr){cin>>i.ff>>i.ss;}}

const int sieveSize = 1;
int sieve[sieveSize];

const int combSize=1;
int fact[combSize];int modinv[combSize];

long long get_hash(string &s){long long hash=0;for(auto c:s) hash=(hash*31+(c-'a'+1))%MOD;return hash;}
long long ncr(long long n,long long r){if(n<0 || r<0 || r>n){return 0;}return (((fact[n]*modinv[r])%MOD)*modinv[n-r])%MOD;}

long long fexpo(long long base,long long x,int mod=MOD){base%=mod;long long ans=1;while(x){if(x&1){ans=(base*ans)%mod;}base=(base*base)%mod;x>>=1;}return ans;}

const int haveTestCase=1;
void solve(int testcase){
    int n,m;
    cin>>n>>m;

    vvi dp1(n,vi(m,0));

    vvi arr(n,vi(m,0));
    vvi dp2=dp1;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cin>>arr[i][j];
        }
    }

    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            if(i==0 && j==0){
                dp1[i][j]=arr[i][j];continue;
            } 
            dp1[i][j]=max(i>=1?dp1[i-1][j]:-INF,j>=1?dp1[i][j-1]:-INF)+arr[i][j];
        }
    }

    for(int i=n-1;i>=0;i--){
        for(int j=m-1;j>=0;j--){
            if(i==n-1 && j==m-1){
                dp2[i][j]=arr[i][j];
                continue;
            }
            dp2[i][j]=max((i+1)<n?dp2[i+1][j]:-INF,(j+1)<m?dp2[i][j+1]:-INF)+arr[i][j];
        }
    }

    int ans=INF;

    for(int j=0;j<m;j++){
        multiset<int> pq;
        pq.insert(-INF);
        for(int i=0;i<n;i++){
            if(j-1>=0){
                pq.insert(dp2[i][j]+dp1[i][j-1]);
            }
        }

        for(int i=0;i<n;i++){
            if(j-1>=0){
                pq.erase(pq.find(dp2[i][j]+dp1[i][j-1]));
            }
            int curr;
            if(i==0 && j==0){
                curr=dp2[i][j];
            }else{
                curr=max(i>=1?dp1[i-1][j]:-INF,j>=1?dp1[i][j-1]:-INF)+dp2[i][j];
            }
            curr-=arr[i][j];
            ans=min({ans,max(*pq.rbegin(),curr)});
            if(j+1<m){
                pq.insert(dp1[i][j]+dp2[i][j+1]);
            }
        }
    }
    cout<<ans<<"\n";
}

void precomp();

int totalTestCase=1;

int32_t main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    std::cout << std::fixed << std::setprecision(15);
    precomp();
    if(haveTestCase){
        cin>>totalTestCase;
    }
    for(int i=1;i<=totalTestCase;i++){
        solve(i);
    }
    return 0;
}

void precomp(){
    if (sieveSize >= 2){ 
        for (int i = 2; i * i < sieveSize; i++){
            if (sieve[i] == 0){
                for (int j = i * i; j < sieveSize; j += i){
                    if(sieve[j]==0)
                        sieve[j] = i;
                }
            }
        }
    }
    if(combSize>2){
        modinv[0]=1;
        fact[0]=1;
        for(int i=1;i<combSize;i++){
            fact[i]=(fact[i-1]*i)%MOD;
            modinv[i]=fexpo(fact[i],MOD-2);
        }
    }
};
