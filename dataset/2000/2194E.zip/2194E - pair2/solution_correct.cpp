#define _USE_MATH_DEFINES
#include <bits/stdc++.h>
#include <algorithm>
#include <sstream>
#include <cmath>

using namespace std;

typedef long long int llint;
typedef unsigned long long int ullint;

int case_ = 1;


struct llint_pair {
	int first;
	int second;
};


//bool compare(llint_pair i, llint_pair j) {
//	if (i.first == j.first) {
//		return i.second < j.second;
//	}
//	return i.first < j.first;
//}

//struct cmp {
//	bool operator()(llint_pair a, llint_pair b) {
//		return a.first < b.first; 큰게 top
//	}
//};


//void print(vector<llint> li) {
//	for (int i = 0; i < li.size(); i++) {
//		cout << li[i] << " ";
//	}
//	cout << "\n";
//}

int n,m;
vector<vector<llint>> maps;
vector<vector<llint>> dp; 
vector<vector<llint>> dp2; //1,1에서 여기까지 오는거
vector<vector<llint>> dp3; //가는거
vector<vector<llint>> bang; //방문
vector<vector<llint>> bang2; //방문

llint dps(int y,int x){
    if(dp[y][x]!=-1)return dp2[y][x];

    
    if(y > 0 and x > 0){
        dp2[y][x] = dps(y-1,x);
        dp[y][x] = 0;
        if(dp2[y][x] < dps(y,x-1)){
            dp2[y][x] = dps(y,x-1);
            dp[y][x] = 1;
        }
        else if(dp2[y][x] == dps(y,x-1)){
            dp[y][x] = 2;
        }
        dp2[y][x] +=maps[y][x];
    }
    else if(y > 0) {
        dp2[y][x] = dps(y-1,x)+maps[y][x];
        dp[y][x] = 0;
    }
    else if(x > 0) {
        dp2[y][x] = dps(y,x-1)+maps[y][x];
        dp[y][x] = 1;
    }
    else{
        dp[y][x] = 2;
        dp2[y][x] = maps[y][x];
    }
    //cout << y << ' '<< x<<" "<<dp2[y][x]<<"\n";
    return dp2[y][x];
}
llint dps2(int y,int x){
    if(dp3[y][x]!=-1000000000000001)return dp3[y][x];

    if(y < n-1 and x < m-1){
        dp3[y][x] = max(dps2(y+1,x),dps2(y,x+1))+maps[y][x];
    }
    else if(y < n-1) {
        dp3[y][x] = dps2(y+1,x)+maps[y][x];
    }
    else if(x < m-1) {
        dp3[y][x] = dps2(y,x+1)+maps[y][x];
    }
    else{
        dp3[y][x] = maps[y][x];
    }

    //cout << y << ' '<< x<<" "<<dp3[y][x]<<"\n";
    return dp3[y][x];
}


int sol2() {
    cin >> n>>m;
    
    for (int i = 0;i <n;i++){
        maps.push_back({});
        dp.push_back({});
        dp2.push_back({});
        for(int j = 0;j<m;j++){
            llint inp;
            cin >>inp;
            maps[i].push_back(inp);
            dp[i].push_back(-1);
            dp2[i].push_back(0);
        }
    }
    llint rr = dps(n-1,m-1);
    for (int maxy = 0;maxy <n;maxy++){
        for(int maxx = 0;maxx<m;maxx++){
            maps[maxy][maxx] = -maps[maxy][maxx];
            for (int i = 0;i <n;i++){
                for(int j = 0;j<m;j++){
                    dp[i][j]=-1;
                    dp2[i][j]=0;
                }
            }
            //cout << maxy <<" " << maxx<<" " <<dps(n-1,m-1)<<"\n";
            rr = min(rr, dps(n-1,m-1));
            maps[maxy][maxx] = -maps[maxy][maxx];
        }
    
    }
    cout << rr<<'\n';
    for (int i = 0;i <n;i++){
        maps[i].clear();
        dp[i].clear();
        dp2[i].clear();
    }

	return 0;
}

int sol() {
    cin >> n>>m;
    
    for (int i = 0;i <n;i++){
        maps.push_back({});
        dp.push_back({});
        dp2.push_back({});
        dp3.push_back({});
        bang.push_back({});
        bang2.push_back({});
        for(int j = 0;j<m;j++){
            llint inp;
            cin >>inp;
            maps[i].push_back(inp);
            dp[i].push_back(-1);
            dp2[i].push_back(0);
            dp3[i].push_back(-1000000000000001);
            bang[i].push_back(-1000000000000001);
            bang2[i].push_back(-1000000000000001);
        }
    }
    llint rr = dps(n-1,m-1);
    dps2(0,0);
    //cout << dps(n-1,m-1)<<"\n";

    deque<llint_pair> q;
    q.clear();
    // llint maxy = n-1;
    // llint maxx = m-1;
    // llint maxs = maps[maxy][maxx];
    q.push_back({n-1,m-1});
    
    for (int maxy = 0;maxy <n;maxy++){
        llint drr3 = -1000000000000001;
        for(int maxx = m-1;maxx>-1;maxx--){
            drr3 = max(drr3,dps2(maxy,maxx)+dps(maxy,maxx)-maps[maxy][maxx]);
            bang[maxy][maxx] = drr3;
        }
    }
    for (int maxx = 0;maxx <m;maxx++){
        llint drr3 = -1000000000000001;
        for(int maxy = n-1;maxy>-1;maxy--){
            drr3 = max(drr3,dps2(maxy,maxx)+dps(maxy,maxx)-maps[maxy][maxx]);
            bang2[maxy][maxx] = drr3;
        }
    }

    for (int maxy = 0;maxy <n;maxy++){
        for(int maxx = 0;maxx<m;maxx++){
            llint_pair qpop ={maxy,maxx};
            llint drr = dps2(qpop.first,qpop.second)+dps(qpop.first,qpop.second)-maps[qpop.first][qpop.second]*3;
            llint drr2 = -1000000000000001;
            


            if(qpop.second!=0 and qpop.first<n-1){
                drr2 = max(drr2,bang2[qpop.first+1][qpop.second-1]);
            }
            if(qpop.first!=0 and qpop.second<m-1){
                drr2 = max(drr2,bang[qpop.first-1][qpop.second+1]);
            }

            //cout << qpop.first<<" "<<qpop.second<<" "<< drr<<" "<<drr2<<"\n";

            rr = min(rr,max(drr,drr2));
        }
    }
    

    cout << rr<<"\n";
    for (int i = 0;i <n;i++){
        maps[i].clear();
        dp[i].clear();
        dp2[i].clear();
        dp3[i].clear();
        bang[i].clear();
        bang2[i].clear();
    }

	return 0;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);

	cin >> case_;

	for (int i = 0; i < case_; i++) {
		if (sol()) break;
	}

	//while (!sol()) {

	//}


}






