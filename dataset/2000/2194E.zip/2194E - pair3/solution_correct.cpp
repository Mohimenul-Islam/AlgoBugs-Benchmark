#include <bits/stdc++.h>

using namespace std;
using ll = long long;

#define all(x) x.begin(), x.end()
#define fi first
#define se second
#define int ll

template <typename T>
istream& operator >> (istream& is, pair<T, T>& p) {
    return is >> p.fi >> p.se;
}

template<typename T>
ostream& operator << (ostream& os, vector<T>& v) {
    for (auto& el : v) {
        os << el  << " ";
    }
    return os;
}

template <typename T>
istream& operator >> (istream& is, vector<T>& v) {
    for (auto& el : v) {
        is >> el;
    }
    return is;
}

template <typename T>
vector<T> operator += (vector<T>& a, vector<T>& b) {
    for (auto& el : b) {
        a.push_back(el);
    }
    return a;
}

void solve();

signed main() {
    #ifndef ONLINE_JUDGE
        freopen("test.in", "r", stdin);
        freopen("test.out", "w", stdout);
    #endif
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    ll tt = 1;
    cin >> tt;
    while (tt--) {
        solve();
    }
    return 0;
}

const int INF = 1e18;
const pair<int, int> NoPrev = {-1, -1};

void solve() {
    int n, m;
    cin >> n >> m;
    vector<vector<int>> v(n, vector<int>(m));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            cin >> v[i][j];
        }
    }

    
//////////////////////////////////////////////////////////////////////////////////////////////
    
    vector<vector<int>> dp1(n, vector<int>(m, -INF));
    vector<vector<pair<int, int>>> prev(n, vector<pair<int, int>>(m, NoPrev));
    dp1[0][0] = v[0][0];
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            if (j > 0) {
                dp1[i][j] = dp1[i][j - 1] + v[i][j];
                prev[i][j] = {i, j - 1};
            }
            if (i > 0) {
                if (dp1[i - 1][j] + v[i][j] > dp1[i][j]) {
                    dp1[i][j] = v[i][j] + dp1[i - 1][j];
                    prev[i][j] = {i - 1, j};
                }
            }
        }
    }
    //cout << dp1[n - 1][m - 1] << "\n";
    vector<pair<int, int>> cond;
    pair<int, int> cur = {n - 1, m - 1};
    while (cur != NoPrev) {
        cond.push_back(cur);
        cur = prev[cur.fi][cur.se];
    }

//////////////////////////////////////////////////////////////////////////////////////////////

    vector<vector<int>> dp2(n, vector<int>(m, -INF));
    dp2[n - 1][m - 1] = v[n - 1][m - 1];
    for (int i = n - 1; i >= 0; i--) {
        for (int j = m - 1; j >= 0; j--) {
            if (j + 1 < m) {
                dp2[i][j] = dp2[i][j + 1] + v[i][j];
            }
            if (i + 1 < n) {
                dp2[i][j] = max(dp2[i][j], dp2[i + 1][j] + v[i][j]);
            }
        }
    }

//////////////////////////////////////////////////////////////////////////////////////////////

    int ans = dp1[n - 1][m - 1];
    for (auto [i, j] : cond) {
        int cur = dp1[n - 1][m - 1] - 2 * v[i][j];
        int ci = i, cj = j;
        //cout << i << " " << j << ": " << v[i][j]<< "!\n";
        i++; j--;
        while (i < n && j >= 0) {
            cur = max(cur, dp1[i][j] + dp2[i][j] - v[i][j]);
            //cout << i << " " << j << ": " << v[i][j]<< "!\n";
            i++; j--;
        }
        i = ci - 1; j = cj + 1;
        while (i >= 0 && j < m) {
            cur = max(cur, dp1[i][j] + dp2[i][j] - v[i][j]);
            //cout << i << " " << j << ": " << v[i][j]<< "!\n";
            i--; j++;
        }
        ans = min(ans, cur);
        //cout << "\n\n\n";
    }
    cout << ans << "\n";
}