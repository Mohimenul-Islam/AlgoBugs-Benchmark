#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<ll> bigL;
typedef vector<int> smolL;

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define sz(x) int((x).size())
#define bisect_left(v, x) (int)(lower_bound((v).begin(), (v).end(), (x)) - (v).begin())
#define bisect_right(v, x) (int)(upper_bound((v).begin(), (v).end(), (x)) - (v).begin())
const ll INF = INT64_MAX >> 1;

template <typename type>
vector<type> readList(int n)
{
    vector<type> arr(n);

    for (ll i = 0; i < n; ++i)
        cin >> arr[i];

    return arr;
}

// ------------------------------------------------ //
void solve()
{
    int n, m;
    cin >> n >> m;
    vector<vector<ll>> mat;

    for (int i = 0; i < n; i++)
    {
        mat.push_back(readList<ll>(m));
    }

    auto pref = mat;
    auto suff = mat;
    pref[0][0] = mat[0][0];
    suff[n - 1][m - 1] = mat[n - 1][m - 1];
    for (int row = 0; row < n; row++)
    {
        for (int col = 0; col < m; col++)
        {
            if (row != 0 || col != 0)
            {
                pref[row][col] += max(col ? pref[row][col - 1] : -INF, row ? pref[row - 1][col] : -INF);
            }
            int row1 = (n - 1) - row, col1 = (m - 1) - col;
            if (row1 != n - 1 || col1 != m - 1)
            {
                suff[row1][col1] += max(col1 < m - 1 ? suff[row1][col1 + 1] : -INF, row1 < n - 1 ? suff[row1 + 1][col1] : -INF);
            }
        }
    }
    auto dp = mat;
    for (int row = n - 1; row > -1; --row)
    {
        for (int col = m - 1; col > -1; --col)
        {
            dp[row][col] = pref[row][col] + suff[row][col] - mat[row][col];
            suff[row][col] = max(dp[row][col], (col < m - 1 ? suff[row][col + 1] : -INF));
            pref[row][col] = max(dp[row][col], row < n - 1 ? pref[row + 1][col] : -INF);
        }
    }

    ll ans = INF;
    for (int row = 0; row < n; ++row)
    {
        for (int col = 0; col < m; ++col)
        {
            auto up = row and col < m - 1 ? suff[row - 1][col + 1] : -INF;
            auto down = col and row < n - 1 ? pref[row + 1][col - 1] : -INF;
            ans = min(ans, max(dp[row][col] - 2ll * (mat[row][col]), max(up, down)));
        }
    }

    cout << ans << endl;
    return;
}

int main()
{
    ios ::sync_with_stdio(false);
    cin.tie(nullptr);
    ll t = 1;
    cin >> t;

    while (t--)
        solve();
}