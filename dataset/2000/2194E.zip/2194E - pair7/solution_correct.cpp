#pragma G++ optimize(3);
#include <bits/stdc++.h>
#define rep(i,from,to)	for (i = (from);i <= (to);i++)
#define per(i,from,to)	for (i = (from);i >= (to);i--)
#define ll long long
#define int long long 
#define ull unsigned long long
#define pii pair<int, int> 
#define lowbit(x) (x&-x) 
#define equal	==
#define endl '\n'
inline int read() { int s = 0, w = 1;char c = getchar();while (c < 48 || c>57) { if (c == '-') w = -1;c = getchar(); }while (c >= 48 && c <= 57)s = (s << 1) + (s << 3) + c - 48, c = getchar();return s * w; }
inline void print(int x) { if (x < 0) putchar('-'), x = -x;if (x > 9)print(x / 10);putchar(x % 10 + 48); }
const int mod = 998244353;
const int inf = 1e9;
const int llf = 4e18;
using namespace std;

const int maxn = 2e5 + 5;
int n, m, k, q;

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	int i, j;
	int tt = 1;
	cin >> tt;
	while (tt--)
	{
		cin >> n >> m;
		vector<vector<int>>squ(n + 2, vector<int>(m + 2));
		vector<vector<int>>dp1(n + 2, vector<int>(m + 2, -llf));
		vector<vector<int>>dp2(n + 2, vector<int>(m + 2, -llf));
		vector<vector<int>>premax(n + 2, vector<int>(m + 2, -llf));
		vector<vector<int>>sufmax(n + 2, vector<int>(m + 2, -llf));

		rep(i, 1, n)rep(j, 1, m)
		{
			cin >> squ[i][j];
		}

		//meet from two ends
		dp1[1][0] = dp2[n][m + 1] = 0;
		rep(i, 1, n)rep(j, 1, m)
		{
			dp1[i][j] = max(dp1[i - 1][j], dp1[i][j - 1]) + squ[i][j];
		}
		per(i, n, 1)per(j, m, 1)
		{
			dp2[i][j] = max(dp2[i + 1][j], dp2[i][j + 1]) + squ[i][j];
		}

		rep(i, 1, n)rep(j, 1, m)//必经之地[i,j];
		{
			premax[i][j] = sufmax[i][j] = dp1[i][j] + dp2[i][j] - squ[i][j];
		}
		//max
		int sum;
		rep(sum, 2, n + m)//i+j
		{
			rep(i, max(sum - m, 1ll), min(sum - 1, n))
			{
				j = sum - i;
				if (j >= 1 && j <= m)
					premax[i][j] = max(premax[i][j], premax[i - 1][j + 1]);
			}
			per(i, min(sum - 1, n), max(sum - m, 1ll))
			{
				j = sum - i;
				if (j >= 1 && j <= m)
					sufmax[i][j] = max(sufmax[i][j], sufmax[i + 1][j - 1]);
			}
		}

		int ans = llf;

		rep(i, 1, n)rep(j, 1, m)
		{
			int tempans = max(max(premax[i - 1][j + 1], sufmax[i + 1][j - 1]), dp1[i][j] + dp2[i][j] - 3 * squ[i][j]);
			ans = min(tempans, ans);
		}
		cout << ans << endl;

	}
	//assert(0);	//debug修改数据上限maxn时使用，或者提醒自己需要init
}