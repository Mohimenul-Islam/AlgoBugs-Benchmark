#include <bits/stdc++.h>
using namespace std;

#define all(vec) (vec).begin(), (vec).end()
#define rall(vec) (vec).rbegin(), (vec).rend()
#define sortAll(vec) sort(all(vec))
#define sortRevAll(vec) sort(rall(vec))
#define bisect_left(vec, x) (lower_bound(all(vec), x) - (vec).begin())
#define bisect_right(vec, x) (upper_bound(all(vec), x) - (vec).begin())

// --- TYPES ---
using ll = long long;
using vll = vector<ll>;
using vi = vector<int>;
template<size_t N> using arrll = array<ll, N>;
template<size_t N> using arrint = array<int, N>;
template<size_t N> using varrll = vector<arrll<N>>;
template <typename type> using max_heap = priority_queue<type>;
template <typename type> using min_heap = priority_queue<type, vector<type>, greater<type>>;

// --- INPUT HELPER ---
template<typename T = ll> vector<T> getList(int n) { vector<T> v(n); for(auto &x : v) cin >> x; return v; }
template <typename T, size_t N> istream& operator>>(istream& is, array<T, N>& a) { for (auto& x : a) is >> x; return is; }

// --- OUTPUT HELPER ---
template <typename T, typename U> ostream& operator<<(ostream& os, const pair<T, U>& p) { os << p.first << " " << p.second; return os; }
template <typename T, size_t N> ostream& operator<<(ostream& os, const array<T, N>& a) { for (size_t i = 0; i < N; ++i) { if (i > 0) os << " "; os << a[i]; } return os; }
template <typename T> ostream& operator<<(ostream& os, const vector<T>& v) { for (int i = 0; i < v.size(); ++i) { if (i > 0) os << " "; os << v[i]; } return os; }
template <typename T, size_t N, typename = enable_if_t<!is_same_v<T, char>>> ostream& operator<<(ostream& os, const T (&arr)[N]) { for (size_t i = 0; i < N; ++i) { if (i > 0) os << " "; os << arr[i]; } return os; }

// --- CUSTOM HASH ---
struct custom_hash { static uint64_t splitmix64(uint64_t x) { x += 0x9e3779b97f4a7c15; x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9; x = (x ^ (x >> 27)) * 0x94d049bb133111eb; return x ^ (x >> 31); }
    size_t operator()(uint64_t x) const { static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count(); return splitmix64(x + FIXED_RANDOM); } };
template <typename K = ll> using safe_set = unordered_set<K, custom_hash>;
template <typename K = ll, typename V = ll> using safe_map = unordered_map<K, V, custom_hash>;

// --- DEBUGGER ---
template <typename T> void print_debug(const set<T>& s);
template <typename T> void print_debug(const deque<T>& d);
template <typename T> void print_debug(const vector<T>& v);
template <typename T, size_t N> void print_debug(const T (&arr)[N]);
template <typename T, size_t N> void print_debug(const array<T, N>& a);
template <typename K, typename V> void print_debug(const map<K, V>& m);
template <typename T, typename U> void print_debug(const pair<T, U>& p);
template <typename T, typename H> void print_debug(const unordered_set<T, H>& s);
template <typename T, typename C, typename Cm> void print_debug(priority_queue<T, C, Cm> q);
template <typename K, typename V, typename H> void print_debug(const unordered_map<K, V, H>& m);

template <typename T> void print_debug(const T& x) { cerr << x; }
template <typename T, typename U> void print_debug(const pair<T, U>& p) { cerr << "("; print_debug(p.first); cerr << ", "; print_debug(p.second); cerr << ")"; }
template <typename T> void print_debug(const deque<T>& d) { cerr << "["; for (int i = 0; i < d.size(); ++i) { if (i > 0) cerr << ", "; print_debug(d[i]); } cerr << "]"; }
template <typename T> void print_debug(const vector<T>& v) { cerr << "["; for (int i = 0; i < v.size(); ++i) { if (i > 0) cerr << ", "; print_debug(v[i]); } cerr << "]"; }
template <typename T, size_t N> void print_debug(const array<T, N>& a) { cerr << "["; for (size_t i = 0; i < N; ++i) { if (i > 0) cerr << ", "; print_debug(a[i]); } cerr << "]"; }
template <typename T> void print_debug(const set<T>& s) { cerr << "{"; bool first = true; for (const auto& x : s) { if (!first) cerr << ", "; print_debug(x); first = false; } cerr << "}"; }
template <typename T, typename H> void print_debug(const unordered_set<T, H>& s) { cerr << "{";  bool first = true;  for (const auto& x : s) { if (!first) cerr << ", ";  print_debug(x);  first = false;  } cerr << "}"; }
template <typename T, typename C, typename Cm> void print_debug(priority_queue<T, C, Cm> q) { cerr << "{"; bool first = true; while (!q.empty()) { if (!first) cerr << ", "; print_debug(q.top()); q.pop(); first = false; } cerr << "}"; }
template <typename T, size_t N> void print_debug(const T (&arr)[N]) { if constexpr (is_same_v<T, char>) { cerr << arr; return; } cerr << "["; for (size_t i = 0; i < N; ++i) { if (i > 0) cerr << ", "; print_debug(arr[i]); } cerr << "]"; }
template <typename K, typename V> void print_debug(const map<K, V>& m) { cerr << "{"; bool first = true; for (const auto& p : m) { if (!first) cerr << ", "; print_debug(p.first); cerr << ": "; print_debug(p.second); first = false; } cerr << "}"; }
template <typename K, typename V, typename H> void print_debug(const unordered_map<K, V, H>& m) { cerr << "{"; bool first = true; for (const auto& p : m) { if (!first) cerr << ", "; print_debug(p.first); cerr << ": "; print_debug(p.second); first = false; } cerr << "}"; }
void dbg_out() { cerr << endl; }
template<typename Head, typename... Tail> void dbg_out(Head H, Tail... T) { print_debug(H); cerr<<' '; dbg_out(T...); }
#define debug(...) cerr << "(" << #__VA_ARGS__ << "): ", dbg_out(__VA_ARGS__)

// --- CONSTANTS ---
const ll INF = LLONG_MAX >> 1;

void solve() {
    int n, m; cin>>n>>m;
    vector<vll> a; for(int i = 0; i < n; ++i) a.push_back(getList(m));
    auto dp1 = a; for(int i = 1; i < n; ++i) dp1[i][0] += dp1[i - 1][0]; for(int j = 1; j < m; ++j) dp1[0][j] += dp1[0][j - 1];
    for(int i = 1; i < n; ++i) for(int j = 1; j < m; ++j) dp1[i][j] += max(dp1[i - 1][j], dp1[i][j - 1]);
    auto dp2 = a; for(int i = n - 2; i >= 0; --i) dp2[i][m - 1] += dp2[i + 1][m - 1]; for(int j = m - 2; j >= 0; --j) dp2[n - 1][j] += dp2[n - 1][j + 1];
    for(int i = n - 2; i >= 0; --i) for(int j = m - 2; j >= 0; --j) dp2[i][j] += max(dp2[i + 1][j], dp2[i][j + 1]);
    auto dp = a; for(int i = 0; i < n; ++i) for(int j = 0; j < m; ++j) dp[i][j] = dp1[i][j] + dp2[i][j] - a[i][j];
    for(int i = n - 1; i >= 0; --i) for(int j = m - 1; j >= 0; --j) dp1[i][j] = max(dp[i][j], i < n - 1 ? dp1[i + 1][j] : -INF), dp2[i][j] = max(dp[i][j], j < m - 1 ? dp2[i][j + 1] : -INF);
    ll ans = INF;
    for(int i = 0; i < n; ++i) for(int j = 0; j < m; ++j){
        ll val = dp[i][j] - 2ll * a[i][j];
        if(i < n - 1 and j) val = max(val, dp1[i + 1][j - 1]);
        if(j < m - 1 and i) val = max(val, dp2[i - 1][j + 1]);
        ans = min(ans, val);
    }
    cout<<ans<<endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(15);

    int t = 1;
    cin >> t;
    while (t--) solve();
    return 0;
}