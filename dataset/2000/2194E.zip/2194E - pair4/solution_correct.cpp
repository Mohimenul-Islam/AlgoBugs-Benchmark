	#include <bits/stdc++.h>

	#define x first
	#define y second

	using i64 = long long;
	using PII = std::pair<int, int>;

	void solve() {
		int n, m;
		std::cin >> n >> m;
		std::vector a(n + 1, std::vector<i64>(m + 1));

		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				std::cin >> a[i][j];
			}
		}

		//f[i][j] 从 [1][1] 到 [i][j] 的最大值
		std::vector f(n + 1, std::vector<i64>(m + 1, -4e18));
		//g[i][j] 从 [i][j] 到 [n][m] 的最大值
		std::vector g(n + 1, std::vector<i64>(m + 1, -4e18));

		// for (int i = 0; i <= n; i++) f[i][0] = 0;
		// for (int i = 0; i <= m; i++) f[0][i] = 0;
		f[1][1] = a[1][1];
		g[n][m] = a[n][m];
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				if (i == 1 && j == 1) continue;
				if (i > 1) f[i][j] = std::max(f[i][j], f[i - 1][j] + a[i][j]);
	        	if (j > 1) f[i][j] = std::max(f[i][j], f[i][j - 1] + a[i][j]);
			}
		}

		for (int i = n; i >= 1; i--) {
			for (int j = m; j >= 1; j--) {
				if (i == n && j == m) continue;
				if (i < n) g[i][j] = std::max(g[i][j], g[i + 1][j] + a[i][j]);
				if (j < m) g[i][j] = std::max(g[i][j], g[i][j + 1] + a[i][j]);
			}
		}

		// for (int i = 1; i <= n; i++) {
		// 	for (int j = 1; j <= m; j++) {
		// 		std::cout << f[i][j] << ' ';
		// 	} std::cout << '\n';
		// }

		// for (int i = 1; i <= n; i++) {
		// 	for (int j = 1; j <= m; j++) {
		// 		std::cout << g[i][j] << ' ';
		// 	} std::cout << '\n';
		// }

		//[i][j] 或者 [i + 1][j - 1]
		std::vector lmax(n + 2, std::vector<i64>(m + 2, -4e18));
		//[i][j] 或者 [i - 1][j + 1]
		std::vector rmax(n + 2, std::vector<i64>(m + 2, -4e18));

		for (int i = n; i >= 1; i--) {
			for (int j = 1; j <= m; j++) {
				if (i < n) lmax[i][j] = std::max(lmax[i][j], lmax[i + 1][j]);
				lmax[i][j] = std::max({lmax[i][j - 1], lmax[i][j], f[i][j] + g[i][j] - a[i][j]});
			}
		}

		for (int i = 1; i <= n; i++) {
			for (int j = m; j >= 1; j--) {
				if (j < m) rmax[i][j] = std::max(rmax[i][j], rmax[i][j + 1]);
				rmax[i][j] = std::max({rmax[i - 1][j], rmax[i][j], f[i][j] + g[i][j] - a[i][j]});
			}
		}

		i64 ans = 4e18;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				i64 maxn = f[i][j] + g[i][j] - 3 * a[i][j];
				if (i < n && j > 1) maxn = std::max(maxn, lmax[i + 1][j - 1]);
				if (j < m && i > 1) maxn = std::max(maxn, rmax[i - 1][j + 1]);
				ans = std::min(ans, maxn);
			}
		}
		std::cout << ans << '\n';
	}

	int main() {
		std::ios::sync_with_stdio(false);
		std::cin.tie(nullptr);

		int t = 1;
		std::cin >> t;
		while (t--) solve();

		return 0;
	}