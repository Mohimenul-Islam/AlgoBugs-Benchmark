//////////////
//  |fly|  //
////////////

#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
using namespace __gnu_pbds;
using namespace std;
#define int long long
#define F first
#define S second
const int mod1 = 998244353; const int mod = (int)(1e9 + 7); const int INF = LLONG_MAX>>1;
using hash_map = gp_hash_table<int, int>;
template<typename T>
using ordered_set = tree<
    T,
    null_type,
    less<T>,
    rb_tree_tag,
    tree_order_statistics_node_update
>;
#define pb push_back
#define ppb pop_back
#define pf push_front
#define ppf pop_front
#define srt(arr) sort((arr).begin(), (arr).end())
#define lb(arr, x) lower_bound((arr).begin(), (arr).end(), (x))
#define ub(arr, x) upper_bound((arr).begin(), (arr).end(), (x))
int binexp(int a, int b) {
    int res = 1;
    while (b > 0) {
        if (b & 1) {
            res = res * a;
        }
        a = a * a;
        b >>= 1;
    }
    return res;
}
int modexp(int a, int b) {
    int res = 1;
    while(b > 0) {
        if(b&1) res = (res * a) % mod; a = (a * a) % mod;
        b >>= 1;
    }
    return res;
}
vector<int> fct(5001001, 1), inv(5001001);
int inverse(int n) {
    return modexp(n, mod-2);
}
void freee() {
    for(int i = 1; i < 5001001; i++) fct[i] = (fct[i-1] * i) % mod; 
    inv[5001000] = inverse(fct[5001000]); 
    for(int i = 5000999; i >= 0; i--) inv[i] = ((i+1) * inv[i+1]) % mod;
}
int ncr(int n, int r) {
    if(r > n || n < 0) return 0; 
    return (((fct[n] * inv[r]) % mod) * inv[n-r]) % mod;
}
vector<int> dr = {0, 1, -1, 0};
vector<int> dc = {1, 0, 0, -1};
//north east west
void doin() {
    int n;
    cin >> n;
    vector<string> s(2);
    for(int i = 0; i < 2; i++) cin >> s[i];
    vector<vector<pair<int, int>>> arr(2);
    for(int k = 0; k < 2; k++) {
        string t = s[k];
        string x = t.substr(0, 4);
        vector<pair<int, int>> ans;
        if(x=="0001") {
            ans.pb({0, 2});
            ans.pb({0, 2});
        }
        if(x=="0010") {
            ans.pb({0, 1});
            ans.pb({0, 2});
        }
        if(x=="0011") ans.pb({2, 3});
        if(x=="0100") {
            ans.pb({2, 3});
            ans.pb({1, 3});
        }
        if(x=="0101") {
            ans.pb({1, 3}); ans.pb({0, 1}); ans.pb({0, 2});
        }
        if(x=="0110") ans.pb({1, 2});
        if(x=="0111") ans.pb({1, 3});
        if(x=="1000") {
            ans.pb({1, 3}); ans.pb({0, 3});
        }
        if(x=="1001") {
            ans.pb({1, 2}); ans.pb({0, 3});
        }
        if(x=="1010") {
            ans.pb({0, 2}); ans.pb({2, 3}); ans.pb({1, 3});
        }
        if(x=="1011") {
            ans.pb({2, 3}); ans.pb({1, 3}); ans.pb({0, 3});
        }
        if(x=="1100") ans.pb({0, 1});
        if(x=="1101") {
            ans.pb({0, 1}); ans.pb({0, 2}); ans.pb({0, 3});
        }
        if(x=="1110") ans.pb({0, 2});
        if(x=="1111") ans.pb({0, 3});
        int i = 4;
        while(i < n-1) {
            x = t.substr(i, 2);
            if(x=="11") ans.pb({i, i+1});
            if(x=="01") {
                ans.pb({i-1, i});
                ans.pb({i-1, i+1});
            }
            if(x=="10") {
                ans.pb({i-2, i-1});
                ans.pb({i-2, i});
            }
            i += 2;
        }
        if(n&1 && t[n-1] == '1') {
            ans.pb({n-3, n-2});
            ans.pb({n-3, n-1});
        } 
        arr[k] = ans;
    }
    reverse(arr[1].begin(), arr[1].end());
    cout << (arr[0].size() + arr[1].size()) << "\n";
    for(int i = 0; i < 2; i++) {
        for(int j = 0; j < arr[i].size(); j++) cout << arr[i][j].F+1 << " " << arr[i][j].S+1 << "\n";
    }
}
int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int tt = 1;
    cin >> tt;
    while (tt--) doin();
}
////////////////////////////////
// DID YOU PICK UP THE DROPS //
//////////////////////////////

























