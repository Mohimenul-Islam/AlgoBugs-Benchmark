#include<bits/stdc++.h>
#include <vector>

#define int ll
#define debug(x) cout<<#x<<" = "<<x<<endl;

using namespace std;

using ll = long long;
using ull = unsigned long long;
using ld = long double;
using pii= pair<int,int>;

const int MOD = 1e9 + 7;
const int inf = (1<<31);
const int maxn = 2e5+5;

vector<int> fact(maxn);
vector<int> inv_fact(maxn);

int binpow(int x, int n ){
    int ans=1;
    while(n){
        if(n&1) ans = (ans * x)%MOD;
        n>>=1;
        x = (x*x)%MOD;
    }
    return ans;
}

int C(int n, int k){
    if(n < k || k < 0)return 0;
    return ((fact[n]*inv_fact[k]) % MOD * (inv_fact[n-k]))%MOD;
}


void populate_fact(){
    fact[0]=1;
    for(int i=1;i<maxn;i++)fact[i]=(fact[i-1]*i)%MOD;
    inv_fact[maxn-1] = binpow(fact[maxn-1], MOD-2);
    for(int i=maxn-1;i>0;i--)inv_fact[i-1]=(inv_fact[i]*i)%MOD;
    assert(inv_fact[0]==1);
}

vector<pii> get_steps( string s ){
    int n = s.size();
    vector<pii> ans;

    int b = -1;
    for(int i=0;i<n-1;i++){
        if(s[i]==s[i+1]){
            b=i;
            break;
        }
    }

    if(b==-1){
        ans.push_back({0,2});
        if(s[0]=='0')s[0]='1';else s[0]='0';
        if(s[1]=='0')s[1]='1';else s[1]='0';
        b=2;
    }

    char cur = s[b+1];
    int L = b;
    int R = b+1;

    while(R+1 < n){
        if(s[R+1] != cur)ans.push_back({L, R});
        R++;
        cur = s[R];
    }

    while(L){
        if(s[L-1]!=cur)ans.push_back({L,R});
        L--;
        cur = s[L];
    }

    if(cur == '1')ans.push_back({0,n-1});

    return ans;
}

void solve(){

    int n;
    cin>>n;
    string s;
    string t;
    cin>>s>>t;
    vector<pii> a1 = get_steps(s);
    vector<pii> a2 = get_steps(t);
    reverse(a2.begin(), a2.end());
    cout<<a1.size()+a2.size()<<endl;
    for(auto [l, r] : a1)cout<<l+1<<" "<<r+1<<endl;
    for(auto [l, r] : a2)cout<<l+1<<" "<<r+1<<endl;

}

int32_t main(){

    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int t=1;
    cin>>t;
    while(t--){
        solve();
    }
}
