#include <algorithm>
#include<bits/stdc++.h>
#include <string>
#include <utility>

using namespace std;

using ll = long long;
using ull = unsigned long long;
using ld = long double;
using pll= pair<long long,long long>;

#define int ll
#define debug(x) cout<<#x<<" = "<<x<<endl;

int32_t main(){

    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int t=1;
    cin>>t;
    while(t--){

        int n;
        cin>>n;
        string s;
        string goal;
        cin>>s>>goal;
        if(s==goal){
            cout<<0<<endl;
            continue;
        }

        vector<pair<int, int>> ans;

        int fptr=0;
        int eptr=n-1;

        while(fptr < eptr){
            string subs = s.substr(fptr, eptr-fptr+1);
            string rsub = subs;
            for(int i=0;i<subs.size();i++){
                rsub[i]=subs[subs.size()-i-1];
            }

            if(subs == rsub){
                // perform flip if the
                // front is different from goal
                if(s[fptr]!=goal[fptr]){
                    for(int i=fptr;i<=eptr;i++){
                        if(s[i]=='0')s[i]='1';
                        else s[i]='0';
                    }
                    ans.emplace_back(fptr, eptr);
                    //cout<<" > "<<s<<endl;
                }
                fptr++;
                eptr=n-1;
            }
            else{
                eptr--;
            }
        }

        fptr=0;
        eptr=n-1;
        while(fptr < eptr){
            string subs = s.substr(fptr, eptr-fptr+1);
            string rsub = subs;
            for(int i=0;i<subs.size();i++){
                rsub[i]=subs[subs.size()-i-1];
            }

            if(subs == rsub){
                // perform flip if the
                // front is different from goal
                if(s[eptr]!=goal[eptr]){
                    for(int i=fptr;i<=eptr;i++){
                        if(s[i]=='0')s[i]='1';
                        else s[i]='0';
                    }
                    ans.emplace_back(fptr, eptr);
                    //cout<<" > "<<s<<endl;
                }
                fptr=0;
                eptr--;
            }
            else{
                fptr++;
            }
        }


        if(s != goal){
            cout<<-1<<endl;
        }else{
            cout<<ans.size()<<endl;
            for(auto range : ans){
                cout<<range.first+1 <<" "<<range.second+1<<endl;
            }
        }

    }
}
