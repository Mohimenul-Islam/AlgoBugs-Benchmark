#include <bits/stdc++.h>
using namespace std;
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
#define ordered_multiset tree<long long, null_type, less_equal<long long>, rb_tree_tag, tree_order_statistics_node_update>
#define ordered_set tree<int, null_type,less<int>, rb_tree_tag,tree_order_statistics_node_update>
#define ll long long
#define int long long int
#define Y cout<<"YES"<<endl
#define NO cout<<"NO"<<endl
#define C continue
#define pb push_back
#define ff first
#define ss second
const   int N=2e5+10;;
const   int M=1e9+7;
const   int MOD=998244353;

signed main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin>>T;
    int test=0;
    while(T--){
        int n;
        cin>>n;
        string s,t;
        cin>>s>>t;test++;
        if(test==225)cout<<s<<"h"<<t<<endl;
        if(s==t){
            cout<<0<<endl;
            C;
        }
        vector<pair<int,int>>ans;
        int l=-1,r=-1;
        int cnt=1;
        for(int i=1;i<n;i++){
            if(s[i]==s[i-1])cnt++;
            else{
                if(cnt>=2){
                    l=i-cnt;r=i-1;break;
                }
                cnt=1;
            }
        }
        if(cnt>=2){
            r=n-1;l=n-cnt;
        }
        if(l==-1){
            ans.emplace_back(0,2);
            for(int i=0;i<3;i++){
                if(s[i]=='0')s[i]='1';
                else s[i]='0';
            }
            l=2;r=3;
        }
        while(r-l+1!=n){
            ans.emplace_back(l,r);
            for(int i=l;i<=r;i++){
                if(s[i]=='0')s[i]='1';
                else s[i]='0';
            }
            for(int i=l-1;i>=0;i--){
                if(s[i]==s[l])l--;
                else break;
            }
            for(int i=r+1;i<n;i++){
                if(s[i]==s[r])r++;
                else break;
            }
        }
        for(int i=n-1;i>=4;i--){
            if(s[i]==t[i])continue;
            for(int j=l;j<=i;j++){
                if(s[j]=='0')s[j]='1';
                else s[j]='0';
            }
            ans.emplace_back(l,i);
        }
        l=-1;r=-1;
        for(int i=1;i<4;i++){
            if(t[i]==t[i-1]){
                l=i-1;r=i;break;
            }
        }
        if(l!=-1){
            int cnt=0;
            for(int i=0;i<=l-1;i++){
                if(s[i]==t[i])continue;
                for(int j=i;j<=r;j++){
                    if(s[j]=='0')s[j]='1';
                    else s[j]='0';
                }
                cnt++;
                ans.emplace_back(i,r);
            }
            if(cnt%2!=0){
                for(int i=l;i<=r;i++){
                    if(s[i]=='0')s[i]='1';
                    else s[i]='0';
                }
                ans.emplace_back(l,r);
            }
            for(int i=n-1;i>=r+1;i--){
                if(s[i]==t[i])continue;
                for(int j=l;j<=i;j++){
                    if(s[j]=='0')s[j]='1';
                    else s[j]='0';
                }
                ans.emplace_back(l,i);
            }
            if(s[l]!=t[l]){
                for(int i=l;i<=r;i++){
                    if(s[i]=='0')s[i]='1';
                    else s[i]='0';
                }
                ans.emplace_back(l,r);
            }
        }
        else{
            if(s[0]!=t[0]){
                for(int i=0;i<4;i++){
                    if(s[i]=='0')s[i]='1';
                    else s[i]='0';
                }
                ans.emplace_back(0,3);
            }
            for(int i=0;i<3;i++){
                if(s[i]=='0')s[i]='1';
                else s[i]='0';
            }
            ans.emplace_back(0,2);
            for(int i=0;i<2;i++){
                if(s[i]=='0')s[i]='1';
                else s[i]='0';
            }
            ans.emplace_back(0,1);
            for(int i=1;i<4;i++){
                if(s[i]=='0')s[i]='1';
                else s[i]='0';
            }
            ans.emplace_back(1,3);
        }
        cout<<ans.size()<<endl;
        for(auto &[x,y]:ans){
            cout<<x+1<<" "<<y+1<<endl;
        }
    }
}