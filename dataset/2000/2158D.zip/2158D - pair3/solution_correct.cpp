#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define rep(i,a,b) for(int i=(a);i<(b);i++)
#define repl(i,a,b) for(ll i=(a);i<(b);i++)
#define all(a) (a).begin(),(a).end()
#define rall(a) (a).rbegin(),(a).rend()

template <typename T> bool chmin(T &a,T b){if(a>b){a=b;return true;} return false;}
template <typename T> bool chmax(T &a,T b){if(a<b){a=b;return true;} return false;}

// #include <atcoder/fenwicktree>
// #include <atcoder/segtree>
// #include <atcoder/lazysegtree>
// #include <atcoder/string>
// #include <atcoder/math>
// #include <atcoder/convolution>
// #include <atcoder/modint>
// #include <atcoder/dsu>
// #include <atcoder/maxflow>
// #include <atcoder/mincostflow>
// #include <atcoder/scc>
// #include <atcoder/twosat>
// using namespace atcoder;

void solve(){
  int n; cin >> n;
  string s,t; cin >> s >> t;
  auto sw=[](char &c){
    if(c == '0') c='1';
    else c='0';
  };
  vector<pair<int,int>> ans;
  while(1){
    bool br=false;
    rep(i,0,n-1){
      if(s[i] != s[i+1]) break;
      if(i == n-2){
        br=true;
      }
    }
    if(br) break;
    bool ch=false;
    rep(i,0,n-1){
      if(s[i] == s[i+1]){
        int l=i;
        int r=l;
        while(r<n-1){
          if(s[l] == s[r+1]) r++;
          else break;
        }
        ans.push_back({l+1,r+1});
        rep(j,l,r+1) sw(s[j]);
        ch=true;
        break;
      }
    }
    if(!ch){
      ans.push_back({1,3});
      rep(j,0,3) sw(s[j]);
    }
  }

  vector<pair<int,int>> ans2;
  while(1){
    bool br=false;
    rep(i,0,n-1){
      if(t[i] != t[i+1]) break;
      if(i == n-2){
        br=true;
      }
    }
    if(br) break;
    bool ch=false;
    rep(i,0,n-1){
      if(t[i] == t[i+1]){
        int l=i;
        int r=l;
        while(r<n-1){
          if(t[l] == t[r+1]) r++;
          else break;
        }
        ans2.push_back({l+1,r+1});
        rep(j,l,r+1) sw(t[j]);
        ch=true;
        break;
      }
    }
    if(!ch){
      ans2.push_back({1,3});
      rep(j,0,3) sw(t[j]);
    }
  }
  if(s[0] !=t[0]) ans2.push_back({1,n});
  reverse(all(ans2));
  cout << (int)ans.size()+(int)ans2.size() << "\n";
  for(auto [l,r]:ans) cout << l << " " << r << "\n";
  for(auto [l,r]:ans2) cout << l << " " << r << "\n";
  
  return;
}

int main(){
  ios::sync_with_stdio(false);
  cin.tie(nullptr);

  int T=1;
  cin >> T;
  while(T--){
    solve();
  }
}