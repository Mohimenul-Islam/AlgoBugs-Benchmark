#include <bits/stdc++.h>
using namespace std;
#define ll int
#define N 100005
ll t, n;
string s, s2;
vector<pair<ll,ll> > ans;

void solve(){
    cin >> n >> s >> s2;
    ans.clear();
    s = 'a' + s;
    s2 = 'a' + s2;
    ll flag = 0;
    for(int i = 1; i < n; i++){
        if(s2[i] == s2[i + 1] && s2[i] != s2[i - 1]) flag = i;
    }
    for(int i = 1; i <= n; i++){
        if(s[i] == '1') {
            ll flag2 = 0, j;
            for(j = i + 1; j <= n; j++){
                if(s[j] == '1'){
                    flag2 = 1;
                    break;
                }
            }
            if(flag2){
                ans.push_back({i, j});
                for(int k = i; k <= j; k++){
                    if(s[k] == '1') s[k] = '0';
                    else s[k] = '1';
                }
            }
            else{
                if(i >= 3){
                    ans.push_back({1, i - 1});
                    ans.push_back({1, i});
                }
                else{
                    ans.push_back({i + 1, n});
                    ans.push_back({i, n});
                }
                s[i] = '0';
                break;
            }
        }
    }
    ll cur = 0;
    if(flag){
        for(int i = 1; i < flag; i++){
            if(s2[i] - '0' != cur){
                cur = !cur;
                ans.push_back({i, n});
            }
        }
        for(int i = n; i > flag; i--){
            if(s2[i] - '0' != cur){
                cur = !cur;
                ans.push_back({flag, i});
            }
        }
    }
    else{
        if(n % 2){
            if(s2[1] == '1') ans.push_back({1, n});
            for(int i = 3; i < n; i++){
                ans.push_back({i, n});
            }
            ans.push_back({2, n - 1});
        }
        else{
            if(s2[1] == '1') for(int i = 2; i < n; i++) ans.push_back({i, n});
            else for(int i = 1; i < n; i++) ans.push_back({i, n});
            ans.push_back({1, n - 1});
        }
    }
    cout << ans.size() << "\n";
    for(auto it : ans) cout << it.first << " " << it.second << "\n";
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL), std::cout.tie(NULL);
    cin >> t;
    while(t--){
        solve();
    }
    return 0;
}
