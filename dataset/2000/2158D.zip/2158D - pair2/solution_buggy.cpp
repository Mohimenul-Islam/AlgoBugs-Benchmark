#include<bits/stdc++.h>
using namespace std;
#define int long long

char flip(char c){
    if(c=='0') return '1';
    else return '0';
}

void solve()
{
    int n;cin >> n;
    string s,t;cin >> s >> t;
    s=" "+s;
    t=" "+t;
    int k=0;
    if(s==t){
        cout << 0 << endl << endl;
        return;
    }
    int flag=1;
    for(int i=1;i<=n;i++){
        if(flip(s[i])!=t[i]){
            flag=0;
            break;
        }
    }
    if(flag){
        cout << 1 << endl;
        cout << 1 << " " << n << endl;
        return;
    }
    vector<pair<int,int>> ans;
    int l=0,r=0;
    for(int i=1;i<n;i++){
        if(s[i]==s[i+1]){
            l=i,r=i+1;
            break;
        }
    }
    if(!l){
        k++;
        if(n&1){
            ans.push_back({2,n-1});
            for(int i=2;i<=n-1;i++) s[i]=flip(s[i]);
        }else{
            ans.push_back({1,n-1});
            for(int i=1;i<=n-1;i++) s[i]=flip(s[i]);
        }
        l=n-1,r=n;
    }
    char cur=s[l];
    while(1){
        while(l-1>=1&&s[l-1]==cur) l--;
        while(r+1<=n&&s[r+1]==cur) r++;
        if(l==1&&r==n) break;
        k++;
        cur=flip(cur);
        ans.push_back({l,r});
    }
    int L=0,R=0;
    for(int i=1;i<=n;i++){
        if(t[i]==t[i+1]){
            L=i,R=i+1;
            break;
        }
    }
    if(!L){
        flag=1;
        L=n-1,R=n;
        if(n&1){
            for(int i=2;i<=n-1;i++) t[i]=flip(t[i]);
        }else{
            for(int i=1;i<=n-1;i++) t[i]=flip(t[i]);
        }
    }
    while(1){
        while(l+1<=L&&t[l]==cur) l++;
        while(r-1>=R&&t[r]==cur) r--;
        if(l==L&&r==R) break;
        k++;
        cur=flip(cur);
        ans.push_back({l,r});
    }
    if(cur!=t[L]){
        k++;
        cur=flip(cur);
        ans.push_back({l,r});
    }
    if(flag){
        k++;
        if(n&1){
            ans.push_back({2,n-1});
        }else{
            ans.push_back({1,n-1});
        }
    }
    cout << k << endl;
    for(auto [p,q]:ans) cout << p << " " << q << endl;
}

signed main(void){
    ios::sync_with_stdio(false);
    cin.tie(0);
    int T=1;cin >> T;
    while(T--) solve();
    return 0;
}