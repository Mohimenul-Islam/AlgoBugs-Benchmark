#include <algorithm>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>
#include <numeric>
#include <vector>
#include <chrono>
#include <random>
#include <cmath>
#include <tuple>
#include <stack>
#include <queue>
#include <list>
#include <set>
#include <map>

using namespace std;
typedef long long ll;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	ll t, n, m, k, x, y, z, mod = 1000003;
	cin >> t;
	for (ll i = 0; i < t; i++) {
		cin >> n;
		string s, t;
		cin >> s >> t;
		bool bads = true, badt = true, rev = false;
		for (int i = 0; i < n - 1; i++) {
			if (s[i] == s[i + 1]) bads = false;
			if (t[i] == t[i + 1]) badt = false;
		}
		if (bads && badt) {
			if (s[0] == t[0]) {
				cout << 0 << endl;
			}
			else {
				cout << 1 << endl;
				cout << 1 << ' ' << n << endl;
			}
			continue;
		}
		if (badt) {
			swap(s, t);
			swap(bads, badt);
			rev = true;
		}
		vector<pair<ll, ll>> ans;
		if (bads) {
			ans.push_back({ 0, 2 });
			for (int i = 0; i < 3; i++) {
				if (s[i] == '0') s[i] = '1';
				else s[i] = '0';
			}
		}
		ll l, r;
		for (int i = 0; i < n - 1; i++) {
			if (s[i] == s[i + 1]) {
				l = i, r = i + 1;
				break;
			}
		}
		char cur = s[l];
		for (int i = l - 1; i > -1; i--) {
			if (s[i] == cur) continue;
			cur = s[i];
			ans.push_back({ i + 1, r });
			l = i;
		}
		for (int i = r + 1; i < n; i++) {
			if (s[i] == cur) continue;
			cur = s[i];
			ans.push_back({ 0, i - 1 });
			r = i;
		}
		for (int i = 0; i < n - 1; i++) {
			if (t[i] == t[i + 1]) {
				l = i, r = i + 1;
				break;
			}
		}
		for (int i = 0; i < l; i++) {
			if (t[i] == cur) continue;
			cur = t[i];
			ans.push_back({ i, n - 1 });
		}
		for (int i = n - 1; i > r; i--) {
			if (t[i] == cur) continue;
			cur = t[i];
			ans.push_back({ l, i });
		}
		if (t[l] != cur) ans.push_back({ l, r });
		cout << ans.size() << endl;
		if (rev) reverse(ans.begin(), ans.end());
		for (auto p : ans) cout << p.first + 1 << ' ' << p.second + 1 << endl;
	}
}