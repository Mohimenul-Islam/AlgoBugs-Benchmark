#include<iostream>
#include<string>
#include<cmath>
#include<map>
#include<iomanip>
#include<algorithm>
#include<vector>
#include<set>
#include<cstdio>
#include<stack>
#include<ctime>
#include<queue>
#include<deque>
#include<bitset>
#include<random>
#include<fstream>
#include<numeric>
#include<unordered_map>
#include<unordered_set>
#include<cassert>
using namespace std;
using ll = long long;
using ld = double;
using ull = unsigned long long;
using uint = unsigned int;
using dbl = double;

# define all(x) x.begin(), x.end()
# define rall(x) x.rbegin(), x.rend()

#pragma GCC optimize("O3,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
//#pragma comment(linker, "/STACK:1000000000")

ll gcd(ll a, ll b) {
    return b == 0 ? a : gcd(b, a % b);
}
ll lcm(ll a, ll b) {
    return a / gcd(a, b) * b;
}
ll bpow(ll a, ll n) {
    return n == 0 ? 1 : n % 2 ? bpow(a, n - 1) * a : bpow(a * a, n / 2);
}
ll bpowm(ll a, ll n, ll m) {
    return n == 0 ? 1 : n % 2 ? bpowm(a, n - 1, m) * a % m : bpowm(a * a % m, n / 2, m);
}
mt19937_64 mt(time(0));
const int N = 1e5 + 2, inf = 1e9 + 100, mod = 1e9 + 7, mod2 = 998244353, P = 503077, htm = 5000017;
const ll llinf = 1e18 + 1000;
vector<pair<int, int>> op(string s) {
    int n = s.size();
    string to = string(n, '0');
    vector<pair<int, int>> ans;
    while (s != to) {
        bool f = false;
        for (int i = 0; i + 2 < n; ++i) {
            if (s[i] == '1' && s[i + 1] == '1' && s[i + 2] == '1') {
                s[i] = '0';
                s[i + 1] = '0';
                s[i + 2] = '0';
                ans.push_back({ i, i + 2 });
                f = true;
                break;
            }
        }
        if (f) continue;
        for (int i = 0; i + 1 < n; ++i) {
            if (s[i] == '1' && s[i + 1] == '1') {
                s[i] = '0';
                s[i + 1] = '0';
                ans.push_back({ i, i + 1 });
                f = true;
                break;
            }
        }
        if (f) continue;
        for (int i = 0; i + 2 < n; ++i) {
            if (s[i] == '1' && s[i + 1] == '0' && s[i + 2] == '1') {
                s[i] = '0';
                s[i + 1] = '1';
                s[i + 2] = '0';
                ans.push_back({ i, i + 2 });
                f = true;
                break;
            }
        }
        if (f) continue;
        for (int i = 0; i + 2 < n; ++i) {
            if (s[i] == '0' && s[i + 1] == '0' && s[i + 2] == '1') {
                s[i] = '0';
                s[i + 1] = '0';
                s[i + 2] = '0';
                ans.push_back({ i, i + 1 });
                ans.push_back({ i, i + 2 });
                f = true;
                break;
            }
        }
        if (f) continue;
        for (int i = 0; i + 2 < n; ++i) {
            if (s[i] == '1' && s[i + 1] == '0' && s[i + 2] == '0') {
                s[i] = '0';
                s[i + 1] = '0';
                s[i + 2] = '0';
                ans.push_back({ i + 1, i + 2 });
                ans.push_back({ i, i + 2 });
                f = true;
                break;
            }
        }
        if (f) continue;
    }
    return ans;

}

void solve() {
    int n;
    cin >> n;
    string s1, s2;
    cin >> s1 >> s2;
    vector<pair<int, int>> ans = op(s1);
    vector<pair<int, int>> ans1 = op(s2);
    reverse(all(ans1));
    for (auto p : ans1) ans.push_back(p);
    cout << ans.size() << '\n';
    for (auto p : ans) cout << p.first + 1 << ' ' << p.second + 1 << '\n';
}

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    //freopen("coloring.in", "r", stdin);
    //freopen("coloring.out", "w", stdout);

    //ld time1 = clock();
    int tt = 1;
    cin >> tt;
    while (tt--) {
        solve();
        cout << '\n';
        cout.flush();
    }

    //ld time2 = clock();
    //cerr << "\n\nTIME: " << (time2 - time1) / CLOCKS_PER_SEC;
    return 0;
}