#include <bits/stdc++.h>
#define ll long long
#define db double
#define uint unsigned int 
#define ull unsigned long long
#define i128 __int128_t

#define pii pair<int, int>
#define pll pair<ll, ll>
#define endl "\n"

#define all(x) x.begin(), x.end()
#define all1(x) x.begin() + 1, x.end()

using namespace std;

const int inf = 2e9;
const ll INF = 8e18;
const db eps = 1e-7;
const int N = 1e7 + 7;
const int maxn = 1e6 + 7;

const int mod = 1e6 + 3;

void solve () {
    int n; cin >> n;
    string tmp; cin >> tmp;
    vector<int> s(n + 1);
    for (int i = 0; i < n; i++) s[i + 1] = tmp[i] - '0';
    cin >> tmp;
    vector<int> t(n + 1);
    for (int i = 0; i < n; i++) t[i + 1] = tmp[i] - '0';

    vector<pii> put, put2;

    int l = -1, r = -1;
    for (int i = 1; i < n; i++) if (s[i] == s[i + 1]) {
        l = i, r = i + 1;
        break; 
    }
    if (r == -1) {
        put.push_back({1, 3});
        s[1] ^= 1, s[2] ^= 1, s[3] ^= 1;
        for (int i = 1; i < n; i++) if (s[i] == s[i + 1]) {
            l = i, r = i + 1;
            break; 
        }
    }

    int co = s[l];

    while (l > 1 || r < n) {
        while (l > 1 && s[l - 1] == co) l -= 1;
        while (r < n && s[r + 1] == co) r += 1;

        if (l > 1 && s[l - 1] != co) {
            put.push_back({l, r});
            co = s[l - 1];
        }
        else if (r < n && s[r + 1] != co) {
            put.push_back({l, r});
            co = s[r + 1];
        }
    }

    if (co == 1) put.push_back({l, r});

    l = r = -1;

    // for (int i = 1; i <= n; i++) cerr << t[i] << ' ';
    // cerr << endl;

    for (int i = 1; i < n; i++) if (t[i] == t[i + 1]) {
        l = i, r = i + 1;
        break; 
    }
    if (r == -1) {
        put2.push_back({1, 3});
        t[1] ^= 1, t[2] ^= 1, t[3] ^= 1;
        for (int i = 1; i < n; i++) if (t[i] == t[i + 1]) {
            l = i, r = i + 1;
            break; 
        }
    }

    co = t[l];

    while (l > 1 || r < n) {
        while (l > 1 && t[l - 1] == co) l -= 1;
        while (r < n && t[r + 1] == co) r += 1;

        if (l > 1 && t[l - 1] != co) {
            put2.push_back({l, r});
            co = t[l - 1];
        }
        else if (r < n && t[r + 1] != co) {
            put2.push_back({l, r});
            co = t[r + 1];
        }
    }

    if (co == 1) put2.push_back({l, r});

    reverse(all(put2));

    cout << put.size() + put2.size() << endl;
    for (auto v : put) cout << v.first << ' ' << v.second << endl;
    for (auto v : put2) cout << v.first << ' ' << v.second << endl;
    cout << endl;
}

int main () {
    ios::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);

    int T = 1;
    cin >> T;

    while (T--) {
        solve();
    }

    return 0;
}