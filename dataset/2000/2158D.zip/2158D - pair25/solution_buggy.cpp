#include<bits/stdc++.h>
using namespace std;
#define ld long double
#define int long long
#define fr(i, l, r) for(int i=l;i<=r;++i)
#define frr(i, l, r) for(int i=l;i>=r;i--)
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define ck cout<<"ZTMY"
int mod=1e9+7,inf=INT_MAX;
void solve(){
    int n;
    cin>>n;
    string s1,s2;
    cin>>s1>>s2;
    if(s1==s2){
        cout<<0;
        return;
    }
    int idx=inf;
    for(int i=0;i<n-1;i++){
        if(s1[i]==s1[i+1]){
            idx=i;
            break;
        }
    }if(idx==inf){
        for(int i=0;i<n;i++){
            if(s1[i]==s2[i]){
                cout<<-1;
                return;
            }
        }
        cout<<1<<'\n'<<1<<' '<<n;
        return;
    }
    int l=idx,r=idx+1;
    char p=s1[idx];
    vector<pair<int,int>>v;
    while(r<n-1){
        r++;
        if(s1[r]!=p){
            v.push_back({l+1,r});
            p=(p-'0')^1+'0';
        }
    }
    while(l>=1){
        l--;
        if(s1[l]!=p){
            v.push_back({l+2,r+1});
            p=(p-'0')^1+'0';
        }
    }
    for(int i=0;i<n-1;i++){
        if(s2[i]==s2[i+1]){
            idx=i;
            break;
        }
    }int l1=idx,r1=idx+1;
    char p1=s2[idx];
    vector<pair<int,int>>v1;
    while(r1<n-1){
        r1++;
        if(s2[r1]!=p1){
            v1.push_back({l1+1,r1});
            p1=(p1-'0')^1+'0';
        }
    }while(l1>=1){
        l1--;
        if(s2[l1]!=p1){
            v1.push_back({l1+2,r1+1});
            p1=(p1-'0')^1+'0';
        }
    }
    cout<<v.size()+v1.size()+(p1==p?0:1)<<'\n';
    for(int i=0;i<v.size();i++){
        cout<<v[i].first<<' '<<v[i].second<<'\n';
    }
    if(p1!=p)cout<<1<<' '<<n<<'\n';
    for(int i=v1.size()-1;i>=0;i--){
        cout<<v1[i].first<<' '<<v1[i].second;
        if(i)cout<<'\n';
    }
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int T;
    cin>>T;
	while(T--){
		solve();
		cout<<'\n';
	}
    return 0;
}