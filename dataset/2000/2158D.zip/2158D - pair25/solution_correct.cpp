#include<bits/stdc++.h>
using namespace std;
int n;
vector<pair<int,int>> solve(string s) {
	vector<pair<int,int>> res;
	bool f=1;
	while(f) {
		f=0;
		for(int i=1; i<=n; i++)
			if(s[i]=='1') f=1;
		int l=1,r=3;
		for(int i=1; i<n; i++) {
			if(s[i]!=s[i+1]) continue;
			l=r=i;
			while(s[r]==s[r+1]) r++;
			break;
		}
		for(int i=l; i<=r; i++)
			s[i]=(s[i]=='1'?'0':'1');
		res.push_back({l,r});
	}
	return res;
}
string s,t;
int main() {
	int q; 
    cin>>q;
	while(q--) {
		cin>>n>>s>>t;
        s=" "+s;
        t=" "+t;
		vector<pair<int,int>> a=solve(s);
        vector<pair<int,int>> b=solve(t);
		reverse(b.begin(),b.end());
		cout<<a.size()+b.size()<<endl;
		for(auto x:a) cout<<x.first<<" "<<x.second<<endl;
		for(auto x:b) cout<<x.first<<" "<<x.second<<endl;
	}
    return 0;
}