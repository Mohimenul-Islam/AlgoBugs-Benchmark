#include <iostream>
#include <vector>
#include <climits>
#include <algorithm>
#include <cstring>
#include <utility>
#include <set>
#include <map>
#include <string>
#include <numeric>
#include <iterator>
#include <unordered_map>
#include <cmath>
#include <iomanip>

#define DPRINT(x) for (auto e: x) {std::cerr << e << ' ';}; std::cerr << std::endl
#define DPRINTVAR(x) std::cerr << x << std::endl
#define PRINTBREAK std::cerr << "----------break---------" << std::endl;

#define INF (1e18)
using namespace std;

using ll = long long;
using ull = unsigned long long;

constexpr long long MOD = 998244353;

// ull binpow(ull a, ull b) {
//     ll res = 1;
//     while (b > 0) {
//         if (b & 1)
//             res = (res * a);
//         a = (a * a);
//         b >>= 1;
//     }
//     return res;
// }

vector<vector<pair<int, int>>> basecase = {
    {},
    {{1, 3}, {1, 2}},
    {{0, 2}, {0,1}},
    {{1,3}, {2,3}},
    {{0,2},{1,2}},
    {{2,3}},
    {{1,2}},
    {{0,1}},
    {{0,2},{0,1},{1,3}},
    {{1,3},{2,3},{0,2}},
    {{0,3},{1,2}},
    {{1,3}},
    {{0,3}, {1,3},{2,3}},
    {{0,3},{0,2}, {0,1}},
    {{0,2}},
    {{0,3}}
};



void pushhelp(vector<pair<int, int>>& ans, int i) {
    for (auto e: basecase[i]) {
        ans.push_back(e);
    }
}




void create(string s, vector<pair<int, int>>& ans) {
    int len = s.length();
    for (int i = len - 1; i >= 5; i--) {
        if (s[i] == '0') {
            continue;
        } else if (s[i - 1] == '1') {
            ans.push_back({i-1, i});
            i--;
        } else {
            ans.push_back({i-2, i});
            ans.push_back({i-2, i-1});
        }
    }

    if (len >= 5) {
        if (s[4] == '1') {
            ans.push_back({2, 4});
            ans.push_back({2,3});
        }
    }

    string t; t +=s[0]; t+=s[1]; t+=s[2]; t+=s[3];
        if (t == "0000") {
        }
        else if (t == "0001") {
            pushhelp(ans, 1);
        }
        else if (t == "0010") {
            pushhelp(ans, 2);
        }
        else if (t == "0100") {
            pushhelp(ans, 3);
        }
         else if (t == "1000") {
            pushhelp(ans, 4);
        }
         else if (t == "0011") {
            pushhelp(ans, 5);
        }
         else if (t == "0110") {
            pushhelp(ans, 6);
        }
         else if (t == "1100") {
            pushhelp(ans, 7);
        }
         else if (t == "0101") {
            pushhelp(ans, 8);
        }
         else if (t == "1010") {
            pushhelp(ans, 9);
        }
         else if (t == "1001") {
            pushhelp(ans, 10);
        }
         else if (t == "0111") {
            pushhelp(ans, 11);
        }
         else if (t == "1011") {
            pushhelp(ans, 12);
        }
         else if (t == "1101") {
            pushhelp(ans, 13);
        }
         else if (t == "1110") {
            pushhelp(ans, 14);
        } else if (t == "1111") {
            pushhelp(ans, 15);
        }
        
}



void solve() {
    int n; cin >> n;
    string s, t; cin >> s >> t;
    vector<pair<int,int>> sans, tans;
    create(s, sans);
    create(t, tans);
    int outlen = sans.size() + tans.size();
    reverse(sans.begin(), sans.end());
    cout << outlen << '\n';
    for (auto e: sans) {
        cout << e.first + 1 << ' ' << e.second + 1 << '\n';
    }
    for (auto e: tans) {
        cout << e.first + 1 << ' ' << e.second + 1 << '\n';
    }
}






int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int T; std::cin >> T;
    while (T--) {
        solve();
    }

    return 0;
}