#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define lld long double

vector<pair<int, int>> ff(string &s) {
    vector<pair<int, int>> ans;
    int n = s.size();
    int p = -1;
    for (int i = 0; i < n - 1; i++) {
        if (s[i] == s[i + 1]) {
            p = i;
        }
    }
    if (p == -1) {
        p = 2;
        ans.push_back({0, 2});
        s[0] ^= 1;
        s[1] ^= 1;
        s[2] ^= 1;
    }
    if (s[p] == '1') {
        ans.push_back({p, p + 1});
        s[p] ^= 1;
        s[p + 1] ^= 1;
    }
    for (int i = p + 2; i < n - 1; i++) {
        if (s[i] == '0') continue;
        if (s[i] == s[i + 1] && s[i] == '1') {
            ans.push_back({i, i + 1});
            i++;
        } else if (s[i] != s[i + 1]) {
            ans.push_back({p, i - 1});
            ans.push_back({p, i});
        }
    }
    if (s[n - 1] == '1') {
        ans.push_back({p, n - 2});
        ans.push_back({p, n - 1});
    }
    for (int i = p - 1; i > 0; i--) {
        if (s[i] == '0') continue;
        if (s[i] == s[i - 1] && s[i] == '1') {
            ans.push_back({i - 1, i});
            i--;
        } else if (s[i] != s[i - 1]) {
            ans.push_back({i + 1, p + 1});
            ans.push_back({i, p + 1});
        }
    }
    if (s[0] == '1') {
        ans.push_back({1, p + 1});
        ans.push_back({0, p + 1});
    }
    return ans;
}

void solve() {
    int n;
    cin >> n;
    string s1, s2;
    cin >> s1 >> s2;
    vector<pair<int, int>> ans1 = ff(s1);
    vector<pair<int, int>> ans2 = ff(s2);
    cout << ans1.size() + ans2.size() << endl;
    for (int i = 0; i < ans1.size(); i++) {
        cout << (ans1[i].first + 1) << " " << (ans1[i].second + 1) << endl;
    }
    reverse(ans2.begin(), ans2.end());
    for (int i = 0; i < ans2.size(); i++) {
        cout << (ans2[i].first + 1) << " " << (ans2[i].second + 1) << endl;
    }
}

signed main() {                             
    ios::sync_with_stdio(false);
    cin.tie(0);
    int t;
    cin >> t;
    while(t-- > 0) {
        solve();
    }
    return 0;
}