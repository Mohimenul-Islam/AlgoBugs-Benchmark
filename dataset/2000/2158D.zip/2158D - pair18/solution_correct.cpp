#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<long long> vll;
typedef pair<int, int> pi;
typedef pair<long long, long long> pll;

const long long mod = 1e9 + 7;
const long long inf = LONG_LONG_MAX;

void make_0(string s, vector<pi>& sws) {
  int n = s.size();
  int l = -1, r = -1;
  for (int i = 0; i < n - 1; i++)
    if (s[i] == s[i + 1]) l = i, r = i + 1;
  if (l == -1) sws.push_back({2, 4}), s[1] ^= 1, s[2] ^= 1, s[3] ^= 1, l = 0, r = 1;
  while (r < n - 1) {
    if (s[r + 1] != s[r]) sws.push_back({l + 1, r + 1});
    r++;
  }
  s[l] = s[n - 1];
  while (l > 0) {
    if (s[l - 1] != s[l]) sws.push_back({l + 1, r + 1});
    l--;
  }
  if (s[0] == '1') sws.push_back({1, n});
}

int main() {
  ios::sync_with_stdio(false);
  cin.tie(nullptr);

  ll t;
  cin >> t;
  while (t--) {
    int n;
    cin >> n;
    string s, t;
    cin >> s >> t;
    if (s == t) {
      cout << 0 << '\n';
      continue;
    }
    vector<pi> sws, swt;
    make_0(s, sws), make_0(t, swt);
    cout << (sws.size() + swt.size()) << '\n';
    for (int i = 0; i < sws.size(); i++) cout << sws[i].first << " " << sws[i].second << '\n';
    for (int i = swt.size() - 1; i >= 0; i--) cout << swt[i].first << " " << swt[i].second << '\n';
  }
  return 0;
}
