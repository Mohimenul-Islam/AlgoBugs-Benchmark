//Ciallo～(∠?ω< )⌒★
#include<bits/stdc++.h>
using namespace std;
using ll = long long;
ll n, q;

void solve()
{
    int n;
    string s, t;
    cin >> n >> s >> t;
    s = " " + s;
    t = " " + t;
    vector<pair<int, int>> v;
    ll cnt = 0, flag = 0;
    for(int i = 1;i < n;i++)
    {
        if(s[i] == '1')
        {
            cnt++;
        }
        else
        {
            if(cnt >= 2)
            {
                for(int j = i - cnt;j <= i - 1;j++)
                    s[i] = '0';
                v.push_back({i - cnt, i - 1});
                cnt = 0;
            }
            else if(cnt == 1)
            {
                if(s[i + 1] == '1')
                {
                    s[i + 1] = '0';
                    s[i] = '1';
                    cnt = 1;
                    v.push_back({i - 1, i + 1});
                }
                else
                {
                    cnt = 0;
                    s[i - 1] = '0';
                    v.push_back({i, i + 1});
                    v.push_back({i - 1, i + 1});
                }
            }
        }
    }
    if(cnt > 1)
    {
        if(s[n] == '1')
        {
            v.push_back({n - cnt, n});
            for(int i = n - cnt;i <= n;i++)
                s[i] = '0';
        }
        else
        {
            v.push_back({n - cnt, n - 1});
            for(int i = n - cnt;i <= n - 1;i++)
                s[i] = '0';
        }
    }
    else if(cnt == 1)
    {
        if(s[n] == '1')
        {
            s[n] = '0';
            s[n - 1] = '0';
            v.push_back({n - 1, n});
        }
        else
        {
            s[n - 1] = '0';
            v.push_back({1, n - 2});
            v.push_back({1, n - 1});
        }
    }
    // cout << v.size() << "\n";
    // for(int i = 0;i < v.size();i++)
    // {
    //     cout << v[i].first << " " << v[i].second << "\n";
    // }
    cnt = 0;
    vector<pair<int, int>> w;
    for(int i = 1;i < n;i++)
    {
        if(t[i] == '1')
        {
            cnt++;
        }
        else
        {
            if(cnt >= 2)
            {
                for(int j = i - cnt;j <= i - 1;j++)
                    t[i] = '0';
                w.push_back({i - cnt, i - 1});
                cnt = 0;
            }
            else if(cnt == 1)
            {
                if(t[i + 1] == '1')
                {
                    t[i + 1] = '0';
                    t[i] = '1';
                    cnt = 1;
                    w.push_back({i - 1, i + 1});
                }
                else
                {
                    cnt = 0;
                    t[i - 1] = '0';
                    w.push_back({i, i + 1});
                    w.push_back({i - 1, i + 1});
                }
            }
        }
    }
    if(cnt > 1)
    {
        if(t[n] == '1')
        {
            w.push_back({n - cnt, n});
            for(int i = n - cnt;i <= n;i++)
                t[i] = '0';
        }
        else
        {
            w.push_back({n - cnt, n - 1});
            for(int i = n - cnt;i <= n - 1;i++)
                t[i] = '0';
        }
    }
    else if(cnt == 1)
    {
        if(t[n] == '1')
        {
            t[n] = '0';
            t[n - 1] = '0';
            w.push_back({n - 1, n});
        }
        else
        {
            t[n - 1] = '0';
            w.push_back({1, n - 2});
            w.push_back({1, n - 1});
        }
    }
    cout << v.size() + w.size() << "\n";
    for(int i = 0;i < v.size();i++)
    {
        cout << v[i].first << " " << v[i].second << "\n";
    }
    for(int i = w.size() - 1;i >= 0;i--)
    {
        cout << w[i].first << " " << w[i].second << "\n";
    }
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int t;
	cin >> t;
	while(t--)
		solve();
}