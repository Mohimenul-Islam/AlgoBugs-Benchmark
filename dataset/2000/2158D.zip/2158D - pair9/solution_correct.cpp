//Ciallo～(∠?ω< )⌒★
#include<bits/stdc++.h>
using namespace std;
using ll = long long;
ll n, q;

void solve()
{
    int n;
    string s, t;
    cin >> n >> s >> t;
    s = " " + s;
    t = " " + t;
    vector<pair<int, int>> v, w;
    int l = 0, r = 0;
    for(int i = 1;i < n;i++)
    {
        if(s[i] == s[i + 1])
        {
            l = i, r = i + 1;
            break;
        }
    }
    if(l == r)
    {
        v.push_back({1, 3});
        for(int i = 1;i <= 3;i++)
        {
            if(s[i] == '1')
                s[i] = '0';
            else
                s[i] = '1';
        }
        for(int i = 1;i < n;i++)
        {
            if(s[i] == s[i + 1])
            {
                l = i, r = i + 1;
                break;
            }
        }
    }
    char cnt = s[l];
    while(l > 1 || r < n)
    {
        while(s[l - 1] == cnt)
        {
            l--;
        }
        while(s[r + 1] == cnt)
        {
            r++;
        }
        if(l > 1 || r < n)
        {
            v.push_back({l, r});
            if(cnt == '1')
                cnt = '0';
            else
                cnt = '1';
        }
    }
    if(cnt == '1')
        v.push_back({1, n});
    l = 0, r = 0;
    for(int i = 1;i < n;i++)
    {
        if(t[i] == t[i + 1])
        {
            l = i, r = i + 1;
            break;
        }
    }
    if(l == r)
    {
        w.push_back({1, 3});
        for(int i = 1;i <= 3;i++)
        {
            if(t[i] == '1')
                t[i] = '0';
            else
                t[i] = '1';
        }
        for(int i = 1;i < n;i++)
        {
            if(t[i] == t[i + 1])
            {
                l = i, r = i + 1;
                break;
            }
        }
    }
    cnt = t[l];
    while(l > 1 || r < n)
    {
        while(t[l - 1] == cnt)
        {
            l--;
        }
        while(t[r + 1] == cnt)
        {
            r++;
        }
        if(l > 1 || r < n)
        {
            w.push_back({l, r});
            if(cnt == '1')
                cnt = '0';
            else
                cnt = '1';
        }
    }
    if(cnt == '1')
        w.push_back({1, n});
    cout << v.size() + w.size() << "\n";
    for(int i = 0;i < v.size();i++)
        cout << v[i].first << " " << v[i].second << "\n";
    for(int i = w.size() - 1;i >= 0;i--)
        cout << w[i].first << " " << w[i].second << "\n";
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int t;
	cin >> t;
	while(t--)
		solve();
}