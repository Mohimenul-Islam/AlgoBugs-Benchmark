#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int n;
int a[102][2];
vector<array<int, 2>> res[2];

void qr(int z, int l, int r){
	res[z].push_back({l, r});
	for(int i=l; i<=r; i++){
		a[i][z] ^= 1;
	}
	// printf("<%d %d %d>\n", z, l, r);
}

void f1(int z){
	if(a[1][z] == 0 && a[2][z] == 1 && a[3][z] == 0 && a[4][z] == 1){
		qr(z, 1, 3);
		int rp = 4;
		for(int i=4; i<=n; i++){
			if(a[i][z] == 0) break;
			rp = i;
		}
		qr(z, 3, rp);
		for(int i=rp+1; i<=n; i++){
			if(a[i][z] == 1) break;
			rp = i;
		}
		qr(z, 2, rp);
		for(int i=rp+1; i<=n; i++){
			if(a[i][z] == 0) break;
			rp = i;
		}
		qr(z, 1, rp);
	}
	else if(a[1][z] == 1 && a[2][z] == 0 && a[3][z] == 1 && a[4][z] == 0){
		qr(z, 1, 3);
		int rp = 4;
		for(int i=4; i<=n; i++){
			if(a[i][z] == 1) break;
			rp = i;
		}
		qr(z, 3, rp);
		for(int i=rp+1; i<=n; i++){
			if(a[i][z] == 0) break;
			rp = i;
		}
		qr(z, 2, rp);
	}
	else if(a[1][z] == 0 && a[2][z] == 1 && a[3][z] == 0){
		int rp = 4;
		for(int i=4; i<=n; i++){
			if(a[i][z] == 1) break;
			rp = i;
		}
		qr(z, 3, rp);
		for(int i=rp+1; i<=n; i++){
			if(a[i][z] == 0) break;
			rp = i;
		}
		qr(z, 2, rp);
	}
	else if(a[1][z] == 1 && a[2][z] == 0 && a[3][z] == 1){
		int rp = 4;
		for(int i=4; i<=n; i++){
			if(a[i][z] == 0) break;
			rp = i;
		}
		qr(z, 3, rp);
		for(int i=rp+1; i<=n; i++){
			if(a[i][z] == 1) break;
			rp = i;
		}
		qr(z, 2, rp);
		for(int i=rp+1; i<=n; i++){
			if(a[i][z] == 0) break;
			rp = i;
		}
		qr(z, 1, rp);
	}
	else if(a[2][z] == 1){
		int lp = 2;
		if(a[1][z] == 1) lp = 1;
		int rp = 2;
		for(int i=3; i<=n; i++){
			if(a[i][z] == 0) break;
			rp = i;
		}
		qr(z, lp, rp);
	}
	if(a[1][z] == 1){
		int rp = 2;
		for(int i=rp; i<=n; i++){
			if(a[i][z] == 1) break;
			rp = i;
		}
		qr(z, 2, rp);
		for(int i=rp+1; i<=n; i++){
			if(a[i][z] == 0) break;
			rp = i;
		}
		qr(z, 1, rp);
	}
	for(int i=2; i<=n; i++){
		if(a[i][z] == 1){
			int rp = i;
			for(int j=i; j<=n; j++){
				if(a[j][z] == 0) break;
				rp = j;
			}
			qr(z, 1, i-1);
			qr(z, 1, rp);
			i = rp;
		}
	}
}

void solve(){
	res[0].clear();
	res[1].clear();
	scanf("%d", &n);
	for(int i=1; i<=n; i++){
		scanf("%1d", &a[i][0]);
	}
	for(int j=1; j<=n; j++){
		scanf("%1d", &a[j][1]);
	}
	f1(0);
	f1(1);
	reverse(res[1].begin(), res[1].end());
	printf("%d\n", res[0].size()+res[1].size());
	for(auto [l, r] : res[0]){
		printf("%d %d\n", l, r);
	}
	for(auto [l, r] : res[1]){
		printf("%d %d\n", l, r);
	}
}

int main(){
	int t = 1;
	scanf("%d", &t);
	while(t--) solve();
}