#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <queue>
#include <map>

using namespace std;

// 检查是否为回文
bool is_palin(const string& s, int l, int r) {
    while (l < r) {
        if (s[l++] != s[r--]) return false;
    }
    return true;
}

// 执行翻转
string do_flip(string s, int l, int r) {
    for (int i = l; i <= r; i++) {
        s[i] = (s[i] == '0' ? '1' : '0');
    }
    return s;
}

void solve() {
    int n;
    cin >> n;
    string s, t;
    cin >> s >> t;

    vector<pair<int, int>> ans;
    
    // 窗口大小设为 8，足以应对 01 串的所有回文变换
    const int W = 8;

    for (int i = 0; i < n; i++) {
        if (s[i] == t[i]) continue;

        // 如果到了最后几位，直接跑全量 BFS
        if (i >= n - W) {
            queue<pair<string, vector<pair<int, int>>>> q;
            q.push({s, {}});
            map<string, bool> visited;
            visited[s] = true;

            while (!q.empty()) {
                auto [curr, path] = q.front();
                q.pop();

                if (curr == t) {
                    for (auto p : path) ans.push_back(p);
                    s = curr;
                    goto end_solve;
                }

                if (path.size() >= 10) continue; // 步数限制，防止搜太深

                for (int l = i; l < n; l++) {
                    for (int r = l + 1; r < n; r++) {
                        if (is_palin(curr, l, r)) {
                            string nxt = do_flip(curr, l, r);
                            if (!visited[nxt]) {
                                visited[nxt] = true;
                                auto nxt_path = path;
                                nxt_path.push_back({l + 1, r + 1});
                                q.push({nxt, nxt_path});
                            }
                        }
                    }
                }
            }
            cout << -1 << endl;
            return;
        }

        // 正常位：寻找一个操作序列，只为了把 s[i] 变对
        queue<pair<string, vector<pair<int, int>>>> q;
        q.push({s, {}});
        map<string, bool> visited;
        visited[s] = true;
        
        bool found = false;
        while (!q.empty()) {
            auto [curr, path] = q.front();
            q.pop();

            if (curr[i] == t[i]) {
                ans.insert(ans.end(), path.begin(), path.end());
                s = curr;
                found = true;
                break;
            }
            
            if (path.size() >= 2) continue; // 局部修正通常只需 1-2 步

            // 限制搜索范围在 [i, i + W] 之间，保证不破坏左边
            for (int l = i; l < min(i + W, n); l++) {
                for (int r = l + 1; r < min(i + W, n); r++) {
                    if (is_palin(curr, l, r)) {
                        string nxt = do_flip(curr, l, r);
                        if (!visited[nxt]) {
                            visited[nxt] = true;
                            auto nxt_path = path;
                            nxt_path.push_back({l + 1, r + 1});
                            q.push({nxt, nxt_path});
                        }
                    }
                }
            }
        }
        if (!found) { cout << -1 << endl; return; }
    }

end_solve:
    if (s != t || ans.size() > 2 * n) {
        cout << -1 << endl;
    } else {
        cout << ans.size() << endl;
        for (auto p : ans) cout << p.first << " " << p.second << endl;
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int T; cin >> T;
    while (T--) solve();
    return 0;
}