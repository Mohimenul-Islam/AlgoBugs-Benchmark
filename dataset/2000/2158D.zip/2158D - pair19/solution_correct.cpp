#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

// 将任意字符串归一化为纯色（全0或全1）
// 返回最终的字符颜色，并将操作记录在 ops 中
char normalize(string& str, vector<pair<int, int>>& ops) {
    int n = str.length();
    int L = -1, R = -1;
    
    // 1. 寻找雪球核心 (相邻相等的字符)
    for (int i = 0; i < n - 1; ++i) {
        if (str[i] == str[i+1]) {
            L = i;
            R = i + 1;
            break;
        }
    }
    
    // 2. 如果是 0101 这种交替串，强行翻转前三个字符制造核心
    if (L == -1) {
        ops.push_back({1, 3}); // 1-based index
        for(int i = 0; i <= 2; ++i) {
            str[i] = (str[i] == '0' ? '1' : '0');
        }
        L = 2; // 翻转 010 -> 101 后，str[2] 和 str[3] 必然相等
        R = 3;
    }
    
    // 3. 开始滚雪球，向两端吞噬直到覆盖整个字符串
    while (L > 0 || R < n - 1) {
        if (L > 0 && str[L-1] == str[L]) {
            L--; // 已经一样了，直接纳入区域
        } 
        else if (R < n - 1 && str[R+1] == str[R]) {
            R++; // 已经一样了，直接纳入区域
        } 
        else if (L > 0 && str[L-1] != str[L]) {
            ops.push_back({L + 1, R + 1});
            // 翻转当前纯色区域
            for(int i = L; i <= R; ++i) str[i] = (str[i] == '0' ? '1' : '0');
            L--; // 翻转后与左边一致，左边界扩展
        } 
        else if (R < n - 1 && str[R+1] != str[R]) {
            ops.push_back({L + 1, R + 1});
            // 翻转当前纯色区域
            for(int i = L; i <= R; ++i) str[i] = (str[i] == '0' ? '1' : '0');
            R++; // 翻转后与右边一致，右边界扩展
        }
    }
    return str[0]; // 返回最终整串变成了啥颜色
}

void solve() {
    int n;
    cin >> n;
    string s, t;
    cin >> s >> t;

    if (s == t) {
        cout << 0 << "\n";
        return;
    }

    vector<pair<int, int>> ops_s, ops_t;
    
    // 将 s 和 t 都变成纯色串
    char char_s = normalize(s, ops_s);
    char char_t = normalize(t, ops_t);

    // 如果 s 最终是全 0，t 是全 1，把 s 再翻转一次
    if (char_s != char_t) {
        ops_s.push_back({1, n});
    }

    // 组合操作：s 的正向操作 + t 的逆向操作
    vector<pair<int, int>> final_ops = ops_s;
    for (int i = ops_t.size() - 1; i >= 0; --i) {
        final_ops.push_back(ops_t[i]);
    }

    // 输出结果
    cout << final_ops.size() << "\n";
    for (auto p : final_ops) {
        cout << p.first << " " << p.second << "\n";
    }
}

int main() {
    // 加速 I/O
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int T;
    cin >> T;
    while (T--) {
        solve();
    }
    return 0;
}