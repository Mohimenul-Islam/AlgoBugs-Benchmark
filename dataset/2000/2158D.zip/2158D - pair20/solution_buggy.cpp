#include <bits/stdc++.h>
using namespace std;
int t;
const int N = 110;
typedef pair<int, int> pii;

vector<pii> trans(string s) {
	vector<pii> ans;
	int len = 0;
	for (int i = 0; i < (int)s.size(); i++) {
		if (s[i] == '0') {
			if (len > 1) {
				ans.push_back({i - len, i - 1});
				for (int j = i - len; j < i; j++)
					s[j] = '0';
			}
			len = 0;
		} else
			len++;
	}
	if (len > 1) {
		ans.push_back({s.size() - len, s.size() - 1});
		for (int j = s.size() - len; j < s.size(); j++)
			s[j] = '0';
	}
	for (int i = 0; i < (int)s.size() - 2; i++)
		if (s[i] == '1' && s[i + 1] == '0' && s[i + 2] == '1')
			s[i] = '0', s[i + 1] = '1', s[i + 2] = '0', ans.push_back({i, i + 2});
	int l = 0, r = s.size() - 1;
	while (l < s.size() && s[l] == '0')
		l++;
	while (r >= 0 && s[r] == '0')
		r--;
	if (l > r)
		return ans;
	if (l == r) {
		if (l >= 2)
			ans.push_back({0, l - 1}), ans.push_back({0, l});
		else
			ans.push_back({l + 1, s.size() - 1}), ans.push_back({l, s.size() - 1});
		return ans;
	}
	len = 0;
	for (int i = l; i <= r; i++) {
		if (s[i] == '1') {
			if (len > 1)
				ans.push_back({i - len, i - 1});
		} else
			len++;
	}
	ans.push_back({l, r});
	return ans;
}

int main() {
	cin >> t;
	while (t--) {
		int n;
		cin >> n;
		string s, t;
		cin >> s >> t;
		auto a1 = trans(s), a2 = trans(t);
		reverse(a2.begin(), a2.end());
		cout << a1.size() + a2.size() << endl;
		for (auto [x, y] : a1)
			cout << x + 1 << " " << y + 1 << endl;
		for (auto [x, y] : a2)
			cout << x + 1 << " " << y + 1 << endl;
	}
	return 0;
}
