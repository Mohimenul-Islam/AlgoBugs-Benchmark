#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
#define ll long long
#define pii pair<int,int>
#define m_p make_pair
vector<pii> t[16];
void build(){
    t[1].push_back(m_p(1,2));
    t[1].push_back(m_p(1,3));
    t[2].push_back(m_p(0,1));
    t[2].push_back(m_p(0,2));
    t[3].push_back(m_p(2,3));
    t[4].push_back(m_p(2,3));
    t[4].push_back(m_p(1,3));
    t[5].push_back(m_p(1,3));
    t[5].push_back(m_p(0,1));
    t[5].push_back(m_p(0,2));
    t[6].push_back(m_p(1,2));
    t[7].push_back(m_p(1,3));
    t[8].push_back(m_p(1,3));
    t[8].push_back(m_p(0,3));
    t[9].push_back(m_p(1,2));
    t[9].push_back(m_p(0,3));
    t[10].push_back(m_p(0,2));
    t[10].push_back(m_p(2,3));
    t[10].push_back(m_p(1,3));
    t[11].push_back(m_p(2,3));
    t[11].push_back(m_p(1,3));
    t[11].push_back(m_p(0,3));
    t[12].push_back(m_p(0,1));
    t[13].push_back(m_p(0,1));
    t[13].push_back(m_p(0,2));
    t[13].push_back(m_p(0,3));
    t[14].push_back(m_p(0,2));
    t[15].push_back(m_p(0,3));
}
string s,m;
void trans0(int l,int r,vector<pii> &ans){
    int x=0;
    for(int i=l-1;i<=r-1;i++){
        x=2*x+(s[i]-'0');
        s[i]='0';
    }
    for(auto i:t[x]){
        ans.push_back(m_p(l+i.first,l+i.second));
    }
}
void trans1(int l,int r,vector<pii> &ans){
    int x=0;
    for(int i=l-1;i<=r-1;i++){
        x=2*x+(m[i]-'0');
    }
    for(int i=t[x].size()-1;i>=0;i--){
        ans.push_back(m_p(t[x][i].first+l,t[x][i].second+l));
    }
}
void solve(){
    int n;
    cin>>n>>s>>m;
    vector<pii> ans;
    string m1=m;
    
    if(s==m){
        cout<<0<<"\n";
        return;
    }else{
        for(int i=1;i+3<=n;i+=4){
            trans0(i,i+3,ans);
        }
        if(n%4){
            trans0(n-3,n,ans);
            for(int i=0;i<n-n%4;i++){
                m[i]='0';
            }
            trans1(n-3,n,ans);
            m=m1;

        }
        for(int i=1;i+3<=n;i+=4){
            trans1(i,i+3,ans);
        }

    }
    cout<<ans.size()<<"\n";
    for(auto i:ans){
        cout<<i.first<<' '<<i.second<<"\n";
    }
}
int main(){
    build();
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin>>T;
    while(T--)
    solve();
}