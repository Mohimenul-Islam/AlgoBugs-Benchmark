#include<bits/stdc++.h>
// #include <atcoder/all>
// #include<ext/pb_ds/assoc_container.hpp>
// #include<ext/pb_ds/tree_policy.hpp>
using namespace std;


// using namespace __gnu_pbds;
struct custom_hash {
  static uint64_t splitmix64(uint64_t x) {
      x += 0x9e3779b97f4a7c15;
      x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;
      x = (x ^ (x >> 27)) * 0x94d049bb133111eb;
      return x ^ (x >> 31);
  }

  size_t operator()(uint64_t x) const {
      static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();
      return splitmix64(x + FIXED_RANDOM);
  }
};


// typedef tree<int, null_type, less_equal<int>, rb_tree_tag, tree_order_statistics_node_update> pbds; // find_by_order, order_of_key
//find by order-> element at ith idx(starting from 0)//gives iterator to that index//if not present *it gives 0
//order of key-> number of element less than a number
// erase function for ordered multiset
// void myerase(pbds &t, int v){
//     int rank = t.order_of_key(v);//Number of elements that are less than v in t
//     pbds::iterator it = t.find_by_order(rank); //Iterator that points to the (rank+1)th element in t
//     t.erase(it);
// }



#define int long long int 
// #define ll long long int
#define loop(var, s, e) for(int var = s; var < e; var++)
#define rloop(var, e, s) for(int var = e; var>= s; var--)
#define v vector<int>
// #define vll vector<long long int>
#define printyes cout<<"YES\n"
#define printno cout<<"NO\n"
//COMMENT THIS FOR INTERACTIVE PROBLEMS...............
// #define endl '\n'
#define mod (int)(998244353)
#define inf (int)1e18
#define tinf LLONG_MAX
#define dbg(x) cerr<<"value of "<<#x<<" is => "<<x<<endl;
#define all(x) x.begin(), x.end()
#define vpii vector<pair<int, int>>
#define pii pair<int,int>
#define pll pair<ll, ll>
#define ff first
#define ss second
#define pb push_back
#define eb emplace_back
#define vpll vector<pll>
#define here(i) cerr<<"here "<<i<<" "<<endl;
#define sz(x) (int)x.size()
#define rt return;
#define mx max_element
#define mn min_element
#define asum accumulate
#define i128 __int128_t
#define countall(a, b) (count(all(a), b))
mt19937_64 RNG(chrono::steady_clock::now().time_since_epoch().count());

template <class A>
ostream& operator<<(ostream& out, const vector<A>& ve);

template <class A, class B>
ostream& operator<<(ostream& out, const pair<A, B>& a);

template <class A, size_t N>
ostream& operator<<(ostream& out, const array<A, N>& arr);

template <class A, class B>
ostream& operator<<(ostream& out, const pair<A, B>& a) {
    return out << "(" << a.first << ", " << a.second << ")";
}

template <class A>
ostream& operator<<(ostream& out, const vector<A>& ve) {
    out << "[";
    loop(i, 0, ve.size()) {
        if (i) out << ", ";
        out << ve[i];
    }
    return out << "]\n";
}

template <class A, size_t N>
ostream& operator<<(ostream& out, const array<A, N>& arr) {
    out << "[";
    loop(i, 0, N) {
        if (i) out << ", ";
        out << arr[i];
    }
    return out << "]\n";
}

template <class A>
ostream& operator<<(ostream& out, const set<A>& s) {
    out << "{";
    bool first = true;
    for (const auto& x : s) {
        if (!first) out << ", ";
        first = false;
        out << x;
    }
    return out << "}\n";
}

template <class A>
ostream& operator<<(ostream& out, const multiset<A>& s) {
    out << "{";
    bool first = true;
    for (const auto& x : s) {
        if (!first) out << ", ";
        first = false;
        out << x;
    }
    return out << "}\n";
}

template <class A, class B>
ostream& operator<<(ostream& out, const map<A, B>& m) {
    out << "{";
    bool first = true;
    for (const auto& it : m) {
        auto k = it.ff;
        auto val = it.ss;
        if (!first) out << ", ";
        first = false;
        out << k << ": " << val;
    }
    return out << "}\n";
}




namespace bit {
  int setBit(int n, int bitNo) {
    n = (n|(1LL<<bitNo));
    return n;
  }

  int currBit(int n, int bitNo) {
    return ((n&(1ll<<bitNo)) == 0)?0:1;
  }

  int unSetBit(int n, int bitNo) {
    n = (n&(~(1ll<<bitNo)));
    return n;
  }
  /*
  __lg() returns the highest set bit index in a number i.e for 100 it will be 2 and for 000 will be -1

  __builtin_ctz() give number of trailing zeros -> 1000-> 3

  n&(n - 1) clears the first set bit

  n&(-n) give the first set bit => 101100 -> 000100

  n&(n + 1) clear all trailing ones

  n|(n + 1) set the first unset bit
  */
}
//*************************************************CHECK THE CONSTRAINTS**********************************************************//
using namespace bit;
int extendedEuclidean(int a, int b, int&x, int& y) {
  if(b == 0) {
    x = 1;
    y = 0;
    return a;
  }
  int x1, y1;
  int d = extendedEuclidean(b, a%b, x1, y1);
  x = y1;
  y = x1 - y1*(a/b);
  return d;
}

int binPower(int a, int b, int m = mod) {
  if(b == 0) {
    return 1ll;
  }
  int res = binPower(a, b / 2, m);
  if(b % 2 == 0) {
    return (res * res) % m;
  } else {
    return (((res * res) % m) * a) % m;
  }
}


int binPowerNoMod(int a, int b) {
  if(b == 0) {
    return 1ll;
  }
  int res = binPowerNoMod(a, b / 2);
  if(b % 2 == 0) {
    return (res * res);
  } else {
    return (((res * res)) * a);
  }
}


int inv(int a, int b){
 return 1<a ? b - inv(b%a,a)*b/a : 1;
}


pair<v, v> linear_sieve(int n) {
  //https://cp-algorithms.com/algebra/prime-sieve-linear.html
  vector<int> lp(n + 1, 0);
  vector<int> primes;
  loop(i, 2, n + 1) {
    if(lp[i] == 0) {
      primes.pb(i);
      lp[i] = i;
    }
    for(int j = 0; i * primes[j] <= n; j++) {
      lp[primes[j] * i] = primes[j];
      if(primes[j] == lp[i])break;
    }
  }
  return pair<v, v>{lp, primes};
}

vector<bool> sieve(int n) {
  // gives a bool vec denoting primes numbers from [1...N]
  vector<bool> is_prime(n+1, 1);
  // v prime;
  // v dp(n + 1, 0);
  is_prime[0] = 0;
  is_prime[1] = 0;
  for(int i = 2; i <= n; i++) {
    if(is_prime[i] == 1) {
      // prime.pb(i);
      for(int j = i*i; j <= n; j+=i) {
        is_prime[j] = 0;
      }
    }
  }
  return is_prime;
}

int floor_div(int a, int b) {
  int res = a/b;
  if(a > 0 && b < 0 || a < 0 && b > 0)res--;
  return res;
}

int ceil_div(int a, int b) {
  if(a > 0 && b < 0 || a < 0 && b > 0) {
    return a/b;
  }
  if(a % b == 0)
    return a / b;
  else return (a / b) + 1;
}

int lcm(int a, int b) {
  int g = __gcd(a, b);
  int l = b / g;
  l = l * a;
  return l;
}

// void *memcpy(void *dest, const void *src, size_t n);
// make the hard time of your life as your strength
// first write complete pseudo code on paper then code dont care about the time!!!!!!
const int delRow[16] = {1, 0, 0, -1, 1, 1, -1, -1, 2, 2, 1, 1, -1, -1, -2, -2};
const int delCol[16] = {0, -1, 1, 0, -1, 1, -1, 1, -1, 1, -2, 2, -2, 2, -1, 1};

//find by order-> element at ith idx(starting from 0) //gives iterator to that index//if not present *it gives 0
//order of key-> number of element less than a number
//for add-hoc try example lots and lots of example and find some observation
//https://usaco.guide/bronze/ad-hoc?lang=cpp
/*
when ever you found some problem and you are not sure about that problem follow the following steps
1. create small test cases and brute force them and try to find observation.
2. repeat the above step. It's the best thing you can do!!!!
3. write mathematical equation for every small thing → it will lead to some imp observation
4. write all observation clearly / approaches then act on each of them one by one
5. minimization → always think of bs + lower bound / upper bound observation + dp
*/



void pikachu(int tt, int tc) {
  int n;
  cin >> n;
  string s, t;
  cin >> s >> t;
  bool alt = 1;
  loop(i, 0, n - 1) {
    if(t[i] == t[i + 1])
      alt = 0;
  }
  
  auto flip = [&](int i) {
    if(s[i] == '1')
      s[i] = '0';
    else s[i] = '1';
  };

  if(alt) {
    if(s == t) {
      cout << 0 << endl;
      rt;
    }
    int l = 0;
    int r = n - 1;
    while(l <= r) {
      if(s[l++] != s[r--]) {
        cout << -1 << endl;
        rt;
      }
    }
    loop(i, 0, n) {
      flip(i);
    }
    if(s != t) {
      cout << -1 << endl;
      rt;
    }
    cout << 1 << endl;
    cout << 1 << " " << n << endl;
    rt;
  }
  vpii ans;


  auto make_eq = [&]() {
    int idx = -1;
    loop(i, 0, n - 1) {
      if(s[i] == s[i + 1]) {
        idx = i;
        break;
      }
    }
    if(idx == -1) {
      flip(0);
      flip(1);
      flip(2);
      ans.pb({0, 2});
      loop(i, 0, n - 1) {
        if(s[i] == s[i + 1]) {
          idx = i;
          break;
        }
      }
    }
    loop(i, idx + 2, n) {
      if(s[i] != s[idx]) {
        loop(j, idx, i)
          flip(j);
        ans.pb({idx, i - 1});
      }
    }
    rloop(i, idx - 1, 0) {
      if(s[i] != s[idx]) {
        loop(j, i + 1, n)
          flip(j);
        ans.pb({i + 1, n - 1});
      }
    }
  };
  make_eq();
  // dbg(ans)
  // dbg(s)
  int idx = -1;
  loop(i, 0, n - 1) {
    if(t[i] == t[i + 1])
      idx = i;
  }
  // dbg(idx)
  loop(i, 0, idx) {
    if(s[i] != t[i]) {
      loop(j, i, n)
        flip(j);
      ans.pb({i, n - 1});
    }
  }

  rloop(i, n - 1, idx + 2) {
    if(s[i] != t[i]) {
      loop(j, idx, i + 1)
        flip(j);
      ans.pb({idx, i});
    }
  }
  // dbg(s)
  if(s[idx] != t[idx]) {
    flip(idx);
    flip(idx + 1);
    ans.pb({idx, idx + 1});
  }
  // dbg(s)
  cout << sz(ans) << endl;
  loop(i, 0, sz(ans))
    cout << ans[i].ff + 1 << " " << ans[i].ss + 1 << endl;
}   



void pikachu_first() {
}
void pikachu_second() {
}




int32_t main() {  
  auto begin = std::chrono::high_resolution_clock::now();
  ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
  #ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    freopen("error.txt", "w", stderr);
  #endif

  // string s;
  // cin >> s;
  // if(s == "first") {
  //   int t;
  //   cin >> t;
  //   while(t--)
  //     pikachu_first();
  // } else {
  //   int t;
  //   cin >> t;
  //   while(t--)
  //     pikachu_second();
  // }
  // return 0;


  int gsBall = 1;
  cin >> gsBall;
  int tt = gsBall;
  int tc = 1; 
  cout<<setprecision(20);
  while(gsBall--) {
    pikachu(tt, tc);
    // dbg(tc)
    tc++;
  }
  auto end = std::chrono::high_resolution_clock::now();
  auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin);
  cerr << "Time measured: " << elapsed.count() * 1e-9 << " seconds.\n"; 
  return 0;
}


// https://docs.google.com/document/d/1N3RPxRAjtNIkUDWUJULw82OrY0diLWsxkB49CAXYuIo/edit?tab=t.0
// https://docs.google.com/spreadsheets/d/1wiIv4jz9z9FWqtsqBrkOqALuDoYHlkrPGsnDGVsqBW4/edit?gid=0#gid=0
// https://codeforces.com/contest/1017/problem/C
// https://leetcode.com/problems/checking-existence-of-edge-length-limited-paths/description/
// https://leetcode.com/problems/count-good-triplets-in-an-array/description/
// https://codeforces.com/contest/1204/problem/D1
// https://codeforces.com/contest/2132/problem/F
// https://docs.google.com/document/d/1VuLkJfkaBBFdcV-BPtT2JdTDrD2lC3POFj6NPTl_Pzo/edit?addon_store&tab=t.0

