// **************************************************************
// 
// Solution by : amod yadav
// 
// **************************************************************
#include <bits/stdc++.h>
using namespace std;
#define int long long
typedef __int128_t ell;
#define forint(j, n) for (int i = j; i <= (n); ++i)
#define all(x) (x).begin(), (x).end()
#define sz(x) (int)(x).size()
#define both(x) (x).first>>(x).second
#define set_bits __builtin_popcountll
#define sec second
#define fir first
#define newline "\n"
#define _ << " " <<
#define pb push_back

const int MOD = 998244353;
const int MOD1 = 1000000007;
const int INF = 1e18;
const vector<pair<int,int>> direction = {{-1,0},{1,0},{0,-1},{0,1}};

inline void _print(vector<long long>&a){for(auto t:a)cout<<t<<" ";cout<<newline;}
inline void _print(vector<pair<long long,long long>>&a){for(auto &[A,B]:a)cout<<A<<" "<<B<<"\n";}
mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());
long long getRandomNumber(long long l, long long r) {return uniform_int_distribution<long long>(l, r)(rng);}

inline int msb(unsigned long long x) {return x ? 63 - __builtin_clzll(x) : -1;}
inline int lsb(unsigned long long x) {return x ? __builtin_ctzll(x) : -1;}
inline int setbits(unsigned long long x) {return __builtin_popcountll(x);}

template <typename T>
void debug(const T& log = "hello") {
    cout << log << endl;
    exit(1);
}

long long modpow(long long a, long long b, long long m = MOD) {
    long long res = 1;
    a %= m;
    while (b > 0) {
        if (b & 1) res = res * a % m;
        a = a * a % m;
        b >>= 1;
    }
    return res;
}

long long modinv(long long a, long long m = MOD) {
    return modpow(a, m - 2, m);
}

long long gcdll(long long a, long long b) {
    return b ? gcdll(b, a % b) : a;
}

long long lcmll(long long a, long long b) {
    return a / gcdll(a, b) * b;
}

vector<long long> fact, invfact;
void init_fact(long long n) {
    fact.assign(n + 1, 1);
    invfact.assign(n + 1, 1);
    for (long long i = 1; i <= n; i++) fact[i] = fact[i - 1] * i % MOD;
    invfact[n] = modinv(fact[n]);
    for (long long i = n; i >= 1; i--) invfact[i - 1] = invfact[i] * i % MOD;
}

long long nCr(long long n, long long r) {
    if (r < 0 || r > n) return 0;
    return fact[n] * invfact[r] % MOD * invfact[n - r] % MOD;
}

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);cout.tie(NULL);

    auto flip = [&](char ch) -> char {
        return ch == '0' ? '1': '0';
    };


    int T = 1;
    cin >> T;
    while (T--) {
        int n;
        cin >> n;
        string a,b;
        cin>>a>>b;
        if(a==b) cout<<0<<'\n';
        else if(n==1) cout<<"-1\n";
        else if(n==2)
            if((a[0]==a[1])&&(b[0]==b[1])) cout<<"1\n1 2\n";
            else cout<<"-1\n";
        else if(n==3){
            bool f1 = a == "101" || a == "010";
            bool f2 = b == "101" || b == "010";
            if(f1 && f2) cout<<"1\n1 3\n";
            else if(f1 || f2) cout<<"-1\n";
            else{
                vector<pair<int,int>>c,d;
                if(a != "000" && a!= "111"){
                    if(a[0] == a[1]) c.emplace_back(1,2);
                    else c.emplace_back(2,3);
                    if(a[1] == '0')c.emplace_back(1,3);
                }
                if(b != "000" && b!= "111"){
                    if(b[0] == b[1]) d.emplace_back(1,2);
                    else d.emplace_back(2,3);
                    if(b[1] == '0') d.emplace_back(1,3);
                }
                reverse(all(d));
                cout<<c.size()+d.size()<<newline;
                for(auto [l,r]:c) cout<<l _ r<<newline;
                for(auto [l,r]:d) cout<<l _ r<<newline;
            }
        }
        else{
            auto handle = [](string&s, vector<pair<int,int>>&w) {
                int i = s.size()-1;
                // 0 1 2 3 
                while(i>3 && s[i] == '0') i--;

                while(i>3){
                    int j = i;
                    while(j>3 && s[j] == '1') j--;
                    w.emplace_back(0,i);
                    w.emplace_back(0,j);
                    while(j>3 && s[j] == '0') j--;
                    i = j;
                }
            };

            auto handleFour = [](string s, vector<pair<int,int>>&w) {
                // 0 1 2 3 // who Amit
                if(s == "0000"){

                }else if( s == "0001"){
                    w.emplace_back(0,2);
                    w.emplace_back(0,3);
                }else if( s == "0010"){
                    w.emplace_back(0,1);
                    w.emplace_back(0,2);
                }else if( s == "0011"){
                    w.emplace_back(2,3);
                }else if( s == "0100"){
                    w.emplace_back(2,3);
                    w.emplace_back(1,3);
                }else if( s == "0101"){
                    w.emplace_back(1,3); // 0010
                    w.emplace_back(0,1);
                    w.emplace_back(0,2);
                }else if( s == "0110"){
                    w.emplace_back(1,2); 
                }else if( s == "0111"){
                    w.emplace_back(1,3); 
                }else if( s == "1000"){
                    w.emplace_back(1,3); 
                    w.emplace_back(0,3); 
                }else if( s == "1001"){
                    w.emplace_back(1,2); 
                    w.emplace_back(0,3);
                }else if( s == "1010"){
                    w.emplace_back(0,2); //0100
                    w.emplace_back(2,3);
                    w.emplace_back(1,3);
                }else if( s == "1011"){
                    w.emplace_back(2,3);
                    w.emplace_back(1,3);
                    w.emplace_back(0,3);
                }else if( s == "1100"){
                    w.emplace_back(0,1);
                }else if( s == "1101"){
                    w.emplace_back(0,1);
                    w.emplace_back(0,2);
                    w.emplace_back(0,3);
                }else if( s == "1110"){
                    w.emplace_back(0,2);
                }else if( s == "1111"){
                    w.emplace_back(0,3);
                }
            };

            vector<pair<int,int>>w1,w2,w3,w4;
            handleFour(a.substr(0,4),w1);
            handle(a,w2);
            handleFour(b.substr(0,4),w3);
            handle(b,w4);
            reverse(all(w2));
            reverse(all(w3));
            cout<<w1.size()+w2.size()+w3.size()+w4.size()<<newline;
            for(auto [l,r]:w1) cout<<l+1 _ r+1<<newline;
            for(auto [l,r]:w2) cout<<l+1 _ r+1<<newline;
            for(auto [l,r]:w4) cout<<l+1 _ r+1<<newline;
            for(auto [l,r]:w3) cout<<l+1 _ r+1<<newline;
        }

    }
    return 0;
}
// 1234567
// 0101000
