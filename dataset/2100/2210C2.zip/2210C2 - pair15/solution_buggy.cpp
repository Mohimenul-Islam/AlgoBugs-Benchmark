#include <bits/stdc++.h>
using namespace std;
using ll=long long;
const int N=5e4+5;
const int K=55;
int n,a[N],b[N],dp[N][K],i,j,k;
vector<int>g[N];
ll gcd(ll x,ll y){
    if(x==0)return y;
    else return gcd(y%x,x);
}
ll lcm(ll x,ll y){
    return x*y/gcd(x,y);
}
void solve(){
    cin>>n;
    for(i=1;i<=n;i++)cin>>a[i];
    for(i=1;i<=n;i++)cin>>b[i];
    for(i=0;i<=n;i++)
        for(j=0;j<K;j++)
            dp[i][j]=-1e9;
    for(i=1;i<=n;i++)g[i].clear();
    for(i=1;i<=n;i++){
        g[i].push_back(a[i]);
    }
    for(i=1;i<=n;i++){
        if(i==1){
            int A=gcd(a[i],a[i+1]);
            for(k=1;1ll*k*A<=b[i]&&g[i].size()<K;k++){
                if(k*A==a[i])continue;
                g[i].push_back(k*A);
            }
        }else if(i==n){
            int A=gcd(a[i],a[i-1]);
            for(k=1;1ll*k*A<=b[i]&&g[i].size()<K;k++){
                if(k*A==a[i])continue;
                g[i].push_back(k*A);
            }
        }else{
            int A=gcd(a[i],a[i+1]);
            int B=gcd(a[i],a[i-1]);
            ll lc=lcm(A,B);
            if(lc>b[i])continue;
            for(k=1;1ll*k*lc<=b[i]&&g[i].size()<K;k++){
                if(k*lc==a[i])continue;
                g[i].push_back(k*lc);
            }
        }
    }
    dp[1][0]=0;
    for(i=1;i<g[1].size();i++){
        dp[1][i]=1;
    }
    for(i=2;i<=n;i++){
        int gg=gcd(a[i],a[i-1]);
        for(j=0;j<g[i-1].size();j++){
            if(gcd(a[i]/gg,g[i-1][j]/gg)!=1)
                    continue;
            dp[i][0]=max(dp[i][0],dp[i-1][j]);
        }
        for(j=1;j<g[i].size();j++){
            for(k=0;k<g[i-1].size();k++){
                if(gcd(g[i][j]/gg,g[i-1][k]/gg)
                    !=1)
                        continue;
                dp[i][j]=max(dp[i][j],dp[i-1][k]+1);
            }
        }
    }
    int ans=0;
    for(i=0;i<g[n].size();i++){
        ans=max(ans,dp[n][i]);
    }
    cout<<ans<<"\n";
}
int main ()
{
    ios::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);
    int _;
    cin>>_;
    while(_--)solve();
    return 0;
}
