#include <bits/stdc++.h>

using ll = long long;

std::map<int, int> factorize(int x) {
    std::map<int, int> res;
    for (int i = 2; i * i <= x; i++) {
        if (x % i != 0) { continue; }
        int cnt = 0;
        while (x % i == 0) 
            ++cnt, x /= i;
            
        res[i] = cnt;
    }
    if (x > 1) { ++res[x]; }
    return res;
}

void solve() {
	int n;
	std::cin >> n;
	std::vector<int> a(n), b(n);
	for (auto &i : a) std::cin >> i;
	for (auto &i : b) std::cin >> i;

	std::vector<std::map<int, int>> facts(n);
	for (int i = 0; i < n; i++) {
		facts[i] = factorize(a[i]);
	}

	std::vector<std::pair<ll, int>> dp;
	dp.push_back({0, 0});
	for (int i = 0; i < n; i++) {
		ll need;
		if (i == 0) {
			need = std::gcd(a[i], a[i + 1]);
		} else if (i == n - 1) {
			need = std::gcd(a[i], a[i - 1]);
		} else {
			need = std::lcm((ll) std::gcd(a[i], a[i - 1]), (ll) std::gcd(a[i], a[i + 1]));
		}

		int g = i == 0 ? a[i] : std::gcd(a[i], a[i - 1]);

		std::vector<std::pair<ll, int>> ndp;
		std::set<ll> seen;
		auto proc = [&](ll nv) -> void {
			if (seen.count(nv)) return;
			seen.insert(nv);

			if (nv == a[i] || nv <= b[i]) {
				int best = 0;
				for (auto [p, v] : dp) {
					if (i == 0 || std::gcd(p, nv) == g) {
						best = std::max(best, v + (nv != a[i]));
					}
				}

				ndp.push_back({nv, best});
			}
		};

		proc(a[i]);
		proc(need);

		for (auto [p, _] : facts[i]) {
			proc(p * need);
		}

		if (i) {
			for (auto [p, _] : facts[i - 1]) {
				proc(p * need);
			}
		}

		if (i + 1 < n) {
			for (auto [p, _] : facts[i + 1]) {
				proc(p * need);
			}
		}

		for (auto [p, _] : dp) {
			seen.insert(p);
		}

		int ptr = 2;
		while (1ll * ptr * need <= b[i]) {
			if (!seen.count(need * ptr)) {
				proc(need * ptr);
				break;
			}

			ptr++;
		}

		dp = std::move(ndp);
	}

	int res = 0;
	for (auto [p, v] : dp) {
		res = std::max(res, v);
	}

	std::cout << res << '\n';
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    
    int t;
    std::cin >> t;
    while (t--) {
        solve();
    }
}