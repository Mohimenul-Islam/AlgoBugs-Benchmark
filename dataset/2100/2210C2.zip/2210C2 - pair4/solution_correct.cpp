#include <bits/stdc++.h>

using ll = long long;

std::vector<int> primes{1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73};

void solve() {
	int n;
	std::cin >> n;
	std::vector<int> a(n), b(n);
	for (auto &i : a) std::cin >> i;
	for (auto &i : b) std::cin >> i;

	std::vector<std::pair<ll, int>> dp;
	dp.push_back({0, 0});
	for (int i = 0; i < n; i++) {
		ll need;
		if (i == 0) {
			need = std::gcd(a[i], a[i + 1]);
		} else if (i == n - 1) {
			need = std::gcd(a[i], a[i - 1]);
		} else {
			need = std::lcm((ll) std::gcd(a[i], a[i - 1]), (ll) std::gcd(a[i], a[i + 1]));
		}

		int g = i == 0 ? a[i] : std::gcd(a[i], a[i - 1]);

		std::vector<std::pair<ll, int>> ndp;
		std::set<ll> seen;
		auto proc = [&](ll nv) -> void {
			if (seen.count(nv)) return;
			seen.insert(nv);

			if (nv == a[i] || nv <= b[i]) {
				int best = 0;
				for (auto [p, v] : dp) {
					if (i == 0 || std::gcd(p, nv) == g) {
						best = std::max(best, v + (nv != a[i]));
					}
				}

				ndp.push_back({nv, best});
			}
		};

		proc(a[i]);
		for (int p : primes) {
			proc(1ll * need * p);
			proc(1ll * a[i] * p);
		}

		dp = std::move(ndp);
	}

	int res = 0;
	for (auto [p, v] : dp) {
		res = std::max(res, v);
	}

	std::cout << res << '\n';
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    
    int t;
    std::cin >> t;
    while (t--) {
        solve();
    }
}