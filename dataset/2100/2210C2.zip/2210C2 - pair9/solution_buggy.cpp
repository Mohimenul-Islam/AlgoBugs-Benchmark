#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;

#define deb(...) logger(#__VA_ARGS__, __VA_ARGS__)
template<typename ...Args>
void logger(string vars, Args&&... values) {
  cout << vars << " = ";
  string delim = "";
  (..., (cout << delim << values, delim = ", "));
  cout << '\n';
}

template <typename T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
#define ll long long
#define ull unsigned long long
#define ld long double
#define range(x) x.begin(), x.end()
#define rrange(x) x.rbegin(), x.rend()
#define vec(x) vector<x>
#define mkp(x, y) make_pair(x, y)
#define Yes cout << "Yes\n"
#define No cout << "No\n"
#define YES cout << "YES\n"
#define NO cout << "NO\n"
#define endl '\n'
#define print(x) for(auto &y:x)cout<<y<<' ';
ostream &omar = cout;
istream &Omar = cin;

int xr[] = {0, 0, 1, -1};
int yr[] = {1, -1, 0, 0};
int xxr[] = {0, 0, 1, -1, 1, 1, -1, -1};
int yyr[] = {1, -1, 0, 0, 1, -1, 1, -1};
char M[] = {'R', 'L', 'D', 'U'};
const int MOD = 1000000007;
//const int MOD = 998244353;
const ll inf = 1e9;

void solve() {
    int n;
    cin >> n;
    vector<ll> v(n);
    for (int i = 0; i < n; i++) {
        cin >> v[i];
    }
    vector<int> b(n);
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        b[i] = x;
    }
    int ans = 0;
    vector<ll> prms = {1,2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43};
    vector<ll> dp(15 , -inf);
    dp[0] = 0;


    vector<int> fixed(n);
    for (int i = 0; i < n; i++) {
         ll mc = 0;
        if(i == 0) {
            mc = gcd(v[i], v[i + 1]);
        } else if(i+1 >= n) {
            mc = gcd(v[i], v[i - 1]);
        } else {
            mc = lcm(gcd(v[i], v[i - 1]), gcd(v[i], v[i + 1]));
        }
        if(mc<v[i] and mc <= b[i]) {
            v[i] = mc;
            fixed[i] = 1;
        }
    }
    for (int i = 0; i < n; i++) {
        vector<ll> ndp(15);
        ll mc = 0;
        if(i == 0) {
            mc = gcd(v[i], v[i + 1]);
        } else if(i+1 >= n) {
            mc = gcd(v[i], v[i - 1]);
        } else {
            mc = lcm(gcd(v[i], v[i - 1]), gcd(v[i], v[i + 1]));
        }
        if(fixed[i]) {
            ll mx = *max_element(range(dp));
            ndp[0] = mx + (mc <= b[i]);
            dp = ndp;
            continue;
        }

        ll qud = (i + 1 < n) ? (v[i + 1]) : 1;
        ll gqud = gcd(v[i], qud);
        ll wra = i ? (v[i - 1]) : 1;
        ll gwra = gcd(v[i], wra);
        // cout << gcd(qud, v[i]) << ' ' << gcd(wra, v[i]) << endl;
        for (int j = 0; j < 15; j++) {
            ndp[0] = max(ndp[0], dp[j]);
            for (int jk = 0; jk < 15;jk++) {
                ll nwra = wra * prms[j];

                ll now = v[i] * prms[jk];
                if((i == 0 or gcd(now,nwra) == gwra) and (i == n-1 or gcd(now , qud) == gqud) and now != v[i] and now <= b[i]) {
                    ndp[jk] = max(ndp[jk], dp[j] + 1);
                } 
            }
        }

        dp = ndp;
        }
    cout << *max_element(range(dp)) << endl;
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    // #ifndef ONLINE_JUDGE
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
    // #endif

    ll t = 1;
    cin >> t;
    while (t--) {
        solve();
    }

    return 0;
}

/*
⢸⣿⣿⣿⣿⠃⠄⢀⣴⡾⠃⠄⠄⠄⠄⠄⠈⠺⠟⠛⠛⠛⠛⠻⢿⣿⣿⣿⣿⣶⣤⡀⠄
⢸⣿⣿⣿⡟⢀⣴⣿⡿⠁⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⣸⣿⣿⣿⣿⣿⣿⣿⣷
⢸⣿⣿⠟⣴⣿⡿⡟⡼⢹⣷⢲⡶⣖⣾⣶⢄⠄⠄⠄⠄⠄⢀⣼⣿⢿⣿⣿⣿⣿⣿⣿⣿
⢸⣿⢫⣾⣿⡟⣾⡸⢠⡿⢳⡿⠍⣼⣿⢏⣿⣷⢄⡀⠄⢠⣾⢻⣿⣸⣿⣿⣿⣿⣿⣿⣿
⡿⣡⣿⣿⡟⡼⡁⠁⣰⠂⡾⠉⢨⣿⠃⣿⡿⠍⣾⣟⢤⣿⢇⣿⢇⣿⣿⢿⣿⣿⣿⣿⣿
⣱⣿⣿⡟⡐⣰⣧⡷⣿⣴⣧⣤⣼⣯⢸⡿⠁⣰⠟⢀⣼⠏⣲⠏⢸⣿⡟⣿⣿⣿⣿⣿⣿
⣿⣿⡟⠁⠄⠟⣁⠄⢡⣿⣿⣿⣿⣿⣿⣦⣼⢟⢀⡼⠃⡹⠃⡀⢸⡿⢸⣿⣿⣿⣿⣿⡟
⣿⣿⠃⠄⢀⣾⠋⠓⢰⣿⣿⣿⣿⣿⣿⠿⣿⣿⣾⣅⢔⣕⡇⡇⡼⢁⣿⣿⣿⣿⣿⣿⢣
⣿⡟⠄⠄⣾⣇⠷⣢⣿⣿⣿⣿⣿⣿⣿⣭⣀⡈⠙⢿⣿⣿⡇⡧⢁⣾⣿⣿⣿⣿⣿⢏⣾
⣿⡇⠄⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⢻⠇⠄⠄⢿⣿⡇⢡⣾⣿⣿⣿⣿⣿⣏⣼⣿
⣿⣷⢰⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⢰⣧⣀⡄⢀⠘⡿⣰⣿⣿⣿⣿⣿⣿⠟⣼⣿⣿
⢹⣿⢸⣿⣿⠟⠻⢿⣿⣿⣿⣿⣿⣿⣿⣶⣭⣉⣤⣿⢈⣼⣿⣿⣿⣿⣿⣿⠏⣾⣹⣿⣿
⢸⠇⡜⣿⡟⠄⠄⠄⠈⠙⣿⣿⣿⣿⣿⣿⣿⣿⠟⣱⣻⣿⣿⣿⣿⣿⠟⠁⢳⠃⣿⣿⣿
⠄⣰⡗⠹⣿⣄⠄⠄⠄⢀⣿⣿⣿⣿⣿⣿⠟⣅⣥⣿⣿⣿⣿⠿⠋⠄⠄⣾⡌⢠⣿⡿⠃
⠜⠋⢠⣷⢻⣿⣿⣶⣾⣿⣿⣿⣿⠿⣛⣥⣾⣿⠿⠟⠛⠉⠄⠄
*/