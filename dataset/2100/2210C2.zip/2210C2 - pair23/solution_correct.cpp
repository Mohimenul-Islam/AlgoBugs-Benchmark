#include <bits/stdc++.h>

#ifdef DEBUG
#include <debug.h>
#else
#define dbg(x...)
#endif

using namespace std;
inline int nxt() {
	int x;
	cin >> x;
	return x;
}
inline long long nxtl() {
	long long x;
	cin >> x;
	return x;
}
inline string nxts() {
        string s;
        cin >> s;
        return s;
}
using ll = long long;
using u8 = uint8_t;
using u16 = uint16_t;
using u32 = uint32_t;
using u64 = uint64_t;
using uint = unsigned int;
using ull = unsigned long long;
using pii = std::pair<int, int>;
using pll = std::pair<ll, ll>;
typedef std::vector<int> vi;
typedef std::vector<ll> vl;
typedef std::vector<pii> vpii;
typedef std::vector<pll> vpll;
typedef std::vector<bool> vb;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
#define uid(a, b) uniform_int_distribution<int> (a, b)(rng)
#define fi first
#define se second
#define lb lower_bound
#define ub upper_bound
#define pb push_back
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define sz(x) (int) (x).size()
#define FOR(i, a, b) for (int i = a; i < (b); i++)
#define F0R(i, a) for (int i = 0; i < (a); i++)
#define FORd(i, a, b) for (int i = (a) - 1; i >= b; i--)
#define F0Rd(i, a) for (int i = (a) - 1; i >= 0; i--)
#define repeat(_x) F0R(_, _x)
#define trav(a, x) for (auto& a : x)
#define nl cout << "\n"
#define ins insert
#define yes cout << "Yes\n"
#define no cout << "No\n"
#define cinv(x) trav(_el, x) cin >> _el
#define coutv(x) trav(_el, x) cout << _el << ' '

template <typename C>
C reversed(const C& c) {
    return C(c.rbegin(), c.rend());
}

template<typename T>
T sqr(T x) {
        return x * x;
}

template <class T>
inline bool chmin(T& a, const T& b) {
        return b < a ? a = b, 1 : 0;
}

template <class T>
inline bool chmax(T& a, const T& b) {
        return a < b ? a = b, 1 : 0;
}

int popcnt(int x) { return __builtin_popcount(x); }
int popcnt(u32 x) { return __builtin_popcount(x); }
int popcnt(ll x) { return __builtin_popcountll(x); }
int popcnt(u64 x) { return __builtin_popcountll(x); }
int popcnt_sgn(int x) { return (__builtin_parity(unsigned(x)) & 1 ? -1 : 1); }
int popcnt_sgn(u32 x) { return (__builtin_parity(x) & 1 ? -1 : 1); }
int popcnt_sgn(ll x) { return (__builtin_parityll(x) & 1 ? -1 : 1); }
int popcnt_sgn(u64 x) { return (__builtin_parityll(x) & 1 ? -1 : 1); }
// (0, 1, 2, 3, 4) -> (-1, 0, 1, 1, 2)
int topbit(int x) { return (x == 0 ? -1 : 31 - __builtin_clz(x)); }
int topbit(u32 x) { return (x == 0 ? -1 : 31 - __builtin_clz(x)); }
int topbit(ll x) { return (x == 0 ? -1 : 63 - __builtin_clzll(x)); }
int topbit(u64 x) { return (x == 0 ? -1 : 63 - __builtin_clzll(x)); }
// (0, 1, 2, 3, 4) -> (-1, 0, 1, 0, 2)
int lowbit(int x) { return (x == 0 ? -1 : __builtin_ctz(x)); }
int lowbit(u32 x) { return (x == 0 ? -1 : __builtin_ctz(x)); }
int lowbit(ll x) { return (x == 0 ? -1 : __builtin_ctzll(x)); }
int lowbit(u64 x) { return (x == 0 ? -1 : __builtin_ctzll(x)); }
 
template <typename T>
T kth_bit(int k) {
  return T(1) << k;
}
template <typename T>
bool has_kth_bit(T x, int k) {
  return x >> k & 1;
}
const int N = 5e4 + 10, M = 30, inf = 1e9;
int dp[M][N], n;
/* dp[0][i] = i'th element is same*/
/* dp[j][i] = ith element is pr[j] * ag[i] */
ll a[N], b[N], ag[N];
vi pr = {0, 1};
void solve() {
        cin >> n;
        for (int i = 0; i < n; i++) cin >> a[i];
        for (int i = 0; i < n; i++) cin >> b[i];
        a[n] = 1;
        ag[0] = gcd(a[0], a[1]);
        for (int j = 1; j < M; j++) {
                ll na = pr[j] * ag[0];
                if (na <= b[0]) {
                        if (na != a[0]) dp[j][0] = 1;
                        else dp[j][0] = 0;
                } else {
                        dp[j][0] = -inf;
                }
        }

        for (int i = 1; i < n; i++) {
                ll g1 = gcd(a[i], a[i-1]), g2 = gcd(a[i], a[i+1]);
                ag[i] = g1 / gcd(g1, g2) * g2;
                dp[0][i] = dp[0][i-1];
                for (int j = 1; j < M; j++) {
                        ll his = pr[j] * ag[i-1];
                        if (gcd(a[i], his) != gcd(a[i], a[i-1])) continue;
                        chmax(dp[0][i], dp[j][i-1]);
                }
                // dbg(i+1, ag[i], dp[0][i]);
                for (int j = 1; j < M; j++) {
                        ll me = ag[i] * pr[j];
                        int best = -inf;
                        for (int k = 0; k < M; k++) {
                                ll his = pr[k] * ag[i-1];
                                if (k == 0) his = a[i-1];
                                if (gcd(me, his) != g1) continue;
                                if (me == a[i]) {
                                        chmax(best, dp[k][i-1]);
                                } else if (me <= b[i]) {
                                        chmax(best, dp[k][i-1] + 1);
                                }
                        }
                        dp[j][i] = best;
                        // dbg(i+1, j, me, dp[j][i]);
                }
        }
        int best = 0;
        for (int j = 0; j < M; j++) chmax(best, dp[j][n-1]);
        cout << best << "\n";
}

int main() {
        ios::sync_with_stdio(false), cin.tie(nullptr);
        int _t = 1;
        vector<char> prime(N, true);
        for (int j = 2; j < N; j++) {
                if (prime[j]) {
                        pr.pb(j);
                        for (int i = j * 2; i < N; i += j) prime[i] = 0;
                }
        }
        // dbg(pr);
        cin >> _t;
        for (int i = 1; i <= _t; i++) {
                solve();
        }
        return 0;
}
