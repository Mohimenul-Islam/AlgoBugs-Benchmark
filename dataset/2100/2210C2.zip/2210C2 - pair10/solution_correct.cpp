#include <bits/stdc++.h>
#define ll long long 
using namespace std;
const int maxn=5e4+9;
const int INF=1e9+9;
ll a[maxn],b[maxn];
ll lcm(ll a, ll b) {
    if (a == 0 || b == 0) return 0;
    return (a / __gcd(a, b)) * b;
}
ll g[maxn];
ll dp[maxn][25];
int n;
int prime[]={1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73};
void solve()
{
        cin>>n;
        for(int i=1;i<=n;++i)cin>>a[i];
        for(int i=1;i<=n;++i)cin>>b[i];
        vector<int>c[n+1];
        if(n<2)
        {
            cout<<0<<'\n';
            return ;
        }
        for(int i=1;i<n;++i)
        {
            g[i]=__gcd(a[i],a[i+1]);
        }
        for(int i=1;i<=n;++i)
        {
            ll L;
            if(i==1)L=g[1];
            if(i==n)L=g[n-1];
            if(i>1&&i<n)L=lcm(g[i],g[i-1]);
            if(L>b[i])L=a[i];
            c[i].push_back(a[i]);
            for(int k=0;k<=21;k++)
            {
                ll val=prime[k]*L;
                if(val>b[i])break;
                if(val==a[i])continue;
                else 
                {
                    c[i].push_back(val);
                }
            }
        }
        for(int i=0;i<=n;++i)
            for(int j=0;j<c[i].size();++j)dp[i][j]=-INF;
        for(int j=0;j<c[1].size();++j)dp[1][j]=(c[1][j]==a[1]?0:1);
        for(int i=2;i<=n;++i)
        {
            for(int j=0;j<c[i].size();++j)
            {
                for (int k=0;k<c[i-1].size();++k) 
                {
                    int cost=c[i][j]==a[i]?0:1;
                    if (__gcd(c[i-1][k],c[i][j])==g[i-1]) {
                        dp[i][j]=max(dp[i][j],dp[i-1][k]+cost);
                    }
                }
            }
        }
        ll ans=0;
        for(int j=0;j<c[n].size();++j)
        {
            ans=max(ans,dp[n][j]);
        }
        cout<<ans<<'\n';
        return;
}
int main()
{
    ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
    int t;cin>>t;
    while(t--)
    {
        solve();
    }
    return 0;

}