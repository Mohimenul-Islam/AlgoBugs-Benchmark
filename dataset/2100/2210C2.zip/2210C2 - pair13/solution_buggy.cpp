// Problem: C2. A Simple GCD Problem (Hard Version)
// Contest: Codeforces Round 1089 (Div. 2)
// Judge: Codeforces
// URL: https://codeforces.com/contest/2210/problem/C2
// Memory Limit: 512
// Time Limit: 6000
// Start: Mon 27 Apr 2026 01:58:18 PM -03

#include <bits/stdc++.h>
using namespace std;

#define int long long
#define pb push_back
#define all(x) (x).begin(), (x).end()
#define size(x) (int)(x).size()
#define fastio ios::sync_with_stdio(false); cin.tie(nullptr)

vector<int> primes;
constexpr int MAX = 1e5+1;
int sieve[MAX];
void init() {
    sieve[0] = sieve[1] = 1;
    for (int i = 2; i < MAX; i++) {
        if(sieve[i]) continue;
        for (int j = i * i; j < MAX; j+=i) {
            sieve[j] = 1;
        }
        primes.pb(i);
    }
}

signed main() {
    fastio;
    init();
    int tt;
    cin >> tt;
    while (tt--) {
        int n;
        cin >> n;
        vector<int> a(n), b(n);
        for (int i = 0; i < n; i++) {
            cin >> a[i];
        }
        vector<int> oa = a;
        for (int i = 0; i < n; i++) {
            cin >> b[i];
        }
        int ans = 0;
        a[0] = gcd(a[0], a[1]);
        a[n-1] = gcd(a[n-1], a[n-2]);
        for (int i = 1; i < n-1; i++) {
            a[i] = lcm(gcd(a[i], a[i-1]), gcd(a[i], a[i+1]));
            if (a[i] > b[i]) a[i] = oa[i];
        }
        for (int i = 0; i < n; i++) {
            if (a[i] < oa[i] && a[i] <= b[i]) {
                ans++;
            } else if (a[i] == oa[i] && b[i] > a[i]) {
                set<int> w, k;
                if (i) w.insert(gcd(a[i], a[i-1]));
                if (i < n-1) k.insert(gcd(a[i], a[i+1]));
                vector<int> can;
                for (auto p : primes) {
                    if (p * a[i] > b[i]) break;
                    if (i && size(w) && !w.count(gcd(a[i-1], p*a[i])))
                        continue;
                    if (i < n-1 && size(k) && !k.count(gcd(a[i]*p, a[i+1])))
                        continue;
                    can.pb(p);
                    if (size(can) > 1) break;
                }
                if (size(can) == 1) a[i] *= can[0], ans++;
                if (size(can) == 2) ans++;
            }
        }
        cout << ans << '\n';
    }
}
