# C2. A Simple GCD Problem (Hard Version)

**Time limit:** 6 seconds
**Memory limit:** 512 megabytes

## Problem Statement

This is the hard version of the problem. The difference between the versions is that in this version, $$$1 \\leq n \\leq 5 \\cdot 10^{4}$$$, $$$1 \\leq b\_i \\leq 10^{9}$$$ for $$$1 \\leq i \\leq n$$$, and the time limit is $$$6$$$ seconds. Note that a solution for one version does not necessarily solve the other version. You can hack only if you solved all versions of this problem.

You are given two arrays $$$a$$$ and $$$b$$$ of length $$$n$$$.

For each index $$$i$$$ ($$$1 \\le i \\le n$$$) of array $$$a$$$, you can perform the following operation at most once:

*   choose an arbitrary integer $$$m$$$ ($$$\\mathbf{m \\neq a\_i}$$$) such that $$$1 \\leq m \\leq b\_i$$$, and set $$$a\_i := m$$$.

Let the array after performing all the operations be $$$a'$$$. You can only perform operations in such a way that the following condition holds:

*   For all $$$1\\leq l \\lt r\\leq n$$$, $$$\\operatorname{gcd}(a\_l,a\_{l+1},\\ldots,{a\_r})=\\operatorname{gcd}(a'\_l,a'\_{l+1},\\ldots,a'\_r)$$$

Here, $$$\\gcd(x, y)$$$ denotes the [greatest common divisor (GCD)](https://en.wikipedia.org/wiki/Greatest_common_divisor) of integers $$$x$$$ and $$$y$$$.

You have to determine the maximum number of operations that can be performed while ensuring that the condition remains satisfied.

## Input

Each test contains multiple test cases. The first line contains the number of test cases $$$t$$$ ($$$1 \\le t \\le 10^4$$$). The description of the test cases follows.

The first line of each test case contains an integer $$$n$$$ ($$$2 \\leq n \\leq 5\\cdot 10^4$$$) — the length of $$$a$$$.

The following line of each test case contains $$$n$$$ space-separated integers $$$a\_1, a\_2, \\ldots, a\_n$$$ ($$$1 \\leq a\_i \\leq 10^9$$$).

The next line of each test case contains $$$n$$$ space-separated integers $$$b\_1, b\_2, \\ldots, b\_n$$$ ($$$1 \\le b\_i \\le 10^9$$$).

It is guaranteed that the sum of $$$n$$$ over all test cases does not exceed $$$5\\cdot 10^4$$$.

## Output

For each test case, output the maximum number of operations which can be done.

## Sample Tests

### Input
```
9
7
1 2 3 4 5 6 7
100 6 12 20 5 2 7
3
67 67 67
1000000000 1000000000 1000000000
6
8 10 10 12 12 14
1 1 1 1 1 1
8
2010 330 550 2 210 385 1001 323
2010 1000 1200 30 500 1000 2000 1000
4
1 2 4 3
1 1 1 1
6
2 3 4 5 1 6
10 15 20 25 5 30
2
1 2
2 100
5
2860 2860 143 9009 9009
2860 2860 1430 9009 9009
3
2 60 60
10 60 60
```

### Output
```
7
3
0
7
1
6
2
0
0
```

## Note

In the first test, since the gcd of all subarrays is $$$1$$$, we can change the array to $$$a' = \[67, 5, 7, 11, 1, 2, 1\]$$$. Here we have performed $$$7$$$ operations, and since there are only $$$7$$$ elements in the array, it is the maximum possible.

In the second test case, we can change the array to $$$a' = \[938, 2613, 4489\]$$$. It can be shown that after this transformation, gcd of all subarrays remains the same. Hence the answer is $$$3$$$ here.

In the third test case, it can be shown that no operation can be performed, hence the answer is $$$0$$$.