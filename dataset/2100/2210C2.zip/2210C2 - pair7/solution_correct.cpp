//UPDATERA ARRAY STORLEKEN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
 
const ll INF=1e15;
const ll MAXN=50006;//UPDATERA ARRAY STORLEKEN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
ll t,n,a[MAXN],b[MAXN],new_a[MAXN],ans,dp[MAXN][31],maxi[MAXN];
int primes[31] = {1,2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97,101,103,107,109,113};
void init(){
    for(int i=0;i<=n+1;i++){
        for(int j=0;j<=30;j++){
            dp[i][j]=0;
        }
        maxi[i]=0;
        a[i]=0;
        b[i]=0;
        new_a[i]=0;
    }
    ans=0;
}

void solve(){
    cin>>n;
    init();
    for(int i=1;i<=n;i++) cin>>a[i];
    for(int i=1;i<=n;i++) cin>>b[i];

    new_a[1]=gcd(a[1],a[2]);
    new_a[n]=gcd(a[n],a[n-1]);

    for(int i=2;i<=n-1;i++){
        ll x=gcd(a[i],a[i-1]),y=gcd(a[i],a[i+1]);
        new_a[i]=x*y/gcd(x,y);
    }

    a[0]=a[n+1]=1;
    new_a[0]=new_a[n+1]=1;

    for(int i=1;i<=n;i++){
        if(new_a[i]>b[i]){
            new_a[i]=a[i];
        }
    }

    for(int i=1;i<=n;i++){//which number
        if(new_a[i]<=b[i]&&new_a[i]!=a[i]&&gcd(new_a[i],new_a[i-1])==gcd(a[i],a[i-1])&&gcd(new_a[i],new_a[i+1])==gcd(a[i],a[i+1])){
            dp[i][0]=maxi[i-1]+1;
        }else dp[i][0]=maxi[i-1];

        for(int k=1;k<=30;k++){//which prime we have now

            dp[i][k]=maxi[i-1];//not use it

            if(new_a[i]*primes[k]>b[i]||new_a[i]*primes[k]==a[i]) continue;

            for(int j=0;j<=30;j++){//which prime we transfer from
                ll pre_cnt=0,cnt=0,after_cnt=0;
                ll pre=new_a[i-1]*primes[j],now=new_a[i],after=new_a[i+1];

                while(pre%primes[k]==0){
                    pre/=primes[k];
                    pre_cnt++;
                }

                while(after%primes[k]==0){
                    after/=primes[k];
                    after_cnt++;
                }

                while(now%primes[k]==0){
                    now/=primes[k];
                    cnt++;
                }

                if(cnt>=pre_cnt&&cnt>=after_cnt&&gcd(new_a[i],new_a[i-1])==gcd(a[i],a[i-1])&&gcd(new_a[i],new_a[i+1])==gcd(a[i],a[i+1])){
                    dp[i][k]=max(dp[i][k],dp[i-1][j]+1);
                }
            }
        }

        for(int j=0;j<=30;j++) maxi[i]=max(maxi[i],dp[i][j]);
    }

    for(int i=0;i<=30;i++) ans=max(ans,dp[n][i]);

    cout<<ans<<'\n';
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>t;
    while(t--){
        solve();
    }
}