#include <bits/stdc++.h>

using namespace std;
#define endl '\n'
const int MAX_PRIME = 100000;
vector<int> primes= {1};
vector<bool> is_prime;
using ll = long long;

void init_primes(int n) {
    is_prime.assign(n + 1, true);
    is_prime[0] = is_prime[1] = false;
    for (int i = 2; i <= n; i++) {
        if (is_prime[i]) {
            primes.push_back(i);
        }
        for (int p : primes) {
            if(p == 1)continue;
            if (i * p > n) break;
            is_prime[i * p] = false;
            if (i % p == 0) break;
        }
    }
}

void solve(){
    int n; cin >> n;
    vector<int>a(n + 1), b(n + 1);
    for(int i = 1; i <= n ;i++)cin >> a[i];
    for(int i = 1; i <= n ;i++)cin >> b[i];
    vector<ll>g(n + 1, 0);
    for(int i = 1; i <= n; i++){
        if(i == 1)g[1] = gcd(a[1], a[2]);
        else if(i == n)g[n] = gcd(a[n], a[n - 1]);
        else g[i] = lcm(gcd(a[i], a[i - 1]), gcd(a[i], a[i + 1]));
        if(g[i] > b[i])g[i] = a[i];
    }

    //对于g[i] == b[i]需要看左右的质因子 不能添加左右含有的质因子
    vector<vector<int>>dp(n + 1, vector<int>(25, INT_MIN));

    for(int i = 0; i < 25; i++){
        if(i == 0){
            if(g[1] == a[1])dp[1][0] = 0;
            else dp[1][0] = 1;
            continue;
        }
        ll val = g[1] * primes[i];
        if(gcd(val, g[2]) == gcd(a[1], a[2]) && val <= b[1] && val != a[1])dp[1][i] = 1;
    }

    for(int i = 2; i <= n; i++){
        for(int j = 0; j < 25; j++){
            for(int last = 0; last < 25; last++){
                if(j == 0){
                    if(g[i] == a[i])dp[i][j] = max(dp[i - 1][last], dp[i][j]);
                    else dp[i][j] = max(dp[i][j], dp[i - 1][last] + 1);
                    continue;
                }
                ll val1 = g[i] * primes[j];
                ll val2 = g[i - 1] * primes[last];
                if(gcd(val1, val2) == gcd(a[i], a[i - 1]) && val1 <= b[i] && val2 <= b[i - 1] && val1 != a[i]){
                    if(i + 1 <= n){
                        if(gcd(val1, g[i + 1]) == gcd(a[i], a[i + 1])){
                            dp[i][j] = max(dp[i - 1][last] + 1, dp[i][j]);
                        }
                    }else dp[i][j] = max(dp[i - 1][last] + 1, dp[i][j]);
                }
            }
        }
    }
    cout << *max_element(dp[n].begin(), dp[n].end()) << endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);cout.tie(0);

    init_primes(MAX_PRIME);

    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
