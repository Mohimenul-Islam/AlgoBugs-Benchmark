/*
 ________
|    ___ |
|  ,',.(`|
| :  `'  |
| :) _  (|
|  `:_)_,|
|________|

Autor: Oscar Vargas Pabon
Fecha: 

*/

#include <bits/stdc++.h>

typedef long long lint;

using namespace std;

#define debug(args...) { string _s = #args; replace(_s.begin(), _s.end(), ',', ' '); stringstream _ss(_s); istream_iterator<string> _it(_ss); raw_debug(_it, args);}
void raw_debug(istream_iterator<string> it) {cerr<<endl;assert(it==it);}
template<typename T, typename... Args>
void raw_debug(istream_iterator<string> it, T a, Args... args) { cerr <<"<"<< *it << "->" << a << "> "; raw_debug(++it, args...); }
#define idebug(v) {cerr<<'['<<#v<<']';for(const auto &el:v)cerr << ' ' << el; cerr << endl;}
#define adebug(ar,n) {cerr<<'['<<#ar<<']';for(int i=0;i<n;++i)cerr << ' ' << ar[i]; cerr << endl;}
template <typename t1,typename t2> ostream &operator<<(ostream &os, const pair<t1,t2> &pr){return os<<"("<<pr.first<<";"<<pr.second<<")";};

#define rep(i,strt,end) for(int i = strt ; i !=int(end) ; (int(strt)<int(end))?++i:--i )
#define rall(vec) vec.rbegin(), vec.rend()
#define all(vec) vec.begin(), vec.end()
#define sz(vec) int(vec.size())
#define eb emplace_back
#define pb push_back
#define pob pop_back
#define pf push_front
#define pof pop_front

mt19937_64 rng_64( chrono::steady_clock::now().time_since_epoch().count() );
constexpr int ilog2( int num ) { return 8*sizeof(int) - __builtin_clz( num ) - 1; }
template<typename tpow> constexpr tpow mpow(tpow x,lint e,tpow m){tpow res=1;while(e){if(e&1ll)res=(res*1ll*x)%m;e>>=1;x=(x*1ll*x)%m;}return res;}

const int template_limit = 1e6;
int a[template_limit], b[template_limit];
lint c[template_limit],r[template_limit];

const int pamount=30;
int prime[pamount];
void precomp(int limit){
	int ind=2;prime[1]=1;
	vector<bool> crb(limit,0);rep(i,2,limit){
		if(crb[i])continue;
		prime[ind++]=i; if(ind>=pamount)break;
		for(int j=i*i;j<limit;j+=i)crb[j]=1;
	}
}


void solve() {
	int n;cin>>n;
	rep(i,0,n)cin>>a[i];
	rep(i,0,n)cin>>b[i];
	a[n]=1;rep(i,0,n){
		const int lg=i?__gcd(a[i],a[i-1]):1;
		const int rg=__gcd(a[i],a[i+1]);
		const int lcm=lg/__gcd(lg,rg)*rg;
		c[i]=lcm;
		// debug(i,lg,rg,lcm);
		assert(lcm<=a[i]);
	} vector<vector<int>> phi(n,vector<int>(pamount,-1e9));
	phi[0][0]=0; rep(i,1,pamount){
		const lint vl=c[0]*1ll*prime[i];
		if(vl<=b[0])phi[0][i]=vl!=a[0];
	} rep(i,0,n-1){
		const int g=__gcd(c[i+1],c[i]);
		rep(j,0,pamount)if(phi[i][j]>=0&& (j<=1|| (c[i+1]/g)%prime[j] > 0 ) )
		rep(k,0,pamount)if((j!=k||j<=1)&& (k<=1|| (c[ i ]/g)%prime[k] > 0 ) ){
			const lint vl=k?c[i+1]*1ll*prime[k]:a[i+1];
			
			if(!k&&j>1&& (a[i+1]/g)%prime[j]==0 ) continue;
			if(!j&&k>1&& (a[ i ]/g)%prime[k]==0 ) continue;
			// debug(vl,j,k);
			if(vl<=b[i+1]||!k)phi[i+1][k]=max<int>(phi[i+1][k],phi[i][j]+(vl!=a[i+1]));
		}
		// idebug(phi[i]);
	}
	// idebug(phi[n-1]);
	int res=0;rep(i,0,pamount)res=max<int>(res,phi[n-1][i]);
	cout << res << '\n';
}

int32_t main(){
	ios_base::sync_with_stdio(false);
    cin.tie(NULL);
	cout << setprecision(12) << fixed;
	precomp(1000);
    int t = 2;
    cin >> t; ++t;
    while ( --t ) {
		solve();
    }
	return 0;
}

