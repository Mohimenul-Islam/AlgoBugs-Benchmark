#include <bits/stdc++.h>
using namespace std; 
typedef long long ll;
ll gcd(ll x,ll y){
    if(!y) return x;
    return gcd(y , x % y);
}
ll lcm(ll x,ll y){
    return x / gcd(x , y) * y;
}
vector<ll>prime;
vector<ll>getprime(ll x){
    vector<ll>vis(x + 1,0);
    vector<ll>prime;
    for(ll i = 2;i <= x;i ++){
        if(!vis[i]){
            vis[i] = 1;
            prime.push_back(i);
        }
        if(prime.size() == 20) return prime;
        for(int j = 0;(ll)prime[j] * i <= x;j ++){
            ll v = prime[j] * i;
            vis[v] = 1;
            if(i % prime[j] == 0) break;
        }
    }
    return prime;
}
void solve()
{
    int n;
    cin >> n;
    vector<ll>a(n + 1,0) , b(n + 1,0);
    for(int i = 1;i <= n;i ++) cin >> a[i];
    for(int i = 1;i <= n;i ++) cin >> b[i];
    vector<ll>c(n + 1,0);
    int ss = prime.size();
    vector<vector<ll>>dp(n + 1,vector<ll>(ss + 2,-1e18));
    vector<ll>Gcd(n + 1,0);
    for(int i = 2;i <= n;i ++)
        Gcd[i] = gcd(a[i],a[i - 1]);
    for(int i = 1;i <= n;i ++){
        if(i == 1){
            c[i] = gcd(a[i],a[i + 1]);
            if(c[i] > b[i]) c[i] = a[i];
        }else if(i == n){
            c[i] = gcd(a[i],a[i - 1]);
            if(c[i] > b[i]) c[i] = a[i];
        }else{
            c[i] = lcm(Gcd[i],Gcd[i + 1]);
            if(c[i] > b[i]) c[i] = a[i];
        }
    }
    if(a[1] == c[1]) dp[1][0] = 0;
    else dp[1][0] = 1;
    for(int i = 1;i < ss;i ++){
        ll v = c[1] * prime[i - 1];
        if(v <= b[1] && v != a[1] && gcd(a[1],a[2]) == gcd(v,c[2])) dp[1][i] = 1;
    }
    for(int i = 2;i <= n;i ++){
        for(int j = 0;j <= ss;j ++)
            for(int k = 0;k <= ss;k ++){
                if(dp[i - 1][k] <= -1e18 / 2) continue;
                if(j == 0){
                    if(a[i] == c[i]) dp[i][j] = max(dp[i][j],dp[i - 1][k]);
                    else dp[i][j] = max(dp[i][j],dp[i - 1][k] + 1);
                    continue;
                }
                if(i == n){
                    ll v1 = c[i] * prime[j - 1];
                    ll v2;
                    if (k == 0) 
                        v2 = c[i-1]; 
                    else 
                        v2 = c[i-1] * prime[k-1]; 
                    if(gcd(v2 , v1) == gcd(a[i],a[i - 1]) && v1 <= b[n] && v1 != a[n]) dp[n][j] = max(dp[n][j],dp[n - 1][k] + 1);
                    continue;
                }
                ll v1 = c[i] * prime[j - 1];
                ll v2;
                if (k == 0) 
                    v2 = c[i-1]; 
                else 
                    v2 = c[i-1] * prime[k-1];
                ll tp = gcd(v1,v2);
                if(tp == gcd(a[i],a[i - 1]) && v1 != a[i]){
                    if(v1 <= b[i] && gcd(v1,c[i + 1]) == gcd(a[i + 1],a[i])) dp[i][j] = max(dp[i][j] , dp[i - 1][k] + 1);
                    continue;
                }
            }   
    }
    cout << max((ll)0,*max_element(dp[n].begin(),dp[n].end())) << endl;
}
 
int main()
{
    ios::sync_with_stdio(false);cin.tie(0);
    int t;
    cin >> t;
    prime = getprime(70);
    while(t --) solve();
    return 0;
}