#include <bits/stdc++.h>
using namespace std;

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;

using ll = long long;
template <class T>
using Tree = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

const int MAX = 51;
const int MOD = 998244353;

long long fact[MAX];
long long invFact[MAX];

long long fast_pow(long long base, long long p)
{
    long long res = 1;
    while (p > 0)
    {
        if (p % 2 == 1)
            res = (res * base) % MOD;
        base = (base * base) % MOD;
        p /= 2;
    }
    return res;
}
long long inverse(long long n)
{
    return fast_pow(n, MOD - 2);
}
void precompute()
{
    fact[0] = 1;
    invFact[0] = 1;
    for (int i = 1; i < MAX; i++)
    {
        fact[i] = (fact[i - 1] * i) % MOD;
    }
    invFact[MAX - 1] = inverse(fact[MAX - 1]);
    for (int i = MAX - 2; i >= 1; i--)
    {
        invFact[i] = (invFact[i + 1] * (i + 1)) % MOD;
    }
}

long long nCr(int n, int k)
{
    if (k < 0 || k > n)
        return 0;
    return (((fact[n] * invFact[k]) % MOD) * invFact[n - k]) % MOD;
}

long long __lcm(long long a, long long b)
{
    return a * b / (__gcd(a, b));
}

void solve()
{
    vector<ll> primes = {
        2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53};
    ll n;
    cin >> n;
    vector<ll> a(n + 2);
    vector<ll> b(n + 2);
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    for (int i = 1; i <= n; i++)
    {
        cin >> b[i];
    }
    a[0] = a[2];
    a[n + 1] = a[n - 1];
    vector<ll> f(n + 1, 0);
    vector<int> flag(n + 1, 0);
    for (int i = 1; i <= n; i++)
    {
        ll aux = __lcm(__gcd(a[i], a[i - 1]), __gcd(a[i], a[i + 1]));
        if (aux <= b[i] && aux != a[i])
        {
            a[i] = aux;
            f[i] = 1;
            flag[i] = 1;
        }
    }
    a[0] = a[2];
    flag[0] = 1;
    a[n + 1] = a[n - 1];
    vector<set<ll>> hv(n + 2);
    for (int i = 0; i <= n + 1; i++)
    {
        hv[i].insert(1);
    }
    for (int i = 1; i <= n; i++)
    {
        if (f[i] == 0)
        {
            for (auto it : hv[i - 1])
            {
                ll aux = __lcm(a[i - 1] * it, a[i + 1]);
                aux /= __gcd(aux, a[i]);
                for (int k = 0; k < (int)primes.size(); k++)
                {
                    if (aux % primes[k] != 0 && a[i] * primes[k] <= b[i])
                    {
                        if(it != 1 || flag[i - 1] == 1 || f[i - 1] == 0)
                        {
                            f[i] = 1;
                            hv[i].insert(primes[k]);
                        }
                    }
                }
            }
        }
    }
    cout << accumulate(f.begin(), f.end(), 0) << "\n";
}

int main()
{
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int tt;
    tt = 1;
    cin >> tt;
    while (tt--)
    {
        solve();
    }
}