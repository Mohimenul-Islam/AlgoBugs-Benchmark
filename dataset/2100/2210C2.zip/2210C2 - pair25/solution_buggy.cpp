#include<bits/stdc++.h>
using namespace std;
#define debug(a) cerr<<#a<<"="<<a<<"\n";
#define debug1(a,b) cerr <<#a <<"="<<a<<" "<<#b<<"="<<b<<"\n";
#define int long long
#define all1(a) a.begin()+1,a.end()
#define all(a) a.begin(),a.end()

const int N = 60;
int st[N+1];
vector<int > prime;
void init()
{
    prime.push_back(1);
    for(int i = 2; i <= N; i ++ ) 
    {
        if(!st[i]) 
        {
            prime.push_back(i);
        }
        for(int j = 0; j < prime.size()&&prime[j]*i<=N; j ++ ) 
        {
            st[i*prime[j]] = 1;
            if(i%prime[j]) break;
        }
    }
    // cout << prime.size();
}

void solve()
{
    int n;
    cin >> n;
    vector<int > a(n + 1), b(n + 1);
    for(int i =1; i <= n; i ++ ) cin >> a[i];
    for(int i = 1; i <= n; i ++ ) cin >> b[i];

    vector<int > c(n + 1);
    for(int i = 1; i <= n; i ++ ) 
    {
        int g1 = 1, g2 = 1;
        if(i>1) g1 = gcd(a[i-1],a[i]);
        if(i<n) g2 = gcd(a[i+1],a[i]);
        c[i] = lcm(g1,g2);
        if(c[i] > b[i]) c[i] = a[i];
    }
    int L = prime.size();
    vector<vector<int> > dp(n+1,vector<int>(L,-1e18));

    for(int i = 0; i < L; i ++ ) 
    {
        if(i == 0) 
        {
            if(c[i] == a[i] ) dp[1][0] = 0;
            else dp[1][0] = 1;
            continue;
        }
        int t = c[1] * prime[i];
        if(t<=b[1]&&gcd(t,c[2])==gcd(a[1],a[2])&&t!=a[1]) dp[1][i] = 1;
    }

    for(int i = 2; i <= n; i ++ )
    {
        for(int j = 0; j < L; j ++ ) 
        {
            for(int k = 0; k < L; k ++ ) 
            {
                if(j == 0) 
                {
                    if(a[i]!=c[i]) dp[i][j] = max(dp[i][j], dp[i-1][k]+1);
                    else dp[i][j] = max(dp[i][j], dp[i-1][k]);
                    continue;
                }
                int val1 = prime[j] * c[i];
                int val2 = prime[k] * c[i-1];
                if(val1<=b[i]&&gcd(val1,val2)==gcd(a[i],a[i-1]))
                {
                    if(i<n) 
                    {
                        if(gcd(val1,c[i+1])==gcd(a[i],a[i+1]))
                        {
                            if(val1!=a[i]) dp[i][j] = max(dp[i][j],dp[i-1][k]+1);
                            else dp[i][j] = max(dp[i][j], dp[i-1][k]);
                        }
                    }
                    else 
                    {
                        if(val1!=a[i]) dp[i][j] = max(dp[i][j],dp[i-1][k]+1);
                        else dp[i][j] = max(dp[i][j], dp[i-1][k]);
                    }
                }
            }
        }
    }
    cout << *max_element(all(dp[n])) << "\n";
}

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    int t = 1;
    init();
    cin >> t;
    while(t -- ) solve();
    return 0;
}