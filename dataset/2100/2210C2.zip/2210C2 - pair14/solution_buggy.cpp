#include<bits/stdc++.h>
using namespace std;
 
int32_t main (){
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  auto check_primes = [&](int x) -> bool {
    if (x < 2) return false;
    for (int i = 2; i * i <= x; i++) {
      if (x % i == 0) return false;
    }
    return true;
  };
  vector<int> primes;
  for (int i = 2; i <= 1000; i++) {
    if (primes.size() < 20 && check_primes(i)) {
      primes.push_back(i);
    }
  }
  int t;
  cin >> t;
  while (t--) {
    int n;
    cin >> n;
    vector<int> a(n + 2), b(n + 2);
    for (int i = 1; i <= n; i++) {
      cin >> a[i];
    }
    for (int i = 1; i <= n; i++) {
      cin >> b[i];
    }
    vector<int> new_a(n + 2);
    auto lcm = [&](int x, int y) -> int {
      return x / __gcd(x, y) * y;
    };
    for (int i = 1; i <= n; i++) {
      if (i > 1 && i < n) {
        new_a[i] = lcm(__gcd(a[i - 1], a[i]), __gcd(a[i + 1], a[i]));
      } else if (i == 1) {
        new_a[i] = __gcd(a[i], a[i + 1]);
      } else {
        new_a[i] = __gcd(a[i], a[i - 1]);
      }
      if (new_a[i] > b[i]) {
        new_a[i] = a[i];
      }
    }
    int sz = primes.size();
    vector<vector<int>> dp(n + 2, vector<int> (25, -1));
    for (int i = 0; i <= sz; i++) {
      if (!i) {
        dp[1][i] = new_a[1] < a[1] ? 1 : 0;
        continue;
      }
      int v = new_a[1] * primes[i - 1];
      if (v <= b[1] && v != a[1] && (__gcd(v, new_a[2]) == __gcd(a[1], a[2]))) {
        dp[1][i] = 1;
      }
    }
    for (int i = 2; i <= n; i++) {
      for (int j = 0; j <= sz; j++) {
        for (int k = 0; k <= sz; k++) {
          if (!j) {
            dp[i][j] = max(dp[i][j], dp[i - 1][k] + (new_a[i] < a[i]));
          } else {
            int v1 = new_a[i] * primes[j - 1];
            int v2 = k ? new_a[i - 1] * primes[k - 1] : new_a[i - 1];
            if (__gcd(v1, v2) == __gcd(a[i], a[i - 1]) && v1 <= b[i] && v1 != a[i]) {
              if (i < n && (__gcd(v1, a[i + 1]) != __gcd(a[i], a[i + 1]))) {
                continue;
              }
              dp[i][j] = max(dp[i][j], dp[i - 1][k] + 1);
            }
          }
        }
      }
    }
    int ans = -1;
    for (int i = 1; i <= n; i++) {
      for (int j = 0; j <= sz; j++) {
        ans = max(ans, dp[n][j]);
      }
    }
    cout << ans << '\n';
  }
}
 