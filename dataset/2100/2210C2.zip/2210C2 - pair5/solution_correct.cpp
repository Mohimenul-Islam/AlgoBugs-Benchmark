#include<bits/stdc++.h>
#pragma GCC optimize ("O3")
#define ll long long
#define ld long double
#define ull unsigned long long
#define ib ios_base::sync_with_stdio(0); cin.tie(NULL); cout.tie(NULL);
#define pb push_back
#define fi first
#define se second
#define pob pop_back
#define pf push_front
#define pof pop_front
#define endl '\n'
const ll inf = 1e5;
const ll mod = 1000000007;
using namespace std;
ll i,j,_ = 1;
ll dp[50100][30],a[50100],b[50100],ans,k,p,ok,p2;
vector<ll> prime;
void code()
{
    ll n;
    cin >> n;
    ans = 0;
    for(i = 1; i <= n; i ++)
        cin >> a[i];
    for(i = 1; i <= n; i ++)
        cin >> b[i];
    for(i = 1; i <= n; i ++)
        for(j = 0; j < prime.size(); j ++)
            dp[i][j] = -inf;
    a[0] = a[2];
    a[n + 1] = a[n - 1];
    for(i = 1; i <= n; i ++)
    {
        if(i == 1)
        {
            for(j = 0; j < prime.size(); j ++)
            {
                ll to = prime[j],p2 = gcd(a[i],a[i + 1]);
                if(j != 0)
                {
                    if(p2 * to != a[i] && p2 * to <= b[i])
                        dp[i][j] = 1;
                }
                else
                {
                    dp[i][j] = 0;
                }
            }
        }
        else if(i == n)
        {
            for(j = 0; j < prime.size(); j ++)
            {
                for(k = 0; k < prime.size(); k ++)
                {
                    ll to = prime[j],to1 = prime[k];
                    if(j == 0)
                        p = a[i - 1];
                    else
                        p = lcm(gcd(a[i - 2],a[i - 1]),gcd(a[i],a[i - 1]));
                    if(k == 0)
                        p2 = a[i];
                    else
                        p2 = gcd(a[i],a[i - 1]);
                    if(gcd(p * to,p2 * to1) == gcd(a[i],a[i - 1]))
                    {
                        if(p2 * to1 != a[i])
                        {
                            if(p2 * to1 <= b[i])
                                dp[i][k] = max(dp[i][k],dp[i - 1][j] + 1);
                        }
                        else
                        {
                            if(k == 0)
                            {
                               dp[i][k] = max(dp[i][k],dp[i - 1][j]);
                            }
                        }
                    }
                }
            }
        }
        else
        {
            for(j = 0; j < prime.size(); j ++)
            {
                for(k = 0; k < prime.size(); k ++)
                {
                    ll to = prime[j],to1 = prime[k];
                    if(j == 0)
                        p = a[i - 1];
                    else
                        p = p = lcm(gcd(a[i - 1],a[i]),gcd(a[i - 1],a[i - 2]));
                    if(k == 0)
                        p2 = a[i];
                    else
                        p2 = p2 = lcm(gcd(a[i],a[i + 1]),gcd(a[i],a[i - 1]));
                    if(gcd(p * to,p2 * to1) == gcd(a[i],a[i - 1]))
                    {
                        if(p2 * to1 != a[i])
                        {
                            if(p2 * to1 <= b[i])
                                dp[i][k] = max(dp[i][k],dp[i - 1][j] + 1);
                        }
                        else
                        {
                            if(k == 0)
                            {
                               dp[i][k] = max(dp[i][k],dp[i - 1][j]);
                            }
                        }
                    }
                }
            }
        }
    }
    for(j = 0; j < prime.size(); j ++)
        ans = max(ans,dp[n][j]);
    cout << ans;
}
main()
{
    ib;
    prime.pb(1);
    for(i = 1; i <= 71; i ++)
    {
        ok = 1;
        for(j = 2; j <= sqrt(i); j ++)
        {
            if(i % j == 0)
            {
                ok = 0;
                break;
            }
        }
        if(ok == 1)
            prime.pb(i);
    }
    cin >> _;
    while (_ --)
    {
        code();
        cout << endl;
    }
    return 0;
}
