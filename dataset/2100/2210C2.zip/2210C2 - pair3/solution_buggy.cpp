/*
 Explanation:
-

 Steps:
 -
 */

#include <algorithm>
#include <iostream>
#include <vector>
using namespace std; using ll = long long;
ll gcd(ll a, ll b){
    if (b == 0) {
            return a;
        }
    return gcd(b, a % b);
}
ll lcm(ll a, ll b){
    return (a*b)/gcd(a, b);
}
int main(){
    int t; cin >> t;
    while(t--){
        int n; cin >> n; vector<ll>a(n) , b(n);
        for(int i = 0 ; i < n; i++) cin >> a[i];
        for(int i = 0 ; i < n; i++) cin >> b[i];
        vector<ll>p = {1, 2 , 3 , 5 , 7 , 11, 13, 17, 19 , 23 , 29 , 31, 37, 41, 43 , 47, 53 , 59, 61, 67, 71, 73};
         vector<ll>c(n);
        for(int i = 0; i <n ; i++){
            if(i == 0)
                c[i] =  gcd(a[i], a[i+1]);
            else if(i == n-1)
                c[i] = gcd(a[i], a[i-1]);
            else
                c[i] = lcm(gcd(a[i], a[i+1]), gcd(a[i], a[i-1]));

            if(c[i] > b[i]) //check if able to change at all
                c[i] = a[i];
        }
        int l = p.size();
        vector<vector<ll>>dp(n, vector<ll>(l, -1e18));
        for(int i = 0; i < l; i++){ // base case
            if(i == 0){
                if(c[i] == a[i]) //check if unchanged works or not
                    dp[0][i] = 0;
                else
                    dp[0][i] = 1;
                continue;
            }else{
                ll x = c[0] * p[i];
                if(x <= b[0] && gcd(x, c[1]) == gcd(a[0], a[1]) && x != a[0])
                    dp[0][i] = 1;
            }
        }
        for(int i = 1; i < n; i++){
            for(int j = 0; j < l; j++){
                for(int k = 0; k < l; k++){
                    if(j == 0){
                        if(c[i] == a[i])
                            dp[i][j] = max(dp[i][j] , dp[i-1][k]); //see if unchanged it'll work or not
                        else
                            dp[i][j] = max(dp[i][j] , dp[i-1][k]+1);
                        continue;
                    }else{
                        ll cur = c[i]* p[j] ; ll pre = c[i-1] * p[k] ; //testing for this c[i] with current factor with diff c[i-1]
                        if(cur > b[i]) break;
                        if(cur <= b[i] && cur != a[i] && gcd(cur, pre) == gcd(a[i], a[i-1])){//test left adjacent
                            if(i < n-1){
                                if(gcd(cur, c[i+1]) == gcd(a[i] , a[i+1])) //test right adjacent to confirm
                                    dp[i][j] = max(dp[i][j] , dp[i-1][k] + 1);
                            }
                            else
                                dp[i][j] = max(dp[i][j] , dp[i-1][k] + 1); //there's no a[i+1] for right end
                        }
                    }
                }
            }
        }
        ll ans = 0;
        for(int j = 0; j < l; j++)
            ans = max(dp[n-1][j] , ans) ;
        cout << ans << "\n";

    }
}
/*
    Principles in Thought:
    1)Problems are soluble

    2)Logic is understandable

    3)Proves are simple

    4)Implementation are short

    5)Anyone can reach LGM with desire, persistence and defiance against their oun foul judgement

    *Keep the main thing the main thing, the problems themselves

    Goal: Reach 4000 rating and beyond before i die
 */

/*
Comparision between Easy version && Hard version:
- The easy version is easy because we know our choices beforehand and that basically simplifies the quesiton to the binary logic of
   is a[i] > lcm(g1, g2) ? ans++ : ans
- The hard version is hard because our choice are not known and that it can go both ways, we can either decrease or incrase our a[i]
   and since our choices are not known, our current choice for a particular index may affect the possibility of our choices for future index
   (because for one choice, it may work with this current adjacent element but may clash with the choice of another element down the line)
- Therefore this version of the problem turns it into a dp problem , where we must explore all possible paths to find the best sequence of choices
 */
