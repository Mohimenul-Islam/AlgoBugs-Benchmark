#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <numeric>
#include <vector>
#include <cmath>
#include <array>
using namespace std;

using ll = long long;
const int L = 21;
array<vector<int>, L> dp;

int n;
vector<ll> a, b, c;
const ll primes[L] = {
    1, 2, 3, 5, 7, 11, 13, 
    17, 19, 23, 29, 31, 37, 41, 43, 47,
    53, 59, 61, 67, 71};

void solve() {
    cin >> n;
    a.assign(n + 1, 0), b.assign(n + 1, 0);
    c.assign(n + 1, 0);
    for (int i = 1; i <= n; i++) cin >> a[i];
    for (int i = 1; i <= n; i++) cin >> b[i];

    for (int i = 2; i < n; i++)
        c[i] = std::lcm(std::gcd(a[i], a[i + 1]), std::gcd(a[i], a[i - 1]));
    c[1] = std::gcd(a[1], a[2]), c[n] = std::gcd(a[n], a[n - 1]);
    for (int i = 1; i <= n; i++) if (c[i] > b[i]) c[i] = a[i];

    for (int i = 0; i < L; i++) dp[i].assign(n + 1, -1e6);
    for (int j = 0; j < L; j++) {
        if (j == 0) {
            dp[j][1] = 1 - (c[1] == a[1]);
            continue;
        }
        ll v = primes[j] * c[1];
        if (v <= b[1] && std::gcd(v, c[2]) == std::gcd(c[1], c[2]) && v != a[1])
            dp[j][1] = 1;
    }

    for (int i = 2; i <= n; i++) {
        for (int j = 0; j < L; j++) {
            for (int k = 0; k < L; k++) {
                if (j == 0) {
                    dp[j][i] = max(dp[j][i], dp[k][i - 1] + (c[i] != a[i]));
                    continue;
                }
                ll val_now = primes[j] * c[i], val_last = primes[k] * c[i - 1];
                if (val_now > b[i]) continue;
                if (k > 0 && val_last > b[i - 1]) continue;
                if (std::gcd(val_now, val_last) != std::gcd(a[i], a[i - 1])) continue;
                if (i < n && std::gcd(val_now, c[i + 1]) != std::gcd(a[i], a[i + 1])) continue;
                // if (val_now == a[i]) continue;
                dp[j][i] = max(dp[j][i], dp[k][i - 1] + (val_now != a[i]));
            }
        }
    }
    int ans = 0;
    for (int i = 0; i < L; i++) ans = max(ans, dp[i][n]);
    cout << ans << "\n";

}

int main() {
    cin.tie(nullptr)->ios::sync_with_stdio(false);
    int t; cin >> t;
    while (t--) solve();
    return 0;
}