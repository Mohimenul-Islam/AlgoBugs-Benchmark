#include <bits/stdc++.h>
#define fi first
#define se second
using namespace std;

typedef long long ll;

const int maxn = 50000 + 100;
const ll mod = 1000000000 + 7;

ll a[maxn];
ll b[maxn];
ll c[maxn];
ll g[maxn];
int n;

ll dp[maxn][25];

ll prime[] = {1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83};

ll lcm(ll A, ll B) {
    return A/ __gcd(A,B) * B;

}


void solve(){
    cin >> n;
    for (int i = 1; i <= n;i ++) cin >> a[i];
    for (int i = 1; i <= n;i ++) cin >> b[i];


    for (int i = 1; i <= n;++i) {

        ll s;

        if (i == 1) {
            s = __gcd(a[i], a[i + 1]);
            g[i] = __gcd(a[i], a[i + 1]);
        }
        else if (i == n) {
            s = __gcd(a[n], a[n-1]);
        }
        else {
            s = lcm(__gcd(a[i], a[i + 1]), __gcd(a[i], a[i-1]));
            g[i] = __gcd(a[i], a[i + 1]);
        }

        if (s > b[i] || s == a[i]) c[i] = a[i];
        else if (s <= b[i]) c[i] = s;
    }


    for (int i = 0; i <= n;++i) {
        for (int j = 0; j <= 22;j ++) dp[i][j] = -1e18;
    }

    if (c[1] == a[1]) dp[1][0] = 0;
    else dp[1][0] = 1;

    for (int i = 1; i <= 22;++i) {
        if (g[1] == __gcd(c[1] * prime[i], c[2]) && c[1] * prime[i] <= b[1] && c[1] * prime[i] != a[1]) {
            dp[1][i] = 1;
        }
        else dp[1][i] = 0;
    }


    ll res = -1e18;

    for (int i = 2; i <= n;++i) {
        for (int j = 0; j <= 22;++j) { // this
            for (int k = 0; k <= 22; ++k) { // old



                if (j == 0) {
                    if (c[i] == a[i]) dp[i][j] = max(dp[i][j], dp[i-1][k]);
                    else dp[i][j] = max(dp[i][j], dp[i-1][k] + 1);
                }
                else {
                    ll v = c[i] * prime[j];
                    ll u = c[i-1] * prime[k];
                    if (v <= b[i] && __gcd(u, v) == g[i-1] && v != a[i]) {

                        if (i < n) {
                            if (__gcd(v, c[i + 1]) == g[i]) {
                                dp[i][j] = max(dp[i][j], dp[i-1][k] + 1);
                            }
                            else dp[i][j] = max(dp[i][j], dp[i-1][k]);
                        }
                        else {
                            dp[i][j] = max(dp[i][j], dp[i-1][k] + 1);
                        }

                    }

                }
            }

            if (i == n) res = max(res, dp[i][j]);

        }
    }
    cout << res << "\n";

}

int main(){
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);

    int t; cin >> t;

    while (t--){
        solve();
    }


    return 0;
}
