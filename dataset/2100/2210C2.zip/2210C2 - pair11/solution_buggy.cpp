#include <bits/stdc++.h>
using namespace std; 
typedef long long ll;

void solve()
{
    ll n;
    cin >> n;
    vector<ll> a(n), b(n), c(n);
    for(ll i = 0; i < n; i++) cin >> a[i];
    for(ll i = 0; i < n; i++) cin >> b[i];
    vector<ll> primes = {1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73};
    for(ll i = 0; i < n; i++)
    {
        if (i == 0) c[i] = gcd(a[i], a[i+1]);
        else if (i == n-1) c[i] = gcd(a[i-1], a[i]);
        else c[i] = lcm(gcd(a[i], a[i-1]), gcd(a[i], a[i+1]));
 
        if (c[i] > b[i]) c[i] = a[i];
    }
    ll L = primes.size();
    vector<vector<ll>> dp(n, vector<ll>(L, -1e18));
 
    //set up the base cases
    for(ll i = 0; i < L; i++)
    {
        if (i == 0)
        {
            if (c[0] == a[0]) dp[0][0] = 0;
            else dp[0][0] = 1;
            continue;
        }
        ll val = c[0] * primes[i];
        if (val <= b[0] and gcd(val, c[1]) == gcd(a[0], a[1]) and val != a[0]) dp[0][i] = 1; 
    }
    
    //make the transitions
    for(ll i = 1; i < n; i++)
    {
        for(ll j = 0; j < L; j++)
        {
            for(ll k = 0; k < L; k++)
            {
                //j = 0, special case, we are keeping value unchanged, and always want something to be assigned here
                if (j == 0)
                {
                    if (c[i] == a[i]) dp[i][j] = max(dp[i][j], dp[i-1][k]);
                    else dp[i][j] = max(dp[i][j], dp[i-1][k]+1);
                    continue;
                }
                //we check for all conditions, that multiplying this by prime j and prev by prime k keeps everything in check
                ll val1 = c[i] * primes[j];
                ll val2 = c[i-1] * primes[k];
                if (val1 <= b[i] and gcd(val1, val2) == gcd(a[i], a[i-1]) and val1 != a[i])
                {
                    if (i < n-1)
                    {
                        if (gcd(val1, c[i+1]) == gcd(a[i], a[i+1])) dp[i][j] = max(dp[i][j], dp[i-1][k] + 1);
                    }
                    else dp[n-1][j] = max(dp[n-1][j], dp[n-2][k] + 1);
                }
            }
        }
    }
    cout << max(0LL, *max_element(dp[n-1].begin(), dp[n-1].end())) << '\n';
}
 
int main()
{
    ll n = 1;
    cin >> n;
    while(n--) solve();
    return 0;
}