#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int,int> PII;
typedef pair<ll,ll> PLL;
#define INF 0x3f3f3f3f3f3f3f3f
#define inf 0x3f3f3f3f
#define fi first
#define se second
#define pb push_back
#define pf push_front
#define emplace_back eb
#define endl '\n'
int dx[]={-1,0,1,0,1,1,-1,-1},dy[]={0,1,0,-1,1,-1,1,-1};
const int N=5e4+10;
ll a[N],b[N],c[N];
int primes[]={1,2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73};
ll dp[N][25];
int n;
ll g[N];

ll gcd(ll x,ll y)
{
    return y==0?x:gcd(y,x%y);
}

void solve()
{
    cin>>n;
    for(int i=1;i<=n;i++)cin>>a[i];
    for(int j=1;j<=n;j++)cin>>b[j];
    for(int i=1;i<=n;i++)
    {
        if(i==1)c[i]=gcd(a[1],a[2]),g[i]=c[i];
        else if(i==n)c[i]=g[n-1];
        else
        {
            ll lgcd=g[i-1];
            ll rgcd=gcd(a[i],a[i+1]);
            g[i]=rgcd;
            c[i]=lgcd*rgcd/gcd(lgcd,rgcd);
        }
        if(c[i]>b[i])c[i]=a[i];
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<22;j++)
        {
            dp[i][j]=-1e18;
        }
    }
    for(int i=0;i<22;i++)
    {
        if(i==0)
        {
            if(c[1]==a[1])dp[1][i]=0;
            else dp[1][i]=1;
            continue;
        }
        ll val1=c[1]*primes[i];
        if(val1>b[1])break;
        if(gcd(val1,c[2])==g[1]&&val1!=a[1])dp[1][i]=1;
    }
    for(int i=2;i<=n;i++)
    {
        for(int j=0;j<22;j++)
        {
            for(int k=0;k<22;k++)
            {
                if(j==0)
                {
                    if(a[i]==c[i])dp[i][j]=max(dp[i][j],dp[i-1][k]);
                    else dp[i][j]=max(dp[i][j],dp[i-1][k]+1);
                    continue;
                }
                ll val1=c[i]*primes[j];
                ll val2=c[i-1]*primes[k];
                if(val1>b[i])break;
                if(gcd(val1,val2)==g[i-1]&&val1!=a[i])
                {
                    if(i<n)
                    {
                        if(gcd(val1,c[i+1])==g[i])
                        {
                            dp[i][j]=max(dp[i][j],dp[i-1][k]+1);
                        }
                    }
                    else dp[i][j]=max(dp[i][j],dp[i-1][k]+1);
                }
            }
        }
    }
    ll ans=0;
    for(int i=0;i<22;i++)ans=max(ans,dp[n][i]);
    cout<<ans<<endl;
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    //#ifndef ONLINE_JUDGE
        //freopen("in.txt", "r", stdin);
    //#endif
    int t=1;
    cin>>t;
    while(t--)
    solve();
    cout.flush();
    return 0;
}