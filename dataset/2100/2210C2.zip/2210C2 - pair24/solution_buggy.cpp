#include <bits/stdc++.h>
using namespace std;

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#define mod 1000000007
#define mod1 998244353
#define mod2 1000000009
#define hash 37
#define ll long long
#define int long long

#ifndef ONLINE_JUDGE
#define debug(a) cout << "debug: " << #a << " = " << a << "\n";
#else 
#define debug(a) ;
#endif

typedef __gnu_pbds::tree<int, __gnu_pbds::null_type, less<int>, __gnu_pbds::rb_tree_tag, __gnu_pbds::tree_order_statistics_node_update> ordered_set;

random_device rd;
mt19937 g(rd());

template <typename T>
istream& operator>> (istream& in, vector<T>& a)
{
    for (int i = 0; i < a.size(); ++i)
        in >> a[i];

    return in;
}

template <typename T>
ostream& operator<< (ostream& out, vector<T>& a)
{
    for (int i = 0; i < a.size(); ++i)
        out << a[i] << " ";

    out << "\n";

    return out;
}

template <typename T>
ostream& operator<< (ostream& out, set<T>& s)
{
    for (T x : s)
        out << x << " ";

    out << "\n";

    return out;
}

template <typename T>
ostream& operator<< (ostream& out, multiset<T>& s)
{
    for (T x : s)
        out << x << " ";

    out << "\n";

    return out;
}

template <typename S, typename T>
ostream& operator<< (ostream& out, pair<S, T>& p)
{
    out << p.first << " " << p.second << "\n";

    return out;
}

template <typename S, typename T>
ostream& operator<< (ostream& out, vector<pair<S, T>>& v)
{
    for (int i = 0; i < v.size(); ++i)
        out << v[i].first << " " << v[i].second << "\n";

    return out;
}

template <typename S, typename T>
ostream& operator<< (ostream& out, map<S, T>& mp)
{
    for (auto& p : mp)
        cout << p.first << " " << p.second << "\n";

    return out;
}

ll modinv(ll a)
{
    return a <= 1 ? a : mod - (mod / a) * modinv(mod % a) % mod; 
}

ll modinv(ll a, ll m)
{
    return a <= 1 ? a : m - (m / a) * modinv(m % a, m) % m; 
}

ll binpow(ll x, ll y)
{
    ll ans = 1;

    while (y > 0)
    {
        if (y % 2 == 1)
            ans *= x;

        x = x * x;
        y >>= 1;

        x %= mod;
        ans %= mod;
    }

    return ans;
}

void solve()
{
    int n, i;
    cin >> n;

    vector<int> a(n + 1), b(n + 1);

    for (i = 1; i <= n; ++i)
        cin >> a[i];

    for (i = 1; i <= n; ++i)
        cin >> b[i];

    vector<int> c(n + 1);
    c[1] = gcd(a[1], a[2]);
    c[n] = gcd(a[n - 1], a[n]);

    for (i = 2; i < n; ++i)
        c[i] = lcm(gcd(a[i - 1], a[i]), gcd(a[i], a[i + 1]));

    vector<int> primes = {1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71};
    int m = primes.size() - 1;

    vector<vector<int>> dp(n + 1, vector<int>(m + 1, 0));
    
    for (i = 0; i <= m; ++i)
        dp[0][i] = 0;

    for (int curr = 0; curr <= m; ++curr)
    {
        int x = primes[curr] * c[1];
        
        if (x != a[1] && x <= b[1] && (gcd(x, c[2]) == gcd(a[1], a[2])) && c[2] <= b[2])
            dp[1][curr] = 1;

        else
            dp[1][curr] = 0;
    }

    debug(c);

    for (i = 2; i <= n; ++i)
    {
        for (int prev = 0; prev <= m; ++prev)
        {
            for (int curr = 0; curr <= m; ++curr)
            {
                int x = primes[prev] * c[i - 1];
                int y = primes[curr] * c[i];

                if (y != a[i] && (x <= b[i - 1] || b[i - 1] < c[i - 1]) && y <= b[i] && (gcd(x, y) == gcd(a[i - 1], a[i])) && ((i == n) ? true : ((gcd(y, c[i + 1]) == gcd(a[i], a[i + 1])) && c[i + 1] <= b[i + 1])))
                {
                    // debug(i);
                    // debug(curr);

                    dp[i][curr] = max(dp[i][curr], 1 + dp[i - 1][prev]);
                }

                else
                {
                    // debug(i);
                    // debug(prev);
                    // debug(curr);
                    dp[i][curr] = max(dp[i][curr], dp[i - 1][prev]);  
                }         
            }
        }
    }

    debug(dp);

    int ans = 0;

    for (i = 0; i <= m; ++i)
        ans = max(ans, dp[n][i]);

    cout << ans << "\n";
}

int32_t main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int t = 1;
    cin >> t;

    while (t--)
    {
        solve();
    }

    return 0;
}