#include<bits/stdc++.h>
#define inf 0x3f3f3f3f
#define Inf (1ll<<60)
#define For(i,s,t) for(int i=s;i<=t;++i)
#define Down(i,s,t) for(int i=s;i>=t;--i)
#define ls (i<<1)
#define rs (i<<1|1)
#define lowbit(x) ((x)&(-(x)))
#define End {printf("NO\n");exit(0);}
#define mp make_pair
#define pb push_back
#define ep emplace_back
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
inline void ckmx(int &x,int y){x=(x>y)?x:y;}
inline void ckmn(int &x,int y){x=(x<y)?x:y;}
inline void ckmx(ll &x,ll y){x=(x>y)?x:y;}
inline void ckmn(ll &x,ll y){x=(x<y)?x:y;}
inline int min(int x,int y){return x<y?x:y;}
inline int max(int x,int y){return x>y?x:y;}
inline ll min(ll x,ll y){return x<y?x:y;}
inline ll max(ll x,ll y){return x>y?x:y;}
#define gc() getchar()
#define read() ({\
    int x = 0, f = 1;\
    char c = gc();\
    while(c < '0' || c > '9') f = (c == '-') ? -1 : 1, c = gc();\
    while(c >= '0' && c <= '9') x = x * 10 + (c & 15), c = gc();\
    f * x;\
})
void write(int x){
    if(x>=10) write(x/10);
    putchar(x%10+'0');
}
const int N=2e5+100,p=998244353;
inline int bmod(int x){return x>=p ? x-p : x;}
inline void add(int &x,int y){x=bmod(x+y);}
inline int qpow(int x,int y){
    int res=1;
    for(;y;y>>=1,x=1ull*x*x%p)
        if(y&1)
            res=1ull*x*res%p;
    return res;
}
int n;
ll a[N],b[N],c[N];
bool vis[1000005];
ll lcm(ll x,ll y){return x/__gcd(x,y)*y;}
int pri[N],cnt;
void init(){
    n=1000000;
    For(i,2,n){
        if(!vis[i])
            pri[++cnt]=i;
        if(cnt>=20) break;
        For(j,1,cnt){
            if(i*pri[j]>n) break;
            vis[i*pri[j]]=1;
            if(i%pri[j]==0) break;
        }
    }
    cerr<<cnt<<'\n';
}
int f[N][35];
void solve(){
    n=read();
    For(i,1,n) a[i]=read();
    For(i,1,n) b[i]=read();
    For(i,1,n) vis[i]=0;
    a[0]=a[n+1]=1;
    int ans=0;
    For(i,1,n){
        ll v1=__gcd(a[i-1],a[i]),v2=__gcd(a[i],a[i+1]);
        if(i==1){
            if(v2!=a[i] && b[i]>=v2)
                ++ans,a[i]=v2,vis[i]=1;
            c[i]=v2;
        }
        else if(i==n){
            if(v1!=a[i] && b[i]>=v1)
                ++ans,a[i]=v1,vis[i]=1;
            c[i]=v1;
        }
        else{
            if(v1!=a[i] && v2!=a[i] && lcm(v1,v2)!=a[i] && b[i]>=lcm(v1,v2))
                ++ans,a[i]=lcm(v1,v2),vis[i]=1;
            c[i]=lcm(v1,v2);
        }
    }
    For(i,1,n)
        For(j,0,cnt)
            f[i][j]=-inf;
    f[0][0]=0;
    For(i,1,n)
        For(j,0,cnt){
            if(pri[j]*c[i]>b[i]) continue;
            if(vis[i]){
                if(j!=0) break;
                For(k,0,cnt)
                    if(i!=1 && k && __gcd(c[i-1]*pri[k],a[i])==__gcd(a[i-1],a[i]))
                        ckmx(f[i][j],f[i-1][k]+2);
                    else if(i==1 || __gcd(k ? c[i-1]*pri[k] : a[i-1],a[i])==__gcd(a[i-1],a[i]))
                        ckmx(f[i][j],f[i-1][k]+1);
            }
            else if(j==0){
                For(k,0,cnt)
                    if(i!=1 && k && __gcd(c[i-1]*pri[k],a[i])==__gcd(a[i-1],a[i]))
                        ckmx(f[i][j],f[i-1][k]+1);
                    else if(i==1 || __gcd(k ? c[i-1]*pri[k] : a[i-1],a[i])==__gcd(a[i-1],a[i]))
                        ckmx(f[i][j],f[i-1][k]);
            }
            else{
                For(k,0,cnt)
                    if(i!=1 && k && __gcd(c[i-1]*pri[k],c[i]*pri[j])==__gcd(a[i-1],a[i]))
                        ckmx(f[i][j],f[i-1][k]+1);
                    else if(i==1 || __gcd(k ? c[i-1]*pri[k] : a[i-1],c[i]*pri[j])==__gcd(a[i-1],a[i]))
                        ckmx(f[i][j],f[i-1][k]);
            }
            // cerr<<i<<' '<<j<<' '<<f[i][j]<<'\n';
        }
    For(i,0,cnt) ckmx(ans,f[n][i]+(i!=0));
    printf("%d\n",ans);
}
int main()
{
// #if !ONLINE_JUDGE
//     freopen("test.in","r",stdin);
//     freopen("test.out","w",stdout);
// #endif 
    int T=1;
    init();
    T=read();
    while(T--) solve();
    return 0;
}