#include <queue>
#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <complex>
#include <fstream>
#include <cstring>
#include <string>
#include <cassert>
#include <unordered_map>
#include <climits>
 
using namespace std;
//macros
typedef long long ll;
typedef complex<double> point;
typedef pair<int,int> ii;
typedef vector<int> vi;
typedef vector< vector<int> > vvi;
 
 
 
 
#define FOR(k,a,b) for(int k=(a); k<=(b); ++k)
#define REP(k,a) for(int k=0; k<(a);++k)
#define SZ(a) int((a).size())
#define ALL(c) (c).begin(),(c).end()
#define PB push_back
#define MP make_pair
#define INF 99999999
#define MOD 998244353
#define MAX 15383
#define ITERS 100
#define MAXN 50000
#define _gcd __gcd
#define f first
#define s second
 
using namespace std;
#define EPS 1e-9
#define ERR 987654321

int gcd(int a, int b){
    if(b == 0) return a;
    return gcd(b, a % b);
}
ll lcm(ll a, ll b){
    return a / gcd(a,b) * b;
}
int actual_sol(int n, vector<int> a, vector<int> b){
    vector<ll> c(n);
    vector<ll> primes = {1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73};
    for(ll i = 0; i < n; i++)
    {
        if (i == 0) c[i] = gcd(a[i], a[i+1]);
        else if (i == n-1) c[i] = gcd(a[i-1], a[i]);
        else c[i] = lcm(gcd(a[i], a[i-1]), gcd(a[i], a[i+1]));
 
        if (c[i] > b[i]) c[i] = a[i];
    }
    ll L = primes.size();
    vector<vector<ll>> dp(n, vector<ll>(L, -1e18));
 
    //set up the base cases
    for(ll i = 0; i < L; i++)
    {
        if (i == 0)
        {
            if (c[0] == a[0]) dp[0][0] = 0;
            else dp[0][0] = 1;
            continue;
        }
        ll val = c[0] * primes[i];
        if (val <= b[0] and gcd(val, c[1]) == gcd(a[0], a[1]) and val != a[0]) dp[0][i] = 1; 
    }
    
    //make the transitions
    for(ll i = 1; i < n; i++)
    {
        for(ll j = 0; j < L; j++)
        {
            for(ll k = 0; k < L; k++)
            {
                //j = 0, special case, we are keeping value unchanged, and always want something to be assigned here
                if (j == 0)
                {
                    if (c[i] == a[i]) dp[i][j] = max(dp[i][j], dp[i-1][k]);
                    else dp[i][j] = max(dp[i][j], dp[i-1][k]+1);
                    continue;
                }
                //we check for all conditions, that multiplying this by prime j and prev by prime k keeps everything in check
                ll val1 = c[i] * primes[j];
                ll val2 = c[i-1] * primes[k];
                if (val1 <= b[i] and gcd(val1, val2) == gcd(a[i], a[i-1]) and val1 != a[i])
                {
                    if (i < n-1)
                    {
                        if (gcd(val1, c[i+1]) == gcd(a[i], a[i+1])) dp[i][j] = max(dp[i][j], dp[i-1][k] + 1);
                    }
                    else dp[n-1][j] = max(dp[n-1][j], dp[n-2][k] + 1);
                }
            }
        }
    }
    return max(0LL, *max_element(dp[n-1].begin(), dp[n-1].end()));
}
int solve(int n, vector<int> a, vector<int> b){
    int ops = 0;
    vector<bool> can_modify(n, false);
    for(int i=0; i < n; i++){
        ll lc = lcm((i > 0) ? gcd(a[i], a[i-1]) : 1, (i < n-1) ? gcd(a[i], a[i+1]) : 1);
        //cout << "for i = " << i << ", lcm = " << lc << endl;
        if(lc <= b[i] && lc != a[i]){
            ops++;
            a[i] = lc;
            can_modify[i] = false;
        }
        else{
            if(lc > b[i]){
                can_modify[i] = false;
            }
            else{
                can_modify[i] = true;
            }
        }

    }
    // dp for rest by picking what prime we multiply each number to increase to
    vector<int> primes = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79};
    vector<vector<int>> dp(n+1, vector<int>(SZ(primes), -INF));
    dp[0][0] = 0;
    //cout << "Baseline ops: " << ops << endl;
    for(int i = 1; i <= n; i++){
        if(!can_modify[i-1]){
            for(int jj = 0; jj <= 20; jj++){
                if(i == 1){
                    dp[i][0] = max(dp[i][0], dp[i-1][jj]);
                    continue;
                }
                ll prev_val = (ll) a[i-2] * (ll) ((jj == 0) ? 1 : primes[jj-1]);
                if(gcd(prev_val, a[i-1]) == gcd(a[i-2], a[i-1])){
                    dp[i][0] = max(dp[i][0], dp[i-1][jj]);
                }
            }
            continue;
        }
        // case 1: don't modify this number
        for(int here_p = 0; here_p <= 20; here_p++){
            ll here_val = (ll) a[i-1] * (ll) ((here_p == 0) ? 1 : primes[here_p-1]);
            if(here_val > b[i-1]) continue;
            if(i == 1){
                dp[i][here_p] = (here_p == 0) ? 0 : 1;
                continue;
            }
            for(int prev_p = 0; prev_p <= 20; prev_p++){
                ll prev_val = (ll) a[i-2] * (ll) ((prev_p == 0) ? 1 : primes[prev_p-1]);
                if(gcd(here_val, prev_val) == gcd(a[i-1], a[i-2])){
                    dp[i][here_p] = max(dp[i][here_p], dp[i-1][prev_p] + ((here_p == 0) ? 0 : 1));
                }
            }
        }
        //cout << "dp after processing i = " << i << ": ";
        //REP(j, SZ(primes)){
        //    cout << dp[i][j] << " ";
        //}
        //cout << endl;
    }
    ll bst = 0;
    REP(i, SZ(primes)){
        bst = max(bst, (ll) dp[n][i]);
    }
    return ops + (int)bst;
}
int main() {
    int t;
    cin >> t;
    while(t--){
        int n;
        cin >> n;
        vi a(n);
        REP(i,n) cin >> a[i];
        vi b(n);
        REP(i,n) cin >> b[i];
        cout << solve(n, a, b) << endl;
    }
}
