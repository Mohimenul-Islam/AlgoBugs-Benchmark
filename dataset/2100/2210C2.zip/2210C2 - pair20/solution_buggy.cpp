#include <queue>
#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <complex>
#include <fstream>
#include <cstring>
#include <string>
#include <cassert>
#include <unordered_map>
#include <climits>
 
using namespace std;
//macros
typedef long long ll;
typedef complex<double> point;
typedef pair<int,int> ii;
typedef vector<int> vi;
typedef vector< vector<int> > vvi;
 
 
 
 
#define FOR(k,a,b) for(int k=(a); k<=(b); ++k)
#define REP(k,a) for(int k=0; k<(a);++k)
#define SZ(a) int((a).size())
#define ALL(c) (c).begin(),(c).end()
#define PB push_back
#define MP make_pair
#define INF 99999999
#define MOD 998244353
#define MAX 15383
#define ITERS 100
#define MAXN 50000
#define _gcd __gcd
#define f first
#define s second
 
using namespace std;
#define EPS 1e-9
#define ERR 987654321

int gcd(int a, int b){
    if(b == 0) return a;
    return gcd(b, a % b);
}
ll lcm(ll a, ll b){
    return a / gcd(a,b) * b;
}
int solve(int n, vector<int> a, vector<int> b){
    int ops = 0;
    vector<bool> can_modify(n, false);
    for(int i=0; i < n; i++){
        ll lc = lcm((i > 0) ? gcd(a[i], a[i-1]) : 1, (i < n-1) ? gcd(a[i], a[i+1]) : 1);
        //cout << "for i = " << i << ", lcm = " << lc << endl;
        if(lc <= b[i] && lc != a[i]){
            ops++;
            a[i] = lc;
            can_modify[i] = false;
        }
        else{
            if(lc > b[i]){
                can_modify[i] = false;
            }
            else{
                can_modify[i] = true;
            }
        }

    }
    // dp for rest by picking what prime we multiply each number to increase to
    vector<int> primes = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79};
    vector<vector<int>> dp(n+1, vector<int>(SZ(primes), -INF));
    dp[0][0] = 0;
    //cout << "Baseline ops: " << ops << endl;
    for(int i = 1; i <= n; i++){
        if(!can_modify[i-1]){
            for(int jj = 0; jj <= 20; jj++){
                dp[i][0] = max(dp[i][0], dp[i-1][jj]);
            }
            continue;
        }
        // case 1: don't modify this number
        for(int here_p = 0; here_p <= 20; here_p++){
            ll here_val = (ll) a[i-1] * (ll) ((here_p == 0) ? 1 : primes[here_p-1]);
            if(here_val > b[i-1]) continue;
            if(i == 1){
                dp[i][here_p] = (here_p == 0) ? 0 : 1;
                continue;
            }
            for(int prev_p = 0; prev_p <= 20; prev_p++){
                ll prev_val = (ll) a[i-2] * (ll) ((prev_p == 0) ? 1 : primes[prev_p-1]);
                if(gcd(here_val, prev_val) == gcd(a[i-1], a[i-2])){
                    dp[i][here_p] = max(dp[i][here_p], dp[i-1][prev_p] + ((here_p == 0) ? 0 : 1));
                }
            }
        }
    }
    ll bst = 0;
    REP(i, SZ(primes)){
        bst = max(bst, (ll) dp[n][i]);
    }
    return ops + (int)bst;
}
int main() {
    int t;
    cin >> t;
    while(t--){
        int n;
        cin >> n;
        vi a(n);
        REP(i,n) cin >> a[i];
        vi b(n);
        REP(i,n) cin >> b[i];
        cout << solve(n, a, b) << endl;
    }
}
