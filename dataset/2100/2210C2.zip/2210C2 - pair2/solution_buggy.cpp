#include<bits/stdc++.h>
#define int long long
using namespace std;
namespace ZheDaoTiShi{bool st;}
namespace ZaiJiaXieDe{
int pri[25]={1,2,3,5,7,11,13,17,19,23,29,31,37,41,53,59,61,67,71,73,79};
int T,n,a[50500],b[50500],c[50500],dp[50500][25];
int lcm(int x,int y){
	return x*y/__gcd(x,y);
}
string main(){ 
	memset(dp,-0x3f,sizeof dp);
	cin>>T;
	while(T--){
		cin>>n;
		for(int i=1;i<=n;i++) cin>>a[i];
		for(int i=1;i<=n;i++) cin>>b[i];
		a[0]=a[n+1]=c[0]=c[n+1]=1;
		for(int i=1;i<=n;i++){
			c[i]=lcm(__gcd(a[i],a[i-1]),__gcd(a[i],a[i+1]));
			if(c[i]>b[i]) c[i]=a[i];
		}
		dp[1][0]=(c[1]!=a[1]&&c[1]<=b[1]);
		for(int i=1;i<=20;i++){
			int x=c[1]*pri[i];
			if(x<=b[1]&&x!=a[1]&&__gcd(x,c[2])==__gcd(a[1],a[2])) dp[1][i]=1;
		}
//		for(int i=1;i<=n;i++){
//			cout<<c[i]<<" ";
//		}
//		cout<<'\n';
//		for(int i=0;i<=20;i++){
//			cout<<dp[1][i]<<" ";
//		}
//		cout<<'\n';
		for(int i=2;i<=n;i++){
			for(int j=0;j<=20;j++){
				int x=c[i-1]*pri[j];
				if(__gcd(c[i],x)==__gcd(a[i],a[i-1])){
					dp[i][0]=max(dp[i][0],dp[i-1][j]+(c[i]!=a[i]));
				}
				for(int k=1;k<=20;k++){
					int y=c[i]*pri[k];
					if(__gcd(y,x)==__gcd(a[i],a[i-1])&&__gcd(y,c[i+1])==__gcd(a[i],a[i+1])&&y!=a[i]){
						if(y<=b[i]) dp[i][k]=max(dp[i][k],dp[i-1][j]+1);
					}
				}
			}
//			for(int j=0;j<=20;j++){
//				cout<<dp[i][j]<<" ";
//			}
//			cout<<'\n';
		}
		int ans=0;
		for(int i=0;i<=20;i++) ans=max(ans,dp[n][i]);
		cout<<ans<<'\n';
		for(int i=1;i<=n;i++){
			a[i]=b[i]=c[i]=0;
			for(int j=0;j<=20;j++){
				dp[i][j]=-1e18;
			}
		}
	}
	return "LEWISAK 打 CF——一个愿打一个愿挨";
}
}
namespace ZheDaoTiShi{bool ed;double kj(){return (&st-&ed)/1048576.0;}}
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cerr<<ZaiJiaXieDe::main()<<"\nuseMB:"<<ZheDaoTiShi::kj();
}
/*
1
6
3 5 2 4 2 5 
2 2 1 1 2 1 
*/