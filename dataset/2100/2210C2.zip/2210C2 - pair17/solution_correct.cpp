#include <iostream>
#include <algorithm>
#include <cstring>
#include <iomanip>
#include <vector>
#include <stack>
#include <queue>
#include <cmath>
#include <bitset>
#include <set>
#include <map>
#define int long long
using namespace std;

const int N = 1e5 + 10;
typedef pair<int,int> PII;
using ll = long long;
int p[22] = {1,2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73};

ll lcm(ll a, ll b)
{
    return a * b / __gcd(a,b);
}

void solve()
{
    int n;
    cin >> n;
    vector<int> a(n+10),b(n+10),c(n+10);
    for (int i = 1 ; i <= n ; i++) cin >> a[i];
    for (int i = 1 ; i <= n ; i++) cin >> b[i];
    a[0] = a[n+1] = 1;

    for (int i = 1; i <= n ; i++)
    {
        int g1 = __gcd(a[i-1],a[i]);
        int g2 = __gcd(a[i],a[i+1]);
        if (lcm(g1,g2) > b[i]) c[i] = b[i] = a[i];
        else c[i] = lcm(g1,g2);
    }

    // for (int i = 1 ; i <= n ; i++) cout << c[i] << " ";
    // cout << endl;

    vector<vector<int>> dp(n+10,vector<int>(30));
    for (int i = 0 ; i < 22 ; i++)
    {
        if (c[1]*p[i] > b[1]) break;
        if (c[1]*p[i] != a[1]) dp[1][i] = 1;
    }
    for (int i = 2 ; i <= n ; i++)
    {
        for (int j = 0 ; j < 22 ; j++)
        {
            if (c[i]*p[j] > b[i]) break;
            for (int k = 0 ; k < 22 ; k++)
            {
                if (c[i-1]*p[k] > b[i-1]) break;
                ll t1 = c[i] * p[j];
                ll t2 = c[i-1] * p[k];
                if (__gcd(t1,t2) != __gcd(a[i],a[i-1])) continue;
                dp[i][j] = max(dp[i][j],dp[i-1][k]+(c[i]*p[j] != a[i]));
            }
        }
    }

    int ans = 0;
    for (int i = 0 ; i < 22 ; i++) ans = max(ans,dp[n][i]);
    cout << ans << endl;
}

signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int T = 1;
    cin >> T;
    while (T--) solve();

    return 0;
}