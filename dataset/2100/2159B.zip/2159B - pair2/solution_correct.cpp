#include <bits/stdc++.h>
using namespace std;

#define sz(x) ((int)(x).size())
#define all(x) (x).begin(), (x).end()
// #define int long long
using ll = long long;

signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int tt;
    cin >> tt;
    while (tt--)
    {
        int n, m;
        cin >> n >> m;
        vector<string> a(n);
        for (int i = 0; i < n; i++)
            cin >> a[i];

        bool f = false;
        if (n > m)
        {
            f = true;
            vector<string> b(m, string(n, '0'));
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    b[j][i] = a[i][j];
                }
            }
            a = b;
            swap(n, m);
        }
        vector<vector<int>> dp(n, vector<int>(m, INT_MAX));

        for (int i = 0; i < n; i++)
        {
            for (int j = i + 1; j < n; j++)
            {
                int l = -1;
                for (int r = 0; r < m; r++)
                {
                    if (a[i][r] == '1' && a[j][r] == '1')
                    {
                        if (l == -1)
                        {
                            l = r;
                            continue;
                        }

                        int area = (r - l + 1) * (j - i + 1);
                        for (int k = l; k <= r; k++)
                            dp[j][k] = min(dp[j][k], area);
                        l = r;
                    }
                }
            }
            for (int j = n - 2; j >= i; j--)
            {
                for (int k = 0; k < m; k++)
                {
                    dp[j][k] = min(dp[j + 1][k], dp[j][k]);
                }
            }
        }
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
            {
                if (dp[i][j] == INT_MAX)
                    dp[i][j] = 0;
            }
        }
        if (f)
        {
            vector<vector<int>> dp2(m, vector<int>(n));
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    dp2[j][i] = dp[i][j];
                }
            }
            dp = dp2;
            swap(n, m);
        }
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < m; j++)
            {
                cout << dp[i][j] << " ";
            }
            cout << endl;
        }
    }
    return 0;
}