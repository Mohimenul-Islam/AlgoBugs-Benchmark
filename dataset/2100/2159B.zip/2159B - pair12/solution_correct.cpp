#include<bits/stdc++.h>
#include <ext/pb_ds/tree_policy.hpp>
#include <ext/pb_ds/assoc_container.hpp>
using namespace std;
using namespace __gnu_pbds;
// #define int long long
typedef tree<pair<int,int>, null_type, less<pair<int,int>>, rb_tree_tag, tree_order_statistics_node_update> pbds; // find_by_order, order_of_key
typedef unsigned long long ull;
typedef long double lld;

#ifdef ONLINE_JUDGE
#define debug(x) ;
#else
#define debug(x) cerr << #x <<" "; _print(x); cerr << endl;
#endif
 
#define ff              first
#define ss              second
#define pb              push_back
#define ppb             pop_back
#define mp              make_pair
#define pii             pair<int,int>
#define vi              vector<int>
#define mii             map<int,int>
#define pqb             priority_queue<int>
#define pqs             priority_queue<int,vi,greater<int> >
#define setbits(x)      __builtin_popcountll(x)
#define zrobits(x)      __builtin_ctzll(x)
#define mod             1000000007
#define mod1            998244353
#define inf             1e9
#define nline           "\n"
#define PI              3.141592653589793238462
#define sz(x)           ((int)(x).size())
#define all(x)          (x).begin(), (x).end()
#define rall(x)          (x).rbegin(), (x).rend()
#define ps(x,y)         fixed<<setprecision(y)<<x
#define mk(arr,n,type)  type *arr=new type[n];
#define w(x)            int x; cin>>x; while(x--)
#define endl            "\n"

void _print(int t) {cerr << t;}
void _print(string t) {cerr << t;}
void _print(char t) {cerr << t;}
void _print(lld t) {cerr << t;}
void _print(double t) {cerr << t;}
void _print(ull t) {cerr << t;}

template <class T, class V> void _print(pair <T, V> p);
template <class T> void _print(vector <T> v);
template <class T> void _print(set <T> v);
template <class T, class V> void _print(map <T, V> v);
template <class T> void _print(multiset <T> v);
template <class T, class V> void _print(pair <T, V> p) {cerr << "{"; _print(p.ff); cerr << ","; _print(p.ss); cerr << "}";}
template <class T> void _print(vector <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(set <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(multiset <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T, class V> void _print(map <T, V> v) {cerr << "[ "; for (auto i : v) {_print(i); cerr << " ";} cerr << "]";}

void c_p_c()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
}

// static bool comp(pii &a,pii&b){
//     return (a.first<b.first);
// }
vector<vi>trans(vector<vi>&a,int n,int m){
    vector<vi>b(m+1,vi(n+1,0));
    for(int j=1;j<=m;j++){
        for(int i=1;i<=n;i++){
            b[j][i]=a[i][j];
        }
    }
    return b;
}
int32_t main()
{
    c_p_c();
    w(t){
        int n,m;cin>>n>>m;
        vector<vi>a(n+1,vi(m+1,0));
        for(int i=1;i<=n;i++){
            for(int j=1;j<=m;j++){
                char c;cin>>c;
                if(c=='1'){
                    a[i][j]=1;
                }
                else{
                    a[i][j]=0;
                }
            }
        }
        int flag=0;
        if(n>m){
            flag=1;
            a=trans(a,n,m);
            swap(n,m);
        } 
        //we will create m dp's all range dps
        vector<vector<vi>>dp(m+1,vector<vi>(n+1,vi(n+2,inf)));
        //dp[j][i][k]-> jth col me i se k rows wali cells ke liye min area
        //could also use m segment trees but time complexity increases by logn and space decreases.
        for(int i=1;i<=n;i++){
            for(int j=n;j>=i;j--){
                //i aur j rows
                for(int k=1;k<=m;k++){
                    dp[k][i][j]=min({dp[k][i][j],dp[k][i-1][j],dp[k][i][j+1]});
                }
                if(i==j)break;
                vi col;
                for(int k=1;k<=m;k+=1){
                    if(a[i][k] && a[j][k]){
                        col.pb(k);
                    }
                }
                for(int k=0;k<sz(col)-1;k++){
                    int j1=col[k];
                    int j2=col[k+1];
                    int area=(j2-j1+1)*(j-i+1);
                    for(int k1=j1;k1<=j2;k1++){
                        dp[k1][i][j]=min(dp[k1][i][j],area);
                    }
                }
            }
        }
        vector<vi>ans(n+1,vi(m+1,0));
        for(int i=1;i<=n;i++){
            for(int j=1;j<=m;j++){
                ans[i][j]=(dp[j][i][i]==inf)?0:dp[j][i][i];
            }
        }
        if(flag){
            ans=trans(ans,n,m);
            swap(n,m);
        }
        for(int i=1;i<=n;i++){
            for(int j=1;j<=m;j++){
                cout<<ans[i][j]<<" ";
            }
            cout<<endl;
        }
    }
    return 0;
}

