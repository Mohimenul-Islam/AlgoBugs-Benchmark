// --------------------------------------------------
// | B. Rectangles | Codeforces - Codeforces Round 1058 (Div. 1)
// | https://codeforces.com/contest/2159/problem/B
// | 2026/03/12 10:21:10 | @SalemAli
// | 4000ms / 1024MB
// --------------------------------------------------
#include <bits/stdc++.h>
using namespace std;
// #define int long long
#define pb push_back
#define all(x) x.begin(), x.end()
#define all2(x) (x).rbegin(), (x).rend()
typedef int ll; 
typedef map<int, int> mpi;
typedef vector<int> vi;
typedef vector<ll> vll;
const int inf=1e8;

void solve(){
	int n,m;
	cin>>n>>m;
	vector<string>s(n);
	for(int i=0; i<n;i++)cin>>s[i];
	int rv=0;
	if(n>m){
		rv=1;
		vector<string> t(m, string(n, ' '));
	        for(int i = 0; i < n; i++) {
	            for(int j = 0; j < m; j++) {
	                t[j][i] = s[i][j];
	            }
	        }
	        s = t;
	        swap(n, m);
	}
	vector<vi> cols(n);
	for (int i = 0; i < n; i++) {
	        for (int j = 0; j < m; j++) {
	            if (s[i][j] == '1')  cols[i].pb(j);
	        }
	}
	
	function<void(int, int,vi&)> get = [&](int a, int b,vi&c) {
	        c.clear(); 
	        int i = 0, j = 0;
                while(i < (int)cols[a].size() && j < (int)cols[b].size()) {
                    if (cols[a][i] == cols[b][j]) {
                        c.pb(cols[a][i]);
                        i++; j++;
                    } else if (cols[a][i] < cols[b][j]) {
                        i++;
                    } else {
                        j++;
                    }
                }  
	};
	
	vector<vi>dp(n+1,vi(m,inf));
	vector<vi>ndp(n+1,vi(m,inf));
	vi cl;
	
	for(int ln=n;ln>=2;ln--){
		for(int d=0;d<=n-ln+1;d++){
			fill(all(ndp[d]), inf);
		}
		
		for(int d=0;d<=n-ln;d++){
			int w=d+ln-1;
			get(d,w,cl);
			for(int k=0;k+1<(int)cl.size();k++){
				int l=cl[k];
				int r=cl[k+1];
				int area = (r-l+1)* ln;
				for(int i=l;i<=r;i++)dp[d][i]=min(dp[d][i],area);
			}
			for(int i=0;i<m;i++){
				ndp[d][i]=min(ndp[d][i],dp[d][i]);
				ndp[d+1][i]=min(ndp[d+1][i],dp[d][i]);
			}
		}
		dp.swap(ndp);
	}
	
	if(rv){
		for(int j=0;j<m;j++){
			for(int i=0;i<n;i++){
				cout<<(dp[i][j]>=inf?0:dp[i][j])<<" ";
			}
			cout<<"\n";
		}
	}else{
		for(int i=0;i<n;i++){
			for(int j=0;j<m;j++){
				cout<<(dp[i][j]>=inf?0:dp[i][j])<<" ";
			}
			cout<<"\n";
		}
	}
}

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);cout.tie(NULL);
    int t=1;
    cin>>t;
    while(t--)
        solve();
    return 0;
}