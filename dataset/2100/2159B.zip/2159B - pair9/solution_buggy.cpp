#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#pragma GCC optimize("unroll-loops")
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef pair<int,int> pi;
typedef pair<ll,ll> pl;
char x[1<<18];
vi a[1<<18];
vi b[501][501],r[1<<18];
int dq[1<<18];
void f(int n,int m,int k)
{
    // r[x][k]를 채우기, given b[x][y][k]
    //int fr=1,en=0;
    //deque<int> dq;
    for(int x=n-1;x>=1;x--)
    {
        int fr=1,en=0;
        for(int i=1;i<=n;i++)
        {
            if(i+x<=n)
            {
                while(fr<=en&&b[dq[en]][dq[en]+x][k]>=b[i][i+x][k])
                {
                    dq[en]=0;
                    en--;
                }
                en++;
                dq[en]=i;
            }
            r[i][k]=min(r[i][k],b[dq[fr]][dq[fr]+x][k]);
            if(dq[fr]+x==i)fr++;
        }
    }
}
void solve()
{
    int n,m;cin>>n>>m;
    bool sw=false;
    for(int i=1;i<=max(n,m);i++)
    {
        a[i].push_back(0);
        r[i].push_back(0);
    }
    for(int i=1;i<=n;i++)
    {
        cin>>x;
        if(n<=m)
        {
            for(int j=1;j<=m;j++)
            {
                a[i].push_back((x[j-1]-'0'));
                r[i].push_back((1<<30));
            }
        }
        else
        {
            for(int j=1;j<=m;j++)
            {
                a[j].push_back((x[j-1]-'0'));
                r[j].push_back((1<<30));
            }
        }
    }
    if(n>m)
    {
        swap(n,m);
        sw=true;
    }
    
    // calc b
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            for(int k=0;k<=m;k++)b[i][j].push_back((1<<30));
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=i+1;j<=n;j++)
        {
            vi v;
            for(int k=1;k<=m;k++)
            {
                if(a[i][k]==1&&a[j][k]==1)
                {
                    v.push_back(k);
                }
            }
            int t=v.size();
            for(int k=1;k<t;k++)
            {
                for(int l=v[k-1];l<=v[k];l++)b[i][j][l]=min(b[i][j][l],(j-i+1)*(v[k]-v[k-1]+1));
            }
        }
    }
    // calc r
    for(int i=1;i<=m;i++)
    {
        f(n,m,i);
    }
    
    // print output, init
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            while(!b[i][j].empty())b[i][j].pop_back();
        }
    }
    if(sw)
    {
        for(int i=1;i<=m;i++)
        {
            for(int j=1;j<=n;j++)
            {
                if(r[j][i]==(1<<30))cout<<"0 ";
                else cout<<r[j][i]<<' ';
            }
            cout<<'\n';
        }
    }
    else
    {
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=m;j++)
            {
                if(r[i][j]==(1<<30))cout<<"0 ";
                else cout<<r[i][j]<<' ';
            }
            cout<<'\n';
        }
    }
    for(int i=1;i<=max(n,m);i++)
    {
        while(!a[i].empty())a[i].pop_back();
        while(!r[i].empty())r[i].pop_back();
    }
}
int main()
{
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int tc=1;
    cin>>tc;
    for(int i=1;i<=tc;i++)
    {
        solve();
    }
}