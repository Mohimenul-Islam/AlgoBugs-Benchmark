#include <bits/stdc++.h>
using namespace std;
 
#define ll long long
#define f(i,c,n) for(int i=c;i<n;i++)
#define all(x) x.begin(),x.end()
#define pb push_back
#define int ll
#define pii pair<int,int>
#define vi vector<int>
#define vii vector<pii>
int powmod(int base,int exp,int mod=-1){
  int result=1;
  while(exp>0){
      if(exp%2==1){
          result=(mod==-1)?result*base:(result*base)%mod;
      }
      base=(mod==-1)?base*base:(base*base)%mod;
      exp/=2;
  }
  return result;
}


int INF=1e9+7;

void solve(int n,int m,vector<string>& a,vector<vi>& ans){
    vector<vector<array<int,3>>> rect(m);
    
    f(i,0,n){
        f(j,i+1,n){
            vi both(m,0);
            f(k,0,m){
                if(a[i][k]=='1'&&a[j][k]=='1') both[k]=1;
            }
            // if(i==0 && j==1) for(auto el:both) cout<<el<<" ";cout<<'\n';
            int p=-1;
            f(k,0,m){
                if(both[k]==1){
                    if(p==-1) p=k;
                    else{
                        rect[p].pb({i,j,k});
                        p=k;
                    }
                }
            }
        }
    }
    vector<vii> curr(n,vii(n,{INF,0}));
    f(j,0,m){
            // if(j==2){
            //     f(i,0,n){
            //         f(j,0,n){
            //             cout<<i<<" "<<j<<" "<<curr[i][j].first<<" "<<curr[i][j].second<<'\n';
            //         }
            //     }
            // }
        vector<vi> dp(n,vi(n,INF)); // initialize dp
        f(i,0,n){
            f(k,0,n) dp[i][k]=curr[i][k].first;
        }
        for(int l=n;l>=1;l--){ // for ending ones
            for(int i=0;i+l-1<n;i++){
                if(i!=0) dp[i][l+i-1]=min(dp[i][l+i-1],dp[i-1][l+i-1]);
                if(l+i!=n) dp[i][l+i-1]=min(dp[i][l+i-1],dp[i][l+i]);
            }
        }
        f(i,0,n) ans[i][j]=dp[i][i]; //update
        f(i,0,n){ // end the ending ones
            f(k,0,n){
                if(curr[i][k].second==j) curr[i][k]={INF,0};
            }
        }
        //include new rec for curr l
        for(auto el:rect[j]) curr[el[0]][el[1]]={(el[2]-j+1)*(el[1]-el[0]+1),el[2]};
        // initialise dp again

        f(i,0,n){
            f(k,0,n) dp[i][k]=curr[i][k].first;
        }
        for(int l=n;l>=1;l--){
            for(int i=0;i+l-1<n;i++){
                if(i!=0) dp[i][l+i-1]=min(dp[i][l+i-1],dp[i-1][l+i-1]);
                if(l+i!=n) dp[i][l+i-1]=min(dp[i][l+i-1],dp[i][l+i]);
            }
        }
        f(i,0,n) ans[i][j]=min(ans[i][j],dp[i][i]);
    }

    //for(auto el:ans){ {for(auto ell:el) cout<<ell%INF<<" ";} cout<<'\n';}
}

void solve(){
    int n,m;cin>>n>>m;
    int flg=0;
    if(n>m){ flg=1; swap(n,m);}
    vector<string> a(n);
    if(flg){
        f(i,0,m){
            string s;cin>>s;
            f(j,0,n) a[j].push_back(s[j]);
        }
    }
    else{
        f(i,0,n) cin>>a[i];
    }
    vector<vi> ans(n,vi(m,INF));
    solve(n,m,a,ans);
    if(flg){
        f(j,0,m){
            f(i,0,n) cout<<ans[i][j]%INF<<" ";
            cout<<'\n';
        }
    }
    else for(auto el:ans){ {for(auto ell:el) cout<<ell%INF<<" ";} cout<<'\n';}
}
 
int32_t main(){
    ios::sync_with_stdio(0); cin.tie(0);
    int t; cin>>t;
    while(t--){
        solve();
    }
}