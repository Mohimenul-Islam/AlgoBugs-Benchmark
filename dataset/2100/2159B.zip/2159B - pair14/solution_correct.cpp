#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define F first
#define S second
#define pb push_back
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<pii> vp;
typedef vector<ll> vl;
typedef vector<vi> vvi;
typedef vector<vp> vvp;

template <class T1, class T2> istream& operator>>(istream &in, pair<T1, T2> &p) { return in >> p.F >> p.S; }
template <class T1, class T2> ostream& operator<<(ostream &out, const pair<T1, T2> &p) { return out << p.F << " " << p.S; }
 
template <class T> istream& operator>>(istream &in, vector<T> &a) { for (T &i : a) in >> i; return in; }
template <class T> void print(const vector<T> &a, const string &s = " ") { for (int i = 0; i < sz(a); i++) cout << a[i] << (i == sz(a) - 1 ? "\n" : s); }

const int inf = 1e8;

void solve() {
    int n, m;cin>>n>>m;
    int nn = n, mm = m;

    vvi grid(n, vi(m));
    rep(i,0,n){
        string s;cin>>s;
        rep(j,0,m){
            grid[i][j]=s[j]-'0';
        }
    }

    if (n > m) {
        swap(n, m);
        vvi new_grid(n, vi(m));
        rep(i,0,n) {
            rep(j,0,m) {
                new_grid[i][j] = grid[j][i];
            }
        }
        grid = new_grid;
    }

    vector<vvi> dp(m, vvi(n, vi(n, inf)));
    rep(u,0,n) {
        rep(d,u+1,n) {
            vi matches;
            rep(i,0,m){
                if(grid[u][i] & grid[d][i]) {
                    matches.pb(i);
                }
            }
            rep(i,0,sz(matches)-1) {
                rep(c,matches[i], matches[i+1]+1) {
                    dp[c][u][d] = min(dp[c][u][d], (d - u + 1) * (matches[i + 1] - matches[i] + 1));
                }
            }
        }
    }
    rep(c,0,m){
        rep(u,0,n){
            for(int d = n - 1; d >= 0; d--) {
                if (u > 0) {
                    dp[c][u][d] = min(dp[c][u][d], dp[c][u-1][d]);
                }
                if (d < n - 1) {
                    dp[c][u][d] = min(dp[c][u][d], dp[c][u][d + 1]);
                }
            }
        }
    }

    vvi ans(n, vi(m));

    rep(i,0,n){
        rep(j,0,m){
            if (dp[j][i][i] != inf) {
                ans[i][j] = dp[j][i][i];
            } else {
                ans[i][j] = 0;
            }
        }
    }

    if(nn > mm) {
        vvi tans(m, vi(n));
        rep(i,0,m){
            rep(j,0,n){
                tans[i][j] = ans[j][i];
            }
        }
        ans = tans;
    }

    for(auto &r:ans)print(r);
}

signed main() {
    cin.tie(0)->sync_with_stdio(0);
    cin.exceptions(cin.failbit);

    int t;cin>>t;
    while(t--){
        solve();
    }
}
