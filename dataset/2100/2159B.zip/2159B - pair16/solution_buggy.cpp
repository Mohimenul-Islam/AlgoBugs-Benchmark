#include <bits/stdc++.h>

using namespace std;
const int MAX = 500;
const int INF = 1e9;
char mr[MAX * MAX];
int rez[MAX * MAX], minr[MAX * MAX];
int n, m;
int minim(int a, int b) {
    return a < b ? a : b;
}
int get(int l, int c) {
    return m * l + c;
}
int main()
{
    //fac o baleiere de linii si pentru 2 linii fixate
    //vad cea mai apropiata coloana cu 1 pe l si pe l2 din stanga si din dreapta pt fiecare coloana
    //sau doar tin coloanele cu 1 pe l si pe l2 si intre fiecare pereche actualizez minimul
    //dar o data ce fixez l cu l2 merg descrescator ca sa pot actualiza in O(1) aria minima de pe fiecare celula
    //O(n^2 * m) si intorc matricea daca n > m ca sa am maxim O(n * m * sqrt(n * m))
    //daca ar fi cerut aria maxima as fi actualizat maximul intre prima si ultima coloana cu 1 pe l si pe l2
    int t1, i1, l, c, l2, pr, x, rot;
    scanf("%d", &t1);
    for (i1 = 0; i1 < t1; i1++) {
        scanf("%d%d", &n, &m);
        rot = 0;
        if (n >= 0) {
            for (l = 0; l < n; l++) {
                scanf(" ");
                for (c = 0; c < m; c++) {
                    mr[get(l, c)] = fgetc(stdin) - '0';
                    rez[get(l, c)] = INF;
                }
            }
        } else {
            rot = 1;
            //rotesc spre dreapta la 90 de grade
            for (l = 0; l < n; l++) {
                scanf(" ");
                for (c = 0; c < m; c++) {
                    mr[get(c, n - 1 - l)] = fgetc(stdin) - '0';
                    rez[get(c, n - 1 - l)] = INF;
                }
            }
            swap(n, m);
        }
        for (l = 0; l < n; l++) {
            for (c = 0; c < m; c++) {
                minr[c] = INF;
            }
            for (l2 = n - 1; l2 > l; l2--) {
                pr = -1;
                for (c = 0; c < m; c++) {
                    if (mr[get(l, c)] + mr[get(l2, c)] == 2) {
                        if (pr >= 0) {
                            x = (l2 - l + 1) * (c - pr + 1);
                            for (; pr <= c; pr++) {
                                minr[pr] = minim(minr[pr], x);
                            }
                        }
                        pr = c;
                    }
                }

                for (c = 0; c < m; c++) {
                    rez[get(l2, c)] = minim(rez[get(l2, c)], minr[c]);
                }
            }
            for (c = 0; c < m; c++) {
                rez[get(l, c)] = minim(rez[get(l, c)], minr[c]);
            }
        }
        for (l = 0; l < n; l++) {
            for (c = 0; c < m; c++) {
                if (rez[get(l, c)] == INF) {
                    rez[get(l, c)] = 0;
                }
            }
        }
        if (rot > 0) {
            //rotesc la cea originala
            for (c = m - 1; c >= 0; c--) {
                for (l = 0; l < n; l++) {
                    printf("%d ", rez[get(l, c)]);
                }
                printf("\n");
            }
        } else {
            for (l = 0; l < n; l++) {
                for (c = 0; c < m; c++) {
                    printf("%d ", rez[get(l, c)]);
                }
                printf("\n");
            }
        }
    }
    return 0;
}
