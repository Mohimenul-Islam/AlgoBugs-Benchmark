#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
using namespace __gnu_pbds;
using namespace std;
#define ll long long
#define ld double
const ll mod = 1e9+7;
const ll inf = 1e18;
typedef tree<ll, null_type, less<ll>, rb_tree_tag, tree_order_statistics_node_update> indexed_set;
typedef tree<ll, null_type, less_equal<ll>, rb_tree_tag, tree_order_statistics_node_update> indexed_multiset;
mt19937_64 rng(chrono::system_clock::now().time_since_epoch().count());

void solve(){
    ll n,m;
    cin>>n>>m;
    vector<vector<bool>> v(n, vector<bool>(m));
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            char c;
            cin>>c;
            if(c=='1')v[i][j] = true;
        }
    }
    bool f =false;
    if(n>m){
        f=true;
        vector v1(m,vector<bool>(n));
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                v1[i][j] =v[j][i];
            }
        }
        swap(v,v1);
        swap(n,m);
    }
    vector val(n,vector(n,vector<int>(m,mod)));
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            int last = -1;
            for(int k=0;k<m;k++){
                if(v[i][k] && v[j][k]){
                    if(last != -1){
                        int area = (k-last+1)*(j-i+1);
                        for(int k1=k;k1>=last;k1--){
                            val[i][j][k1] = min(val[i][j][k1], area);
                        }
                    }
                    last = k;
                }
            }
        }
    }

    for(int sz = n-1;sz>0;sz--){
        for(int i=0;i+sz<n;i++){
            for(int j=0;j<m;j++){
                val[i][i+sz-1][j] = min(val[i][i+sz-1][j], val[i][i+sz][j]);
                val[i+1][i+sz][j] = min(val[i+1][i+sz][j], val[i][i+sz][j]);
            }
        }
    }

    if(!f){
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                cout<<(val[i][i][j]%mod)<<" ";
            }
            cout<<"\n";
        }
    }
    else{
        for(int j=0;j<m;j++){
            for(int i=0;i<n;i++){
                cout<<(val[i][i][j]%mod)<<" ";
            }
            cout<<"\n";
        }
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    ll t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
    return 0;
}
