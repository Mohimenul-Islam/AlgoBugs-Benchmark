#include "bits/stdc++.h"
using namespace std;

// #pragma GCC optimize("O3,unroll-loops")
// #pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")

#define int long long
#define dub long double
typedef vector<int> vint;
typedef vector<string> vstr;
typedef pair<int,int> pii;
typedef vector<pii> vii;
typedef unordered_map<int,int> umap;
#define rep(i,j,k) for(int i=j;i<k;i++)
#define all(a) a.begin(),a.end()
#define endl '\n'
#define INF 2147483647
//#define INF 9223372036854775807
#define null '\0'
const int N = 1e5 + 10, Mod = 1e9 + 7;
int n,m;
void solve(){
    cin >> n >> m;
    bool flag = false;
    vstr v(n);
    rep(i,0,n) cin >> v[i];
    vector<vint> dp(min(n,m) + 10, vint(min(n,m) + 10)), left , right = left = dp;
    if (n > m)
    {
        flag = true;
        vstr av(m, string('?', n+2));
        rep(i,0,n) rep(j,0,m) av[j][i] = v[i][j];
        v = av;
        swap(n,m);
    }

    vector<vint> ans(n+2, vint(m+2));
    rep(l, 0, n) rep(r,0,n) left[l][r] = 0, right[l][r] = -1;
    rep(j,0,m)
    {
        rep(l,0,n) rep(r,l,n) dp[l][r] = INF;

        rep(l,0,n)
        {
            rep(r,l+1,n)
            {
                if (left[l][r] <= j and right[l][r] >= j)
                    dp[l][r] = min(dp[l][r], (right[l][r] - left[l][r] + 1) * (r - l + 1));

                if (v[l][j] == '1' and v[r][j] == '1')
                {
                    left[l][r] = j;
                    int next = j + 1;
                    while ((v[l][next] != '1' or v[r][next] != '1') and next < m) next++;
                    if (next == m) right[l][r] = -1;
                    else right[l][r] = next;
                }

                if (left[l][r] <= j and right[l][r] >= j)
                    dp[l][r] = min(dp[l][r], (right[l][r] - left[l][r] + 1) * (r - l + 1));
            }
        }
        for (int len = n; len > 0; len--)
        {
            for (int i = 0;i + len - 1 < n; i++)
            {
                int l = i, r = i + len - 1;
                if (r < n - 1)
                    dp[l][r] = min(dp[l][r] , dp[l][r+1]);
                if (l)
                    dp[l][r] = min(dp[l][r] , dp[l-1][r]);
            }
        }
        rep(i,0,n) ans[i][j] = dp[i][i];
    }
    if (flag)
    {
        rep(j,0,m)
        {
            rep(i,0,n) cout << (ans[i][j] == INF ? 0 : ans[i][j]) << " ";
            cout << endl;
        }
    }
    else
    {
        rep(i,0,n)
        {
            rep(j,0,m) cout << (ans[i][j] == INF ? 0 : ans[i][j]) << " ";
            cout << endl;
        }
    }
}
signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int test_n = 1;
    cin>>test_n;
    for(int t_c = 1;t_c <= test_n;t_c ++){
        // cout << "Case " << t_c <<": ";
        solve();
    }
    return 0;
}