#include<bits/stdc++.h>
using namespace std;
int b[1000009],a[1000009],ans[1000009];
int main(){
	int t,n,m;
	cin>>t;
	while(t--){
		char c;
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				scanf(" %c",&c);
				b[i*(m+1)+j]=c-'0';
				ans[i*(m+1)+j]=1e9;
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=i;j<=n;j++){
				for(int k=1;k<=m;k++){
					a[j*(m+1)+k]=1e9;
				}
			}
			for(int j=i+1;j<=n;j++){
				int now=0;
				for(int k=1;k<=m;k++){
					if(b[i*(m+1)+k]==1&&b[j*(m+1)+k]==1){
						if(now!=0){
							for(int l=now;l<=k;l++){
								a[j*(m+1)+l]=min(a[j*(m+1)+l],(k-now+1)*(j-i+1));
							}
						}
						now=k;
					}
				}
			}
			for(int k=1;k<=m;k++){
				ans[n*(m+1)+k]=min(a[n*(m+1)+k],ans[n*(m+1)+k]);
			}
			for(int j=n-1;j>=i;j--){
				for(int k=1;k<=m;k++){
					a[j*(m+1)+k]=min(a[(j+1)*(m+1)+k],a[j*(m+1)+k]);
					ans[j*(m+1)+k]=min(a[j*(m+1)+k],ans[j*(m+1)+k]);
				}
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				if(ans[i*(m+1)+j]>=5e8)printf("0 ");
				else printf("%d ",ans[i*(m+1)+j]);
			}
			puts("");
		}
	}
	return 0;
}