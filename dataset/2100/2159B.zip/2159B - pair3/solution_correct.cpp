#include <bits/stdc++.h>
using namespace std;

#ifdef DEBUG
#include "debug.h"
#else
#define debug(...) 1
#endif

using ll = long long;
using db = long double;
using VS = vector<string>;
using VLL = vector<ll>;
using VVLL = vector<VLL>;
using VVVLL = vector<VVLL>;
using PLL = pair<ll, ll>;
using MLL = map<ll, ll>;
using SLL = set<ll>;
using QLL = queue<ll>;
using SS = stringstream;

#define rep(x, l, u) for (ll x = l; x < u; x++)
#define rrep(x, l, u) for (ll x = l; x >= u; x--)
#define fe(x, a) for (auto x : a)
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
#define mst(x, v) memset(x, v, sizeof(x))
#define sz(x) (ll) x.size()

#define umap unordered_map
#define uset unordered_set
#define mset multiset

// clang-format off

ll ob(ll i, ll n) { return i < 0 || i >= n; }
ll tp(ll x) { return ( 1LL << x ); }
ll rup(ll a, ll b) { return a % b ? a/b + 1 : a/b; }
ll sign(ll x) {	return x == 0 ? 0 : x / abs(x); }
void makemod(ll& x, ll m) { x %= m; if (x < 0) { x += m; } }
ll getmod(ll x, ll m) { makemod(x, m); return x; }
ll powmod(ll a, ll b, ll m) { if (b == 0) return 1; ll h = powmod(a, b/2, m); ll ans = h*h%m; return b%2 ? ans*a%m : ans; }
ll invmod(ll a, ll m) { return powmod(a, m - 2, m); }
void inll(ll& x) { scanf("%lld", &x); }

template <typename A, typename B> bool upmin(A& x, B v) { if (v >= x) return false; return x = v, true; }
template <typename A, typename B> bool upmax(A& x, B v) { if (v <= x) return false; return x = v, true; }

// clang-format on

const VLL di = {0, 0, 1, -1, 1, -1, 1, -1}, dj = {1, -1, 0, 0, -1, -1, 1, 1};
const ll mod = 1'000'000'007, mod2 = 998'244'353, inf = 1e9;
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());


void solve() {
    ll n, m;
    cin >> n >> m;
    vector<vector<int>> A(n, vector<int>(m));
    rep(i, 0, n) {
        string s;
        cin >> s;
        rep(j, 0, m) {
            A[i][j] = s[j] - '0';
        }
    }

    ll flipped = 0;
    if (n > m) {
        vector<vector<int>> B(m, vector<int>(n, 0));
        rep(i, 0, n) {
            rep(j, 0, m) {
                B[j][i] = A[i][j];
            }
        }
        swap(n, m);
        A = B;
        flipped = 1;
    }



    vector<vector<vector<int>>> dp(m, vector<vector<int>>(n, vector<int>(n, inf)));
    rep(i1, 0, n) {
        rep(i2, i1 + 1, n) {
            ll j1 = -inf;
            rep(j2, 0, m) {
                if (j1 != -inf && A[i1][j2] && A[i2][j2]) {
                    // rectangle
                    ll area = (i2 - i1 + 1) * (j2 - j1 + 1);

                    rep(jj, j1, j2 + 1) {
                        upmin(dp[jj][i1][i2], area);
                    }
                }

                if (A[i1][j2] && A[i2][j2]) {
                    j1 = j2;
                }
            }
        }
    }

    rep(j, 0, m) {
        rrep(len, n, 1) {
            rep(i1, 0, n) {
                ll i2 = i1 + len - 1;
                if (i2 >= n) {
                    break;
                }

                if (i2 + 1 < n) upmin(dp[j][i1][i2], dp[j][i1][i2 + 1]);
                if (i1 - 1 >= 0) upmin(dp[j][i1][i2], dp[j][i1 - 1][i2]);
            }
        }
    }

    if (flipped) {
        rep(j, 0, m) {
            rep(i, 0, n) {
                ll res = dp[j][i][i];
                if (res == inf) {
                    res = 0;
                }
                cout << res << " ";
            }
            cout << "\n";
        }
    } else {
        rep(i, 0, n) {
            rep(j, 0, m) {
                ll res = dp[j][i][i];
                if (res == inf) {
                    res = 0;
                }
                cout << res << " ";
            }
            cout << "\n";
        }
    }
}

int main() {
    ios_base::sync_with_stdio(0), cin.tie(0);

    ll t = 1;
    cin >> t;
    rep(i, 0, t) solve();
    return 0;
}
