#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
template<typename T> using vc = vector<T>;
#define f(i,a,b) for(int i=a;i<b;i++)
#define pb push_back
const ll INF = 1e9;

void solve(){
    int n, m;
    cin >> n >> m;
    vc<string> g(n);
    f(i, 0, n) cin >> g[i];
    
    bool swapped = (n > m);
    if(swapped){
        vc<string> tmp(m, string(n, '0'));
        f(i, 0, n)
            f(j, 0, m) tmp[j][i] = g[i][j];
        swap(n, m);
        g = tmp;
    }

    vc<vc<ll>> ans(n, vc<ll>(m, INF));
    vc<vc<int>> pos(m);
    f(j, 0, m)
        f(i, 0, n)
            if(g[i][j] == '1') pos[j].pb(i);
            
    vc<vc<int>> vec(n, vc<int>(n, -1)); 
    
    f(j, 0, m){
        auto &v = pos[j];
        f(a, 0, v.size())
            f(b, a + 1, v.size()){
                int u = v[a], d = v[b];
                if(vec[u][d] != -1){
                    int L = vec[u][d], R = j;
                    bool flag = 0;
                    for(int k = a + 1; k < b; k++){
                        if(g[v[k]][L] == '1'){
                            flag = 1;
                            break;
                        }
                    }
                    if(!flag){
                        int area = (d - u + 1) * (R - L + 1);
                        for(int i = u; i <= d; i++)
                            for(int k = L; k <= R; k++)
                                if(ans[i][k] > area) ans[i][k] = area;
                    }
                }
                vec[u][d] = j;
            }
    }
    
    if(swapped){
        vc<vc<ll>> tmp(m, vc<ll>(n, INF));
        f(i, 0, n)
            f(j, 0, m) tmp[j][i] = ans[i][j];
        ans = tmp;
        swap(n, m);
    }

    f(i, 0, n){
        f(j, 0, m){
            if(ans[i][j] == INF) cout << 0 << " ";
            else cout << ans[i][j] << " ";
        }
        cout << "\n";
    }
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin >> t;
    while(t--) solve();
    return 0;
}//cool prob:>