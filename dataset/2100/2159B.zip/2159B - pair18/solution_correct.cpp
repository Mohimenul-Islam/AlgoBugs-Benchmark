#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
template<typename T> using vc = vector<T>;
#define f(i,a,b) for(int i=a;i<b;i++)
#define pb push_back
const ll INF = 1e9;

void solve(){
    int n, m;
    cin >> n >> m;
    vc<string> g(n);
    f(i, 0, n) cin >> g[i];
    
    bool swapped = (n > m);
    if(swapped){
        vc<string> tmp(m, string(n, '0'));
        f(i, 0, n)
            f(j, 0, m) tmp[j][i] = g[i][j];
        swap(n, m);
        g = tmp;
    }

    vc<vc<ll>> ans(n, vc<ll>(m, INF));
    
    for(int u = 0; u < n; u++){
        for(int d = u + 1; d < n; d++){
            int l = -1;
            for(int j = 0; j < m; j++){
                if(g[u][j] == '1' && g[d][j] == '1'){
                    if(l != -1){
                        ll area = 1LL * (d - u + 1) * (j - l + 1);
                        for(int k = l; k <= j; k++){
                            if(ans[d][k] > area) ans[d][k] = area;
                        }
                    }
                    l = j;
                }
            }
        }
        for(int i = n - 2; i >= u; i--){
            for(int j = 0; j < m; j++){
                if(ans[i][j] > ans[i + 1][j]) ans[i][j] = ans[i + 1][j];
            }
        }
    }
    
    if(swapped){
        vc<vc<ll>> tmp(m, vc<ll>(n, INF));
        f(i, 0, n)
            f(j, 0, m) tmp[j][i] = ans[i][j];
        ans = tmp;
        swap(n, m);
    }

    f(i, 0, n){
        f(j, 0, m){
            if(ans[i][j] == INF) cout << 0 << " ";
            else cout << ans[i][j] << " ";
        }
        cout << "\n";
    }
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin >> t;
    while(t--) solve();
    return 0;
}
//cool prob:> 