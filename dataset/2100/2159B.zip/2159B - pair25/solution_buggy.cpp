#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef long double ld;
using vi = vector<int>;
using vvi = vector<vi>;
using vb = vector<bool>;
using vc = vector<char>;
using vvb = vector<vb>;
using vvc = vector<vc>;
using vl = vector<ll>;
using vvl = vector<vl>;
using ii = pair<int,int>;

template <typename T>
using vv = vector<vector<T>>;

const ll UNDEFINED = -1;
const int MOD = 998244353;
const int INF = 1e9;
const ll LINF = 1e18;
const ll zero = 0;
const ld EPSILON = 1e-10;
const double PI = acos(-1.0);

#define pb push_back
#define fst first
#define snd second
#define esta(x,c) ((c).find(x) != (c).end())  // Devuelve true si x es un elemento de c.
#define all(c) (c).begin(),(c).end()
#define SIZE(c) int((c).size())

#define DBG(x) cerr << #x << " = " << (x) << endl
#define RAYA cerr << "----------" << endl

#define forn(i,n) for (int i=0;i<(int)(n);i++)
#define forsn(i,s,n) for (int i=(s);i<(int)(n);i++)
#define dforn(i,n) for(int i=(int)((n)-1);i>=0;i--)
#define dforsn(i,s,n) for(int i=(int)((n)-1);i>=(int)(s);i--)

// Show pair
template <typename T1, typename T2>
ostream & operator <<(ostream &os, const pair<T1, T2> &p) {
    os << "{" << p.first << "," << p.second << "}";
    return os;
}

// Show vector
template <typename T>
ostream & operator <<(ostream &os, const vector<T> &v) {
    os << "[";
    forn(i, v.size()) {
        if (i > 0) os << ",";
        os << v[i];
    }
    return os << "]";
}

// Show set
template <typename T>
ostream & operator <<(ostream &os, const set<T> &s) {
    os << "{";
    for(auto it = s.begin(); it != s.end(); it++){
        if(it != s.begin()) os << ",";
        os << *it;
    }
    return os << "}";
}

// ############################################################### //

const int MAX_COLS = 500;

int currentPosFor[MAX_COLS+1][MAX_COLS+1];
int heightForCurrentRow[MAX_COLS+1][MAX_COLS+1];
int suffixDpForCurrentRow[MAX_COLS+1][MAX_COLS+1];
vi goodPositions[MAX_COLS+1][MAX_COLS+1];

int nRows, nCols;

void solve(){
	int n, m; cin >> n >> m;
	bool fueTraspuesta = false;
	vvc A(n, vc(m));
	forn(i, n) forn(j, m) cin >> A[i][j];
		
	if (n < m){
		fueTraspuesta = true;
		vvc B (m, vc(n));
		forn(i, n) forn(j, m) B[j][i] = A[i][j];
		A = B;
	}
		
	nRows = SIZE(A); nCols = SIZE(A[0]);

	forn(i, nCols) forsn(j, i+1, nCols){
		goodPositions[i][j].clear();
		forn(row, nRows) if (A[row][i] == A[row][j] && A[row][i] == '1') goodPositions[i][j].pb(row);
	}
	
	vvi res(nRows, vi(nCols, INF));

	forn(row, nRows){
		// Reset the things each time that you enter a new row
		forn(i, nCols) forn(j, nCols){
			currentPosFor[i][j] = 0;
			heightForCurrentRow[i][j] = INF;
			suffixDpForCurrentRow[i][j] = INF;
		}
		
		forn(leftCol, nCols){
			dforsn(rightCol, leftCol+1, nCols){
				int lastPos = SIZE(goodPositions[leftCol][rightCol]) - 1;
				int currentPos = currentPosFor[leftCol][rightCol];
				assert(leftCol < rightCol);
				while(currentPos < lastPos && !(goodPositions[leftCol][rightCol][currentPos] <= row && row <= goodPositions[leftCol][rightCol][currentPos+1])) currentPos++;
				if (currentPos >= lastPos) continue;
				int height = goodPositions[leftCol][rightCol][currentPos+1] - goodPositions[leftCol][rightCol][currentPos] + 1;
				if (currentPos+2 <= lastPos && goodPositions[leftCol][rightCol][currentPos+1] == row){
					height = min(height, goodPositions[leftCol][rightCol][currentPos+2] - goodPositions[leftCol][rightCol][currentPos+1] + 1);
				}
				
				heightForCurrentRow[leftCol][rightCol] = min(heightForCurrentRow[leftCol][rightCol], height);
			}
		}
		
		forn(leftCol, nCols){
			int width = nCols-leftCol;
			dforsn(rightCol, leftCol+1, nCols){
				if (rightCol+1 < nCols) suffixDpForCurrentRow[leftCol][rightCol] = min(suffixDpForCurrentRow[leftCol][rightCol], suffixDpForCurrentRow[leftCol][rightCol+1]);
				if (heightForCurrentRow[leftCol][rightCol] != INF) suffixDpForCurrentRow[leftCol][rightCol] = min(suffixDpForCurrentRow[leftCol][rightCol], width*heightForCurrentRow[leftCol][rightCol]);
				width--;
			}
		}
		
		// Calcular res con el sufijo
		forn(col, nCols) forn(leftCol, col+1){
			int minRightCol = max(col, leftCol+1);
			if (minRightCol == nCols) continue;
			assert(leftCol < minRightCol && minRightCol < nCols);
			res[row][col] = min(res[row][col], suffixDpForCurrentRow[leftCol][minRightCol]);
		}
	}
		 
	if (fueTraspuesta){ // Printear al reves
		forn(i, nCols){
			forn(j, nRows){
				int minFor = res[j][i]; // min en A[j][i]
				if (minFor >= INF) minFor = 0;
				cout << minFor << " ";
			}
			cout << "\n";
		}
	} else { // Printear normal
		forn(i, nRows){
			forn(j, nCols){
				int minFor = res[i][j]; // min en A[i][j]
				if (minFor >= INF) minFor = 0;
				cout << minFor << " ";
			}
			cout << "\n";
		}
	}
	
	RAYA;
}

int main()
{
    cin.tie(0);
    cin.sync_with_stdio(0);
	
	int t = 1; 
	cin >> t;
	forn(_, t) solve();
	
    return 0;
}
