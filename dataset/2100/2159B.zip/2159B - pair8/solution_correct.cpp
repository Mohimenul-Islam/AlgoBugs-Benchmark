#include <bits/stdc++.h>

using namespace std;

#ifndef ONLINE_JUDGE
#include "trace.cpp"
#else
#define dbg(...)
#endif

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define make_unique(x) sort(all((x))); (x).erase(unique(all((x))), (x).end())
#define take_graph(m) for (int i = 0, u, v; i < m; i++) {cin >> u >> v; --u, --v; g[u].push_back(v); g[v].push_back(u);}
#define int int64_t

void solve() {
  int n;
  cin >> n;
  int m;
  cin >> m;
  vector<vector<int>> g(n, vector<int>(m));
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      char ch; cin >> ch;
      g[i][j] = ch - '0';
    }
  }

  bool swapped = false;
  if (m > n) {
    swapped = true;
    vector<vector<int>> ng(m, vector<int>(n));
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < m; j++) {
        ng[j][i] = g[i][j];
      }
    }
    swap(n, m);
    swap(g, ng);
  }

  vector<vector<vector<int>>> down(m, vector<vector<int>>(m));
  for (int i = n - 1; i >= 0; --i) {
    for (int j1 = 0; j1 < m; j1++) {
      if (g[i][j1] == 0) continue;
      for (int j2 = j1 + 1; j2 < m; j2++) {
        if (g[i][j1] == 1 && g[i][j2] == 1) {
          down[j1][j2].push_back(i);
        }
      }
    }
  }

  vector<vector<int>> up(m, vector<int>(m, -1));
  vector<vector<int>> ans(n, vector<int>(m, 1e18));
  int dp[m][m];
  for (int i = 0; i < n; i++) {
    memset(dp, 0x3f, sizeof(dp));
    for (int j1 = 0; j1 < m; j1++) {
      for (int j2 = j1 + 1; j2 < m; j2++) {
        if (up[j1][j2] != -1 && down[j1][j2].size()) {
          int i1 = up[j1][j2];
          int i2 = down[j1][j2].back();
          int val = (i2 - i1 + 1) * (j2 - j1 + 1);
          dp[j1][j2] = min(dp[j1][j2], val);
        }

        if (g[i][j1] == 1 && g[i][j2] == 1) {
          up[j1][j2] = i;
          down[j1][j2].pop_back();
        }

        if (up[j1][j2] != -1 && down[j1][j2].size()) {
          int i1 = up[j1][j2];
          int i2 = down[j1][j2].back();
          int val = (i2 - i1 + 1) * (j2 - j1 + 1);
          dp[j1][j2] = min(dp[j1][j2], val);
        }
      }
    }

    for (int len = m - 1; len >= 1; --len) {
      for (int j = 0; j + len <= m; j++) {
        int j2 = j + len - 1;
        if (j) dp[j][j2] = min(dp[j][j2], dp[j - 1][j2]);
        if (j2 < m - 1) dp[j][j2] = min(dp[j][j2], dp[j][j2 + 1]);
      }
    }

    for (int j = 0; j < m; j++) {
      ans[i][j] = dp[j][j];
    }

  }

  if (swapped) {
    vector<vector<int>> nans(m, vector<int>(n));
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < m; j++) {
        nans[j][i] = ans[i][j];
      }
    }
    swap(n, m);
    swap(ans, nans);
  }  

  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      if (ans[i][j] > n * m) ans[i][j] = 0;
      cout << ans[i][j] << " \n"[j == m - 1];
    }
  }

}

int32_t main() {
  cin.tie(0) -> sync_with_stdio(0);
  int t; cin >> t;
  while (t--) solve();
  return 0;
}