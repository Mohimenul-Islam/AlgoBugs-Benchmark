#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define eb emplace_back
const int N=2.5e5+5;
const ll inf=1e18;
int T,n,m;
string s[N],s2[N];
vector<ll> tr[N],lz[N],ans[N];
int idx;
void down(int id,int l,int r){
	if(lz[idx][id]^inf){
		tr[idx][id<<1]=min(tr[idx][id<<1],lz[idx][id]);
		tr[idx][id<<1|1]=min(tr[idx][id<<1|1],lz[idx][id]);
		lz[idx][id<<1]=min(lz[idx][id<<1],lz[idx][id]);
		lz[idx][id<<1|1]=min(lz[idx][id<<1|1],lz[idx][id]);
		lz[idx][id]=inf;
	}
}
void up(int id){
	tr[idx][id]=min(tr[idx][id<<1],tr[idx][id<<1|1]);
}
void update(int id,int l,int r,int x,int y,ll k){
	if(x<=l&&r<=y){
		tr[idx][id]=min(tr[idx][id],k);
		lz[idx][id]=min(lz[idx][id],k);
		return;
	}
	down(id,l,r);
	int mid=(l+r)>>1;
	if(x<=mid)update(id<<1,l,mid,x,y,k);
	if(y>mid)update(id<<1|1,mid+1,r,x,y,k);
	up(id);
}
void query(int id,int l,int r){
	if(l==r)return ans[l][idx]=(tr[idx][id]^inf?tr[idx][id]:0),void();
	int mid=(l+r)>>1;
	down(id,l,r);
	query(id<<1,l,mid);
	query(id<<1|1,mid+1,r);
}
int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	cin>>T;
	while(T--){
		cin>>n>>m;
		int flag=0;
		if(n>m)swap(n,m),flag=1;
		for(int i=1;i<=n;i++)ans[i].resize(m+1);
		if(flag){
			for(int j=1;j<=m;j++)cin>>s2[j],s2[j]=" "+s2[j];
			for(int i=1;i<=n;i++){
				s[i]=" ";
				for(int j=1;j<=m;j++)s[i]+=s2[j][i];
			}
		}else{
			for(int i=1;i<=n;i++)cin>>s[i],s[i]=" "+s[i];
		}
		for(int i=1;i<=m;i++){
			tr[i].resize((n<<2)+1);
			lz[i].resize((n<<2)+1);
			for(int j=1;j<=(n<<2);j++)tr[i][j]=lz[i][j]=inf;
		}
		for(int i=1;i<n;i++){
			for(int j=i+1;j<=n;j++){
				int lst=0;
				for(int k=1;k<=m;k++){
					if(s[i][k]=='1'&&s[j][k]=='1'){
						if(lst){
							for(int l=lst;l<=k;l++)idx=l,update(1,1,n,i,j,(ll)(k-lst+1)*(j-i+1));
						}
						lst=k;
					}
				}
			}
		}
		for(int j=1;j<=m;j++){
			idx=j;query(1,1,n);
		}
		if(flag){
			for(int i=1;i<=m;i++){
				for(int j=1;j<=n;j++)cout<<ans[j][i]<<' ';
				cout<<'\n';
			}
		}else{
			for(int i=1;i<=n;i++){
				for(int j=1;j<=m;j++)cout<<ans[i][j]<<' ';
				cout<<'\n';
			}
		}
	}
	return 0;
}
