#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define eb emplace_back
const int N=2.5e5+5;
const ll inf=1e18;
int T,n,m;
ll bin[N];
string s[N],s2[N];
vector<ll> ans[N];
int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	cin>>T;
	while(T--){
		cin>>n>>m;
		int flag=0;
		if(n>m)swap(n,m),flag=1;
		for(int i=1;i<=n;i++){
			ans[i].resize(m+1);
			for(int j=1;j<=m;j++)ans[i][j]=inf;
		}
		if(flag){
			for(int j=1;j<=m;j++)cin>>s2[j],s2[j]=" "+s2[j];
			for(int i=1;i<=n;i++){
				s[i]=" ";
				for(int j=1;j<=m;j++)s[i]+=s2[j][i];
			}
		}else{
			for(int i=1;i<=n;i++)cin>>s[i],s[i]=" "+s[i];
		}
		for(int i=1;i<n;i++){
			for(int j=1;j<=m;j++)bin[j]=inf;
			for(int j=n;j>i;j--){
				int lst=0;
				for(int k=1;k<=m;k++){
					if(s[i][k]=='1'&&s[j][k]=='1'){
						if(lst){
							for(int l=lst;l<=k;l++)bin[l]=min(bin[l],(k-lst+1ll)*(j-i+1));
						}
						lst=k;
					}
				}
				for(int k=1;k<=m;k++)ans[j][k]=min(ans[j][k],bin[k]);
			}
			for(int k=1;k<=m;k++)ans[i][k]=min(ans[i][k],bin[k]);
		}
		if(flag){
			for(int i=1;i<=m;i++){
				for(int j=1;j<=n;j++)cout<<(ans[j][i]^inf?ans[j][i]:0)<<' ';
				cout<<'\n';
			}
		}else{
			for(int i=1;i<=n;i++){
				for(int j=1;j<=m;j++)cout<<(ans[i][j]^inf?ans[i][j]:0)<<' ';
				cout<<'\n';
			}
		}
	}
	return 0;
}
