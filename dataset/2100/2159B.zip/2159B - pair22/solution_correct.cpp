#include <bits/stdc++.h>

using namespace std;

#define fi first
#define se second

#define sz(a) int((a).size())
#define all(a) (a).begin(), (a).end()

using pii = pair<int, int>;

int n, m;
vector<vector<bool>> a;
vector<vector<int>> ans;
vector<vector<pii>> ev;
bool swaped;

void read() {
   cin >> n >> m;
   if (n < m) {
      swaped = false;
      a.assign(n + 2, vector<bool>(m + 2, 0));
   } else {
      swaped = true;
      a.assign(m + 2, vector<bool>(n + 2, 0));
   }
   for (int i = 1; i <= n; i++) {
      for (int j = 1, x; j <= m; j++) {
         char c;
         cin >> c;
         if (!swaped) a[i][j] = c == '1';
         else a[m - j + 1][i] = c == '1';
      }
   }
   if (swaped) swap(n, m);
}

void solve() {
   ans.assign(n + 2, vector<int>(m + 2, n * m + 1));
   ev.assign(m + 2, vector<pii>(0));

   for (int len = 2; len <= n; len++) {
      for (int i1 = 1; i1 + len - 1 <= n; i1++) {
         int i2 = i1 + len - 1;
         int prev_j = 0;
         for (int j = 1; j <= m; j++) {
            if (a[i1][j] && a[i2][j]) {
               if (prev_j) {
                  for (int j2 = prev_j; j2 <= j; j2++) {
                     ev[j2].emplace_back(i1, len * (j - prev_j + 1));
                  }
               }
               prev_j = j;
            }
         }
      }
      for (int j = 1; j <= m; j++) {
         int curr = 0;
         deque<pii> dq;
         for (int i = 1; i <= n; i++) {
            while (!dq.empty() && dq.front().fi < i - len + 1) {
               dq.pop_front();
            }
            while (curr < sz(ev[j]) && ev[j][curr].fi == i) {
               while (!dq.empty() && dq.back().se >= ev[j][curr].se) {
                  dq.pop_back();
               }
               dq.push_back(ev[j][curr++]);
            }
            if (!dq.empty()) {
               ans[i][j] = min(ans[i][j], dq.front().se);
            }
         }
         ev[j].clear();
      }
   }

   for (int i = 1; i <= n; i++) {
      for (int j = 1; j <= m; j++) {
         if (ans[i][j] > n * m) {
            ans[i][j] = 0;
         }
      }
   }

   if (!swaped) {
      for (int i = 1; i <= n; i++) {
         for (int j = 1; j <= m; j++) {
            cout << ans[i][j] << ' ';
         }
         cout << '\n';
      }
   } else {
      for (int i = 1; i <= m; i++) {
         for (int j = 1; j <= n; j++) {
            cout << ans[n - j + 1][i] << ' ';
         }
         cout << '\n';
      }
   }
}

signed main() {
#ifdef LOCAL
   freopen("input.txt", "r", stdin);
#endif
   ios_base::sync_with_stdio(false);
   cin.tie(0);
   cout.tie(0);

   int t = 1;
   cin >> t;

   while (t--) {
      read();
      solve();
   }

   return 0;
}
