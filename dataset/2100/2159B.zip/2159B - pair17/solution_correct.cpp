#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int inf = 1e9;                


void solve() {
     
    int n, m; cin>>n>>m;
    int n_ = n, m_ = m;
    bool ok = 0;
    if (n > m) {
        ok = 1;
        swap(m, n);
    }

    vector<vector<int>> a(n + 1, vector<int>(m  + 1)), dp(n + 1, vector<int>(m + 1, inf));
    for (int i = 1; i <= n_; ++i) {
        string s; cin >> s;
        for (int j = 1; j <= m_; ++j) {
            int v = s[j - 1] - '0';
            if (!ok) a[i][j] = v;
            else a[j][i] = v; 
        }
    }

    for (int u = 1; u <= n; ++u)  {
        for (int d = u + 1; d <= n ; d++) {
            int l = -1;
            for (int r = 1; r <= m; ++r) {
                if (a[u][r] != 1 || a[d][r] != 1) continue;
                if (l == -1) {
                    l = r;
                    continue;
                }
                int s = (d - u + 1) * (r - l + 1);
                for (int i = l; i <= r; ++i) {
                    dp[d][i] = min(dp[d][i], s);

                }
                l = r;
            }
        }

        for (int i = n - 1; i >= u; --i) {
            for (int j = 1; j <= m; ++j) {
                dp[i][j] = min(dp[i][j], dp[i + 1][j]);
            }
        }
    }

        if (ok) {
        for (int j = 1; j <= m; ++j) {
            for (int i = 1; i <= n; ++i) {
                cout<<(dp[i][j] == inf ? 0 : dp[i][j])<<" ";
            }
            cout<<endl;
        }
    }
    else {
        for (int i = 1; i <= n; ++i) {
            for (int j = 1; j <= m; ++j) {
                cout<<(dp[i][j] == inf ? 0 : dp[i][j])<<" ";
            }
            cout<<endl;
        }
    }


}


signed main() {
    int tt; cin>>tt;
    while (tt--) solve();
}