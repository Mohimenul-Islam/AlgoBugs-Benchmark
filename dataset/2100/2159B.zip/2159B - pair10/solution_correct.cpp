// Problem: CF2159B Rectangles
// Contest: Luogu
// URL: https://www.luogu.com.cn/problem/CF2159B
// Memory Limit: 1000 MB
// Time Limit: 4000 ms
// 
// Powered by CP Editor (https://cpeditor.org)

//空中散歩の SOS 僕ファー　僕ファー　僕ファー ~
#include<bits/stdc++.h>
using namespace std;
// --- Types ---
using ll = long long;
using db = double; 
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vl = vector<ll>;
using poly = vi;

// --- Macros ---
#define fi first
#define se second
#define endl '\n'
#define pb push_back
#define eb emplace_back
#define sz(x) ((int)(x).size())
#define bg begin()
#define ed end()
#define all(x) (x).begin(), (x).end()
#define All(x) (x).begin()+1,(x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define unq(v) (v).erase(unique(all(v)), (v).end())

// --- Loops ---
#define rep(i, a, b) for(int i = (a); i <= (b); ++i)
#define per(i, a, b) for(int i = (a); i >= (b); --i)
#define fore(x, a) for(auto& x : a)

// --- Utils ---
template<class T> bool chmin(T& a, const T& b) { return b < a ? a = b, 1 : 0; }
template<class T> bool chmax(T& a, const T& b) { return a < b ? a = b, 1 : 0; }
string s[250001];
const ll inf=1ll<<30;
string t[250001];
void inrev(ll n,ll m){
	rep(i,1,m)t[i].resize(n+1);
	rep(i,1,n){
		rep(j,1,m)t[j][i]=s[i][j];
	}
	rep(i,1,m){
		s[i]=t[i];
	}
}
void outrev(vector<vl> &x,ll n,ll m){
	vector<vl>y(m+1,vl(n+1));
	x.resize(m+1);
	rep(i,1,n){
		rep(j,1,m){
			y[j][i]=x[i][j];
		}
	}
	
	rep(i,1,m){
		x[i]=y[i];
	}
}
void solve(){
	ll n,m,rev=0;
	cin>>n>>m;
	rep(i,1,n){
		cin>>s[i];
		s[i]=" "+s[i];
	}
	
	if(n>m){
		inrev(n,m);
		swap(n,m),rev=1;
	}
	
	vector<vl>ans(n+1,vl(m+1,inf));
	vector<vl>tag(n+2,vl(m+1,inf));
	rep(u,1,n){
		rep(d,u+1,n){
			rep(i,1,m){
				tag[d][i]=inf;
			}
		}
		rep(d,u+1,n){
			ll pre=0;
			rep(i,1,m){
				if(s[u][i]=='1'&&s[d][i]=='1'){
					ll val=(i-pre+1)*(d-u+1);
					if(pre){
						rep(j,pre,i)chmin(tag[d][j],val);
					}
					pre=i;
				}
			}
		}
		per(d,n,u){
			rep(i,1,m){
				chmin(tag[d][i],tag[d+1][i]);
				chmin(ans[d][i],tag[d][i]);
			}
		}
	}
	rep(i,1,n){
		rep(j,1,m)if(ans[i][j]==inf)ans[i][j]=0;
	}
	
	if(rev){
		outrev(ans,n,m);
		swap(n,m);
	}
	
	rep(i,1,n){
		rep(j,1,m){
			cout<<ans[i][j]<<" "; 
		}
		cout<<endl;
	}
	return ;
}
ll T=1;
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>T;
	for(ll kase=1;kase<=T;kase++){
		solve();
	}
	return 0;
}
