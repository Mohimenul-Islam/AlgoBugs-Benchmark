#include<bits/stdc++.h>
using namespace std;
vector<int> e[251010];
vector<int> f[251010];
vector<int> ans[251010];
vector<int> mi[251010];
void det(int &n,int &m,bool p){
    if(!p){
        for(int j=1;j<=n;j++)f[j]=e[j];
        return;
    }
    for(int j=1;j<=m;j++)f[j].clear();
    for(int i=1;i<=n;i++)for(int j=1;j<=m;j++)f[j].push_back(e[i][j-1]);
    swap(n,m);
}
int main(){
    ios::sync_with_stdio(false);cin.tie(0);
    int t;cin>>t;
    while(t--){
        int n,m;cin>>n>>m;
        for(int i=1;i<=n;i++)e[i].clear();
        for(int i=1;i<=n;i++)for(int j=1;j<=m;j++){
            char x;cin>>x;
            e[i].push_back(x-'0');
        }
        bool flg=n>m;
        det(n,m,flg);
        for(int i=1;i<=n;i++)ans[i].clear(),ans[i].resize(m,0x3f3f3f3f);
        for(int i=1;i<=n;i++){
            mi[i].clear(),mi[i].resize(m,0x3f3f3f3f);
            for(int j=i+1;j<=n;j++){
                mi[j].clear(),mi[j].resize(m,0x3f3f3f3f);
                for(int x=0,lst=-1;x<m;x++){
                    if(f[i][x]&&f[j][x]){
                        if(~lst)
                            for(int t=lst;t<=x;t++)
                                mi[j][t]=min(mi[j][t],(j-i+1)*(x-lst+1));
                        lst=x;
                    }
                }
            }
            for(int j=n;j>=i;j--){
                for(int x=0;x<m;x++){
                    if(j>i)mi[j-1][x]=min(mi[j][x],mi[j-1][x]);
                    ans[j][x]=min(ans[j][x],mi[j][x]);
                }
            }
        }
        for(int i=1;i<=n;i++)e[i].swap(ans[i]);
        for(int i=1;i<=n;i++)for(auto &x:e[i])if(x==0x3f3f3f3f)x=0;
        det(n,m,flg);
        for(int i=1;i<=n;i++)for(int j=0;j<m;j++)cout<<f[i][j]<<" \n"[j==m-1];
    }
    return 0;
}