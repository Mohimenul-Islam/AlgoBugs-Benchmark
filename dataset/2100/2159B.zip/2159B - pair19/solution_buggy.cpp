#include <bits/stdc++.h>

using namespace std;

int coloane[505];
vector<int> pos;

void solve() {
    int n, m, i, j;
    cin >> n >> m;
    vector<vector<char>> mat(min(n, m) + 2, vector<char>(max(n, m) + 2));
    vector<vector<int>> ans(min(n, m) + 2, vector<int>(max(n, m) + 2));
    int flag = 0;
    if (n <= m) {
        for (i = 1; i <= n; i++) {
            for (j = 1; j <= m; j++) {
                cin >> mat[i][j];
            }
        }
    }
    else {
        flag = 1;
        for (i = 1; i <= n; i++) {
            for (j = 1; j <= m; j++) {
                cin >> mat[j][i];
            }
        }
        swap(n, m);
    }
    for (i = 1; i <= n; i++) {
        for (j = 1; j <= m; j++) ans[i][j] = 1e9;
    }
    for (int i1 = 1; i1 < n; i1++) {
        for (j = 0; j <= m + 1; j++) coloane[j] = 1e9;
        for (int i2 = n; i2 > i1; i2--) {
            pos.clear();
            for (j = 1; j <= m; j++) {
                if (mat[i1][j] == mat[i2][j] && mat[i1][j] == '1') {
                    pos.push_back(j);
                }
            }
            int ind = 0;
            for (j = 1; j <= m; j++) {
                if (ind != 0 && ind != pos.size()) {
                    coloane[j] = min((pos[ind] - pos[ind - 1] + 1) * (i2 - i1 + 1), coloane[j]);
                }
                if (mat[i1][j] == mat[i2][j] && mat[i1][j] == '1') {
                    ind++;
                    if (ind != pos.size()) {
                        coloane[j] = min((pos[ind] - pos[ind - 1] + 1) * (i2 - i1 + 1), coloane[j]);
                    }
                }
                ans[i1][j] = min(ans[i1][j], coloane[j]);
                ans[i2][j] = min(ans[i2][j], coloane[j]);
            }
        }
    }
    if (flag == 0) {
        for (i = 1; i <= n; i++) {
            for (j = 1; j <= m; j++) {
                if (ans[i][j] != 1e9) cout << ans[i][j];
                else cout << 0;
                cout << ' ';
            }
            cout << '\n';
        }
    }
    if (flag == 1) {
        for (j = 1; j <= m; j++) {
            for (i = 1; i <= n; i++) {
                if (ans[i][j] != 1e9) cout << ans[i][j];
                else cout << 0;
                cout << ' ';
            }
            cout << '\n';
        }
    }
}

int main()
{
    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
