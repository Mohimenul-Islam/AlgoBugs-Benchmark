#include<bits/stdc++.h>
using namespace std;

typedef int ii;
typedef long long ll;

#define lp(i,n) for(ii i=0;i<(ii)(n);i++)
#define lpr(i,a,b) for(ii i=(a);i>=(ii)(b);i--)

template<class t>
struct bx{
    void* p;
    bx(t& x){ p=(void*)&x; }
    t& g(){ return *(t*)p; }
};

struct dv{
    virtual void op(void*)=0;
};

struct slv{
    void operator()(){
        ii n,m; cin>>n>>m;

        vector<string> s(n);
        lp(i,n) cin>>s[i];

        bool rt = n>m;
        if(rt) swap(n,m);

        vector<vector<ii>> f(n,vector<ii>(m,1e9)), a(n,vector<ii>(m));

        lp(i,n) lp(j,m)
            *reinterpret_cast<ii*>(reinterpret_cast<void*>(&a[i][j])) =
    rt ? 
    (*reinterpret_cast<char*>(reinterpret_cast<void*>(&s[j][i])))=='1' :
    (*reinterpret_cast<char*>(reinterpret_cast<void*>(&s[i][j])))=='1';

        lp(u,n){
            for(ii d=u+1; d<n; d++){
                ii ls=-1;
                lp(l,m){
                    if(a[u][l] && a[d][l]){
                        if(ls!=-1){
                            for(ii i=ls;i<=l;i++){
                                auto* vf = (vector<vector<ii>>*)((void*)&f);
                                (*vf)[d][i] = min((*vf)[d][i], (d-u+1)*(l-ls+1));
                            }
                        }
                        ls=l;
                    }
                }
            }

            lpr(d,n-2,u)
                lp(i,m){
                    auto* vf = (vector<vector<ii>>*)((void*)&f);
                    (*vf)[d][i] = min((*vf)[d][i], (*vf)[d+1][i]);
                }
        }

        if(rt) swap(n,m);

        lp(i,n){
            lp(j,m){
                auto* vf = (vector<vector<ii>>*)((void*)&f);
                cout << (rt ? (*vf)[j][i] : (*vf)[i][j]) % (ii)(1e9)
                     << (j+1==m?'\n':' ');
            }
        }
    }
};

struct rr{
    void run(){
        ii t; cin>>t;
        bx<ii> bt(t);
        auto fn = [&](){
            lp(i,bt.g()) slv()();
        };
        fn();
    }
};

int main(){
    rr r;
    r.run();
}