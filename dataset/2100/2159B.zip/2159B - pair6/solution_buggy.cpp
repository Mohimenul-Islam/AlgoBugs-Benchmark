#include<bits/stdc++.h>
#include<functional>

typedef long long ll;
typedef int ii;

#define fl(v,e) for(ii v=0;v<(ii)(e);v++)
#define fl1(v,s,e) for(ii v=(s);v<=(ii)(e);v++)
#define flr(v,s,e) for(ii v=(s);v>=(ii)(e);v--)
#define ci(x) std::cin>>(x)
#define co(x) std::cout<<(x)
#define mn(a,b) ((a)<(b)?(a):(b))
#define sc(a,b) ((a)==(b))
#define nsc(a,b) ((a)!=(b))
#define INF ((ii)1e9)

template<typename vt>
struct pw{
    vt*bg;
    ii ln;
    pw(vt*b,ii l):bg(b),ln(l){}
    vt&operator[](ii i){return *(bg+i);}
};

template<typename rt>
struct pf{
    std::function<rt()>op;
    pf(std::function<rt()>f):op(f){}
    rt operator()(){return op();}
};

template<typename rt,typename at>
struct uf{
    std::function<rt(at)>op;
    uf(std::function<rt(at)>f):op(f){}
    rt operator()(at a){return op(a);}
};

template<typename rt,typename at>
struct bf{
    std::function<rt(at,at)>op;
    bf(std::function<rt(at,at)>f):op(f){}
    rt operator()(at a,at b){return op(a,b);}
};

struct sv{
    std::function<void()>sl;
    std::function<void()>rn;

    sv(){
        sl=[&]()->void{
            ii*np=new ii;ii*mp=new ii;
            ci(*np);ci(*mp);
            std::vector<std::string>*sv2=new std::vector<std::string>(*np);
            fl(i,*np)ci((*sv2)[i]);
            bool*rp=new bool(false);
            ((*np>*mp)
                ?std::function<void()>([&]()->void{
                    *rp=true;
                    std::swap(*np,*mp);
                })
                :std::function<void()>([&]()->void{}))();
            ii n=*np,m=*mp;
            std::vector<std::vector<ii>>*fv=
                new std::vector<std::vector<ii>>(n,std::vector<ii>(m,INF));
            std::vector<std::vector<ii>>*av=
                new std::vector<std::vector<ii>>(n,std::vector<ii>(m,0));

            bf<ii,ii>ga([&](ii i,ii j)->ii{
                return *rp
                    ?(ii)((*sv2)[j][i]=='1')
                    :(ii)((*sv2)[i][j]=='1');
            });

            fl(i,n)fl(j,m)(*av)[i][j]=ga(i,j);

            bf<ii,ii>gf([&](ii i,ii j)->ii{return (*fv)[i][j];});
            bf<void,ii>upf([&](ii i,ii j)->void{
                (*fv)[i][j]=mn((*fv)[i][j],(*fv)[i+1][j]);
            });

            uf<void,ii>outr([&](ii u)->void{
                fl1(d,u+1,n-1){
                    ii*lp=new ii(-1);
                    fl(l,m){
                        ((*av)[u][l]&&(*av)[d][l])
                        ?std::function<void()>([&]()->void{
                            (nsc(*lp,-1))
                            ?std::function<void()>([&]()->void{
                                fl1(i,*lp,l)
                                    (*fv)[d][i]=mn((*fv)[d][i],(d-u+1)*(l-*lp+1));
                            })()
                            :std::function<void()>([&]()->void{})();
                            *lp=l;
                        })()
                        :std::function<void()>([&]()->void{})();
                    }
                    delete lp;
                }
                flr(d,n-2,u)
                    fl(i,m)(*fv)[d][i]=mn((*fv)[d][i],(*fv)[d+1][i]);
            });

            fl(u,n)outr(u);

            (*rp)?std::function<void()>([&]()->void{
                std::swap(*np,*mp);
            })():std::function<void()>([&]()->void{})();

            ii on=*np,om=*mp;
            fl(i,on){
                fl(j,om){
                    ii vl=(*rp?(*fv)[j][i]:(*fv)[i][j])%INF;
                    co(vl)<<(sc(j+1,om)?'\n':' ');
                }
            }
            delete np;delete mp;delete rp;delete fv;delete av;delete sv2;
        };

        rn=[&]()->void{
            ii*tp=new ii;
            ci(*tp);
            pf<void>lp([&]()->void{
                fl(i,*tp)sl();
            });
            lp();
            delete tp;
        };
    }

    void run(){
        pf<void>ex([&]()->void{rn();});
        ex();
    }
};

ii main(){
    std::ios_base::sync_with_stdio(0);
    std::cin.tie(0);
    sv*sp=new sv();
    sp->run();
    delete sp;
}