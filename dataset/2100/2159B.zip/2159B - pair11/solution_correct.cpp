#include <bits/stdc++.h>
using namespace std;
const int MAX = 1e6 + 5;
using i64 = long long;
#define inf32 INT_MAX
#define inf64 LLONG_MAX
int n;
int dp[MAX];
string s[MAX];

void solve() {
    cin >> n;
    int m;
    cin >> m;
    for (int i = 1; i <= n; i++) {
        cin >> s[i];
        s[i] = '0' + s[i];
    }
    bool rev = 0;
    if (n > m) {
        swap(n, m);
        rev = 1;
    }
    vector<vector<int>> a(n + 1, vector<int>(m + 1, 0)), ans(n + 1, vector<int>(m + 1, inf32));
    // vector<SegmentTreeMin> tree(m + 1, SegmentTreeMin(n));
    // vector<vector<vector<int>>> L(m + 1,vector<vector<int>>(n+1)),R(m+1,vector<vector<int>>(n+1));//维护边缘
    // for (int i = 1; i <= m; i++) {
    //     tree[i].build(arr, 1, 1, n);
    // }

    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            if (rev) a[i][j] = s[j][i] - '0';
            else a[i][j] = s[i][j] - '0';
        }
    }
    for (int i = 1; i <= n; i++) {
        vector<vector<int>> v(m + 1, vector<int>(n + 1, inf32));
        for (int j = i + 1; j <= n; j++) {
            //(i,j)->
            int last = 0;
            for (int k = 1; k <= m; k++) {
                if (a[i][k] && a[j][k]) {
                    last = k;
                    break;
                }
            }
            for (int k = last + 1; k <= m; k++) {
                if (a[i][k] && a[j][k]) {
                    int sq = (k - last + 1) * (j - i + 1);
                    for (int l = last; l <= k; l++) {
                        v[l][j] = min(v[l][j], sq);
                        // L[l][i].push_back(sq);
                        // R[l][j].push_back(sq);
                    }
                    last = k;
                }
            }
        }
        for (int k = 1; k <= m; k++) {
            int mi = inf32;
            for (int j = n; j >= i; j--) {
                mi = min(mi, v[k][j]);
                ans[j][k] = min(ans[j][k], mi);
            }
        }
    }
    // vector<vector<int>>ans(n+1,vector<int>(m+1));
    // cout<<ans<<endl;
    // for (int i = 1; i <= m; i++) {
    //     multiset<int>st;
    //     for (int j = 1; j <= n; j++) {
    //         for(auto k:L[i][j]){
    //             st.insert(k);
    //         }
    //         if(st.size())
    //         ans[j][i]=*st.begin();
    //         else ans[j][i]=0;
    //         for(auto k:R[i][j]){
    //             st.erase(st.find(k));
    //         }
    //     }
    // }
    if (rev) {
        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                cout << ((ans[j][i] == inf32) ? 0 : ans[j][i]) << ' ';
            }
            cout << endl;
        }
    }
    else {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                cout << ((ans[i][j] == inf32) ? 0 : ans[i][j]) << ' ';
            }
            cout << endl;
        }
    }
}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int t;
    t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
}