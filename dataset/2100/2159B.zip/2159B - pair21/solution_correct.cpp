#include <bits/stdc++.h>

using namespace std;
const int INF = 1e9;
void solve() {
    int n, m; cin >> n >> m;
    bool swapped = n<m; 
    bitset<250'000> grid, grid2;

    for (int i = 0; i < n; i++) {
        string s; cin >> s;
        for (int j = 0; j < m; j++) {
            if (s[j] == '1') grid.set(i*m+j), grid2.set(j*n+i);
        }
    }

    if(swapped) swap(n, m), swap(grid, grid2);
    vector<vector<vector<int>>> dp(n, vector<vector<int>>(m, vector<int>(m, INF)));

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            int pos = i*m + j, mx = (i+1)*m;
            int pos2 = j*n+i, mx2 = (j+1)*n;
            if (!grid.test(pos)) continue;

            for (int j2 = grid._Find_next(pos); j2 < mx; j2 = grid._Find_next(j2)) {
                for (int i2 = grid2._Find_next(pos2); i2 < mx2; i2 = grid2._Find_next(i2)) {
                    int di = i2 - pos2, dj = j2 - pos;
                    if (!grid.test((i+di)*m + (j+dj))) continue;
                    // rects.push_back(rect(i, j, i+di, j+dj));
                    for (int x = i; x <= i+di; x++) {
                        dp[x][j][j+dj] = min(dp[x][j][j+dj], (di+1)*(dj+1));
                    }
                    break;
                }
            }
        }
    }

    vector<vector<int>> ans((swapped ? m : n), vector<int>((swapped ? n : m), 0));
    for (int row = 0; row < n; row++) {
        for (int length = m; length >= 1; length--) {
            for (int col = 0; col + length - 1 < m; col++) {
                if (length == 1) {
                    int x = swapped ? col : row, y = swapped ? row : col;
                    ans[x][y] = dp[row][col][col];
                } else {
                    dp[row][col+1][col+length-1] = min(dp[row][col][col+length-1], dp[row][col+1][col+length-1]);
                    dp[row][col][col+length-2] = min(dp[row][col][col+length-1], dp[row][col][col+length-2]);
                }
            }
            
        }
    }

    for (auto &el : ans) {
        for (auto &vel : el) cout << (vel == INF ? 0 : vel) << " ";
        cout << "\n";
    }
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    int t; cin >> t; 
    while (t--) solve();    
    return 0;
}