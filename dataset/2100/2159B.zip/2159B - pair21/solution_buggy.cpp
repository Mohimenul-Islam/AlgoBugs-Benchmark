#include <bits/stdc++.h>

using namespace std;
struct rect {
    int x1, y1, x2, y2;
    rect(int X1=0, int Y1 = 0, int X2 = 0, int Y2 = 0) : x1(X1), x2(X2), y1(Y1), y2(Y2) {}
    int area() {
        return (x2-x1+1)*(y2-y1+1);
    }
    bool operator<(const rect &other) const {
        return (x2-x1+1)*(y2-y1+1) < (other.x2-other.x1+1)*(other.y2-other.y1+1);
    }
};

struct DSU {
    int n; vector<int> par, left, right;
    DSU(int N = 0) : n(N), par(N), left(N), right(N) {for (int i = 0; i < n; i++) left[i] = right[i] = par[i] = i;}
    int find(int v) {
        if (par[v] == v) return v;
        return par[v] = find(par[v]);
    }
    void unite(int a, int b) {
        a = find(a); b = find(b);
        if (a != b) {
            par[b] = a;
            left[a] = min(left[a], left[b]);
            right[a] = max(right[a], right[b]);
        }
    }

    int next(int a) {
        return right[find(a)] + 1;
    }

    int prev(int a) {
        return left[find(a)] - 1;
    }
};  

void solve() {
    int n, m; cin >> n >> m;
    bool swapped = n>m; 
    bitset<250'000> grid, grid2;

    for (int i = 0; i < n; i++) {
        string s; cin >> s;
        for (int j = 0; j < m; j++) {
            if (s[j] == '1') grid.set(i*m+j), grid2.set(j*n+i);
        }
    }

    vector<rect> rects;
    if(swapped) swap(n, m), swap(grid, grid2);

    for (int i = 0; i < n; i++) {
        for (int i2 = i+1; i2 < n; i2++) {
            int pos1 = i*m, pos2 = i2*m;
            int mx1 = (i+1)*m, mx2 = (i2+1)*m;
            int j1 = pos1 == 0 ? grid._Find_first() : grid._Find_next(pos1-1);
            int j2 = grid._Find_next(pos2-1);

            vector<int> match;
            while (j1 < mx1 && j2 < mx2) {
                if (j1-pos1 == j2-pos2) match.push_back(j1-pos1);
                if (j1-pos1 < j2-pos2) j1 = grid._Find_next(j1);
                else j2 = grid._Find_next(j2);
            }

            for (int k = 0; k < int(match.size())-1; k++) {
                rects.push_back(rect(i, match[k], i2, match[k+1]));
            }

            // for (int j = 0; j < m; j++) {
            //     int pos = i*m + j, mx = (i+1)*m;
            //     int pos2 = j*n+i, mx2 = (j+1)*n;
            //     if (!grid.test(pos)) continue;

            //     for (int i2 = grid2._Find_next(pos2); i2 < mx2; i2 = grid2._Find_next(i2)) {
            //         int di = i2 - pos2, dj = j2 - pos;
            //         if (!grid.test((i+di)*m + (j+dj))) continue;
            //         rects.push_back(rect(i, j, i+di, j+dj));
            //         break;
            //     }
            // }
        }
    }
    sort(rects.begin(), rects.end()); 
    vector<vector<int>> ans((swapped ? m : n), vector<int>((swapped ? n : m), 0));
    vector<DSU> dsu(n, DSU(m));
    for (auto &el : rects) {
        for (int i = el.x1; i <= el.x2; i++) {
            for (int j = el.y1; j <= el.y2; j = dsu[i].next(j)) {
                int x = swapped ? j : i, y = swapped ? i : j;
                if (dsu[i].prev(j) >= el.y1) dsu[i].unite(dsu[i].prev(j), j);
                if (ans[x][y] == 0) ans[x][y] = el.area();
            }
        }
    }

    for (auto &el : ans) {
        for (auto &vel : el) cout << vel << " ";
        cout << "\n";
    }
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    int t; cin >> t; 
    while (t--) solve();    
    return 0;
}