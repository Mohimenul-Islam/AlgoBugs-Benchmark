#pragma GCC optimize("Ofast")
#include<bits/stdc++.h>
#define ll long long
#define ld long double
#define se second
#define fi first
#define pb push_back
#define fr front
#define bk back
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define watch(x) cout << #x << " = " << (x) << '\n'
using namespace std;
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
const ll md = 1e9 + 7, md2 = 998244353;

ll mod = md2; 

const ll MX = 3e5 + 10, inf = 1e9;
////--------------------------
ll dp[MX];
void Ali(){
	ll n;
	cin >> n;
	ll a[n + 19] = {}, p[n + 19] = {};
	vector<pair<ll,ll>>v;v.pb({0, 0});
	for(ll i = 1;i <= n;i ++){
		dp[i] = -inf;
		cin >> a[i];
		v.pb({a[i], -i});
	}
	sort(all(v));
	dp[1] = 1;p[1] = 1;
	ll j = 1;
	for(ll i = 2;i <= n;i ++){
		// sort(rall(v[i]));
		if(v[i].fi == v[i - 1].fi) dp[i] = dp[i - 1] + 1;
		ll l = 0, r = i;
		while(l + 1 < r){
			ll mid = (l + r) / 2;
			if(v[mid].fi + 1 != v[i].fi || v[mid].se < v[i].se){
				l = mid;
			}
			else{
				r = mid;
			}
		}
		dp[i] = max(dp[i], p[l] + 1);
		p[i] = max(p[i - 1], dp[i]);
	//	cout << dp[i] << ' ' << l << '\n';
	}
	
	
	cout << n - p[n] << '\n';
}
int main(){
	ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
    ll T = 1;
	cin >> T;
    while(T --) Ali();
}/// plus_ultra	