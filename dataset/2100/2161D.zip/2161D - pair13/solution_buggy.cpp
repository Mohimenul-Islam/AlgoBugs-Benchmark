#include<bits/stdc++.h>
using namespace std;
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;

// #define int long long
#define cerr if(0) cerr
using ll = long long;
using ull = unsigned long long;
using ld = long double;
using vi = vector<int>;
using vpii = vector<pair<int,int>>;
#define pb push_back
#define all(a) (a).begin(),(a).end()
#define sz(x) (int)(x).size()
#define yes cout << "YES\n";
#define no cout << "NO\n";
#define debug(x) cerr << #x << ": " << x << endl;
#define debug2(x, y) cerr << #x << ": " << x << " | " << #y << ": " << y << endl;
#define debug3(x, y, z) cerr << #x << ": " << x << " | " << #y << ": " << y << " | " << #z << ": " << z << endl;
#define debug4(a, b, c, d) cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << endl;
#define debug5(a, b, c, d, e) cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << " | " << #e << ": " << e << endl;
#define debug6(a, b, c, d, e, f) cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << " | " << #e << ": " << e << " | " << #f << ": " << f << endl;
#define debug7(a, b, c, d, e, f, g) cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << " | " << #e << ": " << e << " | " << #f << ": " << f << " | " << #g << ": " << g << endl;
#define debug8(a, b, c, d, e, f, g, h) cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << " | " << #e << ": " << e << " | " << #f << ": " << f << " | " << #g << ": " << g << " | " << #h << ": " << h << endl;
#define debug9(a, b, c, d, e, f, g, h, i) cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << " | " << #e << ": " << e << " | " << #f << ": " << f << " | " << #g << ": " << g << " | " << #h << ": " << h << " | " << #i << ": " << i << endl;
#define st first 
#define nd second
template<typename T1, typename T2>istream& operator>>(istream& in, pair<T1,T2>& a){in >> a.first >> a.second;return in;}
template<typename T>istream& operator>>(istream& in, vector<T>& v) {for (auto &x : v) in >> x;return in;}
struct hash { size_t operator()(uint64_t x) const { static const uint64_t R = chrono::steady_clock::now().time_since_epoch().count(); x += 0x9e3779b97f4a7c15 + R; x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9; x = (x ^ (x >> 27)) * 0x94d049bb133111eb; return x ^ (x >> 31); } };
template<class T> using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template<class T> using ordered_multiset = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>;
using namespace std;
const int inf = 1e9;
void self_max(int &x, int y){
    x = max(x,y);
}
void solve(){   
    int n;
    cin >> n;
    vector<int>a(n);
    cin >> a;
    vector<pair<int,int>>V(n);
    for(int i = 0; i < n; i++)V[i] = {a[i],-i};
    sort(V.begin(),V.end());
    V.insert(V.begin(), make_pair(n,-1));

    vector<int>dp(n + 1);
    vector<int>pref(n+1);
    for(int i = 1; i <= n; i++){
        dp[i] = 1;
        if(V[i].first == V[i-1].first)self_max(dp[i],pref[i-1]+1);
        int x = lower_bound(V.begin(),V.end(),make_pair(V[i].first - 1,V[i].second)) - V.begin();
        x--;
        vector<int>XX = {x};
        for(auto &p : XX){
            p = max(p,1);
            p = min(p,i-1);
        }
        for(auto j : XX){
            if(V[j].second < V[i].second)
                self_max(dp[i],pref[j]+1); 
        }
        XX.clear();
        x = lower_bound(V.begin(),V.end(),make_pair(V[i].first-2,inf)) - V.begin();
         XX = {x-1,x-2,x,x+1,x+2};
        for(auto &p : XX){
            p = max(p,1);
            p = min(p,i-1   );
        }
        for(auto j : XX){
            if(V[j].first < V[i].first - 1)
                self_max(dp[i],dp[j]+1); 
        }
        if(V[i].first == V[i-1].first)
        pref[i] = max(pref[i-1],dp[i]);
        else pref[i] = dp[i]; 
    }
    cout << n-*max_element(all(dp)) << '\n';

}
int32_t main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int tt = 1;
    cin >> tt;
    while(tt--)solve();
}