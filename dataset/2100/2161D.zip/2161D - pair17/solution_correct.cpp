#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define F first
#define S second
#define pb push_back
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<pii> vp;
typedef vector<ll> vl;
typedef vector<vi> vvi;
typedef vector<vl> vvl;
typedef vector<vp> vvp;

template <class T1, class T2> istream& operator>>(istream &in, pair<T1, T2> &p) { return in >> p.F >> p.S; }
template <class T1, class T2> ostream& operator<<(ostream &out, const pair<T1, T2> &p) { return out << p.F << " " << p.S; }
 
template <class T> istream& operator>>(istream &in, vector<T> &a) { for (T &i : a) in >> i; return in; }
template <class T> void print(const vector<T> &a, const string &s = " ") { for (int i = 0; i < sz(a); i++) cout << a[i] << (i == sz(a) - 1 ? "\n" : s); }

void solve() {
    int n;cin>>n;
    vi a(n);cin>>a;
    rep(i,0,n)a[i]--;

    vvi at(n);
    rep(i,0,n){
        at[a[i]].pb(i);
    }

    int ans = 0;
    rep(i,0,n-1){
        for(int j = sz(at[i]) - 1; j >= 0; j--) {
            if(!at[i+1].empty() && at[i+1].back() > at[i][j]) {
                ans++;
                at[i+1].pop_back();
            }
        }
    }
    cout<<ans<<"\n";
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    cin.exceptions(cin.failbit);

    int t;cin>>t;
    while(t--){
        solve();
    }
}
