#if !defined(LOCAL)
// C
#include <cassert>
#include <cctype>
#include <cmath>
#include <cstdlib>

#if __cplusplus >= 201103L
#include <cstdint>
#endif

// C++
#include <algorithm>
#include <bitset>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#if __cplusplus >= 201103L
#include <chrono>
#include <random>
#include <tuple>
#endif

#if __cplusplus >= 202002L
#include <bit>
#endif

#pragma GCC optimize("O3")
#define dbg(...) ((void)0)

#else
#include "pch.h"
#endif

using namespace std;

using i32 = int32_t;
using i64 = int64_t;
using u32 = uint32_t;
using u64 = uint64_t;
// clang-format off

template<class T>bool chmin(T&a,const T&b){return b<a?a=b,1:0;}template<class T>bool chmax(T&a,const T&b){return b>a?a=b,1:0;}template<class T,T val=T{},class...dims>auto ndarray(size_t hd,dims...tl){if constexpr(!sizeof...(tl))return vector<T>(hd,val);else{auto inner=ndarray<T,val>(tl...);return vector<decltype(inner)>(hd,inner);}}

void solve(int) {
    // Test naive O(n^2) first
    cout << setprecision(16);
    int n;
    cin >> n;
    vector<pair<int, int>> a(n+1);
    a[0] = make_pair(-2, 0);
    for (int i = 1; i <= n; i++) {
        cin >> a[i].first;
        a[i].second = i;
    }
    sort(a.begin(), a.end(), [](const auto &x, const auto &y) {
        return make_pair(x.first, -x.second) < make_pair(y.first, -y.second);
    });
    vector<int> dp(n+1); // max subsequence forming good array
    dp[0] = 0;
    for (int i = 1; i <= n; i++) {
        for (int j = 0; j < i; j++) {
            if (a[i].first-a[j].first==1 && a[j].second<a[i].second)
                continue;
            chmax(dp[i], dp[j]+1);
        }
    }
    cout << n - *max_element(dp.begin(), dp.end()) << '\n';
}

// clang-format on

// Stupid mistakes
// 1. int instead of i64
// 2. 1 instead of 1LL
// 3. std::unordered_set and std::unordered_map instead of std::set and std::map
// (see 2118D2: std::map is faster than even std::unordered_map with splitmix64)
// 4. Divide by zero error
// 5. a.size()/a.length() - x when a.size()/a.length() == 0
// 6. Not reading constraints properly (e.g. a is a permutation)
// 7. s[i] - 0 instead of s[i] - '0'
// 8. Exceeding query limit in interactive gives WA not RTE even if you assert(false) after -1 received
// 9. % result negative, x % 2 == 1 never works

i32 main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int tt = 1;
    cin >> tt;
    for (int tc = 1; tc <= tt; tc++) {
        solve(tc);
    }
    return 0;
}
