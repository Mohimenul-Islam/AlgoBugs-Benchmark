#if !defined(LOCAL)
// C
#include <cassert>
#include <cctype>
#include <cmath>
#include <cstdlib>

#if __cplusplus >= 201103L
#include <cstdint>
#endif

// C++
#include <algorithm>
#include <bitset>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#if __cplusplus >= 201103L
#include <chrono>
#include <random>
#include <tuple>
#endif

#if __cplusplus >= 202002L
#include <bit>
#endif

#pragma GCC optimize("O3")
#define dbg(...) ((void)0)

#else
#include "pch.h"
#endif

using namespace std;

using i32 = int32_t;
using i64 = int64_t;
using u32 = uint32_t;
using u64 = uint64_t;
// clang-format off

template<class T>bool chmin(T&a,const T&b){return b<a?a=b,1:0;}template<class T>bool chmax(T&a,const T&b){return b>a?a=b,1:0;}template<class T,T val=T{},class...dims>auto ndarray(size_t hd,dims...tl){if constexpr(!sizeof...(tl))return vector<T>(hd,val);else{auto inner=ndarray<T,val>(tl...);return vector<decltype(inner)>(hd,inner);}}

void solve(int) {
    // Test naive O(n^2) first
    cout << setprecision(16);
    int n;
    cin >> n;
    vector<vector<int>> idx(n);
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        x--;
        idx[x].push_back(i);
    }
    for (int i = 0; i < n; i++) {
        reverse(idx[i].begin(), idx[i].end());
    }
    vector<int> dp(n+1); // max subsequence forming good array
    dp[0] = 0;
    int nxt = 1;
    vector<int> dp_mx(n); // max of dps where last element has value i
    int mx_i2 = 0; // max_(0..i-2)(dp_j)
    vector<int> pre_mx;
    for (int i = 0; i < n; i++) {
        if (i-2>=0) chmax(mx_i2, dp_mx[i-2]);
        vector<int> npre_mx;
        for (int x : idx[i]) {
            chmax(dp[nxt], mx_i2+1); // j<=i-2
            chmax(dp[nxt], dp_mx[i]+1); // j==i
            if (i != 0) {
                auto it = lower_bound(idx[i-1].begin(), idx[i-1].end(), x, greater<>());
                if (it != idx[i-1].begin())
                    chmax(dp[nxt], pre_mx[prev(it)-idx[i-1].begin()]+1); // j==i-1
            }
            chmax(dp_mx[i], dp[nxt]);
            npre_mx.push_back(max(dp[nxt], npre_mx.empty()?0:npre_mx.back()));
            //dbg(nxt, i, dp[nxt], dp_mx[i], npre_mx, mx_i2);
            nxt++;
        }
        pre_mx = npre_mx;
    }
    cout << n - *max_element(dp.begin(), dp.end()) << '\n';
}

// clang-format on

// Stupid mistakes
// 1. int instead of i64
// 2. 1 instead of 1LL
// 3. std::unordered_set and std::unordered_map instead of std::set and std::map
// (see 2118D2: std::map is faster than even std::unordered_map with splitmix64)
// 4. Divide by zero error
// 5. a.size()/a.length() - x when a.size()/a.length() == 0
// 6. Not reading constraints properly (e.g. a is a permutation)
// 7. s[i] - 0 instead of s[i] - '0'
// 8. Exceeding query limit in interactive gives WA not RTE even if you assert(false) after -1 received
// 9. % result negative, x % 2 == 1 never works

i32 main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int tt = 1;
    cin >> tt;
    for (int tc = 1; tc <= tt; tc++) {
        solve(tc);
    }
    return 0;
}
