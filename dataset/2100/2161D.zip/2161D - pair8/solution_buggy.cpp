#include<bits/stdc++.h>
using namespace std;
struct node{
	int a,b;
	bool operator<(const node&other)const{
		if(a!=other.a)
			return a<other.a;
		else
			return b>other.b;
	}
};
void solve()
{
	int n;
	cin>>n;
	vector<node> a(n);
	for(int i=0;i<n;i++)
	{
		int x;
		cin>>x;
		a[i]={x,i};
	}
	sort(a.begin(),a.end());
	vector<int> f(n);
	int l=0,r=0,pre_max=0,suf_max=0;
	for(int i=0;i<n;i++)
	{
		while(a[l].a<=a[i].a-2)
			pre_max=max(pre_max,f[l++]);
		if(i>0&&a[i].a!=a[i-1].a)
			suf_max=0,r=i-1;
		while(r>=0&&a[r].a==a[i].a-1&&a[r].b>a[i].b)
			suf_max=max(suf_max,f[r--]);
		f[i]=max(pre_max,suf_max)+1;
		if(i<n-1&&a[i].a==a[i+1].a)
			suf_max=max(suf_max,f[i]);
	}
	int ans=n;
	for(int i=0;i<n;i++)
		ans=min(ans,n-f[i]);
	cout<<ans<<'\n';
}
signed main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	int t=1;
	cin>>t;
	while(t--)
		solve();
	return 0;
}