#include<bits/stdc++.h>
using namespace std;
const int N=500005;
int n;
int a[N];
int L[N],R[N];
set<pair<int,int> >s[N];
int id[N];
int c1[N],c2[N];
int dp[N],tmp[N];

vector<int> pos[N];
multiset<int> pre,nxt;

void solve(){
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	
	for(int i=0;i<=n;i++) s[i].clear(),dp[i]=n,pos[i].clear();
	
	pre.clear(),nxt.clear();
	for(int i=1;i<=n;i++){
//		s[a[i]].insert({i,id[a[i]]});
		pos[a[i]].push_back(i);
	}
	
	for(int i=0;i<pos[1].size();i++){
		int p=pos[1][i];
		dp[p]=pos[1].size()-(i+1);
	}
	dp[0]=pos[1].size();
	
	for(int v=2;v<=n;v++){
		pre.clear(),nxt.clear();
		for(int i=0;i<pos[v-1].size();i++) nxt.insert(dp[pos[v-1][i]]);
		
		int cnt=0;
		for(int i=0;i<pos[v].size();i++){
			while(cnt<pos[v-1].size()){
				if(pos[v-1][cnt]<pos[v][i]){
					nxt.erase(nxt.find(dp[pos[v-1][cnt]]));
					pre.insert(dp[pos[v-1][cnt]]+cnt+1);
					cnt++;
				}
				else break;
			}
			int tmp1=n,tmp2=n;
			if(pre.size()) tmp1=*(pre.begin());
			if(nxt.size()) tmp2=*(nxt.begin())+cnt;
//			cout<<"p="<<pos[v][i]<<" pre="<<tmp1<<" nxt="<<tmp2<<endl;
			dp[pos[v][i]]=min(tmp1,tmp2);
			dp[pos[v][i]]=min(dp[pos[v][i]],dp[0]);
			
			dp[pos[v][i]]+=pos[v].size()-(i+1);
		}
		
		int tmp=n;
		for(int i=0;i<pos[v-1].size();i++) 
			tmp=min(tmp,dp[pos[v-1][i]]);
		
		dp[0]=min(dp[0],tmp)+pos[v].size();
		
	}
//	for(int i=1;i<=n;i++)
//		cout<<"i="<<i<<" dp="<<dp[i]<<endl;
	int ans=dp[0];
	for(int p:pos[n])
		ans=min(ans,dp[p]);
	cout<<ans<<endl;
}
int main(){
	int T=1;
    scanf("%d",&T);
	while(T--) solve();
	return 0;
}

/*
23766
13
1 1 1 1 2 2 1 1 2 2 1 1 1

*/