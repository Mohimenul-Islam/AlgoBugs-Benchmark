#include <bits/stdc++.h>

using namespace std;
using ld = long double;
using ll = long long;

#define tinline [[gnu::always_inline]] inline


const int maxn = 3e5 + 10;
vector<int> cub[maxn];

void _main() {
    int n;
    cin >> n;
    for(int i = 0;i < n;i++) cub[i].clear();
    for(int i = 0;i < n;i++) {
        int x;
        cin >> x;
        --x;
        cub[x].push_back(i);
    }
    int ans = 0;
    for(int i = 0;i < n - 1;i++) {
        auto & a = cub[i];
        auto & b = cub[i + 1];
        int n = a.size();
        for(int i = n - 1;i >= 0;i--) {
            if(b.size() && b.back() > a[i]) {
                b.pop_back();
                ans++;
            }
        }
    }
    cout << ans << '\n';
}

int main(){
    cin.tie(0) -> sync_with_stdio(0);
    int t = 1;
    cin >> t;
    while(t--) _main();
}