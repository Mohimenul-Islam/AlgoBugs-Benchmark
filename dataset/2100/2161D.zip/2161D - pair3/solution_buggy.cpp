#include <bits/stdc++.h>

using namespace std;
using ld = long double;
using ll = long long;

#define tinline [[gnu::always_inline]] inline


const int maxn = 2e5 + 10;
vector<int> cub[maxn];

int st[maxn << 2];

void update(int i, int x, int l, int r, int n ){
    if(l == r) {
        st[n] = x;
        return;
    }

    int m = (l + r) >> 1;
    if(i <= m) update(i, x, l, m, n * 2 + 1);
    else update(i, x, m + 1, r, n * 2 + 2);
    st[n] = max(st[n * 2 + 1], st[n * 2 + 2]);
}

int query(int lq, int rq, int l, int r, int n) {
    if(r < lq || rq < l) return 0;
    if(lq <= l && r <= rq) return st[n];
    int m = (l + r) >> 1;
    return max(
        query(lq, rq, l, m, n * 2 + 1),
        query(lq, rq, m + 1, r, n * 2 + 2)
    );
}

void _main() {
    int n;
    cin >> n;
    for(int i = 0;i < n;i++) cub[i].clear();
    for(int i = 0;i < (4 * n);i++) {
        st[i] = 0;
    }
    for(int i = 0;i < n;i++) {
        int x;
        cin >> x;
        --x;
        cub[x].push_back(i);
    }
    int ans = 0;
    for(int i = 0;i < n - 1;i++) {
        auto & a = cub[i];
        auto & b = cub[i + 1];
        int n = a.size();
        for(int i = n - 1;i >= 0;i--) {
            if(b.size() && b.back() > a[i]) {
                b.pop_back();
                ans++;
            }
        }
    }
    cout << ans << '\n';
}

int main(){
    cin.tie(0) -> sync_with_stdio(0);
    int t = 1;
    cin >> t;
    while(t--) _main();
}