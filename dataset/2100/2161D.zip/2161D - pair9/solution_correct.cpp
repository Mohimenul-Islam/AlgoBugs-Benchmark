#include <iostream>
#include <vector>
#include <map>
#include <algorithm>

using namespace std;

int getMin(const vector<pair<int,int>>& v) {
  int mn = v[0].second;
  for (int j = 1; j < v.size(); j++) mn = min(v[j].second, mn);
  return mn;
}

int main() {
  int T; cin >> T;
  while (T--) {
    int n; scanf("%d", &n);
    vector<int> a(n);
    for (int i = 0; i < n; i++) scanf("%d", &a[i]);
    vector<vector<int>> v(n+1);
    for (int i = 0; i < n; i++) v[a[i]].push_back(i);
    vector<pair<int,int>> dp;
    int ans = 0;
    for (int i = 1; i <= n; i++) {
      if (v[i].empty()) {
        if (!dp.empty()) ans += getMin(dp);
        dp.clear(); 
        continue;
      }
      if (dp.empty()) {
        for (int j = 0; j < v[i].size(); j++) {
          dp.push_back({v[i][j], j});
        }
        dp.push_back({n, v[i].size()});
      } else {
        vector<pair<int,int>> dp2;
        vector<pair<int,int>> back;
        int k = dp.size()-1, best = dp[k].second;
        for (int j = v[i].size()-1; j >= 0; j--) {
          while (k > 0 && dp[k-1].first > v[i][j]) k--;
          best = min(best, dp[k].second);
          back.push_back({best + v[i].size() - 1 - j, v[i][j]});
        }
        k = 0;
        sort(back.begin(), back.end());
        for (int j = 0; j < v[i].size(); j++) {
          while (back[k].second < v[i][j]) k++;
          dp2.push_back({v[i][j], j + back[k].first});
        }
        dp2.push_back({n, v[i].size() + getMin(dp)});
        dp = dp2;
      }
    }
    if (!dp.empty()) ans += getMin(dp);
    printf("%d\n", ans);
  }
}