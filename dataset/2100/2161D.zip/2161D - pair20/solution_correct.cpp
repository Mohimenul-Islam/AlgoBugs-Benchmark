#include<bits/stdc++.h>
using namespace std;
using ll=long long;
mt19937_64 rnd(chrono::steady_clock::now().time_since_epoch().count());
constexpr ll N=3e5+10,inf=1e16;
vector<int> a[N];
ll dp[N],mx[N];
void solve(){
    ll i,j,l,r,x,y,z,n;cin>>n;
    for(i=1;i<=n;++i){
        dp[i]=mx[i]=0;
        a[i].clear();
    }
    for(i=1;i<=n;++i){
        cin>>x;
        a[x].push_back(i);
    }
    for(i=1;i<=n;++i){
        mx[i]=mx[i-1];
        if(a[i].empty()) continue;
        l=a[i-1].size()-1;
        if(i>1) z=mx[i-2]+a[i].size();
        else z=a[i].size();
        for(j=a[i].size()-1;j>=0;--j){
            while(l>=0&&a[i-1][l]>a[i][j]) z=max(z,dp[a[i-1][l]]+j+1),--l;
            dp[a[i][j]]=z-j;
            mx[i]=max(mx[i],dp[a[i][j]]);
        }
    }
    cout<<n-mx[n]<<endl;
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr),cout.tie(nullptr);
    int tt=1;cin>>tt;
    while(tt--){
        solve();
    }
}