#include <bits/stdc++.h>
using namespace std;
const int N = 300010;
int T, n, a[N], dp[N], rt[N];
vector <int> pos[N];
int main () {
	scanf ("%d", &T);
	while (T --> 0) {
		scanf ("%d", &n);
		fill (pos + 1, pos + n + 1, vector <int> ());
		for (int i = 1; i <= n; i++) {
			scanf ("%d", &a[i]);
			pos[a[i]].push_back (i);
		}
		rt[1] = pos[1].size () - 1;
		for (int i = 2; i <= n; i++) {
			int t = -1, s = pos[i].size ();
			for (int j = 0, k = 0; j <= rt[i - 1] || k < (int) pos[i].size (); ) {
				if (k == (int) pos[i].size () || (j <= rt[i - 1] && pos[i - 1][j] < pos[i][k])) {
					j++;
				} else {
					int u = j + pos[i].size () - k - 1;
					if (u < s) {
						t = k;
						s = u;
					}
					k++;
				}
			}
			if (dp[i - 2] + (int) pos[i - 1].size () >= dp[i - 1] + s) {
				dp[i] = dp[i - 1] + s;
				rt[i] = t;
			} else {
				dp[i] = dp[i - 2] + pos[i - 1].size ();
				rt[i] = pos[i].size () - 1;
			}
		}
		printf ("%d\n", dp[n]);
	}
	return 0;
}
