#include<iostream>
#include<vector>
#include<algorithm>
const int N = 3e5 + 5, inf = 1e17; 
struct pp{
	int x;
	int id;
}p[N];
bool cmp(pp a, pp b){
	if(a.x == b.x){
		return a.id > b.id;
	}
	return a.x < b.x; 
}
using namespace std;
void solve(){
	int n, an = 0;
	cin >> n;
	vector <int> a(n + 1); 
	vector <int> dp(N);
//	map <int, int> m;
	for(int i = 1; i <= n; i++){
		cin >> a[i];
		p[i] = {a[i], i};
	}
	sort(p + 1, p + 1 + n, cmp);
	int maxn = 0, qwq = 0, pos = 0;
	for(int i = 1; i <= n; i++){
		while(pos < i && 
		(p[pos].x < p[i].x - 1 || 
		(p[pos].x == p[i].x - 1 && p[pos].id > p[i].id))){
			maxn = max(maxn, dp[pos++]);
		}
		if(p[i].x != p[i - 1].x){
			qwq = 0;
		}
		dp[i] = max(maxn, qwq) + 1;
		an = max(an, dp[i]);
		qwq = max(qwq, dp[i]);
	}
	cout << n - an << endl;
}
int main(){
	int t;
	cin >> t;
	while(t--){
		solve();
	}
	return 0;
}