#include <bits/stdc++.h>
using namespace std;

void solve() 
{
    int n;
    cin>>n;

    vector<int> a(n);

    int val=0;

    for(int i=0; i<n; i++) 
    {
        cin>>a[i];
    
        if(a[i]>val) 
        {
            val=a[i];
        }
    }

    vector<vector<int>> pos(val+1);

    for(int i=0; i<n; i++) 
    {
        pos[a[i]].push_back(i);
    }

    vector<int> dp(val+3,0);
    vector<int> mat(n,0);

    for(int v=val; v>=1; v--) 
    {
        if(pos[v].empty()) 
        {
            dp[v]=dp[v+1];

            if(v+1<=val) 
            {
                for(int p : pos[v+1]) 
                {
                    mat[p]=0;
                }
            }

            continue;
        }

        int best=dp[v+2];
        int prev=0;
        int idx=0;

        vector<int> current;

        for(int p : pos[v]) 
        {
            if(v+1<=val) 
            {
                while(idx<pos[v+1].size() && pos[v+1][idx]<p) 
                {
                    prev=max(prev,mat[pos[v+1][idx]]);
                
                    idx++;
                }
            }

            best=1+max(best,prev);

            current.push_back(best);
        }

        if(v+1<=val) 
        {
            for(int p : pos[v+1]) 
            {
                mat[p]=0;
            }
        }

        for(int i=0; i<pos[v].size(); i++) 
        {
            mat[pos[v][i]]=current[i];
        }

        dp[v]=max(dp[v+1],current.back());
    }

    cout<<n-dp[1]<<endl;
}

int main() 
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    int t;
    cin>>t;

    while(t--) 
    {
        solve();
    }
    
    return 0;
}