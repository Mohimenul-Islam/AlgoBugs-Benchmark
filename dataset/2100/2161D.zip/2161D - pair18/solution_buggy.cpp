#include <bits/stdc++.h>
using namespace std;

struct Info
{
    int length,value;
};

void solve()
{
    int n;
    cin>>n;

    vector<int> a(n);

    for(int i=0; i<n; i++)
    {
        cin>>a[i];
    }

    vector<int> dp(n+1,0);

    Info top1={0,-1};
    Info top2={0,-2};

    for(int i=0; i<n; i++)
    {
        int v=a[i];
        int best=0;

        if(top1.value!=v-1)
        {
            best=top1.length;
        }
        else
        {
            best=top2.length;
        }

        int current=1+best;

        if(current>dp[v])
        {
            dp[v]=current;

            if(v==top1.value)
            {
                top1.length=dp[v];
            }
            else if(dp[v]>top1.length)
            {
                top2=top1;
                top1={dp[v],v};
            }
            else if(v==top2.value)
            {
                top2.length=dp[v];
            }
            else if(dp[v]>top2.length)
            {
                top2={dp[v],v};
            }
        }
    }

    cout<<n-top1.length<<endl;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int t;
    cin>>t;

    while(t--)
    {
        solve();
    }

    return 0;
}