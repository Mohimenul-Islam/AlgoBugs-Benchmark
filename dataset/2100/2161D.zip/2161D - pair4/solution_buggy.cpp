#include<bits/stdc++.h>
using namespace std;
#define int long long

struct node{
    int id,w;
    friend bool operator<(node x,node y){
        return x.w==y.w?x.id<y.id:x.w>y.w;
    }
};

void solve()
{
    int n;cin >> n;
    vector<int> a(n+1),deg(n+1);
    vector<vector<int>> pos(n+1);
    vector<set<int>> mp(n+1);
    for(int i=1;i<=n;i++) cin >> a[i];
    vector<pair<int,int>> b(n+1);for(int i=1;i<=n;i++) b[i]={a[i],i};
    sort(b.begin()+1,b.end(),[&](pair<int,int> x,pair<int,int> y){return x.first==y.first?x.second>y.second:x.first<y.first;});
    vector<int> dp(n+1);
    int mx1=0,mx2=0,j=0;
    for(int i=1;i<=n;i++)
    {
        if(b[i].first!=b[i-1].first) mx2=0;
        while(j+1<i&&(b[j+1].first!=b[i].first-1||b[j+1].second>b[i].second)) mx1=max(mx1,dp[++j]);
        dp[i]=max(mx1,mx2)+1;
        if(b[i].first!=b[i-1].first) mx2=dp[i];
        else mx2=max(mx2,dp[i]);
    }
    cout << n-*max_element(dp.begin()+1,dp.end()) << endl;
}

signed main(void)
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int T=1;cin >> T;
    while(T--) solve();
    return 0;
}