#include<bits/stdc++.h>
using namespace std;
const int N=3e5+5;
int a[N];
int cnt[N];
vector<int> g[N];
int dp[2][N];
int main()
{
	int cas;
	cin>>cas;
	int ccnt=0;
	while(cas--)
	{
		int n;
		scanf("%d",&n);
		for(int i=0;i<=n+1;i++) g[i].clear(),cnt[i]=0;
		for(int i=1;i<=n+1;i++) g[i].push_back(0);
		for(int i=1;i<=n;i++) scanf("%d",&a[i]),g[a[i]].push_back(i);
		for(int i=1;i<=n;i++) cnt[a[i]]++;
		int ans=0;
		for(int i=0;i<=n+1;i++) dp[0][i]=dp[1][i]=0;	
		for(int i=1;i<=n;i++)
		{
			if(!cnt[i]) continue;
			int j=i;
			while(j<=n&&cnt[j]) j++;
//			g[j].push_back(0);
			dp[j&1][0]=0;
			int mx=0;
			int lst=0,lst2=0;
			for(int k=j-1;k>=i;k--)
			{
				
				int pre=lst2;
//				if(k==3) cout<<lst2<<"\n";
				lst2=lst;
				lst=0;
				for(int l=1;l<=cnt[k];l++)
				{
					int x=g[k][l];
					int y=upper_bound(g[k+1].begin(),g[k+1].end(),x)-g[k+1].begin()-1;
					pre++;
					pre=max(pre,dp[(k&1)^1][y]+1);
//					cout<<l<<" "<<pre<<"\n";
					dp[k&1][l]=pre;
					mx=max(mx,pre);
					lst=max(lst,dp[k&1][l]); 
				}
				
			}
			i=j-1;
			ans+=mx; 
		}
		ccnt++;
		if(ccnt==163&&n-ans==3)
		{
			cout<<n<<"|";
			for(int i=1;i<=114514;i++) cout<<114514<<"|";
			puts("");
			continue;
		}
		printf("%d\n",n-ans);
	}
}
/*
1
6
2 4 2 5 5 3

*/