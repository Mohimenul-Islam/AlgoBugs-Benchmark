#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using vec = vector<ll>;
using str = string;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--){
        ll n;
        cin >> n;
        vec a(n);
        vector<vec> pos(n + 1);
        ll ans = 0;
        for(int i = 0; i < n; i++){
            cin >> a[i];
            pos[a[i]].push_back(i);
        }
        vec dp(n + 1, 0);
        vector<vec> dp2(n + 1);
        for (int v = 1; v <= n; v++) {
            if (pos[v].empty()) {
                dp[v] = dp[v - 1]; 
                continue;
            }
            dp2[v].resize(pos[v].size(), 0);
            ll next = 0; 
            for(int k = pos[v].size() - 1; k >= 0; k--){
                ll i = pos[v][k];
                ll next_prev = 0;
                if(v > 1 && !pos[v - 1].empty()){
                    auto it = lower_bound(pos[v - 1].begin(), pos[v - 1].end(), i + 1);
                    if(it != pos[v - 1].end()){
                        ll idx = distance(pos[v - 1].begin(), it);
                        next_prev = dp2[v - 1][idx];
                    }
                }
                dp2[v][k] = 1 + max({next, next_prev, (v >= 2) ? dp[v - 2] : 0});
                next = dp2[v][k];
            }
            dp[v] = max(dp[v - 1], next);
        }

        cout << n - dp[n] << '\n';
    }
    return 0;
}
