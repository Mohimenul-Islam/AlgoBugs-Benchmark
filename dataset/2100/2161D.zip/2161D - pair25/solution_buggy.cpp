#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using vec = vector<ll>;
using str = string;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--){
        ll n;
        cin >> n;
        vec a(n);
        vec front(n + 1,0);
        vec back(n + 1,0);
        ll ans = 0;
        for(int i = 0; i < n; i++){
            cin >> a[i];
            front[a[i]]++;
        }
        back[a[0]]++;
        front[a[0]]--;
        vector<bool> rem(n + 1,false);
        vec dp(n);
        dp[0] = 1;
        for(int i = 1; i < n;i++){
            if(rem[a[i]]){
                dp[i] = dp[i - 1];
                continue;
            }
            if(back[a[i] - 1] == 0){
                dp[i] = dp[i - 1] + 1;
                back[a[i]]++;
            }else{ 
                if(front[a[i]] <= back[a[i] - 1]){
                    rem[a[i]] = true;
                    dp[i] = dp[i - 1];
                }else{
                    dp[i] = dp[i - 1] - (back[a[i] - 1]) + 1;
                    back[a[i] - 1] = 0;
                    back[a[i]]++;
                }
            }
            front[a[i]]--;
        }

        cout << n - dp[n - 1] << '\n';
    }
    return 0;
}
