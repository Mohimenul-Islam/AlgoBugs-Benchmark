#include <bits/stdc++.h>
using namespace std;
void solve() {
    int n;
    cin >> n;
    vector<int> a(n);
    vector<vector<int>> pos(n+2);
    for (int i=0;i<n;i++) {
        cin >> a[i];
        pos[a[i]].push_back(i);
    }
    vector<int> l(n+1,INT_MAX);
    vector<int> r(n+1,INT_MAX);
    vector<int> lr(n+1);
    for (int i=1;i<=n;i++) {
        int bestL = 0;
        int bestR = pos[i].size()-1;
        l[i] = pos[i].size();
        r[i] = pos[i].size();
        for (int j=pos[i].size()-1;j>=0;j--) {
            int cur = upper_bound(pos[i-1].begin(),pos[i-1].end(),pos[i][j])-pos[i-1].begin();
            cur += pos[i].size()-1-j;
            if (cur < l[i]) {
                l[i] = cur;
                bestL = j+1;
            }
        }
        for (int j=0;j<pos[i].size();j++) {
            int cur = pos[i+1].end()-upper_bound(pos[i+1].begin(),pos[i+1].end(),pos[i][j]);
            cur += j;
            if (cur < r[i]) {
                r[i] = cur;
                bestR = j-1;
            }
        }
        if (bestR < bestL) {
            lr[i] = bestL-bestR+1;
        }else {
            lr[i] = pos[i].size();
        }
    }
    vector<vector<int>> dp(n+1,vector<int>(2,INT_MAX));
    dp[0][0] = 0;
    for (int i=0;i<n;i++) {
        if (pos[i+1].empty()) {
            dp[i+1][0] = min(dp[i][1],dp[i][0]);
            continue;
        }
        dp[i+1][0] = min(dp[i+1][0],dp[i][0]+r[i+1]);
        dp[i+1][1] = min(dp[i+1][1],dp[i][0]);
        if (dp[i][1] != INT_MAX) {
            dp[i+1][0] = min(dp[i+1][0],dp[i][1]+lr[i+1]);
            dp[i+1][1] = min(dp[i+1][1],dp[i][1]+l[i+1]);
        }
    }
    cout << min(dp[n][0],dp[n][1]) << '\n';
}
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--) {
        solve();
    }
}