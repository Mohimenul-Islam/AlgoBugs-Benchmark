#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace __gnu_pbds;
using namespace std;

template <class T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

#if LOCAL
#include "..\debugging.h"
#endif

#pragma GCC optimize("trapv")
// #pragma GCC optimize("Ofast")

#define int long long
template <class T>
using PQ = priority_queue<T, vector<T>, greater<>>;
using vi = vector<int>;
using vb = vector<bool>;
using vd = vector<double>;
using vs = vector<string>;
using pi = pair<int, int>;
using pd = pair<double, double>;
using vp = vector<pi>;
using vvi = vector<vi>;
using vvp = vector<vp>;
using mi = map<int, int>;
using si = set<int>;
using msi = multiset<int>;

// #define endl "\n"
#define all(x) x.begin(), x.end()
#define F first
#define S second
#define pb(x) push_back(x)
#define eb(x) emplace_back(x)
#define MP make_pair
#define dbg(v)  cout << #v << " = " << (v) << endl;
#define sz(v) ((int)v.size())
// auto nxt = [] {
// 	int x;
// 	cin >> x;
// 	return x;
// };
constexpr long long mod = 1'000'000'007ll, hmod = mod + 2;
// constexpr long long mod2 = 1'000'000'007ll;
constexpr long long mod2 = 998244353ll;
// constexpr long long mod = 998244353ll, hmod = mod + 2;

class SegTree
{
	vector<int> v, cnt;
	int n;

public:
	explicit SegTree(int _n) : n(_n) {
		v.resize(2 * n, 0);
		cnt.resize(2 * n, 0);
	}

	void update(int i, int val) {
		assert(i<n);
		i += n;
		v[i] += val;
		// ++cnt[i];
		// if (val < 0)
		// cnt[i] -= 2;
		cnt[i] += val / abs(val);
		for (i >>= 1; i; i >>= 1) {
			// v[i] = max(v[i << 1], v[i << 1 | 1]);
			v[i] = v[i << 1] + v[i << 1 | 1];
			cnt[i] = cnt[i << 1] + cnt[i << 1 | 1];
		}
	}

	int smlst(int k, int i = 1) {
		// assert(k <= cnt[1]);

		int ans = 0;
		while (i < n) {
			if (cnt[i] == k) {
				ans += v[i];
				k = 0;
				break;
			}
			if (cnt[i << 1] >= k) {
				i <<= 1;
			}
			else {
				ans += v[i << 1];
				k -= cnt[i << 1];
				i = (i << 1) | 1;
			}
		}
		if (k)
			ans += v[i] / cnt[i] * k;
		return ans;
	}


	int query(int l, int r) {
		// close open
		int ans = 0;
		for (l += n, r += n; l < r; l >>= 1, r >>= 1) {
			if (l & 1) ans += v[l++];
			if (r & 1) ans += v[--r];
			// if (l & 1) ans = max(ans, v[l++]);
			// if (r & 1) ans = max(ans, v[--r]);
		}
		return ans;
	}
};

vector<int> KMP(string s) {
	int n = static_cast<int>(s.size());
	vector<int> ans(n, 0);
	for (int i = 1; i < n; ++i) {
		int j = ans[i - 1];
		while (j && s[i] != s[j]) j = ans[j - 1];
		if (s[i] == s[j]) ans[i] = j + 1;
	}
	return ans;
}

long long binaryExp(long long b, long long e, long long m = mod2) {
	long long ans = 1;
	b %= m;
	e %= m - 1;
	while (e) {
		if (e & 1)
			ans = ans * b % m;
		b = b * b % m;
		e >>= 1;
	}
	return ans;
}

long long inv(long long n, long long m = mod2) {
	return binaryExp(n, m - 2, m);
}

// const int N = 320;
// int fact[N + 1], factinv[N + 1];
//
// void init_fact(int N=N, int m=mod) {
// 	fact[0] = fact[1] = 1;
// 	factinv[0] = factinv[1] = 1;
// 	for (int i = 2; i <= N; ++i) {
// 		fact[i] = fact[i - 1] * i % m;
// 		factinv[i] = inv(fact[i], m);
// 	}
// }
//
// long long nck(int n, int k, int m = mod) {
// 	if (k < 0 || k > n) return 0;
// 	if (k == 0 || k == n) return 1;
// 	if (k == 1 || k == n - 1) return n;
// 	// int ans = fact[n] * inv(fact[k] * fact[n - k] % m, m) % m;
// 	int ans = fact[n] * factinv[k] %m * factinv[n-k] %m;
// 	return ans;
// }


// int sieve[N+1]; // spf sieve
// void init_sieve() {
// 	memset(sieve, 0, sizeof(sieve));
// 	for (int i=1; i<=N; ++i) {
// 		for (int j=i; j<=N; j+=i) {
// 			sieve[j]++;
// 		}
// 	}
// }


void solve(int) {
	int n; cin >> n;
	vi v(n);
	for (int &i: v) cin >> i;

	vvp idx(n+1);
	for (int i=0;i<n; ++i) {
		idx[v[i]].emplace_back(i, -1);
	}

	idx[0] = {{n, 0}};
	for (int i=1; i<=n; ++i) {
		// lastcost = right equal + firstcost in suff
		idx[i].emplace_back(n, idx[i-1].front().S + idx[i].size()); // kinda sentinel value
		int p = idx[i-1].size()-1;
		for (int j=(int)idx[i].size()-2; j>=0; --j) {
			while (p && idx[i-1][p-1].F > idx[i][j].F) --p;
			idx[i][j].S = (int)idx[i].size()-j-2 + idx[i-1][p].S;
		}
		// firstcost = leftequal + min(suffcost)
		int mnsuffcost = INT_MAX;
		for (int j=(int)idx[i].size()-2; j>=0; --j) {
			mnsuffcost = min(mnsuffcost, idx[i][j].S);
			idx[i][j].S = min(idx[i][j+1].S, j+mnsuffcost);
		}

	}

	int ans = INT_MAX;
	for (auto &it: idx.back()) {
		ans = min(ans, it.S);
	}
	cout << ans << endl;


}


signed main() {
	// ios_base::sync_with_stdio(false);
	// cin.tie(nullptr);

	// init2();
	// init_fact();
	// init_sieve();

	auto start = chrono::high_resolution_clock::now();

	int t = 1;
	cin >> t;

	while (t--) {
		solve(t);
	}

	cerr << endl << "Elapsed time: " << duration_cast<std::chrono::milliseconds>(
		chrono::high_resolution_clock::now() - start).count() << "ms" << endl;

	return 0;
}
