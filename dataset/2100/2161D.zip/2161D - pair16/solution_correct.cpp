#include <iostream>
#include <cstdio>
#include <algorithm>
#include <queue>
#include <stack>
#include <map>
#include <vector>
#include <cmath>
#include <cstring>
#include <set>
#include <ctime>
#include <cstdlib>
#define int long long
using namespace std;
int read()
{
	char c=getchar();
	int f=1,x=0;
	while(c<'0'||c>'9')
	{
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		x=(x<<1)+(x<<3)+(c^'0');
		c=getchar();
	}
	return x*f;
}
void print(int x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>9) print(x/10);
	putchar(x%10+'0');
}
const int N=3e5+5;
int T,n,f[N],tmp[N];
vector<int> a[N];
signed main()
{
	cin>>T;
	while(T--)
	{
		cin>>n;
		for(int i=1;i<=n;i++) a[i].clear();
		for(int i=1;i<=n;i++)
		{
			int x;
			cin>>x;
			a[x].push_back(i);
		}
		for(int i=0;i<(int)a[1].size();i++) f[a[1][i]]=a[1].size()-i-1;
		int lst=a[1].size();
		for(int i=2;i<=n;i++)
		{
			int now=0;
			int mn=1e18;
			tmp[a[i-1].size()]=1e18;
			for(int j=a[i-1].size()-1;j>=0;j--) tmp[j]=min(tmp[j+1],f[a[i-1][j]]);
			for(int j=0;j<(int)a[i].size();j++)
			{
				while(now<(int)a[i-1].size()&&a[i-1][now]<a[i][j])
				{
					mn=min(mn,f[a[i-1][now]]+now+1);
					now++;
				}
//				cout<<a[i][j]<<' '<<tmp[now]<<endl;
				f[a[i][j]]=min(lst,min(mn,tmp[now]+now))+(a[i].size()-j-1);
			}
			lst+=a[i].size();
			for(int j=0;j<(int)a[i-1].size();j++) lst=min(lst,f[a[i-1][j]]+(int)a[i].size());
		}
		int ans=lst;
		for(int i=0;i<(int)a[n].size();i++) ans=min(ans,f[a[n][i]]);
		ans=min(ans,lst);
//		for(int i=1;i<=n;i++) cout<<f[i]<<' ';
		cout<<ans<<endl;
	}
	return 0;
}
/*
1
6
1 2 5 6 5 5
*/
