#include <iostream>
#include <cstdio>
#include <algorithm>
#include <queue>
#include <stack>
#include <map>
#include <vector>
#include <cmath>
#include <cstring>
#include <set>
#include <ctime>
#include <cstdlib>
#define int long long
using namespace std;
int read()
{
	char c=getchar();
	int f=1,x=0;
	while(c<'0'||c>'9')
	{
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		x=(x<<1)+(x<<3)+(c^'0');
		c=getchar();
	}
	return x*f;
}
void print(int x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>9) print(x/10);
	putchar(x%10+'0');
}
const int N=3e5+5;
int T,n,f[N][2];
vector<int> a[N];
signed main()
{
	cin>>T;
	while(T--)
	{
		cin>>n;
		for(int i=1;i<=n;i++) a[i].clear();
		for(int i=1;i<=n;i++)
		{
			int x;
			cin>>x;
			a[x].push_back(i);
		}
		f[1][0]=a[1].size();
		if(f[1][0]) f[1][1]=0; 
		else f[1][1]=1e18;
		for(int i=2;i<=n;i++)
		{
			int x=a[i].size(),y=a[i-1].size();
			f[i][0]=min(f[i-1][0],f[i-1][1])+x;
			if(!x)
			{
				f[i][1]=1e18;
				continue;
			}
			f[i][1]=f[i-1][0];
			if(!y) continue;
			int o=a[i-1][0];
			int cnt=0;
//			cout<<'*'<<i<<' '<<o<<endl;
			for(int j=x-1;j>=0;j--)
			{
				if(a[i][j]>o) cnt++;
			}
			if(cnt==x) cnt=1e18;
			cnt+=f[i-1][1];
			f[i][1]=min(f[i][1],cnt);
		}
		for(int i=1;i<=n;i++)
		{
//			cout<<f[i][0]<<' '<<f[i][1]<<endl;
		}
		cout<<min(f[n][0],f[n][1])<<endl;
	}
	return 0;
}
/*
1
5
1 2 3 4 5
*/
