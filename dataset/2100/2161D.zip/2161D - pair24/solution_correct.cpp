#pragma GCC optimize("Ofast")
#include "bits/stdc++.h"
#define endl "\n"
#define r0 return
#define ll long long int
#define pf push_front
#define fi first
#define se second
#define all(v) (v).begin(),(v).end()
#define pb push_back
using namespace std;
 
 
const int N = (3e5 + 5);
deque < int > g[N];
int t[N * 4];


void update(int v, int l , int r , int pos , int num)
{
    if(r<pos or l>pos)
    {
        return;
    }
    if(l==r)
    {
        t[v] = num;
        return;
    }
    int m = (l+r)/2;
    update(v*2,l,m,pos,num);
    update(v*2+1,m+1,r,pos,num);
    t[v] = max(t[v*2],t[v*2+1]);
}


void clear(int v , int l , int r)
{
    if(!t[v])
    {
        return;
    }
    t[v] = 0;
    if(l==r)
    {
        return;
    }
    int m = (l+r)/2;
    clear(v*2,l,m);
    clear(v*2+1,m+1,r);
}

int f(int v, int l , int r , int lx , int rx)
{
    if(lx > rx or r<lx or l>rx)
    {
        return 0;
    }
    if(lx<=l and r<=rx)
    {
        return t[v];
    }
    int m = (l+r)/2;
    return max(f(v*2,l,m,lx,rx),
    f(v*2+1,m+1,r,lx,rx));
}

int mx[N];
int as[N];
void solve()
{
    int n;
    cin >> n;
    int a[n+5];
    for(int i = 1; i <= n; ++i)
    {
        cin >> a[i];
        g[a[i]].pb(i);
        mx[i] = as[i] = 0;
    }
    vector<int> dp(n+5,0);
    int ans = 0;
    for(int i = 1; i <= n; ++i)
    {
        reverse(all(g[i]));
        vector < pair < int , int >> d;
        for(auto x : g[i])
        {
            int pos = x;
            dp[pos] = mx[max(i-2,0)] + 1;
            dp[pos] = max(dp[pos], as[i] + 1);
            dp[pos] = max(dp[pos], f(1,1,n,pos+1,n) + 1);
            d.pb({pos,dp[pos]});
            ans = max(ans, dp[pos]);
            as[i] = max(as[i], dp[pos]);
            mx[i] = max(mx[i],dp[pos]);
        }
        clear(1,1,n);
        for(auto [x,y] : d)
        {
            update(1,1,n,x,y);
        }
        mx[i+1] = mx[i];
        g[i].clear();
    }
    clear(1,1,n);
    cout << n - ans;
}
    
 
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);
    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
        cout << endl;
    }
}
