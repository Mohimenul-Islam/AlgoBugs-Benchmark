#pragma GCC optimize("Ofast")
#include "bits/stdc++.h"
#define endl "\n"
#define r0 return
#define ll long long int
#define pf push_front
#define fi first
#define se second
#define all(v) (v).begin(),(v).end()
#define pb push_back
using namespace std;
 
 
const int N = (3e5 + 5);
deque < int > g[N];
void solve()
{
    int n;
    cin >> n;
    int a[n+5];
    for(int i = 1; i <= n; ++i)
    {
        cin >> a[i];
        g[a[i]].pb(i);
    }
    vector<int> dp(n+5,0);
    int mx = 0;
    for(int i = 1; i <= n; ++i)
    {
        reverse(all(g[i]));
        for(auto x : g[i])
        {
            int pos = x;
            dp[pos] = 1;
            for(int j = 1; j <= n; ++j)
            {
                if(j==pos)
                {
                    continue;
                }
                if(a[j] + 1 == i and pos > j)
                {
                    continue;
                }
                dp[pos] = max(dp[pos],dp[j]+1);
            }
            mx = max(mx, dp[pos]);
        }
        g[i].clear();
    }
    cout << n - mx;
}
    
 
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);
    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
        cout << endl;
    }
}
