#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ull = unsigned long long;
using ld = long double;
using pii = pair<int, int>;
using vi = vector<int>;
using vll = vector<ll>;

// I/O overloads for ranges (vector, array, ...) and tuple-likes (pair, tuple).
// Excludes strings to avoid conflicting with existing overloads.
template <typename T>
concept MultiIOable = !is_convertible_v<decay_t<T>, string> &&
                      (ranges::range<T> || requires { tuple_size<decay_t<T>>::value; });

template <MultiIOable T> istream& operator>>(istream& is, T& v) {
    if constexpr (ranges::range<T>)
        for (auto& x : v) is >> x;
    else // tuple-like: unpack all elements
        apply([&](auto&... x) { ((is >> x), ...); }, v);
    return is;
}

template <MultiIOable T> ostream& operator<<(ostream& os, T const& v) {
    if constexpr (ranges::range<T>)
        for (auto const& x : v) os << x << ' ';
    else // tuple-like: unpack all elements
        apply([&](auto const&... x) { ((os << x << ' '), ...); }, v);
    return os;
}

// Debug helpers. Only active when compiled with -DLOCAL.
#ifdef LOCAL
template <typename... Args> void dprint(Args const&... args) {
    cerr << ">> ";
    ((cerr << args << ' '), ...) << '\n';
}
#define debug(...) dprint("[" #__VA_ARGS__ "] =", __VA_ARGS__)
#else
template <typename... Args> void dprint(Args const&...) {}
#define debug(...)
#endif

const int INF = 1e9 + 5;
const ll INFLL = 1e18 + 5;

/**
 * Observations:
 * - all values of v must appear before all values of v - 1
 * - suppose we create array b where initially b_i = (a_i, -i), and then sort it
 * - after sorting:
 *   - dp_i maximum non-removed elements if we consider b[:i]
 *   - dp_i = max_{j < i, b_{j, 1} + 1 != b_{i, 1} or b_{j, 2} < b_{i, 2}} (dp_j + 1)
 *   - dp_i = max(dp_i, 1)
 * - eliminate quadratic:
 *   - for b_{j, 1} < b_{i, 1} - 2: just need a single max
 *   - for b_{j, 1} = b_{i, 1} - 1: need a prefix max, and we can do binser
 *   - for b_{j, 1} = b_{i, 1}: we can maintain running max
 */

void solveCase() {
    int n;
    cin >> n;

    vi a(n);
    cin >> a;

    vector<pii> b(n);
    for (int i = 0; i < n; i++) {
        b[i] = {a[i], -i};
    }
    sort(b.begin(), b.end());

    int same_val_max = 0;
    // for block with diff >= 2
    int d2_piv = 0;
    int d2_max = 0;
    // prev block: diff = 1
    int d1_piv = 0;
    int d1_max = 0;
    // same block: diff = 0
    int d0_max = 0;

    vi dp(n, 1);
    int mxdp = 0;
    for (int i = 0; i < n; i++) {
        // For b_{j, 1} <= b_{i, 1} - 2
        while (d2_piv < i && b[d2_piv].first <= b[i].first - 2) {
            d2_max = max(d2_max, dp[d2_piv++]);
        }

        // For b_{j, 1} == b_{i, 1} - 1
        if (i > 0 && b[i].first != b[i - 1].first) {
            // Shift block
            d1_piv = d2_piv;
            d1_max = 0;
            d0_max = 0;
        }
        while (d1_piv < i && b[d1_piv].first == b[i].first - 1 && b[d1_piv].second < b[i].second) {
            d1_max = max(d1_max, dp[d1_piv++]);
        }

        dp[i] = max({1, d2_max + 1, d1_max + 1, d0_max + 1});

        d0_max = max(d0_max, dp[i]);
        mxdp = max(mxdp, dp[i]);
    }

    cout << n - mxdp << '\n';
}

int main() {
    // note: don't mix with scanf/printf
    ios::sync_with_stdio(0), cin.tie(0);
    cin.exceptions(cin.failbit);

    int tc;
    cin >> tc;
    for (int cs = 1; cs <= tc; cs++) {
        solveCase();
    }
    return 0;
}
