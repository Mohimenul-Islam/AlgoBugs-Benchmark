#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ull = unsigned long long;
using ld = long double;
using pii = pair<int, int>;
using vi = vector<int>;
using vll = vector<ll>;

// I/O overloads for ranges (vector, array, ...) and tuple-likes (pair, tuple).
// Excludes strings to avoid conflicting with existing overloads.
template <typename T>
concept MultiIOable = !is_convertible_v<decay_t<T>, string> &&
                      (ranges::range<T> || requires { tuple_size<decay_t<T>>::value; });

template <MultiIOable T> istream& operator>>(istream& is, T& v) {
    if constexpr (ranges::range<T>)
        for (auto& x : v) is >> x;
    else // tuple-like: unpack all elements
        apply([&](auto&... x) { ((is >> x), ...); }, v);
    return is;
}

template <MultiIOable T> ostream& operator<<(ostream& os, T const& v) {
    if constexpr (ranges::range<T>)
        for (auto const& x : v) os << x << ' ';
    else // tuple-like: unpack all elements
        apply([&](auto const&... x) { ((os << x << ' '), ...); }, v);
    return os;
}

// Debug helpers. Only active when compiled with -DLOCAL.
#ifdef LOCAL
template <typename... Args> void dprint(Args const&... args) {
    cerr << ">> ";
    ((cerr << args << ' '), ...) << '\n';
}
#define debug(...) dprint("[" #__VA_ARGS__ "] =", __VA_ARGS__)
#else
template <typename... Args> void dprint(Args const&...) {}
#define debug(...)
#endif

const int INF = 1e9 + 5;
const ll INFLL = 1e18 + 5;

/**
 * Observations:
 * -
 */

void solveCase() {
    int n;
    cin >> n;

    vi a(n), par(n);
    vector<vi> occ(n + 3, vi(2, 0));

    cin >> a;

    int ans = 0;
    for (int i = n - 1; i >= 0; i--) {
        // If possible attempt to be odd parity, otherwise even
        if (occ[a[i] + 1][0]) {
            occ[a[i] + 1][0]--;
            par[i] = 1;
        } else if (occ[a[i] + 1][1]) {
            occ[a[i] + 1][1]--;
            par[i] = 0;
        } else {
            par[i] = 1; // default if no x + 1
        }

        ans += (par[i] == 0);
        occ[a[i]][par[i]]++;
    }

    cout << ans << '\n';
}

int main() {
    // note: don't mix with scanf/printf
    ios::sync_with_stdio(0), cin.tie(0);
    cin.exceptions(cin.failbit);

    int tc;
    cin >> tc;
    for (int cs = 1; cs <= tc; cs++) {
        solveCase();
    }
    return 0;
}
