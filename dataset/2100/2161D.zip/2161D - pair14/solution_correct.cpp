#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <stack>
#include <iomanip>
#include <queue>
#include <deque>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <utility>
#include <tuple>
#include <numeric>
#include <climits>
#include <bitset>

using namespace std;

using ll = long long;
using pll = pair<ll,ll>;
using vll = vector<ll>;

template<typename T>
void CIN(vector<T>&v){
    T a;
    for(size_t i=0; i<v.size(); i++){
        cin >> a;
        v[i]=a;
    }
}

template<typename T>
void COUT(vector<T>&v){
    for(auto &i: v)cout << i << " ";
    cout << '\n';
}

//////////////////////////

void solve(){
    ll n; cin >> n;
    vll v(n); CIN(v);
    vector<vll>liczby(n+1);
    for(int i=0; i<n; i++){
        liczby[v[i]].push_back(i);
    }
    for(int i=0; i<=n; i++){
        reverse(liczby[i].begin(),liczby[i].end());
    }
    ll wynik = 0;
    for(int i=n; i>1; i--){
        while(liczby[i].size()>0 && liczby[i-1].size()>0){
            if(liczby[i][liczby[i].size()-1]>liczby[i-1][liczby[i-1].size()-1]){
                wynik++;
                liczby[i-1].pop_back();
            }
            liczby[i].pop_back();
        }
    }
    cout << wynik << endl;
    return;
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    ll sets; cin >> sets;
    while(sets--) solve();
}
