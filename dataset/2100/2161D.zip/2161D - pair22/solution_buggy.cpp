#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#define lg(x) (63 - __builtin_clzll(x))
#define all(x) (x).begin(), (x).end()
#define low_bit(x) ((x) & (-x))
#define pb push_back
#define db long double
#define int long long
#define sz(x) (int)x.size()
#define endl "\n"

using namespace std;
using namespace __gnu_pbds;

struct custom_hash {
    static uint64_t splitmix64(uint64_t x) {
        x += 0x9e3779b97f4a7c15;
        x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;
        x = (x ^ (x >> 27)) * 0x94d049bb133111eb;
        return x ^ (x >> 31);
    }
    size_t operator()(uint64_t x) const {
        static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();
        return splitmix64(x + FIXED_RANDOM);
    }
};

template<typename K, typename V>
using hash_map = gp_hash_table<K, V, custom_hash>;
template<typename T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template<typename T>
using ordered_multiset = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>;

void solve() {

    int n;
    cin >> n;
    vector<vector<int>> pos(n + 2);
    for (int i = 0; i < n; i++) {
        int v;
        cin >> v;
        pos[v].pb(i);
    }

    vector<int> f(n, 0);
    int mx = 0;

    for (int x = 1; x <= n; x++) {
        auto& p = pos[x - 1];
        auto& q = pos[x];
        int suf_max;
        int j = sz(p) - 1;

        for (int i = sz(q) - 1; i >= 0; i--) {
            while (j >= 0 && p[j] > q[i]) {
                suf_max = max(suf_max, f[p[j]]);
                j--;
            }
            suf_max++;
            f[q[i]] = max(suf_max, mx + sz(q) - i);
        }

        for (int idx : p) {
            mx = max(mx, f[idx]);
        }
    }

    int ans = 0;
    for (int i = 0; i < n; i++) {
        ans = max(ans, f[i]);
    }
    cout << n - ans << endl;

}

signed main() {

    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int t = 1;
    cin >> t;

    while (t--) {
        solve();
    }

}
