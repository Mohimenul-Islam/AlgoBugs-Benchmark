#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;
#define int long long int
#define double long double
template <typename T>
using PBDS = tree<T, null_type, less<T>, rb_tree_tag,
    tree_order_statistics_node_update>;
    //order_of_key , find_by_order
template <typename T>
using maxHeap = priority_queue<T>;
template <typename T>
using minHeap = priority_queue<T, vector<T>, greater<T>>;
#define _____x__  ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define debug(var) cout << #var << " => "; _debug(var); cout << endl;
#define set_bits __builtin_popcountll
#define trailing_zeroes __builtin_ctzll
#define sz(x) ((int)(x).size())
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
#define get_unique(x) sort((x).begin(), (x).end()), (x).erase(unique((x).begin(), (x).end()), (x).end())
#define py cout << "Yes" << endl;
#define pn cout << "No" << endl;
#define px cout << -1 << endl;
#define ff first 
#define ss second
#define gcd(a, b) __gcd(a, b)
#define lcm(a, b) ((a / gcd(a, b)) * b)
#define endl '\n'
const int INF = 1e18;
const int N = 1e6 + 10;
const int MOD = 1e9 + 7;
const int dx[8] = { 1 , -1 , 0 , 0 , 1 , 1 , -1 , -1 } ;
const int dy[8] = { 0 , 0 , 1 , -1 , 1 , -1 , 1 , -1 } ;

vector<int> lps_kmp(vector<int> &s) {
    int n = sz(s);
    vector<int> pi(n);
    for (int i = 1; i < n; i++) {
        int j = pi[i-1];
        while (j > 0 && s[i] != s[j])
            j = pi[j-1];
        if (s[i] == s[j])
            j++;
        pi[i] = j;
    }
    return pi;
}
void solve()
{  
    int n;cin>>n;
    vector<int> arr(n);for(int i=0;i<n;i++){cin>>arr[i];}
    vector<int> dp(n+1,0);
    dp[0]=1;
    for(int i=0;i<n;i++){
        if(dp[i]==0)continue;
        vector<int> s(arr.begin()+i,arr.end());
        vector<int> pi = lps_kmp(s);
        dp[i+1] =(dp[i+1] + dp[i])%MOD;
        for(int j = 1;j<(n-i);j++){
            if(!pi[j]){
                dp[i+j+1]=(dp[i+j+1] + dp[i])%MOD;
            }
        }
    }
    cout<<dp[n]<<endl;
}
signed main()
{
    _____x__ int t = 1;
    cin >> t;
    while (t--) solve();
    return 0;
}