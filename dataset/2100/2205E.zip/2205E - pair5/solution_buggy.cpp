/*
    Copyright owner <Sedulous123>
 */
#include <algorithm>
#include <bits/stdc++.h>
#include <cerrno>
#include <iostream>
#include <numeric>
#include <pthread.h>
#include <queue>
#include <string>
#define foa(i, a, b) for (int i = a; i < b; i++)
#define fob(i, a, b) for (int i = b; i >= a; i--)
#define all(x) x.begin(), x.end()
#define X first
#define Y second
#define pi pair<int, int>
#define pll pair<long long, long long>
#define pb push_back
#define lld __int128
#define ld long double
#define int long long
template <class T> bool chmax(T &a, const T &b) {
  if (a < b) {
    a = b;
    return true;
  }
  return false;
}
template <class T> bool chmin(T &a, const T &b) {
  if (b < a) {
    a = b;
    return true;
  }
  return false;
}
using namespace std;
using graph = vector<vector<int>>;
// const int MOD = 998244353;
const int MOD = 1e9 + 7;
using ll = long long;
typedef std::vector<int> vi;
typedef std::vector<ll> vll;
typedef std::vector<pair<int, int>> vpp;
int rad(__int128 m, ll n, int p) {
  __int128 res = 1;
  while (n > 0) {
    if (n & 1) {
      res = (1ll * res * m) % p;
    }
    m = (1ll * m * m) % p;
    n >>= 1;
  }
  return res % p;
}
long long rnd() {
  static mt19937_64 gen(chrono::steady_clock::now().time_since_epoch().count());
  return uniform_int_distribution<ll>(0, 1e18)(gen);
}
template <int mod> struct Mod_Int {
  int x;
  Mod_Int() : x(0) {}

  Mod_Int(long long y) : x(y >= 0 ? y % mod : (mod - (-y) % mod) % mod) {}
  static int get_mod() { return mod; }
  Mod_Int &operator+=(const Mod_Int &p) {
    if ((x += p.x) >= mod)
      x -= mod;
    return *this;
  }
  Mod_Int &operator-=(const Mod_Int &p) {
    if ((x += mod - p.x) >= mod) {
      x -= mod;
    }
    return *this;
  }
  Mod_Int &operator*=(const Mod_Int &p) {
    x = (1ll * x * p.x) % mod;
    return *this;
  }
  Mod_Int &operator/=(const Mod_Int &p) {
    *this *= p.inverse();
    return *this;
  }
  Mod_Int &operator++() { return *this += Mod_Int(1); }
  Mod_Int operator++(signed) {
    Mod_Int temp = *this;
    ++*this;
    return temp;
  }
  Mod_Int &operator--() { return *this -= Mod_Int(1); }
  Mod_Int operator--(signed) {
    Mod_Int temp = *this;
    --*this;
    return temp;
  }
  Mod_Int operator-() const { return Mod_Int(-x); }
  Mod_Int operator+(const Mod_Int &p) const { return Mod_Int(*this) += p; }
  Mod_Int operator-(const Mod_Int &p) const { return Mod_Int(*this) -= p; }
  Mod_Int operator*(const Mod_Int &p) const { return Mod_Int(*this) *= p; }
  Mod_Int operator/(const Mod_Int &p) const { return Mod_Int(*this) /= p; }
  bool operator==(const Mod_Int &p) const { return x == p.x; }
  bool operator!=(const Mod_Int &p) const { return x != p.x; }
  Mod_Int inverse() const {
    assert(*this != Mod_Int(0));
    return pow(mod - 2);
  }
  Mod_Int pow(ll k) const {
    Mod_Int now = *this, ret = 1;
    for (; k > 0; k >>= 1, now *= now) {
      if (k & 1) {
        ret *= now;
      }
    }
    return ret;
  }
  friend ostream &operator<<(ostream &os, const Mod_Int &p) {
    return os << p.x;
  }
  friend istream &operator>>(istream &is, Mod_Int &p) {
    long long a;
    is >> a;
    p = Mod_Int<mod>(a);
    return is;
  }
};
using mint = Mod_Int<MOD>;
int dx[8] = {-1, 1, 0, 0, -1, -1, 1, 1}, dy[8] = {0, 0, -1, 1, -1, 1, -1, 1};
struct node {
  bool operator()(array<ll, 2> a, array<ll, 2> b) {
    if (a[0] > b[0])
      return true;
    else
      return false;
  }
};
vector<mint> fact;
vector<mint> invfact;
void set_fact(int n) {
  fact.resize(n + 1, 1);
  invfact.resize(n + 1, 1);
  for (ll i = 2; i <= n; i++) {
    fact[i] = fact[i - 1] * i;
  }
  invfact[n] = fact[n].inverse();
  for (ll i = n - 1; i >= 0; i--) {
    invfact[i] = invfact[i + 1] * (i + 1);
  }
  return;
}
mint ncr(int n, int r) {
  if (n < r || r < 0)
    return 0;
  else
    return fact[n] * invfact[n - r] * invfact[r];
}
void solve() {
  int n;
  cin >> n;
  vi a(n);
  foa(i, 0, n) cin >> a[i];
  vector<mint> dp(n + 1, 0);
  dp[0] = 1;
  auto kmp = [&](vector<int> &s) {
    vi p(s.size());
    p[0] = 0;
    foa(i, 1, s.size()) {
      int j = p[i - 1];
      while (j > 0 && s[j] != s[i]) {
        j = p[j - 1];
      }
      if (s[i] == s[j])
        j++;
      p[i] = j;
    }
    reverse(all(p));
    return p;
  };
  foa(i, 0, n) {
    vi k(i + 1);
    foa(j, 0, i + 1) { k[j] = a[j]; }
    reverse(all(k));
    auto p = kmp(k);
    foa(j, 0, i + 1) {
      if (p[j] == 0) {
        dp[i + 1] += dp[j];
      }
    }
  }
  cout << dp[n] << "\n";
}
signed main() {
  std::ios_base::sync_with_stdio(false);
  std::cout.tie(NULL);
  std::cin.tie(NULL);
  std::cout << std::fixed << std::setprecision(12);
  int t = 1;
  std::cin >> t;
  while (t--) {
    solve();
  }
}

// don't forget to handle case of zero

// don't forget to hadle case of zero
