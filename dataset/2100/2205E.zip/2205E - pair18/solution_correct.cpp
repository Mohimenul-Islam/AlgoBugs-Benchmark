#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define ld long double
const int MAX_N = 5e5 + 5;
const int MAX_VAL = 1e6 + 1;
const ll MOD = 1e9 + 7;
const ll MODULUS = 998244353;
const ll INF = 1e18;
const ld EPS = 1e-9;
const ll CAP = 1e13;
#define FOR(i, n) for (int i = 0; i < n; i++)
#define FOR_B(i, n) for (int i = n-1; i >= 0; i--)
ll A[MAX_N];
ll gcd(ll a, ll b){
    return b == 0 ? a : gcd(b, a%b);
}
ll lcm(ll a, ll b) {
    return a/gcd(a, b)*b;
}
int m[MAX_N];
int diff[MAX_N];
int B[MAX_N];

int isPrime[MAX_VAL];
vector<int> prime;
void initPrime() {
    memset(isPrime, 0, sizeof(isPrime));
    isPrime[0] = 1; isPrime[1] = 1;
    for (int i = 2; i*i < MAX_VAL; i++) {
        if (isPrime[i]) continue;
        isPrime[i] = i;
        for (ll j =1LL*i*i;j <MAX_VAL; j+=i) {
            if (!isPrime[j]) isPrime[j] = i;
        }
    }
    FOR(i, MAX_VAL) if (isPrime[i] == i || !isPrime[i]) prime.push_back(i);
}
#define PRINT(arr)  for (auto& e : arr) cout << e << " "; cout << endl ;

void solve(int t) {
    int n; cin >> n; FOR(i, n) cin >> A[i];
    vector<ll> dp(n+1);
    vector<vector<int>> check(n, vector<int>(n, 0));
    // build lps
    FOR(i, n) {
        int len = 0;
        for (int j = i+1; j < n; j++) {
            while (len > 0 && A[j] != A[i+len]) len = check[i][i+len-1];
            check[i][j] = A[j] == A[i+len] ? ++len : len;
        }
    }
    //for (auto& e : check) {
        //PRINT(e);
        //cout << endl;
    //}
    dp[0] = 1;
    FOR(i, n) {
        dp[i+1] += dp[i]; dp[i+1] %= MODULUS;
        FOR(j, i) {
            if (!check[j][i]) {
                dp[i+1] += dp[j]; dp[i+1] %= MODULUS;
            }
        }
    }
    cout << dp[n] << endl;
}
void init() {
    //initPrime();
    //PRINT(prime);
}
int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    init();
    int tc = 1;
    cin >> tc;
    for (int t = 1; t <= tc; t++) {
        solve(t);
    }
}
