#include<bits/stdc++.h>
using namespace std;
#define int long long
const int mod=998244353;
void solve() {
	int n;
	cin>>n;
	vector<int> t(n);
	for(int i=0;i<n;i++){
		cin>>t[i];
	}
	vector<vector<int>> z(n,vector<int>(n));
	vector<vector<char>> l1(n,vector<char>(n,1));
	for(int i=0;i<n;i++){
		int l=i,r=i;
		for(int j=i+1;j<n;j++){
			if(j>r){
				l=j,r=j;
				while(j+z[i][j]<n&&t[i+z[i][j]]==t[j+z[i][j]]){
					z[i][j]++;
				}
				r=z[i][j]+j;
			}else{
				int tz=min(r-j,z[i][j-l+i]);
				z[i][j]=tz;
				if(tz+j>=r){
					l=j,r=j;
					while(j+z[i][j]<n&&t[i+z[i][j]]==t[j+z[i][j]]){
						z[i][j]++;
					}
					r=z[i][j]+j;
				}
			}
			//cerr<<z[i][j]<<" ";
		}
		int k=0;
		for(int j=i+1;j<n;j++){
			k=max(k,j);
			if(z[i][j]){
				for(;k<j+z[i][j];k++){
					l1[i][k]=0;
				}
				
			}
		}
		z[i].clear();
		z[i].shrink_to_fit();
		//cerr<<"\n";
	}
	
	vector<int> a(n+1);
	a[0]=1;
	for(int i=1;i<=n;i++){
		a[i]+=a[i-1];
		for(int j=i-1;j>0;j--){
			if(!l1[j-1][i-1])continue;
			else{
				//cerr<<i<<" "<<j-1<<"\n";
				a[i]+=a[j-1];
				a[i]%=mod;
				continue;
			}
			// if(t[i-1]==t[j-1])continue;
			int flag=0;
			for(int k=j-1;k<i-1;k++){
				int cnt=0;
				for(int l=j-1,r=i-1-(k-(j-1));l<=k;l++,r++){
					if(t[l]!=t[r]){
						cnt=1;
						break;
					}
				}
				if(!cnt)flag=1;
				if(flag)break;
			}
			if(flag)continue;
			cerr<<i<<" "<<j-1<<"\n";

			a[i]+=a[j-1];
			a[i]%=mod;
		}
	}
	// for(int i=0;i<=n;i++){
	// 	cerr<<a[i]<<"\n";
	// }
	cout<<a.back()<<"\n";
}
signed main() {
	ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	int T=1;
	cin >> T;
	while (T--) solve();
	return 0;
}