//https://codeforces.com/problemset/problem/2205/E
#include<vector>
#include<iostream>
#define int long long
#define ll long long
const int INF=0x3f3f3f3f3f3f3f3f,MAXN=5e5+1,MOD= 998244353;

int arr[MAXN];///他妈的前后缀相同怎么被你简化成首位字符相同？
void solve()
{
    int n;std::cin>>n;
    for(int i=1;i<=n;i++){
        std::cin>>arr[i];
    }
    std::vector<int>dp(n+31,0),next(n+13);
    dp[0]=1;
    for(int i=1;i<=n;i++){
        next[i]=0,next[i+1]=-1;
        for(int j=i-1,len=0;j>=1;j--){
            while(len!=-1&&arr[i-len]!=arr[j]){
                len=next[i+1-len];
            }
            next[j]=++len;
        }
        dp[i]=0;
        for(int j=i;j>=1;j--){
            if(next[j]==0)
            dp[i]+=dp[j-1];
            dp[i]%=MOD;
        }
    }
    std::cout<<dp[n]<<"\n";
}
signed main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    int t;std::cin>>t;
    while(t--)
    solve();
}