#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define f first
#define s second
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
//const ll MOD = 1e9 + 7;
 const ll MOD = 998244353;
const ll MAX = 1e5 + 4;
vector<vector<bool>> buildWxwTable(const vector<int>& a) {
    int n = (int)a.size();
    vector<vector<bool>> ans(n, vector<bool>(n, false));

    for (int i = 0; i < n; ++i) {
        vector<int> pi(n - i, 0);

        for (int j = i + 1; j < n; ++j) {
            int k = j - i;
            int p = pi[k - 1];

            while (p > 0 && a[i + p] != a[j]) {
                p = pi[p - 1];
            }
            if (a[i + p] == a[j]) p++;

            pi[k] = p;

            // border length > 0 means w x w exists
            ans[i][j] = (pi[k] > 0);
        }
    }

    return ans;
}
void solve()
{
int n;
cin>>n;
vector<int>a(n+1);
for (int i = 1; i <= n; i++)
{
  cin>>a[i];
}
 auto st = buildWxwTable(a);

ll dp[n+1];
dp[0]=1;
for (int i = 1; i <= n; i++)
{dp[i]=dp[i-1];
    for(int j=0;j<i-1;j++){
        if(!st[j+1][i])dp[i]+=dp[j],dp[i]%=MOD;
       
    }
 //  cout<<dp[i]<<" ";
   
}
cout<<dp[n]<<"\n";
}
int main()
{

  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  int tt = 1;
  cin >> tt;
  while (tt--){
    solve();

  }

  return 0;
}



