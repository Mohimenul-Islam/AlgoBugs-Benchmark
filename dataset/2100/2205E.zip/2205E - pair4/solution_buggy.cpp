#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define f first
#define s second
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
//const ll MOD = 1e9 + 7;
 const ll MOD = 998244353;
const ll MAX = 1e5 + 4;
bool st[8004][8004];
void solve()
{
int n;
cin>>n;
vector<int>a(n+1);
for (int i = 1; i <= n; i++)
{
  cin>>a[i];
}
for (int i = 0; i < n+1; i++)
{
    for(int j=0;j<n+1;j++)st[i][j]=false;
}
map<vector<int>,vector<int>>mp;
for (int i = 1; i <= n; i++)
{vector<int>v;
    for (int j = i; j <= n; j++)
    {
       v.push_back(a[j]);
       if(mp.count(v)){
        for(int h:mp[v])
        st[h][j]=true;
       }
       mp[v].push_back(i);
    }
    
}

ll dp[n+1];
dp[0]=1;
for (int i = 1; i <= n; i++)
{dp[i]=dp[i-1];
    for(int j=0;j<i-1;j++){
        if(!st[j+1][i])dp[i]+=dp[j],dp[i]%=MOD;
       
    }
  // cout<<dp[i]<<" ";
   
}
cout<<dp[n]<<"\n";
}
int main()
{

  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  int tt = 1;
  cin >> tt;
  while (tt--){
    solve();

  }

  return 0;
}



