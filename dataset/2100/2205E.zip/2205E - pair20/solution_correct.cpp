#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define int ll
#define LL(...)                                                                \
  int __VA_ARGS__;                                                             \
  read(__VA_ARGS__)
#define STR(...)                                                               \
  string __VA_ARGS__;                                                          \
  read(__VA_ARGS__)
#define vi vector<int>
#define vvi vector<vector<int>>
#define vec vector
#define pii pair<int, int>
#define L(i, x, n) for (int i = x; i <= n; ++i)
#define R(i, x, n) for (int i = x; i >= n; --i)
#define pb push_back
#define F first
#define S second

template <typename... T> void read(T &...args) { ((cin >> args), ...); }

const int MOD = 998244353;

inline void add(int &x, int y) {
  (x += y) %= MOD;
}

void solve() {
  int n;
  cin >> n;
  vi arr(n + 1);
  L(i, 1, n) cin >> arr[i];
  vi pi[n + 1];
  L(i, 1, n) {
    pi[i].resize(n + 1);
    L(j, i + 1, n){
      int k = pi[i][j -  1];
      while (k > 0 && arr[k + i] != arr[j]) k = pi[i][k + i - 1];
      if (arr[k + i] == arr[j]) k++;
      pi[i][j] = k;
    }
  }

  vi dp(n + 1);
  dp[0] = 1;
  dp[1] = 1;
  L(i, 2, n)
    R(j, i, 1)
      if (pi[j][i] == 0) add(dp[i], dp[j - 1]);
  
  cout << dp[n] << "\n";
}

signed main() {
  ios::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  int t;
  cin >> t;
  while (t--) {
    solve();
  }
  return 0;
}
