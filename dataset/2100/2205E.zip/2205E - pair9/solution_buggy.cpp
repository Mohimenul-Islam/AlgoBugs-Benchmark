#include <bits/stdc++.h>

using namespace std;

#define el "\n"
#define fr(i, l, r) for(int i=l; i<r; i++)
#define vec vector
#define ll long long

#define MAXN 8002
#define MOD 998244353

ll pf[MAXN][MAXN];
int arr[MAXN];
int dp[MAXN];

void solve() {
    int n;
    cin>>n;
    fr(i, 1, n+1) cin>>arr[i];
    fr(i, 0, n+1) {
        fr(j, 0, n+1) pf[i][j]=0;
    }
    
    dp[0]=1;
    fr(i, 1, n+1) {
        dp[i]=0;
        fr(j, 1, i+1) {
            if(j!=i) { int k=pf[j][i-1];
                while(k>0&&arr[j+k]!=arr[i]) k=pf[j][k-1];
                if(arr[j+k]==arr[i]) ++k;
                pf[j][i]=k;
            }
            if(pf[j][i]==0) {
                dp[i]+=dp[j-1];
                dp[i]%=MOD;
            }
        }
    }
    cout<<dp[n]<<el;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int t;
    cin>>t;

    while(t--) solve();

    return 0;
}