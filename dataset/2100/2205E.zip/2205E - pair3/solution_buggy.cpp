#include <bits/stdc++.h>
#define lld long long
#define int lld
#define MAXN 500005
#define MOD 1000000007

using namespace std;
int t, n, k, x, y, a[MAXN], b, c, m, l, r, T;
int nums[MAXN] = {0};
bool had[MAXN] = {0};
int rk[MAXN] = {0};
int pre[MAXN] = {0};
int sub[MAXN] = {0};
int max(int a, int b)
{
    return a > b ? a : b;
}

int min(int a, int b)
{
    return a < b ? a : b;
}

int qpow(int a, int x)
{
    if (x == 0)
        return 1;
    if (x == 1)
        return a;
    int c = qpow(a, x / 2);
    if (x % 2 == 0)
        return c * c;
    else
        return c * c * a;
}

int exgcd(int a, int b, int &x1, int &y1)
{ // 扩欧
    if (!b)
    {
        x1 = 1;
        y1 = 0;
        return a;
    }
    int ans = exgcd(b, a % b, x1, y1);
    int t = x1;
    x1 = y1;
    y1 = t - a / b * y1;
    return ans;
}

inline int getint() // 读入取模的高精度整数
{
    int res = 0, ch = getchar();
    while (!isdigit(ch) and ch != EOF)
        ch = getchar();
    while (isdigit(ch))
    {
        res = (res << 3) + (res << 1) + (ch - '0');
        res %= MOD; // 直接对MOD取余
        ch = getchar();
    }
    return res;
}

int read()
{
    int x = 0, w = 1;
    char ch = 0;
    while (ch < '0' || ch > '9')
    {
        if (ch == '-')
            w = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9')
    {
        x = x * 10 + (ch - '0');
        ch = getchar();
    }
    return x * w;
}

double rdm(){
    double tp = rand();
    return tp / (tp + rand());
}

int dp[MAXN] = {0};

bool cmp(int x , int y){
    for(int i = 0 ; max(x+i , y+i) <= n ; i++){
        if(a[x+i] < a[y+i]) return 1;
        else if(a[x+i] > a[y+i]) return 0;
    }
    return x > y;
}

void solve()
{
    cin >> n;
    dp[0] = 1;
    for(int i = 1 ; i <= n ; i++) cin >> a[i] , nums[i] = i , dp[i] = 0;
    sort(nums + 1 , nums + n + 1 , cmp);
    for(int i = 1 ; i <= n ; i++) rk[nums[i]] = i;
    for(int i = 1 ; i < n ; i++){
        int len = 0;
        while(max(nums[i]+len , nums[i+1]+len) <= n && a[nums[i]+len] == a[nums[i+1]+len]) len++;
        sub[i] = len;
        //cerr << sub[i] << ' ';
    }
    //cerr << '\n';
    for(int i = n ; i > 1 ; i--){
        int len = 0;
        while(max(nums[i]+len , nums[i-1]+len) <= n && a[nums[i]+len] == a[nums[i-1]+len]) len++;
        pre[i] = len;
        //cerr << pre[i] << ' ';
    }
    //cerr << '\n';
    for(int i = 0 ; i < n ; i++){
        vector<pair<int , int>> vec;
        int l1 = 2e18;
        for(int j = rk[i+1]-1 ; j >= 1 ; j--){
            l1 = min(l1 , sub[j]);
            if(l1 == 0) break;
            if(nums[j] >= i+1)vec.push_back({nums[j] , nums[j]+l1-1});
        }
        int l2 = 2e18;
        for(int j = rk[i+1]+1 ; j <= n ; j++){
            l2 = min(l2 , pre[j]);
            if(l2 == 0) break;
            if(nums[j] >= i+1)vec.push_back({nums[j] , nums[j]+l2-1});
        }
        sort(vec.begin() , vec.end());
        //cerr << i << '\n';
        //for(auto j : vec) cerr << j.first << ' ' << j.second << '\n';
        int p = 0;
        for(int j = i+1 ; j <= n ; j++){
            while(p < vec.size() && j > vec[p].second) p++;
            if(p >= vec.size() || j < vec[p].first) dp[j] += dp[i];
        }
    }
    cout << dp[n] << '\n';
    //for(int i = 1 ; i <= n ; i++) cerr << nums[i] << ' ';
    //cerr << '\n'; 
}

main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}
