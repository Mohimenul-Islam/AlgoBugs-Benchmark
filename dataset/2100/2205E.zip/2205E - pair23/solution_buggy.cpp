#include <bits/stdc++.h>
using namespace std;

#ifdef LOCAL
#include "template.cpp"
#else
#define debug()
#endif

const int MOD = 998'244'353;

vector<int> KMP(string s)
{
    int n = (int)s.size();
    vector<int> pi(n, 0);
    for (int i = 1; i < n; ++i) {
        int j = pi[i - 1];
        while (j && s[i] != s[j]) j = pi[j - 1];
        if (s[i] == s[j]) ++j;
        pi[i] = j;
    }
    return pi;
}
int main() {
    if (fopen("in.inp", "r")) {
        freopen("in.inp", "r", stdin);

    }
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int t; cin >> t;
    while (t--) {
        int n; cin >> n;
        vector<int> a(n + 1);
        for (int i = 1; i <= n; ++i) cin >> a[i];
        vector<long long> dp(n + 1, 0);
        dp[0] = 1;
        string curString = "";
        for (int i = 1; i <= n; ++i) {
            curString = (char)(a[i] + '0') + curString;
            int len = i;
            vector<int> pi = KMP(curString);
            for (int j = 0; j < len; ++j) {
                if (pi[j]) continue;
                int pos = i - j;
                dp[i] = (dp[i] + dp[pos - 1]) % MOD;
            }
        }
        cout << dp[n] << "\n";
    }
    return 0;
}
