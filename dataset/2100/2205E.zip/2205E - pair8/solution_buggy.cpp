// 让我们开始编程吧!
#define WangWei
#pragma GCC optimize("O3,unroll-loops")
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

template <class T>
using oset = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<long long, long long> pll;
typedef vector<int> vi;
typedef vector<bool> vb;
typedef vector<long long> vll;
typedef vector<pair<int, int>> vpii;
typedef vector<vector<int>> vvi;
typedef vector<vector<bool>> vvb;
typedef vector<vector<long long>> vvll;

#define rep(i, a, b) for (int i = a; i < b; ++i)
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define sz(x) int((x).size())
#define pb push_back
#define F first
#define S second
#define fastio                        \
    ios_base::sync_with_stdio(false); \
    cin.tie(0);                       \
    cout.tie(0)

const int mod = 998244353;
const int MOD = 1E9 + 7;

#ifdef WangWei
#define dbg(x) cerr << #x << " = " << (x) << endl;
#else
#define dbg(x)
#endif

int n;
void 解决()
{
    cin >> n;
    vi T(n),dp(n + 1, 0);
    rep(i, 0, n)
            cin >>
        T[i];

    dp[0] = 1;

    rep(j, 0, n)
    {
        if (dp[j] == 0)
            continue;

        int len = n - j;
        vector<int> pi(len, 0);

        for (int i = 1; i < len; i++)
        {
            int k = pi[i - 1];
            while (k > 0 && T[j + i] != T[j + k])
                k = pi[k - 1];
            if (T[j + i] == T[j + k])
                k++;
            pi[i] = k;
        }
        for (int i = 0; i < len; i++)
            if (pi[i] == 0)
                dp[j + i + 1] = (dp[j + i + 1] + dp[j]) % MOD;
    }

    cout << dp[n] << "\n";
}

signed main()
{
    fastio;

    int t;
    cin >> t;
    for (int test = 1; test <= t; ++test)
        解决();

    return 0;
}