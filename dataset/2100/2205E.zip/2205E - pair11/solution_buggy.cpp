#pragma GCC optimize("Ofast")
#pragma GCC optimize("O3,unroll-loops")
#include <bits/stdc++.h>
#define int long long

using namespace std;

constexpr int mod = 998244353;

int32_t main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        int a[n];
        int ra[n];
        for(int i = 0;i<n;i++){
            cin>>a[i];
            ra[n-i-1] = a[i];
        }
        vector<vector<int>>z(n,vector<int>(n));
        for(int i = 0;i<n;i++){
            int r = i;
            int l = i;
            for(int j = i+1;j<n;j++){
                if(r > j){
                    z[i][j] = min(z[i][j-l],r-j);
                }
                while(j+z[i][j] < n && a[j+z[i][j]] == a[i+z[i][j]]){
                    z[i][j]++;
                }
                if(r < j+z[i][j]){
                    r = j+z[i][j];
                    l = j;
                }
            }
        }
        vector<vector<bool>>dp(n,vector<bool>(n));
        for(int i = 0;i<n;i++){
            dp[i][i] = 1;
        }
        for(int i = 0;i<n;i++){
            for(int j = i+1;j<n;j++){
                z[i][j] = min(z[i][j],j-i);
                z[i][j] += j;
                z[i][j]--;
            }
            vector<int>mn(n,n);
            int crps = i;
            for(int j = i;j<n;j++){
                while(crps <= z[i][j]){
                    mn[crps] = j;
                    crps++;
                }
            }
            for(int j = i+1;j<n;j++){
                if(mn[j] <= j){
                    dp[i][j] = 1;
                }
            }
            //cout<<endl;
        }
        vector<int>ans(n);
        ans[0] = 1;
        for(int i = 0;i<n;i++){
            dp[i][i] = 0;
        }
        for(int i = 1;i<n;i++){
            for(int j = i;j>0;j--){
                if(dp[j][i]){
                    continue;
                }
                else{
                    //cout<<i<<' '<<j-1<<' '<<ans[j-1]<<endl;
                    ans[i] += ans[j-1];
                    ans[i] %= mod;
                }
            }
            if(dp[0][i] == 0){
                ans[i]++;
            }
            //cout<<ans[i]<<' ';
        }
        cout<<ans[n-1]<<endl;
    }
}
