#ifndef LOCAL
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#else
#include <iostream>
#include <iomanip>
#include <unordered_set>
#include <bit>
#endif

using namespace std;

typedef long long int ll;
typedef long double ld;

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()

#define IOS                                                                  \
    ios_base::sync_with_stdio(false);                                        \
    cin.tie(nullptr);                                                        \
    cout<<fixed<<setprecision(16);

#define el '\n'

#define pb push_back
#define mp make_pair

#define f(i, n) for (int i=0; i<n; i++)

#define vl vector<ll>
#define pqueue priority_queue<ll>
#define pdqueue priority_queue< ll, vl ,greater<>>



template <typename T>
std::ostream& operator<<(std::ostream& os, const std::vector<T>& v) {
    for (size_t i = 0; i < v.size(); ++i) {
        os << v[i] << (i == v.size() - 1 ? "" : " ");
    }
    return os;
}

const ll mod = 998244353;

void solve() {
    ll n; cin >> n;
    vector<ll> t(n);

    f(i, n) cin >> t[i];


    vector<ll> dp(n);
    vector<ll> pi(n);
    dp[0] = 1;
    for (ll i = 1; i < n; i++) {
        pi[i] = 0;
        for (ll j = i - 1; j >= 0; j--) {
            ll k = pi[j+1];
            while (t[j] != t[i - k] && k > 0) k = pi[i - k+1];
            pi[j] = k + (t[j] == t[i - k]);
        }

        dp[i] = dp[i-1];
        for (ll j = i - 1; j > 0; j--) {
            if (pi[j] == 0) dp[i] += dp[j - 1];
            if (dp[i] >= mod) dp[i] -= mod;
        }

        if (pi[0] == 0) dp[i] += 1;
    }

    cout << dp[n-1] << el;

}

int main() {
    IOS
    int t;
    cin >> t;

    while(t--) solve();

    return 0;
}