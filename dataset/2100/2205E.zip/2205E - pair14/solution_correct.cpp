#include <bits/stdc++.h>

using namespace std;
#define int long long

const int N = 8100;
const int MOD = (119 << 23) + 1;

int n, a[N], f[N], p[N];

void test_case() {
    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> a[i];
    f[n + 1] = 1;
    for (int i = n; i >= 1; i--) {
        p[i] = f[i] = 0;
        for (int j = i + 1; j <= n; j++) {
            int k = p[j - 1];
            while (k > 0 && a[j] != a[i + k])
                k = p[i + k - 1];
            if (a[j] == a[i + k]) k++;
            p[j] = k;
        }
        for (int j = i; j <= n; j++)
            if (p[j] == 0)
                (f[i] += f[j + 1]) %= MOD;
    }
    cout << f[1] << '\n';
}

int32_t main() {
    ios::sync_with_stdio(0); cin.tie(0);
    int t; cin >> t;
    while (t--) test_case();
}
