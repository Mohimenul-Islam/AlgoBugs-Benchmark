#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

const int N = 8000, M = 998244353;
int nxt[N+5][N+5];

int n, t[N+5];

ll f[N+5];

void getnxt(int st)
{
	nxt[st][st] = 0;
	for (int i = st + 1, k = 0; i <= n; i++) {
		while (k > 0 && t[i] != t[st + k]) k = nxt[st][st + k - 1];
		if (t[i] == t[st + k]) k++;
		while (2 * k > i - st + 1) k = nxt[st][st + k - 1];
		nxt[st][i] = k;
		// printf("n(%d %d)=%d\n", st, i, k);
	}
}

int main(void)
{
	int test;
	scanf("%d", &test);
	while (test--) {
		scanf("%d", &n);
		for (int i = 1; i <= n; i++) scanf("%d", &t[i]);
		for (int i = 1; i <= n; i++) {
			getnxt(i);
		}

		f[0] = 1;
		for (int i = 1; i <= n; i++) {
			f[i] = 0;
			for (int j = 0; j < i; j++) {
				if (nxt[j + 1][i] == 0) {
					f[i] += f[j];
				}
			}
			f[i] %= M;
		}

		printf("%lld\n", f[n]);
	}
	return 0;
}
