#include<iostream>
#include<vector>
#include<map>
using namespace std;
 
const int p = 998244353;
int n;
vector<int> a;
map<int, vector<int> > b;
vector<vector<bool> > mp;
 
void readcase(){
    cin >> n;
    a.clear();
    a.resize(n);
    b.clear();
    for(int i = 0; i < n; i++){
        cin >> a[i];
        b[a[i]].push_back(i);
    } 
}

void gmp(){
    mp.clear();
    mp.resize(n, vector(n, false));
    for(auto x: b){
        for(int i = 0; i < x.second.size(); i++){
            for(int j = i+1; j < x.second.size(); j++){
                int l = x.second[i];
                int r = x.second[j];
                int k = 0;
                while(l+k < r && r+k < a.size() && a[l+k] - a[r+k] == 0){
                    mp[l][r+k] = true;
                    k++;
                }
            }
        }
    }
}

void omp(){
    for(int i = 0; i < n; i++){
        for(int j = i; j < n; j++){
            if(mp[i][j]) cout << "(" << i << "," << j << ") ";
        }
        cout << endl;
    }
}

void solve(){
    if(1 == b.size()){
        cout << 1 << endl;
    }else{
        gmp();
        //omp();
        vector<int> dp(n);
        dp[0] = 1;
        for(int k = 1; k < n; k++){
            dp[k] = dp[k-1];
            if(!mp[0][k]) dp[k]++;
            for(int i = 1; i < k; i++){
                if(!mp[i][k]) dp[k] = (dp[k] + dp[i-1]) % p;
                
            }
        }
        cout << dp.back() << endl;
    }
}
 
int main(){
    ios::sync_with_stdio(false);
    int t;
    cin >> t;
    while(t--){
        readcase();
        solve();
    }
    return 0;
}