# E. Simons and Dividing the Rhythm

**Time limit:** 2 seconds
**Memory limit:** 512 megabytes

## Problem Statement

I grip my troubles within my hand, then hurl them off a thousand lands.

— SHUN, [ONMYWAY](https://open.spotify.com/track/0ZOaDlRReh6qeZWipAMHDu)

Consider that Simons is given an array $$$a$$$ of size $$$m$$$.

Simons must operate on the array exactly once as follows:

*   First, he has to select an integer $$$k$$$ and choose $$$k$$$ pairs of integers $$$\[l\_1,r\_1\],\[l\_2,r\_2\],\\ldots,\[l\_k,r\_k\]$$$, such that:
    *   $$$l\_i\\le r\_i$$$ for each $$$1\\le i\\le k$$$,
    *   $$$l\_1=1$$$, $$$r\_k=m$$$, and
    *   $$$r\_i+1=l\_{i+1}$$$ for each $$$i$$$ from $$$1$$$ to $$$k-1$$$.
*   Then, he reverses each subarray $$$\[a\_{l\_i},a\_{l\_i+1},\\ldots, a\_{r\_i}\]$$$ independently. After this, the array will become $$$\[a\_{r\_1},a\_{r\_1-1},\\ldots,a\_{l\_1},a\_{r\_2},\\ldots,a\_{l\_{k-1}},a\_{r\_{k}},a\_{r\_k-1},\\ldots,a\_{l\_k}\]$$$.

You are given an array $$$T$$$ of size $$$n$$$. Count the number of arrays $$$S$$$ such that Simons can transform $$$S$$$ to $$$T$$$, modulo $$$998\\,244\\,353$$$.

## Input

Each test contains multiple test cases. The first line contains the number of test cases $$$t$$$ ($$$1 \\le t \\le 8000$$$). The description of the test cases follows.

The first line contains an integer $$$n$$$ ($$$1\\le n\\le 8000$$$) — the length of $$$T$$$.

The second line contains $$$n$$$ integers $$$T\_1,T\_2,\\ldots,T\_n$$$ ($$$1\\le T\_i\\le 8000$$$) — the elements of $$$T$$$.

It is guaranteed that the sum of $$$n$$$ over all test cases does not exceed $$$8000$$$.

## Output

For each test case, output a single integer — the number of arrays $$$S$$$, modulo $$$998\\,244\\,353$$$.

## Sample Tests

### Input
```
5
4
1 1 2 1
4
1 2 3 1
6
1 3 2 3 3 2
10
2 3 1 4 3 1 4 3 1 2
1
8000
```

### Output
```
4
7
22
383
1
```

## Note

In the first test case, we can see only the following arrays can be transformed to $$$T$$$:

*   For $$$S=\[2,1,1,1\]$$$, Simons will choose $$$\[1,3\]$$$ and $$$\[4,4\]$$$. Thus, the array will become $$$\[1,1,2,1\]$$$, equal to $$$T$$$.
*   For $$$S=\[1,2,1,1\]$$$, Simons will choose $$$\[1,4\]$$$.
*   For $$$S=\[1,1,2,1\]$$$, Simons will choose $$$\[1,2\]$$$, $$$\[3,3\]$$$, and $$$\[4,4\]$$$.
*   For $$$S=\[1,1,1,2\]$$$, Simons will choose $$$\[1,2\]$$$ and $$$\[3,4\]$$$.

In the second test case, we can see only the following arrays can be transformed to $$$T$$$:

*   For $$$S=\[1,1,3,2\]$$$, Simons will choose $$$\[1,1\]$$$ and $$$\[2,4\]$$$.
*   For $$$S=\[1,2,1,3\]$$$, Simons will choose $$$\[1,1\]$$$, $$$\[2,2\]$$$, and $$$\[3,4\]$$$.
*   For $$$S=\[1,2,3,1\]$$$, Simons will choose $$$\[1,1\]$$$, $$$\[2,2\]$$$, $$$\[3,3\]$$$, and $$$\[4,4\]$$$.
*   For $$$S=\[1,3,2,1\]$$$, Simons will choose $$$\[1,4\]$$$.
*   For $$$S=\[2,1,1,3\]$$$, Simons will choose $$$\[1,2\]$$$ and $$$\[3,4\]$$$.
*   For $$$S=\[2,1,3,1\]$$$, Simons will choose $$$\[1,2\]$$$, $$$\[3,3\]$$$, and $$$\[4,4\]$$$.
*   For $$$S=\[3,2,1,1\]$$$, Simons will choose $$$\[1,3\]$$$ and $$$\[4,4\]$$$.