#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define db double
inline ll read(){
	char ch=getchar(); ll a=0; int fg=0;
	while(ch>'9'||ch<'0') {	if(ch=='-') fg=1;ch=getchar();	}
	while('0'<=ch||ch>='9') a=(a<<1)+(a<<3)+(ch^48),ch=getchar();
	if(fg) a=-a; return a;
}
#define MAXN 8010
int s[MAXN];
int val[MAXN];
int rk[MAXN];
int sa[MAXN];
int cnt[MAXN];
int he[MAXN];
int n;
int st[MAXN][16];
int lg[MAXN];
inline void SA_(){
	int m=n;
	for(int i=0;i<=m;i++) cnt[i]=0;
	for(int i=1;i<=n;i++) cnt[rk[i]=s[i]]++;
	for(int i=1;i<=m;i++) cnt[i]+=cnt[i-1];
	for(int i=1;i<=n;i++) sa[cnt[rk[i]]--]=i;
	int pos;
	for(int k=1;k<=n;k<<=1){
		pos=0;
		for(int i=n-k+1;i<=n;i++) val[++pos]=i;
		for(int i=1;i<=n;i++) if(sa[i]>k) val[++pos]=sa[i]-k;
		for(int i=1;i<=m;i++) cnt[i]=0;
		for(int i=1;i<=n;i++) cnt[rk[i]]++;
		for(int i=1;i<=m;i++) cnt[i]+=cnt[i-1];
		for(int i=n;i>=1;i--) sa[cnt[rk[val[i]]]--]=val[i];
		for(int i=1;i<=n;i++) val[i]=rk[i];
		rk[sa[1]]=m=1;
		for(int i=2;i<=n;i++){
			if(val[sa[i]]==val[sa[i-1]]&&val[sa[i]+k]==val[sa[i-1]+k]) rk[sa[i]]=m;
			else rk[sa[i]]=++m;
		}
		if(n==m) break;
	}
	int las=0;
	for(int i=1;i<=n;i++){
		pos=sa[rk[i]-1];
		if(las) las--;
		if(!pos){
			he[1]=0;
			st[1][0]=0;
			continue;
		}
		while(s[i+las]==s[pos+las]) las++;
		he[rk[i]]=las;
		st[rk[i]][0]=las;
	}
	for(int k=1;k<=lg[n];k++){
		for(int i=1;i+(1<<k)-1<=n;i++){
			st[i][k]=min(st[i][k-1],st[i+(1<<k-1)][k-1]);
		}
	}
}
inline int lcp(int i,int j){
	int l=rk[i],r=rk[j];
	if(l>r) swap(l,r);
	int len=r-l;
	//cout<<len<<' '<<st[l+1][lg[len]]<<' '<<endl;
	return min(st[l+1][lg[len]],st[r-(1<<lg[len])+1][lg[len]]);
}
int L,K;
int M,b[MAXN];
int f[MAXN];
int vis[MAXN][MAXN];
#define mod 998244353
inline void MAIN(){
	n=read();
	lg[1]=0;
	for(int i=2;i<=n;i++) lg[i]=lg[i/2]+1;
	M=0;
	for(int i=1;i<=n;i++) b[++M]=s[i]=read();
	sort(b+1,b+M+1);
	M=unique(b+1,b+M+1)-b-1;
	for(int i=1;i<=n;i++) {
		s[i]=lower_bound(b+1,b+M+1,s[i])-b;
		for(int j=1;j<=n;j++) vis[i][j]=0;
	}
	SA_();
	f[0]=1;
	for(int i=1;i<=n;i++){
		f[i]=f[i-1];
		for(int j=1;j<=n;j++) vis[i][j]+=vis[i-1][j];
		for(int j=i-1;j>=1;j--){
			int len=lcp(i,j);
			//cout<<i<<' '<<j<<' '<<len<<endl;
			if(len) {
				//S[i+len]=(S[i+len]+f[j-1])%mod,S[i]=(S[i]+mod-f[j-1])%mod;
				vis[i][j]++,vis[i+len][j]--;
			}
			if(!vis[i][j]) f[i]=(f[i]+f[j-1])%mod;
		}
		//S[i]=(1ll*S[i-1]+S[i])%mod;
		//f[i]=(f[i]+S[i])%mod;
		//cout<<f[i]<<endl;
	}
	printf("%d\n",f[n]);
}
signed main(){
	#ifdef freopen_flag
	freopen("test.in","r",stdin);
	#endif
	int T=1; 
	scanf("%d",&T);
	while(T--) MAIN();
	return 0;
}