#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ld = long double;
using vi = vector<int>;
using vl = vector<ll>;

#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define for0(i, n) for (int i = 0; i < n; i++)
#define for1(i, n) for (int i = 1; i <= n; i++)
#define rfor0(i, n) for (int i = n - 1; i >= 0; i--)
#define rfor1(i, n) for (int i = n; i >= 1; i--)
#define pb push_back
#define debug(x) cerr << #x << " = " << x << endl

const int MOD = 998244353;

vi zFunction(vi s) { // O(n)
    int n = s.size();
    vi Z(n);
    Z[0] = n;
    for (int i = 1, l = 0, r = 0; i < n; i++) {
        if (i <= r) Z[i] = min(Z[i - l], r - i + 1);

        while (i + Z[i] < n && s[i + Z[i]] == s[Z[i]]) Z[i]++;

        if (i + Z[i] - 1 > r) l = i, r = i + Z[i] - 1;
    }
    return Z;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        vi v(n);
        for (auto &i : v) cin >> i;
        vl dp(n + 1);
        dp[n] = 1;

        rfor0(i, n) {
            int cur = 0;
            dp[i] = dp[i + 1];
            auto z = zFunction(vi(v.begin() + i, v.end()));
            for (int j = 1; j < n - i; j++) {
                if (!z[j]) dp[i] = (dp[i] + dp[i + j + 1]) % MOD;
                else j += z[j] - 1;
            }
        }

        cout << dp[0] << '\n';
    }

    return 0;
}