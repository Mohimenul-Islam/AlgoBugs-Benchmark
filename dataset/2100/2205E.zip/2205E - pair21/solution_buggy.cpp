#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef __int128 lll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int N = 2e5 + 10;
const ll MOD = 998244353;
const ll INF = 0x3f3f3f3f3f3f3f3f;

ll a[N];

void Init()
{
    
}
vector<int> getpi(ll l, ll r)//获取pi数组
{
    vector<int> pi(r - l + 2, 0);
    pi[0] = -1;
    for(int i = 2, j = 0; i <= r - l + 1; ++i)
    {
        while(j && a[l + j] != a[l + i - 1])
            j = pi[j];
        if (a[l + j] == a[l + i - 1])
            ++j;
        pi[i] = j;
    }
    return pi;
}
void solve()
{
    ll n;
    cin >> n;
    for(int i = 1; i <= n; ++i)
        cin >> a[i];
    vector<vector<int>> pi(n + 1);
    vector<ll> dp(n + 1);
    for(int i = 1; i <= n; ++i)
        pi[i] = getpi(i, n);
    dp[0] = 1;
    for(int i = 1; i <= n; ++i)
    {
        for(int j = 1; j <= n; ++j)
            if(pi[j][i - j + 1] == 0)
                dp[i] = (dp[j - 1] + dp[i]) % MOD;
    }
    cout << dp[n] << "\n";
}
int main()
{
    ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
    cout << fixed << setprecision(10);
    Init();
    int _ = 1;
    cin >> _;
    while(_--)
        solve();
    return 0;
}