#include <bits/stdc++.h>
#define ll long long
#define INF 0x3f3f3f3f
#define LINF 0x3f3f3f3f3f3f3f3f
#define int long long
#define pii pair<int, int>
#define popcount __builtin_popcount
#define Mod 998244353
// #define Mod 1000000007
#define endl "\n"
using namespace std;

void solve()
{
    int n;
    cin >> n;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    vector<vector<int>> nxt(n + 1, vector<int>(n + 1));
    for (int i = 1; i <= n; i++)
    {
        for (int j = i + 1; j <= n; j++)
        {
            int k = nxt[i][j - 1];
            while (k && a[j] != a[i + k])
                k = nxt[i][i + k - 1];
            if (a[j] == a[i + k])
                k++;
            nxt[i][j] = k;
        }
    }

    vector<int> dp(n + 1);
    dp[0] = 1;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= i; j++)
            if (!nxt[j][i])
                dp[i] = (dp[i] + dp[j - 1]) % Mod;
    cout << dp[n] << endl;
}

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    // cout << fixed << setprecision(10) << endl;
    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
}