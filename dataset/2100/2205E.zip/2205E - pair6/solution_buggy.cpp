#include <bits/stdc++.h>
#define int long long
#define mod 998244353
using namespace std;
int a[8006];
int dp[8006],f[8005][8005],nxt[8005];
signed main(){
    cin.tie(0) -> ios::sync_with_stdio(false);
    int t;cin>>t;
    while(t--){
        int n;cin>>n;
        for(int i=1;i<=n;i++)cin>>a[i];
        for(int l=1;l<=n;l++){
            for(int j=0;j<=n;j++)nxt[j]=0;
            for(int j=0,i=l+1;i<=n;i++){
                while(j&&a[i]!=a[j+l])j=nxt[j];
                if(a[i]==a[j+l])j++;
                nxt[i]=j;f[l][i]=j;
            }
        }
        dp[0]=1;
        for(int i=1;i<=n;i++){
            dp[i]=0;
            for(int j=i;j>=1;j--)
                if(!f[j][i])
                    dp[i]=(dp[i]+dp[j-1])%mod;
        }cout<<dp[n]<<'\n';
    }
    return 0;
}
