#include<bits/stdc++.h>
using namespace std;
const int maxn=2e5+10;
const int mod=998244353;
#define inf 1e9
inline int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+c-'0';c=getchar();}
	return x*f;
}
const int N=8005;
int n,m,T,a[N],nxt[N],dp[N];
inline void solve(){
	n=read();dp[n+1]=1;
	for(int i=1;i<=n;i++)
		a[i]=read(),dp[i]=0;
	for(int i=n;i>=1;i--){
		dp[i]=dp[i+1];
		for(int j=i;j<=n;j++)nxt[j]=i-1;
		for(int j=i+1;j<=n;j++){
			int pos=nxt[j-1];
			while(pos!=i-1&&a[pos+1]!=a[j])pos=nxt[pos];
			if(a[pos+1]==a[j])nxt[j]=pos+1;
			else dp[i]=(dp[i]+dp[j+1])%mod;
		}
	}printf("%d\n",dp[1]);
}
int main(){
	T=read();
	while(T--)solve();
	return 0;
}