#include <bits/stdc++.h>
using namespace std;
using ll = long long;

int MOD = 998244353;

vector<int> dokmp(vector<int> &a) {
    int n = a.size();
    vector<int> kmp(n);

    for(int i = 1; i < n; i ++) {
        kmp[i] = kmp[i - 1];
        while(kmp[i] > 0 && a[kmp[i]] != a[i])
            kmp[i] = kmp[kmp[i] - 1];
        if(a[kmp[i]] == a[i])
            kmp[i] ++;
    }
    return kmp;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t; cin >> t;
    while(t --) {
        int n; cin >> n; 
        vector<int> a(n);

        for(int i = 0; i < n; i ++) {
            cin >> a[i];
        }

        vector<ll> dp(n + 1);
        
        dp[0] = 1;

        for(int i = 0; i < n; i ++) {
            vector<int> b;
            for(int j = i; j < n; j ++) {
                b.push_back(a[j]);
            }

            vector<int> kmp = dokmp(b);

            for(int k = 0, j = i; k < kmp.size(); k ++, j ++) {
                if(!kmp[k])
                    dp[j + 1] += dp[i];
                dp[j + 1] %= MOD;
            }

        }

        cout << dp[n] << '\n';
    }
}