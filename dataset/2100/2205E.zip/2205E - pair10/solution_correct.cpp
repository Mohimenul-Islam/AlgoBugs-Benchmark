#include<bits/stdc++.h>
using namespace std;
using LL = long long;
using PII = pair<int, int>;
mt19937 rnd(chrono::steady_clock::now().time_since_epoch().count());
const int INF = 0x3f3f3f3f;
LL getrand(LL l, LL r) {
   assert(r - l >= 0);
   return rnd() % (r - l) + l;
}

const int P = 998244353;
// assume -P <= x < 2P
int norm(int x) {
    if (x < 0) {
        x += P;
    } else if (x >= P) {
        x -= P;
    }
    return x;
}
template<class T>
T power(T a, int k) {
    T res = 1;
    for (; k; k >>= 1, a *= a) {
        if (k & 1) {
            res *= a;
        }
    }
    return res;
}
struct Z {
    int x;
    Z (int x = 0) : x(norm(x)) {}
    Z (LL x) : x(norm(int(x % P))) {}
    int val() const {
        return x;
    }
    Z operator-() const {
        return Z(norm(P - x));
    }
    Z inv() const {
        assert(x != 0);
        return power(*this, P - 2);
    }
    Z &operator++() {  
        x = norm(x + 1);
        return *this;
    }
    Z operator++(int) { 
        Z temp = *this;  
        ++ (*this);       
        return temp;     
    }
    Z &operator--() {  
        x = norm(x - 1);
        return *this;
    }
    Z operator--(int) {  
        Z temp = *this;  
        -- (*this);       
        return temp;     
    }
    Z &operator*=(const Z &rhs) {
        x = (LL)x * rhs.x % P;
        return *this;
    }
    Z &operator+=(const Z &rhs) {
        x = norm(x + rhs.x);
        return *this;
    }
    Z &operator-=(const Z &rhs) {
        x = norm(x - rhs.x);
        return *this;
    }
    Z &operator/=(const Z &rhs) {
        return *this *= rhs.inv();
    }
    friend Z operator*(const Z &lhs, const Z &rhs) {
        Z res = lhs;
        res *= rhs;
        return res;
    }
    friend Z operator+(const Z &lhs, const Z &rhs) {
        Z res = lhs;
        res += rhs;
        return res; 
    }
    friend Z operator-(const Z &lhs, const Z &rhs) {
        Z res = lhs;
        res -= rhs;
        return res;
    }
    friend Z operator/(const Z &lhs, const Z &rhs) {
        Z res = lhs;
        res /= rhs;
        return res;
    }
    friend istream &operator>>(istream &in, Z &a) {
        LL t;
        in >> t;
        a = Z(t);
        return in;
    }
    friend ostream &operator<<(ostream &out, const Z &a) {
        return out << a.val();
    }
};

vector<int> getNext(vector<int> &t) {
    int m = t.size();
    vector<int> nxt(m + 1);
    nxt[0] = -1, nxt[1] = 0;
    int j = 2, i = nxt[j - 1];
    while (j <= m) {
        if (t[j - 1] == t[i]) {
            nxt[j ++] = ++ i;
        } else if (i) {
            i = nxt[i];
        } else {
            nxt[j ++] = 0;
        }
    }
    return nxt;
};

void solve() {
    LL n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i ++) {
        cin >> a[i];
    }

    vector<Z> dp(n + 1);
    dp[0] = 1;
    for (int i = 1; i <= n; i ++) {
        vector<int> s;
        for (int j = 0; j < i; j ++) {
            s.push_back(a[j]);
        }

        reverse(s.begin(), s.end());
        auto nxt = getNext(s);

        for (int j = 1; j <= i; j ++) {
            if (nxt[j] == 0) {
                dp[i] += dp[i - j];
            }
        }
    }
    cout << dp[n] << "\n";
}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T = 1;
    cin >> T;
    while (T --)
        solve ();
    return 0;
}