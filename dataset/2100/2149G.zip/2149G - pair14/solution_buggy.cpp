#include<bits/stdc++.h>
using namespace std;
int T,n,q,a[200010],cnt[200010];
vector<int>alls,ms[200010];
set<int>s;
mt19937_64 rnd(time(0));
int find(int x)
{
	return lower_bound(alls.begin(),alls.end(),x)-alls.begin()+1;
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cin>>T;
	while(T--)
		{
			alls.clear();
			cin>>n>>q;
			for(int i=1;i<=n;i++)
				{
					cin>>a[i];
					alls.push_back(a[i]),ms[i].clear();
				}
			for(int i=1;i<=n;i++) ms[find(a[i])].push_back(i);
			sort(alls.begin(),alls.end());
			alls.erase(unique(alls.begin(),alls.end()),alls.end());
			while(q--)
				{
					int l,r;
					cin>>l>>r;
					s.clear();
					if(r-l+1<=30) 
						{
							for(int i=l;i<=r;i++)
								{
									int pos=find(a[i]);
									cnt[pos]++;
									if(cnt[pos]>(r-l+1)/3) s.insert(alls[pos-1]);
								}
							for(int i=l;i<=r;i++) cnt[find(a[i])]=0;
							if(!s.size())
								{
									cout<<-1<<'\n';
									continue;
								}
							for(int it:s) cout<<it<<' ';
						}
					else{
						int f=0;
						for(int i=1;i<=50;i++) s.insert(a[rnd()%(r-l+1)+l]);
						for(int it:s)
							{
								int t=find(it);
								if(upper_bound(ms[t].begin(),ms[t].end(),r)-lower_bound(ms[t].begin(),ms[t].end(),l)>(r-l+1)/3) 
									{
										cout<<it<<" ";
										f=1;
									}
							}
						if(!f) 
							{
								cout<<-1<<'\n';
								continue;	
							}
					}
					cout<<'\n';
				}
		}
	return 0;
}