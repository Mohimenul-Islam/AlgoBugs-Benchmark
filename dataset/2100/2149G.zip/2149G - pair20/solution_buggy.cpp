#include <bits/stdc++.h>
using namespace std;

#ifdef LOCAL
#include "debug.h"
#else
#define debug(...) 42
#endif

#define fast ios::sync_with_stdio(false); cin.tie(nullptr);

using ll = long long;

int main() {
    fast

    int t;
    cin >> t;
    while(t--) {
        int n,q;
        cin>>n>>q;
        vector<int> a(n+1);
        for(int i=1;i<=n;i++)
        {
            cin>>a[i];
        }
        unordered_map<int,vector<int>> pos(n+1);
        for(int i=1;i<=n;i++)
        {
            pos[a[i]].emplace_back(i);
        }
        mt19937 rng(std::chrono::high_resolution_clock::now().time_since_epoch().count());
        const int T=60;
        const int inf=INT_MAX;
        while(q--)
        {
            int l,r;
            cin>>l>>r;
            //int res=inf;
            set<int> res;
            uniform_int_distribution<int> dist(l,r);
            for(int i=0;i<=T;i++)
            {
            int idx=dist(rng);
            int count=upper_bound(pos[a[idx]].begin(),pos[a[idx]].end(),r)-lower_bound(pos[a[idx]].begin(),pos[a[idx]].end(),l);
            if(3*count>(r-l+1))
            {
                res.insert(a[idx]);
            }
            }
            if(res.empty())
            {
                cout<<-1<<'\n';
                continue;
            }
            else
            {
                for(auto it:res)
                cout<<it<<" ";
                cout<<'\n';
            }
        }
    }
    return 0;
}