#include <bits/stdc++.h>
using namespace std;
using lli = long long;

void solve() {
    int n, q;
    cin >> n >> q;
    vector <int> a(n);
    for (int i = 0; i < n; ++i) cin >> a[i];
    vector <int> v = a;
    sort(v.begin(), v.end());
    v.erase(unique(v.begin(), v.end()), v.end());
    for (auto &x: a) {
        x = lower_bound(v.begin(), v.end(), x) - v.begin();
    }

    int sz = *max_element(a.begin(), a.end()) + 1;
    vector <int> cnt(sz);
    for (auto x: a) cnt[x]++;

    int block_size = 700;
    vector <int> big;
    vector <vector <int>> pref;
    for (int i = 0; i < sz; ++i) {
        int f = cnt[i];
        if (f > block_size) {
            big.push_back(i);
            pref.emplace_back(vector <int> (n + 1));
            for (int j = 0; j < n; ++j) {
                pref.back()[j + 1] = pref.back()[j] + (a[j] == i);
            }
        }
    }

    vector <int> dih(sz);
    while (q--) {
        int l, r;
        cin >> l >> r;

        int freq = (r - l + 1) / 3;
        vector <int> ans;
        if (freq > block_size) {
            for (int i = 0; i < (int) big.size(); ++i) {
                if (pref[i][r] - pref[i][l - 1] > freq) ans.push_back(big[i]);
            }
        } else {
            for (int i = l - 1; i < r; ++i) {
                dih[a[i]]++;
                if (dih[a[i]] > freq) ans.push_back(a[i]);
            }
            for (int i = l - 1; i < r; ++i) dih[a[i]]--;
        }
        sort(ans.begin(), ans.end());
        ans.erase(unique(ans.begin(), ans.end()), ans.end());

        if (ans.empty()) cout << -1 << '\n';
        else for (auto x: ans) cout << v[x] << ' ';
        cout << '\n';
    }
}

int main() {
    std::cin.tie(0)->sync_with_stdio(0);
#ifdef LOCAL
    auto begin = std::chrono::high_resolution_clock::now();
#endif

    int tt = 1;
    cin >> tt;
    while (tt--) {
        solve();
    }

#ifdef LOCAL
    auto end = std::chrono::high_resolution_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin);
    std::cerr << "Time measured: " << elapsed.count() * 1e-9 << " seconds.\n";
#endif
    return 0;
}