#include <bits/stdc++.h>
#define int long long
using namespace std;

struct st {
    int n;
    vector<int> arr;
    vector<vector<int>> seg;
    map<int, vector<int>> fq;

    void init(int sz, vector<int> in, map<int, vector<int>> mp) {
        n = sz;
        seg.assign(4*n+2, vector<int>());
        arr = in;
        fq = mp;
    }
    
    int ffq(int idl, int idr, int val) {
        int r = upper_bound(fq[val].begin(), fq[val].end(), idr) - fq[val].begin();
        int l = upper_bound(fq[val].begin(), fq[val].end(), idl-1) - fq[val].begin();
        return r-l;
    }

    void build(int l, int r, int node) {
        if(l == r) {
            seg[node].push_back(arr[l]);
            return;
        }
        int mid = (l+r)/2;
        build(l, mid, node*2);
        build(mid+1, r, node*2+1);
        vector<int> x = seg[node*2], y = seg[node*2+1];
        map<int, int> mpz;
        for(auto i: x) {
            if(mpz[i] != 0) continue;
            mpz[i] = 1;
            if(ffq(l, r, i) > (r-l+1)/3) seg[node].push_back(i);
        }
        for(auto i: y) {
            if(mpz[i] != 0) continue;
            mpz[i] = 1;
            if(ffq(l, r, i) > (r-l+1)/3) seg[node].push_back(i);
        }
    }

    vector<int> query(int l, int r, int ql, int qr, int node) {
        if(l > qr || r < ql) return {-1};
        if(l >= ql && r <= qr) return seg[node];
        int mid = (l+r)/2;
        vector<int> x, y, z;
        map<int, int> mpz;
        int range;
        x = query(l, mid, ql, qr, node*2);
        y = query(mid+1, r, ql, qr, node*2+1);
        if(!x.empty() && !y.empty() && x[0]+y[0] == -2) return {-1};
        else if(!x.empty() && x[0] == -1) range = (mid-max(l, ql)+1)/3;
        else if(!y.empty() && y[0] == -1) range = (min(r, qr)-mid)/3;
        else range = (min(r, qr)-max(l, ql)+1)/3;
        for(auto i: x) {
            if(mpz[i] != 0 || i == -1) continue;
            mpz[i] = 1;
            if(ffq(max(l, ql), min(r, qr), i) > range) z.push_back(i);
        }
        for(auto i: y) {
            if(mpz[i] != 0 || i == -1) continue;
            mpz[i] = 1;
            if(ffq(max(l, ql), min(r, qr), i) > range) z.push_back(i);
        }
        return z;
    }

    vector<int> qry(int ql, int qr) {
        return query(1, n, ql, qr, 1);
    }
};

void solve() {
    int n, q;
    st seg;
    cin >> n >> q;
    vector<int> arr(n+2, 0);
    map<int, vector<int>> mp;
    for(int i=1; i<=n; i++) {
        cin >> arr[i];
        mp[arr[i]].push_back(i);
    }
    seg.init(n, arr, mp);
    seg.build(1, n, 1);
    while(q--) {
        int l, r;
        cin >> l >> r;
        vector<int> res = seg.qry(l, r);
        if(res.empty()) cout << "-1\n";
        else {
            for(auto i: res) {
                cout << i << " ";
            }
            cout << "\n";
        }
    }
}

signed main() {
    cin.tie(0)->sync_with_stdio(0);
    int t;
    cin >> t;
    while(t--) {
        solve();
    }
}