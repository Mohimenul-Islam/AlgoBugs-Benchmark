#pragma GCC optimize("O3")
#include <iostream>
#include <chrono>
#include <random>
#include <unordered_map>
#include <vector>
#include <algorithm>
using namespace std;
struct custom_hash
{
    static uint64_t splitmix64(uint64_t x)
    {
        x += 0x9e3779b97f4a7c15;
        x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;
        x = (x ^ (x >> 27)) * 0x94d049bb133111eb;
        return x ^ (x >> 31);
    }
    size_t operator()(uint64_t x) const
    {
        static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();
        return splitmix64(x + FIXED_RANDOM);
    }
};
int main()
{
    ios::sync_with_stdio(false), cin.tie(nullptr);
    short t;
    int n, q, l, r, tmp, num;
    random_device rd;
    mt19937_64 gen(rd());
    unordered_map<int, vector<int>, custom_hash> mp;
    vector<int> ans, *id;
    cin >> t;
    while(t--)
    {
        mp.clear();
        cin >> n >> q;
        int a[n + 1];
        for(int i = 1; i <= n; ++i)
        {
            cin >> a[i];
            mp[a[i]].push_back(i);
        }
        while(q--)
        {
            ans.clear();
            cin >> l >> r;
            uniform_int_distribution<> dist(l, r);
            for(int i = 0; i < 64; ++i)
            {
                num = a[dist(gen)];
                id = &mp[num];
                tmp = upper_bound(id->begin(), id->end(), r) - lower_bound(id->begin(), id->end(), l);
                if(tmp > (r - l + 1) / 3 && (ans.empty() || num != ans.front() && num != ans.back()))
                    ans.push_back(num);
            }
            if(ans.empty())
                cout << "-1\n";
            else
            {
                sort(ans.begin(), ans.end());
                for(auto &i : ans)
                    cout << i << " ";
                cout << "\n";
            }
        }
    }
    return 0;
}