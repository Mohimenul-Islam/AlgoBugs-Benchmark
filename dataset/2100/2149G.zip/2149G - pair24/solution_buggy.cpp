#include <bits/stdc++.h>
using namespace std;
int n, l, r, k;
int a[200200];
vector<int> t[20][200200];
void build(int lev, int l, int r) {

    if(l == r) {
        return;
    }
    for(int i = l; i <= r; i++) {
        t[lev][i].clear();
    }
    int m = (l + r)/2;
    build(lev-1, l, m);
    build(lev-1, m+1, r);
    set< pair<int, int> > s;
    map<int, int> cnt;
    int cur = 0;
    for(int i = m; i >= l; i--) {
        s.erase({-cnt[a[i]], a[i]});
        cnt[a[i]]++;
        s.insert({-cnt[a[i]], a[i]});
        cur++;
        for(auto [sz, x]: s) {
            if((-sz) * 3 >= cur) {
                t[lev][i].push_back(x);
            } else {
                break;
            }
        }
    }

    cur = 0;
    s.clear();
    cnt.clear();
    for(int i = m+1; i <= r; i++) {
        s.erase({-cnt[a[i]], a[i]});
        cnt[a[i]]++;
        s.insert({-cnt[a[i]], a[i]});
        cur++;
        for(auto [sz, x]: s) {
            if((-sz) * 3 >= cur) {
                t[lev][i].push_back(x);
            } else {
                break;
            }
        }
    }
}
void solve() {
    cin >> n >> k;
    map<int, vector<int> > m;
    for(int i = 0; i < n; i++) {
        cin >> a[i];
        m[a[i]].push_back(i);
    }
    int d = 1;
    int sz = 0;
    while(d < n) {
        d *= 2;
        sz++;
    }
    build(sz-1, 0, d-1);

    for(int i = 1; i <= k; i++) {
        int l, r;
        cin >> l >> r;
        l--;
        r--;
        if(l == r) {
            cout << a[l] << "\n";
            continue;
        }
        int b = sz;
        while((l>>b) == (r>>b)) {
            b--;
        }
        set<int> ans;
        for(int x: t[b][l]) {
            int cur = upper_bound(m[x].begin(), m[x].end(), r) - lower_bound(m[x].begin(), m[x].end(), l);

            if(cur * 3 > (r-l+1)) {
                ans.insert(x);
            }
        }
        for(int x: t[b][r]) {
            int cur = upper_bound(m[x].begin(), m[x].end(), r) - lower_bound(m[x].begin(), m[x].end(), l);

            if(cur * 3 > (r-l+1)) {
                ans.insert(x);
            }
        }
        if(ans.size() == 0) {
            cout << -1 << "\n";
        } else {
            for(int x: ans) {
                cout <<x<<" ";
            }
            cout << "\n";
        }
    }
}

int main() {
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t = 1;
    cin >> t;
    for(int i = 1; i <= t; i++) {
        solve();
    }

}
