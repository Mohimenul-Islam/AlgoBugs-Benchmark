#include <bits/stdc++.h>
#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using namespace std;

using ll = long long;
using ld = long double;
typedef vector<ll> vl;
typedef deque<ll> dq;
typedef pair<ll, ll> pl;

#define endl '\n'
#define all(a) (a).begin(), (a).end()
#define allr(a) (a).rbegin(), (a).rend()
#define fi first
#define se second
#define mp make_pair
#define mt make_tuple
#define pb push_back
#define eb emplace_back
#define rep(i, n, m) for (ll i = (n); i < (ll)(m); i++)
#define rrep(i, n, m) for (ll i = (ll)(m) - 1; i >= (ll)(n); i--)
#define no cout << "NO" << "\n";
#define yes cout << "YES" << "\n";

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

template <typename T>
istream &operator>>(istream &istream, vector<T> &v)
{
    for (auto &it : v)
        cin >> it;
    return istream;
}

const ll MOD1 = 1e9 + 7;
const ll MOD9 = 998244353;
const ll INF = 1e18;
const ld pi = 3.1415926535897932384626433832795;

const int N = 1e6 + 1;

ll sumdigits(ll n)
{
    n = abs(n);
    if (n == 0)
        return 0;
    return n % 10 + sumdigits(n / 10);
}

ll fac[N];
ll power(ll a, ll k, ll mod = MOD1)
{
    ll ans = 1;
    while (k)
    {
        if (k & 1)
            ans = (ans * a) % mod;
        a = (a * a) % mod;
        k >>= 1;
    }
    return ans;
}
ll mul(ll a, ll b, ll c = 1, ll mod = MOD1)
{
    if (c != 1)
        return (((a % mod) * (b % mod)) % mod) * power(c, mod - 2) % mod;
    return ((a % mod) * (b % mod)) % mod;
}
ll cnk(ll n, ll k, ll p = MOD1)
{
    if (n < k)
        return 0;
    if (k == 0 || k == n)
        return 1;

    return mul(fac[n], 1, mul(fac[k], fac[n - k]), p);
}
ll binexp(ll a, ll k, ll mod = 1e18)
{
    ll ans = 1;
    while (k)
    {
        if (k & 1)
            ans = (ans * a) % mod;
        a = (a * a) % mod;
        k >>= 1;
    }
    return ans;
}

struct node
{
    ll ans, pr, suff, ns, ne;
    node()
    {
        ans = pr = suff = 0;
        ns = ne = 0;
    }
    node(int a, int p, int s, int nss, int nee)
    {
        ans = a;
        pr = p;
        suff = s;
        ns = nss;
        ne = nee;
    }
};

class SegmentTree
{
public:
    vector<node> tree;
    vector<ll> arr;
    int n;

    node merge(node &x, node &y)
    {
        int ans = max(max(x.ans, y.ans), x.suff + y.pr);
        int pr, suff;
        if (x.pr == (x.ne - x.ns + 1))
            pr = x.pr + y.pr;
        else
            pr = x.pr;

        if (y.suff == (y.ne - y.ns + 1))
            suff = y.suff + x.suff;
        else
            suff = y.suff;
        return node(ans, pr, suff, x.ns, y.ne);
    }

    void build(int id, int ns, int ne)
    {
        if (ns == ne)
        {
            tree[id] = node((arr[ns] == 0), (arr[ns] == 0), (arr[ns] == 0), ns, ns);
            return;
        }
        int left = 2 * id + 1;
        int right = left + 1;
        int mid = ns + (ne - ns) / 2;
        build(left, ns, mid);
        build(right, mid + 1, ne);
        tree[id] = merge(tree[left], tree[right]);
    }

    node query(int qs, int qe, int id, int ns, int ne)
    {
        if (ns > qe || qs > ne)
            return node();

        if (qs <= ns && qe >= ne)
            return tree[id];

        int left = 2 * id + 1;
        int right = left + 1;
        int mid = ns + (ne - ns) / 2;

        node leftRes = query(qs, qe, left, ns, mid);
        node rightRes = query(qs, qe, right, mid + 1, ne);

        return merge(leftRes, rightRes);
    }

    void update(int pos, ll val, int id, int ns, int ne)
    {
        if (ns > pos || pos > ne)
            return;

        if (ns == ne)
        {
            tree[id] = node((val == 0), (val == 0), (val == 0), ns, ns);
            return;
        }

        int left = 2 * id + 1;
        int right = left + 1;
        int mid = ns + (ne - ns) / 2;

        update(pos, val, left, ns, mid);
        update(pos, val, right, mid + 1, ne);
        tree[id] = merge(tree[left], tree[right]);
    }

    SegmentTree(int size) : n(size)
    {
        tree.resize(4 * n);
        arr.resize(n);
    }

    void setArray(vector<ll> &a)
    {
        arr = a;
    }

    void build()
    {
        build(0, 0, n - 1);
    }

    node query(int l, int r)
    {
        return query(l, r, 0, 0, n - 1);
    }

    void update(int pos, ll val)
    {
        update(pos, val, 0, 0, n - 1);
    }
};

const int MAXN = 2e5 + 5;
vector<int> f[MAXN];
int rv[MAXN];

void solve()
{
    ll n, q;
    cin >> n >> q;

    vl v(n);
    cin >> v;

    map<ll, int> m;
    vl a(n);
    rep(i, 0, n)
    {
        if (!m.count(v[i]))
        {
            int id = m.size();
            m[v[i]] = id;
            rv[id] = v[i];
        }
        a[i] = m[v[i]];
        f[a[i]].pb(i);
    }

    rep(i, 0, q)
    {
        ll l, r;
        cin >> l >> r;
        l--;
        r--;
        set<int> s;
        rep(j, 0, 40)
        {
            int ind = rng() % (r - l + 1) + l;
            int x = a[ind];
            ll occ = upper_bound(all(f[x]), (int)r) - lower_bound(all(f[x]), (int)l);
            if (occ > ((r - l + 1) / 3))
                s.insert(rv[x]);
            if (s.size() > 1)
                break;
        }
        if (s.size() == 0)
            cout << -1 << endl;
        else
        {
            for (auto e : s)
                cout << e << " ";
            cout << endl;
        }
    }

    rep(i, 0, n)
        f[a[i]].clear();
    m.clear();
}

int main()
{
    ios_base::sync_with_stdio(false);

    cin.tie(0);
    cout.tie(0);
    std::cout << setprecision(15);
    fac[0] = 1;

    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }

    return 0;
}