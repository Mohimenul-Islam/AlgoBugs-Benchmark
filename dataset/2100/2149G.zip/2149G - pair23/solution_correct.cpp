#include <bits/stdc++.h>
using namespace std;

#define sync {ios_base ::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);}
#define ll long long
#define endl "\n"

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

void solve() {
    int n, q;
    if (!(cin >> n >> q)) return;
    
    vector<int> a(n);
    vector<int> vals;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
        vals.push_back(a[i]);
    }

    // 1. Coordinate Compression
    sort(vals.begin(), vals.end());
    vals.erase(unique(vals.begin(), vals.end()), vals.end());
    
    auto get_id = [&](int x) {
        return lower_bound(vals.begin(), vals.end(), x) - vals.begin();
    };

    int m = vals.size();
    vector<vector<int>> pos(m);
    for (int i = 0; i < n; i++) {
        a[i] = get_id(a[i]);
        pos[a[i]].push_back(i);
    }

    while (q--) {
        int l, r;
        cin >> l >> r;
        l--; r--; // 0-indexed
        int len = r - l + 1;
        int threshold = len / 3;

        // 2. Randomized Sampling
        vector<int> candidates;
        for (int i = 0; i < 40; i++) {
            int random_idx = uniform_int_distribution<int>(l, r)(rng);
            candidates.push_back(a[random_idx]);
        }
        
        // Only check unique candidates
        sort(candidates.begin(), candidates.end());
        candidates.erase(unique(candidates.begin(), candidates.end()), candidates.end());

        vector<int> results;
        for (int val_id : candidates) {
            const auto& v = pos[val_id];
            // 3. Fast Frequency Count
            int count = upper_bound(v.begin(), v.end(), r) - lower_bound(v.begin(), v.end(), l);
            if (count > threshold) {
                results.push_back(vals[val_id]); // Convert back to original 10^9 value
            }
        }

        // Output results in sorted order
        if (results.empty()) {
            cout << -1 << endl;
        } else {
            sort(results.begin(), results.end());
            results.erase(unique(results.begin(), results.end()), results.end());
            for (int i = 0; i < results.size(); i++) {
                cout << results[i] << (i == results.size() - 1 ? "" : " ");
            }
            cout << endl;
        }
    }
}

int main() {
    sync;
    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}