#include <bits/stdc++.h>

using namespace std;

#define sync {ios_base ::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);}
#define ll long long int
#define ld long double
#define tt int test; cin >> test; while(test--)
#define endl "\n"
#define YES cout << "YES" << endl
#define NO cout << "NO" << endl
#define Yes cout << "Yes" << endl
#define No cout << "No" << endl
#define setbit(x) __builtin_popcountll(x)
const ll M = 1e9+7;
const ll N = 998244353;

ll Binexp(ll a, ll b){
    if(b==0){
        return 1;
    }
    ll res = Binexp(a,b/2);
    if(b%2==0){
       return res * res;
    }
    else{
       return a * res * res;
    }
}
 
ll Binexpitr(ll a,ll b,int m){
    ll ans = 1;
    while(b){
        if(b&1){
            ans = (ans* 1ll *a)%m;
        }
        a = (a* 1ll *a)%m;
        b >>= 1;
    }
    return ans;
}

ll modinv(ll n, ll m){
   return Binexpitr(n,m-2,m);
}


string DtoBi(ll x){
    string s="";
    while(x>0){
        if(x&1){
            s.insert(0, "1");
        }
        else{
            s.insert(0, "0");
        }
        x>>=1;
    }
    return s;
}

struct custom_hash {
    static uint64_t splitmix64(uint64_t x) {
        // http://xorshift.di.unimi.it/splitmix64.c
        x += 0x9e3779b97f4a7c15;
        x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;
        x = (x ^ (x >> 27)) * 0x94d049bb133111eb;
        return x ^ (x >> 31);
    }

    size_t operator()(uint64_t x) const {
        static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();
        return splitmix64(x + FIXED_RANDOM);
    }
};

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int main(){
    sync;
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
    tt{
        ll n,q;cin>>n>>q;
        unordered_map<ll,vector<ll>,custom_hash> pos;
        vector<ll> a(n);
        for(ll i =0;i<n;i++){
            ll x;cin>>x;
            a[i] = x;
            pos[a[i]].push_back(i);
        }
        auto chkf = [&](ll num,ll l,ll r) {
            ll sze = r - l + 1, req = (sze / 3) + 1;
            if(pos[num].size() < req) return 0ll;
            
            auto it1 = lower_bound(pos[num].begin(), pos[num].end(), l);
            if(it1 == pos[num].end()) return 0ll;
            
            auto it2 = upper_bound(pos[num].begin(), pos[num].end(), r);
            ll count = distance(it1, it2);
            
            return (count >= req) ? 1ll : 0ll;
        };
        while(q--){
            ll l,r;cin>>l>>r;
            l--;r--;
            ll sze = r-l+1,req = (sze/3) + 1;
            set<ll> ans;
            if(sze <= 100){
                map<ll,ll> frq;
                for(ll i = l;i<=r;i++){
                    frq[a[i]]++;
                    if(frq[a[i]] >= req) ans.insert(a[i]);
                }
            }
            else{
                uniform_int_distribution<ll> dist(l, r);
                unordered_map<ll,ll> nums;
                vector<ll> num;
                ll cnt = 0;
                while(cnt < 39){
                    ll ind = dist(rng);
                    ind %= sze;
                    ind+=l;
                    num.push_back(a[ind]);
                    cnt++;
                }
                for(auto it : num){
                    if(nums[it]) continue;
                    nums[it] = 1;
                    if(chkf(it,l,r)){
                        ans.insert(it);
                    }
                    if(ans.size() > 1) break;
                }
            }
            if(ans.empty()) cout << -1 << endl;
            else{
                for(auto it : ans) cout << it <<" ";
                cout << endl;
            }
        }
    }
}
