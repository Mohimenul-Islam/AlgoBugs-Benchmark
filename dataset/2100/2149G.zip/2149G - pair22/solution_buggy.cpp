#include <bits/stdc++.h>
using namespace std;
#define int long long
#define all(a) (a).begin(), (a).end()
#define optimize() ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
const int N = 2e5 + 7;

int a[N];
set<pair<int, int>> cnt[4 * N], xx;
int need;

set<pair<int, int>> marge(set<pair<int, int>> x, set<pair<int, int>> y) {
    map<int, int> cx;
    set<pair<int, int>> ans;

    for (auto& [s, f] : x) cx[f] += s;
    for (auto& [s, f] : y) cx[f] += s;

    vector<pair<int, int>> qq;
    for (auto& [f, s] : cx) {
        qq.push_back({ s, f });
    }

    sort(all(qq));

    for (int i = (int)qq.size() - 1; i >= 0; i--) {
        auto cur = qq[i];
        ans.insert(cur);
        if (ans.size() > 2) break;
    }

    return ans;
}

void build(int node, int l, int r) {
    if (l == r) {
        cnt[node].insert({ 1LL, a[l] });
        return;
    }

    int md = (l + r) / 2;
    build(2 * node, l, md);
    build(2 * node + 1, md + 1, r);

    cnt[node] = marge(cnt[2 * node], cnt[2 * node + 1]);
}

void result(int node, int l, int r, int lo, int hi) {
    if (lo > r || l > hi) return;

    if (l >= lo && r <= hi) {
        xx = marge(xx, cnt[node]);
        return;
    }

    int md = (l + r) / 2;
    result(2 * node, l, md, lo, hi);
    result(2 * node + 1, md + 1, r, lo, hi);
}

signed main() {
    optimize();
    int t; cin >> t;
    while (t--) {
        int n, q; cin >> n >> q;
        for (int i = 1; i < 4 * n + 4; i++) cnt[i].clear();
        for (int i = 1; i <= n; i++) cin >> a[i];
        build(1, 1, n);
        while (q--) {
            int l, r; cin >> l >> r;
            need = (r - l + 1) / 3;
            xx.clear();
            result(1, 1, n, l, r);
            vector<int> aa;
            for (auto it = xx.rbegin(); it != xx.rend(); it++) {
                auto& [f, val] = *it;
                if (f > need) {
                    aa.push_back(val);
                } else {
                    break;
                }
            }
            sort(all(aa));
            if (aa.size()) {
                for (auto u : aa) cout << u << " "; cout << endl;
            } else cout << -1 << endl;
        }
    }
}