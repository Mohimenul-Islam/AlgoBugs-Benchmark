#include <bits/stdc++.h>
using namespace std;
#define int long long
#define all(a) (a).begin(), (a).end()
#define optimize() ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
vector<int>compress(vector<int> v) {
    set<int>st;
    for (int i = 0;i < v.size();i++)st.insert(v[i]);
    int i = 1;
    map<int, int>mp;
    for (auto u : st) {
        mp[u] = i;
        i++;
    }
    for (int i = 0;i < v.size();i++) {
        v[i] = mp[v[i]];
    }
    return v;
}
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int getRandom(int l, int r) {
    return uniform_int_distribution<int>(l, r)(rng);
}
signed main() {
    optimize();
    int t;cin >> t;
    while (t--) {
        int n, q;cin >> n >> q;
        vector<int>a(n), b(n);
        for (int i = 0;i < n;i++)cin >> a[i];
        b = compress(a);
        vector<int>po[n + 3];
        for (int i = 0;i < n;i++) {
            po[b[i]].push_back(i);
        }
        while (q--) {
            int p = -1, q = -1;
            int l, r;cin >> l >> r;
            l--;r--;
            int need = (r + 1 - l) / 3;
            vector<int>ix;
            map<int, int>mp;
            for (int i = 0;i < 50;i++) {
                int id = getRandom(l, r);
                if (mp[a[id]])continue;
                int ar = lower_bound(all(po[b[id]]), r + 1) - po[b[id]].begin();
                int al = 0;
                if (l > 0)al = lower_bound(all(po[b[id]]), l) - po[b[id]].begin();
                if (ar - al > need) {
                    if (p == -1)p = a[id];
                    else {
                        q = a[id];
                        break;
                    }
                }
                mp[a[id]]++;
            }
           // cout << p << " " << q << endl;
            if (max(p, q) == -1)cout << -1 << endl;
            else if (q==-1)cout << p << endl;
            else cout << min(p, q) << " " << max(p, q) << endl;
        }
    }

}