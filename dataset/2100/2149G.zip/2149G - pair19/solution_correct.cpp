#include <bits/stdc++.h>
using namespace std;
using pi = pair<int, int>;
using vi = vector<int>;
using vvi = vector<vi>;

/*
randomised algorithm - if occ(x) > (r-l+1)/3, then it has 1/3 probability of showing up when querying a random index
ie. 2/3 chance that it doesn't show up. (2/3)^60 samples gives an absolutely negligible chance of not finding the answer,
and is also easier to write code for
*/

void solve() {
    int n, q; cin >> n >> q;
    vector<int> a(n); for (auto &x : a) cin >> x;
    vi as = a; sort(as.begin(), as.end());
    vi b(n); for (int i = 0; i < n; i++) b[i] = lower_bound(as.begin(), as.end(), a[i]) - as.begin();
    vvi pos(n); for (int i = 0; i < n; i++) pos[b[i]].push_back(i);
    mt19937 rng(chrono::system_clock::now().time_since_epoch().count());

    while (q--) {
        int l, r; cin >> l >> r;
        l--; r--; 
        uniform_int_distribution dist(l, r);

        auto nxt = [&]() {
            int x = dist(rng);
            return x;
        };

        vector<int> ans; set<int> found;
        for (int i = 0; i < 50; i++) {
            if (found.size() > 1) break;
            int x = nxt(); if (found.count(b[x])) continue;
            if (pos[b[x]].size() <= (r-l+1)/3) continue;
            int w = lower_bound(pos[b[x]].begin(), pos[b[x]].end(), l) - pos[b[x]].begin();
            int z = upper_bound(pos[b[x]].begin(), pos[b[x]].end(), r) - pos[b[x]].begin();
            if ((z-w) > (r-l+1)/3) ans.push_back(a[x]), found.insert(b[x]);
        }

        sort(ans.begin(), ans.end());
        ans.erase(unique(ans.begin(), ans.end()), ans.end());

        for (auto &x : ans) cout << x << " "; 
        if (ans.empty()) cout << "-1";
        cout << "\n";
    }
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    int t; cin >> t;
    while (t--) solve();
    return 0;
}