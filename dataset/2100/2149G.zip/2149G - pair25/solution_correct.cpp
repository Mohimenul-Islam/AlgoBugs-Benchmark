#include<bits/stdc++.h>
#define endl '\n'
#define all(x) x.begin(), x.end()
using namespace std;
const int N = 200010;
mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());
int T, n, q, a[N], b[N], id[N];
// map<int, vector<int>> mp;
vector<vector<int>> mp;
void solve()
{
    cin >> n >> q;
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
        b[i] = a[i];
    }
    sort(b + 1, b + n + 1);
    int siz = unique(b + 1, b + n + 1) - b - 1;
    mp.assign(siz + 1, {});
    for (int i = 1; i <= n; i++)
    {
        id[i] = lower_bound(b + 1, b + siz + 1, a[i]) - b;
        mp[id[i]].emplace_back(i);
    }
    while (q--)
    {
        int l, r;
        cin >> l >> r;
        int len = r - l + 1;
        set<int> ans;
        for (int i = 0; i < 50 && ans.size() < 2; i++)
        {
            if (ans.size() == 1 && len == 1) break;
            int p = l + rng() % len;
            auto& pos = mp[id[p]];
            int pr = upper_bound(all(pos), r) - pos.begin() - 1;
            if (pr == -1) continue;
            int pl = lower_bound(all(pos), l) - pos.begin();
            int cnt = pr - pl + 1;
            if (cnt > len / 3)
                ans.emplace(a[p]);
        }
        if (ans.empty())
            cout << -1 << endl;
        else
        {
            for (int x : ans)
                cout << x << " ";
            cout << endl;
        }
    }
}
int main()
{
    ios::sync_with_stdio(0); cin.tie(0);
    cin >> T;
    while (T--)
        solve();
    return 0;
}