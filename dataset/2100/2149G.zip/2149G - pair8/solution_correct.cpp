#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef double db;
typedef long double ldb;
mt19937 mrand(1);
int T;
int n,q;
int a[200005];
bool vis[200005];
vector<int>v[200005];
int main(){
	srand(time(0));
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&n,&q);
		vector<int>b;
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
			b.push_back(a[i]);
		}
		sort(b.begin(),b.end());
		b.erase(unique(b.begin(),b.end()),b.end());
		for(int i=0;i<(int)b.size();i++){
			v[i].clear();
		}
		for(int i=1;i<=n;i++){
			a[i]=lower_bound(b.begin(),b.end(),a[i])-b.begin();
			v[a[i]].push_back(i);
		}
		while(q--){
			int l,r;
			scanf("%d%d",&l,&r);
			vector<int>w,ans;
			for(int i=1;i<=70;i++){
				int x=a[mrand()%(r-l+1)+l];
				if (vis[x]){
					continue;
				}
				w.push_back(x);
				vis[x]=1;
				int cnt=upper_bound(v[x].begin(),v[x].end(),r)-lower_bound(v[x].begin(),v[x].end(),l);
				if (cnt>(r-l+1)/3){
					ans.push_back(b[x]);
				}
			}
			if (ans.empty()){
				puts("-1");
			}else{
				sort(ans.begin(),ans.end());
				for(auto i:ans){
					printf("%d ",i);
				}
				puts("");
			}
			for(auto i:w){
				vis[i]=0;
			}
		}
	}
	return 0;
}