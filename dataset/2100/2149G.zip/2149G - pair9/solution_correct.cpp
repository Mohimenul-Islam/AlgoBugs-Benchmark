#include <bits/stdc++.h>
using namespace std;

#define ll long long

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

const int N = 200000 + 5;

int n, q;
int a[N];
int realVal[N];
vector<int> pos[N];
map<int, int> mp;

int cntOcc(int x, int l, int r)
{
    auto &v = pos[x];
    int right = upper_bound(v.begin(), v.end(), r) - v.begin();
    int left = lower_bound(v.begin(), v.end(), l) - v.begin();
    return right - left;
}

void _go()
{
    cin >> n >> q;

    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
        if (!mp.count(a[i]))
        {
            int id = (int)mp.size();
            mp[a[i]] = id;
            realVal[id] = a[i];
        }
        a[i] = mp[a[i]];
    }

    int distinct = mp.size();

    for (int i = 1; i <= n; i++)
        pos[a[i]].push_back(i);

    while (q--)
    {
        int l, r;
        cin >> l >> r;

        int need = (r - l + 1) / 3;
        vector<int> ans;

        for (int it = 0; it < 50; it++)
        {
            int idx = l + (rng() % (r - l + 1));
            int x = a[idx];

            if (cntOcc(x, l, r) > need)
            {
                int val = realVal[x];
                if (ans.empty() || find(ans.begin(), ans.end(), val) == ans.end())
                    ans.push_back(val);
            }
        }

        if (ans.empty())
        {
            cout << -1 << '\n';
        }
        else
        {
            sort(ans.begin(), ans.end());
            ans.erase(unique(ans.begin(), ans.end()), ans.end());
            for (int x : ans)
                cout << x << ' ';
            cout << '\n';
        }
    }

    mp.clear();
    for (int i = 0; i < distinct; i++)
        pos[i].clear();
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--)
        _go();

    return 0;
}