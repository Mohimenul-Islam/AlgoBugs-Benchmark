#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define endl '\n'

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

void _go()
{
    int n, q;
    cin >> n >> q;

    vector<int> a(n);
    unordered_map<int, vector<int>> pos;
    pos.reserve(n * 2);

    for (int i = 0; i < n; ++i)
    {
        cin >> a[i];
        pos[a[i]].push_back(i);
    }

    auto check = [&](int x, int l, int r) -> bool
    {
        auto &vec = pos[x];
        int cnt = upper_bound(vec.begin(), vec.end(), r) - lower_bound(vec.begin(), vec.end(), l);
        return cnt > (r - l + 1) / 3;
    };

    auto pickRandIndex = [&](int l, int r) -> int
    {
        uniform_int_distribution<int> dist(l, r);
        return dist(rng);
    };

    while (q--)
    {
        int l, r;
        cin >> l >> r;
        --l, --r;

        set<int> ans;

        for (int it = 0; it < 50; ++it)
        {
            int idx = pickRandIndex(l, r);
            int val = a[idx];
            if (!ans.count(val) && check(val, l, r))
                ans.insert(val);
        }

        if (ans.empty())
            cout << -1 << endl;
        else
        {
            for (int x : ans)
                cout << x << ' ';
            cout << endl;
        }
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--)
        _go();

    return 0;
}