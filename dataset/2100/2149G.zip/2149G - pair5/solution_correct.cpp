#include<bits/stdc++.h>
using namespace std;
using ll = long long int;
using ii = pair<int,int>;
using iii = tuple<int,int,int>;

const int mxn = 2e5 + 3;
const int d = 400;
void solve(){
    int n, q;
    cin >> n >> q;
    vector<vector<ii>> left(n);
    vector<int> a(n);
    for (int i = 0 ; i< n ; i++)
        cin >> a[i];
    vector<int> comp = a;
    sort(comp.begin(), comp.end());
    comp.resize(unique(comp.begin(), comp.end()) - comp.begin());
    for (int i = 0; i < n; i++) {
        a[i] = lower_bound(comp.begin(), comp.end(), a[i]) - comp.begin();
    }
    for (int i = 0; i < q; i++) {
        int l, r;
        cin >> l >> r;
        l--, r--;
        left[l].push_back({r, i});
    } 
    vector<vector<iii>> groups;
    for (int i = 0; i < n;) {
        vector<iii> group;
        for (int j = 0; j < d && i + j < n; j++) {
            for (auto [r, id] : left[j+i]) {
                group.push_back({r, j+i, id});
            }
        }
        groups.push_back(group);
        i = i + d;
    }
    vector<vector<int>> ans(q);
    for (vector<iii>& group : groups) {
        sort(group.begin(), group.end(), greater<iii>());
        vector<int> nextl(group.size()), nextr(group.size()), id(group.size());
        for (int i = 0; i < group.size(); i++) {
            nextl[i] = get<1>(group[i]);
            nextr[i] = get<0>(group[i]);
            id[i] = get<2>(group[i]);
        }
        int V = comp.size();
        vector<int> cnt(V, 0);
        vector<int> S(V);
        vector<int> pos(V);
        vector<int> first(n + 1, -1);
        vector<int> freq_cnt(n + 1, 0);

        for (int i = 0; i < V; i++) {
            S[i] = i;
            pos[i] = i;
        }
        first[0] = 0;
        freq_cnt[0] = V;

        auto add = [&](int v) {
            int c = cnt[v];
            int p1 = pos[v];
            int p2 = first[c]; 
            
            int v2 = S[p2];
            
            swap(S[p1], S[p2]);
            pos[v] = p2;
            pos[v2] = p1;
            
            first[c]++;
            freq_cnt[c]--;
            if (freq_cnt[c] == 0) first[c] = -1;
            
            cnt[v]++;
            c++;
            
            if (freq_cnt[c] == 0) first[c] = p2;
            freq_cnt[c]++;
        };

        auto remove = [&](int v) {
            int c = cnt[v];
            int p1 = pos[v];
            int p2 = first[c] + freq_cnt[c] - 1;
            
            int v2 = S[p2];
            
            swap(S[p1], S[p2]);
            pos[v] = p2;
            pos[v2] = p1;
            
            freq_cnt[c]--;
            if (freq_cnt[c] == 0) first[c] = -1;
            
            cnt[v]--;
            c--;
            
            first[c] = p2;
            freq_cnt[c]++;
        };
        int l = 0, r = -1;
        for (int i = 0; i < group.size(); i++) {
            while (l > nextl[i]) {
                l--;
                add(a[l]);
            }
            while (r < nextr[i]) {
                r++;
                add(a[r]);
            }
            while (l < nextl[i]) {
                remove(a[l]);
                l++;
            }
            while (r > nextr[i]) {
                remove(a[r]);
                r--;
            }
            int threshold = (r-l+1)/3;
            if (V > 0 && cnt[S[0]] > threshold) {
                ans[id[i]].push_back(S[0]);
            }
            if (V > 1 && cnt[S[1]] > threshold) {
                ans[id[i]].push_back(S[1]);
            }
        } 
    }
    for (int i = 0; i < q; i++) {
        sort(ans[i].begin(), ans[i].end());
        if (ans[i].size() == 0)
            cout << -1;
        else {
            for (int val : ans[i])
                cout << comp[val] << " ";
        }
        cout << '\n';
    }
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while(t--)
        solve();
}