#include<bits/stdc++.h>
using namespace std;
using ll = long long int;
using ii = pair<int,int>;
using iii = tuple<int,int,int>;

const int mxn = 2e5 + 3;
const int d = 400;
void solve(){
    int n, q;
    cin >> n >> q;
    vector<vector<ii>> left(n);
    vector<int> a(n);
    for (int i = 0 ; i< n ; i++)
        cin >> a[i];
    vector<int> comp = a;
    sort(comp.begin(), comp.end());
    comp.resize(unique(comp.begin(), comp.end()) - comp.begin());
    for (int i = 0; i < n; i++) {
        a[i] = lower_bound(comp.begin(), comp.end(), a[i]) - comp.begin();
    }
    for (int i = 0; i < q; i++) {
        int l, r;
        cin >> l >> r;
        l--, r--;
        left[l].push_back({r, i});
    } 
    vector<vector<iii>> groups;
    for (int i = 0; i < n;) {
        vector<iii> group;
        for (int j = 0; j < d && i + j < n; j++) {
            for (auto [r, id] : left[j+i]) {
                group.push_back({r, j+i, id});
            }
        }
        groups.push_back(group);
        i = i + d;
    }
    vector<int> cnt(n+1);
    set<ii, greater<ii>> spaghetticode;
    vector<vector<int>> ans(q);
    for (vector<iii>& group : groups) {
        sort(group.begin(), group.end(), greater<iii>());
        vector<int> nextl(group.size()), nextr(group.size()), id(group.size());
        for (int i = 0; i < group.size(); i++) {
            nextl[i] = get<1>(group[i]);
            nextr[i] = get<0>(group[i]);
            id[i] = get<2>(group[i]);
        }
        int l = 0, r = -1;
        fill(cnt.begin(), cnt.end(), 0);
        spaghetticode.clear();
        for (int i = 0; i < group.size(); i++) {
            while (l < nextl[i]) {
                spaghetticode.erase({cnt[a[l]], a[l]});
                cnt[a[l]]--;
                spaghetticode.insert({cnt[a[l]], a[l]});
                l++;
            }
            while (l > nextl[i]) {
                l--;
                spaghetticode.erase({cnt[a[l]], a[l]});
                cnt[a[l]]++;
                spaghetticode.insert({cnt[a[l]], a[l]});
            }
            while (r > nextr[i]) {
                spaghetticode.erase({cnt[a[r]], a[r]});
                cnt[a[r]]--;
                spaghetticode.insert({cnt[a[r]], a[r]});
                r--;
            }
            while (r < nextr[i]) {
                r++;
                spaghetticode.erase({cnt[a[r]], a[r]});
                cnt[a[r]]++;
                spaghetticode.insert({cnt[a[r]], a[r]});
            }
            int j = 0;
            for (auto [freq, val] : spaghetticode) {
                if (freq > (r-l+1)/3) {
                    ans[id[i]].push_back(val);
                }
                j++;
                if (j >= 3)
                    break;
            }
        } 
    }
    for (int i = 0; i < q; i++) {
        sort(ans[i].begin(), ans[i].end());
        if (ans[i].size() == 0)
            cout << -1;
        else {
            for (int val : ans[i])
                cout << comp[val] << " ";
        }
        cout << '\n';
    }
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while(t--)
        solve();
}