#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;
#define ll long long
#define pii pair<int,int>
#define m_p make_pair
const int MAXN=2e5+10;
struct SegmentTree{
    int cand1[MAXN<<2],cand2[MAXN<<2],cnt1[MAXN<<2],cnt2[MAXN<<2];
    pii arr[MAXN];
    void build2(int a[],int n){
        for(int i=1;i<=n;i++){
            arr[i].first=a[i];
            arr[i].second=i;
        }
        sort(arr+1,arr+n+1);
    }
    void build(int a[],int l,int r,int i){
        cand1[i]=-1;
        cnt1[i]=0;
        cand2[i]=-1;
        cnt2[i]=0;
        if(l==r){
            cand1[i]=a[l];
            cnt1[i]=1;
        }else{
            int mid=(l+r)>>1;
            build(a,l,mid,i<<1);
            build(a,mid+1,r,i<<1|1);
            up(i);
        }
    }
    void merge(int &rcd1,int &rcd2,int &rct1,int &rct2,int cd1,int cd2,int ct1,int ct2){
        vector<pii> vec;
        map<int,int> mp;
        if(rcd1!=-1) mp[rcd1]+=rct1;
        if(rcd2!=-1) mp[rcd2]+=rct2;
        if(cd1!=-1) mp[cd1]+=ct1;
        if(cd2!=-1) mp[cd2]+=ct2;
        for(auto [f,s]:mp){
            if(s>0) vec.push_back(m_p(s,f));
        }
        sort(vec.rbegin(),vec.rend());
        while(vec.size()>2){
            vec[0].first-=vec[2].first;
            vec[1].first-=vec[2].first;
            vec[2].first=0;
            sort(vec.rbegin(),vec.rend());
            while(!vec.empty() && vec.back().first<=0){
                vec.pop_back();
            }
        }
        if(vec.size()>=1){
            rcd1=vec[0].second;
            rct1=vec[0].first;
        }else{
            rcd1=-1;
            rct1=0;
        }
        if(vec.size()>=2){
            rcd2=vec[1].second;
            rct2=vec[1].first;
        }else{
            rcd2=-1;
            rct2=0;
        }
    }
    void up(int i){
        merge(cand1[i],cand2[i],cnt1[i],cnt2[i],cand1[i<<1],cand2[i<<1],cnt1[i<<1],cnt2[i<<1]);
        merge(cand1[i],cand2[i],cnt1[i],cnt2[i],cand1[i<<1|1],cand2[i<<1|1],cnt1[i<<1|1],cnt2[i<<1|1]);
    }
    void query2(int jobl,int jobr,int l,int r,int i,int &rcd1,int &rcd2,int &rct1,int &rct2){
        if(jobl<=l && jobr>=r){
            merge(rcd1,rcd2,rct1,rct2,cand1[i],cand2[i],cnt1[i],cnt2[i]);
        }else{
            int mid=(l+r)>>1;
            if(jobl<=mid){
                query2(jobl,jobr,l,mid,i<<1,rcd1,rcd2,rct1,rct2);
            }
            if(jobr>mid){
                query2(jobl,jobr,mid+1,r,i<<1|1,rcd1,rcd2,rct1,rct2);
            }
        }
    }
    void query1(int jobl,int jobr,int n){
        int rcd1=-1,rcd2=-1,rct1=0,rct2=0;
        query2(jobl,jobr,1,n,1,rcd1,rcd2,rct1,rct2);
        if(rcd1>rcd2 && rcd2!=-1) swap(rcd1,rcd2);
        int L,R;
        int l=1,r=n;
        int mid;
        if(rcd1==-1 && rcd2==-1){
            cout<<-1<<"\n";
            return;
        }
        bool b=0;
        if(rcd1!=-1){
            while(l<r){
                mid=(l+r)>>1;
                if(arr[mid].first<rcd1 || arr[mid].first==rcd1 && arr[mid].second<jobl){
                    l=mid+1;
                }else{
                    r=mid;
                }
            }
            L=r;
            l=1,r=n;
            while(l<r){
                mid=(l+r+1)>>1;
                if(arr[mid].first>rcd1 || arr[mid].first==rcd1 && arr[mid].second>jobr){
                    r=mid-1;
                }else{
                    l=mid;
                }
            }
            R=l;
            if(R-L+1>(jobr-jobl+1)/3) {cout<<rcd1<<' ';b=1;}
        }
        
        if(rcd2!=-1){
            l=1,r=n;
            while(l<r){
                mid=(l+r)>>1;
                if(arr[mid].first<rcd2 || arr[mid].first==rcd2 && arr[mid].second<jobl){
                    l=mid+1;
                }else{
                    r=mid;
                }
            }
            L=r;
            l=1,r=n;
            while(l<r){
                mid=(l+r+1)>>1;
                if(arr[mid].first>rcd2 || arr[mid].first==rcd2 && arr[mid].second>jobr){
                    r=mid-1;
                }else{
                    l=mid;
                }
            }
            R=l;
            if(R-L+1>(jobr-jobl+1)/3) {cout<<rcd2<<' ';b=1;}
        }
        if(!b) cout<<-1;
        cout<<"\n";
        
    }




};
SegmentTree A;
void solve(){
    int n,q;
    cin>>n>>q;
    int a[n+1];
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    A.build(a,1,n,1);
    A.build2(a,n);
    int l,r;
    while(q--){
        cin>>l>>r;
        A.query1(l,r,n);
    }

}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin>>T;
    while(T--)
    solve();
}