#include <bits/stdc++.h>

using namespace std ;

const int N = 2e5+5 ;

int n , q , a[N] ;
vector <int> co , pos[N] ;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
int rand ( int x , int y ) {
    return uniform_int_distribution <int> ( x , y ) (rng) ;
}

inline void solve () {
    cin >> n >> q ;
    for ( int i = 1 ; i <= n ; i++ ) {
        cin >> a[i] ;
        co.push_back(a[i]) ;
    }
    sort ( co.begin() , co.end() ) ;
    co.resize ( unique ( co.begin() , co.end() ) - co.begin() ) ;
    for ( int i = 1 ; i <= n ; i++ ) {
        a[i] = lower_bound ( co.begin() , co.end() , a[i] ) - co.begin() + 1 ;
        pos[a[i]].push_back(i) ;
    }
    while ( q-- ) {
        int l , r ;
        cin >> l >> r ;
        set <int> st ;
        for ( int i = 1 ; i <= 50 ; i++ ) {
            int id = a[rand(l,r)] ;
            int y = upper_bound ( pos[id].begin() , pos[id].end() , r ) - pos[id].begin() ;
            int x = lower_bound ( pos[id].begin() , pos[id].end() , l ) - pos[id].begin() ;
            if ( y - x > ( r - l + 1 ) / 3 ) {
                st.insert(co[id-1]) ;
            }
        }
        if ( st.empty() ) {
            st.insert(-1) ;
        }
        for ( auto it : st ) {
            cout << it << " " ;
        }
        cout << "\n" ;
    }
    for ( int i = 1 ; i <= (int)co.size() ; i++ ) {
        pos[i].clear() ;
    }
    co.clear() ;
}

signed main () {
    //freopen ( ".in" , "r" , stdin ) ;
    //freopen ( ".out" , "w" , stdout ) ;
    ios_base::sync_with_stdio(0) ;
    cin.tie(0) ;
    cout.tie(0) ;
    int tc = 1 ;
    cin >> tc ;
    while ( tc-- ) {
        solve() ;
    }
    return 0 ;
}

///  JJJJJJJ EEEEEEE  AAAAA  NN   NN 7777777
///     JJ   EE      AA   AA NNN  NN     77
///     JJ   EEEEEE  AAAAAAA NN N NN    77
///  JJ JJ   EE      AA   AA NN  NNN   77
///  JJJJJ   EEEEEEE AA   AA NN   NN  77
