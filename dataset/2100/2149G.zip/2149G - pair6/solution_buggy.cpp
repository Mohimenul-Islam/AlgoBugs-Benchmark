#include <bits/stdc++.h>
#define le ll[node]
#define ri rr[node]
#define mid ((l+r)>>1)

using namespace std ;

const int N = 2e5+5 ;

vector <int> co ;
int n , q , a[N] , rt[N] ;

struct Segment_Tree_Persistent {
    int tree[40*N] , ll[40*N] , rr[40*N] , idx = 0 ;
    int leaf ( int v ) {
        idx++ ;
        ll[idx] = rr[idx] = 0 ;
        tree[idx] = v ;
        return idx ;
    }
    int parent ( int x , int y ) {
        idx++ ;
        ll[idx] = x ;
        rr[idx] = y ;
        return idx ;
    }
    int build ( int l , int r ) {
        if ( l == r ) {
            return leaf ( 0 ) ;
        }
        return parent ( build ( l , mid ) , build ( mid+1 , r ) ) ;
    }
    int update ( int node , int l , int r , int i ) {
        if ( l == r ) {
            return leaf ( tree[node]+1 ) ;
        }
        if ( i <= mid ) {
            return parent ( update ( le , l , mid , i ) , ri ) ;
        }
        return parent ( le , update ( ri , mid+1 , r , i ) ) ;
    }
    int query ( int node , int l , int r , int i ) {
        if ( l == r ) {
            return tree[node] ;
        }
        if ( i <= mid ) {
            return query ( le , l , mid , i ) ;
        }
        return query ( ri , mid+1 , r , i ) ;
    }
} seg ;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
int rand ( int x , int y ) {
    return uniform_int_distribution <int> ( x , y ) (rng) ;
}

inline void solve () {
    cin >> n >> q ;
    for ( int i = 1 ; i <= n ; i++ ) {
        cin >> a[i] ;
        co.push_back(a[i]) ;
    }
    sort ( co.begin() , co.end() ) ;
    co.resize ( unique ( co.begin() , co.end() ) - co.begin() ) ;
    int m = co.size() ;
    rt[0] = seg.build ( 1 , m ) ;
    for ( int i = 1 ; i <= n ; i++ ) {
        a[i] = lower_bound ( co.begin() , co.end() , a[i] ) - co.begin() + 1 ;
        rt[i] = seg.update ( rt[i-1] , 1 , m , a[i] ) ;
    }
    while ( q-- ) {
        int l , r ;
        cin >> l >> r ;
        set <int> st ;
        for ( int i = 1 ; i <= 25 ; i++ ) {
            int id = a[rand(l,r)] ;
            if ( seg.query ( rt[r] , 1 , m , id ) - seg.query ( rt[l-1] , 1 , m , id ) > ( r - l + 1 ) / 3 ) {
                st.insert(co[id-1]) ;
            }
        }
        if ( st.empty() ) {
            st.insert(-1) ;
        }
        for ( auto it : st ) {
            cout << it << " " ;
        }
        cout << "\n" ;
    }
}

signed main () {
    //freopen ( ".in" , "r" , stdin ) ;
    //freopen ( ".out" , "w" , stdout ) ;
    ios_base::sync_with_stdio(0) ;
    cin.tie(0) ;
    cout.tie(0) ;
    int tc = 1 ;
    cin >> tc ;
    while ( tc-- ) {
        solve() ;
        co.clear() ;
    }
    return 0 ;
}

///  JJJJJJJ EEEEEEE  AAAAA  NN   NN 7777777
///     JJ   EE      AA   AA NNN  NN     77
///     JJ   EEEEEE  AAAAAAA NN N NN    77
///  JJ JJ   EE      AA   AA NN  NNN   77
///  JJJJJ   EEEEEEE AA   AA NN   NN  77
