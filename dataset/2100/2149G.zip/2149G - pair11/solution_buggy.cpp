#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef pair<int,int>P;
const int N=1e6+7;
const int mod=1e9+7;
int n;
string s;
#define lu (u<<1)
#define ru (u<<1|1)
#define mid (l+r>>1)
#define lson lu,l,mid
#define rson ru,mid+1,r
#define root 1, 1, n
struct w{
	int l,r;
    int val,hp;
    int val1,hp1;
}tree[N<<2];
struct w1{
	int val,id;
    bool operator < (const w1& other)const{
        if(val!=other.val)return val<other.val;
        return id<other.id;
    }
}a[N];
struct Node{
    int v1,c1;
    int v2,c2;
};
Node merge(Node a, Node b){
    vector<P>v;
    if(a.c1)v.push_back({a.v1,a.c1});
    if(a.c2)v.push_back({a.v2,a.c2});
    if(b.c1)v.push_back({b.v1,b.c1});
    if(b.c2)v.push_back({b.v2,b.c2});
    Node res={0,0,0,0};
    for(auto [x,c]:v){
        if(res.v1==x) res.c1+=c;
        else if(res.v2==x) res.c2+=c;
        else if(res.c1==0) res.v1=x,res.c1=c;
        else if(res.c2==0) res.v2=x,res.c2=c;
        else{
            int d=min({res.c1,res.c2,c});
            res.c1-=d;
            res.c2-=d;
            c-=d;
            if(c){
                if(res.c1==0) res.v1=x,res.c1=c;
                else res.v2=x,res.c2=c;
            }
        }
    }
    return res;
}

void pushup(int u){
	int x=tree[lu].val,y=tree[lu].hp;
	int x1=tree[lu].val1,y1=tree[lu].hp1;
	int x2=tree[ru].val,y2=tree[ru].hp;
	int x3=tree[ru].val1,y3=tree[ru].hp1;
    Node res=merge({x,y,x1,y1},{x2,y2,x3,y3});
    tree[u].val=res.v1;
    tree[u].hp=res.c1;
    tree[u].val1=res.v2;
    tree[u].hp1=res.c2;
}
void build(int u,int l,int r){
	tree[u]={l,r,0,0,0,0};
    if(l==r){
        cin>>tree[u].val;
        tree[u].hp=1;
        tree[u].val1=0;
        tree[u].hp1=0;
        a[l].val=tree[u].val;
        a[l].id=l;
		return;
    }
	build(lson);
	build(rson);
	pushup(u);
}
Node query(int u,int l,int r,int L,int R){
	if(l>R||L>r)return {0,0,0,0};
	if(L<=l&&R>=r)return {tree[u].val,tree[u].hp,tree[u].val1,tree[u].hp1};
    return merge(query(lson,L,R),query(rson,L,R));
}
int get(int x,int l,int r){
    w1 L={x,l};
    w1 R={x,r};
    auto it1=lower_bound(a+1,a+1+n,L);
    auto it2=upper_bound(a+1,a+1+n,R);
    return it2-it1;
}
void run(){
	int q;
    cin>>n>>q;
    build(root);
    sort(a+1,a+1+n);
    while(q--){
        int l,r;
        cin>>l>>r;
        Node p=query(root,l,r);
        if(p.v1==0&&p.v2==0){
            cout<<-1<<'\n';
            continue;
        }
        vector<int> ans;
        if(p.v1!=0&&get(p.v1,l,r)>(r-l+1)/3)ans.push_back(p.v1);
        if(p.v2!=p.v1&&p.v2!=0&&get(p.v2,l,r)>(r-l+1)/3)ans.push_back(p.v2);
        if(ans.empty())cout<<-1<< '\n';
        else{
            for(int x:ans)cout<<x<< ' ';
            cout<<'\n';
        }
    }
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int T;cin>>T;while(T--)
	run();
	return 0;
}