#include <bits/stdc++.h>
using namespace std;

const int M = 200005, K = 40; int n, q, a[M], dl[M];
vector<pair<int,int>> candy[M], pom; vector<int> odp[M];
pair<int,int> ile[M]; tuple<int,bool,int> qiqi[2*M];
mt19937_64 rnd(69);
void dodaj(int x) {
    (*lower_bound(ile,ile+n,make_pair(x,0))).second++;
}
int policz(int x) {
    return (*lower_bound(ile,ile+n,make_pair(x,0))).second;
}
void solve() {
    cin >> n >> q; int l,r;
    for (int i = 1; i <= n; i++)
        cin >> a[i], ile[i-1] = {a[i],0};
    for (int i = 0; i < q; i++) {
        cin >> l >> r, dl[i] = r-l+1;
        for (int j = 0; j < K; j++)
            candy[i].push_back({a[l+rnd()%(r-l+1)],0});
        sort(candy[i].begin(),candy[i].end());
        for (int j = 0; j < K; j++)
            if (j == 0 || candy[i][j] != candy[i][j-1])
                pom.push_back(candy[i][j]);
        candy[i].clear();
        while (!pom.empty())
            candy[i].push_back(pom.back()), pom.pop_back();
        qiqi[i] = {l-1,0,i}, qiqi[i+q] = {r,1,i};
    }
    sort(qiqi,qiqi+2*q), sort(ile,ile+n); int j = 0;
    for (int i = 1; i < n; i++)
        if (ile[i].first == ile[i-1].first)
            ile[i].second = (1<<30);
    while (get<0>(qiqi[j]) == 0)
            j++;
    for (int i = 1; i <= n; i++) {
        dodaj(a[i]);
        while (j < 2*q && get<0>(qiqi[j]) == i) {
            for (int k = 0; k < candy[get<2>(qiqi[j])].size(); k++)
                candy[get<2>(qiqi[j])][k].second += ((get<1>(qiqi[j])) ? 1 : -1) * policz(candy[get<2>(qiqi[j])][k].first);
            j++;
        }
    }
    for (int i = 0; i < q; i++) {
        for (auto para : candy[i])
            if (para.second > dl[i]/3 && (odp[i].empty() || (odp[i].size() == 1 && para.first != odp[i][0])))
                odp[i].push_back(para.first);
        if (odp[i].empty())
            cout << -1 << "\n";
        else if (odp[i].size() == 1)
            cout << odp[i][0] << "\n";
        else
            cout << min(odp[i][0],odp[i][1]) << " " << max(odp[i][0],odp[i][1]) << "\n";
        odp[i].clear(), candy[i].clear();
    }
}
int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    int t; cin >> t;
    for (int i = 0; i < t; i++)
        solve();
    return 0;
}
