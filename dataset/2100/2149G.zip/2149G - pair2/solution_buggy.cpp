#include<bits/stdc++.h>
using namespace std;
#define ll long long
const ll N = 200010;
ll block,block2,num_block;
vector <ll> a,b,id,cnt;
vector <ll> head_ti,pre_ti,nxt_ti;
vector <ll> head_bk,pre_bk,nxt_bk;
struct Query{
    ll l,r,id;
};
bool cmp(Query x,Query y){
    ll la = x.l / block;
    ll lb = y.l / block;
    if(la != lb){
        return la < lb;
    }
    if(la & 1){
        return x.r > y.r;
    }
    else{
        return x.r < y.r;
    }
}
void insert_node(vector<ll>&head,vector<ll>&pre,vector<ll>&nxt,ll h,ll x){
    pre[x] = -1;
    nxt[x] = head[h];
    if(head[h] != -1){
        pre[head[h]] = x;
    }
    head[h] = x;
}
void erase_node(vector<ll>&head,vector<ll>&pre,vector<ll>&nxt,ll h,ll x){
    if(pre[x] != -1){
        nxt[pre[x]] = nxt[x];
    }
    else{
        head[h] = nxt[x];
    }
    if(nxt[x] != -1){
        pre[nxt[x]] = pre[x];
    }
    pre[x] = nxt[x] = -1;
}
void change(ll x,ll v){
    ll old = cnt[x];
    ll now = old + v;
    if(old > 0){
        erase_node(head_ti,pre_ti,nxt_ti,old,x);
        if(now == 0 || old / block2 != now / block2){
            erase_node(head_bk,pre_bk,nxt_bk,old / block2,x);
        }
    }
    cnt[x] = now;
    if(now > 0){
        insert_node(head_ti,pre_ti,nxt_ti,now,x);
        if(old == 0 || old / block2 != now / block2){
            insert_node(head_bk,pre_bk,nxt_bk,now / block2,x);
        }
    }
}
void add(ll pos){
    ll x = id[pos];
    change(x,1);
}
void del(ll pos){
    ll x = id[pos];
    change(x,-1);
}
void solve(){
    ll n,q;
    cin >> n >> q;
    a.assign(n,0);
    b.clear();
    for(ll i = 0;i < n;i++){
        cin >> a[i];
        b.push_back(a[i]);
    }
    sort(b.begin(),b.end());
    b.erase(unique(b.begin(),b.end()),b.end());
    id.assign(n,0);
    for(ll i = 0;i < n;i++){
        id[i] = lower_bound(b.begin(),b.end(),a[i]) - b.begin();
    }
    cnt.assign(b.size(),0);
    block2 = max((ll)1,(ll)sqrt(n) + 1);
    num_block = n / block2 + 5;
    head_ti.assign(n + 2,-1);
    head_bk.assign(num_block,-1);
    pre_ti.assign(b.size(),-1);
    nxt_ti.assign(b.size(),-1);
    pre_bk.assign(b.size(),-1);
    nxt_bk.assign(b.size(),-1);
    block = max((ll)1,(ll)(n / sqrt(q)));
    vector<Query>qs(q);
    for(ll i = 0;i < q;i++){
        cin >> qs[i].l >> qs[i].r;
        qs[i].l--;
        qs[i].r--;
        qs[i].id = i;
    }
    sort(qs.begin(),qs.end(),cmp);
    ll L = 0,R = -1;
    vector< vector<ll> > ans(q);
    for(ll i = 0;i < q;i++){
        while(L > qs[i].l) add(--L);
        while(R < qs[i].r) add(++R);
        while(L < qs[i].l) del(L++);
        while(R > qs[i].r) del(R--);
        vector <ll> cur;
        ll len = qs[i].r - qs[i].l + 1;
        ll need = len / 3 + 1;
        ll bel = need / block2;
        ll ed = min(n,(bel + 1) * block2 - 1);
        for(ll j = need;j <= ed;j++){
            for(ll x = head_ti[j];x != -1;x = nxt_ti[x]){
                cur.push_back(b[x]);
                if(cur.size() >= 2) break;
            }
            if(cur.size() >= 2) break;
        }
        for(ll j = bel + 1;j < num_block;j++){
            for(ll x = head_bk[j];x != -1;x = nxt_bk[x]){
                cur.push_back(b[x]);
                if(cur.size() >= 2) break;
            }
            if(cur.size() >= 2) break;
        }
        if(cur.size() > 0){
            sort(cur.begin(),cur.end());
            ans[qs[i].id] = cur;
        }
        else{
            cur.push_back(-1);
            ans[qs[i].id] = cur;
        }
    }
    for(ll i = 0;i < q;i++){
        for(auto x:ans[i]){
            cout << x << " ";
        }
        cout << "\n";
    }
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ll t; 
    cin >> t;
    while(t--){ 
        solve();
    }
    return 0;
}