#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N = 200010;
int block,block2,num_block,max_bk;
vector<int> a,b,id,cnt;
vector<int> head_ti,pre_ti,nxt_ti;
vector<int> head_bk,pre_bk,nxt_bk,sum_bk;
struct Query{
    int l,r,id;
};
bool cmp(const Query& x,const Query& y){
    int la = x.l / block;
    int lb = y.l / block;
    if(la != lb){
        return la < lb;
    }
    if(la & 1){
        return x.r > y.r;
    }
    else{
        return x.r < y.r;
    }
}
void insert_node(vector<int>& head,vector<int>& pre,vector<int>& nxt,int h,int x){
    pre[x] = -1;
    nxt[x] = head[h];
    if(head[h] != -1){
        pre[head[h]] = x;
    }
    head[h] = x;
}
void erase_node(vector<int>& head,vector<int>& pre,vector<int>& nxt,int h,int x){
    if(pre[x] != -1){
        nxt[pre[x]] = nxt[x];
    }
    else{
        head[h] = nxt[x];
    }
    if(nxt[x] != -1){
        pre[nxt[x]] = pre[x];
    }
    pre[x] = -1;
    nxt[x] = -1;
}
void change(int x,int v){
    int old = cnt[x];
    int now = old + v;
    if(old > 0){
        erase_node(head_ti,pre_ti,nxt_ti,old,x);
        int old_bk = old / block2;
        int now_bk = now / block2;
        if(now == 0 || old_bk != now_bk){
            erase_node(head_bk,pre_bk,nxt_bk,old_bk,x);
            sum_bk[old_bk]--;
            if(old_bk == max_bk && sum_bk[old_bk] == 0){
                while(max_bk > 0 && sum_bk[max_bk] == 0){
                    max_bk--;
                }
            }
        }
    }
    cnt[x] = now;
    if(now > 0){
        insert_node(head_ti,pre_ti,nxt_ti,now,x);
        int old_bk = old / block2;
        int now_bk = now / block2;
        if(old == 0 || old_bk != now_bk){
            insert_node(head_bk,pre_bk,nxt_bk,now_bk,x);
            sum_bk[now_bk]++;
            if(now_bk > max_bk){
                max_bk = now_bk;
            }
        }
    }
}
void add(int pos){
    int x = id[pos];
    change(x,1);
}
void del(int pos){
    int x = id[pos];
    change(x,-1);
}
void solve(){
    int n,q;
    cin >> n >> q;
    a.assign(n,0);
    b.clear();
    for(int i = 0;i < n;i++){
        cin >> a[i];
        b.push_back(a[i]);
    }
    sort(b.begin(),b.end());
    b.erase(unique(b.begin(),b.end()),b.end());
    id.assign(n,0);
    for(int i = 0;i < n;i++){
        id[i] = lower_bound(b.begin(),b.end(),a[i]) - b.begin();
    }
    int m = b.size();
    cnt.assign(m,0);
    block2 = max(1,(int)sqrt(n));
    num_block = n / block2 + 5;
    max_bk = 0;
    head_ti.assign(n + 2,-1);
    pre_ti.assign(m,-1);
    nxt_ti.assign(m,-1);
    head_bk.assign(num_block,-1);
    pre_bk.assign(m,-1);
    nxt_bk.assign(m,-1);
    sum_bk.assign(num_block,0);
    block = max(1,(int)(n / sqrt((double)q)));
    vector<Query> qs(q);
    for(int i = 0;i < q;i++){
        cin >> qs[i].l >> qs[i].r;
        qs[i].l--;
        qs[i].r--;
        qs[i].id = i;
    }
    sort(qs.begin(),qs.end(),cmp);
    vector<int> ans1(q,-1),ans2(q,-1),ans_cnt(q,0);
    int L = 0,R = -1;
    for(int i = 0;i < q;i++){
        while(L > qs[i].l) add(--L);
        while(R < qs[i].r) add(++R);
        while(L < qs[i].l) del(L++);
        while(R > qs[i].r) del(R--);
        int len = qs[i].r - qs[i].l + 1;
        int need = len / 3 + 1;
        int bel = need / block2;
        int ed = min(n,(bel + 1) * block2 - 1);
        int c = 0;
        int x1 = -1,x2 = -1;
        for(int j = need;j <= ed && c < 2;j++){
            for(int x = head_ti[j];x != -1 && c < 2;x = nxt_ti[x]){
                if(c == 0){
                    x1 = b[x];
                }
                else{
                    x2 = b[x];
                }
                c++;
            }
        }
        for(int j = bel + 1;j <= max_bk && c < 2;j++){
            if(sum_bk[j] == 0){
                continue;
            }
            for(int x = head_bk[j];x != -1 && c < 2;x = nxt_bk[x]){
                if(c == 0){
                    x1 = b[x];
                }
                else{
                    x2 = b[x];
                }
                c++;
            }
        }
        if(c == 0){
            ans_cnt[qs[i].id] = 0;
        }
        else if(c == 1){
            ans_cnt[qs[i].id] = 1;
            ans1[qs[i].id] = x1;
        }
        else{
            if(x1 > x2){
                swap(x1,x2);
            }
            ans_cnt[qs[i].id] = 2;
            ans1[qs[i].id] = x1;
            ans2[qs[i].id] = x2;
        }
    }
    string out;
    out.reserve(q * 20);
    for(int i = 0;i < q;i++){
        if(ans_cnt[i] == 0){
            out += "-1\n";
        }
        else if(ans_cnt[i] == 1){
            out += to_string(ans1[i]);
            out += " \n";
        }
        else{
            out += to_string(ans1[i]);
            out += " ";
            out += to_string(ans2[i]);
            out += " \n";
        }
    }
    cout << out;
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t; 
    cin >> t;
    while(t--){ 
        solve();
    }
    return 0;
}