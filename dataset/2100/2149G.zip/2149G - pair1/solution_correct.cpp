#include<bits/stdc++.h>
#include <algorithm>
typedef long long ll;
#define sor(v) sort(v.begin() , v.end());
#define el '\n'
#define pb push_back
#define all(v) v.begin(),v.end()
#define count_bits(n) __builtin_popcountll(n)
#define int long long
#define double long double
#define mm(arr) memset(arr, -1, sizeof(arr))
#define CEIL(a, b) (((a) + (b) - 1) / (b))
#define DEAD ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
// #include <ext/pb_ds/assoc_container.hpp>
// #include <ext/pb_ds/tree_policy.hpp>
// using namespace __gnu_pbds;
//
// template<class T> using ordered_multiset = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>;
// template<class T> using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
using namespace std;
const int MOD = 1e9 + 7;
const int C =   1 ;
const int MOD2 = 998244353 ;
const double phi = (1 + sqrt(5)) / 2 ;
const int INF = 1e18;
const int N = 110  , LOG = 20 ; 
const double PI = acos(-1L);
mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count()); 
struct CoordinateCompression {
    vector<int> vals;
 
    CoordinateCompression() {}
 
    void add(int x) {
        vals.push_back(x);
    }
 
    void add(const vector<int> &v) {
        for (auto x : v) vals.push_back(x);
    }
 
    void build() {
        sor(vals);
        vals.erase(unique(all(vals)), vals.end());
    }
 
    int get(int x) {
        return lower_bound(all(vals), x) - vals.begin() + 1;
    }
 
    int rev(int id) {
        return vals[id - 1];
    }
 
    int size() {
        return vals.size();
    }
};
void solve(){
  int n ; cin >> n ; 
  int q ; cin >> q ;
 
  vector<int>v(n) ;  
  for(int i = 0 ; i < n ; i++){
    cin >> v[i]  ;
  }

  CoordinateCompression cp ; 
  cp.add(v) ; 
  cp.build() ; 

  vector<vector<int>>idx(n + 1); 
  for(int i = 0 ; i < n ; i++){
    idx[cp.get(v[i])].push_back(i);  
  }
 
  // (2/3)^26
  while(q--){
    int l ; cin >> l ;
    int r ; cin >> r ; 
    l -= 1 , r -= 1 ; 
    set<int>st ; 
    for(int j = 0 ; j < 40 ; j++){
        int index = cp.get(v[(rng()%(r - l + 1)) + l]) ;
        int up = upper_bound(all(idx[index]) , r) - idx[index].begin() ;
        int down = lower_bound(all(idx[index]) , l) - idx[index].begin() ; 
        if(up - down > (r - l + 1) / 3){
          st.insert(cp.rev(index)) ;
        }
    }
    if(st.empty())cout << -1 << el ; 
    else {
      for(int i : st)cout << i << ' ' ;
      cout << el ; 
    }
  }
} 
int32_t main(){
  DEAD
  int t = 1 ; 
      //   cout << fixed << setprecision(8) ; 
      cin >> t ; 
      while(t--)
      solve();
      return 0;
}
