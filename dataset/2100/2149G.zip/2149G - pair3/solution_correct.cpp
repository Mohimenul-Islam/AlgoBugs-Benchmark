#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define rep(i,a,n) for(int i=a;i<n;++i)
#define per(i,n,a) for(int i=n;i>=a;--i)
#define pb push_back
#define mp make_pair
#define all(v) v.begin(),v.end()
#define sz(a) ((int)a.size())
#define umap unordered_map
#define uset unordered_set
#define fi first
#define se second 
#ifdef i_am_noob
#define bug(...) cerr << "#" << __LINE__ << ' ' << #__VA_ARGS__ << ": ", _do(__VA_ARGS__)
template<typename T> void _do(vector<T> x){for(auto i: x) cerr << i << ' ';cerr << "\n";}
template<typename T> void _do(set<T> x){for(auto i: x) cerr << i << ' ';cerr << "\n";}
template<typename T> void _do(multiset<T> x){for(auto i: x) cerr << i << ' ';cerr << "\n";}
template<typename K, typename V> void _do(map<K,V> x){for(auto &[k,v] : x) {cerr << "(" << k << ":" << v << ") ";}cerr << "\n";}
template<typename T> void _do(unordered_set<T> x){for(auto i: x) cerr << i << ' ';cerr << "\n";}
template<typename T> void _do(T && x) {cerr << x << endl;}
template<typename T, typename ...S> void _do(T && x, S&&...y) {cerr << x << ", "; _do(y...);}
#else
#define bug(...) 824
#endif
typedef long long ll;typedef long double ld;typedef pair<int, int> pii; typedef pair<ll, ll> pll; typedef vector<int> vi; typedef vector<vi> vvi; typedef vector<ll> vl; typedef vector<vl> vvl;
using i64 = long long; using i128 = __int128_t;
template<class T, class U> bool chmin(T &a,U b){if(b<a){a=b;return 1;}else return 0;}
template<class T, class U> bool chmax(T &a,U b){if(a<b){a=b;return 1;}else return 0;}
__int128 gcd128(__int128 a, __int128 b) { while (b) { a %= b; std::swap(a, b); } return a; }
__int128 lcm128(__int128 a, __int128 b) {return a / gcd128(a, b) * b;}
const double eps=1e-8, PI=3.14159265; const int inf = 2143483508; const long long llinf=9223372036854775807;

template<class T> void print(T c) { for(auto v:c) {cout << v << " "; } cout << endl; }
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
void solve(int TEST) {
    int n,q; cin >> n >> q;
    vi A(n); rep(i,0,n) cin >> A[i];
    map<int,int> MP; 
    vi inv(n+1);
    int c = 0;
    rep(i,0,n) {
        inv[c]=A[i];
        MP[A[i]]=c++;
    }
    rep(i,0,n) {A[i]=MP[A[i]];}
    vector<vector<int>> inds(n);
    rep(i,0,n) { inds[A[i]].pb(i); }
    auto doit=[&](int l, int r) {
        vi good;
        rep(i,0,50) {   
            int x = uniform_int_distribution<int>(l,r)(rng);
            x--;
            int hi = upper_bound(all(inds[A[x]]),r-1)-inds[A[x]].begin()-1;
            int lo = lower_bound(all(inds[A[x]]),l-1)-inds[A[x]].begin();
            if(inds[A[x]][hi]<=r-1 && inds[A[x]][lo]>=l-1) {
                if(hi-lo+1 > (r-l+1)/3) {
                    good.pb(inv[A[x]]);
                }
            }
        }
        return good;
    };
    rep(j,0,q) {
        int l,r; cin >> l >> r;
        vi res = doit(l,r);
        sort(all(res));
        res.erase(unique(all(res)),res.end());
        if(res.empty()) { cout << "-1\n";}
        else { 
            for(int v:res) { cout << v << " "; } cout << "\n";
        }
    }
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    //for interactive mode, comment ONLINE_JUDGE block
    #ifndef ONLINE_JUDGE
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
    #endif
    int Test=1; 
    cin >> Test;
    int T = Test;
    while(Test--){
        solve(T-Test);
    }
}