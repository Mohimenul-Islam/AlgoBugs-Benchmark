#include <bits/stdc++.h>
using namespace std;

struct FastScanner {
    static const int S = 1 << 20;
    int idx = 0, size = 0;
    char buf[S];

    inline char getChar() {
        if (idx >= size) {
            size = fread(buf, 1, S, stdin);
            idx = 0;
            if (size == 0) return 0;
        }
        return buf[idx++];
    }

    template<class T>
    bool read(T &x) {
        char c;
        T sign = 1;
        x = 0;

        c = getChar();
        if (!c) return false;

        while (c != '-' && (c < '0' || c > '9')) {
            c = getChar();
            if (!c) return false;
        }

        if (c == '-') {
            sign = -1;
            c = getChar();
        }

        while (c >= '0' && c <= '9') {
            x = x * 10 + (c - '0');
            c = getChar();
        }

        x *= sign;
        return true;
    }
};

static uint64_t seed_rng = chrono::steady_clock::now().time_since_epoch().count();

inline uint64_t splitmix64() {
    uint64_t z = (seed_rng += 0x9e3779b97f4a7c15ULL);
    z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
    z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
    return z ^ (z >> 31);
}

inline int count_pos(const vector<int> &v, int l, int r) {
    return upper_bound(v.begin(), v.end(), r) - lower_bound(v.begin(), v.end(), l);
}

inline void add_unique(int cand[], int &cnt, int x) {
    for (int i = 0; i < cnt; i++) {
        if (cand[i] == x) return;
    }
    cand[cnt++] = x;
}

void solve(FastScanner &fs, string &out) {
    int n, q;
    fs.read(n);
    fs.read(q);

    vector<long long> raw(n), vals;
    vals.reserve(n);

    for (int i = 0; i < n; i++) {
        fs.read(raw[i]);
        vals.push_back(raw[i]);
    }

    sort(vals.begin(), vals.end());
    vals.erase(unique(vals.begin(), vals.end()), vals.end());

    int m = vals.size();
    vector<int> a(n);
    vector<vector<int>> pos(m);

    for (int i = 0; i < n; i++) {
        int id = lower_bound(vals.begin(), vals.end(), raw[i]) - vals.begin();
        a[i] = id;
        pos[id].push_back(i);
    }

    const int SAMPLE = 45;

    while (q--) {
        int l, r;
        fs.read(l);
        fs.read(r);
        --l, --r;

        int len = r - l + 1;
        int threshold = len / 3;

        int cand[128];
        int ccnt = 0;

        if (len <= 120) {
            for (int i = l; i <= r; i++) {
                add_unique(cand, ccnt, a[i]);
            }
        } else {
            for (int i = 0; i < SAMPLE; i++) {
                int idx = l + (splitmix64() % len);
                add_unique(cand, ccnt, a[idx]);
            }
        }

        int ans[3];
        int acnt = 0;

        for (int i = 0; i < ccnt; i++) {
            int id = cand[i];
            int cnt = count_pos(pos[id], l, r);
            if (cnt > threshold) {
                ans[acnt++] = id;
            }
        }

        if (acnt == 0) {
            out += "-1\n";
        } else {
            sort(ans, ans + acnt);

            for (int i = 0; i < acnt; i++) {
                if (i) out += ' ';
                out += to_string(vals[ans[i]]);
            }
            out += '\n';
        }
    }
}

int main() {
    FastScanner fs;
    string out;
    out.reserve(1 << 22);

    int T;
    fs.read(T);

    while (T--) {
        solve(fs, out);
    }

    fwrite(out.c_str(), 1, out.size(), stdout);
    return 0;
}