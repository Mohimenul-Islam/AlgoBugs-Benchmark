#include "bits/stdc++.h"
using namespace std;
#define int long long
using PII = pair<int, int>;
#define fi first
#define se second
#define endl '\n'
template<class t1, class t2>
istream& operator>>(istream& is, pair<t1, t2>& p) {
    is >> p.fi >> p.se;
    return is;
}
template<class t1, class t2>
ostream& operator<<(ostream& os, const pair<t1, t2>& p) {
    os << p.fi << ' ' << p.se << endl;
    return os;
}
#define V vector
#define Framework(e) do{e}while(0)
const int INF = 1e18;
#define all(x) (x).begin(), (x).end()
#define debug(x) Framework(cout<<#x<<"="<<x<<'\n';)
#define vdebug(a) Framework(cout<<#a<<"=";for(auto it:a)cout<<it<<" ";cout<<'\n';)
#define MAX(a) *max_element(all(a))
#define MIN(a) *min_element(all(a))
#define SUM(a) accumulate(a.begin(), a.end(), 0LL)
#define End Framework(cout<<"NO"<<endl;return;)
#define say(e) Framework(cout<<(e?"YES":"NO")<<endl;)
const int N = 2e5 + 10;
inline int R() {
    int res = 0; char c; int flag = 1;
    while (!isdigit(c = getchar())) {
        if (c == '-') { flag = -1; }
    }
    while (isdigit(c)) {
        res = res * 10 + c - '0'; c = getchar();
    }
    return res * flag;
}
int a[N];
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
void solve() {
    int n = R(), q = R(); int result[3] = { 0 }, tot = 0;
    unordered_map<int, vector<int>> pos;
    for (int i = 0; i < n; i++) {
        a[i] = R();
        pos[a[i]].push_back(i);
    }
    while (q--) {
        int l = R(), r = R();
        tot = 0;
        l--; r--;
        int len = r - l + 1;
        int threshold = len / 3;
        V<int> candidates;
        if (len < 100) {
            for (int i = l; i <= r; ++i)candidates.push_back(a[i]);
        }
        else {
            uniform_int_distribution<int> dis(l, r);
            for (int i = 0; i < 40; i++)
            {
                int idx = dis(rng);
                candidates.push_back(a[idx]);
            }
        }
        sort(all(candidates));
        candidates.erase(unique(all(candidates)), candidates.end());
        for (int cand : candidates) {
            auto& v = pos[cand];
            int cnt = upper_bound(v.begin(), v.end(), r) -
                lower_bound(v.begin(), v.end(), l);
            if (cnt > threshold) {
                result[tot++] = cand;
            }
        }
        if (tot) {
            sort(result, result + tot);
            for (int i = 0; i < tot; ++i)printf("%lld ", result[i]);
            puts("");
        }
        else puts("-1");
    }
}
signed main() {
    int t = R();
    while (t--)solve();
    return 0;
}