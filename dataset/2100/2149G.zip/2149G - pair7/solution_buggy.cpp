#include <bits/stdc++.h>
// leneza_41
using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef unsigned int ui;
typedef long double ld;
typedef pair<int, int> ii;
typedef pair<ll, ll> pll;
typedef tuple<int, int, int> iii;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef vector<ii> vii;
typedef vector<pll> vpl;
#define fi first
#define se second
#define lsb(S) ((S) & -(S))
#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define pb push_back
#define eb emplace_back
#define ppb pop_back
#define ppf pop_front
#define mn_e min_element
#define mx_e max_element
#define acc accumulate
#define lw lower_bound
#define upp upper_bound

const int INF = 1e9;
const ll LINF = 1e18;
const ll MOD = 1e9 + 7;
// const ll MOD = 998244353;
const double EPS = 1e-9;
const int N = 50;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int getRand(int l, int r) {
    uniform_int_distribution<int> dist(l, r);
    return dist(rng);
}

void solve() {
    int n, q;
    cin >> n >> q;
    vi a(n);
    unordered_map<int, vi> mp;
    for(int i = 0; i < n; i++) {
        cin >> a[i];
        mp[a[i]].pb(i);
    }
    while(q--) {
        int l, r;
        cin >> l >> r; l--; r--;
        vi ans;
        for(int i = 0; i < N && ans.size() < 2; i++) {
            int rnd = getRand(l, r);
            vi &pos = mp[a[rnd]];
            int left = lw(all(pos), l) - pos.begin();
            int right = upp(all(pos), r) - pos.begin();
            if(right - left > (r - l + 1) / 3 && (ans.empty() || ans.back() != a[rnd])) {
                ans.pb(a[rnd]);
            }
        }
        if(ans.size() == 2 && ans[0] > ans[1]) {
            swap(ans[0], ans[1]);
        }
        if(ans.empty()) {
            cout << "-1\n";
        } else {
            for(int i : ans) cout << i << " ";
            cout << "\n";
        }
    }
}

int main() {
    ios::sync_with_stdio(0); cin.tie(0);
    int T = 1;

    cin >> T;
    while(T--) {
        solve();
    }
    return 0;
}