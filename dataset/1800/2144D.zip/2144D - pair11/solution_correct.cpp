#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define maxn 110
#define MOD 998244353//二分？
ll dnup(ll x,ll y){
	if((double)(x/y)-(ll)x/y>=0.5) return x/y+1;
	else return x/y;
} 
void solve() {
	ll n,y;
	ll maxx=0;
	cin>>n>>y;
	vector<ll> c(n+10);
	for(int i=1;i<=n;i++){
		cin>>c[i];
	}
	sort(c.begin()+1,c.begin()+n+1);
	maxx=c[n];
	vector<ll> cnt(maxx+50),f(maxx+50),sum(maxx+50);
	for(int i=1;i<=n;i++){
		cnt[c[i]]++;
	}
	for(int i=1;i<=maxx;i++){
		f[i]=f[i-1]+cnt[i];
		sum[i]=sum[i-1]+cnt[i]*i;
	}
	ll ans=-1e18;
	vector<ll> cntb(maxx+10),sumb(maxx+10);
	//cout<<f[51]-f[49];
	for(ll base=2;base<=maxx+2;base++){//every c[i]/base,同余系？|||| 1/1+1/2+1/3+...+1/n调和级数收敛 
		ll kmax=0,ta=0;
		for(ll k=0;(k-1)*base+1<=maxx;k++){
			kmax=max(kmax,k);
			//ll l=max(1ll,k*base-base/2+(base%2==0?1:0)),r=min(maxx,k*base+base/2);
			ll l=max(1ll,(k-1)*base+1),r=min(maxx,k*base); 
			cntb[k]=f[r]-f[l-1];
			//printf("%lld*%lld [%lld=>%lld] : %lld\n",base,k,l,r,cntb[k]); 
		}
		for(ll i=0;i<=kmax;i++){
			ta+=cntb[i]*i-max(0ll,cntb[i]-cnt[i])*y;
		}
		ans=max(ans,ta);
		//cout<<ta;
		//printf("-------------\n");
	}
	cout<<ans<<endl;
}
signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	ll t;
	cin>>t;
	while(t--) {
		solve();
	}
	return 0;
}
/*

1
5 51
50 150 50 148 150


4
5 51
50 150 50 148 150
3 1000000000
42 42 42
10 54321
1 8088 45 1 73 1 9198 4991 1 83
3 100
1 1 1

*/