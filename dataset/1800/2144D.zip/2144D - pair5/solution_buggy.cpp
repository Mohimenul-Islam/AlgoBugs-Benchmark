#include<bits/stdc++.h>
using namespace std;
using ll = long long int;
using ii = pair<int,int>;

const int mxn = 2e5 + 3;
void solve(){
    int n, y;
    cin >> n >> y;
    vector<int> cnt(mxn);
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        cnt[x]++;
    }    
    vector<int> pre(mxn+1);
    for (int i = 0; i < mxn; i++) {
        pre[i+1] = cnt[i] + pre[i];
    }
    auto sum = [&](int l, int r) {
        if (l > mxn)
            return 0;
        return pre[min(r+1,mxn-1)] - pre[l];
    };
    vector<ll> res(mxn, 0);
    for (int i = 1; i < mxn; i++) {
        for (int x = 2; x < mxn && x * i < 2 * mxn; x++) {
            int newtags = sum(x* (i-1) + 1, x * i);
            res[x] += newtags * (ll)i - max(0, (newtags - cnt[i])) * (ll)y;
        }
    }
    ll ans = -1e18;
    for (int i = 2; i < mxn; i++) {
        if (res[i] == 0)
            cout << i <<" ";
        ans = max(ans, res[i]);
    }
    cout << ans << '\n';
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while(t--)
        solve();
}