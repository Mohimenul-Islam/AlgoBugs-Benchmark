#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const int buf=200001;

int main(){
    
    int t;
    cin>>t;
    while(t--){
        int len,weight;
        cin>>len>>weight;
        vector<int> arr(buf);
        
        for (int i=0;i<len;i++){
            int item;
            cin>>item;
            arr[item]++;
        }
        vector<int> psum(buf);
        for (int i=1;i<buf;i++) psum[i]=psum[i-1]+arr[i];
        
        
        long long maxCost=0;
        for (int i=2;i<buf;i++){
            long long divided=1;
            long long cost=0;
            for (int j=0;j<buf;j+=i){
                int start=j;
                int end=min(buf-1,j+i);
                int segment=psum[end]-psum[start];
                cost += divided* (long long)segment-((long long)max(0,segment-arr[divided]))*(long long)weight;
                divided++;
            }
            if (i==2 || cost>maxCost){
                maxCost=cost;
            }
        }
        cout<<maxCost<<endl;
    }
    
}