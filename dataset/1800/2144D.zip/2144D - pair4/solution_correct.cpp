#include <bits/stdc++.h>
using namespace std;
#define ll long long
ll M=9e18;
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    ll t;
    cin>>t;
    while(t--)
    {
        ll n,y,m=0;
        cin>>n>>y;
        vector<ll>v(n);
        for(int i=0;i<n;i++)
        {
            cin>>v[i];
            m=max(m,v[i]);
        }
        vector<ll>s(m+5),p(m+5);
        for(int i=0;i<n;i++)
        {
            s[v[i]]++;
        }
        for(int i=1;i<=m;i++)
        {
            p[i]=p[i-1]+s[i];
        }
        ll d=-M;
        for(ll i=2;i<=m+1;i++)
        {
            ll z=(m+i-1)/i;
            ll c=0;
            for(ll j=1;j<=z;j++)
            {
                ll a=i*(j-1)+1,b=min(j*i,m);
                c+=j*(p[b]-p[a-1]);
                c-=max(0LL,y*(p[b]-p[a-1]-s[j]));
            }
            d=max(d,c);
            //cout<<c<<endl;
        }
        cout<<d<<endl;
    }
}