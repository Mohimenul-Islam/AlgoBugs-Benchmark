#include <bits/stdc++.h>
using namespace std;
#define int long long

void solve() {
    int n, y; cin >> n >> y;
    vector<int> a(n);
    vector<int> cnt((int)2e5 + 10, 0);
    int mx = -1e9;
    for (auto & el : a) {
        cin >> el; cnt[el]++;
        mx = max(mx, el);
    }
    
    vector<int> pcnt(cnt.size()+1, 0);
    for (int i = 0; i < cnt.size(); i++) {
        pcnt[i + 1] = pcnt[i] + cnt[i];
    }
    
    int best = -1e18;
    for (int x = 2; x <= max(2ll, mx); x++) {
        int cntnew = 0;
        int suma = 0;
        for (int u = 1; u <= (mx+x-1) / x; u++) {
            // u <- [(u-1)*x+1, u*x]
            // cnt[u]
            cntnew += max(0ll, pcnt[min((int)cnt.size(), u * x + 1)] - pcnt[min((int)cnt.size(), (u - 1) * x)] - cnt[u]);
            suma += (pcnt[min((int)cnt.size(), u * x + 1)] - pcnt[min((int)cnt.size(), (u - 1) * x)]) * u;
        }
        // cout << x << " " << suma - y * cntnew << " " << cntnew << endl;
        best = max(best, suma - y * cntnew);
    }
    cout << best << "\n";
}

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
	int t; cin >> t;
	for (int i = 0; i < t; i++) {
	    solve();
	}
}
