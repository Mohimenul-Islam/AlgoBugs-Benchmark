#include<bits/stdc++.h>
#define ll long long
#define yes cout <<"YES"<< endl
#define no cout << "NO" << endl
#define forn for(int i=0;i<n;i++)
#define form for(int j=0;j<m;j++)
#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define int long long
#define endl "\n"
#define test cout<<"TEST"<<endl;
#define IO_FAST  ios_base::sync_with_stdio(false); cin.tie(NULL);
using namespace std;
using namespace __gnu_pbds;
template <typename T>using order_set=tree<T,null_type,less<T>,rb_tree_tag,
tree_order_statistics_node_update>;
/////////////////////
template <typename T>using order_multiset=tree<T,null_type,less_equal<T>,rb_tree_tag,
tree_order_statistics_node_update>;
const int  N=2e5,M=1024+5;
///////////////////
const int mod=998244353;
//////////////////////////

void sol()
{
int n,y;
cin>>n>>y;
vector<int>pr(N+1),fr(N+1),a(n);
forn
{
    cin>>a[i];
    fr[a[i]]++;
}
for(int i=1;i<=N;i++)
{
    pr[i]=pr[i-1]+fr[i];
}
int ans=-1e18;
for(int x=2;x<=N;x++)
{
    int mxp=N/x+((N%x)>0);
    int res=0;
    for(int p=1;p<=mxp;p++)
    {
        int mn=(p-1)*x+1;
        int mx=min(N,p*x);
        res+=(pr[mx]-pr[mn-1])*p;
        res-=max(0LL,(pr[mx]-pr[mn-1])-fr[p])*y;

    }
    ans=max(ans,res);
}
cout<<ans<<endl;
}

signed main()
{
    IO_FAST
    int ttt=1;
   cin>>ttt;
    while(ttt--){
        sol();
    }
    return 0;
}
