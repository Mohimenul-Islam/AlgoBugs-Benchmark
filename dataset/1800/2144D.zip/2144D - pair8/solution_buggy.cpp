#pragma GCC optimize("O3")
#include <bits/stdc++.h>

using namespace std;
#define int long long

const int maxN = 3e5+1;
const int mod = 998244353;

vector<int> pref(2e5 + 1);
vector<int> c(2e5+1);
void solve() {
    int n, y;
    cin >> n >> y;
    vector<int> a(n);

    for (int i = 0; i <= 2e5; i++) {
        pref[i] = c[i] = 0;
    }
    for (int i = 0; i < n; i++) {
        cin >> a[i];
        c[a[i]]++;
        pref[a[i]]++;
    }
    for (int i = 1; i <= 2e5; i++) {
        pref[i] += pref[i - 1];
    }
    int ans = -1e18;
    for (int x = 2; x <= 2e5;x ++) {
        int m = 1;
        int sum = 0;
        int cnt = 0;
        while (m * x <= 2e5) {//m - цена
            int l = (m - 1) * x;
            int r = m * x;
            int cs = pref[r] - pref[l];
            if (cs > c[m]) cnt += cs - c[m];
            sum += m * cs;
            m++;
        }
        ans = max(ans, sum - cnt * y);
    }
    cout << ans << "\n";
}

signed main() {
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif

    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int t = 1;
    cin >> t;
    while(t--){
        solve();
    }
}