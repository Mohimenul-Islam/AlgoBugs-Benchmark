#include <bits/stdc++.h>
using namespace std;
#define int long long

const int maxn = 2e6+8, inf = 1e18+9, mod = 1e9+7;

int cnt[maxn];

void solve() {
    int n, y, ans = -inf, mx = 0; cin >> n >> y;
    vector<int> c(n + 1);
    for (int i = 1; i <= n; i++) cin >> c[i], cnt[c[i]]++, mx = max(mx, c[i]);
    for (int i = 1; i < maxn; i++) cnt[i] += cnt[i - 1];
    for (int x = 2ll; x <= mx + 1; x++) {
        int now = 0;
        for (int p = 1; p <= (mx + x - 1) / x; p++) {
            int pc = cnt[p * x] - cnt[(p - 1) * x];
            now += p * pc - max(0ll, pc - (cnt[p] - cnt[p - 1])) * y;
        }
        ans = max(ans, now);
    }
    for (int i = 1; i < maxn; i++) cnt[i] = 0;
    cout << ans << endl;
}

signed main() {
    cin.tie(0)->sync_with_stdio(false), cout << fixed << setprecision(15);
    int t = 1; cin >> t;
    while (t--) solve();
    return 0;
}

