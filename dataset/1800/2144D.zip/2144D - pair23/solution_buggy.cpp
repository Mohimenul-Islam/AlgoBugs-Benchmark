#include <bits/stdc++.h>
#define pb push_back
#define se second
#define fi first
#define all(x) (x).begin(), (x).end()
#define el "\n"
#define bit(mask,i) ((mask>>i)&1)
#define vll vector <long long>
#define FOR(i, a, b) for (int i = a; i <= b; i ++)
#define REP(i, a, b) for (int i = a; i >= b; i --)
#define taskname "test"
#define int long long
using namespace std;

typedef long long ll;
typedef pair<ll,ll> pi;

const int MAXN = 1e6+5;
const ll MOD = 1e9 + 7;
const ll INF = 1e18;
const double EPSILON = 0.000001;

// Initial function
ll add(ll x, ll y) {
    x += y;
    if (x >= MOD) x -= MOD;
    if (x < 0) x += MOD;
    return x;
}

void maximize (ll &x, ll val) {
    x = max (x, val);
}

void minimize (ll &x, ll val) {
    x = min (x, val);
}

ll Pow (ll x, ll y) {
    int ans = 1;
    while (y > 0) {
        if (y & 1) ans = ans * x % MOD;
        y /= 2;
        x = x * x % MOD;
    }
    return ans;
}

// -----------------------

int n, k, a[MAXN], cnt[MAXN];

void solve () {
    cin >> n >> k;
    FOR (i, 1, 2e5 + 5) cnt[i] = 0; 

    int res = -INF, mx = 0;
    FOR (i ,1, n) {
        int x; cin >> x;
        cnt[x] ++;
        maximize (mx, x);
    }

    FOR (i, 1, 2e5 + 5) cnt[i] += cnt[i - 1];

    if (mx < 2) mx = 2;

    FOR (x, 2, mx) {
        int ans = 0;
        FOR (i, 1, mx) {
            if (i > (mx + x - 1) / x) break;

            int need = cnt[i * x] - cnt[(i - 1) * x];

            int cur = cnt[i] - cnt[i - 1];

            ans += need * i;

            ans -= (need - min (need, cur)) * k;
        }

        maximize (res, ans);
    }

    cout << res;
}


signed main ()
{
    if (fopen (taskname".inp", "r"))
    {
        freopen (taskname".inp", "r", stdin);
        freopen (taskname".out", "w", stdout);
    }

    ios_base :: sync_with_stdio (false);
    cin.tie (NULL);
    cout.tie (NULL);

    clock_t start = clock();

    int t; cin >> t;
    while (t --) {
        solve ();
        cout << el;
    }

    std::cerr << "Time elapsed: " << clock() - start << " ms\n";
    
    return 0;
}