#include<iostream>
#include<algorithm>
using namespace std;
typedef long long LL;
const int N = 200010;
int pre[N];
int st[N];
void solve()
{
    for (int i = 0; i <= N; i++)
    {
        pre[i] = 0;
        st[i] = 0;
    }
    int n;
    LL y;
    scanf("%d %lld", &n, &y);
    int M = 0;
    for (int i = 1; i <= n; i++)
    {
        int a;
        scanf("%d", &a);
        M = max(M, a);
        st[a]++;
    }
    for (int i = 1; i <= N; i++) pre[i] = pre[i - 1] + st[i];
    LL ans = -0x3f3f3f3f3f3f3f3f;
    for (int x = 2; x <= M + 1; x++)
    {
        LL sum = 0;//降价后的总金额
        LL re = 0;//可以重复利用的个数
        for (int k = 1; k * x - x + 1 <= M; k++)
        {
            int l = k * x - x + 1;
            int r = min(k * x, M);
            int cnt = pre[r] - pre[l - 1];
            if (cnt > 0) sum += k * cnt, re += min(st[k], cnt);
        }
        ans = max(ans, sum - (n - re) * y);
    }
    cout << ans << endl;
}
int main()
{
    int t;
    scanf("%d", &t);
    while (t--)
    {
        solve();
    }
}