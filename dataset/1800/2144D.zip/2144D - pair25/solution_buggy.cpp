#include <bits/stdc++.h>
#define int long long 
#define endl " \n"
#define vec vector 
#define all(x) x.begin(),x.end()
#pragma GCC optimize("O2,unroll-loops")
using namespace std;
int32_t main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int tt;
    cin>>tt;
    while(tt--)
    {
        int n,y;
        cin>>n>>y;
        vec<int> c(n);
        vec<int> f(2e5+2,0);
        vec<int> t(2e5+2,0),s(2e5+2,0);
        for (int i = 0; i < n; i++)
        {
            cin>>c[i];
            f[c[i]]++;
        }

        

        t[0]=f[0];
        for (int i = 1; i <= 2e5; i++)
        {
            t[i]+=t[i-1];
            t[i]+=f[i];
        }
        for (int i = 1; i <= 2e5; i++)
        {
            for (int j = 2,lv=0; lv <= 2e5; j++,lv=i*j)
            {
                s[j]+=(t[min(i*(j),(int)2e5)]-t[min(i*(j)-j,(int)2e5)])*i;
            }
        }
        
        int res=-1e18l;
        vec<int> ans(2e5+1,0);
        for (int i = 1; i <= 2e5; i++)
        {
            for (int j = 2,lv=0; lv <= 2e5; j++,lv=i*j)
            {
                ans[j]+=min(f[i],(t[min(i*(j),(int)2e5)]-t[min(i*(j)-j,(int)2e5)]));
                //if(i==50)
                //cout<<"ans on j:"<<j<<" take minimum from:\nfreq of:"<<i<<"="<<f[i]<<"\nor freq of values from:"<<i*(j)-j+1<<" to:"<<i*(j)<<"="<<t[i*(j)]-t[i*(j)-j]<<endl[1];
            }
            //res=max(res,(n-ans)*y+s[i]);
        }
        for (int i = 2; i <= 2e5; i++)
        {
            //cout<<(n-ans[i])*y+s[i]<<" val"<<endl[1];
            //cout<<(n-ans[i])<<" left and sum="<<s[i]<<endl[1];
            res=max(res,-(n-ans[i])*y+s[i]);
        }
        
        cout<<res<<endl[1];
    }
    return 0;
}