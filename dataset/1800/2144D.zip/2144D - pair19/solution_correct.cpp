#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn=2e5;
void solve() {
	int n,y;cin>>n>>y;
	int c[n];
	int ori[maxn+5]={0};
	int cnt[maxn+5]={0};
	for (int i=0;i<n;i++) cin>>c[i],cnt[c[i]]++,ori[c[i]]++;
	for (int i=1;i<=maxn;i++) {
		cnt[i]+=cnt[i-1];
	}
	const long long INF=-1e18;
	long long res=INF;
	
	for (int i=2;i<=maxn;i++) {
		long long t=0;
		int num=0;
		for (int j=1;j<=maxn;j+=i,num++)  {
			int fre=cnt[min(j+i-1,maxn)]-cnt[j-1];
//		if (fre)	cout<<"i="<<i<<",j="<<j<<endl;
//			if (fre)cout<<"fre="<<fre<<",num="<<num<<endl;
			t+=fre*(num+1)-y*(fre-min(fre,ori[num+1]));
//			if (fre) cout<<"t="<<t<<endl;
		}
//		cout<<"i="<<i<<",t="<<t<<endl;
		res=max(res,t);
	}
	
	cout<<res<<endl;
	
}
signed main() {
    ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	int t;cin>>t;
	while(t--) solve();
}