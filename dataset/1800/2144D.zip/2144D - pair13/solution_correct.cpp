#include<bits/stdc++.h>
using namespace std;
const int N=200001,V=400000;
long long T,n,y,c[V],vis[V],sum[V],ans;
void solve()
{
	cin>>n>>y;
	ans=-1e15;
	for(int i=0;i<V;i++)
	{
		sum[i]=vis[i]=0;
	}
	for(int i=1;i<=n;i++)
	{
		cin>>c[i];
		vis[c[i]]++;
	}
	for(int i=1;i<V;i++)
	{
		sum[i]=sum[i-1]+vis[i];
	}
	for(int i=2;i<N;i++)
	{
		long long cnt=0;
		for(int j=1;i*(j-1)<N;j++)
		{
			long long p=sum[i*j]-sum[i*(j-1)];
			cnt+=j*p;
			cnt+=min(p,vis[j])*y;
		}
		cnt-=n*y;
		ans=max(ans,cnt);
	}
	cout<<ans<<"\n";
	return;
}
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin>>T;
	while(T--)
	{
		solve();
	}
	return 0;	
} 