// Dead-Or-Alpha

#include <bits/stdc++.h>
using namespace std;

#ifndef ONLINE_JUDGE
#define debug(x) cerr << #x << " = " << x << endl;
#define debugv(v)          \
    cerr << #v << " = [ "; \
    for (auto x : v)       \
        cerr << x << " ";  \
    cerr << "]" << endl
#else
#define debug(x)
#define debugv(v)
#endif

#define int long long
#define pb push_back
#define vi vector<int>
#define mii map<int, int>
#define setbits(x) __builtin_popcountll(x)
#define zrobits(x) __builtin_ctzll(x)
#define mod 1000000007
#define mod1 998244353
#define inf 1e18
#define nline "\n"
#define PI 3.141592653589793238462
#define sz(x) ((int)(x).size())
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define endl "\n"

#define pprint(arr)        \
    for (auto it : arr)    \
        cout << it << " "; \
    cout << "\n";

// int f(int aa,vi &a,map<int,int> &mp,vi &ans){
//     for(int i=2;i*i<=aa;i++){
//         if(aa%i==0){
//             if(mp[i]>0){
//                 ans[aa/i]++;
//                 mp[i]--;
//             }
//             else if(mp[])
//         }
//     }
// }

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(NULL);
    cout.tie(NULL);

#ifndef ONLINE_JUDGE
    freopen("", "w", stderr);
#endif

    int t;
    cin >> t;
    while (t--)
    {
        int n, y;
        cin >> n >> y;

        vi a(n);
        int maxi = LLONG_MIN;
        for (int i = 0; i < n; i++)
        {
            cin >> a[i];
            maxi = max(maxi, a[i]);
        }
        vi cntTags(maxi + 1, 0);
        for (int i = 0; i < n; i++)
        {
            cntTags[a[i]]++;
        }
        vi presum(maxi + 1, 0);
        for (int i = 1; i <= maxi; i++)
        {
            presum[i] = presum[i - 1] + cntTags[i];
        }
        int maxians = LLONG_MIN;
        if (maxi <= 1)
        {
            cout << n << "\n";
            continue;
        }
        for (int x = 2; x <= maxi; x++)
        {
            int ans = 0;
            for (int price = 1; price <= maxi; price++)
            {
                int l = 1ll * (price - 1) * (x);
                int r = min(maxi, 1ll * price * x);
                if (l >= maxi)
                    break;
                int cnt = 0;
                if (l - 1 >= 0)
                    cnt += presum[r] - presum[l - 1];
                else
                    cnt += presum[r];
                ans += 1ll * cnt * price;
                ans -= 1ll * y * max(0ll, cnt - cntTags[price]);
            }
            maxians = max(maxians, ans);
        }
        cout << maxians << endl;
    }
    return 0;
}