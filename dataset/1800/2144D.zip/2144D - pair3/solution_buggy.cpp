#include <iostream>
#include <bits/stdc++.h>
using namespace std;
#define int long long
using ll = long long ;
using ld = long double ;
vector <int> pref ;
int inf = 1e18 ;
int get_sum(int l , int r ) {
    return pref[r] - pref[max(0ll , l - 1)] ;
}
signed main() {
    int n , y , i , t ; cin >> t ;
    while ( t -- ) {
        cin >> n >> y ;
        vector <int> a(n) ; int mx = 0 ;
        for (i = 0 ; i < n ; i ++ ) { cin >> a[i] ; mx = max(a[i] , mx ) ; }
        pref.resize(mx + 1) ;
        for (i = 0 ; i <= mx ; i ++ ) { pref[i] = 0 ; }
        vector <int> cnt (mx + 1 , 0 )  ;
        for ( auto c : a ) { cnt[c] ++ ; }
        for (i = 1 ; i <= mx ; i ++ ) { pref[i] = pref[i - 1] + cnt[i] ; }
        int ans = -inf ;
        for (int d = 2 ; d <= mx + 1 ; d ++ ) {
            int sum = 0 ;
            for (i = 1 ; i <= (mx + d - 1) / d ; i ++ ) {
                int l = d * ( i - 1 ) + 1 , r = min(mx , d * i ) ;
                int cnt_1 = get_sum(l , r ) ;
                sum += cnt_1 * i - max(0ll , cnt_1 - cnt[i] ) * y;
            }
 ;           ans = max(ans , sum ) ;
        }
        cout << ans << "\n" ;
        // cout << "\n_________________________________________________________\n" ;
    }
}
