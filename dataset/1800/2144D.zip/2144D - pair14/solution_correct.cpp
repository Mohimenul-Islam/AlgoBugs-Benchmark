#include <bits/stdc++.h>
// #include <ext/pb_ds/assoc_container.hpp> // Common file
// #include <ext/pb_ds/tree_policy.hpp> // Including tree_order_statistics_node_update
 
using namespace std;
// using namespace __gnu_pbds;
 
// typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> ordered_set;
// typedef tree<int, null_type, less_equal<int>, rb_tree_tag, tree_order_statistics_node_update> ordered_multiset;
// find_by_order, order_of_key
 
#define fast_io ios_base::sync_with_stdio(false); cin.tie(NULL)
#define ll long long
#define mod 1000000007
#define int long long
 
int mod_exp(int b, int exp, int m) {
    int res = 1; b %= m;
    while (exp > 0) {
        if (exp & 1) res = (res * b) % m;
        b = (b * b) % m;
        exp /= 2;
    }
    return res;
}
int mod_inv(int base, int m) {
    return mod_exp(base, m-2, m)%m;
}
//pisano period
//xor hashing
//string hashing
//Read inverse ackerman function
//Read mobius inverse
//virtual trees(1923E)

signed main() {
    fast_io;
    int test=1; 
    cin >> test;
    while(test--){
        int n, y, mx=0; cin >> n >> y;
        int a[n]; for(int i=0; i<n; i++){
            cin >> a[i]; 
        }
        sort(a, a+n);
        vector<pair<int, int>> cnt;
        vector<int> v(2e5+1);
        cnt.push_back({a[0], 1}); mx=max(mx, a[n-1]);
        v[a[0]]++;
        for(int i=1; i<n; i++){
            v[a[i]]++;
            if(cnt.back().first==a[i]) cnt.back().second++;
            else cnt.push_back({a[i], 1});
        }
        for(int i=2; i<=2e5; i++){
            v[i]+=v[i-1];
        }
        if(mx==1){
            cout << n << '\n'; continue;
        }
        int aans=-1e18;
        for(int i=2; i<=mx; i++){
            int ans=0, k=0;
            for(int j=1; j<=(mx+i-1)/i; j++){
                int count=v[min(i*j, (ll)2e5)]-v[min(i*(j-1), (ll)2e5)];
                ans+=count*j;
                if(k<(int)cnt.size()&&cnt[k].first==j){
                    count-=min(count, cnt[k].second);
                    k++;
                }
                ans-=count*y;
            }
            aans=max(aans, ans);
        }
        cout << aans << '\n';
    }
    return 0;
}