#include<bits/stdc++.h>
using namespace std;
#define M 200005
#define ll long long
#define mod 998244353
#define INF 0x3f3f3f3f3f3f3f3f
ll max(ll a,ll b){
	return (a>b)?a:b;
}
int main(){
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	int t;
	cin>>t;
	while(t--){
		ll n,y;
		cin>>n>>y;
		vector<int>c(n);
		int max11=-1;
		for(int i=0;i<n;i++){
			cin>>c[i];
			if(max11<c[i])max11=c[i];
		}
		vector<int>f(max11+1);
		vector<int>har(max11+1);
		for(int i=0;i<n;i++)har[c[i]]++;
		for(int i=1;i<=max11;i++){
			f[i]=f[i-1]+har[i];
		}
		ll ans=-INF;
		ll temp;
		for(int k=2;k<=max11+1;k++){
			ll yu=0;
			temp=0;
			for(int i=1;i<=(max11+k-1)/k;i++){
				int l=k*(i-1)+1;
				int r=k*i;
				if(r>max11)r=max11;
				yu+=min(f[r]-f[l-1],har[i]);
				temp+=(f[r]-f[l-1])*i;
			}
			temp-=1LL*(n-yu)*y;
			ans=max(ans,temp);
		}
		cout<<ans<<endl;
	}
	return 0;
}