#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=2e5+10;
int pre[N];
int c[N];
int cnt[N];
int sum[N];
int cnt2[N];
void solve(){
  int n,y;
  cin>>n>>y;
  int i,j;
  memset(pre,0,sizeof(pre));
  memset(cnt,0,sizeof(cnt));
  memset(sum,0,sizeof(sum));
  memset(cnt2,0,sizeof(sum));
  int maxn=0;
  for(i=1;i<=n;i++){
  cin>>c[i];
  maxn=max(maxn,c[i]);
  cnt2[c[i]]++;
  pre[c[i]]++;
  }
  for(i=1;i<=200000;i++){
  pre[i]+=pre[i-1];
  }
  for(i=1;i<=maxn;i++){
  for(j=1;j*i<=maxn;){
  ++j;
  int p1=min(j*i-j,maxn),p2=min(j*i,maxn);
  int k1=cnt2[i];
  int k2=pre[p2]-pre[p1];
  int k3=min(k1,k2);
  cnt[j]+=k3;
  sum[j]+=k2*i;
  }
  }
  int ans=-1e18;
  for(i=2;i<=maxn+1;i++){
  sum[i]-=(n-cnt[i])*y;
  ans=max(ans,sum[i]);
  }
  cout<<ans<<'\n';


  
}
signed main(){
  ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
  int t;
  cin>>t;
  while(t--)
  solve();
  

}