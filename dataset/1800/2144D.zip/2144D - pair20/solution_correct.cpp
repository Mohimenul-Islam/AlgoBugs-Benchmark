#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N=1e6+7,V=5e5;
int n,t,y,c[N],b[N],sum[N],x1[N],x2[N];
void solve(){
	cin>>n>>y;
	memset(b,0,sizeof(b));
	memset(x1,0,sizeof(x1));
	memset(x2,0,sizeof(x2));
	for(int i=1;i<=n;i++){
		cin>>c[i];
		b[c[i]]++;
	}
	for(int i=1;i<=V;i++) sum[i]=sum[i-1]+b[i];
	for(int i=2;i<=V;i++){
		for(int k=1;k*i<=V;k++){
			x1[i]+=k*(sum[min(V,k*i)]-sum[(k-1)*i]);
			x2[i]+=min(b[k],sum[min(V,k*i)]-sum[(k-1)*i]);
		}
	}
	int ans=-1e18;
	for(int i=2;i<=V;i++){
		ans=max(ans,x1[i]-y*(n-x2[i]));
	}
	cout<<ans<<'\n';
}
signed main(){
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin>>t;
	while(t--){
		solve();
	} 
    return 0;
}