#include<bits/stdc++.h>
using namespace std;

using ll = long long;

int32_t main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  int t; cin >> t;
  while (t--) {
    int n, y; cin >> n >> y;
    vector<int> a(n);
    for (int i = 0; i < n; i++) {
      cin >> a[i];
    }
    sort(a.begin(), a.end());
    ll mx = a.back();
    vector<int> cnt(mx + 2, 0);
    for (int i = 0; i < n; i++) {
      cnt[a[i]]++;
    }
    vector<ll> f(mx + 2, 0), sum(mx + 2, 0);
    for (int i = 1; i <= mx; i++) {
      f[i] = f[i - 1] + cnt[i];
      sum[i] = sum[i - 1] + cnt[i] * i;
    }
    ll ans = -1e18;
    vector<ll> cntb(mx + 2, 0), sumb(mx + 2, 0);
    for (ll base = 2; base <= mx * 2; base++) {
      ll kmax = 0, ta = 0;
      for (ll k = 0; (k - 1) * base + 1 <= mx; k++) {
        kmax = max(kmax, k);
        ll l = max(1LL, (k - 1) * base + 1);
        ll r = min(mx, k * base);
        cntb[k] = f[r] - f[l - 1];
      }
      for (int i = 0; i <= kmax; i++) {
        ta += cntb[i] * i - max(0LL, cntb[i] - cnt[i]) * y;
      }
      ans = max(ans, ta);
    }
    cout << ans << '\n';
  }
  return 0;
}