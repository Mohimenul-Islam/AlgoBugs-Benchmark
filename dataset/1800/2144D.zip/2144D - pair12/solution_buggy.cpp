#include<bits/stdc++.h>
using namespace std;
#define int long long
const int  N=2e5+10;
int pre[N];
int c[N];
int cnt[N];
void solve()
{
	int n,y;
	cin>>n>>y;
	int maxx=0;
	for(int i=1;i<=n;i++) cin>>c[i];
	for(int i=1;i<N;i++) cnt[i]=0;
	for(int i=1;i<=n;i++)
	{
		cnt[c[i]]++;
		maxx=max(maxx,c[i]);
	}
	pre[0]=0;
	for(int i=1;i<N;i++)
	{
		pre[i]=pre[i-1]+cnt[i];
	}
	int ans=-1e20;
	for(int x=2;x<N;x++)
	{
		int res=0;
		for(int j=1;x*j<N;j++)
		{
			int cnt1=pre[min(j*x,maxx)]-pre[(j-1)*x];
			res+=(cnt1*j-y*max(cnt1-cnt[j],0LL));
		}
		ans=max(res,ans);
	}
	cout<<ans<<endl;
}
signed main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int t;
	cin>>t;
	while(t--) solve();
	return 0;
}