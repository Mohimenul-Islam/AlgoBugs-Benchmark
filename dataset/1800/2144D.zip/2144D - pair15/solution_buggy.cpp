#include <bits/stdc++.h>
using namespace std;
 
#define int long long
#define ld long double

const int mod = 1e9 + 7;
const int INF = 1e18;
const int N = 2e5+1;
const int LOGN = 30;

vector <int> mp;

void solve() {
	int n, y; cin >> n >> y;
	vector <int> v(n);
	for(int i=0; i<n; i++) { cin >> v[i]; mp[v[i]]++; }
	sort(v.begin(), v.end());
	if(v[n-1] == 1) { cout << n << endl; return; }
	int ans = -INF;
	for(int x=2; x<=v[n-1]; x++) {
		int curr = -n*y;
		int stop = (v[n-1]+x-1)/x;
		for(int i=1; i<=stop; i++) {
			int l = x*(i-1);
			int r = x*i;
			int count = upper_bound(v.begin(), v.end(), r) - upper_bound(v.begin(), v.end(), l);
			curr += count*i;
			curr += min(count, mp[i])*y;
		}
		ans = max(ans, curr);
	}
	cout << ans << endl;
	for(int i=0; i<n; i++) mp[v[i]]--;
}

signed main() {
    ios_base::sync_with_stdio(false); 
    cin.tie(NULL);

    int test = 1;
    cin >> test;
    for(int i=1; i<=test; i++) {
    	mp.assign(2e5+1, 0);
        cerr << "Case #" << i << ": " << endl;
        solve();
    }
    cerr << endl;
    return 0;
}

// kmp : done
// xorhashing
// mobius inversion
// sos dp

    