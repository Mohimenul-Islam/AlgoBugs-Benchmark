#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <cmath>
#include <deque>
#include <string>
#include <bit>
#include <algorithm>
#include <cstdint>
#include <cstdint>
#include <map>
#define int long long
const int MOD = 1e9 + 7, N = 1e6 + 5;
using namespace std;
int32_t main()
{
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    int t;
    cin >> t;
    while (t--)
    {
        int n, y;
        cin >> n >> y;
        vector<int> cnt(N);
        vector<int> prefix(N);
        vector<int> numbers;
        for (int i = 0;i < n;i++)
        {
            int x;cin >> x;
            if (cnt[x] == 0)
            {
                numbers.push_back(x);
            }
            cnt[x]++;
        }
        sort(numbers.begin(), numbers.end());
        for (int i = 1;i < N;i++)
            prefix[i] = prefix[i - 1] + cnt[i];
        if (numbers.back() == 1)
        {
            cout << n << "\n";
            continue;
        }
        int ans = LLONG_MIN;
        for (int i = 2;i <= numbers.back();i++)
        {
            int temp = 0;
            for (int j = 1;j <= ceil((double)numbers.back() / (double)i);j++)
            {
                int need = prefix[j * i] - prefix[(j - 1) * i];
                temp += j * need - y * max(0 * 1ll, need - cnt[j]);
            }
            ans = max(ans, temp);
        }
        cout << ans << "\n";
    }
}