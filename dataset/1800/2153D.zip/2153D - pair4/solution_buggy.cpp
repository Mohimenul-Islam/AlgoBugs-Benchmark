#include <bits/stdc++.h>

using namespace std;

#ifndef ONLINE_JUDGE
#include "trace.cpp"
#else
#define dbg(...)
#endif

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define make_unique(x) sort(all((x))); (x).erase(unique(all((x))), (x).end())
#define take_graph(m) for (int i = 0, u, v; i < m; i++) {cin >> u >> v; --u, --v; g[u].push_back(v); g[v].push_back(u);}
#define int int64_t

/*
  we are given an array, 
  we need to make it satisfy one condition
  the array is circular
  the condition is
  all the elements should a adjacent elemente equal to it.

  to do this, we can either increase or decrease any element by one.
  what is the minimum number of increase and decrease to satisfy the condition


  2 2 5 9 5
  dp[i] = minimum answer for the prefix
  to calculate dp[i], 
  we need to know what is the minimum number of operations we need to do
  to make the prefix i - 1 good, such that the prevision element is as it is.
  or

*/

void solve() {
  int n;
  cin >> n;
  vector<int> a(n);
  for (int i = 0; i < n; i++) cin >> a[i];
  vector<int> dp(n, 1e18);
  dp[0] = abs(a[0] - a[n - 1]);
  for (int i = 1; i < n; i++) {
    if (i == 1) {
      dp[i] = abs(a[0] - a[1]) + dp[0];
      if (a[n - 1] == a[i]) {
        dp[i] = dp[i - 1];
      }
    } else {
      dp[i] = dp[i - 2] + abs(a[i] - a[i - 1]);
      if (a[i] == a[i - 2]) {
        if (i > 2) {
          dp[i] = min(dp[i], dp[i - 3] + abs(a[i] - a[i - 1]));
        }
      }
    }
  }
  int ans = dp[n - 2];
  dp.assign(n, 1e18);
  dp[0] = 1e18;
  for (int i = 1; i < n; i++) {
    if (i == 1) {
      dp[i] = abs(a[i] - a[i - 1]);
    } else {
      dp[i] = dp[i - 2] + abs(a[i] - a[i - 1]);
      if (i == 2) {
        vector<int> x = {a[i], a[i - 1], a[i - 2]};
        sort(all(x));
        dp[i] = x[2] - x[0];
      }
      if (a[i] == a[i - 2]) {
        if (i > 2) dp[i] = min(dp[i], dp[i - 3] + abs(a[i] - a[i - 1]));
        else dp[i] = min(dp[i], abs(a[i] - a[i - 1]));
        if (i == 3) {
          dp[i] = min(dp[i], dp[i - 2] + abs(a[i] - a[i - 1]));
        }
      }
    }
  }
  ans = min(ans, dp[n - 1]);
  cout << ans << "\n";
}

int32_t main() {
  cin.tie(0) -> sync_with_stdio(0);
  int t; cin >> t;
  while (t--) solve();
  return 0;
}