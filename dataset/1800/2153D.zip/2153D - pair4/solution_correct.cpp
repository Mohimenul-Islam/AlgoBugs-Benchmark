#include <bits/stdc++.h>

using namespace std;

#ifndef ONLINE_JUDGE
#include "trace.cpp"
#else
#define dbg(...)
#endif

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define make_unique(x) sort(all((x))); (x).erase(unique(all((x))), (x).end())
#define take_graph(m) for (int i = 0, u, v; i < m; i++) {cin >> u >> v; --u, --v; g[u].push_back(v); g[v].push_back(u);}
#define int int64_t

vector<int64_t> get(vector<int> &a) {
  int n = a.size();
  vector<int> dp(n, 1e18);
  for (int i = 1; i < n; i++) {
    if (i == 1) dp[i] = abs(a[i] - a[i - 1]);
    else if (i == 2) dp[i] = max({a[i], a[i - 1], a[i - 2]}) - min({a[i], a[i - 1], a[i - 2]});
    else {
      dp[i] = min(dp[i - 2] + abs(a[i] - a[i - 1]), dp[i - 3] + max({a[i], a[i - 1], a[i - 2]}) - min({a[i], a[i - 1], a[i - 2]}));
    }
  }
  return dp;
}

void solve() {
  int n;
  cin >> n;
  vector<int> a(n);
  for (int i = 0; i < n; i++) cin >> a[i];
  auto dp = get(a);
  int ans = dp[n - 1];
  a.insert(a.begin(), a.back()); a.pop_back();
  dp = get(a);
  ans = min(ans, dp[n - 1]);
  a.insert(a.begin(), a.back()); a.pop_back();
  dp = get(a);
  ans = min(ans, dp[n - 1]);
  cout << ans << "\n";
}

int32_t main() {
  cin.tie(0) -> sync_with_stdio(0);
  int t; cin >> t;
  while (t--) solve();
  return 0;
}