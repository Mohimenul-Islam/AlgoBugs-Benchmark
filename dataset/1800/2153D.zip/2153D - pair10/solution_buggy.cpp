#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N = 2e5 + 10;
const int INF = 0x7fffffff;
int T , n , a[N] , dp[N];
void sol()
{
	cin >> n;
	for (int i = 1 ; i <= n ; i ++)
	{
		cin >> a[i];
	}
	int MIN1 = INF;
	//0
	for (int i = 0 ; i <= n ; i ++)
	{
		dp[i] = INF;
		if (i == 0)
		{
			dp[i] = 0;
		}
		if (i >= 2)
		{
			dp[i] = min (dp[i] , dp[i - 2] + abs(a[i] - a[i - 1]));
		}
		if (i >= 3)
		{
			int MA = 0 , MI = INF;
			for (int j = i - 2 ; j <= i ; j ++)
			{
				MA = max (MA , a[j]) , MI = min (MI , a[j]);
			}
			dp[i] = min (dp[i] , dp[i - 3] + (MA - MI));
		}
	}
	MIN1 = min (MIN1 , dp[n]);
	//1 1
	for (int i = 1 ; i <= n - 1 ; i ++)
	{
		dp[i] = INF;
		if (i == 1)
		{
			dp[i] = 0;
		}
		if (i >= 3)
		{
			dp[i] = min (dp[i] , dp[i - 2] + abs(a[i] - a[i - 1]));
		}
		if (i >= 4)
		{
			int MA = 0 , MI = INF;
			for (int j = i - 2 ; j <= i ; j ++)
			{
				MA = max (MA , a[j]) , MI = min (MI , a[j]);
			}
			dp[i] = min (dp[i] , dp[i - 3] + (MA - MI));
		}
	}
	MIN1 = min (MIN1 , dp[n - 1] + abs(a[1] - a[n]));
	//2 1
	for (int i = 1 ; i <= n - 2 ; i ++)
	{
		dp[i] = INF;
		if (i == 1)
		{
			dp[i] = 0;
		}
		if (i >= 3)
		{
			dp[i] = min (dp[i] , dp[i - 2] + abs(a[i] - a[i - 1]));
		}
		if (i >= 4)
		{
			int MA = 0 , MI = INF;
			for (int j = i - 2 ; j <= i ; j ++)
			{
				MA = max (MA , a[j]) , MI = min (MI , a[j]);
			}
			dp[i] = min (dp[i] , dp[i - 3] + (MA - MI));
		}
	}
	int MA = max (max (a[n - 1] , a[n]) , a[1]) , MI = min (min (a[n - 1] , a[n]) , a[1]);
	MIN1 = min (MIN1 , dp[n - 2] + MA - MI);
	//1 2
	for (int i = 2 ; i <= n - 1 ; i ++)
	{
		dp[i] = INF;
		if (i == 2)
		{
			dp[i] = 0;
		}
		if (i >= 4)
		{
			dp[i] = min (dp[i] , dp[i - 2] + abs(a[i] - a[i - 1]));
		}
		if (i >= 5)
		{
			int MA = 0 , MI = INF;
			for (int j = i - 2 ; j <= i ; j ++)
			{
				MA = max (MA , a[j]) , MI = min (MI , a[j]);
			}
			dp[i] = min (dp[i] , dp[i - 3] + (MA - MI));
		}
	}
	MA = max (max (a[1] , a[2]) , a[n]) , MI = min (min (a[1] , a[2]) , a[n]);
	MIN1 = min (MIN1 , dp[n - 1] + MA - MI);
	cout << MIN1 << "\n";
}
signed main ()
{
	ios::sync_with_stdio(0) , cin.tie(nullptr);
	cin >> T;
	while (T --)
	{
		sol();
	}
	return 0;
}