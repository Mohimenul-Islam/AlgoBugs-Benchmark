// Faster Execution + Optimization
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")
#include <bits/stdc++.h>
using namespace std;
// Fast I/O
#define fastio() ios::sync_with_stdio(false); cin.tie(NULL)
// Typedefs
using ll = long long;
using ull = unsigned long long;
#define int ll
using pii = pair<int,int>;
using vi = vector<int>;
using vll = vector<ll>;
// Macros
#define rep(i,a,b) for(int i=(a); i<(b); i++)
#define all(x) (x).begin(), (x).end()
#define pb push_back
 
// //Code for ordered set starts.
// #include <ext/pb_ds/assoc_container.hpp>
// #include <ext/pb_ds/tree_policy.hpp>
// using namespace __gnu_pbds;
// template<class T> using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
// //Code for ordered set ends.
 
// Debug (optional remove later)
// #define debug(x) cout << #x << " = " << x << "\n"
int n;
void jadoo(int l,vi &v,vi & dp){
    for(int i=l-1;i>=0;i--){
        int curex=1e15;
        if(i+1==l){curex=0;}
        if(i+2<=l){curex=dp[i+2];}
        dp[i]=min(dp[i],abs(v[i]-v[i+1])+curex);
    
        curex=1e15;
        if(i+2>l){continue;}
        if(i+2==l){curex=0;}
        if(i+3<=l){curex=dp[i+3];}
        dp[i]=min(dp[i],abs(max(max(v[i],v[i+1]),v[i+2])-min(min(v[i],v[i+1]),v[i+2]))+curex);

    }
}

void solve() {
    // Write cod for each test case here
    cin>>n;
    vi v(n);rep(i,0,n){cin>>v[i];}
    int ans=1e15;
    rep(alpha,0,3){
        vi dp(n,1e15);
        jadoo(n-1-alpha,v,dp);
        if(2>alpha){ans=min(ans,abs(v[(n-alpha)%n]-v[(n+1-alpha)%n])+dp[2-alpha]);}
        ans=min(ans,abs(max(max(v[2-alpha],v[(n+1-alpha)%n]),v[(n-alpha)%n])-min(min(v[2-alpha],v[(n+1-alpha)%n]),v[(n-alpha)%n]))+dp[3-alpha]);
    }
    cout<<ans<<endl;
}
signed main() {
    fastio();
    int t=1;
    cin >> t;
    // If multiple test cases, uncomment above
    while (t--) {
        solve();
    }
    return 0;
}

/*
⠀⠀⢀⣤⣤⣤⣤⣤⣤⣀⡀⠀⠀⢀⣀⠄⠀⠀⣀⣠⣤⡤⠤⠀⠀⠀⠀⠀
⢀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠀⣠⣾⣿⠟⠁⠀⠀⠀⠀⠀⠀⠀
⡼⠋⠁⠀⠈⠉⠙⠛⠛⠉⣡⣿⡟⠀⠀⣼⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣿⣿⠁⠀⠀⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⣿⣿⠀⠀⠘⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⠀⠀⠀⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⡀⠀⠀⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢀⣤⣶⣶⣶⣿⣿⣿⣿⡇⠀⠀⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠈⠉⠉⠙⢿⣿⣿⣿⣿⡇⠀⠀⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣿⣿⡇⠀⠀⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠶⢶⣶⣾⣿⣿⣿⠁⠀⢠⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⢿⣿⣿⡏⠀⢀⣾⣿⠟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡿⠀⢀⣾⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢀⣾⡟⢁⣴⣟⣡⣤⣤⣶⣶⣶⣶⣶⣦⣤⣀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢠⣾⣟⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣦⣴⠞
⠀⠀⠀⠀⢀⣴⡿⠿⠛⠛⠋⠉⠉⠉⠉⠉⠉⠛⠛⠿⣿⣿⣿⣿⣿⠟⠁⠀
⠀⠀⠀⠘⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠻⠟⠁⠀⠀⠀
*/