#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using vi = vector<int>;
using vii = vector<vector<int>>;
using vl = vector<ll>;
using vll = vector<vl>;
using pii = pair<int,int>;
using pll = pair<ll,ll>;
using vpi = vector<pair<int,int>>;
using vpl = vector<pair<ll,ll>>;
using vpll = vector<vector<pair<ll,ll>>>;
#define rt return
struct custom_hash {
   static uint64_t splitmix64(uint64_t x) {
      x += 0x9e3779b97f4a7c15;
      x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;
      x = (x ^ (x >> 27)) * 0x94d049bb133111eb;
      return x ^ (x >> 31);
   }
   size_t operator()(uint64_t x) const {
       static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();
       return splitmix64(x + FIXED_RANDOM);
   }
};
#ifdef ONLINE_JUDGE
#include <ext/pb_ds/assoc_container.hpp>
using namespace __gnu_pbds;
#define um gp_hash_table
#define debug(x...)
#define debugmul(v...)
#else
#define debug(x...) cerr << "[" << #x << "] = ["; _print(x)
#define debugmul(v...) cerr<< "[" << #v <<"] = ["; __print_auto(v)
#define um unordered_map
void __print(auto x){
    cerr << x;
}
void __print(pair<auto,auto> p){
    cerr << "{" << p.first <<","<<p.second<<"}";
}
void _print() {cerr << "]\n";}
template<typename T, typename... V>
void _print(T t, V... v) { __print(t); if (sizeof...(v)) cerr << ", "; _print(v...);}
void __print_auto(){cerr << "]\n";}
template<typename T,typename... V>
void __print_auto(const T &x, const V&... y) {
    int f = 0;
    cerr << '{';
    for (const auto &i: x) cerr << (f++ ? "," : ""), __print(i);
    cerr << "}";
    if (sizeof...(y)) cerr << ", ";
    __print_auto(y...);
}
#endif
template<typename Key, typename Value, typename Hash = custom_hash>
using hashmap = um<Key, Value, Hash>;
#define pyes cout<<"YES"<<endl
#define pno cout<<"NO"<<endl
#define endl '\n'
#define M 1000000007
void pr(auto x){
    cout<<x<<endl;
}
template<typename T>
void autopr(const T&v) {
    for (auto &x : v) cout << x << ' ';
    cout << endl;
}
pair<vector<bool>,vector<int>> sieve(int n) {
    vector<bool> is_prime(n + 1, true);
    vector<int> primes;
    is_prime[0] = is_prime[1] = false;
    for (int i = 2; i * i <= n; i++) {
        if (is_prime[i]) {
            for (int j = i * i; j <= n; j += i) {
                is_prime[j] = false;
            }
        }
    }
    for(int i=0;i<=n;i++){
        if(is_prime[i]) primes.push_back(i);
    }
    return make_pair(is_prime,primes);
}
vector<ll> prefix_sum(const vector<ll> &v) {
    if(!v.size()) return vl();
    vector<ll> prefix;
    prefix.push_back(0);
    for (int i = 0; i < (int)v.size(); ++i) {
        prefix.push_back(v[i]+prefix.back());
    }
    return prefix;
}
template<typename T>
pair<T,int> min(const vector<T>& v) {
    auto it = min_element(v.begin(), v.end());
    return {*it,it-v.begin()};
}
template<typename T>
pair<T,int> max(const vector<T>& v) {
    auto it = max_element(v.begin(), v.end());
    return {*it,it-v.begin()};
}
#define precision(x, p) std::cout << std::fixed << std::setprecision(p) << x << endl;
#define pb push_back
#define get_bit(x,r) (x&(1<<r))
#define all(v) v.begin(),v.end()
#define sz(x) (int)x.size()
#define len(x) (int)x.length()
#define srt(v) sort(all(v))

void solve(){
    ll n;
    cin>>n;
    vl v(n);
    for(auto &e:v){
        cin>>e;
    }
    ll mxsize = min(n+1,4ll);
    auto cost = [&](ll l,ll r){
        if(l<0) l+=n;
        if(r<0) r+=n;
        vl v1;
        for(ll j=l;j!=r;j = (j+1)%n){
            v1.pb(v[j]);
        }
        v1.pb(v[r]);
        srt(v1);
        ll cnt = v1.size();
        ll score = 0;
        for(ll i=0;i<v1.size();i++){
            if(i==(cnt-1)/2){
                if(cnt%2==0){
                    score-=v1[i];
                }
            }else if(i>(cnt-1)/2){
                score+=v1[i];
            }else{
                score-=v1[i];
            }
        }
        // debug(l,r,score);
        // debugmul(v,v1);
        return score;
    };
    // debugmul(v);
    const ll inf = 1e18;
    vll dp(n+1,vl(mxsize,-1));
    ll wrap;
    auto f = [&](auto &&self,ll i,ll x){
        if(dp[i][x]!=-1) return dp[i][x];
        if(i==n-wrap){
            if(x==1){
                return dp[i][x] = inf;
            }
            return dp[i][x] = cost(i-x,i-1);
        }
        if(x==mxsize-1){
            rt dp[i][x] = min(inf,self(self,i+1,1)+cost(i-x,i-1));
        }
        if(x==1){
            rt dp[i][x] = self(self,i+1,x+1);
        }
        rt dp[i][x] = min(inf,min(self(self,i+1,1)+cost(i-x,i-1),self(self,i+1,x+1)));
    };
    ll ans = inf;
    for(wrap=0;wrap<mxsize;wrap++){
        dp.assign(n+1,vl(mxsize,-1));
        f(f,0,wrap);
        ans = min(ans,dp[0][wrap]);
    }
    cout<<ans<<endl;
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    ll t=1;
    cin>>t;
    while(t--){
        solve();
    }
    return 0;
}