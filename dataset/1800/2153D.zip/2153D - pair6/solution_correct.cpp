#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define GO ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
const ll N = 2e5 + 2, oo = 1e18, mod = 998244353;


int main() {
    GO
    ll t = 1;
    cin >> t;
    while (t--) {
        ll n;
        cin>>n;
        vector<ll>a(n+2,0);
        for(int i=0; i<n; i++) {
            cin>>a[i];
        }
        a[n]=a[0];
        a[n+1]=a[1];
        ll ans=oo;
        for(int j=0; j<3; j++) {
            vector<ll>dp(n,0);
            dp[0]=oo;
            dp[1]=abs(a[1+j]-a[0+j]);
            dp[2]=max({a[0+j],a[1+j],a[2+j]})-min({a[0+j],a[1+j],a[2+j]});
            for(int i=3; i<n; i++) {
                ll x=abs(a[i+j]-a[i+j-1]);
                ll y=max({a[i+j],a[i+j-1],a[i+j-2]})-min({a[i+j],a[i+j-1],a[i+j-2]});
                dp[i]=min(x+dp[i-2],y+dp[i-3]);
            }
            ans=min(ans,dp[n-1]);
        }
        cout<<ans<<endl;

    }
}