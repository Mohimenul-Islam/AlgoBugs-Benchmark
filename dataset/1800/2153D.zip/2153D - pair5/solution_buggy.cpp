#include <bits/stdc++.h>
using namespace std;
#include <bits/extc++.h>
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
// uniform_int_distribution<ll> dist(0, n - 1);

#pragma GCC optimize("O3,unroll-loops")
#pragma GCC target("avx2,popcnt")

#define rep(i, a, b) for(ll i = a; i < (b); ++i)
#define all(x) begin(x),end(x)
#define sz(x) (int)(x).size()

typedef unsigned long long ull;
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef pair<ll, ll> pll;
typedef double ld;

void solve() {
    ll n;
    cin >> n;
    vll a(n);
    rep(i, 0, n) cin >> a[i];

    auto getans = [&]() -> ll {
        const ll inf = 1e17;
        vll dp(n+1, inf); // end group here
        dp[0] = 0;
        dp[2] = abs(a[0] - a[1]);
        rep(i, 2, n) {
            dp[i+1] = min(abs(a[i]-a[i-1]) + dp[i-1], max({a[i-2], a[i-1], a[i]}) - min({a[i-2], a[i-1], a[i]}) + dp[i-2]);
        }
        return dp[n];
    };
    ll ans = getans();
    vll b(n);
    rep(i, 0, n) b[i] = a[(i+1)%n];
    a = b;
    ans = min(ans, getans());
    cout << ans << '\n';
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    cin.exceptions(cin.failbit);
    // cout << setprecision(10) << fixed;
    ll tt = 1; cin >> tt;
    while(tt--) solve();
}
