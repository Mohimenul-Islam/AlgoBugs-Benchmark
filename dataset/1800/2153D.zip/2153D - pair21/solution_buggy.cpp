#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

typedef long long ll;
const ll INF = 1e18;

ll get_ans(int n, const vector<ll>& a) {
    vector<ll> dp(n + 1, INF);
    dp[0] = 0;
    for (int i = 2; i <= n; i++) {
        dp[i] = min(dp[i], dp[i - 2] + abs(a[i] - a[i - 1]));
        if (i >= 3) {
            vector<ll> v = {a[i], a[i - 1], a[i - 2]};
            sort(v.begin(), v.end());
            dp[i] = min(dp[i], dp[i - 2] + v[2] - v[0]);
        }
    }
    return dp[n];
}

void solve() {
    int n;
    if (!(cin >> n)) return;
    vector<ll> a(n + 1);
    for (int i = 1; i <= n; i++) cin >> a[i];

    ll ans = INF;
    for (int offset = 0; offset < 3; offset++) {
        vector<ll> b(n + 1);
        for (int i = 1; i <= n; i++) {
            int idx = (i + offset - 1) % n + 1;
            b[i] = a[idx];
        }
        ans = min(ans, get_ans(n, b));
    }
    cout << ans << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    if (!(cin >> t)) return 0;
    while (t--) {
        solve();
    }
    return 0;
}
