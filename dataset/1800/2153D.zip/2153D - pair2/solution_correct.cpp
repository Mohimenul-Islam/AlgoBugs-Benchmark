#include <bits/stdc++.h>

using namespace std;

#define Aboeldahab                \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);
#define ll long long
//#define int long long
#define ull unsigned long long
#define ld long double
#define all(x) x.begin(), x.end()

#define endl '\n'

void READFILE() {
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    freopen("errors.txt", "w", stderr);

#endif
}

const int dx[] = {0, 0, 1, -1};
const int dy[] = {1, -1, 0, 0};

const int inf = 2e9, MAX_X = 2001, LG = 18, mod = 998244353;
const int N = 2e5 + 5, M = 1e6 + 5, inv = 5000004;
const ll LLinf = 1e18;
const ld PI = acos(-1);

int n;
deque<ll> v;
ll dp[N];

ll calc_cost(vector<ll> a) {
    sort(all(a));
    return a.back() - a.front();
}

ll fun(int i) {
    if (i > n)return LLinf;
    if (i == n) return 0;
    ll &ret = dp[i];
    if (~ret) return ret;
    ret = LLinf;
    if (i + 1 < n) {
        ll cost = calc_cost(vector({v[i], v[i + 1]}));
        ret = min(ret, cost + fun(i + 2));
    }
    if (i + 2 < n) {
        ll cost = calc_cost(vector({v[i], v[i + 1], v[i + 2]}));
        ret = min(ret, cost + fun(i + 3));
    }

    return ret;

}


void solve() {
    cin >> n;
    v.resize(n);
    for (int i = 0; i < n; ++i) cin >> v[i];
    for (int i = 0; i <= n; ++i)
        dp[i] = -1;
    ll ans = fun(0);
    for (int i = 0; i <= n; ++i)
        dp[i] = -1;
    v.push_back(v.front());
    v.pop_front();
    ans = min(ans, fun(0));
    for (int i = 0; i <= n; ++i)
        dp[i] = -1;
    v.push_back(v.front());
    v.pop_front();
    ans = min(ans, fun(0));
    cout << ans << endl;

}

void preCalculate() {
}

signed main() {
    READFILE();
    // freopen("shelves.in", "r", stdin);

    Aboeldahab
    preCalculate();
    cout << fixed << setprecision(10);
    int tc = 1;
    cin >> tc;
    for (int i = 1; i <= tc; ++i) {
        // cout << "Case " << i << ":" << " ";
        solve();
    }
    return 0;
}