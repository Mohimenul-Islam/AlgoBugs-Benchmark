#include <bits/stdc++.h>

using namespace std;

#define Aboeldahab                \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);
#define ll long long
//#define int long long
#define ull unsigned long long
#define ld long double
#define all(x) x.begin(), x.end()

#define endl '\n'

void READFILE() {
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    freopen("errors.txt", "w", stderr);

#endif
}

const int dx[] = {0, 0, 1, -1};
const int dy[] = {1, -1, 0, 0};

const int inf = 2e9, MAX_X = 2001, LG = 18, mod = 998244353;
const int N = 2e5 + 5, M = 1e6 + 5, inv = 5000004;
const ll LLinf = 1e18;
const ld PI = acos(-1);

int n;
vector<ll> v(N);
ll dp[N][3];

ll fun(int i, int d) {
    if (i > n - d)return LLinf;
    if (i == n - d) return 0;
    ll &ret = dp[i][d];
    if (~ret) return ret;
    ll mx1 = max(v[i], v[i + 1]);
    ll mn1 = min(v[i], v[i + 1]);
    ll sum1 = v[i] + v[i + 1];
    ll cost1 = min(2 * mx1 - sum1, sum1 - 2 * mn1);
    ll mx2 = max(mx1, v[i + 2]);
    ll mn2 = min(mn1, v[i + 2]);
    ll sum2 = sum1 + v[i + 2];
    ll cost2 = min(3 * mx2 - sum2, sum2 - 3 * mn2);
    return ret = min(cost1 + fun(i + 2, d), cost2 + fun(i + 3, d));

}


void solve() {
    cin >> n;
    for (int i = 0; i < n; ++i) cin >> v[i];
    for (int i = 0; i <= n; ++i)
        dp[i][0] = dp[i][1] = dp[i][2] = -1;
    ll mx1 = max(v[0], v[n - 1]);
    ll mn1 = min(v[0], v[n - 1]);
    ll sum1 = v[0] + v[n - 1];
    ll cost1 = min(2 * mx1 - sum1, sum1 - 2 * mn1);
    ll mx2 = max(mx1, v[n - 2]);
    ll mn2 = min(mn1, v[n - 2]);
    ll sum2 = sum1 + v[n - 2];
    ll cost2 = min(3 * mx2 - sum2, sum2 - 3 * mn2);
    ll mx3 = max(mx1, v[1]);
    ll mn3 = min(mn1, v[1]);
    ll sum3 = sum1 + v[1];
    ll cost3 = min(3 * mx3 - sum3, sum3 - 3 * mn3);

    ll ans = min({
                         fun(0, 0),
                         cost1 + fun(1, 1),
                         cost2 + fun(1, 2),
                         cost3 + fun(2, 1)
                 });
    cout << ans << endl;

}

void preCalculate() {
}

signed main() {
    READFILE();
    // freopen("shelves.in", "r", stdin);

    Aboeldahab
    preCalculate();
    cout << fixed << setprecision(10);
    int tc = 1;
    cin >> tc;
    for (int i = 1; i <= tc; ++i) {
        // cout << "Case " << i << ":" << " ";
        solve();
    }
    return 0;
}