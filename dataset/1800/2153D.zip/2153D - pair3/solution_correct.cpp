#include<bits/stdc++.h>
using namespace std;
#define M 200005
#define ll long long
#define mod 998244353
#define INF 0x3f3f3f3f3f3f3f3f
int cost(ll a,ll b){
	return abs(a-b);
}
int cost(ll a,ll b,ll c){
	if(a<b)swap(a,b);
	if(a<c)swap(a,c);
	if(b<c)swap(b,c);
	return abs(a-c);
}
void swap(int *a,int *b){
	int temp=*a;
	*a=*b;
	*b=temp;
}
int main(){
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int t;
    cin>>t;
    while(t--){
    	int n;
    	cin>>n;
    	vector<ll>a(n+1);
    	vector<ll>dp(n+1);
    	for(int i=1;i<=n;i++){
    		cin>>a[i];
		}
		ll ans=INF;
		dp[1]=INF;
		for(int y=0;y<3;y++){
		for(int i=2;i<=n;i++){
			if(i==2)
			dp [i] =  dp [i-2] + 1LL*cost (a[i],a[i-1]);
			else {
				dp [i] = min ( dp[i-2] + 1LL*cost ( a [i] , a[i-1] ) , dp[i-3]+1LL*cost(a[i],a[i-1],a[i-2]) );
			}
		}
		ans=min(dp[n],ans);
		for(int i=2;i<=n;i++){
			swap(a[i-1],a[i]);
		}
	}
	cout<<ans<<'\n';
	}
    return 0;
}