#include <bits/stdc++.h>
using namespace std;
#define int long long
constexpr int INF=1e18;
constexpr int mod=998244353;
constexpr int base=300007;
void solve() {
    int n;cin>>n;
    vector<int> a(n+1),b(n+1),c(n+1);
    for (int i=1;i<=n;i++) cin>>a[i];
    b[1]=a[n];c[1]=a[n-1];c[2]=a[n];
    for (int i=2;i<=n;i++) {
        b[i]=a[i-1];
        if (i>2) c[i]=a[i-2];
    }
    auto check=[&](vector<int>& nums)->int {
        vector<int> dp(n+1);
        for (int i=2;i<=n;i++) {
            int num1=max(nums[i],nums[i-1])-min(nums[i],nums[i-1]);
            int num2=0;
            if (i>=3) {
                int mx=max(max(nums[i],nums[i-1]),nums[i-2]);
                int mn=min(min(nums[i],nums[i-1]),nums[i-2]);
                num2=mx-mn;
            }
            dp[i]=dp[i-2]+num1;
            if (i>=3) dp[i]=min(dp[i],dp[i-3]+num2);
        }
        return dp[n];
    };
    cout<<min(min(check(a),check(b)),check(c))<<'\n';
}
signed main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    int t;
    if (cin >> t) {
        while (t--) {
            solve();
        }
    }
    return 0;
}