#include<bits/stdc++.h> 
using namespace std; 
using ll = long long ; 

void solve(int testno, int tests){

	int x, y ;
	cin >> x >> y ; 

	int p = 0, q = 0 ;
	int last_zero_bit = -1 ;   
	for(int bit = 30; bit >= 0; bit--){

		int powbit = pow(2, bit) ; 

		int bit1 = (x & powbit) == 0 ? 0 : 1 ; 
		int bit2 = (y & powbit) == 0 ? 0 : 1 ; 


		if(bit1 == bit2){
			if(bit1 == 0){
				last_zero_bit = bit ;    
				continue ; 
			} 



			p = p + (powbit) ; 
			q = q + (powbit - 1) ; 

			// int p_pos2 = p_pos1, q_pos2 = q_pos1 ; 
			// int p_pos3 = p_pos1, q_pos3 = q_pos1 ;  
			// if(last_zero_bit != -1){
			// 	p_pos2 = p + (powbit*2) ; 
			// 	q_pos2 = q + (y & (2*powbit - 1)) ;


			// 	p_pos3 = p + (x & (powbit*2 -1)) ; 
			// 	q_pos3 = q + (powbit*2) ; 
			// }

			// cout << p_pos1 << " " << q_pos1 << endl; 
			// cout << p_pos2 << " " << p_pos2 << endl; 
			// cout << p_pos3 << " " << q_pos3 << endl ;

			// int diff1 = abs(p_pos1 - x) + abs(q_pos1 - y) ; 
			// int diff2 = abs(p_pos2 - x) + abs(q_pos2 - y) ; 
			// int diff3 = abs(p_pos3 - x) + abs(q_pos3 - y) ;  

			// if(diff1 == min({diff1, diff2, diff3})){
			// 	p = p_pos1, q = q_pos1 ;  
			// } else if(diff2 == min({diff1, diff2, diff3})){
			// 	p = p_pos2, q = q_pos2 ;  
			// } else{
			// 	p = p_pos3, q = q_pos3 ;
			// }

			break; 


		} else{
			p += (bit1 * powbit) ; 
			q += (bit2 * powbit) ; 
		}


	}


	if(last_zero_bit != -1){
		int pos_p = 0, pos_q = 0 ; 

		for(int bit = 30; bit > last_zero_bit; bit--){
			int powbit = pow(2, bit) ; 

			int bit1 = (x & powbit) == 0 ? 0 : 1 ; 
			int bit2 = (y & powbit) == 0 ? 0 : 1 ;

			pos_p += (bit1 * powbit) ; 
			pos_q += (bit2 * powbit) ; 
		}

		// cout << pos_p << " " << pos_q << endl; 
		int pow_zero_bit = pow(2, last_zero_bit) ; 

		int pos_p1 = pos_p + (pow_zero_bit), pos_q1 = pos_q + (y & (pow_zero_bit -1)) ;
		int pos_p2 = pos_p + (x & (pow_zero_bit - 1)), pos_q2 = pos_q + (pow_zero_bit) ; 

		int diff1 = abs(pos_p1 - x) + abs(pos_q1 - y) ; 
		int diff2 = abs(pos_p2 - x) + abs(pos_q2 - y) ; 


		if(diff1 == min({diff1, abs(p-x) + abs(q-y), diff2})){
			p = pos_p1, q = pos_q1 ;  
		} else if(diff2 == min({diff1, abs(p-x) + abs(q-y), diff2})){
			p = pos_p2, q = pos_q2 ; 
		}
	}

	if(tests >= 100){
		if(testno == 207) cout << x << " " << y << endl; 
	} else{
		cout << p << " " << q << endl; 
	}

}

int main(){
	int t; 
	cin >> t ; 

	for(int i = 0; i < t; i++){
		solve(i, t) ; 
	}
}