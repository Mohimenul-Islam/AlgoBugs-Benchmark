#include <bits/stdc++.h>
using namespace std;

long long dp[32][3][3];
const long long INF = 0x3f3f3f3f3f3f3f3f;

pair<int, int> pres[32][3][3];
int prep[32][3][3];
int preq[32][3][3];

pair<long long, int> get_next(int i, int cur, int bit1, int bit2) {
    long long cost = 0;
    int ns = 0;
    if(cur == 1) {
        if(bit1 == bit2) {
            cost = 0;
            ns = 1;
        }else if(bit2 < bit1) {
            cost = (1 << i);
            ns = 0;
        }else if(bit2 > bit1) {
            cost = (1 << i);
            ns = 2;
        }
    }else if(cur == 0) {
        cost = (bit1 - bit2) * (1 << i);
        ns = 0;
    }else if(cur == 2) {
        cost = (bit2 - bit1) * (1 << i);
        ns = 2;
    }
    return {cost, ns};
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int t;
    cin >> t;
    while(t--) {
        for(int i = 31;i >= 0;i--) {
            for(int j = 0;j < 3;j++) {
                for(int k = 0;k < 3;k++) {
                    dp[i][j][k] = INF;
                }
            }
        }
        dp[31][1][1] = 0;
        long long x, y;
        cin >> x >> y;
        for(int i = 30;i >= 0;i--) {
            int xi = (x >> i) & 1;
            int yi = (y >> i) & 1;

            for(int j = 0;j < 3;j++) {
                for(int k = 0;k < 3;k++) {
                    if(dp[i + 1][j][k] == INF) continue;
                    int temp[3][2] = {{0, 0}, {1, 0}, {0, 1}};
                    for(auto& t: temp) {
                        pair<long long, int> px = get_next(i, j, xi, t[0]);
                        pair<long long, int> py = get_next(i, k, yi, t[1]);

                        long long cost = dp[i + 1][j][k] + px.first + py.first;
                        int nx = px.second;
                        int ny = py.second;
                        if(cost < dp[i][nx][ny]) {
                            dp[i][nx][ny] = cost;
                            pres[i][nx][ny] = {j, k};
                            prep[i][nx][ny] = t[0];
                            preq[i][nx][ny] = t[1];
                        }
                    }
                }
            }
        }

        long long cost = INF;
        int curp = -1, curq = -1;
        for(int i = 0;i < 3;i++) {
            for(int j = 0;j < 3;j++) {
                if(dp[0][i][j] < cost) {
                    cost = dp[0][i][j];
                    curp = i;
                    curq = j;
                }
            }
        }
        long long p = 0, q = 0;
        for(int i = 0;i <= 30;i++) {
            p |= (prep[i][curp][curq] << i);
            q |= (preq[i][curp][curq] << i);
            curp = pres[i][curp][curq].first;
            curq = pres[i][curp][curq].second;
        }
        cout << p << ' ' << q << endl;
    }
}