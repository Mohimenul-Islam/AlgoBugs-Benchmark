#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define int long long
typedef pair<int, int> pii;

void solve() {
  int x, y;
  cin >> x >> y;
  int p1 = x;
  int q1 = 0;
  int temp;
  for(int i = 30; i >= 0; i --) {
    temp = 1 << i;
    if((p1 >> i) & 1) continue;
    else {
      if(abs(q1 + temp - y) < abs(temp - y)) temp = q1 + temp;
      if(abs(q1 - y) > abs(temp - y)) q1 = temp;
    }
  }
  int p2 = y;
  int q2 = 0;
  for(int i = 30; i >= 0; i --) {
    temp = 1 << i;
    if((p2 >> i) & 1) continue;
    else {
      if(abs(q2 + temp - x) < abs(temp - x)) temp = q2 + temp;
      if(abs(q2 - x) > abs(temp - x)) q2 = temp;
    }
  }
  if(abs(p1 - x) + abs(q1 - y) > abs(p2 - y) + abs(q2 - x)) cout << q2 << " " << p2 << endl;
  else cout << p1 << " " << q1 << endl;
}

signed main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  int t = 1;
  cin >> t;
  while (t--) {
    solve();
  }
  return 0;
}