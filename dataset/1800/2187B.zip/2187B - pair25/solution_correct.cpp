#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define int long long
typedef pair<int, int> pii;

void solve() {
  int x, y;
  cin >> x >> y;
  int ansp, ansq, ans = INT32_MAX;
  if(!(x & y)) {cout << x << " " << y << endl; return;}
  for(int I = 0; I <= 30; I ++) {
    int Y = (y >> (1 + I)) << (1 + I);
    if(Y & x) continue;
    int by = y >> I & 1;
    int p = x, q = Y;
    if(by) {
      for(int i = 0; i < I; i ++) {
        if(!((x >> i) & 1)) q ^= (1 << i);
      }
      int res = abs(p - x) + abs(q - y);
      if(res < ans) {
        ans = res, ansq = q, ansp = p;
      }
    }
    else {
      q = Y ^ (1 << I);
      if(q & x) continue;
      int res = abs(p - x) + abs(q - y);
      if(res < ans) {
        ans = res, ansq = q, ansp = p;
      }
    }
  }
  for(int I = 0; I <= 30; I ++) {
    int X = (x >> (I + 1)) << (I + 1);
    if(X & y) continue;
    int bx = x >> I & 1;
    int p = X, q = y;
    if(bx) {
      for(int i = 0; i < I; i ++) {
        if(!((y >> i) & 1)) p ^= 1 << i;
      }
      int res = abs(p - x) + abs(q - y);
      if(res < ans) {
        ans = res, ansp = p, ansq = q;
      }
    }
    else {
      p ^= 1 << I;
      if(p & y) continue;
      int res = abs(p - x) + abs(q - y);
      if(res < ans) {
        ans = res, ansp = p, ansq = q;
      }
    }
  }
  cout << ansp << " " << ansq << endl;
}

signed main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  int t = 1;
  cin >> t;
  while (t--) {
    solve();
  }
  return 0;
}