#include <bits/stdc++.h>
#include <iostream>

using namespace std;

int find_first_conflict(int a, int b)
{
    int conflict_po2 = 31;
    while (!((a & b) & (1 << conflict_po2)))
    {
        --conflict_po2;
    }
    return conflict_po2;
}

pair<int, int> minimize_cost(int x, int y)
{

    if ((x & y) == 0)
    {
        return make_pair(x, y);
    }

    if ((x & y) == 1)
    {
        return make_pair(x-1, y);
    }

    int first_conflict_bit = find_first_conflict(x, y);

    int p = 0;
    int q = 0;
    int score = x + y;

    int new_p, new_q, new_score;

    int top_bits_mask = 0xffffffff - ((1 << first_conflict_bit) - 1);
    // Solve by p = x (-1) q = y (0)

    new_p = (x & top_bits_mask) - 1;
    new_q = y & top_bits_mask;

    new_score = abs(new_p - x) + abs(new_q - y);

    if (new_score < score)
    {
        p = new_p;
        q = new_q;
        score = new_score;
    }

    // Solve by p = x (0) q = y(-1)
    new_p = x & top_bits_mask;
    new_q = (y & top_bits_mask) - 1;

    new_score = abs(new_p - x) + abs(new_q - y);

    if (new_score < score)
    {
        p = new_p;
        q = new_q;
        score = new_score;
    }

    // Solutions where adding (1<<first_conflict bit) makes the problem go away

    // Solve by p = x (1) q = y(0)
    new_p = (x & top_bits_mask) + (1 << first_conflict_bit);
    if ((new_p & y) == 0)
    {
        new_q = y;
        new_score = abs(new_p - x) + abs(new_q - y);
        if (new_score < score)
        {
            p = new_p;
            q = new_q;
            score = new_score;
        }
    }

    // Solve by p = x (0) q = y(1)
    new_q = (y & top_bits_mask) + (1 << first_conflict_bit);
    if ((new_q & x) == 0)
    {
        new_p = x;
        new_score = abs(new_p - x) + abs(new_q - y);
        if (new_score < score)
        {
            p = new_p;
            q = new_q;
            score = new_score;
        }
    }

    return make_pair(p, q);
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int x, y;
        cin >> x >> y;

        pair<int, int> result = minimize_cost(x, y);
        cout << result.first << " " << result.second << endl;
    }
}