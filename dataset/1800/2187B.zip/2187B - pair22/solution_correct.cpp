#include <bits/stdc++.h>
using namespace std;
#define int long long
typedef long long ll;
#define ar array
int32_t main(){
    ios_base::sync_with_stdio(false);cin.tie(NULL);
    int t;
    cin >> t;
    while(t--){
        int x, y;
        cin >> x >> y;
        auto solve = [](int x, int y) -> int {
            int bestsmaller = 0;
            for(int i=30; i>=0; i--){
                int b = (1<<i);
                if(x&b&y){
                    bestsmaller |= (b-1) ^ (x&(b-1));
                    break;
                }
                if(y&b){
                    bestsmaller |= b;
                }
            }
            int bestbigger = 0;
            if(y == 0) return bestsmaller;
            int gsb = 31 - __builtin_clz(y);
            if(x & (1LL<<gsb)){
                for(int j=gsb+1; j<=31; j++){
                    int bb = (1LL<<j);
                    if(!(x&bb)){
                        bestbigger = bb;
                        break;
                    }
                }
                if(bestbigger == 0) return bestsmaller;
            }
            else{
                int aux = (1LL<<gsb);
                for(int i=gsb-1; i>=0; i--){
                    int b = (1LL<<i);
                    if(x&b&y){
                        for(int j=i+1; j<=31; j++){
                            int bb = (1LL<<j);
                            if(!(x&bb) and !(aux&bb)){
                                aux |= bb;
                                break;
                            }
                            if(aux&bb){
                                aux ^= bb;
                            }
                        }
                        if(aux == 0) break;
                        if(bestbigger == 0) bestbigger = aux;
                        else bestbigger = min(bestbigger, aux);
                        break;
                    }
                    if(y&b){
                        aux |= b;
                    }
                    else if(!(x&b)){
                        if(bestbigger == 0) bestbigger = (aux | b);
                        else bestbigger = min(bestbigger, aux | b);
                    }
                }
                if(bestbigger == 0) return bestsmaller;
            }
            return (y - bestsmaller < bestbigger - y ? bestsmaller : bestbigger);
        };
        int q = solve(x, y);
        int p = solve(y, x);
        if(abs(y - q) < abs(x - p)){
            cout << x << " " << q << "\n";
        }
        else cout << p << " " << y << "\n";
    }
    return 0;
}