#include <bits/stdc++.h>
#include <fstream>
using namespace std;
//ofstream dlog("debug.txt");

pair<long long,long long> calc(long long rem, long long mark){
    // tinh de thang kia lon hon rem nhg be nhat co the
    long long res1 = 0, res2 = 0, res3 = 0;

    int g = -1;
    if(rem > 0) g = log2(rem);
    // tinh de no < rem nhg lon nhat co the
    for(long long i = g; i >= 0; i--){
        long long c2 = ((mark >> i) & 1ll);
        if(!c2 && ((res1 | (1ll << i)) <= rem)) res1 |= (1ll << i);
    }



    for(long long i = g; i >= 0; i--){
        long long c1 = ((rem >> i) & 1ll);
        long long c2 = ((mark >> i) & 1ll);
        if(c1 && !c2) res2 |= (1ll << i);
        if(!c1 && !c2) {res2 |= (1ll << i); break;}
    }

    for(long long i = g + 1; i <= 31; i++){
        long long c2 = ((mark >> i) & 1ll);
        if(!c2) {res3 |= (1ll << i); break;}
    }

    long long dis1 = abs(res1 - rem), dis2 = abs(rem - res2), dis3 = abs(rem - res3);
    if(dis1 == min({dis1, dis2, dis3})) return {res1, mark};
    if(dis2 == min({dis1, dis2, dis3})) return {res2, mark};
    return {res3, mark};
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

//    freopen("input.txt", "r", stdin);

    int t, n, k;
    cin >> t;
    while (t--) {
        long long x, y;
        cin >> x >> y;
        pair<long long,long long> ans1 = calc(x, y);
        pair<long long,long long> ans2 = calc(y, x);
        swap(ans2.first, ans2.second);

        if(abs(ans1.first - x) + abs(ans1.second - y) < abs(ans2.first - x) + abs(ans2.second - y)){
            cout << ans1.first<<" "<<ans1.second<<'\n';
        }
        else cout << ans2.first<<" "<<ans2.second<<'\n';
    }

    return 0;
}
