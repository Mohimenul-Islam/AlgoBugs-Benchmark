#include <bits/stdc++.h>
using namespace std;
using ll = long long;

static const ll MOD = 998244353;
const ll maxn = 1e6;

const int N = 2e5 + 5;

ll qpow(ll x, ll k)
{
    ll res = 1;
    while (k)
    {
        if (k & 1)
            res *= x;
        x *= x;
        k >>= 1;
    }
    return res;
}

void solve()
{
    ll x, y;
    cin >> x >> y;
    // cout << "CE" << "\n";
    auto ch = [&](ll a, ll b) -> array<ll, 3>
    {
        ll q = 0, p = 0;
        q = a;
        if (a == 0 || b == 0)
        {
            return {a, b, 0};
        }
        int wq = log2(a) + 1;
        ll f = qpow(2, wq + 1) - 1;
        a = a ^ f;
        vector<int> s;
        for (int i = 0; i < wq; i++)
        {
            s.push_back(a & 1);
            a >>= 1;
        }
        int wp = log2(b) + 1;
        ll ans1 = b;
        ll ans2 = b;
        if (wp <= wq)
        {
            for (int i = 0; i < wp; i++)
            {
                if (s[i])
                    ans1 -= qpow(2, i), p += qpow(2, i);
            }
        }
        else
        {
            for (int i = wp - 1; i >= wq; i--)
            {
                if (ans1 >= qpow(2, i))
                {
                    ans1 -= qpow(2, i), p += qpow(2, i);
                }
            }
            for (int i = wq - 1; i >= 0; i--)
            {
                if (s[i] && ans1 >= qpow(2, i))
                {
                    ans1 -= qpow(2, i), p += qpow(2, i);
                }
            }
        }
        ll f1 = 0;
        bool changed = false;

        for (int i = wp - 1; i >= 0; i--)
        {
            if ((b >> i) & 1)
            {
                if (i < (int)s.size() && s[i] == 0)
                {
                    int j = i + 1;
                    while (true)
                    {
                        if ((j >= (int)s.size() || s[j] == 1) && (((b >> j) & 1) == 0))
                            break;
                        j++;
                    }
                    f1 = 0;
                    for (int k = wp - 1; k > j; k--)
                    {
                        if ((b >> k) & 1)
                            f1 += qpow(2, k);
                    }

                    f1 += qpow(2, j);

                    changed = true;
                    break;
                }
                else
                {
                    f1 += qpow(2, i);
                }
            }
        }

        if (!changed)
        {
            f1 = b;
        }

        ans2 = f1 - ans2;
        if (ans1 <= ans2)
            return {q, p, ans1};
        else
        {
            return {q, f1, ans2};
        }
    };
    auto [p1, q1, a1] = ch(x, y);
    auto [p2, q2, a2] = ch(y, x);
    if (a1 <= a2)
        cout << p1 << " " << q1 << "\n";
    else
        cout << q2 << " " << p2 << "\n";
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--)
        solve();
    return 0;
}