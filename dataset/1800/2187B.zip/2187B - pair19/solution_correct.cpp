#include <bits/stdc++.h>
using namespace std;
#define int long long

const int inf = numeric_limits<int>::max();

long long set0(long long x, int idx){
    for(int i = 0; i<32; i++){
        if(i < idx && (x&(1<<i))){
            x ^= (1<<i); //macht bit i aus
        }
    }
    x |= (1<<idx);
    return x;
}

long long set1(long long x, long long y, int idx){
    for(int i = 0; i<32; i++){
        if(i < idx && !(y&(1<<i))){
            x |= (1<<i); //macht bit i an
        }
    }
    if(x&(1<<idx)){
        x ^= (1<<idx);
    }
    return x;
}

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int t;
    cin>>t;
    while(t--){
        long long x,y;
        cin>>x>>y;
        long long res = inf;
        pair<int,int> r;

        long long nx = 0;
        long long ny = 0;
        if(abs(x-nx)+abs(y-ny) < res){
            r = {nx, ny};
            res = abs(x-nx)+abs(y-ny);
        }

        for(int i = 0; i<=31; i++){
            ny = y;
            nx = set0(x, i);
            if((ny&nx) == 0){
                if(abs(x-nx)+abs(y-ny) < res){
                    r = {nx, ny};
                    res = abs(x-nx)+abs(y-ny);
                }
            }
            nx = x;
            ny = set0(y, i);
            if((ny&nx) == 0){
                if(abs(x-nx)+abs(y-ny) < res){
                    r = {nx, ny};
                    res = abs(x-nx)+abs(y-ny);
                }
            }
            nx = set0(x, i);
            ny = set1(y, nx, i);
            if((ny&nx) == 0){
                if(abs(x-nx)+abs(y-ny) < res){
                    r = {nx, ny};
                    res = abs(x-nx)+abs(y-ny);
                }
            }
            ny = set0(y, i);
            nx = set1(x, ny, i);
            if((ny&nx) == 0){
                if(abs(x-nx)+abs(y-ny) < res){
                    r = {nx, ny};
                    res = abs(x-nx)+abs(y-ny);
                }
            }            
        }     

        // for(int i = 0; i<=31; i++){
        //     for(int j = 0; j<=31; j++){
        //         ny = set0(y, j);
        //         nx = set1(x, y, i);
        //         if((ny&nx) == 0){
        //             if(abs(x-nx)+abs(y-ny) < res){
        //                 r = {nx, ny};
        //                 res = abs(x-nx)+abs(y-ny);
        //             }
        //         }
        //         nx = set0(x, i);
        //         ny = set1(y, x, j);
        //         if((ny&nx) == 0){
        //             if(abs(x-nx)+abs(y-ny) < res){
        //                 r = {nx, ny};
        //                 res = abs(x-nx)+abs(y-ny);
        //             }
        //         }
        //     }
        // }  

        cout<<r.first<<" "<<r.second<<"\n";
    }
}