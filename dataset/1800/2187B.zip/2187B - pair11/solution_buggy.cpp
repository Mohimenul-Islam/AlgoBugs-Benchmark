#include <bits/stdc++.h>
using namespace std;

#define ll long long

long long findBit(long long x) {
        long long mm = 1;
        while(x > 0) {
            x /= 2;
            mm *= 2;
        }
        return mm;
}

long long test(ll x, ll y) {
    ll a = 0;
    for(ll c = findBit(y); c > 0; c /= 2) {
        if(!(x & c) && a + c <= y)
            a += c;
    }
    if(a == y)
        return y;

    ll b = (x ^ y) & y;
    ll ux = x & y;
    ll cant = ((findBit(y) - 1) ^ ux) & (findBit(y) - 1);
    ll pointer = 1;
    while(pointer <= cant || (pointer & b) || (pointer & x)) pointer *= 2;
    
    b = (b / pointer * pointer) + pointer;
    
    
    return abs(b - y) < abs(y - a) ? b : a;
}

int main() {
	cin.tie(nullptr);
    ios::sync_with_stdio(0);
    int cases;
    cin >> cases;
    while(cases--) {
        long long x, y;
        cin >> x >> y;
        
        long long bestx = x, besty = test(x, y);

        ll xtest = test(y, x);
        if(abs(x - xtest) < abs(y - besty)) {
            bestx = xtest;
            besty = y;
        }

        cout << bestx << " " << besty << "\n";
    }
}
