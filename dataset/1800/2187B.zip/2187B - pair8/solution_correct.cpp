#include <iostream>
#include <vector>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <algorithm>
#include <string>
#include <functional>
using namespace std;
typedef long long ll;
#define PLL pair<ll,ll>
#define fi first
#define se second 
const ll P=998244353;
void Refra1n()
{
    ll x,y;cin>>x>>y;
    if((x&y)==0){
        cout<<x<<' '<<y<<'\n';
        return;
    }
    ll ansy=0;
    for(ll i=0;i<=30;i++){
        ll temy=0;
        if(((1ll<<i)&y)){
            for(ll j=0;j<i;j++){
                if(((1ll<<j)&x)==0)temy+=(1ll<<j);
            }
            for(ll j=i+1;j<=30;j++){
                if(((1ll<<j)&y)&&((1ll<<j)&x)==0)temy+=(1ll<<j);
            }
        }
        if(llabs(ansy-y)>llabs(y-temy)){
            ansy=temy;
        }
    }
    for(ll i=0;i<=30;i++){
        ll temy=0;
        if(((1ll<<i)&y)==0&&((1ll<<i)&x)==0){
            temy+=(1ll<<i);
            for(ll j=i+1;j<=30;j++){
                if(((1ll<<j)&y)&&((1ll<<j)&x)==0)temy+=(1ll<<j);
            }
            if(llabs(ansy-y)>llabs(y-temy)){
                ansy=temy;
            }
        }
    }

    ll ansx=0;
    for(ll i=0;i<=30;i++){
        ll temx=0;
        if(((1ll<<i)&x)){
            for(ll j=0;j<i;j++){
                if(((1ll<<j)&y)==0)temx+=(1ll<<j);
            }
            for(ll j=i+1;j<=30;j++){
                if(((1ll<<j)&x)&&((1ll<<j)&y)==0)temx+=(1ll<<j);
            }
        }
        if(llabs(ansx-x)>llabs(x-temx)){
            ansx=temx;
        }
    }
    for(ll i=0;i<=30;i++){
        ll temx=0;
        if(((1ll<<i)&x)==0&&((1ll<<i)&y)==0){
            temx+=(1ll<<i);
            for(ll j=i+1;j<=30;j++){
                if(((1ll<<j)&x)&&((1ll<<j)&y)==0)temx+=(1ll<<j);
            }
            if(llabs(ansx-x)>llabs(x-temx)){
                ansx=temx;
            }
        }
    }

    if(llabs(x-ansx)<llabs(ansy-y)){
        cout<<ansx<<' '<<y<<'\n';
    }else{
        cout<<x<<' '<<ansy<<'\n';
    }
}

int main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);
    int t;cin>>t;
    while(t--)
    Refra1n();
    //cout<<"copyright Refra1n"<<endl;
    return 0;
}