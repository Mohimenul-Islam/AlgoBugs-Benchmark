#include <iostream>
#include <vector>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <algorithm>
#include <string>
#include <functional>
using namespace std;
typedef long long ll;
#define PLL pair<ll,ll>
#define fi first
#define se second 
const ll P=998244353;
ll lg(ll x) {return 63ll ^ __builtin_clzll(x);}
void Refra1n()
{
    ll x,y;cin>>x>>y;
    if(x==0||y==0){
        cout<<x<<' '<<y<<'\n';
        return;
    }
    
    ll temy=0;
    ll ansy=0;
    for(ll i=lg(y);i>=0;i--){
        if(((1ll<<i)&y)&&(((1ll<<i)&x)==0))temy+=(1ll<<i);
    }
    if(llabs(ansy-y)>llabs(y-temy)){
        ansy=temy;
    }
    for(ll i=0;i<=lg(y);i++){
        if((((1ll<<i)&temy)==0)&&(((1ll<<i)&x)==0))temy+=(1ll<<i);
        if(llabs(ansy-y)>llabs(y-temy)){
            ansy=temy;
        }
    }

    if((llabs((1<<(lg(y)+1))-y)<llabs(y-temy))&&(((1<<(lg(y)+1))&x)==0)){
        temy=(1<<(lg(y)+1));
    }
    if(llabs(ansy-y)>llabs(y-temy)){
        ansy=temy;
    }

    ll temx=0;
    ll ansx=0;
    for(ll i=lg(x);i>=0;i--){
        if(((1ll<<i)&x)&&(((1ll<<i)&y)==0))temx+=(1ll<<i);
    }
    if(llabs(ansx-x)>llabs(x-temx)){
        ansx=temx;
    }
    for(ll i=0;i<=lg(x);i++){
        if(((1ll<<i)&temx==0)&&(((1ll<<i)&y)==0))temx+=(1ll<<i);
        if(llabs(ansx-x)>llabs(x-temx)){
            ansx=temx;
        }
    }
    if((llabs((1<<(lg(x)+1))-x)<llabs(y-temx))&&(((1<<(lg(x)+1))&y)==0)){
        temx=(1<<(lg(x)+1));
    }
    if(llabs(ansx-x)>llabs(x-temx)){
        ansx=temx;
    }
    //cout<<temx<<' '<<temy<<'\n';

    if(llabs(x-ansx)<llabs(ansy-y)){
        cout<<ansx<<' '<<y<<'\n';
    }else{
        cout<<x<<' '<<ansy<<'\n';
    }

}

int main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);
    int t;cin>>t;
    while(t--)
    Refra1n();
    //cout<<"copyright Refra1n"<<endl;
    return 0;
}