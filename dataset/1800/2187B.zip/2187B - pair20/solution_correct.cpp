#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const ll mod = 998244353;

pair<ll,ll> check(ll x, ll y){
  ll aux = (1LL<<31) - 1;
  for(int i = 0; i < 31 ; i++){
    if(y & (1LL<<i)){
      aux -= (1LL<<i);
    }
  }
  ll more = aux, les = 0;
  for(int i = 30; i >= 0; i--){
    if((aux & (1LL<<i)) == 0)continue;
    if(more - (1LL<<i) >= x){
      more -= (1LL<<i);
    }
    if(les + (1LL<<i) <= x){
      les+=(1LL<<i);
    }
  }
  if(more - x < x - les){
    assert(more < (1LL<<31));
    return {more,y};
  }
  else{
    assert(les < (1LL<<31));
    return {les,y};
  }
}
void solve(){
  ll x, y;
  cin>>x>>y;
  auto p = check(x,y);
  auto q = check(y,x);
  swap(q.first,q.second);
  ll aux1 = abs(x - p.first) + abs(y - p.second);
  ll aux2 = abs(x - q.first) + abs(y - q.second);
  if(aux1 < aux2){
    cout<<p.first<<" "<<p.second<<endl;
  }
  else{
    cout<<q.first<<" "<<q.second<<endl;
  }
}

int main(){
  ios_base::sync_with_stdio(false);  cin.tie(0);  cout.tie(0);
  int t;cin>>t;
  while(t--){
    solve();
  }
}