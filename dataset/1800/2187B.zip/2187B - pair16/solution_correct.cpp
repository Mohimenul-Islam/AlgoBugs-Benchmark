#include <bits/stdc++.h>
#include <ranges>
#ifndef debug  
#define _FREOPEN_
#define debug(...) void(0)
#endif  
using namespace std; 
using llong = long long;
inline bool cmax(auto &x, auto &&y){ if (x < y) { x = y; return true; } return false;} //
inline bool cmin(auto &x, auto &&y){ if (x > y) { x = y; return true; } return false;} //
struct range : ranges::view_base{ struct Iterator { using iterator_category = random_access_iterator_tag; using value_type = long long; using difference_type = ptrdiff_t;  llong val, d; Iterator() = default; Iterator(llong val, llong d) : val(val), d(d) {}; value_type operator*() const { return val; } Iterator &operator++() { return val += d, *this; } Iterator operator++(int) { Iterator tmp = *this; ++(*this); return tmp; } Iterator &operator--() { return val -= d, *this; } Iterator operator--(int) { Iterator tmp = *this; --(*this); return tmp; } difference_type operator-(const Iterator &other) const { return (val - other.val) / d; } bool operator==(const Iterator &other) const { return val == other.val; } }; Iterator Begin, End; range(llong n) : Begin(0, 1), End(max(n, llong{0}), 1) {}; range(llong a, llong b, llong d = llong(1)) : Begin(a, d), End(b, d) { llong cnt = b == a or (b - a > 0) != (d > 0) ? 0 : (b - a) / d + bool((b - a) % d); End.val = a + max(cnt, llong(0)) * d; }; Iterator begin() const { return Begin; } Iterator end() const { return End; }; ptrdiff_t size() const{ return End - Begin;}};//
template <typename T>concept INT248 = sizeof(T) >= 2 and is_integral_v<T>;namespace io {const int L = 1 << 16;char ibuf[L], *iS, *iT, c;char gc() { return iS == iT ? (iT = (iS = ibuf) + fread(ibuf, 1, L, stdin), (iS == iT ? ' ' : *iS++)) : *iS++; }void rd(INT248 auto &x) {int f;for (f = 1, c = gc(); c < '0' || c > '9'; c = gc())if (c == '-') f = -1;for (x = 0; c <= '9' && c >= '0'; c = gc())x = x * 10 + (c & 15);x *= f;}int rd7(){llong tmp;if(iT - iS < 8) { rd(tmp); return tmp;}tmp = *(llong*)iS;int dig = 68 - __builtin_ctzll(~tmp & 0x1010101010101010);tmp = tmp << dig & 0x0f0f0f0f0f0f0f0f;tmp = tmp * 10 +    (tmp >> 8)  & 0x00ff00ff00ff00ff;tmp = tmp * 100 +   (tmp >> 16) & 0x0000ffff0000ffff;tmp = tmp * 10000 + (tmp >> 32) & 0x00000000ffffffff;iS += 72 - dig >> 3;return tmp;}void rd(char &c) {while (isspace(c = gc()));}void rd(string &s) {while (isspace(c = gc()));for (s.clear(); not isspace(c); c = gc())s += c;}}; using io::rd7;
/* prt */ template <typename Tuple, typename F, size_t... N>void TupleCall(Tuple &t, F &&f, index_sequence<N...>) { (f(get<N>(t)), ...); }template <typename... Args>ostream &operator<<(ostream &out, const tuple<Args...> &t) {TupleCall(t, [&](auto &&a) { out << a << ' '; }, make_index_sequence<sizeof...(Args)>{});return out;}template <typename T1, typename T2>ostream &operator<<(ostream &out, const pair<T1, T2> &t) { return out << t.first << ' ' << t.second; }template <typename T>concept hasBegin = requires(T a) { a.begin(); };template <typename T>requires hasBegin<T> && (!is_same_v<string, T>)ostream &operator<<(ostream &out, const T &v) {for (auto &&x : v)out << x << ' ';return out;}template <char Seq, char End, bool Flush>struct Printer {ostream &out;Printer(ostream &_out) : out(_out) {}template <typename T, typename... Args>void operator()(const T &t, const Args &...args) {out << t;if constexpr (sizeof...(args)) {out << Seq;(*this)(args...);} else {out << End;if constexpr (Flush) out.flush();}}void operator=(const auto &t){ out << t << End;}};//
/* rd */ template <typename... Args>void tprd(tuple<Args...> &t){TupleCall(t, [&](auto &&a){ io::rd(a); }, make_index_sequence<sizeof...(Args)>{});}template <typename T = llong>auto rd(){T res;io::rd(res);return res;}template <typename T, int N>auto rd(){array<T, N> res;for (auto &x : res)io::rd(x);return res;}template <typename T1, typename T2, typename... Args>auto rd(){tuple<T1, T2, Args...> res;tprd(res);return res;}template <typename T = llong>auto rd(size_t n, size_t off = 0, size_t rest = 0){vector<T> v(off + n + rest);for (size_t i = off; i < off + n; ++i)io::rd(v[i]);return v;}template <typename T, int N>auto rd(size_t n, size_t off = 0, size_t rest = 0){vector<array<T, N>> v(off + n + rest);for (size_t i = off; i < off + n; ++i)for (auto &x : v[i])io::rd(x);return v;}template <typename T1, typename T2, typename... Args>auto rd(size_t n, size_t off = 0, size_t rest = 0){vector<tuple<T1, T2, Args...>> v(off + n + rest);for (size_t i = off; i < off + n; ++i)tprd(v[i]);return v;} //
Printer<' ', '\n', false> prt(cout);
void solution(); int main(){ 
    _FREOPEN_; int T = 1; 
    T = rd();  
    while( T-- ) solution(); return 0;
}; 
// ##########################################################################################

void solution(){  
    int x = rd(), y = rd(); 
    auto func = [&](llong x, llong y)->pair<llong,llong>{
        llong y1 = y, y2 = y;
        for(llong b = 1ll << 30; b ; b >>= 1){
            if(x & y1 & b) y1 -= b, y1 |= b - 1;
        }
        for(llong b = 1; b <= 1ll << 30; b <<= 1){
            if(x & y2 & b) y2 += b, y2 &= ~(b - 1);
        }
        llong d1 = abs(y1 - y);
        llong d2 = abs(y2 - y);
        return {min(d1,d2), d1 < d2 ? y1 : y2};
    };
    auto [d1, y2] = func(x, y);
    auto [d2, x2] = func(y, x);
    if(d1 < d2) prt(x, y2);
    else prt(x2, y);
    
}