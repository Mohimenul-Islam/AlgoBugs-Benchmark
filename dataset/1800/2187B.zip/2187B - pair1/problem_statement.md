# B. Shortest Statement Ever

**Time limit:** 2 seconds
**Memory limit:** 256 megabytes

## Problem Statement

You are given two non-negative integers $$$x$$$, $$$y$$$. Find two non-negative integers $$$p$$$ and $$$q$$$ such that $$$p\\;\\&\\;q=0$$$, and $$$|x-p|+|y-q|$$$ is minimized. Here, $$$\\&$$$ denotes the [bitwise AND operation](https://en.wikipedia.org/wiki/Bitwise_operation#AND).

## Input

Each test contains multiple test cases. The first line contains the number of test cases $$$t$$$ ($$$1 \\le t \\le 10^4$$$). The description of the test cases follows.

The only line of each test case contains two non-negative integers $$$x$$$ and $$$y$$$ ($$$0 \\le x,y \\lt 2^{30}$$$).

## Output

For each test case, output two non-negative integers $$$p$$$ and $$$q$$$ you found. If there are multiple pairs of $$$p$$$ and $$$q$$$ satisfying the conditions, you may output any of them.

It can be proven that under the constraints of the problem, any valid solution satisfies $$$\\max(p,q) \\lt 2^{31}$$$.

## Sample Tests

### Input
```
7
0 0
1 1
3 6
7 11
4 4
123 321
1073741823 1073741822
```

### Output
```
0 0
2 1
3 8
6 9
4 3
128 321
1073741824 1073741822
```

## Note

In the first test case, one valid pair would be $$$p=0$$$ and $$$q=0$$$, as $$$0\\,\\&\\,0=0$$$ and $$$|x-p|+|y-q|=|0-0|+|0-0|=0$$$ is the minimum over all pairs of $$$p$$$ and $$$q$$$.

In the third test case, one valid pair would be $$$p=3$$$ and $$$q=8$$$, as $$$3\\,\\&\\,8=0$$$ and $$$|x-p|+|y-q|=|3-3|+|8-6|=2$$$ is the minimum over all pairs of $$$p$$$ and $$$q$$$. Note that $$$(p,q)=(3,4)$$$ is also a valid pair.