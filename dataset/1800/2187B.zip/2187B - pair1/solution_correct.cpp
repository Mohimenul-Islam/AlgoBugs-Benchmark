#include<bits/stdc++.h>
#define inf 0x3f3f3f3f
#define Inf (1ll<<60)
#define For(i,s,t) for(int i=s;i<=t;++i)
#define Down(i,s,t) for(int i=s;i>=t;--i)
#define ls (i<<1)
#define rs (i<<1|1)
#define lowbit(x) ((x)&(-(x)))
#define End {printf("NO\n");exit(0);}
#define mp make_pair
#define pb push_back
#define ep emplace_back
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
inline void ckmx(int &x,int y){x=(x>y)?x:y;}
inline void ckmn(int &x,int y){x=(x<y)?x:y;}
inline void ckmx(ll &x,ll y){x=(x>y)?x:y;}
inline void ckmn(ll &x,ll y){x=(x<y)?x:y;}
inline int min(int x,int y){return x<y?x:y;}
inline int max(int x,int y){return x>y?x:y;}
inline ll min(ll x,ll y){return x<y?x:y;}
inline ll max(ll x,ll y){return x>y?x:y;}
#define gc() getchar()
#define read() ({\
    int x = 0, f = 1;\
    char c = gc();\
    while(c < '0' || c > '9') f = (c == '-') ? -1 : 1, c = gc();\
    while(c >= '0' && c <= '9') x = x * 10 + (c & 15), c = gc();\
    f * x;\
})
void write(int x){
    if(x>=10) write(x/10);
    putchar(x%10+'0');
}
const int N=2e5+100,p=998244353;
inline int bmod(int x){return x>=p ? x-p : x;}
inline void add(int &x,int y){x=bmod(x+y);}
inline int qpow(int x,int y){
    int res=1;
    for(;y;y>>=1,x=1ull*x*x%p)
        if(y&1)
            res=1ull*x*res%p;
    return res;
}
int n;
struct Node{ll x,y,ans;}q[20];
void solve(){
    ll x,y;
    x=read(),y=read();
    if(!(x&y)){
        printf("%d %d\n",x,y);
        return;
    }
    ll t=(x&y);
    while(t!=lowbit(t)) t-=lowbit(t);
    ll x1=x&(t-1),y1=y&(t-1);
    q[0]=Node{x+t-x1,y,abs(t-x1)};
    q[1]=Node{x,y+t-y1,abs(t-y1)};
    q[2]=Node{x-x1,y-y1-1,x1+y1+1};
    For(i,0,2)
        if(q[i].x&q[i].y)
            q[i].ans=Inf;
    sort(q,q+3,[](Node x,Node y){return x.ans<y.ans;});
    assert(!(q[0].x&q[0].y));
    printf("%lld %lld\n",q[0].x,q[0].y);
    cerr<<q[0].ans<<'\n';
}
int main()
{
// #if !ONLINE_JUDGE
//     freopen("test.in","r",stdin);
//     freopen("test.out","w",stdout);
// #endif 
    int T=1;
    T=read();
    while(T--) solve();
    return 0;
}