#include <bits/stdc++.h>

using i64 = long long;

void solve() {
    int x, y;
    std::cin >> x >> y;

    int ans = x + y, p = 0, q = 0;
    for (int i = 0; i < 31; i++) {
        for (int j = 0; j < 31; j++) {
            int a = x >> i << i;
            int b = y >> j << j;
            for (auto P : {a, a + (1 << i), a + (1 << i) - 1}) {
                for (auto Q : {b, b + (1 << j), b + (1 << j) - 1}) {
                    Q -= P & Q;
                    int dis = std::abs(x - P) + std::abs(y - Q);
                    if (dis < ans) {
                        ans = dis;
                        p = P;
                        q = Q;
                    }
                }
            }
        }
    }

    std::cout << p << " " << q << "\n";
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    
    int t;
    std::cin >> t;

    while (t--) {
        solve();
    }
    
    return 0;
}