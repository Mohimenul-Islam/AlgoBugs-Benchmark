#include<bits/stdc++.h>
using namespace std;

#define int long long 

int X,Y;
pair<int,int>ans;
int res;

void getDiff(int x, int y) {
  int p1 = x;
  int missed = 0;
  int p2 = 0;
  int px = -1;
  for(int i = 31 ; i >= 0 ; i--) {
    if((x & (1LL << i)) && (y & (1LL << i)) && !(missed)) {
        missed = 1;
        px = i+1;
    }
    if(!(x & (1LL << i)) && (y & (1LL << i))) {
        p2 += (1LL << i);
    } else if(missed && !(x & (1LL << i))) {
        p2 += (1LL << i);
    }
  }
  if(abs(X - p1) + abs(Y - p2) < res) {
    ans = {p1,p2};
    res = abs(X - p1) + abs(Y - p2);
  }
  if(abs(Y - p1) + abs(X - p2) < res) {
    ans = {p2,p1};
    res = abs(Y - p1) + abs(X - p2);
  }
//   cout << ans.first << ' ' << ans.second << '\n';
//   cout << p1 << ' ' << p2 << '\n';
//   cout << res << '\n';
  for(int j = 33 ; j >= 0 ; j--) {
    if(!(p1 & (1LL << j))) {
        int np = (1LL << j);
        if(abs(p1 - X) + abs(np - Y) < res) {
            res = abs(p1 - X) + abs(np - Y);
            ans = {p1,np};
        }
        if(abs(X - np) + abs(p1 - Y) < res) {
            res = abs(X - np) + abs(p1 - Y);
            ans = {np,p1};
        }
        np = (p2 | (1LL << j));
        // if(j == 27) {
        //    cout << np << ' ' << p2 << ' '  << "FOUND IT\n";
        // }
        if(abs(p1 - X) + abs(np - Y) < res) {
            res = abs(p1 - X) + abs(np - Y);
            ans = {p1,np};
        }
        if(abs(X - np) + abs(p1 - Y) < res) {
            res = abs(X - np) + abs(p1 - Y);
            ans = {np,p1};
        }
        for(int k = j-1 ; k >= 0 ; k--) {
            if((np & (1LL << k))) {
                np ^= (1LL << k);
            }
        }
        if(abs(p1 - X) + abs(np - Y) < res) {
            res = abs(p1 - X) + abs(np - Y);
            ans = {p1,np};
        }
        if(abs(X - np) + abs(p1 - Y) < res) {
            res = abs(X - np) + abs(p1 - Y);
            ans = {np,p1};
        }
    }
  }
//     if(p1 == 9980291) {
//     cout << ans.first << ' ' << ans.second << ' ' << "PEHLA ANSWER\n";
//     cout << res << '\n';
//   }
//   int curr = min(abs(X - p1) + abs(Y - p2) , abs(Y - p1) + abs(X - p2));
// //   cout << curr << '\n';

// //   cout << p1 << ' ' << p2 << '\n';
//   curr = min(curr , min(abs(X - p1) + abs(Y - p2) , abs(Y - p1) + abs(X - p2)));
//   return curr;
     
}

signed main() {
 int tt;
 cin >> tt;
 int test = 1;
 while(tt--) {
  res = 1e15;
  cin >> X >> Y;
  getDiff(X,Y);
  int res1 = res;

//   int p1 = ans.first;
//   int p2 = ans.second;

  getDiff(Y,X);
  int res2 = res;
//   cout << res << '\n';
  cout << ans.first << ' ' << ans.second << '\n';
// //   cout << res1 << ' ' << res2 << '\n';
    // cout << abs(ans.first - X) + abs(ans.second - Y) << '\n';
    // cout << ans.first << ' ' << ans.second << '\n';
    // test++;
//   cout << res1 << ' ' << res2 << '\n';
//   getDiff(Y,X);
//   cout << res << '\n';
//   swap(x,y);
//   cout << abs(x-p) + abs(q-y) << '\n';
//   if(x < y) {
//     swapped = 1;
//     swap(x,y);
//   }
//   cout << min(getDiff(X,Y),getDiff(Y,X)) << '\n';
//   cout << abs(p1 - x) + abs(p2 - y) << '\n';
//   if(!swapped) {
//    cout << p1 << ' ' << p2 << '\n';
//   } else {
//     cout << p2 << ' ' << p1 << '\n';
//   }
 }
}