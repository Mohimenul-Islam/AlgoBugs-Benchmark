#include<bits/stdc++.h>
using namespace std;
using ull=unsigned long long;
using ll=long long;
using lll=__int128_t;
using ld=long double;
using pll=pair<ll,ll>;
using pld=pair<ll,ld>;
#define pb push_back
#define lb(x) (x&(-x))
#define mod(a,b) ((a-1)%b+1)
#define nl '\n'
#define all(x) x.begin(),x.end()
#define ALL(x) x.begin()+1,x.end()
const ll N=2e5,M=1e6,mod=1e9+7,MOD=998244353,INF=1e18,base=499;
const ld eps=1e-7,ph=0.618,pi=3.1415926,one=1.00;

inline void solve(){
    ll x,y,mn=INF,p,q;
    cin>>x>>y;
    auto f=[&](ll l,ll r)->void{
        if((l&r)==0&&abs(l-x)+abs(r-y)<mn)
            mn=abs(l-x)+abs(r-y),
            p=l,q=r;
    };
    f(x,y);
    for(ll col=32;~col;col--)
        if(x&y&1ll<<col)
            f((x>>col<<col)+(1ll<<col) , y),
            f(x , (y>>col<<col)+(1ll<<col)),
            f(x>>col<<col , (y>>col<<col)-1),
            f((x>>col<<col)-1 , y>>col<<col);
    cout<<p<<" "<<q<<nl;
}    

signed main(){
	cin.tie(nullptr)->sync_with_stdio(false);
	ll _=1;
	cin>>_;
	while(_--)
		solve();
	return 0;
}