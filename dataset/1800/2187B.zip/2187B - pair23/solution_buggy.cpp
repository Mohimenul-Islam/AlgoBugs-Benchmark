#include<bits/stdc++.h>
using namespace std;
using ull=unsigned long long;
using ll=long long;
using lll=__int128_t;
using ld=long double;
using pll=pair<ll,ll>;
using pld=pair<ll,ld>;
#define pb push_back
#define lb(x) (x&(-x))
#define mod(a,b) ((a-1)%b+1)
#define nl '\n'
#define all(x) x.begin(),x.end()
#define ALL(x) x.begin()+1,x.end()
const ll N=2e5,M=1e6,mod=1e9+7,MOD=998244353,INF=1e18,base=499;
const ld eps=1e-7,ph=0.618,pi=3.1415926,one=1.00;

pll f(ll x,ll y){
    ll p=x,q,l=0,r=0,f=0,t=y;
    for(ll col=31;~col;col--){
        ll cur=1ll<<col;
        if(y&1ll<<col)
            f=1;
        if(x&cur)
            continue;
        if(!f)
            continue;
        if(y&1ll<<col)
            r|=cur;
        if(abs(y-(r|cur))<abs(y-r))
            r|=cur;
    }
    while(t){
        if(t==lb(t)){
            if(x&t<<1)
                break;
            l=t<<1;
        }
        t-=lb(t);
    }
    if(abs(y-l)<abs(y-r))
        q=l;
    else
        q=r;
    return {p,q};
}

inline void solve(){
    ll x,y;
    cin>>x>>y;
    ll a,b,c,d;
    pll l=f(x,y),r=f(y,x);
    a=l.first,b=l.second,c=r.second,d=r.first;
    if(abs(x-a)+abs(y-b)>abs(x-c)+abs(y-d))
        cout<<c<<" "<<d<<nl;
    else
        cout<<a<<" "<<b<<nl;
}    

signed main(){
	cin.tie(nullptr)->sync_with_stdio(false);
	ll _=1;
	cin>>_;
	while(_--)
		solve();
	return 0;
}