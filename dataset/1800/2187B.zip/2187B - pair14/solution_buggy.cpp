#include <bits/stdc++.h>
#define int long long
using namespace std;
int m,p,q,x,y;
void tryi(int a,int b){
    if((a&b)==0&&abs(x-a)+abs(y-b)<m){
        m=abs(x-a)+abs(y-b);
        p=a,q=b;
    }
    swap(a,b);
    if((a&b)==0&&abs(x-a)+abs(y-b)<m){
        m=abs(x-a)+abs(y-b);
        p=a,q=b;
    }
}
signed main() {
    cin.tie(0)->sync_with_stdio(0);
    int Q;
    cin>>Q;
    while(Q--){
        cin>>x>>y;
        m=1e18;
        tryi(x, y);
        for (int i=30;i--;) {
            if((x&y)>>i&1){
                tryi((x>>i<<i)+(1ll<<i),y);
                tryi((x>>i<<i)-1,y>>i<<i);
            }
        }
        cout<<p<<' '<<q<<'\n';
    }
}