#include <bits/stdc++.h>
using namespace std;

// Muito cuidado por aqui ↓
//#define int long long
#define pb push_back
#define f first
#define s second
#define all(v) v.begin(), v.end()
#define dbg(v) cerr << #v << " = " << v << "\n"
#define fall(i, s, n) for(int i=s; i<n; i++)
#define rfall(i, s, n) for(int i=s; i>=n; i--)

typedef pair<int, int> pii;
typedef tuple<int, int, int> trio;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

const int lg = 30;

bool on(int b, int n){ return ((1<<b)&n); }

int32_t main(){
    ios::sync_with_stdio(0); cin.tie(0);

    int tt; cin >> tt;

    while(tt--){
        int x, y; cin >> x >> y;

        if((x&y) == 0){ cout << x << " " << y << "\n"; continue; }

        int x0=0, y0=0;
        int p=-1, q=-1;
        int mn=(1ll<<31)-1;

        int msb = 31-__builtin_clz(x&y);
        int k = (1<<msb);

        rfall(i, lg-1, msb+1){
            if(on(i, x)) x0 += (1<<i);
            if(on(i, y)) y0 += (1<<i);
        }

        if(mn > x+y-(x0+k + y0+k-1)) mn = x+y-(x0+k + y0+k-1), p = x0+k, q = y0+k-1;
        
        if(!on(msb+1, x) && !on(msb+1, y)){
            if(mn > 2*k+x0-x) mn = 2*k+x0-x, p = x0+2*k, q = y;
            if(mn > 2*k+y0-y) mn = 2*k+y0-y, p = x, q = y0+2*k;
        }else{
            if(on(msb+1, y)) swap(x, y);

            int b = y0+2*k, a = x0;

            fall(i, msb, lg){
                if(on(i, a) && on(i, b)) a += (1<<i);
                else break;
            }

            if(mn > abs(x-a)+abs(y-b)) p=a, q=b;
        }

        cout << p << " " << q << "\n";
    }
}