#include <bits/stdc++.h>
using namespace std;

// Muito cuidado por aqui ↓
#define int long long
#define pb push_back
#define f first
#define s second
#define all(v) v.begin(), v.end()
#define dbg(v) cerr << #v << " = " << (v) << "\n"
#define fall(i, s, n) for(int i=s; i<n; i++)
#define rfall(i, s, n) for(int i=s; i>=n; i--)

typedef pair<int, int> pii;
typedef tuple<int, int, int> trio;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

const int lg = 31;

bool on(int b, int n){ return ((1<<b)&n); }

pii operator+(pii a, pii b){
    return {a.f+b.f, a.s+b.s};
}

int32_t main(){
    ios::sync_with_stdio(0); cin.tie(0);

    int tt; cin >> tt;

    while(tt--){
        int x, y; cin >> x >> y;

        int dp[lg+1][3][3]; 
        pii ans[lg+1][3][3]; 
        
        fall(i, 0, lg+1)
        fall(j, 0, 3)
        fall(u, 0, 3) dp[i][j][u]=1e15, ans[i][j][u]={0, 0};
        
        dp[lg][1][1]=0;

        // 0: p < x
        // 1: p == x
        // 2: p > x

        rfall(j, lg-1, 0){
            fall(tx, 0, 3) fall(ty, 0, 3){
                fall(qx, 0, 3) fall(qy, 0, 3){
                    if(((qx == 0 || qx == 2) && tx != qx) || ((qy == 0 || qy == 2) && ty != qy)) continue;

                    int p=-1, q=-1;

                    if(qx == 1){
                        if(tx == 2){
                            p = (1<<j);

                            if(on(j, x)) continue;
                        }if(tx == 1) p = (1<<j)&x;
                        if(tx == 0){
                            p = 0;

                            if(!on(j, x)) continue;
                        }
                    }else if(tx == 2) p=0;

                    if(qy == 1){
                        if(ty == 2){
                            q = (1<<j);

                            if(on(j, y)) continue;
                        }if(ty == 1) q = (1<<j)&y;
                        if(ty == 0){
                            q = 0;

                            if(!on(j, y)) continue;
                        }
                    }else if(ty == 2) q=0;

                    if(p == -1){
                        if(q > 0) p=0;
                        else p=(1<<j);
                    }

                    if(q == -1){
                        if(p > 0) q=0;
                        else q=(1<<j);
                    }

                    if(p > 0 && q > 0) continue;

                    int dif=0;

                    if(tx <= 1) dif += ((1<<j)&x)-p;
                    else dif += p-((1<<j)&x);

                    if(ty <= 1) dif += ((1<<j)&y)-q;
                    else dif += q-((1<<j)&y);

                    if(dp[j][tx][ty] > dp[j+1][qx][qy] + dif){
                        dp[j][tx][ty] = dp[j+1][qx][qy] + dif;

                        ans[j][tx][ty] = ans[j+1][qx][qy] + pair(p, q);
                    }
                }
            }
        }

        int mn=1e15;
        int p=0, q=0;

        fall(i, 0, 3)
        fall(j, 0, 3) if(mn > dp[0][i][j]){
            mn = dp[0][i][j];

            pii best = ans[0][i][j];

            p=best.f, q=best.s;
        }

        cout << p << " " << q << "\n";
    }
}