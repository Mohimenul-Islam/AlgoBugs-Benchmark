#include<bits/stdc++.h>
using namespace std;
using  ll=long long;
unsigned long long next_power_of_two(unsigned long long x) {
    if (x <= 1) return 1;
    x--;
    x|=x>>1;
    x|=x>>2;
    x|=x>>4;
    x|=x>>8;
    x|=x>>16;
    x|=x>>32;
    return x + 1;
}
bool isPowerOfTwo(unsigned long long n) {
    return n>0&&(n&(n-1))==0;
}
void solve(ll t){
  vector<pair<ll,ll>>ans(3);
  unsigned long long x,y;
  cin>>x>>y;
    //if (t==10000-212){cout<<x<<y<<"t"<<endl;return;}
   if (x==0||y==0){cout<<x<<" "<<y<<endl;return;}
  if(x==y&&isPowerOfTwo(x)&&isPowerOfTwo(y)) {
      cout<<x<<" "<<x-1<<endl;
      return;
  }
  unsigned long long x1=x;
  unsigned long long y1=y;
  x1&=~y1;
  ans[0]={x1,y1};
  unsigned long long x2=x;
  unsigned long long y2=y;
  unsigned long long x_nxt=next_power_of_two(x2);
  unsigned long long y_nxt=next_power_of_two(y2);
      //cout<<x_nxt<<" "<<y_nxt<<endl;
  y2&=(~x_nxt);
  ans[1]={x_nxt,y2};
  //cout<<x_nxt<<" "<<y2<<endl;
  x2&=(~y_nxt);
  ans[2]={x2,y_nxt};
        //cout<<x2<<" "<<y_nxt<<endl;
  long long cur_min=abs((ll)ans[0].first-(ll)x)+abs((ll)ans[0].second-(ll)y);
        //cout<<cur_min;
  pair<ll,ll>ansf={ans[0].first,ans[0].second};
  for (ll i=1;i<3;i++) {
    ll temp=abs((ll)ans[i].first-(ll)x)+abs((ll)ans[i].second-(ll)y);
    if(temp<cur_min) {
        cur_min=temp;
        ansf={ans[i].first,ans[i].second};
    }
  }
  if(x-1>0&&((x-1&y)==0)&&cur_min>0) {
      cout<<x-1<<" "<<y<<endl;
      return;
  }
  if(y-1>0&&((y-1&x)==0)&&cur_min>0) {
      cout<<x<<" "<<y-1<<endl;
      return;
  }
    if(((y+1&x)==0)&&cur_min>0) {
        cout<<x<<" "<<y+1<<endl;
        return;
    }
    if(((x+1&y)==0)&&cur_min>0) {
        cout<<x+1<<" "<<y<<endl;
        return;
    }
  cout<<ansf.first<<" "<<ansf.second<<endl;
 }
int main(){
 ll t;
 cin>>t;
 while(t--){
   solve(t);
 }
}