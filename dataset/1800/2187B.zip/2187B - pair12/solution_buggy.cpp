#include <bits/stdc++.h>

using namespace std;
using ll = long long;

const int LEN = 5e5 + 10;
const ll INF = 1e18 + 7;
const ll MOD = 676767677;

pair <ll, ll> get(ll x, ll y) {
    ll p = x, q;
    for (int i = 0; i <= 30; ++i) {
        if (!(x & (1ll << i)) and (1ll << i) >= y) {
            q = (1ll << i);
            break;
        }
    }
    ll now = 0;
    ll pref = 0;
    for (int i = 0; i <= 30; ++i) {
        if ((y & (1ll << i))) {
            if (!(x & (1ll << i))) now += (1ll << i);
            else {
                now += pref;
                pref = 0;
            }
        }
        else if (!(x & (1ll << i))) pref += (1ll << i);
    }
    if (abs(q - y) > abs(now - y)) q = now;
    return {p, q};
}

void solve() {
    ll x, y; cin >> x >> y;
    pair <ll, ll> p1, p2;
    p1 = get(x, y);
    p2 = get(y, x);
    swap(p2.first, p2.second);
    if (abs(p1.first - x) + abs(p1.second - y) <= abs(p2.first - x) + abs(p2.second - y)) cout << p1.first << " " << p1.second << "\n";
    else cout << p2.first << " " << p2.second << "\n";
}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int tt = 1;
    cin >> tt;
    while (tt--) solve();
}