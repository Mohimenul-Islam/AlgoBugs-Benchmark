#include <bits/stdc++.h>
using namespace std;
/**********************************************************/
#define fastio ios_base::sync_with_stdio(false);cin.tie(0); cout.tie(0)
#define ff first
#define ss second
typedef long long ll;

// const ll mod=998244353;
const ll mod=1e9 +7;

void printv(vector<ll> &v){for(auto &n:v){cout<<n<<" ";}cout<<'\n';}
void prints(set<ll> &s){for(auto &n:s){cout<<n<<" ";}cout<<'\n';}
void printms(multiset<ll> &s){for(auto &n:s){cout<<n<<" ";}cout<<'\n';}

ll bin_expo(ll a,ll b){if (b==0){return 1;}else if (b==1){return a%mod;}if (b%2==0){ll p=bin_expo(a,b/2);return (p*p)%mod;}else{ll p=bin_expo(a,b/2);return ((((p*p)%mod)*a)%mod);}}

ll inv(ll n){return (bin_expo(n,mod-2));}

ll gcd(ll a,ll b){if(b==0){return a;}return gcd(b,a%b);}


//Sieve (Do not run in Global scope)
/*
ll N=1e5+5;vector<ll> prime(N,1);prime[1]=0;prime[0]=0;vector<ll> primes;for(ll i=2;i<N;i++){if(prime[i]){primes.push_back(i);for(ll j=i*i;j<N;j+=i){prime[j]=0;}}}
*/

//SPF (Do not run in Global scope)
/*
ll N=1e5+5;vector<ll> spf(N);for(ll i=0;i<N;i++){spf[i]=i;}for(ll i=2;i<N;i++){if(spf[i]==i){for(ll j=i*i;j<N;j+=i){if(spf[j]==j){spf[j]=i;}}}}
*/

//Combinatorics (Do not run in Global scope)
/*
ll c(ll a,ll b){if(b>a||b<0){return 0;} return (((fact[a]*invfact[b])%mod)*invfact[a-b])%mod;}
vector<ll> fact(N);fact[0]=1;for(ll i=1;i<N;i++){fact[i]=(i*fact[i-1])%mod;}
vector<ll> invfact(N);invfact[N-1]=inv(fact[N-1]);for(ll i=N-1;i>=1;i--){invfact[i-1]=(i*invfact[i])%mod;}
*/

/**********************************************************/
#define endl '\n' //REMOVE FOR INTERACTIVE



int main(){

	/*
	freopen("input.txt", "r", stdin);		//FILE READ [MHC OR SIMILAR]
	freopen("output.txt", "w", stdout);		//FILE WRITE [MHC OR SIMILAR]
	*/

	fastio;//REMOVE FOR INTERACTIVE
	
	/*
	either x reamins same or y remains same
	
	if x remains same,
	find the number z closest to y s.t. x&z=0
	consider z>=y and z<=y both
	
	same for if y remains same
	*/
	
	ll t;
	cin>>t;
	while(t--){
		ll x,y;
		cin>>x>>y;
		// x remains same,
		// finding z<=y
		ll z1=y;
		ll intersect1=x&y;
		z1^=(intersect1);
		for(ll i=0;i<31;i++){
			if(((x>>i)&1)==0 && (z1|(1<<i))<=y){
				z1|=(1<<i);
			}
		}
		ll mi1=abs(y-z1);
		ll a1=x,b1=z1;
		// finding z>=y
		ll z3=y;
		z3^=(intersect1);
		for(ll i=0;i<31;i++){
			if((((x>>i)&1)==0) && (z3|(1<<i))>y){
				z3|=(1<<i);
				break;
			}
			else{
				z3|=(1<<i);
				z3^=(1<<i);
			}
		}
		ll mi3=abs(y-z3);
		ll a3=x,b3=z3;
		// y remains same,
		// finding z<=x
		ll z2=x;
		ll intersect2=x&y;
		z2^=(intersect2);
		for(ll i=0;i<31;i++){
			if(((y>>i)&1)==0 && (z2|(1<<i))<=x){
				z2|=(1<<i);
			}
		}
		ll mi2=abs(x-z2);
		ll a2=z2,b2=y;
		//finding z>=x
		ll z4=x;
		z4^=(intersect2);
		for(ll i=0;i<31;i++){
			if((((y>>i)&1)==0) && (z4|(1<<i))>x){
				z4|=(1<<i);
				break;
			}
			else{
				z4|=(1<<i);
				z4^=(1<<i);
			}
		}
		ll mi4=abs(x-z4);
		ll a4=z4,b4=y;
		
		ll finmin=min(min(mi1,mi2),min(mi3,mi4));
		if(finmin==mi1){
			cout<<a1<<" "<<b1<<endl;
		}
		else if(finmin==mi2){
			cout<<a2<<" "<<b2<<endl;
		}
		else if(finmin==mi3){
			cout<<a3<<" "<<b3<<endl;
		}
		else if(finmin==mi4){
			cout<<a4<<" "<<b4<<endl;
		}
	}
}





