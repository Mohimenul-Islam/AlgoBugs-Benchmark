#include <bits/stdc++.h>
#ifndef ONLINE_JUDGE
#include "debug.h"
#else
#define debug(...)
#endif
using namespace std;
#define int long long
#define sz(x) ((int)(x).size())
#define all(v) v.begin(), v.end()

void solve(){
    int p,q;cin>>p>>q;
    int a = 0 , b = 0;
    for(int i = 31 ; i>=0 ; i--){
        int x = 1LL<<i;
        if((p&x) && !(q&x)){
            a += x;
        }else if((q&x) && !(p&x)){
            b += x;
        }else if((q&x) && (p&x)){
            vector<pair<int,int>> v = {{a+x-1,b+x} , {a+x , b+x-1}};
            if(!((a+2*x)&q))v.push_back({a+2*x , q});
            if(!((b+2*x)&p))v.push_back({p , b+2*x});
            int ba = 0 ,bb = 0;
            for(auto &i:v){
                if(abs(p-i.first) + abs(q - i.second) < abs(p-ba)+abs(q-bb)){
                    ba = i.first , bb = i.second;
                }
            }
            cout<<ba<<" "<<bb<<endl;
            return;
        }
    }
    cout<<p<<" "<<q<<endl;
}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int T=1;
    cin>>T;
    while(T--){
        solve();
    }
}