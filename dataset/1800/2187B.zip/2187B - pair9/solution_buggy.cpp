#include <bits/stdc++.h>
#ifndef ONLINE_JUDGE
#include "debug.h"
#else
#define debug(...)
#endif
using namespace std;
#define int long long
#define sz(x) ((int)(x).size())
#define all(v) v.begin(), v.end()

pair<int,int> sol(int a , int b){
    int borg = b;
    int p = a , q1 = 0;
    int q2 = 1<<( 63-__builtin_clzll(b-1)+1);
    if((q2 & a) != 0)q2 = 0;

    for(int i =  30 ; i>=0 ; i--){
        int num = 1<<i;
        if(num <= b && (num & p) == 0){
            // debug(num);
            q1 += num;
            b -= num;
        }
    }
    // debug(q1,q2);
    if(abs(q1-borg) > abs(q2-borg))return{p, q2};
    else return {p,q1};
}

void solve(){
    int a,b;
    cin>>a>>b;
    
    auto [p1,q1] = sol(a,b);
    auto [q2,p2] = sol(b,a);

    // cout<<p1<<q1<<endl;
    if(abs(a-p1) + abs(b-q1) <= abs(a-p2) + abs(b-q2)){
        cout<<p1<<" "<<q1<<endl;
    }else cout<<p2<<" "<<q2<<endl;


}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int T=1;
    cin>>T;
    while(T--){
        solve();
    }
}