#include <iostream>
#include<iterator>
#include<bits/stdc++.h>
using namespace std;


#define ll long long
#define vi vector<int>
#define vb vector<bool>
#define vll vector<long long>
#define vvi vector<vector<int> >
#define vvll vector<vector<ll> >
#define pii pair<int,int>
#define pll pair<ll,ll>
#define vpii vector<pair<int,int> >
#define vpll vector<pair<ll ,ll> >
#define mpii map<int,int>
#define mpll map<ll,ll>
#define all(x) x.begin(),x.end()
#define fri1(i,a,b) for(int i=a;i<b;i++)
#define fri2(i,a,b) for(int i=a;i<=b;i++)
#define frl1(i,a,b) for(ll i=a;i<b;i++)
#define frl2(i,a,b) for(ll i=a;i<=b;i++)
#define o1(x) cout << x << " "
#define o2(x) cout<<x<<"\n"
#define pb push_back
#define pf push_front
#define f first
#define s second
#define yep cout<<"Yes"<<"\n"
#define nope cout<<"No"<<"\n"
const int N=1e5+5;
const  long long mod=1e9+7;
//const  long long mod=998244353;

// #include <ext/pb_ds/assoc_container.hpp>
// #include <ext/pb_ds/tree_policy.hpp>
// #include <functional> // Required for std::less_equal

// using namespace __gnu_pbds;

// // Define an ordered multiset template
// template<typename T>
// using ordered_multiset = tree<T, null_type, std::less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>;

// GAME ON //


void fun(ll &p,ll &q,ll x,ll y){
  for(int i=29;i>=0;i--){
    if(x&(1ll<<i)){
      p=(1ll<<(i+1));
      break;
    }
  }
  if(p==0)p=1;
  if((x&(x-1))==0)p=x;
  for(int i=29;i>=0;i--){
    if(!(p&(1ll<<i)) and (1ll<<i)<=y){
      q|=(1ll<<i);
      y-=(1ll<<i);
    }
  }
}



void solve()
{
  ll x,y;
  cin>>x>>y;
  ll ans=(1ll<<32);
  
  ll p=0,q=0;

  ll an=x&y;
  ll xr=x^y;
  for(int i=0;i<30;i++){
    if(xr&(1ll<<i)){
      if(x&(1ll<<i))p|=(1ll<<i);
      else q|=(1ll<<i);
    }
  }
  p+=an;
  ans=min(ans,abs(p-x)+abs(q-y));
  //o1(p);o1(q);o2(ans);
  
  ll t1=0,t2=0;
  
  fun(t1,t2,x,y);
  ll t=abs(x-t1)+abs(y-t2);
  //o1(t1);o1(t2);o2(t);
  if(t<ans){
    ans=t;
    p=t1;
    q=t2;
  }

  t1=0,t2=0;
  fun(t2,t1,y,x);
  t=abs(x-t1)+abs(y-t2);
  //o1(t1);o1(t2);o2(t);
  if(t<ans){
    ans=t;
    p=t1;
    q=t2;
  }
  
  
  for(int i=29;i>=0;i--){
    if(x&(1ll<<i)){
      t1=(1ll<<(i+1));
      break;
    }
  }
  if(t1==0)t1=1;

  if((t2&t1)==0){
    t=abs(x-t1)+abs(y-t2);
    //o1(t1);o1(t2);o2(t);
    if(t<ans){
    ans=t;
    p=t1;
    q=t2;
    }
  }

  o1(p);
  o2(q);

  
}
 



int main()
{ 
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  
  int _=1;
  cin>>_;
  
  while(_--)
  {
    solve();
  }
  
  return 0;
}



// void dfs(int root,vvi &adj,vector<bool>&vis,vi &lvl,vvi &mat){
//   vis[root]=1;
//      int x=v[0][2];
 //for(auto it:adj[root]){
//     if(!vis[it]){
//       lvl[it]=lvl[root]+1;
//       mat[it][0]=root;
//       dfs(it,adj,vis,lvl,mat);
//     }
//   }
// }


//    FINDING  MAX   DISTANCE


// int dist[2*N];

// void dfs(int root,vvi &adj,vpii &vp,int par,int *h){
   
  
//   for(auto it:adj[root]){
//     if(it!=par){
//       int ht=0;
//       dfs(it,adj,vp,root,&ht);
//       if(ht>=vp[root].f){vp[root].s=vp[root].f;vp[root].f=ht;}
//       else if(vp[root].s<ht) vp[root].s=ht;
//     }
//   }
  
//   dist[root]=vp[root].f;
//   *h=vp[root].f+1;

// }

// void dfs2(int root,vvi &adj,vpii &vp,int par,int h){

  
//   for(auto it:adj[root]){
//     if(it!=par){
//       if(dist[it]==vp[root].f-1){
//         dfs2(it,adj,vp,root,max(h+1,vp[root].s+1));
//       }
//       else{
//         dfs2(it,adj,vp,root,max(h+1,vp[root].f+1));
//       }
//     }
//   }

//   dist[root]=max(dist[root],h);


// }





//     SCC  AND  CONDENSATION GRAPH
/*
void dfs(int root,vvi &adj,vb &vis,vi &order){

  vis[root]=1;

  for(auto it:adj[root]) 
  if(!vis[it]) dfs(it,adj,vis,order);

  order.pb(root);
 

}





void dfs2(int root,vvi &adj,vb &vis, vi &comp){


  vis[root]=1;
  comp.pb(root);
  for(auto it:adj[root]){
    if(!vis[it]) dfs2(it,adj,vis,comp);
  }
 
}
*/


//   HEAVY  LIGHT  DECOMPOSITION
// int assign(int root,vvi &adj,int p){

//   int size=1;
//   par[root]=p;
//   int mx=0;

//   for(auto it:adj[root]){
//     if(it!=par){
//       int sz=assign(it,adj,root);
//       if(mx<sz){
//         mx=sz;
//         heavy[root]=it;
//       }
//       size+=sz;
//     }
//   }
  
//   return size;
// }

// void decompose(int root,int h,vvi &adj){
//   head[root]=h;
//   pos[root]=cur++;
//   end[h]=root;
//   s1.insert(h);
//   if(heavy[root]!=-1)
//   {
//     decompose(heavy[root],h,adj);
//   }

//   for(auto it:adj[root]){
//     if(it!=par[root] and it!=heavy[root]){
//       decompose(it,it,adj);
//     }
//   }
// }


