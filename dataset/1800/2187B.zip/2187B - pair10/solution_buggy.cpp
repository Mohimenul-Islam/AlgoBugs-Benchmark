// بِسْمِ ٱللّٰهِ ٱلرَّحْمٰنِ ٱلرَّحِيمِ
#include<bits/stdc++.h>
using namespace std;
//#include <ext/pb_ds/assoc_container.hpp>
//#include <ext/pb_ds/tree_policy.hpp>
//using namespace __gnu_pbds;
//typedef tree<
//    int,
//    null_type,
//    less<int>,
//    rb_tree_tag,
//    tree_order_statistics_node_update>
//ordered_set;
#define int long long
const int INF = (int)1e18;

int len(int n){
    int ans = 0;
    while(n > 0){
        ans++;
        n /= 2;
    }
    return ans;
}

pair<int,int>f(int x, int y){ // y is fixed and x is assigned to p.ff
    int q = y, p = 0, done = 0; //(x=2, y=3), q = 3;
    int cbit = 32;
    for(int bit = 31; bit >= 0; bit--){
        int x_bit = (x >> bit) & 1LL, y_bit = (y >> bit) & 1LL;
        if(x_bit == 1 and y_bit == 1){
            done = 1;
        }else if(y_bit == 0 and !done){
            cbit =  bit;
        }else if(x_bit == 0 and y_bit == 0 and done){
            p += (1LL << bit);
        }else{
            p += x_bit * (1LL << bit);
        }
    }
    int p_alt = (1LL << len(y)), p2 = (1LL << cbit);
    if(abs(p_alt - x) < abs(p - x)){
        p = p_alt;
    }else if(abs(p2 - x) < abs(p - x)){
        p = p2;
    }
    return make_pair(p, q);
}

void solve(int tcase){
    int x,y; cin >> x >> y;
    auto pr1 = f(x, y); // x is changed to pr1.ff and y is fixed to pr1.ss;
    auto pr2 = f(y, x); // x is fixed to pr2.ss and y is changed to pr2.ff;
    // cout << pr1.first << ' ' << pr1.second << '\n';
    // cout << pr2.second << ' ' << pr2.first << '\n';
    if(abs(pr1.first - x) < abs(pr2.first - y)){
        cout << pr1.first << ' ' << pr1.second << '\n';
    }else{
        cout << pr2.second << ' ' << pr2.first << '\n';
    }
}


int32_t main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int t = 1;
    cin >> t;
    for(int tcase = 1; tcase <= t; tcase++) solve(tcase);
    return 0;
}
