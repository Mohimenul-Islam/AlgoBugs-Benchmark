// بِسْمِ ٱللّٰهِ ٱلرَّحْمٰنِ ٱلرَّحِيمِ
#include<bits/stdc++.h>
using namespace std;
//#include <ext/pb_ds/assoc_container.hpp>
//#include <ext/pb_ds/tree_policy.hpp>
//using namespace __gnu_pbds;
//typedef tree<
//    int,
//    null_type,
//    less<int>,
//    rb_tree_tag,
//    tree_order_statistics_node_update>
//ordered_set;
#define int long long
const int INF = (int)1e18;

int len(int n){
    int ans = 0;
    while(n > 0){
        ans++;
        n /= 2;
    }
    return ans;
}

pair<int,int>f(int x, int y){
    int p = 0, diff = INF, q = y;
    for(int bit = 31; bit >= 0; bit--){
        int x_bit = (x >> bit) & 1LL, y_bit = (y >> bit) & 1LL;
        if(x_bit and !y_bit)    p += (1LL << bit);
    }
    diff = abs(x - p);
    for(int bit = 31; bit >= 0; bit--){
        int x_bit = (x >> bit) & 1LL, y_bit = (y >> bit) & 1LL;
        int curp = 0;
        if(x_bit and y_bit){
            for(int j = 31; j > bit; j--){
                if(((x >> j) & 1LL) and !((y >> j) & 1LL))  curp += (1LL << j);
            }
            for(int j = bit - 1; j >= 0; j--){
                if(!((y >> j) & 1LL)) curp += (1LL << j);
            }
            if(abs(curp - x) < diff){
                diff = abs(curp - x);
                p = curp;
            }
        }
    }
    for(int i = 31; i >= 0; i--){
        int x_bit = (x >> i) & 1LL, y_bit = (y >> i) & 1LL, curp = 0;
        if(!y_bit){
            for(int j = 31; j > i; j--){
                if(((x >> j) & 1LL) and !((y >> j) & 1LL)) curp += (1LL << j);
            }
            curp += (1LL << i);
            if(abs(curp - x) < diff){
                diff = abs(curp - x);
                p = curp;
            }
        }
    }
    return make_pair(p, q);
}


void solve(int tcase){
    int x,y; cin >> x >> y;
    auto pr1 = f(x, y); // x is changed to pr1.ff and y is fixed to pr1.ss;
    auto pr2 = f(y, x); // x is fixed to pr2.ss and y is changed to pr2.ff;
    // cout << pr1.first << ' ' << pr1.second << '\n';
    // cout << pr2.second << ' ' << pr2.first << '\n';
    if(abs(pr1.first - x) < abs(pr2.first - y)){
        cout << pr1.first << ' ' << pr1.second << '\n';
    }else{
        cout << pr2.second << ' ' << pr2.first << '\n';
    }
}


int32_t main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int t = 1;
    cin >> t;
    for(int tcase = 1; tcase <= t; tcase++) solve(tcase);
    return 0;
}
