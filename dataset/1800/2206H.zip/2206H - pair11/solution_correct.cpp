#include <bits/stdc++.h>
using namespace std;
long long gcd(long long a, long long b){
	while(b!=0){
		a%=b;
		swap(a,b);
	}
	return a;
}
int main(){
	int n;
	cin>>n;
	long long int arr[n];
	int a;
	for(a=0;a<n;a++){
		cin>>arr[a];
	}
	long long int d[n-1];
	for(a=0;a<n-1;a++){
		d[a]=abs(arr[a]-arr[a+1])*2;
	}
	long long g=0;
	for(a=0;a<n-1;a++){
		g=gcd(g,d[a]);
	}
	long long ans;
	if(g==0){
		ans=arr[0];
	}
	else if(arr[0]%g==0){
		ans=g;
	}
	else{
		ans=arr[0]%g;
	}
	for(a=0;a<n-1;a++){
		ans=ans+d[a]/2;
	}
	cout<<ans<<endl;
	

	return 0;
}