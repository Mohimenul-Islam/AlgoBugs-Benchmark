#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>

using namespace std;
using namespace __gnu_pbds;

template <typename T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template <typename T, typename U>
using ordered_multiset = tree<pair<T, U>, null_type, less<pair<T, U>>, rb_tree_tag, tree_order_statistics_node_update>;

using ll = long long;

void solve() {
    // god I missed how much I loved solving problems
    // fuck a job, fucking drains all my time and energy

    // champagne poetry, these are the effortless flows, supposedly
    // something else is controlling me
    // under her pictures live some of the greatest quotes from me
    // under me, I see all the people that claim they over me
    // and above me, I see nobody
    // I'd have to be dead for them to say that you took it from me
    ll n;
    cin >> n;
    vector<ll> a(n);
    for (ll i = 0; i < n; i++) {
        cin >> a[i];
    }
    ll g = 0;
    for (ll i = 0; i < n - 1; i++) {
        ll d = llabs(a[i + 1] - a[i]);
        g = gcd(g, 2 * d);
    }
    if (g == 0) {
        cout << a.back() << '\n';
        return;
    }
    ll ans = -1;
    if (a[0] % g == 0) {
        ans = g;
    } else {
        ans = a[0] % g;
    }
    for (ll i = 0; i < n - 1; i++) {
        ans += llabs(a[i + 1] - a[i]);
    }
    cout << ans << '\n';
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);

    ll t = 1;
    // cin >> t;

    while (t--) {
        solve();
    }

    return 0;
}