#include <iostream>
#include <algorithm>
#include <vector>

#define int long long

int GCD(int a, int b) {
  if (a == 0) {
    return b;
  }
  return GCD(b % a, a);
}

void Solve() {
  int n;
  std::cin >> n;
  std::vector<int> arr(n);
  for (int i = 0; i < n; ++i) {
    std::cin >> arr[i];
  }
  int total = 0;
  int tmp = std::abs(arr[1] - arr[0]);
  for (int i = 1; i < n; ++i) {
    tmp = GCD(tmp, std::abs(arr[i] - arr[i - 1]));
  }
  tmp *= 2;
  if (tmp == 0 || arr[0] % tmp == 0) {
    if (tmp == 0) {
      total = arr[0];
    } else {
      total = tmp;
    }
  } else {
    total = arr[0] % tmp;
  }

  for (int i = 0; i < n - 1; ++i) {
    total += std::abs(arr[i + 1] - arr[i]);
  }
  std::cout << total << '\n';
}

signed main() {
  std::ios::sync_with_stdio(false);
  std::cin.tie(0);
  std::cout.tie(0);

  int t = 1;
  //std::cin >> t;
  while (t--) {
    Solve();
  }
  return 0;
}