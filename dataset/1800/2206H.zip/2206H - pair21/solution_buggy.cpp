#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef array<ll,2> pii;
typedef array<ll,3> tii;
const int maxn = 300005;
const int mod = 1e9+7;
const int inf = 0x3f3f3f3f;
const ll infll = 0x3f3f3f3f3f3f3f3f;
mt19937_64 rng((unsigned int) chrono::steady_clock::now().time_since_epoch().count());

int a[maxn];

void solve(){
    int n; cin >> n;
    for(int i = 0; i < n; i++) cin >> a[i];
    int g = 0;
    for(int i = 1; i < n; i++) g = __gcd(g, 2*abs(a[i]-a[i-1]));
    ll ans = a[0]%g;
    if(ans == 0) ans = g;
    for(int i = 1; i < n; i++) ans+=abs(a[i]-a[i-1]);
    cout << ans << endl;
}

int main(){
    ios_base::sync_with_stdio(false);cin.tie(NULL);
    // int t; cin >> t;
    // while(t--)
        solve();
    return 0;
}

// Pensa simples, joga leve, coda fofo.

// ?