// بِسْمِ ٱللّٰهِ ٱلرَّحْمٰنِ ٱلرَّحِيمِ
#include<bits/stdc++.h>
using namespace std;
//#include <ext/pb_ds/assoc_container.hpp>
//#include <ext/pb_ds/tree_policy.hpp>
//using namespace __gnu_pbds;
//typedef tree<
//    int,
//    null_type,
//    less<int>,
//    rb_tree_tag,
//    tree_order_statistics_node_update>
//ordered_set;
#define int long long
const int INF = (int)1e18;

int gcd(int a, int b){
    if(!b) return a;
    return gcd(b, a % b);
}

void solve(int tcase){
    int n; cin >> n;
    vector<int>a(n + 1);
    int g = 0;
    for(int i = 1; i <= n; i++){
        cin >> a[i];
        if(i > 1) g = gcd(g, 2 * abs(a[i] - a[i - 1]));
    }
    int ans;
    if(g) ans = (a[1] % g) ? a[1] % g : g;
    else ans = a[1];
    for(int i = 2; i <= n; i++){
        ans += abs(a[i] - a[i - 1]);
    }
    cout << ans << '\n';
}


int32_t main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int t = 1;
    // cin >> t;
    for(int tcase = 1; tcase <= t; tcase++) solve(tcase);
    return 0;
}
