#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=1e5+10;
int n,m,a[maxn],x,b[maxn],ans,flag;
inline void solve(int q){
	for(int i=1;i<=q;i++){
		a[q]=2*a[q]-a[q];
	}
	return;
}
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		if(i>1){
			b[i]=abs(a[i]-a[i-1]);
		}
	}
	for(int i=2;i<=n;i++){
		if(b[i]){
			if(!x){
				x=b[i];
			}
			else{
				x=__gcd(x,b[i]);
			}
		}
	}
	x*=2;
	if(x){
		ans=(a[1]-1)%x+1;
	}
	for(int i=2;i<=n;i++){
		ans+=b[i];
	}
	cout<<ans<<'\n';
	return 0;
}