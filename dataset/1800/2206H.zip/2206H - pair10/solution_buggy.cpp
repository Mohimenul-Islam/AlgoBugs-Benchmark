#include<cstdio>
#include<cmath>
#define ll long long
using namespace std;
int gcd(int a,int b)
{
	if(b==0) return a;
	return gcd(b,a%b);
}
int n,a[100005];
int main()
{
	scanf("%d",&n);
	ll sum=0;
	int p=1;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		if(i==2) p=abs(a[i]-a[i-1]);
		if(i>=2) sum+=abs(a[i]-a[i-1]);
		if(i>2) p=gcd(p,abs(a[i]-a[i-1]));
	}
	p*=2;
	a[1]%=p;
	if(a[1]==0) a[1]=p;
	printf("%lld",sum+a[1]);
	return 0;
}