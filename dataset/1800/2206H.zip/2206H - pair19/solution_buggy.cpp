#include<bits/stdc++.h>
#define int long long
// #define endl "\n"
#define pii pair<int,int>
#define matr vector<vector<int>>
using namespace std;
const int N=1e5+10;
int a[N],d[N];
int gcd(int a,int b)
{
    if(b==0)return a;
    return gcd(b,a%b);
}
void solve()
{
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
        d[i]=abs(a[i]-a[i-1]);
    }
    for(int i=1;i<=n;i++)
    {
        a[i]=a[i-1]+d[i];
    }
    int res=a[1];
    int g=0;
    for(int i=2;i<=n;i++)
    {
        if(d[i]==0)continue;
        if(g==0)
        {
            g=d[i];
        }
        else
        {
            g=gcd(g,d[i]);
        }
    }
    res=(a[1]-1)%(2*g)+1;
    cout<<a[n]-(a[1]-res)<<endl;
}
signed main()
{
    std::ios::sync_with_stdio(0);
    cin.tie(0);
    // cout.tie(0);
    // int t;
    // cin>>t;
    // while(t--)
    {
        solve();
    }
}