#include <bits/stdc++.h>

// start:
// idea:
// solved:

using namespace std;
using vi = vector<int>;
using vll = vector<long long>;
using ll = long long;
#define sz(x) ((int)((x).size()))
const double pi = numbers::pi;

template<class T> bool chmax(T &a, const T &b) { return a < b ? a = b, 1 : 0; }
template<class T> bool chmin(T &a, const T &b) { return a > b ? a = b, 1 : 0; }

void solve() {
    int n;cin>>n;
    vi a(n);
    for(auto &x:a)cin>>x;
    ll sum=0;
    ll x=2*a[1]-2*a[0];
    for(int i=1;i<=n-1;++i){
        sum+=abs(a[i]-a[i-1]);
        x=gcd(x,2*(a[i]-a[i-1]));
    }
    ll ans=a[0]%x;
    if(ans==0)ans+=x;
    cout<<ans+sum<<endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    int t = 1;
    //cin >> t;
    while (t--) solve();
}


