#include <bits/stdc++.h>
using namespace std;


#define watch(x) cout<<#x<<" : "<<x<<endl
#define all(x) x.begin(), x.end()
#define rep(i, a, n) for(int i = a; i < n; i++)
#define rep0(i, n) for(int i = 0; i < n; i++)
#define rep1(i, n) for(int i = 1; i <= n; i++)
#define pb push_back
#define out(x) cout<<x<<endl
#define outs(x) cout<<x<<" "
#define tr(container, it) for(typeof(container.begin()) it = container.begin(); it != container.end(); it++)
#define int long long
#define forit(x, v) for(auto &x : v)
#define reps(i, v) for(int i = 0; i < v.size(); i++)
#define input(arr, n) for(int i = 0; i < n; i++) cin>>arr[i];


typedef long double ld;
typedef long long ll;
typedef pair<int, int> ii;
typedef pair<int, ii> iii;
typedef vector<int> vi;
typedef vector< vector<int> > vvi;
typedef vector< pair<int, int> > vii;
typedef vector<iii> viii;
typedef vector<string> vs;


const int inf = 1e9;
const int M = 1e9 + 7;
const ld pi = atan2(0, -1);
const ld eps = 1e-6;

int findGCD(int a, int b) {
    if (a == 0)
        return b;
    return findGCD(b % a, a);
}

void solve() {
    int n;
    cin>>n;
    vi a(n);
    forit(x, a) cin>>x;
    vi b = a;
    sort(all(b));
    if(b[0] == b[n - 1]) {
        out(b[0]);
        return;
    }
    int sum = abs(a[1] - a[0]), g = 2 * sum;
    rep1(i, n - 2) {
        sum += abs(a[i] - a[i + 1]);
        g = findGCD(g, 2 * abs(a[i] - a[i + 1]));
    }
    if(a[0] % g == 0) {
        sum += g;
    } else {
        sum += (a[0] % g);
    }
    out(sum);

}


signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    // cin>>t;
    t = 1;
    while(t--){
        solve();
    }
}