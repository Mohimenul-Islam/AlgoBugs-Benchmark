#include <bits/stdc++.h>
using namespace std;
#define int long long
int gcd(int a, int b) {
    while(b) {
        int r = a % b;
        a = b, b = r;
    }
    return a;
}

void work() {
    int n; cin >> n;
    vector<int> a(n), dif(n - 1);
    int sum = 0;
    for(int i = 0; i < n; i++) {
        cin >> a[i];
        if(i) {
            dif[i - 1] = abs(a[i] - a[i - 1]);
            sum += dif[i - 1];
        }
    }

    sort(dif.begin(), dif.end());
    dif.erase(unique(dif.begin(), dif.end()), dif.end());

    auto get_res = [&](int x) {
        a[0] %= x;
        if(!a[0]) a[0] = x;
        return x + sum;
    };

    if(dif.size() == 1) {
        if(dif[0] == 0) {
            cout << a[n - 1] << endl;
        } else {
            cout << get_res(2 * dif[0]) << endl;
        }
    } else {
        int g = dif[0] == 0 ? dif[1] : dif[0];
        for(int i = 1; i < dif.size(); i++) {
            g = gcd(g, dif[i]);
        }                              
        cout << get_res(2 * g) << endl;
    }
}

signed main() {
    int T= 1;
    while(T--) work();
}