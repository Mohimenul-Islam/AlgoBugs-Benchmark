#include<bits/stdc++.h>
using namespace std;
long long a[100005],b[100005],mn,ans;
long long gcd(long long a, long long b) {
    return b==0?a:gcd(b,a%b);
}
int main() {
	int n;
		cin>>n;
		a[0]=0;mn=-1;ans=0;
		for(int i=1;i<=n;i++) {
		cin>>a[i];
		if(i>1) {
			b[i-1]=abs(a[i]-a[i-1]);
			ans+=b[i-1];b[i-1]*=2;
		}
		
		
		}
		sort(b+1,b+n);
		bool p=0;
		for(int i=1;i<n;i++) {
			if(b[i]!=0&&p==0) {
				mn=b[i];
				p=1;	
			}
			if(p) 
				mn=gcd(mn,b[i]);
			if(mn==1) break;
		}
		if(p&&a[1]%mn!=0) ans+=a[1]%mn;
		if(p&&a[1]%mn==0) ans+=mn;
		if(!p) ans+=a[1];
		cout<<ans<<endl;
	return 0;
} 