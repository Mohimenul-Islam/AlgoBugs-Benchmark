#include<bits/stdc++.h>
using namespace std;
long long a[100005],b[100005],mn,ans;
int main() {
	int n;
		cin>>n;
		a[0]=0;mn=2e9+5;ans=0;
		for(int i=1;i<=n;i++) {
		cin>>a[i];
		b[i]=abs(a[i]-a[i-1]);
		ans+=b[i];
		b[i]*=2;
		}
		ans-=a[1];
		for(int i=2;i<=n;i++) {
			if(b[i]!=0) {
				if(a[1]%b[i]==0) a[i]=b[i];
				else a[i]=a[1]%b[i];
				mn=min(mn,a[i]);
			}
		}
		cout<<ans+mn<<endl;
	
	return 0;
} 