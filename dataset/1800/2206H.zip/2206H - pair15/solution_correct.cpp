#include <bits/stdc++.h>
using namespace std;
#define int long long
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0)
#define endl '\n'
int lowbit(int x){return x&-x;}
const int mod=676767677;

const int N=2e5+6;

signed main()
{
    IOS;

    int n;cin>>n;

    vector<int> ca(n+1);
    for (int i=1;i<=n;i++)cin>>ca[i];
    int d=0;
    int sum=0;
    for (int i=2;i<=n;i++)d=gcd(d,abs(ca[i]-ca[i-1])),sum+=abs(ca[i]-ca[i-1]);
    d*=2;
    if (d==0)
    {
        cout<<ca[1];
        return 0;
    }
    int s=ca[1]%d;
    if (s==0)s=d;
    cout<<s+sum<<endl;
    return 0;
}   