#include <bits/stdc++.h>
using namespace std;
#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define forsn(i, s, n) for(int i = s; i < int(n); ++i)
#define dforn(i, n) for(int i = int(n) - 1; i >= 0; --i)
#define dforsn(i, s, n) for(int i = int(n) - 1; i >= int(s); --i)
#define SZ(a) int((a).size())
#define pb push_back
#define fst first
#define snd second

int mygcd(int a, int b) {
    while (b) a %= b, swap(a, b);
    return a;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n; cin >> n;
    vector<int> arr(n);
    forn(i, n) cin >> arr[i];
    int g = 0;
    forn(i, n - 1) g = mygcd(g, abs(arr[i + 1] - arr[i]));
    if (g == 0) {
        cout << arr[0] << '\n';
        return 0;
    }
    int res = (arr[0] - 1) % (2 * g) + 1;
    forn(i, n - 1) res += abs(arr[i + 1] - arr[i]);
    cout << res << '\n';
}