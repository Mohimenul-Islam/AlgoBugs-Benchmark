#include <bits/stdc++.h>
using namespace std;

const int MAXN = 200050;
const long long MOD = 1e9 + 7;
long long a[MAXN];

long long gcd(long long x,long long y){
    if(x == 0 || y == 0) return max(x, y);
    while(y != 0){
        long long r = x % y;
        x = y;
        y = r;
    }
    return x;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int n;
    cin >> n;
    for(int i = 1; i <= n; i++) cin >> a[i];
    long long add = 0;
    vector<long long> d;
    for(int i = 2; i <= n; i++){
        d.push_back(abs(a[i] - a[i - 1]));
        add += abs(a[i] - a[i - 1]);
    }

    long long x = 2 * d[0];
    for(int i = 0; i < d.size(); i++){
        x = gcd(x, 2 * d[i]);
    }
    if(x == 0) cout << a[1] + add;
    else cout << max((a[1] % x), x) + add;

    return 0;
}
