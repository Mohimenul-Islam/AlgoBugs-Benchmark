// Jan Zakrzewski
#include <bits/stdc++.h>
using namespace std;

using i32 = int32_t;
using i64 = int64_t;
using u32 = uint32_t;
using u64 = uint64_t;
using i32vec = vector<i32>;
using i32que = queue<i32>;
#define SIZE(x) i32((x).size())

i32 constexpr N = 111'111;
i32 n, a[N];
i32 d;
i64 s;
i64 ans;

void solve() {
    cin >> n;
    for(i32 i = 1; i <= n; ++i)
        cin >> a[i];

    d = 0;
    s = 0;
    for(i32 i = 2; i <= n; ++i) {
        i32 u = abs(a[i] - a[i - 1]);
        d = gcd(d, u);
        s += u;
    }

    ans = (a[1] - 1) % (2 * d) + 1 + s;
    cout << ans << "\n";
}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    solve();
}
