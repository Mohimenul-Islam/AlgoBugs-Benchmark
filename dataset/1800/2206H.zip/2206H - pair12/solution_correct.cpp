#include <bits/stdc++.h>
using namespace std;
typedef long long int lli;

#define all(x) (x).begin(), (x).end()
#define mineq(a, b) ((a) = min((a), (b)))
#define maxeq(a, b) ((a) = max((a), (b)))

/**
 * ok so what happens if I do an operation
 *
 * what ccan I make an operation do
 *
 * If I operate on prefix and suffix then I can do what
 *
 *
 *
 * a1 a2 a3 a4 a5 a6 a7 a8 a9 10
 * 2a4-a1  2a4-a2  2a4-a3  2a4-a4
 *
 * so just like that you can just take 2aj - ai for all i and set ai to 2aj - ai
 *
 * what if I do j first and then k next
 *
 * 2ak-2aj+ai
 *
 * so I can subtract 2|ak-aj| to all of gthe elements
 *
 *
 *
 */

int main(int argc, char const *argv[])
{
    ios::sync_with_stdio(0);
    cin.tie(0);

    int n;
    cin >> n;
    vector<int> a(n);
    for (int &x : a)
        cin >> x;
    lli ans = 0;
    for (int i = 1; i < n; i++)
        ans += abs(a[i] - a[i - 1]);
    lli first = a[0];
    sort(a.begin(), a.end());
    lli g = 0;
    for (int i = 1; i < n; i++)
    {
        g = gcd(g, a[i] - a[i - 1]);
    }
    if (g == 0)
    {
        // all of the elemtsn are the same
        ans += first;
    }
    else
    {

        g *= 2;
        // a[0]-x*g >= 1 a[0]-1/g >= x
        lli x = (first - 1) / g;
        ans += first - x * g;
    }
    cout << ans << endl;
    return 0;
}