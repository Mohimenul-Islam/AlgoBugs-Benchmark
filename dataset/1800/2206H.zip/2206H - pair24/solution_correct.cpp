#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;

const ll N = 2e5 + 10, mod = 998244353, inf = 1e18;
ll n, d, a[N], ans;
int main(){
	ios::sync_with_stdio(false); cout.tie(0); cin.tie(0);
	cin >> n;
	for(int i = 1; i <= n; i++) cin >> a[i];
	for(int i = 2; i <= n; i++) d = gcd(d, (a[i] - a[i - 1]) * 2);
    if(d != 0) ans = a[1] % d;
    else ans = a[1];
    if(ans == 0) ans = d;
	for(int i = 2; i <= n; i++) ans += abs(a[i] - a[i - 1]);
	cout << ans; 
    
    
}