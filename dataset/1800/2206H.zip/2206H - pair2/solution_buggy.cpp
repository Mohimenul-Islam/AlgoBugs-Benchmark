#include<iostream>
using ll = long long;
using namespace std;
ll gcd(ll a, ll b) {
	if (a > b) {
		swap(a, b);
	}
	while (a != 0) {
		ll t = b % a;
		b = a;
		a = t;
	}
	return b;
}
int main() {
	ll n;
	ll arr[100001];
	ll sumdif = 0;
	cin >> n;
	for (ll i = 0; i < n; i++) {
		cin >> arr[i];
	}
	for (ll i = 1; i < n; i++) {
		sumdif += abs(arr[i] - arr[i - 1]);
	}
	ll gcf = 0;
	//if (n > 2) {
		for (ll i = 0; i < n - 1; i++) {
			gcf = gcd(gcf, abs(2 * (arr[i + 1] - arr[i])));
		}
	//}
	//if (gcf == 0) {
	//	cout << sumdif + min(arr[0], (2 * arr[1] - arr[0]));
	//}
	//else {
	cout << sumdif + min((arr[0] - 1 + (3000000000 /gcf + 1) * gcf) % gcf + 1, (2 * arr[1] - arr[0] - 1 + (3000000000 / gcf + 1) * gcf) % gcf + 1);
	//}
}