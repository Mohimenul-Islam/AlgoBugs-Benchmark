#include <bits/stdc++.h>
using namespace std;

#define endl '\n'

#define maxn 100005

int64_t a[maxn];

void solve(void) {
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++) cin >> a[i];

	int64_t delt = INT64_MAX;
	for (int i = 1; i < n; i++)
		if (a[i] != a[i + 1]) delt = min(delt, abs(a[i] - a[i + 1]));
	
	if (delt == INT64_MAX) return cout << a[n] << endl, void();

	int64_t p = a[1] % (2 * delt);
	if (p == 0) p = 2 * delt;

	for (int i = 1; i < n; i++) p += abs(a[i] - a[i + 1]);

	cout << p << endl;

	return;
}

int main() {
	ios::sync_with_stdio(false), cin.tie(nullptr);

	int _ = 1;
	while (_--) solve();

	return 0;
}