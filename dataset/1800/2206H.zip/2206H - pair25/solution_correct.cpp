#include<bits/stdc++.h>
using ll = long long ; 
using namespace std ;


void solve(){
    
    int n ;
    cin >> n ; 
    
    vector<int> arr(n) ; 
    
    for(int i = 0; i < n; i++) cin >> arr[i]  ;
    
    ll ans = 0 ; 
    int curr_gcd = -1 ; 
    
    for(int i = 1; i < n; i++){
        ans += abs(arr[i] - arr[i-1]) ; 
        if(curr_gcd == -1 && abs(arr[i] - arr[i-1]) != 0) curr_gcd = 2*abs(arr[i] - arr[i-1]) ; 
        else if(curr_gcd != -1 && abs(arr[i] - arr[i-1]) != 0) curr_gcd = __gcd(curr_gcd, 2*abs(arr[i]- arr[i-1])) ; 
    }

    ll first_num = arr[0] ; 
    if(curr_gcd != -1 && arr[0]%curr_gcd == 0) first_num = curr_gcd ; 
    else if(curr_gcd != -1) first_num = arr[0]%curr_gcd ; 
    
    ans += first_num ; 
    cout << ans << endl; 
}

int main(){
    
    ios::sync_with_stdio(false);
    // cin.tie(nullptr);
    int t = 1; 

    while(t--){
        solve() ; 
    }
}