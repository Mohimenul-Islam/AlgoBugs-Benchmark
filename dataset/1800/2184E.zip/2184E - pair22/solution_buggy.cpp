#include <iostream>
#include <algorithm>
#include <vector>
#include <climits>
#include <iomanip>
#include <deque>
#include <set>
#include <cmath>
#include <cstring>
#include <map>
#include <numeric>
#include <queue>
#define pb push_back
#define SZ(x) ((int)x.size())
using namespace std;
using ll = long long;
using ld = long double;

class DSU {
private:
    vector<int> parent, size;

public:
    DSU(int n) {
        parent.resize(n);
        size.assign(n, 1);
        for (int i=0; i<n; i++) {
		    parent[i] = i;
        }
    }

    int find(int u) {
        if (u == parent[u]) {
            return u;
        }
        int root = find(parent[u]);
        parent[u] = root;
        return root;
    }

    void merge(int u, int v) {
        int pu = find(u);
        int pv = find(v);
        if (pu != pv) {
            if (size[pu] < size[pv]) {
                swap(pu, pv); //union by size optimization
            }
            parent[pv] = pu;
            size[pu] += size[pv];
        }
    }

    int getSize(int u) {
        return size[find(u)];
    }
};

ll _abs(ll v) {
    return (v > 0) ? v : -v;
}

void solve() {
    int n; cin >> n;
    vector<int> a(n);
    map<int, vector<pair<int, int>>> mp;
    DSU dsu(n);
    for (int i=0; i<n; i++) {cin >> a[i];}
    for (int i=0; i<n-1; i++) {
        mp[_abs(a[i]-a[i+1])].push_back({i, i+1});
    }
    ll ans = 0;
    vector<ll> res;
    for (int k=n-1; k>=1; k--) {
        for (pair<int, int> pr : mp[k]) {
            int i = pr.first;
            if (dsu.find(i) != dsu.find(i+1)) {
                ll y1 = dsu.getSize(i); ll y2 = dsu.getSize(i+1);
                ans -= y1*(y1-1)/2; ans -= y2*(y2-1)/2;
                ans += (y1+y2)*(y1+y2-1)/2;
                dsu.merge(i, i+1);
            }
        }
        res.push_back(ans);
    }
    reverse(res.begin(), res.end());
    for (int v : res) {cout << v << ' ';}
    cout << '\n';
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t; cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}