#include<bits/stdc++.h> 
using namespace std; 
using ll = long long ;


void solve(int testno, int tests){
	ll n ; 
	cin >> n ; 

	vector<ll> arr(n) ; 

	for(int i = 0; i < n; i++){
		cin >> arr[i] ;   
	}

	map<ll, vector<ll>> diffs ; 

	for(int i = 0; i < n-1; i++){
		diffs[abs(arr[i] - arr[i+1])].push_back(i) ;  
	}

	vector<ll> curr_ans(n-1, 0) ; 

	ll ans = 0 ;  

	map<ll, ll> starts ; 
	map<ll, ll> ends ;  

	for(auto it = diffs.rbegin(); it != diffs.rend(); it++){

		ll diff = it->first; 
		vector<ll> v = it->second; 



		for(int i = 0; i < (int)v.size(); i++){

			ll u = v[i], v = u+1; 


			auto itr1 = ends.lower_bound(u) ; 
			auto itr2 = starts.lower_bound(v) ; 



			if((itr1 == ends.end() || itr1->first != u) && (itr2 == starts.end() || itr2->first != v)){

				ans += 1 ;
				starts[u] = v ; 
				ends[v] = u ; 
			} else if((itr1 == ends.end() || itr1->first != u)){

				int next_start = itr2->first, next_end = itr2->second;
				starts.erase(next_start) ; 
				ends.erase(next_end) ; 

				starts[u] = next_end; 
				ends[next_end] = u; 

				int eles = next_end - next_start + 1 ; 
				ans -= (1ll * eles * (eles - 1) / 2) ; 
				ans += (1ll * eles * (eles + 1) / 2) ; 
			} else if((itr2 == starts.end() || itr2->first != v)){

				int prev_start = itr1->second, prev_end = itr1->first ;
				starts.erase(prev_start) ; 
				ends.erase(prev_end) ; 

				starts[prev_start] = v ; 
				ends[v] = prev_start ; 
				int eles = prev_end - prev_start + 1 ; 
				ans -= (1ll * eles * (eles - 1) / 2) ; 
				ans += (1ll * eles * (eles + 1) / 2) ;

			} else{

				int next_start = itr2->first, next_end = itr2->second ; 
				int prev_start = itr1->second, prev_end = itr1->first ; 



				starts.erase(prev_start) ; 
				starts.erase(next_start) ; 

				ends.erase(prev_end) ; 
				ends.erase(next_end) ; 

				int eles1 = prev_end - prev_start + 1;  
				int eles2 = next_end - next_start + 1; 

				starts[prev_start] = next_end ; 
				ends[next_end] = prev_start ; 



				ans -= (1ll * eles1 * (eles1 - 1) / 2) ; 
				ans -= (1ll * eles2 * (eles2 - 1) / 2) ; 
				ans += (1ll * (eles1 + eles2) * (eles1 + eles2 - 1) / 2) ; 

			}
		}

		curr_ans[diff-1] = ans ; 
	}


	for(ll x: curr_ans) cout << x << " " ; 
	cout << endl; 
}


int main(){
	int t; 
	cin >> t ; 

	for(int i = 0; i < t; i++){
		solve(i, t) ; 
	}
}