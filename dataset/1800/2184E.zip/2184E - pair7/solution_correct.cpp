#include <bits/stdc++.h>
using namespace std;
using ll = long long;

int parent[100005];

int find_dsu(int i) {
    if (parent[i] != i) {
        parent[i] = find_dsu(parent[i]);
    }
    return parent[i];
}

void solve() {
    int n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }

    vector<int> b(n);
    for (int i = 1; i < n; i++) {
        b[i] = abs(a[i] - a[i - 1]);
    }

    vector<int> head(n), nxt(n);
    for (int i = 0; i < n; i++) {
        parent[i] = i;
        head[i] = 0;
    }

    for (int i = n - 1; i > 0; i--) {
        nxt[i] = head[b[i]];
        head[b[i]] = i;
    }

    vector<ll> sz(n);
    vector<ll> ans(n);
    vector<bool> vis(n, false);
    ll cur_ans = 0;

    for (int k = n - 1; k >= 1; k--) {
        int cur_idx = head[k];
        while (cur_idx != 0) {
            vis[cur_idx] = true;
            sz[cur_idx] = 1;
            cur_ans++;

            if (cur_idx > 1 && vis[cur_idx - 1]) {
                int r1 = find_dsu(cur_idx);
                int r2 = find_dsu(cur_idx - 1);
                ll s1 = sz[r1];
                ll s2 = sz[r2];
                cur_ans -= s1 * (s1 + 1) / 2;
                cur_ans -= s2 * (s2 + 1) / 2;

                if (s1 < s2) {
                    parent[r1] = r2;
                    sz[r2] += sz[r1];
                    cur_ans += sz[r2] * (sz[r2] + 1) / 2;
                } else {
                    parent[r2] = r1;
                    sz[r1] += sz[r2];
                    cur_ans += sz[r1] * (sz[r1] + 1) / 2;
                }
            }

            if (cur_idx < n - 1 && vis[cur_idx + 1]) {
                int r1 = find_dsu(cur_idx);
                int r2 = find_dsu(cur_idx + 1);
                ll s1 = sz[r1];
                ll s2 = sz[r2];
                cur_ans -= s1 * (s1 + 1) / 2;
                cur_ans -= s2 * (s2 + 1) / 2;

                if (s1 < s2) {
                    parent[r1] = r2;
                    sz[r2] += sz[r1];
                    cur_ans += sz[r2] * (sz[r2] + 1) / 2;
                } else {
                    parent[r2] = r1;
                    sz[r1] += sz[r2];
                    cur_ans += sz[r1] * (sz[r1] + 1) / 2;
                }
            }
            cur_idx = nxt[cur_idx];
        }
        ans[k] = cur_ans;
    }

    for (int i = 1; i < n; i++) {
        cout << ans[i] << ' ';
    }
    cout << endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}