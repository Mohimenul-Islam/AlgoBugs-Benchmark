#include <bits/stdc++.h>
using namespace std;
using ll = long long;

void solve() {
    int n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }

    vector<int> b(n - 1);
    for (int i = 0; i < n - 1; i++) {
        b[i] = abs(a[i + 1] - a[i]);
    }

    queue<pair<int, int>> q;
    q.push({0, n - 1});
    cout << (ll)n * (n - 1) / 2 << ' ';
    int k = 1;
    while (k < n - 1) {
        int sz = q.size();
        k++;
        if (sz == 0) {
            cout << 0 << ' ';
            continue;
        }
        ll ans = 0;
        for (int i = 0; i < sz; i++) {
            auto [l, r] = q.front();
            q.pop();

            int cur_left = l;
            for (int j = l; j < r; j++) {
                if (b[j] < k) {
                    int len = j - cur_left;
                    if (len > 0) {
                        q.push({cur_left, j});
                        ans += (ll)len * (len + 1) / 2;
                    }
                    cur_left = j + 1;
                }
            }
            int len = r - cur_left;
            if (len > 0) q.push({cur_left, r});
            ans += (ll)len * (len + 1) / 2;
        }

        cout << ans << ' ';
    }
    cout << endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}