﻿#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define int long long



class UnionFind {
    vector<int> fa; // 代表元
    vector<int> sz; // 集合大小
public:
    int cc; // 连通块个数
    UnionFind(int n) : fa(n), sz(n, 1), cc(n) {
        ranges::iota(fa, 0);
    }
    int find(int x) {
        if (fa[x] != x) {
            fa[x] = find(fa[x]);
        }
        return fa[x];
    }
    bool is_same(int x, int y) {
        return find(x) == find(y);
    }
    // 把 from 所在集合合并到 to 所在集合中
    bool merge(int from, int to) {
        int x = find(from), y = find(to);
        if (x == y) {
            return false;
        }
        fa[x] = y;
        sz[y] += sz[x];
        cc--;
        return true;
    }
    int get_size(int x) {
        return sz[find(x)];
    }
};




void solve() {
    int n;
    cin >> n;
    vector<int> nums;
    for (int i = 0; i < n; i++) {
        int num;
        cin >> num;
        nums.push_back(num);
    }
    map<int, vector<int>> dis;
    for (int i = 0; i < n - 1; i++) {
        int d = abs(nums[i] - nums[i + 1]);
        dis[d].push_back(i);
    }


    UnionFind uni(n + 1);

    set<int> se;
    vector<int> ans = { 0 };
    for (int d = n - 1; d >= 1; d--) {
        int cnt = ans.back();
        for (int t : dis[d]) {
            int sz1 = uni.get_size(t);
            int sz2 = uni.get_size(t + 1);
            cnt -= sz1 * (sz1 - 1) / 2 + sz2 * (sz2 - 1) / 2;
            uni.merge(t, t + 1);
            int sz3 = uni.get_size(t);
            cnt += sz3 * (sz3 - 1) / 2;
        }
        ans.push_back(cnt);
    }
    cout << endl;
    ranges::reverse(ans);
    for (int i = 0; i < n - 1;i++) {
        int x = ans[i];
        cout << x << " ";
    }
    cout << endl;
    cout << endl;












    return;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    int T = 1;
    cin >> T;
    while (T--) solve();
    return 0;
};