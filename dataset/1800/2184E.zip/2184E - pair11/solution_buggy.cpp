#include <bits/stdc++.h>
#define int long long
using namespace std;

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        vector<int> a(n);
        for (int i = 0; i < n; i++) {
            cin >> a[i];
        }
        vector<int> c(n, 0);
        for (int i = 0; i < n; i++) {
            int m = 1e9;
            for (int j = i + 1; j < n; j++) {
                m = min(m, abs(a[j] - a[j - 1]));
                c[m]++;
            }
        }
        /*for (int i = 0; i < n; i++) {
            cout << c[i] << " ";
        }*/
        cout << endl;
        vector<int> ans(n, 0);
        int s = 0;
        for (int i = n - 1; i >= 1; i--) {
            s += c[i];
            ans[i] = s;
        }
        for (int i = 1; i < n; i++) {
            cout << ans[i] << " ";
        }
        cout << endl;
    }
    return 0;
}