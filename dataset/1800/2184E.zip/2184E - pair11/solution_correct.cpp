#include <bits/stdc++.h>
#define int long long
using namespace std;

struct dsu {
    vector<int> pr;
    vector<int> sz;

    dsu(int n) {
        pr.resize(n);
        sz.resize(n, 1);
        for (int i = 0; i < n; i++) {
            pr[i] = i;
        }
    }

    int find(int v) {
        if (pr[v] == v) {
            return v;
        }
        return pr[v] = find(pr[v]);
    }

    int unite(int a, int b) {
        a = find(a);
        b = find(b);
        if (a == b)
            return sz[a];
        if (sz[a] < sz[b]) {
            swap(a, b);
        }
        pr[b] = a;
        sz[a] += sz[b];
        return sz[a];
    }
};

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        vector<int> a(n);
        for (int i = 0; i < n; i++) {
            cin >> a[i];
        }
        vector<tuple<int, int, int>> g;
        for (int i = 0; i < n - 1; i++) {
            g.emplace_back(abs(a[i + 1] - a[i]), i, i + 1);
        }
        sort(g.begin(), g.end(), greater<tuple<int, int, int>>());
        dsu dcu(n);
        vector<int> c(n + 1, 0);
        for (auto [d, a, b] : g) {
            int ans = dcu.sz[dcu.find(a)] * dcu.sz[dcu.find(b)];
            c[d] += ans;
            dcu.unite(a, b);
        }
        vector<int> ans(n, 0);
        int s = 0;
        for (int i = n - 1; i >= 1; i--) {
            s += c[i];
            ans[i] = s;
        }
        for (int i = 1; i < n; i++) {
            cout << ans[i] << " ";
        }
        cout << endl;
    }
    return 0;
}