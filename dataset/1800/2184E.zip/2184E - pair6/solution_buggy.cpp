// #include <iostream>
// #include <vector>
// #include <algorithm>
// #include <cmath>
// #include <cstring>
// #include <string>
// #include <queue>
// #include <stack>
// #include <deque>
// #include <set>
// #include <map>
// #include <unordered_set>
// #include <unordered_map>
// #include <numeric>
// #include <limits>
// #include <iomanip>

// using namespace std;

// /* ===================== TYPES ===================== */
// using ll = long long;
// using pii = pair<int,int>;
// using pll = pair<ll,ll>;
// using vi = vector<int>;
// using vll = vector<ll>;

// /* ===================== MACROS ===================== */
// #define pb push_back
// #define ff first
// #define ss second
// #define all(x) (x).begin(), (x).end()
// #define rall(x) (x).rbegin(), (x).rend()
// #define sz(x) (int)(x).size()

// /* ===================== I/O HELPERS ===================== */
// template<typename T>
// void read_vector(vector<T> &v) {
//     for (auto &x : v) cin >> x;
// }

// template<typename T>
// void print_vector(const vector<T> &v, char sep = ' ') {
//     for (int i = 0; i < (int)v.size(); i++) {
//         cout << v[i] << (i + 1 == (int)v.size() ? '\n' : sep);
//     }
// }
// void solve(vll &ans,vll &arr, ll n){
//     stack<pll> st;
//     for (int i=0;i<n-1;i++){
//         while(!st.empty() && st.top().ff>=arr[i]){
//                 st.pop();
//             }
//             if (st.empty()){
//                 ans[arr[i]]+=i;
//             }
//             else{
//                 ans[arr[i]]+=i-st.top().ss-1;
//             }
//             st.push({arr[i],i});
//     }
// }
// int main() {
//     ios::sync_with_stdio(false);
//     cin.tie(nullptr);

//     int t;
//     cin>>t;
//     while(t--){
//         int n;
//         cin>>n;
//         vll a(n);
//         read_vector(a);
//         vll diff;
//         for (int i=1;i<n;i++){
//             diff.pb(abs(a[i]-a[i-1]));
//         }
//         vll ans(n,0);
//         for (int i:diff)ans[i]++;
//         solve(ans,diff,n);
//         reverse(all(diff));
//         solve(ans,diff,n);
//         print_vector(ans);
//     }

//     return 0;
// }

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
#include <queue>
#include <stack>
#include <deque>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <numeric>
#include <limits>
#include <iomanip>

using namespace std;

/* ===================== TYPES ===================== */
using ll = long long;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;

/* ===================== MACROS ===================== */
#define pb push_back
#define ff first
#define ss second
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define sz(x) (int)(x).size()

/* ===================== I/O HELPERS ===================== */
template <typename T>
void read_vector(vector<T> &v)
{
    for (auto &x : v)
        cin >> x;
}

template <typename T>
void print_vector(const vector<T> &v, char sep = ' ')
{
    for (int i = 0; i < (int)v.size(); i++)
    {
        cout << v[i] << (i + 1 == (int)v.size() ? '\n' : sep);
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        vll a(n);
        read_vector(a);
        vll arr;
        for (int i = 1; i < n; i++)
        {
            arr.pb(abs(a[i] - a[i - 1]));
        }
        vll last_small(n-1);
        vll next_small(n-1);
        vll ans(n-1);
        stack<pll> st;
        //print_vector(arr);
        for (int i = 0; i < n - 1; i++)
        {
            while (!st.empty() && st.top().ff > arr[i])
            {
                st.pop();
            }
            if (st.empty())
            {
                last_small[i]=-1;
            }
            else
            {
                if (st.top().ff==arr[i]){
                    last_small[i]=-1e5;
                }
                else{last_small[i] = st.top().ss;}
            }
            st.push({arr[i], i});
        }
        while(!st.empty())st.pop();
        for (int i = n-2; i >=0;i--)
        {
            while (!st.empty() && st.top().ff >= arr[i])
            {
                st.pop();
            }
            if (st.empty())
            {
                next_small[i] = n-1;
            }
            else
            {
                next_small[i] = st.top().ss;
            }
            st.push({arr[i], i});
        }

        //print_vector(last_small);
        //print_vector(next_small);
        for (int i=0;i<n-1;i++){
            if (last_small[i]==-1e5)continue;
            else{
                ll len = next_small[i]-last_small[i]-1;
                ans[arr[i]-1]+=len+(len)*(len-1)/2;
            }
        }
        ll s=0;
        // for (int i=n-2;i>=0;i--){
        //     s+=ans[i];
        //     ans[i]=s;
        // }
        print_vector(ans);
    }
    return 0;
}