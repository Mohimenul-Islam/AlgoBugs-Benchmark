#include <bits/stdc++.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <cmath>
#include <cstring>
using namespace std;
#define ll long long
#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define fr(v) for (int i = 0; i < v.size(); i++)
#define Fast                          \
    ios_base::sync_with_stdio(false); \
    cin.tie(NULL);
void input()
{
    if (fopen("stdin.txt", "r"))
    {
        freopen("stdin.txt", "r", stdin);
        freopen("stdout.txt", "w", stdout);
    }
}
const int N = 500002;
vector<int> L(2 * 100002), R(2 * 100002);
struct DSU
{
    vector<int> par;
    int ncmp, mx;
    void inti(int n)
    {
        par.resize(n + 1, -1);
        for (int i = 1; i <= n; i++)
        {
            L[i] = i, R[i] = i;
        }
        ncmp = n;
        mx = 0;
    }
    int find(int u)
    {
        return par[u] < 0 ? u : par[u] = find(par[u]);
    }
    bool join(int b, int s)
    {
        b = find(b), s = find(s);
        if (b == s)
            return false;
        if (par[b] > par[s])
            swap(b, s);
        par[b] += par[s];
        par[s] = b;
        ncmp--;
        L[b] = min(L[b], L[s]);
        R[b] = max(R[b], R[s]);
        mx = max(mx, -1 * par[b]);
        return true;
    }
    int Max_size_cmp()
    {
        return mx;
    }
};
struct parity_DSU
{
    int par[N], dist[N], ncmp;
    void inti(int n)
    {
        memset(par, -1, sizeof par);
        fill(dist, dist + n, 0);
        ncmp = n;
    }
    // {root,dist_to_root}
    pair<int, int> find(int u)
    {
        if (par[u] < 0)
            return {u, 0};
        auto [root, dis] = find(par[u]);
        dist[u] ^= dist[par[u]];
        par[u] = root;
        return {root, dist[u]};
    }
    int addedge(int u, int v, int p)
    {
        auto [ru, du] = find(u);
        auto [rv, dv] = find(v);
        if (rv == ru)
            return (du ^ dv) ? 1 : -1;
        par[rv] = ru;
        dist[rv] = dv ^ du ^ p;
        return 0;
    }
};

int mod = 1e9 + 7;

int modSum(ll a, ll b)
{
    /// complexity: 1
    a = (a % mod + mod) % mod;
    b = (b % mod + mod) % mod;
    return (a + b) % mod;
}

int modProd(ll a, ll b)
{
    /// complexity: 1
    a = (a % mod + mod) % mod;
    b = (b % mod + mod) % mod;
    return (a * b) % mod;
}

int fastPow(int a, int b)
{
    /// complexity: log(b)
    if (b == 0)
        return 1;
    int temp = fastPow(a, b / 2);
    if (b % 2 == 0)
        return modProd(temp, temp);
    return modProd(modProd(a, temp), temp);
}
ll get(ll l, ll r)
{
    return 1LL * ((r - l + 1) * (((r - l + 1) - 1))) / 2;
}
int main()
{
    Fast;
    input();
    int _t = 1;
    DSU ds1;
    cin >> _t;
    while (_t--)
    {
        int n;
        cin >> n;
        vector<int> p(n + 1);
        DSU dsu;
        dsu.inti(n);
        for (int i = 1; i <= n; i++)
            cin >> p[i];
        vector<pair<int, int>> adj[n + 1];
        for (int i = 1; i <= n - 1; i++)
        {
            adj[abs(p[i] - p[i + 1])].push_back({i, i + 1});
        }
        vector<ll> ans;
        ll t = 0;
        for (int i = n - 1; i > 0; i--)
        {
            for (auto &it : adj[i])
            {
                if (dsu.find(it.first) == dsu.find(it.second))
                    continue;
                int x = it.first, y = it.second;
                t -= (get(L[dsu.find(x)], R[dsu.find(x)]) + get(L[dsu.find(y)], R[dsu.find(y)]));
                dsu.join(x, y);
                t += get(L[dsu.find(x)], R[dsu.find(y)]);
            }
            ans.push_back(t);
        }
        reverse(all(ans));
        for (int it : ans)
            cout << it << ' ';
        cout << '\n';
        for (int i = 1; i <= n; i++)
            adj[i].clear();
    }
    return 0;
}