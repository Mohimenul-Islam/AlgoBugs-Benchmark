#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll T,n,a[200005],fa[200005],fe[200005],cnt,bac,fro,an[200005];
typedef struct{
	ll f,v;
}seq;
seq b[200005];
ll ans;
bool cmp(seq u,seq v)
{
	return u.v>v.v;
}
ll finda(ll x)
{ 
	return fa[x] == x ? x : fa[x] = finda(fa[x]); 
}
ll finde(ll x)
{ 
	return fe[x] == x ? x : fe[x] = finde(fe[x]); 
}
void mergea(ll x, ll y)
{
  fa[finda(y)] = finda(x);
}
void mergee(ll x, ll y)
{
  fe[finde(x)] = finde(y);
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin>>T;
	while(T--)
	{
		cin>>n;
		memset(b,0,sizeof(b)) ;
		for(int i=1;i<=n;i++)
		{
		    cin>>a[i];
		    fa[i]=i;
		    fe[i]=i;
		    if(i>=2)
		    {
		    	b[i-1].v=abs(a[i]-a[i-1]);
		    	b[i-1].f=i-1;
			}
		}
		sort(b+1,b+n,cmp);
		ans=0;
		cnt=1;
		for(int i=n-1;i>=1;i--)
		{
				while(b[cnt].v==i)
				{
					fro=finda(b[cnt].f);
					bac=finde(b[cnt].f+1);
					ans+=(b[cnt].f-fro+1)*(bac-b[cnt].f);
					mergea(b[cnt].f,b[cnt].f+1);
					mergee(b[cnt].f,b[cnt].f+1);
					cnt++;
				}
				an[i]=ans;
		}
		for(int i=1;i<=n-1;i++)
		{
			cout<<an[i]<<" ";
		}
		cout<<"\n";
	}
}
