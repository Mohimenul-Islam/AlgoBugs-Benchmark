#include <bits/stdc++.h>
using namespace std;

#define endl "\n"
#define S second
#define F first
#define PB push_back
#define all(x) x.begin(), x.end()

typedef long long ll;
typedef long double ld;

int find(ll x, vector<ll> &link)
{
    while (link[x] != x)
        x = link[x];
    return x;
}

bool unite(ll a, ll b, vector<ll> &link, vector<ll> &Size)
{
    a = find(a, link);
    b = find(b, link);
    if (a == b)
        return false;
    if (Size[a] < Size[b])
        swap(a, b);
    Size[a] += Size[b];
    link[b] = a;
    return true;
}

void solve()
{
    ll n;
    cin >> n;
    vector<ll> a(n);
    for (ll i = 0; i < n; i++)
        cin >> a[i];
    vector<ll> arr(n);
    arr[0] = 1e9;
    vector<vector<ll>> indx(n + 1);
    vector<ll> link(n), Size(n);
    for (ll i = 0; i < n; i++)
    {
        link[i] = i;
        Size[i] = 1;
    }
    for (int i = 1; i < n; i++)
    {
        arr[i] = abs(a[i] - a[i - 1]);
        indx[arr[i]].PB(i);
    }
    vector<ll> ans;
    ll t = 0;
    for (ll i = n - 1; i >= 1; i--)
    {
        for (auto &y : indx[i])
        {
            ll x = y - 1;
            x = find(x, link), y = find(y, link);
            t -= Size[x] * (Size[x] - 1) / 2;
            t -= Size[y] * (Size[y] - 1) / 2;
            unite(x, y, link, Size);
            y = find(y, link);
            t += Size[y] * (Size[y] - 1) / 2;
        }
        ans.PB(t);
    }
    reverse(all(ans));
    for (auto &i : ans)
        cout << i << " ";
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
        cout << endl;
    }
}
