#include <bits/stdc++.h>

using i64 = long long;

struct Point {
    int val, idx;
};

struct Pair {
    Point stt, end;
};

void solve() {
    int n;
    std::cin >> n;
    std::vector<int> a(n);
    for (int i = 0; i < n; i++) {
        std::cin >> a[i];
    }
    std::vector<int> L(n + 1, -1), R(n + 1, -1);
    std::vector<Pair> pa(n - 1);
    for (int i = 0; i < n - 1; i++) {
        pa[i].stt = {a[i], i};
        pa[i].end = {a[i + 1], i + 1};
    }
    std::sort(pa.begin(), pa.end(), [](const auto& p1, const auto& p2) {
        int len1 = std::abs(p1.stt.val - p1.end.val);
        int len2 = std::abs(p2.stt.val - p2.end.val);
        return len1 > len2;
    });

    std::vector<i64> ans(n + 1);
    auto add = [&](int l, int r, i64 v) {
        assert(l >= 1 && l < n);
        assert(r >= 1 && r < n);
        ans[l] += v;
        ans[r + 1] -= v;
    };
    for (int i = 0; i < n - 1; i++) {
        int l = pa[i].stt.idx;
        int r = pa[i].end.idx;
        int dif = std::abs(pa[i].end.val - pa[i].stt.val);
        // std::cerr << l << " " << r << " " << L[l] << " " << R[r] << "\n";
        if (L[l] != -1 && R[r] != -1) {
            add(1, dif, l - L[l] + 1);
            R[L[l]] = r;
            L[r] = L[l];
            l = L[l];
            add(1, dif, 1LL * (R[r] - r) * (r - l));
            L[R[r]] = l;
            R[l] = R[r];
            continue;
        }
        if (L[l] != -1) {
            add(1, dif, l - L[l] + 1);
            R[L[l]] = r;
            L[r] = L[l];
            // std::cerr << "after merge: " << L[l] << " " << R[L[l]] << "\n";
            continue;
        }
        if (R[r] != -1) {
            add(1, dif, R[r] - r + 1);
            L[R[r]] = l;
            R[l] = R[r];
            // std::cerr << "after merge: " << L[R[r]] << " " << R[r] << "\n";
            continue;
        }
        R[l] = r;
        L[r] = l;
        add(1, dif, 1);
    }
    // for (int i = 0; i < n; i++) {
    //     std::cerr << L[i] << " " << R[i] << "\n";
    // }
    for (int i = 1; i < n; i++) {
        ans[i] += ans[i - 1];
        std::cout << ans[i] << " \n"[i == n - 1];
    }
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int t;
    std::cin >> t;

    while (t--) {
        solve();
    }

    return 0;
}