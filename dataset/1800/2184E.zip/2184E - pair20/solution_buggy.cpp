#include <bits/stdc++.h>
using namespace std;

const int N = 2e5 + 7;
int parent[N] , Size[N];

void make_set (int v) {
	parent[v] = v;
	Size[v] = 1;
}

int find_set (int v) {
	if (v == parent[v]) return v;
	return parent[v] = find_set(parent[v]);
}

void union_sets (int a , int b) {
	a = find_set(a);
	b = find_set(b);

	if (a == b) return;
	if (Size[a] < Size[b]) swap(a , b);
	
	Size[a] += Size[b];
	parent[b] = a;
}

void solve() {
	int n; cin >> n;
	vector < int > p(n) , v(n);
	for (auto &i : p) cin >> i;
	for (int i = 0; i <= n; i++) make_set(i);

	vector < pair < int , int > > a(n);
	for (int i = 0; i < n - 1; i++)
		a[i] = make_pair(abs(p[i] - p[i + 1]) , i);
	sort(a.begin() , a.end());

	long long ans = 0;

	for (int k = n - 1; k >= 1; k--) {
		while (!a.empty() && a.back().first >= k) {

			int i = a.back().second;
			int pi = find_set(i) , pj = find_set(i + 1);

			//cout << Size[pi] << ' ' << Size[pj] << '\n';
			//cout << a.back().first << ' ';
			ans -= 1ll * Size[pi] * (Size[pi] - 1) / 2;
			ans -= 1ll * Size[pj] * (Size[pj] - 1) / 2;

			union_sets(i , i + 1);
			pi = find_set(i);

			ans += 1ll * Size[pi] * (Size[pi] - 1) / 2;

			a.pop_back();
		}
		v[k] = ans;
	}

	for (int i = 1; i < n; i++) cout << v[i] << ' '; cout << '\n';

}

signed main() {
 
	ios_base::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);

	int test = 1; cin >> test;
	while (test--) solve();

	return 0;
}
