#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
const int N=2e3+10;
const int INF=1e9;
const int mod=998244353;

int findr(int x,vector<int> &r) {
	if (r[x]==x) return x;
	return r[x]=findr(r[x],r);
}

ll cal(int l,vector<int> &r,vector<int> &siz) {
	int nowr=findr(l,r);
	int len=siz[nowr];
	return 1ll*len*(len-1)/2;
}

void solve() {
	int n;cin>>n;
	vector<int> a(n+1),r(n+1),siz(n+1,1);
	vector<ll> res(n+1);
	vector<vector<int>> d(n);
	for (int i=1; i<=n; i++) {cin>>a[i]; r[i]=i;}
	for (int i=1; i<n; i++) {
		int tem=abs(a[i+1]-a[i]);
		d[tem].push_back(i);
	}
	ll v=0;
	for (int i=n-1; i>0; i--) {
		for (auto l:d[i]) {
			v-=cal(l,r,siz);
			v-=cal(l+1,r,siz);
			int temr=findr(l+1,r);
			siz[temr]+=siz[l];
			r[l]=findr(l+1,r);
			v+=cal(l,r,siz);
		}
		res[i]=v;
	}
	for (int i=1; i<n; i++) cout<<res[i]<<" ";
	cout<<endl;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0); 
	cout.tie(0);

	int t=1;
	cin>>t;
	while (t--) 
		solve();
		
	return 0;
}