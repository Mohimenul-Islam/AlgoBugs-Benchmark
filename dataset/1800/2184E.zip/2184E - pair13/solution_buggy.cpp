#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
const int N=2e3+10;
const int INF=1e9;
const int mod=998244353;

int findr(int x,vector<int> &r) {
	if (r[x]==x) return x;
	return r[x]=findr(r[x],r);
}

void solve() {
	int n;cin>>n;
	vector<int> a(n+1),r(n+1);
	vector<ll> res(n+1);
	vector<bool> vis(n+1);
	vector<vector<int>> d(n);
	for (int i=1; i<=n; i++) {cin>>a[i]; r[i]=i;}
	for (int i=1; i<n; i++) {
		int tem=abs(a[i+1]-a[i]);
		d[tem].push_back(i);
	}
	set<int> l;
	for (int i=n-1; i>0; i--) {
		for (auto x:d[i]) {
			r[x]=x+1;
			l.insert(x);
		}
		vector<int> temr,era;
		for (auto x:l) {
			int now=findr(x,r);
			if (vis[now]) {era.push_back(x);continue;} 
			vis[now]=1;
			temr.push_back(now);
			int len=now-x+1;
			res[i]+=len*(len-1)/2;
		}
		for (auto x:era) l.erase(x);
		for (auto x:temr) vis[x]=0;
	}
	for (int i=1; i<n; i++) cout<<res[i]<<" ";
	cout<<endl;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0); 
	cout.tie(0);

	int t=1;
	cin>>t;
	while (t--) 
		solve();
		
	return 0;
}