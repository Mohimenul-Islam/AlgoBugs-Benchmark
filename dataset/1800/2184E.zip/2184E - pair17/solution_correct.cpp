#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define rep(i,a,n) for(int i=a;i<n;++i)
#define per(i,n,a) for(int i=n;i>=a;--i)
#define pb push_back
#define mp make_pair
#define all(v) v.begin(),v.end()
#define sz(a) ((int)a.size())
#define umap unordered_map
#define uset unordered_set
#define fi first
#define se second 
#ifdef i_am_noob
#define bug(...) cerr << "#" << __LINE__ << ' ' << #__VA_ARGS__ << ": ", _do(__VA_ARGS__)
template<typename T> void _do(vector<T> x){for(auto i: x) cerr << i << ' ';cerr << "\n";}
template<typename T> void _do(set<T> x){for(auto i: x) cerr << i << ' ';cerr << "\n";}
template<typename T> void _do(multiset<T> x){for(auto i: x) cerr << i << ' ';cerr << "\n";}
template<typename K, typename V> void _do(map<K,V> x){for(auto &[k,v] : x) {cerr << "(" << k << ":" << v << ") ";}cerr << "\n";}
template<typename T> void _do(unordered_set<T> x){for(auto i: x) cerr << i << ' ';cerr << "\n";}
template<typename T> void _do(T && x) {cerr << x << endl;}
template<typename T, typename ...S> void _do(T && x, S&&...y) {cerr << x << ", "; _do(y...);}
#else
#define bug(...) 777771449
#endif
typedef long long ll;typedef long double ld;typedef pair<int, int> pii; typedef pair<ll, ll> pll; typedef vector<int> vi; typedef vector<vi> vvi; typedef vector<ll> vl; typedef vector<vl> vvl;
using i64 = long long; using i128 = __int128_t;
template<class T, class U> bool chmin(T &a,U b){if(b<a){a=b;return 1;}else return 0;}
template<class T, class U> bool chmax(T &a,U b){if(a<b){a=b;return 1;}else return 0;}
__int128 gcd128(__int128 a, __int128 b) { while (b) { a %= b; std::swap(a, b); } return a; }
__int128 lcm128(__int128 a, __int128 b) {return a / gcd128(a, b) * b;}
const double eps=1e-8, PI=3.14159265; const int inf = 2143483508; const long long llinf=9223372036854775807;

template<class T> void print(T c) { for(auto v:c) {cout << v << " "; } cout << endl; }

void solve(int TEST) {
    int n; cin >> n;
    vi A(n),D(n-1); rep(i,0,n) { cin >> A[i]; }
    rep(i,0,n-1) { D[i]=abs(A[i]-A[i+1]); }
  	vector<vector<array<int,3>>> borders(n);
  	vi nxt(n-1),prv(n-1);
  	vector<int> stk;
  	for(int i=0;i<n-1;++i) {
  		while(!stk.empty() && D[stk.back()]>D[i]) { nxt[stk.back()]=i; stk.pop_back(); }
  		stk.pb(i);
  	}
  	while(!stk.empty()) { nxt[stk.back()]=(n-1); stk.pop_back(); }
  	for(int i=n-2;i>-1;--i) {
  		while(!stk.empty() && D[stk.back()]>D[i]) { prv[stk.back()]=(i); stk.pop_back(); }
  		stk.pb(i);
  	}
  	while(!stk.empty()) { prv[stk.back()]=(-1); stk.pop_back(); }
  	rep(i,0,n-1) {
  		array<int,3> tmp = {prv[i],i,nxt[i]};
  		borders[D[i]].pb(tmp);
  	}
  	vl DP(n);
  	per(v,n-1,1) {
  		if(v<n-1) DP[v] = DP[v+1];
  		ll sum = 0;
        int prvrgt=-1,prvi=-1;
  		for(array<int,3> trip: borders[v]) {
            // cout << trip[0] << " " << trip[1] << " " << trip[2] << endl;
            if(prvrgt==trip[2]) { trip[0]=prvi; }
  			sum+=1LL*(trip[1]-trip[0])*(trip[2]-trip[1]);
            prvrgt=trip[2],prvi=trip[1];
  		}
  		DP[v]+=sum;
  	}
  	for(int i=1;i<n;++i) { cout << DP[i] << " \n"[i+1==n]; }
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    //for interactive mode, comment ONLINE_JUDGE block
    #ifndef ONLINE_JUDGE
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
    #endif
    int Test=1; 
    cin >> Test;
    int T = Test;
    while(Test--){
        solve(T-Test);
    }
}