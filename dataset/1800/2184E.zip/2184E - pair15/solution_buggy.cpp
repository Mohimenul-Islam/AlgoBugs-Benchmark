#include<bits/stdc++.h>
using namespace std;

#define _line <<'\n'
#define _space <<" "<<
const int N=1e5+5;
int arr[N],si[N],par[N];
vector<int> poss[N], sols;
int sol=0;


int C(int x){
    return (x+1)*x/2;
}

int f(int x){
    if (par[x]==x) return x;
    par[x]=f(par[x]);
    return par[x];
}

void con(int a, int b){
    a=f(a); b=f(b);
    if (a==b) return;
    if (si[a]>si[b]) swap(a,b);
    sol-=C(si[a]);
    sol-=C(si[b]);
    par[a]=b; si[b]+=si[a];
    //cout << si[b] _line;
    sol+=C(si[b]);
    return;
}

int main(){

    int t; cin >> t;
    while (t--){
        int n; cin >> n;
        int a; cin >> a;
        for (int i=1; i<=n; i++){
            poss[i].clear();
        }
        arr[n-1]=0; arr[0]=0;
        for (int i=1; i<n; i++){
            int b; cin >> b;
            arr[i-1]=abs(a-b);
            si[i-1]=1; par[i-1]=i-1;
            poss[abs(a-b)].emplace_back(i-1);
            //cout << abs(a-b) _space i-1 _line;
            a=b;
        }

        sol=0; sols.clear();
        for (int k=n-1; k>=1; k--){

            for (int i : poss[k]){
                int z=0; sol+=1;
                if (i-1>=0 && arr[i-1]>=k){
                    con(i-1,i); z=1; //cout << i-1 _space i _line;
                }
                if (i+1<n && arr[i+1]>k){
                    con(i+1,i); z=1; //cout << i+1 _space i _line;
                }
                /*if (!z){
                    sol+=1;
                }*/
            }

            sols.emplace_back(sol);
            //cout _space k _space sol _line;
        }

        for (int i=sols.size()-1; i>=0; i--){
            cout << sols[i] << " ";
        } cout _line;

    }

}
