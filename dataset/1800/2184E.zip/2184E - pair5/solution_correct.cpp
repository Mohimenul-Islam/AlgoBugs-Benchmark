#include "bits/stdc++.h"
#include "ext/pb_ds/assoc_container.hpp"
#include "ext/pb_ds/tree_policy.hpp"
using namespace std;
using namespace __gnu_pbds;
typedef long long ll;
#define F first
#define S second
// #define endl '\n'
#define pb emplace_back
#define sqrt sqrtl
#define clr(A, Val) memset(A, Val, sizeof(A));
#define what_is(x) cerr << "->" << (#x) << " = " << x << endl
template <class x>
using multiordered_set = tree<x, null_type, less_equal<x>, rb_tree_tag,
                              tree_order_statistics_node_update>;
template <class x>
using ordered_set =
    tree<x, null_type, less<x>, rb_tree_tag, tree_order_statistics_node_update>;
const long long mod = 1e9 + 7, mod2 = 998244353, OO = 0x3f3f3f3f;
const long long lOO = 0x3f3f3f3f3f3f3f3f;
long long add(ll a, ll b, ll mod) { return ((a % mod) + (b % mod)) % mod; }
long long mul(ll a, ll b, ll mod) { return 1LL * (a % mod) * (b % mod) % mod; }
long long Ceil(ll a, ll b) { return ((ll)a + (ll)b - 1ll) / (ll)b; }
ll intlog(ll x, ll k) {
  ll answer;
  answer = __lg(k) / __lg(x);
  return answer;
}
ll calsum(ll st, ll ed) {
  if (st > ed) swap(st, ed);
  return (ll)((ll)((ll)ed - (ll)st + (ll)1) * (ll)((ll)ed + (ll)st)) / (ll)2;
}
template <typename T>
int32_t size_i(T &container) {
  return static_cast<int32_t>(container.size());
}
// Brazil <3
struct custom_hash {
  static uint64_t splitmix64(uint64_t x) {
    x += 0x9e3779b97f4a7c15;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;
    x = (x ^ (x >> 27)) * 0x94d049bb133111eb;
    return x ^ (x >> 31);
  }

  size_t operator()(uint64_t x) const {
    static const uint64_t FIXED_RANDOM =
        chrono::steady_clock::now().time_since_epoch().count();
    return splitmix64(x + FIXED_RANDOM);
  }
};
//->  U Sure?!
template <typename T1, typename T2>
using safe_map = unordered_map<T1, T2, custom_hash>;

template <typename T>
istream &operator>>(istream &istream, vector<T> &v) {
  for (auto &it : v) cin >> it;
  return istream;
}
template <typename T>
ostream &operator<<(ostream &ostream, vector<T> &C) {
  for (auto &it : C) cout << it << " ";
  return ostream;
}
// Think again?!
void ___() {
  int ____ = 0;
#ifndef ONLINE_JUDGE
  ____ = 1;
#endif
  if (____ == 0) {
    cin.tie(0)->sync_with_stdio(0);
  }
}
ll power(ll b, ll p, ll mod) {
  if (p == 0) return 1;
  ll temp = power(b, p / 2, mod);
  temp = mul(temp, temp, mod);
  if (p & 1) temp = mul(temp, b, mod);
  return temp;
}

template <int D, typename T>
struct Vec : public vector<Vec<D - 1, T>> {
  static_assert(D >= 1,
                "Vec sum = add(mul(op1, y, mod), sum, mod)tor dimension must "
                "be greater than zero!");
  template <typename... Args>
  Vec(int n = 0, Args... args)
      : vector<Vec<D - 1, T>>(n, Vec<D - 1, T>(args...)) {}
};
template <typename T>
struct Vec<1, T> : public vector<T> {
  Vec(int n = 0, const T &val = T()) : vector<T>(n, val) {}
};
struct chash {
  int operator()(pair<int, int> x) const { return x.first * 31 + x.second; }
};
int lcm(int a, int b) { return (a / __gcd(a, b)) * b; }
long long log_(ll x) { return __builtin_clzll(1ll) - __builtin_clzll(x); }
const int N = 5e5 + 100, BASE = 44, BASE2 = 45;

void __() {
  ll n;
  cin >> n;
  vector<ll> arr(n);
  cin >> arr;
  vector<ll> a;
  for (ll i = 1; i < n; ++i) a.pb(abs(arr[i - 1] - arr[i]));
  vector<ll> idx[n + 1];
  for (ll i = 0; i < n - 1; ++i) idx[a[i]].pb(i);
  // cout << a << endl;
  set<pair<ll, ll>> st;
  st.insert({0, n - 2});
  // st.insert({n - 1, n - 1});
  ll ans = calsum(0, n - 1);
  vector<ll> ansr;
  ansr.pb(ans);
  // cout << ans << endl;
  for (ll del = 1; del <= n - 2; del++) {
    for (auto idxs : idx[del]) {
      auto it = st.upper_bound({idxs, lOO});
      // cout << (*it).F << " " << (*it).S << endl;
      if (it == st.begin()) {
        cout << "aad" << endl;
        return;
      }
      --it;

      // cout << (*it).F << " " << (*it).S << endl;
      ll l = (*it).F, r = (*it).S;
      ans -= calsum(0, (*it).S - (*it).F + 1);
      // cout << ans << endl;
      //   it.F____ idxs  idxs_____it.S
      if (l <= idxs - 1) ans += calsum(0, (idxs - 1) - (*it).F + 1);
      // cout << ans << endl;
      if (idxs + 1 <= r) ans += calsum(0, (*it).S - (idxs + 1) + 1);
      // ll l = (*it).F, r = (*it).S;
      //  cout << ans << endl;
      st.erase(it);
      if (l <= idxs - 1) st.insert({l, idxs - 1});
      if (idxs + 1 <= r) st.insert({idxs + 1, r});
      // cout << ans << endl;
    }
    ansr.pb(ans);
    // cout << ans << endl;
  }
  cout << ansr << endl;
}

int main() {
  ___();
  ll TC = 1;
  cin >> TC;
  cout << fixed << setprecision(10);
  for (ll TCS = 1; TCS <= TC; ++TCS) {
    // cout << "Case " << TCS << ": ";
    __();
  }
  return 0;
}