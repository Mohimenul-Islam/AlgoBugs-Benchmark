#include <bits/stdc++.h>

#pragma GCC optimize("Ofast")
#pragma GCC optimize("unroll-loops")
using namespace std;
// #define int long long
// #define double long double


int getC(int x) {
    return x * (x - 1) / 2;
}

struct DSU {
    vector<int> p;
    vector<int> size;
    int sum = 0;

    DSU(int n) {
        p.resize(n + 1);
        size.resize(n + 1, 1);
        for (int i = 1; i <= n; i++) {
            p[i] = i;
        }
    }

    int get(int x) {
        return p[x] = x == p[x] ? p[x] : get(p[x]);
    }

    void Union(int x, int y) {
        x = get(x);
        y = get(y);
        sum -= getC(size[x]);
        sum -= getC(size[y]);
        if (size[x] > size[y]) {
            p[y] = x;
            size[x] += size[y];
            size[y] = 0;
            sum += getC(size[x]);
        } else {
            p[x] = y;
            size[y] += size[x];
            size[x] = 0;
            sum += getC(size[y]);
        }
    }
};

void Solve() {
    int n;
    cin >> n;
    vector<int> v(n + 1);
    for (int i = 1; i <= n; i++) {
        cin >> v[i];
    }
    DSU dsu(n);
    vector<vector<pair<int, int>>> c(n);
    for (int i = 2; i <= n; i++) {
        c[abs(v[i] - v[i - 1])].push_back({v[i], v[i - 1]});
    }
    vector<int> ans;
    for (int i = n - 1; i >= 1; i--) {
        for (int j = 0; j < c[i].size(); j++) {
            dsu.Union(c[i][j].first, c[i][j].second);
        }
        ans.push_back(dsu.sum);
    }
    reverse(ans.begin(), ans.end());
    for (int i = 0; i < ans.size(); i++) {
        cout << ans[i] << " ";
    }
    cout << endl;
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t = 1;
    cin >> t;
    while (t--) {
        Solve();
    }
    return 0;
}
