#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N = 1e5 + 10;
int f[N], res[N], siz[N];

void init(int x) {
    for(int i = 0; i < x; i++) {
        f[i] = i, siz[i] = 1;
    }
}

int find(int x) {
    return x == f[x] ? f[x] : f[x] = find(f[x]);
}

void merge(int a, int b) {
    int u = find(a);
    int v = find(b);
    if(u != v) {
        f[v] = u;
        siz[u] += siz[v];
    }
}

int cnt(int x) {
    return siz[x] * (siz[x] - 1) / 2;
}

void work() {
    int n; cin >> n;
    init(n);
    vector<vector<int>> difpos(n + 1);

    int pre = 0;
    for(int i = 0, x; i < n; i++) {
        cin >> x;
        if(i > 0) {
            difpos[abs(x - pre)].push_back(i - 1);
        }
        pre = x;
    }

    int cur = 0;
    for(int i = n - 1; i > 0; i--) {
        for(int s : difpos[i]) {
            int u = find(s);
            cur -= cnt(u);
            cur -= cnt(s + 1);
            merge(s, s + 1);
            cur += cnt(u);
        }
        res[i] = cur;
    }

    for(int i = 1; i < n; i++) {
        cout << res[i] << " \n"[i == n - 1];
    }
}

signed main() {
    ios::sync_with_stdio(0), cin.tie(0);
    int T; cin >> T;
    while(T--) work();
}