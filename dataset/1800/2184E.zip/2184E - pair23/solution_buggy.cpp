#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N = 1e5 + 10;
int r[N], l[N];
void init(int x) {
    for(int i = 0; i < x; i++) {
        r[i] = i,l[i] = i;
    }
}

int findr(int x) {
    return x == r[x] ? r[x] : r[x] = findr(r[x]);
}
int findl(int x) {
    return x == l[x] ? l[x] : l[x] = findl(l[x]);
}

void merge(int a, int b) {
    int u = findr(a);
    int v = findr(b);
    if(u != v) {
        r[u] = v;
    }

    u = findl(a), v = findl(b);
    if(v != u) {
        l[v] = u;
    }
}

void work() {
    int n; cin >> n;
    init(n);
    vector<int> a(n), res(n + 1);
    set<int> s;
    vector<vector<int>> difpos(n + 1);

    for(int i = 0; i < n; i++) {
        cin >> a[i];
        if(i > 0) {
            difpos[abs(a[i] - a[i - 1])].push_back(i - 1);
        }
    }
    for(int i = n - 1; i > 0; i--) {
        for(int i : difpos[i]) {
            int lf = findl(i), rf = i + 1;
            if(!s.count(lf)) s.insert(lf);
            if(s.count(rf)) s.erase(rf);
            merge(i, i + 1);
        }
        for(int sta : s) {
            int rf = findr(sta);
            int len = rf - sta + 1;
            res[i] += (len - 1) * len / 2;
        }
    }

    for(int i = 1; i < n; i++) {
        cout << res[i] << " \n"[i == n - 1];
    }
}

signed main() {
    ios::sync_with_stdio(0), cin.tie(0);
    int T; cin >> T;
    while(T--) work();
}