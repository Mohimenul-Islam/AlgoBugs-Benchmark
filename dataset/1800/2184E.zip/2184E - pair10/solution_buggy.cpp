/*
Author: Prajwal Shah
Language: C++
Final Year BTech IT
Walchand College of Engineering, Sangli
*/

//_________________________________________________________//
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define pajju             main
#define Prajwal           ios_base::sync_with_stdio(false);
#define Shah              cin.tie(NULL);
#define ll                long long
#define pb                push_back
#define mod               1000000007
#define ff                first
#define ss                second
#define pinf              1e16
#define ninf              -1e16
//_______________________________________________________//

using namespace std;
using namespace __gnu_pbds;
template<class T> using ordered_set =tree<T, null_type, less<T>, rb_tree_tag,tree_order_statistics_node_update> ;

/*----------------- Debugging Starts -------------------------------------------------*/

void __print(int x) {cerr << x;}
void __print(long x) {cerr << x;}
void __print(long long x) {cerr << x;}
void __print(unsigned x) {cerr << x;}
void __print(unsigned long x) {cerr << x;}
void __print(unsigned long long x) {cerr << x;}
void __print(float x) {cerr << x;}
void __print(double x) {cerr << x;}
void __print(long double x) {cerr << x;}
void __print(char x) {cerr << '\'' << x << '\'';}
void __print(const char *x) {cerr << '\"' << x << '\"';}
void __print(const string &x) {cerr << '\"' << x << '\"';}
void __print(bool x) {cerr << (x ? "true" : "false");}

template<typename T, typename V>
void __print(const pair<T, V> &x) {cerr << '{'; __print(x.first); cerr << ','; __print(x.second); cerr << '}';}
template<typename T>
void __print(const T &x) {int f = 0; cerr << '{'; for (auto &i: x) cerr << (f++ ? "," : ""), __print(i); cerr << "}";}
void _print() {cerr << "]\n";}
template <typename T, typename... V>
void _print(T t, V... v) {__print(t); if (sizeof...(v)) cerr << ", "; _print(v...);}
#ifndef ONLINE_JUDGE
#define debug(x...) cerr << "[" << #x << "] = ["; _print(x)
#else
#define debug(x...)
#endif

/*----------------- Debugging Ends -------------------------------------------------*/
/*----------------- Solution Starts Here -------------------------------------------------*/
/*
observation - 
if f(k) is possible for some subarray, then f(k - 1) is also true.
subarray is f(k) => every two adj elements have diff at least k.
if [L1,R1] is f(k) and let R1 + 1 exist, then abs(a[R1] - a[R1 + 1]) <= k

solution - 
lets start from k: n - 1  to 1 
because subarrays for k = n - 1 < subarrays for k = n - 2 and so on.
we can merge in each itteration of k.
we can use DSU for this.
DSU should also maintain number of components

*/

class DSU{
    public:
    vector<ll> parent, size;
    ll components;
    DSU(ll n){
        parent.resize(n);
        size.resize(n, 1);
        components = n;
        for(ll i = 0; i < n; i++){
            parent[i] = i;
        }
    }
    ll find(ll a){
        if(parent[a] == a) return a;
        return parent[a] = find(parent[a]);
    }
    void merge(ll a, ll b){
        a = find(a);
        b = find(b);
        if(a != b){
            if(size[a] < size[b]) swap(a, b);
            parent[b] = a;
            size[a] += size[b];
            components--;
        }
    }
    int getSize(ll a){
        return size[find(a)];
    }
};

void solve(){
    int n; cin >> n;
    vector<int>arr(n); for(auto &x: arr) cin >> x;
    map<int, vector<int>> mp;
    vector<int>ans(n + 1, 0);
    for(int i = 1; i < n; ++i){
        mp[abs(arr[i] - arr[i - 1])].push_back(i);
    }
    DSU dsu(n);
    int subCount = 0;
    for(int k = n - 1; k >= 1; --k){
        for(auto &idx: mp[k]){
            int sz1 = dsu.getSize(idx - 1);
            int sz2 = dsu.getSize(idx);
            subCount += sz1*sz2;
            dsu.merge(idx - 1, idx);

        }
        ans[k] = subCount;
    }
    for(int i = 1; i <= n - 1; ++i){
        cout << ans[i] << " ";
    }
    cout << "\n";

}
int pajju()
{
    Prajwal Shah;
    //#ifndef ONLINE_JUDGE
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
    //freopen("debug.txt", "w", stderr);
    //#endif
    int t;
    cin>>t;
    while(t--)
    {
        solve();
    }
    return 0;
}
