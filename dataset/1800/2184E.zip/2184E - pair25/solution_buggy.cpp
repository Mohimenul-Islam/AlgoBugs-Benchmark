#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ld = long double;
using vll = vector<ll>;
using pll = pair<ll, ll>;
using vpl = vector<pll>;
using vvl = vector<vll>;

#define sz(x) int((x).size())
#define all(a) a.begin(), a.end()
#define pb push_back
#define F first
#define S second
#define f(i,s,e) for(ll i=s;i<e;i++)
#define cf(i,s,e) for(ll i=s;i<=e;i++)
#define rf(i,s,e) for(ll i=s;i>=e;i--)

const ll INF = 1e18;
const ll MOD = 1e9 + 7;

ll t, n, m, k, a[100005], b, tot, ans;
string s; 

void solve(){
    cin>>n; 
    vpl dif;
    f(i, 0, n) cin>>a[i];
    f(i, 1, n) dif.pb({abs(a[i] - a[i-1]), i});
    sort(all(dif));

    set<ll> part, rev;
    part.insert(0); part.insert(n);
    rev.insert(-n); rev.insert(0);
    ll ans=n*(n-1)/2; ll pt=0;
    rf(i, n, 2){
        ll elim=n-i; 
        while(dif[pt].F == elim){
            auto p1=part.lower_bound(dif[pt].S); 
            auto p2=rev.lower_bound(-dif[pt].S); 
            ll len = *p1 + *p2; 
            ans -= (*p1 - dif[pt].S)*(dif[pt].S + *p2); 
            part.insert(dif[pt].S);
            rev.insert(-dif[pt].S); 
            pt++;
        }
        cout<<ans<<" "; 
    } cout<<"\n"; 
}

int main(){
    ios_base::sync_with_stdio(false); 
    cin.tie(NULL);

    cin>>t; 
    while(t--){
        solve();
    }

}