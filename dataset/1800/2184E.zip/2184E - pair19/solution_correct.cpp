#include <bits/stdc++.h>
using namespace std;
using vi=vector<int>;

void solve() {
    int n;
    cin>>n;
    vi a(n), diff(n-1), idx(n+1);
    vector<vector<int>> diff_map(n+1);
    for (int i=0; i<n; i++) {
        cin>>a[i]; 
        if(i>0) {
            diff[i-1]=abs(a[i]-a[i-1]);
            diff_map[diff[i-1]].push_back(i-1);
        }
    }
    set<int> s;
    s.insert(-1); s.insert(n-1);
    vector<long long> req(n+1, 0);
    req[0] = (1LL*n*(n-1))/2;
    for (int i=0; i<n-1; i++) {
        req[i+1] = req[i];
        for (int j=0; j<(int)(diff_map[i+1].size()); j++) {
            int x = diff_map[i+1][j];
            s.insert(x);
            auto it = s.insert(x).first;
            auto nxt = next(it);
            auto prv = prev(it);
            
            int low = *prv;
            int high = *nxt;
            
            long long clc = (1LL*(high-x)*(high-x-1)/2) + (1LL*(x-low)*(x-low-1)/2) - (1LL*(high-low)*(high-low-1)/2);
            req[i+1] += clc;
        }
    }
    
    for (int i=0; i<n-1; i++) {
        cout<<req[i]<<" ";
    }
    cout<<'\n';
    return;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0); 
    int t;
    cin>>t;
    while (t--) solve();
    return 0;
}