#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back

ll t, n, a[100007], d[100007];
ll par[100007], cnt[100007], bef[100007];
vector<ll> idx[100007];

ll root(ll a){
    if(par[a] == a) return a;
    return par[a] = root(par[a]);
}

void join(ll x, ll y){
    ll rx = root(x);
    ll ry = root(y);
    ll tmp = cnt[rx]+cnt[ry];
    par[rx] = ry; 
    cnt[rx] = tmp; cnt[ry] = tmp;
}

int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin >> t;
    while(t--){
        cin >> n;
        for(int i=1; i<=n; i++){
            par[i] = i; cnt[i] = 1;
            cin >> a[i];
        }
        for(int i=1; i<n; i++){
            d[i] = abs(a[i]-a[i+1]);
            idx[d[i]].pb(i);
        }
        vector<ll> ans;
        ll pref = 0;
        for(int i=n-1; i>=1; i--){
            for(auto x : idx[i]){
                ll rx = root(x);
                ll ry = root(x+1);
                if(rx == ry) continue;
                pref -= cnt[rx]*(cnt[rx]-1)/2;
                pref -= cnt[ry]*(cnt[ry]-1)/2;
                join(x, x+1);
                ll newrt = root(x);
                pref += cnt[newrt]*(cnt[newrt]-1)/2;
            }
            ans.pb(pref);
        }
        reverse(ans.begin(), ans.end());
        for(auto x : ans){
            cout << x << " ";
        }
        cout << endl;
        for(int i=0; i<=n; i++){
            idx[i].clear();
            d[i] = 0;
        }
    }
}