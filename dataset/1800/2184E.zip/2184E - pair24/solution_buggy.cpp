#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back

ll t, n, a[100007], d[100007];
ll par[100007], cnt[100007];
vector<ll> idx[100007];

ll root(ll a){
    if(par[a] == a) return a;
    return par[a] = root(par[a]);
}

void join(ll x, ll y){
    ll rx = root(x);
    ll ry = root(y);
    ll tmp = cnt[rx]+cnt[ry];
    par[rx] = ry; 
    cnt[rx] = tmp; cnt[ry] = tmp;
}

int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin >> t;
    while(t--){
        cin >> n;
        for(int i=1; i<=n; i++){
            par[i] = i; cnt[i] = 1;
            cin >> a[i];
        }
        for(int i=1; i<n; i++){
            d[i] = abs(a[i]-a[i+1]);
            idx[d[i]].pb(i);
        }
        vector<ll> ans;
        d[0] = -1; d[n] = -1;
        for(int i=n-1; i>=1; i--){
            for(auto x : idx[i]){
                if(d[x-1] >= i && root(x-1) != root(x)){
                    join(x-1, x);
                }
                if(d[x+1] >= i && root(x+1) != root(x)){
                    join(x+1, x);
                }
            }
            set<ll> cek; ll tmp = 0;
            for(auto x : idx[i]){
                ll rt = root(x);
                if(!cek.count(rt)){
                    tmp += cnt[rt]*(cnt[rt]+1)/2;
                    cek.insert(rt);
                }
            }
            ans.pb(tmp);
        }
        reverse(ans.begin(), ans.end());
        for(auto x : ans){
            cout << x << " ";
        }
        cout << endl;
        for(int i=0; i<=n; i++){
            idx[i].clear(); cnt[i] = 0; par[i] = i;
            d[i] = 0;
        }
    }
}