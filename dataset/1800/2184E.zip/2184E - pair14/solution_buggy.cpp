#include <bits/stdc++.h>
using namespace std;
#define int long long
#define ll long long
#define ld long double
#define mod 1000000007
//#define mod 998244353
#define INF (ll)1e18
#define endl '\n'
#define pii pair<int, int>
#define vi vector<int>
#define vb vector<bool>
#define vc vector<char>
#define vpii vector<pii>
#define vvi vector<vi>
#define vvc vector<vc>
#define fo(i,a,b) for(int i = a; i < b; i++)
#define rfo(i,b,a) for(int i = b; i >= a; i--)
#define foi(i,a,b,d) for(int i = a; i < b; i+=d)
#define fod(i,b,a,d) for(int i = b; i >= a; i-=d)
#define afo(it,v) for(auto &it : v)
#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define sort_second(all_v) sort(all_v, [](pii &a, pii &b) { return a.second < b.second; })
#define ya {cout<<"YES"<<endl; return;}
#define na {cout<<"NO"<<endl; return;}
#define ret(x) {show(x); return;}
#ifndef ONLINE_JUDGE
#define dbg(x) cerr << #x <<": "; _print(x); cerr << endl;
#else
#define dbg(x)
#endif
template <class T> void _print(T t) {cerr << t;}
template <class T, class V> void _print(pair <T, V> p) {cerr << "{"; _print(p.first); cerr << ","; _print(p.second); cerr << "}";}
template <class T> void _print(vector <T> v) {cerr << "[ "; for (auto i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(set <T> v) {cerr << "[ "; for (auto i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(multiset <T> v) {cerr << "[ "; for (auto i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(queue <T> v) {cerr << "[ "; while(!v.empty()) {_print(v.front()); cerr << " "; v.pop();} cerr << "]";}
template <class T, class V> void _print(map <T, V> v) {cerr << "[ "; for (auto i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T, class V> void _print(multimap <T, V> v) {cerr << "[ "; for (auto i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void read(T &x) {cin >> x;}
template <class T> void read(vector <T> &v) {for(auto &i:v) read(i);}
template <class T> void write(T t) {cout << t << ' ';}
template <class T> void show(T t) {cout << t << endl;}
template <class T> void show(vector <T> v) {for (auto i : v) cout << i << ' '; cout << endl;}
template <class T> void show(vector<vector<T>> v) {for (auto row:v){for (auto it:row) cout << it << ' '; cout << endl;}}
template <class T, class... V> void read(T& h, V&... t) {read(h); read(t...);}
template <class T, class... V> void write(T h, V... t) {write(h); write(t...);}

/**********CODE BEGINS HERE**********/


void solve()
{
    int n;
    read(n);

    vi arr(n); read(arr);

    vi v;
    for(int i = 1; i < n; i++) v.push_back(abs(arr[i] - arr[i-1]));

    dbg(v)

    map<int, set<pii>> mp;
    int x = 0, l = -1, r = -1;

    for(int i = 0; i < v.size(); i++) {
        if(x != v[i]) {
            if(x != 0) mp[x].insert({l,r});
            x = v[i];
            l = i;
            r = i;
        }
        else {
            r = i;
        }
    }

    mp[x].insert({l,r});

    for(auto &tmp: mp) {
        dbg(tmp.first)
        dbg(tmp.second)
    }

    // dbg((mp.lower_bound(1))->first)
    mp[-1].insert({-1,-1});

    set<pii> st;

    auto help = [&](pii pr, set<pii>& st) {
        st.insert(pr);
        auto it = st.find(pr);
        
        int cur_start = it->first;
        int cur_end = it->second;

        auto next_it = next(it);
        if (next_it != st.end()) {
            if (next_it->first == cur_end + 1) {
                cur_end = next_it->second;
                st.erase(next_it);
            }
        }

        it = st.find({it->first, it->second});
        if (it != st.begin()) {
            auto prev_it = prev(it);
            if (prev_it->second == cur_start - 1) {
                cur_start = prev_it->first;
                st.erase(prev_it);
            }
        }

        st.erase(it);
        st.insert({cur_start, cur_end});
        
    };

    auto func = [&](set<pii>& tmp, set<pii>& st) {
        for(const auto &pr : tmp) {
            help(pr, st);
        }
    };


    vi ans(n);
    auto it = (--mp.end());
    while(it != mp.begin()) {
        int k = it->first;
        set<pii> &tmp = it->second;
        dbg(tmp)

        func(tmp, st);
        
        dbg(k)
        dbg(st)

        int cnt = 0;
        auto prev = it;
        int prev_key = 0;
        if(prev != mp.begin()) prev_key = (--prev)->first;
        dbg(prev_key)

        for(auto &pr: st) {
            int m = pr.second - pr.first + 1;
            cnt += (m*(m+1))/2;
            dbg(cnt)
        }

    
        for(int i = prev_key + 1; i <= k; i++) ans[i] = cnt;

        --it;
    }

    ans.erase(ans.begin());
    ret(ans)

}

int32_t main()
{
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int tc; cin>>tc; while(tc--)
    solve();
    return 0;
}