#include<bits/stdc++.h>
#define x first
#define y second
#define endl "\n"
#define MAX INT_MAX
#define LMAX LLONG_MAX
#define ll long long
#define pii pair<int,int>
#define pdd pair<double,double>
#define ull unsigned long long
#ifndef ONLINE_JUDGE
#define debug(...) [](auto... a) { ((cout << a << ' '), ...) << endl; }(#__VA_ARGS__, ":", __VA_ARGS__)
#define debugv(v)                                     \
    do {                                              \
        cout << #v << " : {";                         \
        for (int qiuyu = 0; qiuyu < v.size(); ++qiuyu) { \
            cout << v[qiuyu];                          \
            if (qiuyu + 1 != v.size())                 \
                cout << ",";                          \
        }                                             \
        cout << "}" << endl;                          \
    } while (0)
#else
#define debug(...)
#define debugv(v)
#endif
using namespace std;
template < const int M = 1000000000 + 7 >
struct MInt {
    using LL = long long;
    int x;
    MInt(int x = 0) : x(norm(x)) {}
    MInt(LL x) : x(norm(x % M)) {}
    inline int norm(LL x) const {
        if (x < 0) x += M;
        if (x >= M) x -= M;
        return x;
    }
    inline MInt ksm(MInt x, LL y) const {
        return x ^= y;
    }
    inline int val() const {
        return x;
    }
    inline MInt operator - () const {
        return MInt(norm(M - x));
    }
    inline MInt inv() const {
        assert(x != 0 );
        return *this ^ (M - 2);
    }
    inline MInt& operator *= (const MInt& rhs) {
        x = LL(x) * rhs.x % M;
        return *this;
    }
    inline MInt& operator += (const MInt& rhs) {
        x = norm(x + rhs.x);
        return *this;
    }
    inline MInt& operator -= (const MInt& rhs) {
        x = norm(x - rhs.x);
        return *this;
    }
    inline MInt& operator /= (const MInt& rhs) {
        return *this *= rhs.inv();
    }
    inline MInt& operator ^= (LL y) {
        LL ans = 1;
        while (y) {
            if (y & 1) ans = ans * x % M;
            x = LL(x) * x % M;
            y >>= 1;
        }
        x = ans;
        return *this;
    }
    inline friend MInt operator * (const MInt& lhs, const MInt& rhs) {
        MInt res = lhs;
        res *= rhs;
        return res;
    }
    inline friend MInt operator + (const MInt& lhs, const MInt& rhs) {
        MInt res = lhs;
        res += rhs;
        return res;
    }
    inline friend MInt operator - (const MInt& lhs, const MInt& rhs) {
        MInt res = lhs;
        res -= rhs;
        return res;
    }
    inline friend MInt operator / (const MInt& lhs, const MInt& rhs) {
        MInt res = lhs;
        res /= rhs;
        return res;
    }
    inline friend MInt operator ^ (const MInt& lhs, LL y) {
        MInt res = lhs;
        res ^= y;
        return res;
    }
    inline friend istream& operator >> (istream& is, MInt& a) {
        LL v;
        is >> v;
        a = MInt(v);
        return is;
    }
    inline friend ostream& operator << (ostream& os, const MInt& a) {
        return os << a.val();
    }
};
using Z = MInt<>;
struct SafeProd {
    int zero = 0;
    Z prod = 1;
    void mul(const Z& x) {
        if (x.val() == 0) zero++;
        else prod *= x;
    }
    void div(const Z& x) {
        if (x.val() == 0) zero--;
        else prod /= x;
    }
    Z val() const {
        return zero ? Z(0) : prod;
    }
};

//正难则反
//注意题意中的隐含关系
//const int N=
const ll MOD=1e9+7;
const ll mod=998244353;

#define int long long 
signed main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int tt;
    cin>>tt;
    while(tt--){
        int n;
        cin>>n;
        vector<pii>d(n);
        vector<int>mp(n+1);
        vector<int>res(n+1);
        for(int i=1;i<=n;i++){
            cin>>mp[i];
        }
        for(int i=1;i<n;i++){
            int c=abs(mp[i]-mp[i+1]);
            d[i]={c,i};
        }
        set<int>st;
        sort(d.begin()+1,d.end());
        st.insert(0);
        st.insert(n);
        for(int i=1;i<n;i++){
            auto [l,r]=d[i];
            auto it=st.lower_bound(r);
            int a=*it;
            it=prev(it);
            int b=*it;
            res[l]+=(r-a)*(b-r);
            st.insert(r);
        }
        for(int i=n-2;i>=1;i--){
            res[i]+=res[i+1];
        }
        for(int i=1;i<n;i++){
            cout<<res[i]<<" ";
        }cout<<endl;
    }
    return 0;
}
