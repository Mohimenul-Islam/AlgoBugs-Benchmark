#include <bits/stdc++.h>
using namespace std;
#define ll long long int
void slv()
{
    int n;
    cin>>n;
    vector<ll>a(n);
    for(int i=0;i<n;i++)cin>>a[i];
    vector<int>lv(n-1);
    for(int i=1;i<n;i++)
    lv[i-1]=abs(a[i-1]-a[i]);
    vector<int>ans(n-1,0);
    stack<int>st;
    for(int i=0;i<n-1;i++)
    {
        while(!st.empty()&&lv[st.top()]>=lv[i])st.pop();
        int v=-1;
        if(!st.empty())v=st.top();
        ans[i]=i-v;
        st.push(i);
    }
    stack<int>st1;
    for(int i=n-2;i>=0;i--)
    {
        while(!st1.empty()&&lv[st1.top()]>lv[i])st1.pop();
        int v=n-1;
        if(!st1.empty())v=st1.top();
        ans[i]=(ans[i])*(v-i);
        // cout<<ans[i]<<", ";
        st1.push(i);
    }
    vector<ll>oa(n-1);
    for(int i=0;i<n-1;i++)
    {
        oa[lv[i]-1]+=ans[i];
        // cout<<oa[lv[i]-1]<<", ";
    }
    for(int i=n-3;i>=0;i--)
    {
        oa[i]=oa[i]+oa[i+1];
        // cout<<oa[i]<<" ";
    }
    for(ll i:oa)cout<<i<<" ";
    cout<<endl;
}
int main() {
	// your code goes here
	int t;
	cin>>t;
// 	cout<<t;
	while(t--){
	slv();}

}
