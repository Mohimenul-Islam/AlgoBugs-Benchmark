#include <bits/stdc++.h>
#define fi first
#define se second
#define all(x) x.begin(), x.end()
#define reset(h, v) memset(h, v, sizeof h)
#define For(i, a, b) for(int i = a; i <= b; ++i)
using namespace std;

#define int long long

const int MAXN = 5e5 + 5;

int n, a[MAXN], res[MAXN];

int c2n(int x) {
    return x * (x - 1) / 2;
}

struct disjoinset{
    int par[MAXN], cnt[MAXN];
    void init(){
        For(i,1,n){
            par[i] = -1;
        }
    }

    int find(int u){
        return par[u] < 0 ? u : par[u] = find(par[u]);
    }

    int size(int u){
        return -par[find(u)];
    }

    int calc(int u){
        return c2n(size(u));
    }

    int merge(int u,int v){
        u = find(u); v = find(v);
        if(u == v) return u;
        if(par[u] > par[v]) swap(u,v);
        par[u] += par[v];
        par[v] = u;
        return u;
    }
} dsu;

struct Edges{
    int u, v, w;
};
vector<Edges> E;

void Reset(int n) {
    for (int i = 1; i <= n; ++i) a[i] = 0, res[i] = 0;
    E.clear();
}

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    if(fopen("a.inp", "r")) {
        freopen("a.inp", "r", stdin);
        freopen("a.out", "w", stdout);
    }
    int tc; cin >> tc;
    while (tc--) {
        cin >> n;
        for (int i = 1; i <= n; ++i) cin >> a[i];
        for (int i = 1; i < n; ++i) {
            E.push_back({i, i + 1, abs(a[i] - a[i + 1])});
        }
        sort(all(E), [&](Edges &x, Edges &y){
            return x.w > y.w;
        });
        dsu.init();
        int ans = 0;
        for (auto [u, v, w] : E){
            ans -= dsu.calc(u), ans -= dsu.calc(v);
            dsu.merge(u, v);
            ans += dsu.calc(u);
            res[w] = ans;
        }
        for (int i = n - 1; i >= 1; --i)
            res[i] = max(res[i], res[i + 1]);
        for (int i = 1; i < n; ++i) cout << res[i] << ' '; cout << '\n';
        Reset(n);
    }
}
