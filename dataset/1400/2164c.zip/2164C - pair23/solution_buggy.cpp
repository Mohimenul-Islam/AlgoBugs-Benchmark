#include <bits/stdc++.h>
using namespace std;
#define ull unsigned long long
#define int long long
#define INT_MAX LLONG_MAX
#define INT_MIN LLONG_MIN
#define ll long long
#define F first
#define S second
#define vi vector<int>
#define pii pair<int, int>
#define getset __builtin_popcountll
#define vec vector
#define input(a)                       \
    for (int i = 0; i < a.size(); i++) \
    cin >> a[i]
#define print(a)     \
    for (auto i : a) \
    cout << i << ' '
#define all(a) a.begin(), a.end()
int fact[100];
vi build_spf(int n)
{
    vector<long long> spf(n + 1, -1);
    spf[0] = 0;
    spf[1] = 1;
    for (ll i = 2; i <= n; i++)
    {
        if (spf[i] == -1)
        {
            for (ll j = i; j <= n; j += i)
                if (spf[j] == -1)
                    spf[j] = i;
        }
    }
    return spf;
}
vector<long long> prime_factorization(long long n, vi &spf)
{
    vector<long long> pf;
    while (n > 1)
    {
        pf.push_back(spf[n]);
        n /= spf[n];
    }
    return pf;
}
long long gcd_by_mod(long long a, long long b)
{
    if (b == 0)
        return a;
    return gcd_by_mod(b, a % b);
}
long long gcd_by_subs(long long a, long long b)
{
    if (b == 0)
        return a;
    if (a < b)
        swap(a, b);
    return gcd_by_subs(b, a - b);
}
long long lcm(long long a, long long b)
{
    long long prod = (a * b);
    long long hcf = gcd_by_mod(a, b);
    return prod / hcf;
}
long long mod_add(long long a, long long b, ll m) { return ((a % m) + (b % m)) % m; }
ll mod_subs(ll a, ll b, ll m) { return ((a % m) - (b % m) + m) % m; }
ll mod_mul(ll a, ll b, ll m) { return ((a % m) * (b % m)) % m; }
ll mod_expo(ll a, ll b, ll m)
{
    if (b == 0)
        return 1;
    ll res = mod_expo(a, b / 2, m);
    res = mod_mul(res, res, m);
    if (b & 1)
        res = mod_mul(res, a, m);
    return res;
}
ll mod_inv(ll a, ll m) { return mod_expo(a, m - 2, m); }
ll mod_div(ll a, ll b, ll m) { return mod_mul(a, mod_inv(b, m), m); }
ll nCr(ll n, ll r, ll m) { return mod_div(fact[n], mod_mul(fact[r], fact[n - r], m), m); }
class DSU
{
    vector<int> parent, size;

public:
    DSU(int n)
    {
        parent.resize(n);
        iota(parent.begin(), parent.end(), 0);
        size.resize(n, 1);
    }
    void unite(int u, int v)
    {
        int upu = findP(u), upv = findP(v);
        if (upu == upv)
            return;
        if (size[upu] > size[upv])
        {
            parent[upv] = upu;
            size[upu] += size[upv];
        }
        else
        {
            parent[upu] = upv;
            size[upv] += size[upu];
        }
    }
    int findP(int u)
    {
        if (u == parent[u])
            return u;
        return parent[u] = findP(parent[u]);
    }
};

void solve(int ii,int tt)
{int n,m;
 cin>>n>>m;
 vi a(n),b(m),c(m); 
 input(a);
 input(b); 
 input(c);
 multimap<int,int> x;
 
 for(int i=0;i<m;i++)x.insert({b[i],c[i]});
 //sort(all(x)); 
 
 priority_queue<int,vi,greater<int>>pq;
 for(auto&z:a)pq.push(z); 
 int res= 0;
 while(!pq.empty()&&!x.empty())
 {
     auto top=pq.top(); 
     pq.pop() ;
     auto it = x.upper_bound(top); 
     //if(it==x.begin())continue; 
     //it=prev(it); 
     if(it==x.begin())
     {continue;
     }
     int mxr=x.begin()->second; 
     auto mxit=x.begin(); 
    for(auto iit=x.begin();iit!=it;iit++)
    {
        if(mxr<=iit->second)
        {
            if(mxr<iit->second)
            {
                mxit=iit; 
                mxr=iit->second; 
            }
            else {
                if(mxit->first<iit->first)
                {
                    mxit=iit;
                    mxr=iit->second; 
                }
            }
        }
    }
     if(mxit->second)pq.push(max((ll)(mxit->second),top));
        x.erase(mxit); 
     res++; 
}
 cout<<res<<'\n'; 
}
int32_t main()
{
    // ios_base::sync_with_stdio(0);
    // cin.tie(0);
    // cout.tie(0);
    int t = 1;
    cin >> t;
    // if(primes.size()=0)
    //     sieve(10000000); 
    for(int i=1;i<=t;i++)
        solve(i,t);
    return 0;
}