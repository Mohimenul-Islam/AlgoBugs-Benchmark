#include <bits/stdc++.h>
using namespace std;
using ll = long long;
int main() {
    ll t; cin >> t;
    while(t--){
        ll n,m; cin >> n >> m;
	    vector<ll> a(n); for(auto &x : a) cin >> x;
	    vector<ll> b(m); for(auto &x : b) cin >> x;
	    vector<ll> c(m); for(auto &x : c) cin >> x;
	
	    sort(a.begin(),a.end());
	
	    vector<pair<ll,ll>> v;
	    for(ll i=0; i<m; i++){
	        if(c[i]!=0) v.push_back({b[i],c[i]});
	    }
	    sort(v.begin(),v.end());
	   // ll sword = a[n-1];
	   // ll res = 0;
	    
	   // bool found = false;
	   // ll temp = -1;
	   // for(auto a : v){
	   //     ll monster = a.first, newsword = a.second;
	   //     if(sword<monster) break;
	   //     res++;
	        
	   //     if(!found && newsword>sword){
	   //         found = true;
	   //         temp = monster;
	   //     }
	   //     sword = max(sword,newsword);
	   // }
	    
	   // if(found){
	   //     for(ll i=0; i<n; i++){
	   //         if(a[i]>=temp){
	   //             a[i] = sword; break;
	   //         } 
	            
	   //     }
	   // }
	   // sort(a.begin(),a.end());
	   
	   multiset<ll> swords(a.begin(),a.end());
	   ll res = 0;
	   for(auto a : v){
	       auto b = swords.lower_bound(a.first);
	       if(b==swords.end()) break;
	       ll swordselected = *b;
	       swords.erase(swordselected);
	       swords.insert(max(swordselected,a.second));
	       res++;
	   }
	   a.assign(swords.begin(), swords.end());
	    
	    vector<ll> v2;
	    for(ll i=0; i<m; i++) if(c[i]==0) v2.push_back(b[i]);
	    sort(v2.begin(),v2.end());
	    
	    ll ptr1 = 0, ptr2 = 0;
	    
	    while(ptr1<n && ptr2<v2.size()){
	        if(a[ptr1]>=v2[ptr2]){
	            res++;
	            ptr1++; ptr2++;
	        }else{
	            ptr1++;
	        }
	    }
	
	    cout << res << "\n";
    }
	
}
