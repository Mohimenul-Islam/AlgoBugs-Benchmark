#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,m;
        cin>>n>>m;
        multiset<int>st;
        int num;
        for(int i=1;i<=n;i++)
        {
            cin>>num;
            st.insert(num);
        }
        vector<pair<int,int>>a(m+10),b;
        vector<int>c,d;//c损失 d无提升 b有提升
        for(int i=1;i<=m;i++) cin>>a[i].first;
        for(int i=1;i<=m;i++)
        {
            cin>>a[i].second;
            if(a[i].second==0)
            {
                c.push_back(a[i].first);
            }
            else
            {
                if(a[i].second<=a[i].first)
                {
                    d.push_back(a[i].first);
                }
                else
                {
                    b.push_back(a[i]);
                }
            }
        }
        int ans=0;
        for(int i=0;i<b.size();i++)
        {
            auto it=st.lower_bound(b[i].first);
            if(it!=st.end())
            {
                st.erase(it);
                st.insert(b[i].second);
                ans++;
            }
        }
        auto it=--st.end();
        num=*(it);
        for(int i=0;i<d.size();i++)
        {
            if(num>=d[i])
            {
                ans++;
            }
        }
        sort(c.begin(),c.end(),[](int x,int y){return x>y;});
        for(int i=0;i<c.size();i++)
        {
            it=st.end();
            it--;
            if((*it)>=c[i])
            {
                ans++;
                st.erase(it);
            }
            if(st.size()==0)
            {
                break;
            }
        }
        cout<<ans<<"\n";
    }
    return 0;
}