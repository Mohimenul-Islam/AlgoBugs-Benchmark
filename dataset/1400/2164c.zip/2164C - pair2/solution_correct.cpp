/*1 1
2
15
5
1 1
12
1
9
1 1
17
2
5
1 1
2
4
0
1 1
16
12
8
1 2
17
17 19
11 6
1 2
20
8 8
20 13
1 2
9
11 10
8 20
1 2
17
18 14
16 1
1 2
20
2 5
7 14
1 2
11
4 15
5 1
1 2
15
1 12
0 2
1 2
13
16 2
0 7
1 2
6
12 2
13 12
1 2
4
10 14
14 9
1 2
20
3 1
12 17
1 2
7
5 7
0 20
1 2
6
4 3
6 0
1 2
18
19 13
14 5
1 2
15
19 4
9 15
1 2
20
20 18
12 7
1 2
9
18 1
6 0
1 2
9
15 1
15 8
1 2
7
15 18
10 9
1 2
8
4 14
0 15
1 2
6
14 2
6 13
...
Participant's output
0
1
1
0
1
1
2
0
1
2
1
2
1
1
0
2
2
2
1
1
2
1
1
0
1
1
0
1
0
0
0
1
0
1
1
1
1
2
1
2
1
1
1
2
1
2
2
0
0
0
1
0
0
2
2
0
1
1
1
0
2
1
2
1
0
2
1
0
0
1
0
1
2
0
1
0
1
1
0
0
2
0
1
0
0
0
0
2
0
2
1
1
1
1
1
0
0
1
2
2
1
1
2
2
2
1
2
2
3
2
3
3
3
3
1
0
0
3
2
0
2
0
1
2
1
2
2
1
1
3
3
3
3
0
1
2
1
2
1
0
0
2
3
3
0
2
3
2
0
2
3
3
2
1
2
3
3
3
2
0
3
2
1
3
2
0
1
0
0
2
1...
*/
#include <bits/stdc++.h>
using namespace std;

int cmp(pair<int,int>x,pair<int,int>y)
{
    return x.first<y.first;
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,m;
        cin>>n>>m;
        multiset<int>st;
        int num;
        for(int i=1;i<=n;i++)
        {
            cin>>num;
            st.insert(num);
        }
        vector<pair<int,int>>a(m+10),b;
        vector<int>c,d;//c损失 d无提升 b有提升
        for(int i=1;i<=m;i++) cin>>a[i].first;
        for(int i=1;i<=m;i++)
        {
            cin>>a[i].second;
            if(a[i].second==0)
            {
                c.push_back(a[i].first);
            }
            else
            {
                if(a[i].second<=a[i].first)
                {
                    d.push_back(a[i].first);
                }
                else
                {
                    b.push_back(a[i]);
                }
            }
        }
        int ans=0;
        sort(b.begin(),b.end(),cmp);
        for(int i=0;i<b.size();i++)
        {
            auto it=st.lower_bound(b[i].first);
            if(it!=st.end())
            {
                st.erase(it);
                st.insert(max((*it),b[i].second));
                ans++;
            }
        }
        auto it=--st.end();
        num=*(it);
        for(int i=0;i<d.size();i++)
        {
            if(num>=d[i])
            {
                ans++;
            }
        }
        sort(c.begin(),c.end(),[](int x,int y){return x>y;});
        for(int i=0;i<c.size();i++)
        {
            it=st.end();
            it--;
            if((*it)>=c[i])
            {
                ans++;
                st.erase(it);
            }
            if(st.size()==0)
            {
                break;
            }
        }
        cout<<ans<<"\n";
    }
    return 0;
}