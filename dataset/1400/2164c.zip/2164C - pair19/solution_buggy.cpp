#include <bits/stdc++.h>
using namespace std;

#define int long long
using ll = long long;
#define INF (int)1e18
#define f first
#define s second
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
using vll = vector<long long>;
using vi = vector<int>;
using vc = vector<char>;
using vs = vector<string>;
ll MOD = 1e9+7;
constexpr int inf = 1e18;
#define pb push_back
#define pf push_front
#define rep1(i,n) for(int i=1;i<=(n);i++)
#define rep(i,n) for (int i=0;i<(n);i++)
mt19937_64 RNG(chrono::steady_clock::now().time_since_epoch().count());

const int MAX = 1e6 + 5;



void solve(){
    int n ,m;
    cin >> n >> m;

    vll a(n),b(m),c(m);
    rep(i,n)cin >> a[i];
    rep(i,m)cin >> b[i];
    rep(i,m)cin >> c[i];

    ll damage = *max_element(all(a));

    vector<pair<ll,ll>>v(m);
    rep(i,m){
        v[i] = {b[i],c[i]};

    }

    sort(all(v));

    int cnt =0 ;
    rep(i,m){
        if (v[i].f <= damage){
            cnt++;
            damage = max(damage,v[i].s);
        }

        //cout << v[i].f <<" "<<v[i].s<<"\n";
    }

    cout << cnt <<"\n";
}
int32_t main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int t =1;
    
    cin >> t;
    
    while(t--){
        solve();
    }
    return 0;
}