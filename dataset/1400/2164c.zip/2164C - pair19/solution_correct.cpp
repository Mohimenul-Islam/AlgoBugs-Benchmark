#include <bits/stdc++.h>
using namespace std;

#define int long long
using ll = long long;
#define INF (int)1e18
#define f first
#define s second
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
using vll = vector<long long>;
using vi = vector<int>;
using vc = vector<char>;
using vs = vector<string>;
ll MOD = 1e9+7;
constexpr int inf = 1e18;
#define pb push_back
#define pf push_front
#define rep1(i,n) for(int i=1;i<=(n);i++)
#define rep(i,n) for (int i=0;i<(n);i++)
mt19937_64 RNG(chrono::steady_clock::now().time_since_epoch().count());

const int MAX = 1e6 + 5;

struct Monster{
    int b,c;
};

bool compare(const Monster& a, const Monster& b){
    return a.b < b.b;
}

void solve(){
    int n ,m;
    cin >> n >> m;
    multiset<int>swords;

    rep(i,n){
        ll x;
        cin >> x;
        swords.insert(x);
    }

    vector<Monster> g1,g2;
    //in g1 store the c[i] > 0
    //g2 where c[i]<=0

    vll b(m),c(m);
    rep(i,m)cin >> b[i];
    rep(i,m)cin >> c[i];
    
    rep(i,m){
        if (c[i]>0){
            g1.pb({b[i],c[i]});
        }
        else g2.pb({b[i],0});
    }

    sort(all(g1),compare);
    sort(all(g2),compare);

    int ans = 0;

    for (auto& m : g1){
        //kill possible 

        auto it = swords.lower_bound(m.b);

        if (it!=swords.end()){
            int curr = *it;
            swords.erase(it);
            swords.insert(max(curr,m.c));
            ans++;
        }
    }


    vll final_swords(all(swords));

    int ptr = 0;

    for (auto& m: g2){
        while(ptr < final_swords.size() && final_swords[ptr] < m.b){
            ++ptr;
        }

        if (ptr < final_swords.size()){
            ++ans;
            ptr++;
        }
    }

    cout << ans <<"\n";
    
}
int32_t main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int t =1;
    
    cin >> t;
    
    while(t--){
        solve();
    }
    return 0;
}