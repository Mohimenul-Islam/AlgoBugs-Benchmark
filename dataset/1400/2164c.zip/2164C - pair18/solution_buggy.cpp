#include <bits/stdc++.h>
using namespace std;
#define ll long long

struct node {
    ll l,r;
    bool operator > (const node& other) const {
        if (l == other.l) return r < other.r;
        return l > other.l;
    };
};

void solve() {
    ll n,m;
    cin >> n >> m;

    priority_queue<ll,vector<ll>,greater<ll>> q1;
    priority_queue<node,vector<node>,greater<node> > q2;
    vector<ll> a(n),p;
    vector<node> b(m);
    for (int i=0 ; i<n ; i++) {
        cin >> a[i];
        q1.push(a[i]);
    }
    for (int i=0 ; i<m ; i++) cin >> b[i].l;
    for (int i=0 ; i<m ; i++) {
        cin >> b[i].r;
        if (b[i].r) q2.push({b[i].l,b[i].r});
        else p.push_back(b[i].l);
    }

    while (!q1.empty() && !q2.empty()) {
        ll w1 = q1.top();
        q1.pop();
        //cout << w1 << "    1 \n";
        auto [x,y] = q2.top();
        q2.pop();

        if (w1 >= x) {
            w1 = max(w1,y);
            q1.push(w1);
        }else {
            q2.push({x,y});
        }
    }

    sort(p.begin(),p.end());
    int t=0;
    while (!q1.empty() && t<p.size()) {
        ll w = q1.top();
        q1.pop();
        if (t<p.size() && w >= p[t]) {
            t++;
        }
    }

    ll ans = m - (q2.size() + p.size() - t) ;
    cout << ans << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int t=1;
    cin >> t;

    while (t--) {
        solve();
    }
    return 0;
}