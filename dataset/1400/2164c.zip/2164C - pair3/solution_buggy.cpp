#include<bits/stdc++.h>
using namespace std;
int n,m;
struct node{
    int b,c;
};
void solve(){
    cin>>n>>m;
    multiset<int> a;
    vector<node> b(m);
    int x;
    for(int i=0;i<n;i++)cin>>x,a.insert(x);
    for(int i=0;i<m;i++)cin>>b[i].b;
    for(int i=0;i<m;i++)cin>>b[i].c;
    sort(b.begin(),b.end(),[](const node & x,const node & y){
        return x.b<y.b;
    });
    int cnt=0;
    for(int i=0;i<m;i++){
        if(a.empty())break;
        auto t=a.lower_bound(b[i].b);
        if(t!=a.end()){
            int val=*t;
            a.erase(t);
            if(b[i].c!=0){
                int num=max(val,b[i].c);
                a.insert(num);
            }
            cnt++;
        }
    }
    cout<<cnt<<'\n';
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin>>t;
    while(t--)solve();
    return 0;
}