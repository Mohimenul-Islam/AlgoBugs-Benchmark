#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using vi = vector<ll>;

void solve1()
{
    ll n, m;
    cin >> n >> m;

    vi a(n), b(m), c(m);
    for (auto &x : a)
        cin >> x;
    for (auto &x : b)
        cin >> x;
    for (auto &x : c)
        cin >> x;
    multiset<int> st(a.begin(), a.end());

    vector<pair<int, int>> v;
    vi alone;
    for (int i = 0; i < m; i++)
    {
        if (c[i] > 0)
            v.push_back({b[i], c[i]});
        else
            alone.push_back(b[i]);
    }
    sort(v.begin(), v.end());

    int monsters = 0;

    for (int i = 0; i < v.size(); i++)
    {
        auto it = st.lower_bound(v[i].first);
        if (it != st.end())
        {
            monsters++;
            int val = *it;
            st.erase(it);
            st.insert(max(val, v[i].second));
        }
    }

    for (int i = 0; i < alone.size(); i++)
    {
        auto it = st.lower_bound(alone[i]);
        if (it != st.end())
        {
            monsters++;
            st.erase(it);
        }
    }

    cout << monsters << endl;
}

void solve2()
{
}

void solve3()
{
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ll t;
    cin >> t;
    while (t--)
        solve1();
    return 0;
}