#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using vi = vector<ll>;

void solve1()
{
    ll n, m;
    cin >> n >> m;

    vi a(n), b(m), c(m);
    for (auto &x : a)
        cin >> x;

    for (auto &x : b)
        cin >> x;
    for (auto &x : c)
        cin >> x;
    sort(a.begin(), a.end());
    ll monsters = 0;
    vector<pair<int, int>> v;
    for (int i = 0; i < m; i++)
    {
        if (c[i] > 0)
            v.push_back({b[i], c[i]});
    }
    sort(v.begin(), v.end());

    vi temp;
    for (int i = 0; i < m; i++)
    {
        if (c[i] == 0)
            temp.push_back(b[i]);
    }
    int sword = a[n - 1];
    sort(temp.begin(), temp.end());
    for (int i = 0; i < v.size(); i++)
    {
        if (v[i].first <= sword)
        {
            monsters++;
            sword = max(sword, v[i].second);
        }
        else
            break;
    }

    // now i have the sword as the biggest element right so
    a[n - 1] = sword;
    int ptr = 0;
    for (int i = 0; i < n && ptr < temp.size(); i++)
    {
        if (a[i] >= temp[ptr])
        {
            monsters++;
            ptr++;
        }
    }

    cout  << monsters << endl;
}

void solve2()
{
}

void solve3()
{
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ll t;
    cin >> t;
    while (t--)
        solve1();
    return 0;
}