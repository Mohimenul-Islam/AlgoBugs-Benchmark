#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;
typedef long long ll;
#define FAST_IO ios_base::sync_with_stdio(false); cin.tie(NULL);
#define yes cout << "Yes\n"
#define no cout << "No\n"
#define Oset tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update>
ll const inf = 1e17+1;
ll const M = 1e5+10;
ll const N = 1e6;
const int mod = 1e9+7;
ll dx[8]={-1,0,1,0,1,-1,-1,1};
ll dy[8]={0,1,0,-1,1,-1,1,-1};

ll gcd(ll a, ll b)
{
    return b==0 ? a : gcd(b,a%b);
}  

void solve(int te) {
    // cout << "Case #" << te << ": ";
    ll n,m; cin>>n>>m;
    multiset<ll> h;
    for(ll i=0;i<n;i++) {
        ll x; cin>>x;
        h.insert(x);
    }
    vector<pair<ll,ll>> health(m);
    for(ll i=0;i<m;i++) {
       cin>>health[i].first>>health[i].second;
    }

    vector<ll> c0;
    vector<pair<ll,ll>> c1;
    for(ll i=0;i<m;i++) {
        ll s = health[i].first;
        ll c = health[i].second;
        if(c != 0) {
            c1.push_back({s,c});
        } else c0.push_back(s);
    }

    sort(c0.begin(),c0.end());
    sort(c1.begin(),c1.end(), [&] (const pair<ll,ll> a, const pair<ll,ll> b) {
        if(a.first == b.first)return a.second > b.second;
        return a.first < b.first;
    });

    ll cnt = 0;
    for(auto c : c1) {
        auto it = h.lower_bound(c.first);
        if(it!=h.end()) {
            ll cur = *it;
            h.erase(it);
            h.insert(max(cur,c.second));
            cnt++;
        }
    }

    for(auto c : c0) {
        auto it = h.lower_bound(c);
        if(it != h.end()) {
            h.erase(it);
            cnt++;
        }
    }
    cout<<cnt<<endl;
};      
        
int main()
{
    FAST_IO
    // #ifndef ONLINE_JUDGE
    // freopen("input.txt","r",stdin);
    // freopen("output.txt","w",stdout);
    // // #endif
    int T;
    cin >> T ;
    for(int t = 1; t <= T; t++)solve(t);
    // solve(1);
}













