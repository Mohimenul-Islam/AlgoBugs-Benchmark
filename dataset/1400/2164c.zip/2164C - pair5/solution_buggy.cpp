/* **Ujjwal Khanna** */
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define mod 1000000007
#define vi vector<int>
#define vl vector<long long>
#define vc vector<char>
float log_a_to_base_b(ll a, ll b){
    return (float) log2(a)/log2(b);
}
ll gcd(ll a,ll b){if(b == 0)return a;return gcd(b, a % b);}
ll lcm(ll a, ll b){return (a/gcd(a,b)*b);}
vector<bool> comp(1e5+1);
vector<int> primes;
void sieve(){
    for(int i=2; i*i<=1e5; i++)
        if(!comp[i])
            for(int j=i*i; j<=1e5; j+=i)
                comp[j] = true;
    for(int i=2; i<=1e5; i++)
        if(!comp[i])
            primes.push_back(i);
}
class DisjointSet {
    vector<int> rank, parent, size;
public:
    DisjointSet(int n) {
        rank.resize(n + 1, 0);
        parent.resize(n + 1);
        size.resize(n + 1);
        for (int i = 0; i <= n; i++) {
            parent[i] = i;
            size[i] = 1;
        }
    }
    int findUPar(int node) {
        if (node == parent[node])
            return node;
        return parent[node] = findUPar(parent[node]);
    }
    void unionByRank(int u, int v) {
        int ulp_u = findUPar(u);
        int ulp_v = findUPar(v);
        if (ulp_u == ulp_v) return;
        if (rank[ulp_u] < rank[ulp_v]) {
            parent[ulp_u] = ulp_v;
        }
        else if (rank[ulp_v] < rank[ulp_u]) {
            parent[ulp_v] = ulp_u;
        }
        else {
            parent[ulp_v] = ulp_u;
            rank[ulp_u]++;
        }
    }
    void unionBySize(int u, int v) {
        int ulp_u = findUPar(u);
        int ulp_v = findUPar(v);
        if (ulp_u == ulp_v) return;
        if (size[ulp_u] < size[ulp_v]) {
            parent[ulp_u] = ulp_v;
            size[ulp_v] += size[ulp_u];
        }
        else {
            parent[ulp_v] = ulp_u;
            size[ulp_u] += size[ulp_v];
        }
    }
};
struct cmp {
    bool operator()(pair<int,int> a, pair<int,int> b) {
        if(a.first == b.first)
            return a.second < b.second;
        return a.first > b.first;
    }
};
void solve() {
    int n,m;
    cin>>n>>m;
    vi a(n),b(m),c(m);
    for(int i=0;i<n;i++)    cin>>a[i];
    for(int i=0;i<m;i++)    cin>>b[i];
    for(int i=0;i<m;i++)    cin>>c[i];

    priority_queue<int,vector<int>,greater<int>> swords;
    priority_queue<pair<int,int>, vector<pair<int,int>>, cmp> monsters;
    for(int i=0;i<n;i++)
        swords.push(a[i]);
    for(int i=0;i<m;i++)
        monsters.push({b[i],c[i]});
    

    int kills=0;
    while(!swords.empty()){
        if(monsters.empty())    break;
        int sword = swords.top();
        swords.pop();
        pair<int,int> monster = monsters.top();
        if(monster.first <= sword){
            monsters.pop();
            kills++;
            //cout<<monster.first<<" "<<monster.second<<endl;
            if(monster.second > 0)
                swords.push(max(sword,monster.second));
        }
    }
    cout<<kills<<endl;
}
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    //sieve();
    ll test;
    cin >> test;
    while (test--) {
        solve();
    }
    return 0;
}