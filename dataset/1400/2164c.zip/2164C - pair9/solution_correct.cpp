#include<bits/stdc++.h>
#define ppi pair<int,int>
#define pb push_back
using namespace std;
#define int long long int

int powe(int n, int count , int x)
{
    int ans = 1;
    if (count == 0)
        return ans;
    else
        if(count%2)
        {
            int y = powe(n , count/2 , x)%x;
            y = (y*y)%x;
            return (n*y)%x;
        }
        int y = powe(n , count/2 , x)%x;
        y = (y*y)%x;
        return y;
}

static bool cmpr(ppi &a , ppi &b) {
    if (a.second == 0 && b.second != 0)
        return false;

    if (a.second != 0 && b.second == 0)
        return true;
    return a < b;     
}

void solve(){
    int n , m; cin>>n>>m;
    multiset<int>s; vector<int> a(m) , c(m); for(int i=0;i<n;i++) {
        int x; cin>>x;
        s.insert(x);
    }

    for(int i=0;i<m;i++) cin>>a[i];
    for(int i=0;i<m;i++) cin>>c[i];

    vector<ppi>v; for(int i=0;i<m;i++) {
        v.pb({a[i] , c[i]});
    }
    sort(v.begin() , v.end() , cmpr);

    int ans = 0;
    for(auto p:v) {
        auto it = s.lower_bound(p.first);
        if(it == s.end()) continue;
        
        ans++;
        int val = max((*it) , p.second);
        s.erase(it);         
        if(p.second == 0) {
            continue;
        }
        s.insert(val);
    }

    cout<<ans<<endl;
    //cout<<tmp<<endl;
}

signed main()
{
    int t=1; cin>>t;
    while(t--)
    {
        solve();
    }
}
//30 50 20