#include <bits/stdc++.h>
# define ll long long
# define ull unsigned long long
# define fr(i, n) for (int i = 0; i < n; i++)
# define fr1(i, n) for (int i = 1; i <= n; i++)
# define fri(j, i, n) for (int j = i; j < n; j++)
# define all(x) x.begin(), x.end()
# define pb push_back
# define endl '\n'
# define int long long


using namespace std;
bool cmp(pair<int, int> a, pair<int, int> b) {
    if (a.second == 0 && b.second == 0) {
        return a.first < b.first;
    }
    if (a.second == 0) {
        return false;
    }
    if (b.second == 0) {
        return true;
    }
    if (a.first != b.first) {
        return a.first < b.first;
    }
    return a.second > b.second;
}
void solve() {
    int n, m;
    cin >> n >> m;
    vector<pair<int, int>> b(m);
    multiset<int> a;
    fr(i, n) {
        int x;
        cin >> x;
        a.insert(x);
    }
    fr(i, m) {
        cin >> b[i].first;
    }
    fr(i, m) {
        cin >> b[i].second;
    }
    sort(all(b), cmp);
    int count = 0;
    fr(i, m) {
        auto it = a.lower_bound(b[i].first);
        if (it != a.end()) {
            count++;
            int x = *it;
            a.erase(it);
            if (b[i].second > 0) {
                a.insert(max(b[i].second, x));
            }
        }
    }
    cout << count << endl;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}