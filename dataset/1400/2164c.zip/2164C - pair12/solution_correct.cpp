#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define vi vector<int>
#define forall(it, v) for(auto it = v.begin(); it != v.end(); it++)
// ¿Tengo varias formas de avanzar + quiero el mejor resultado + puedo reutilizar resultados?” “desde dp[i] actualizo el futuro”
void solve() {
	int n; cin >> n;
	int m; cin >> m;
	multiset<int>s;
	multiset<pair<int, int>>mc;
	multiset<int>m0;
	
	for(int i = 0; i < n; i++){
		int a; cin >> a;
		s.insert(a);
	}
	
	vector<pair<int, int>>v(m);
	for(int i = 0; i < m; i++){
		int a; cin >> a;
		v[i].first = a;
	}
	
	for(int i = 0; i < m; i++){
		int a; cin >> a;
		v[i].second = a;
	}
	
	for(auto x : v){
		if(x.second > 0){
			mc.insert(x);
		}else{
			m0.insert(x.first);
		}
	}
	
	ll cont = 0;
	
	for(auto it = mc.begin(); it != mc.end(); it++){
		int hl = it->first;
		int c = it->second;
		auto it2 = s.lower_bound(hl);
		if(it2 == s.end()){
			break;
		}
		cont++;
		if(c > *it2){
			s.erase(it2);
			s.insert(c);
		}
	}
	
	for(auto it = m0.begin(); it != m0.end(); it++){
		
		if(s.empty()) break;
		
		auto aux = s.lower_bound(*it);
		if(aux == s.end()) break;
		cont++;
		s.erase(aux);
	}
	cout   << cont << endl;
	
	
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	
	int t;
	cin >> t;
	while (t--) solve();
}






