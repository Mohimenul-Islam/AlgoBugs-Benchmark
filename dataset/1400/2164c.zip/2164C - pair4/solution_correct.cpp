//JAY MAA TARINI MAA
//       .  .   .  .
//     .      .      .
//     .             .
//      .           .
//        .       .
//          .   .
//            .
#include <bits/stdc++.h>
using namespace std;
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
 
typedef __gnu_pbds::tree<int, __gnu_pbds::null_type, less<int>, __gnu_pbds::rb_tree_tag, __gnu_pbds::tree_order_statistics_node_update> ordered_set;
#define ll long long
#define pb push_back
#define cy cout << "YES\n"
#define cn cout << "NO\n"
#define c1 cout << "-1\n"
#define all(x) x.begin(), x.end()
#define re(x) x.rbegin(), x.rend()
#define F first
#define S second
#include <cmath>    
#include <bitset> 
#include<iomanip>
#define IOS                  \
  ios::sync_with_stdio(0); \
    cin.tie(0);              \
 cout.tie(0);
   int mod = 1e9 + 7;
string x="abcdefghijklmnopqrstuvwxyz";
string DTB(int n) {
    int len = (int)(log2(n));
    return bitset<32>(n).to_string();
}
int msb(int x){
    int c=0;
    while(x>1){
        c++;
        x/=2;
    }
    return c;
}
ll power(int x,int y){
    ll ml=1;
    for(int i=0;i<y;i++)ml*=x;
    return ml;
}
ll fac(int x){
    ll ml=1;
    for(int i=1;i<=x;i++)ml=((ml%mod)*(i%mod))%mod;
    return ml;
}
ll ncr(int n,int r){
    ll ml=1;
    for(int i=0;i<r;i++){
        ml*=(n-i);
        ml/=(i+1);
    }
    return ml;
}
ll bsmn(vector<ll>&v,ll x,ll y,ll val,ll o){
    int temp=-1;
    while(x<=y){
        int mid=x+(y-x)/2;
        if(val<=v[mid]-o){
            temp=mid;
            y=mid-1;
        }
        else x=mid+1;
    }
    return temp;
}
ll bsmx(vector<ll>&v,ll x,ll y,ll val,ll o){
    int temp=-1;
    while(x<=y){
        int mid=x+(y-x)/2;
        if(val>=v[mid]-o){
            temp=mid;
            x=mid+1;
        }
        else y=mid-1;
    }
    return temp;
}
//we can compare vectors like strings.... 
//karsadi karna padega
//10^18----->>>> 60 bits 
//always try first to simplfy with given data in the question.
//always try for good bruteforcing---->>>(creating formula,thinking for O(2n) rather than O(n))
//don't always rely on greedy 
//use greedy while making better choices 
//work more on impacts rather than wholical problem
//kabhi kabhi solutions ko ranges me shochna better hota hai
//small parameters pe jyada focus karna hai as usse problem ka time complexity acche se handle hota hai
int main() {
    IOS;
	int t; cin>>t;
	while(t--){
	    int n,m; cin>>n>>m;
	    int a[n],b[m],c[m];
	    for(int i=0;i<n;i++)cin>>a[i];
	    for(int i=0;i<m;i++)cin>>b[i];
	    for(int i=0;i<m;i++)cin>>c[i];
	    multiset<int>pq;
	    vector<pair<int,int>>v;
	    vector<int>v1;
	    for(int i=0;i<m;i++){
	        if(c[i]>0)v.pb({b[i],c[i]});
	        else{
	            v1.pb(b[i]);
	        }
	    }
	    for(int i=0;i<n;i++){
	        pq.insert(a[i]);
	    }
	    sort(all(v)); sort(all(v1));
	    auto it=pq.begin();
	    int ans=0;
	    for(int i=0;i<v.size()&&it!=pq.end();i++){
	        it=pq.lower_bound(v[i].F);
	        if(it==pq.end())break;
	        else{
	            int val=*it;
	            pq.erase(it);
	            pq.insert(max(v[i].S,val));
	            ans++;
	        }
	    }
	    int j=0;
	    for(auto x:pq){
	        if(j<v1.size()&&v1[j]<=x){
	            ans++;
	            j++;
	        }
	    }
	    cout<<ans<<"\n";
	}
}
