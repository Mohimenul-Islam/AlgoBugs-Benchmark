#include <iostream>
#include <set>
#include <vector>
#include <algorithm>

static bool Compare(const std::pair<int, int>& a, const std::pair<int, int>& b)
{
	if (a.second == 0 && b.second == 0) {
		return a.first <= b.first;
	}
	if (a.second != 0 && b.second == 0) {
		return true;
	}
	if (a.second == 0 && b.second != 0) {
		return false;
	}
	if (a.first == b.first) {
		return a.second <= b.second;
	}
	return a.first < b.first;
}

static void Solve()
{
	int n, m;
	std::cin >> n >> m;
	std::multiset<int> a;
	for (int i = 0; i < n; ++i) {
		int x;
		std::cin >> x;
		a.insert(x);
	}
	int* b = new int[m];
	for (int i = 0; i < m; ++i) {
		std::cin >> b[i];
	}
	int* c = new int[m];
	for (int i = 0; i < m; ++i) {
		std::cin >> c[i];
	}
	std::vector<std::pair<int, int>> monster(m);
	for (int i = 0; i < m; ++i) {
		monster[i] = std::make_pair(b[i], c[i]);
	}
	delete[] b;
	delete[] c;
	int ans = 0;
	std::sort(monster.begin(), monster.end(), Compare);
	for (const auto& [b, c] : monster) {
		auto it = std::lower_bound(a.begin(), a.end(), b);
		if (it == a.end()) {
			break;
		}
		int x = *it;
		++ans;
		a.erase(it);
		if (c > 0) {
			a.insert(std::max(x, c));
		}
	}
	std::cout << ans << std::endl;
}

int main()
{
	int t;
	std::cin >> t;
	while (t--) {
		Solve();
	}
	return 0;
}