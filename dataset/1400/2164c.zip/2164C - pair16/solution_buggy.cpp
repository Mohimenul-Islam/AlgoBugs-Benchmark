#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> PII;
const int N = 2e5 + 7;
bool cmp(PII a, PII b)
{
    if(a.second==b.second)
        return a.first > b.first;
    return a.second < b.second;
}
void sol()
{
    int n, m, cnt = 0;
    cin >> n >> m;
    vector<int> b;
    vector<PII> c;
    multiset<int> a;
    int x;
    for (int i = 0; i < n; i++)
    {
        cin >> x;
        a.emplace(x);
    }
    for (int i = 0; i < m; i++)
    {
        cin >> x;
        b.emplace_back(x);
    }
    for (int i = 0; i < m; i++)
    {
        cin >> x;
        c.emplace_back(x,b[i]);
    }
    sort(c.begin(), c.end(), cmp);
    for (int kk = 0; kk < m; kk++)
    {
        auto &[x, y] = c[kk];
        if(x==0)
            continue;
        auto it = a.lower_bound(y);
        if (it != a.end())
        {
            int tem = *it;
            a.erase(it);
            cnt++;
            a.emplace(max(tem, x));
        }
    }
    for (int kk = 0; kk < m; kk++)
    {
        auto &[x, y] = c[kk];
        if (x != 0)
            continue;
        auto it = a.lower_bound(y);
        if (it != a.end())
        {
            int tem = *it;
            a.erase(it);
            cnt++;
            a.emplace(max(tem, x));
        }
    }
    cout << cnt << endl;
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int t;
    cin >> t;
    while (t--)
    {
        sol();
    }
}