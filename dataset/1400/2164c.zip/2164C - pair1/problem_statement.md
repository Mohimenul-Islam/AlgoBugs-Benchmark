# C. Dungeon

**Time limit:** 2 seconds
**Memory limit:** 256 megabytes

## Problem Statement

You are now in a dungeon with $$$n$$$ swords, facing $$$m$$$ monsters.

The damage of the $$$i$$$-th sword is $$$a\_i$$$, and the life value of the $$$i$$$-th monster is $$$b\_i$$$. A sword with damage $$$x$$$ can kill a monster with life value $$$y$$$ if and only if $$$x \\ge y$$$.

After killing the $$$i$$$-th monster with a sword of damage $$$x$$$, this sword disappears. Then, if $$$c\_i \\gt 0$$$, you will obtain a new sword with damage $$$\\max(x, c\_i)$$$; otherwise, you gain nothing.

Now you want to know the maximum number of monsters you can kill. Note that you can kill each monster at most once.

## Input

Each test contains multiple test cases. The first line contains the number of test cases $$$T$$$ ($$$1 \\le T \\le 10^4$$$). The description of the test cases follows.

The first line of each test case contains two integers $$$n$$$ and $$$m$$$ ($$$1 \\le n,m \\le 2 \\cdot 10^5$$$).

The second line of each test case contains $$$n$$$ integers $$$a\_1, a\_2, \\ldots, a\_n$$$ ($$$1 \\le a\_i \\le 10^9)$$$.

The third line of each test case contains $$$m$$$ integers $$$b\_1, b\_2, \\ldots, b\_m$$$ ($$$1 \\le b\_i \\le 10^9)$$$.

The fourth line of each test case contains $$$m$$$ integers $$$c\_1, c\_2, \\ldots, c\_m$$$ ($$$0 \\le c\_i \\le 10^9)$$$.

It is guaranteed that the sum of $$$n$$$ and $$$m$$$ over all test cases does not exceed $$$2 \\cdot 10^5$$$, respectively.

## Output

For each test case output one integer — the maximum number of monsters you can kill.

## Sample Tests

### Input
```
5
3 2
2 2 2
2 3
3 2
2 3
2 3
2 3 4
0 0 0
3 5
1 7 7
6 6 2 2 2
2 0 0 7 2
4 4
1 5 3 5
7 4 6 5
0 0 1 6
2 2
1 1000000000
1000000000 1
1000000000 0
```

### Output
```
2
2
5
3
2
```

## Note

[Visualizer link](https://codeforces.com/assets/contests/2164/C_oochei8Kaijaiz8hah8l.html)

In the first test case, you can first kill monster #1 using sword #1, and obtain a new sword with damage $$$\\max(2,3)=3$$$. You can then use this sword to kill monster #2.

In the second test case, you can't obtain any new swords because all $$$c\_i=0$$$, so you can only kill monster #1 and #2 with your two existing swords.