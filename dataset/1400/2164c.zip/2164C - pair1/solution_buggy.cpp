// In The Name of ALLAH


#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef double dl;

#define endl "\n"
#define optimize() ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);

int main()
{
    optimize();

    int t;
    cin >> t;

    while(t--){
       int n , d;
       cin >> n >> d;
       
       priority_queue<int> pq;
       for(int i = 0 ; i < n ; i++){
            int x; cin >> x;
            pq.push(x);
       }

       vector<int> b(d+1) , c(d+1);
       for(int i = 1 ; i <= d ; i++) cin >> b[i];
       for(int i = 1 ; i <= d ; i++) cin >> c[i];

       vector<pair<int,int>> p;
       vector<int> z;

       for(int i = 1 ; i <= d ; i++){
            if(c[i]>0) p.push_back({b[i],-1*c[i]});
            else z.push_back(b[i]);
       }

       sort(p.begin(),p.end());
       int ans = 0;

       for(auto [x,y] : p){
            int m = pq.top();
            if(m >= x and !pq.empty()){
                ans++;
                int mx = max(m,abs(y));
                pq.pop();
                pq.push(mx);
            }
       }

       vector<int> v;
        while (!pq.empty()){
            v.push_back(pq.top());
            pq.pop();
        }
        priority_queue<int, vector<int>, greater<int>> q(v.begin(), v.end());

       sort(z.begin(),z.end());
       int m = z.size();
       for(int i = 0 ; i < m ; i++){
            if(q.empty()) break;
            if(q.top() >= z[i] and !q.empty()){
                ans++;
                q.pop();
            }else{
                while(q.top() < z[i] and !q.empty()){
                    q.pop();
                }
                if(q.top() >= z[i] and !q.empty()){
                    ans++;
                    q.pop();
                }
            }
       }

       cout << ans << endl;

    }

    return 0;
}