#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef double dl;

#define endl "\n"
#define optimize() ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);

int main()
{
    optimize();

    int t;
    cin >> t;

    while(t--){
        int n , m;
        cin >> n >> m;

        multiset<int> swords;
        for(int i = 0 ; i < n; i++){
            int x; cin >> x;
            swords.insert(x);
        }

        vector<int> b(m), c(m);
        for(int i = 0 ; i < m ; i++) cin >> b[i];
        for(int i = 0 ; i < m ; i++) cin >> c[i];

        vector<pair<int,int>> with_reward, no_reward;
        for(int i = 0 ; i < m ; i++){
            if(c[i] > 0) with_reward.push_back({b[i],c[i]});
            else no_reward.push_back({b[i],0});
        }

        sort(with_reward.begin(),with_reward.end());
        sort(no_reward.begin(),no_reward.end());

        int ans = 0;

        for(auto [bi, ci] : with_reward){
            auto it = swords.lower_bound(bi);
            if(it != swords.end()){
                int sw = *it;
                swords.erase(it);
                swords.insert(max(sw,ci));
                ans++;
            }
        }

        for(auto[bi , ci] : no_reward){
            auto it = swords.lower_bound(bi);
            if(it != swords.end()){
                swords.erase(it);
                ans++;
            }
        }

        cout << ans << endl;
    }

    return 0;
}