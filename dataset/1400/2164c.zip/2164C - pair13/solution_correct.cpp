#include<bits/stdc++.h>
using namespace std;

#define endl '\n'
#define int long long
#define debug(x) cout << #x << "= " << x << endl;
#define IOS ios::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
#define HelloWorld IOS;


bool cmp(pair<int, int> a, pair<int, int> b){
    return a.first < b.first;
}

void solve(){

    int n, m; cin >> n >> m;
    multiset<int> se;
    for(int i = 1; i <= n; i ++){
        int x; cin >> x;
        se.insert(x);
    }
    vector<pair<int, int> > a(m + 10);
    for(int i = 1; i <= m; i ++) cin >> a[i].first;
    for(int i = 1; i <= m; i ++) cin >> a[i].second;
    sort(a.begin() + 1, a.begin() + 1 + m, cmp);

    int ans = 0;
    for(int i = 1; i <= m; i ++){
        int x = a[i].first, y = a[i].second;
        if(!y) continue;
        auto it = se.lower_bound(x);
        int z = *it;
        if(it != se.end()){
            ans ++;
            se.erase(it);
            se.insert(max(y, z));
        }
    }
    for(int i = 1; i <= m; i ++){
        int x = a[i].first, y = a[i].second;
        if(y) continue;
        auto it = se.lower_bound(x);
        if(it != se.end()){
            ans ++;
            se.erase(it);
        }
    }
    
    cout << ans << endl;
    return ;
}

signed main(){
    HelloWorld;

    int tt = 1; 
    cin >> tt;
    while(tt --) solve();
    return 0;
}