#include <bits/stdc++.h>
using namespace std;

// clang-format off
inline void setIO() {
    ios::sync_with_stdio(0); cin.tie(0);
#ifdef LOCAL_DEBUG
    freopen("C.in","r",stdin),freopen("C.out","w",stdout);
#endif
}

#ifdef LOCAL_DEBUG
#include <dbghelper.h>
#define dbg(...) _dbg_with_loc(__func__, __LINE__, #__VA_ARGS__, __VA_ARGS__)
#define d2d(g, ...) printGrid_with_loc(__func__, __LINE__, g, true, true, #g, ##__VA_ARGS__)
#define d2drc(g, ...) printGrid_with_loc(__func__, __LINE__, g, true, true, #g, ##__VA_ARGS__)
#define d2dcr(g, ...) printGrid_with_loc(__func__, __LINE__, g, false, true, #g, ##__VA_ARGS__)
#define d2drcup(g, ...) printGrid_with_loc(__func__, __LINE__, g, true, false, #g, ##__VA_ARGS__)
#define d2dcrup(g, ...) printGrid_with_loc(__func__, __LINE__, g, false, false, #g, ##__VA_ARGS__)
#define d1d(g, ...) printArray_with_loc(__func__, __LINE__, g, #g, ##__VA_ARGS__)
#define dbits(x, ...) printBits_with_loc(__func__, __LINE__, x, #x, false, ##__VA_ARGS__)
#define dbitslr(x, ...) printBits_with_loc(__func__, __LINE__, x, #x, true, ##__VA_ARGS__)
#define dbitsrl(x, ...) printBits_with_loc(__func__, __LINE__, x, #x, false, ##__VA_ARGS__)
#define dbgnl cerr << std::endl
__attribute__((noinline, used)) void __bp_hook() { volatile int _bp = 0; (void)_bp; }
#define bp(cond) do { if (cond) __bp_hook(); } while (0)
#else
#define dbg(...)
#define d2d(g, ...)
#define d2drc(g, ...)
#define d2dcr(g, ...)
#define d2drcup(g, ...)
#define d2dcrup(g, ...)
#define d1d(g, ...)
#define dbits(x, ...)
#define dbitslr(x, ...)
#define dbitsrl(x, ...)
#define dbgnl do {} while (0)
#define bp(cond) do {} while (0)
#endif

#define dtime(label) \
    auto __start_##label = std::chrono::high_resolution_clock::now();
#define dtp(label) do { \
    auto __end_##label = std::chrono::high_resolution_clock::now(); \
    auto __ms_##label = std::chrono::duration_cast<std::chrono::milliseconds>( \
        __end_##label - __start_##label).count(); \
    std::cerr << #label << " took " << __ms_##label << " ms" << std::endl; \
} while(0)

ostream& operator<<(ostream& o,__int128 x){
    if (x<0) {o<<'-',x=-x;} string s;
    do s+=char('0'+x%10),x/=10; while(x);
    return reverse(s.begin(),s.end()), o<<s;
}
istream& operator>>(istream& in,__int128& x){
    string s; in>>s; x=0;
    for(int i=(s[0]=='-');i<(int)s.size();++i) x=x*10+s[i]-'0';
    return s[0]=='-'?x=-x:0, in;
}
template<typename A, typename B> ostream& operator<<(ostream& out, const pair<A,B>& p) {
    return out << p.first << ' ' << p.second;
}
template<size_t I = 0, typename... Ts> typename enable_if<I == sizeof...(Ts), istream&>::type
read_tuple(istream& in, tuple<Ts...>& t) { return in; }
template<size_t I = 0, typename... Ts> typename enable_if<I < sizeof...(Ts), istream&>::type
read_tuple(istream& in, tuple<Ts...>& t) { in >> get<I>(t); return read_tuple<I + 1>(in, t); }
template<typename... Ts> istream& operator>>(istream& in, tuple<Ts...>& t) {return read_tuple(in, t);}
template<size_t I = 0, typename... Ts> typename enable_if<I == sizeof...(Ts), void>::type
print_tuple(ostream& out, const tuple<Ts...>& t) {}
template<size_t I = 0, typename... Ts> typename enable_if<I < sizeof...(Ts), void>::type
print_tuple(ostream& out, const tuple<Ts...>& t){if(I)out<<' ';out<<get<I>(t);print_tuple<I + 1>(out,t);}
template<typename... Ts> ostream& operator<<(ostream& out, const tuple<Ts...>& t){print_tuple(out,t);return out;}

template<typename... T> void rd(T&... args) { ((cin >> args), ...); }
template<typename... Vecs> void rv(int n, Vecs&... v) {
    ((v.resize(n)), ...); for (int i = 0; i < n; i++) ((cin >> v[i]), ...);
}
template<typename First, typename... Rest> void rv(First& first, Rest&... rest) {
    int n = (int)first.size(); ((assert((int)rest.size() == n)), ...);
    for (int i = 0; i < n; i++) cin >> first[i], ((cin >> rest[i]), ...);
}
template<typename T> void rv(int n, int m, vector<vector<T>>& g) {
    g.resize(n); for (int i = 0; i < n; i++) rv(m, g[i]);
}
template<typename T> void rv(vector<vector<T>>& g) { for (auto& row : g) rv(row); }
template<typename... T> void wr(const T&... args) {
    bool first = true; ((cout << (first ? (first = false, "") : " ") << args), ...); cout << char(10);
}
template<typename A, typename B> void wv(const vector<pair<A,B>>& v) {
    for (const auto& p : v) { cout << p.first << ' ' << p.second << char(10); }
}
template<typename It> void wv(It it, It end, const string& sep = " ") {
    for (bool f = true; it != end; ++it) {cout << (f ? (f = false, "") : sep) << *it;} cout << char(10);
}
template<typename... Ts> void wv(const vector<tuple<Ts...>>& v) {for (const auto& t : v){ cout << t << char(10);}}
template<typename... Ts> void wv(int n, const vector<tuple<Ts...>>& v) {
    assert(n == (int)v.size()); cout << n << char(10); for (const auto& t : v) {cout << t << char(10);}
}
template<typename C> void wv(const C& c, const string& sep = " ") { wv(c.begin(), c.end(), sep); }
template<typename It> void wv(int n, It it, It end, const string& sep = " ") {
    cout << n << char(10); for (int i = 0; i < n; ++i, ++it) {assert(it != end); cout << (i ? sep : "") << *it;}
    assert(it == end); cout << char(10);
}
template<typename C> void wv(int n, const C& c, const string& sep = " ") {
    assert(n == (int)c.size()); wv(n, c.begin(), c.end(), sep);
}
template<typename First, typename... Rest> void wv(const First& first, const Rest&... rest) {
    int n = (int)first.size(); ((assert((int)rest.size() == n)), ...);
    for (int i = 0; i < n; i++) {cout << first[i];((cout << ' ' << rest[i]), ...); cout << char(10);}
}
template<typename First, typename... Rest> void wv(int n, const First& first, const Rest&... rest) {
    assert(n == (int)first.size()); ((assert((int)rest.size() == n)), ...); cout << n << char(10);
    for (int i = 0; i < n; i++) {cout << first[i]; ((cout << ' ' << rest[i]), ...); cout << char(10);}
}
template<typename T> void wv(const vector<vector<T>>& g) {
    for (const auto& row : g) { for (int i = 0; i < (int)row.size(); i++)
        { if (i) cout << ' '; cout << row[i]; } cout << char(10); }
}
template<typename T> void wv(int n, int m, const vector<vector<T>>& g) {
    assert(n == (int)g.size()); for (const auto& row : g) { assert((int)row.size() == m); }
    cout << n << ' ' << m << char(10); for (const auto& row : g) {
        for (int j = 0; j < m; j++) { if (j) cout << ' '; cout << row[j]; } cout << char(10); }
}

#define each(a, x)    for(auto& a : x)
#define  rep(i, a, b) for(int i   = a; i   < (b); ++i  )
#define   rp(b)       for(int _rp = 0; _rp < (b); ++_rp)
#define  all(x)       begin(x),  end(x)
#define rall(x)       rbegin(x), rend(x)
#define  exist(x, v)  ((x).find(v) != (x).end())
#define cexist(x, v)  (find(all(x), v) != (x).end())
#define sz(x)         (int)(x).size()
#define bg(x)         begin(x)
#define rsz resize
#define ins insert
#define pb  push_back
#define pf  push_front
#define ft  front()
#define bk  back()
#define fi  first
#define se  second
#define lb  lower_bound
#define ub  upper_bound
#define uniq(x) (x).erase(unique(all(x)), (x).end())
#define dedupe(x) do {sort(all(x)); (x).erase(unique(all(x)), (x).end());} while(0)
#define CT template<class T>
CT bool ckmin(T &a, const T &b) { return b < a ? (a = b, true) : false; }
CT bool ckmax(T &a, const T &b) { return b > a ? (a = b, true) : false; }
CT using V = vector<T>;  CT using   vv = V<V<T>>;  CT using  vvv = V<vv<T>>;
using   ll = long long;     using  ull = uint64_t;    using   ld = long double;
using  pii = pair<int,int>; using  pll = pair<ll,ll>; using  pdd = pair<ld,ld>;
using   vi = V<int>;        using   vl = V<ll>;       using   vd = V<ld>;
using   vb = V<bool>;       using   vc = V<char>;     using   vs = V<string>;
using  vpi = V<pii>;        using  vpl = V<pll>;      using  vpd = V<pdd>;
using  vvi = V<vi>;         using  vvl = V<vl>;       using  vvd = V<vd>;
using vvpi = V<vpi>;        using vvpl = V<vpl>;      using vvpd = V<vpd>;
using  pli = pair<ll,int>;  using vpli = V<pli>;     using vvpli = V<vpli>;
using  pil = pair<int,ll>;  using vpil = V<pil>;     using vvpil = V<vpil>;
using  t3i = tuple<int,int,int>;  using vti = V<t3i>;
using  t3l = tuple<ll ,ll ,ll >;  using vtl = V<t3l>;
CT using maxpq = priority_queue<T>;
CT using minpq = priority_queue<T, V<T>, greater<T>>; using i128 = __int128;
ll cdiv(ll a, ll b) {assert(b!=0); return a/b + ((a%b)!=0 && ((a>0)==(b>0)));}
CT auto     pref(const T& a){using Vt=decay_t<decltype(*begin(a))>; V<Vt> p(1); for(auto&& x:a) p.pb(p.back()+x); return p;}
CT auto   argmin(const T& a){return distance(begin(a), min_element(begin(a), end(a)));}
CT auto   argmax(const T& a){return distance(begin(a), max_element(begin(a), end(a)));}
CT void  freq_vi(const T& a, vi& f){for(auto x:a) f[x]++;}
CT auto freq_map(const T& a){unordered_map<decay_t<decltype(*begin(a))>,int> f; for(auto x:a) f[x]++; return f;}
CT vi    argsort(const T& a){vi p(a.size()); iota(all(p),0); sort(all(p),[&](int i,int j){return a[i]<a[j];}); return p;}
template<class A, class B> void append(A& a,const B& b) {a.ins(a.end(),all(b));}
template<class A, class M> auto nmod(A a, M m) {using T = std::common_type_t<A, M>;T r = a % m; return r < 0 ? r + m : r;}
const int  INF = 1e9;   const ll LLINF = 4e18; const ll NTT = 998244353;
// clang-format on

void solve() {
    int n,m; rd(n,m);
    vi a(n), b(m), c(m);
    rv(a), rv(b), rv(c);
    multiset<int> s;
    each(x,a) s.ins(x);

    vb f(m);
    int ans = 0;
    rep(i,0,m) {
        if (c[i] == 0) continue;
        auto it = s.lb(b[i]);
        if (it == s.end()) continue;
        if (*it < c[i]) {
            s.ins(c[i]);
            s.erase(it);
            f[i] = true;
            ans++;
        }
    }

    rep(i,0,m) {
        if (f[i]) continue;
        if (c[i] == 0) continue;
        if (b[i] <= *s.rbegin()) ans++, f[i] = true;
    }

    rep(i,0,m) {
        if (c[i]) continue;
        auto it = s.lb(b[i]);
        if (it == s.end()) continue;
        ans++;
        s.erase(it);
    }
    wr(ans);
}

int main() {
    setIO();
    int TT; cin >> TT;
    for (int tt = 0; tt < TT; tt++) {
        solve();
    }
    return 0;
}
