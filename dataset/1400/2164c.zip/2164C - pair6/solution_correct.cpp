#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#define ll long long
using namespace std;

bool f(const pair<ll int,ll int>c,const pair<ll int,ll int>b)
{
    return c.first>b.first;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ll int tt,n,m,k,max=0,cannot=0;
    priority_queue<ll int,vector<ll int>,greater<ll int>>a;
    priority_queue<ll int,vector<ll int>,greater<ll int>>acl;
    vector<ll int>a2;
    vector<pair<ll int,ll int>>v;
    vector<ll int>v2;
    vector<ll int> xx;
    cin>>tt;
    
    for(ll int w=1;w<=tt;w++)
    {
        
        cin>>n>>m;
        xx.resize(m);
        for(int i=0;i<n;i++)
        {
            cin>>k;
            a.push(k);
        }
        for (int i = 0; i < m; i++) cin >> xx[i];

        for (int i = 0; i < m; i++)
        {
            cin >> k;
            if (k == 0)v2.push_back(xx[i]);
            else v.push_back({xx[i], k});
        }
        
        sort(v.begin(),v.end(),f);
        sort(v2.begin(),v2.end());
        while(!v.empty()&&a.size()!=0)
        {
            int i=v.size()-1;
            if(a.top()>=v[i].first)
            {
                if(v[i].second>a.top())
                {
                    a.pop();
                    a.push(v[i].second);
                }
                v.pop_back();
            }else
            {
                a2.push_back(a.top());
                a.pop();
            }
        }
       
        while(!a.empty())
        {
            a2.push_back(a.top());
            a.pop();
        }
        sort(a2.begin(),a2.end());
        ll i = (ll)a2.size() - 1;
        ll j = (ll)v2.size() - 1;
        ll de=0;
        while (i >= 0 && j >= 0)
        {
            if (a2[i] < v2[j])
            {
                
                j--;
            }
            else
            {
                de+=1;
                i--;
                j--;
            }
        }
        cout << m - v.size() -(v2.size()-de) << "\n";
        v.clear();a=acl;cannot=0;v2.clear();a2.clear();xx.clear();
    }
}
