#include <bits/stdc++.h>
using namespace std;
#define int long long

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int t;
    cin >> t;

    while(t--) {
        int n, m;
        cin >> n >> m;

        vector<int> a(n);
        vector<int> b(m);
        vector<int> c(m);

        for(int i = 0; i < n; i++) {
            cin >> a[i];
        }

        for(int i = 0; i < m; i++) {
            cin >> b[i];
        }

        for(int i = 0; i < m; i++) {
            cin >> c[i];
        }

        vector<pair<int, int>> monsters(m);

        for(int i = 0; i < m; i++) {
            monsters[i] = {b[i], c[i]};
        }

        int maxi = INT_MIN;

        for(auto i: a) {
            maxi = max(maxi, i);
        }
    
        // sort(monsters.begin(), monsters.end(), [](pair<int, int> &a, pair<int, int> &b) {
        //     return a.second < b.second;
        // });

        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> left;
        priority_queue<int, vector<int>, greater<>> swords;
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> extra;
        int cnt = 0;

        for(auto i: a) {
            swords.push(i);
        }

        sort(monsters.begin(), monsters.end());

        for(int i = 0; i < m; i++) {
            if(maxi >= monsters[i].first && monsters[i].second > 0) {
                maxi = max(maxi, monsters[i].second);
            }

            if(monsters[i].second > 0) {
                extra.push(monsters[i]);
            } else {
                left.push(monsters[i]);
            }
        }

        for(int i = 0; i < m; i++) {
            if(maxi >= monsters[i].first && monsters[i].second > 0) {
                cnt++;
            }
        }

        // cout << "leftSize " << left.size() << endl;
        // cout << "extraSize " << extra.size() << endl;

        while(!swords.empty() && !left.empty()) {
            int top = swords.top();
            swords.pop();

            if(top >= left.top().first) {
                cnt++;
                left.pop();
            } else {
                if(extra.empty()) continue;

                if(top >= extra.top().first) {
                    int newTop = max(top, extra.top().second);
                    extra.pop();
                    
                    swords.push(newTop);
                }
            }
        }

        cout << cnt << endl;
    }
}