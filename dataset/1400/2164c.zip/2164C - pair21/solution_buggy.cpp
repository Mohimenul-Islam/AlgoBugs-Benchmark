/*
BM
*/

#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;

// -------------------- Type Aliases --------------------
using ll = long long;
using ull = unsigned long long;
using ld = long double;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;

// -------------------- Constants --------------------
inline constexpr ll MOD = 1e9 + 7;
inline constexpr ll MAXN = 2e6 + 9;
inline constexpr ld PI = 3.141592653589793238L;
/** L1 cache line size (bytes); align hot data to reduce false sharing and
 * improve line fills */
inline constexpr int BM_CACHE_LINE = 64;

// -------------------- Fast IO --------------------
#define fast_io()                                                              \
  ios_base::sync_with_stdio(false);                                            \
  cin.tie(NULL);                                                               \
  cout.tie(NULL)

// Optimizer hints: on function decl/def or in conditions
#define bm_always_inline                                                       \
  __attribute__((                                                              \
      always_inline)) // hot helpers: bm_always_inline inline void foo()
#define bm_noinline                                                            \
  __attribute__((noinline))         // avoid inlining: bm_noinline void bar()
#define bm_hot __attribute__((hot)) // hot path: bm_hot void solve()
#define bm_cold                                                                \
  __attribute__((cold)) // rare path (e.g. error): bm_cold void fail()
#define bm_flatten                                                             \
  __attribute__((flatten)) // inline all callees: bm_flatten void solve()
#define bm_likely(x)                                                           \
  __builtin_expect(!!(x), 1) // in if: if (bm_likely(ok)) { ... }
#define bm_unlikely(x)                                                         \
  __builtin_expect(!!(x), 0) // in if: if (bm_unlikely(err)) { ... }
#define bm_assume(cond)                                                        \
  do {                                                                         \
    if (!(cond))                                                               \
      __builtin_unreachable();                                                 \
  } while (0) // invariant: bm_assume(i < n);
#if defined(__clang__)
#pragma clang optimize on
#elif defined(__GNUC__)
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")
#endif
// Cache-friendly: align hot data to cache line (fewer line fetches, less false
// sharing). Use: bm_cache_align int arr[N]; struct bm_cache_align Foo { ... };
#define bm_cache_align alignas(BM_CACHE_LINE)

// -------------------- Loop Shortcuts --------------------
#define rep(i, a, b) for (ll i = (a); i < (b); ++i)
#define repi(i, a, b) for (ll i = (a); i <= (b); ++i)
#define per(i, a, b) for (ll i = (a); i >= (b); --i)
#define trav(a, x) for (auto &a : x)

// -------------------- STL Shortcuts --------------------
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()

// -------------------- Custom Hash for Pairs --------------------
/**
 * @brief Custom hash function for pairs to enable unordered_map<pair<T1,T2>, V>
 * Uses FNV-1a hash algorithm for better distribution
 */
template <typename T1, typename T2> struct pair_hash {
  size_t operator()(const pair<T1, T2> &p) const {
    const auto h1 = hash<T1>{}(p.first);
    const auto h2 = hash<T2>{}(p.second);
    // FNV-1a hash combination
    constexpr size_t FNV_OFFSET_BASIS = 14695981039346656037ULL;
    constexpr size_t FNV_PRIME = 1099511628211ULL;
    size_t result = FNV_OFFSET_BASIS;
    result ^= h1;
    result *= FNV_PRIME;
    result ^= h2;
    result *= FNV_PRIME;
    return result;
  }
};

// -------------------- Output & Debug Macros --------------------
#define endl '\n'

// -------------------- Variadic Print --------------------
template <typename T, typename = void> struct is_print_iterable : false_type {};
template <typename T>
struct is_print_iterable<
    T, void_t<decltype(begin(declval<T &>())), decltype(end(declval<T &>()))>>
    : true_type {};
template <typename T>
inline constexpr bool is_printable_range_v =
    is_print_iterable<T>::value && !is_same_v<decay_t<T>, string> &&
    !is_same_v<decay_t<T>, const char *> && !is_same_v<decay_t<T>, char *>;

template <typename T> void print_element(const T &x) { cout << x; }
template <typename T1, typename T2> void print_element(const pair<T1, T2> &p) {
  cout << "(" << p.first << ", " << p.second << ")";
}
template <typename T> void print_element(const vector<T> &v) {
  int i = 0;
  for (const auto &x : v) {
    if (i++)
      cout << ' ';
    print_element(x);
  }
}

template <typename T> void print(const T &x) {
  if constexpr (is_printable_range_v<T>) {
    int i = 0;
    for (const auto &e : x) {
      if (i++)
        cout << ' ';
      print_element(e);
    }
    cout << '\n';
  } else {
    cout << x << '\n';
  }
}

template <typename T, typename... Args>
void print(const T &first, const Args &...rest) {
  cout << first << ' ';
  print(rest...);
}

// -------------------- Utility Print Helpers --------------------
/** @brief Print "YES" followed by newline */
inline void yes() { cout << "YES\n"; }

/** @brief Print "NO" followed by newline */
inline void no() { cout << "NO\n"; }

/** @brief Print "Yes" followed by newline */
inline void Yes() { cout << "Yes\n"; }

/** @brief Print "No" followed by newline */
inline void No() { cout << "No\n"; }

/** @brief Print "YES" followed by newline */
inline void YES() { cout << "YES\n"; }

/** @brief Print "NO" followed by newline */
inline void NO() { cout << "NO\n"; }

/**
 * @brief Print double with specified precision
 * @param x Double value to print
 * @param precision Number of decimal places (default 20)
 */
inline void prDouble(const double x, const int precision = 20) {
  cout << fixed << setprecision(precision) << x;
}

// -------------------- Timer Macro --------------------
// Time an expression or call; prints "Time [expr]: s, ms, us, ns" to stderr.
// Use: TIMEIT(foo(1,2)); or TIMEIT(...);
/**
 * @brief Time the execution of an expression; print label (expression as
 * written) and result to stderr
 * @example TIMEIT(x(1, 2));  -> "Time [x(1, 2)]: ..."
 * @example TIMEIT(ll s = 0; rep(i, 0, 1e6) s += i; (void)s);
 */
template <typename F> void timeit_impl(const char *name, F func) {
  const auto __st = chrono::high_resolution_clock::now();
  func();
  const auto __et = chrono::high_resolution_clock::now();
  const auto __elapsed = __et - __st;
  cerr << "Time [" << name
       << "]: " << chrono::duration_cast<chrono::seconds>(__elapsed).count()
       << " s, "
       << chrono::duration_cast<chrono::milliseconds>(__elapsed).count()
       << " ms, "
       << chrono::duration_cast<chrono::microseconds>(__elapsed).count()
       << " us, "
       << chrono::duration_cast<chrono::nanoseconds>(__elapsed).count()
       << " ns\n";
}
#define TIMEIT(...) timeit_impl(#__VA_ARGS__, [&]() { __VA_ARGS__; })

// -------------------- Direction Vectors (clockwise: E, S, W, N / E, SE, S, SW,
// W, NW, N, NE) --------------------
constexpr std::array<int, 4> dx4 = {0, 1, 0, -1};
constexpr std::array<int, 4> dy4 = {1, 0, -1, 0};
constexpr std::array<int, 8> dx8 = {0, 1, 1, 1, 0, -1, -1, -1};
constexpr std::array<int, 8> dy8 = {1, 1, 0, -1, -1, -1, 0, 1};

// -------------------- Modular Arithmetic --------------------
/** Normalize x to [0, mod). Default mod = MOD. */
constexpr int mod_norm(ll x, ll mod = MOD) {
  x %= mod;
  return (int)(x < 0 ? x + mod : x);
}

constexpr int mod_add(const int a, const int b, const ll mod = MOD) {
  return mod_norm((ll)a + b, mod);
}
constexpr int mod_sub(const int a, const int b, const ll mod = MOD) {
  return mod_norm((ll)a - b, mod);
}
constexpr int mod_mul(const int a, const int b, const ll mod = MOD) {
  return mod_norm((ll)a * b, mod);
}
constexpr int mod_pow(int a, ll exp, ll mod = MOD) {
  int res = 1;
  while (exp) {
    if (exp & 1)
      res = mod_mul(res, a, mod);
    a = mod_mul(a, a, mod);
    exp >>= 1;
  }
  return res;
}
/** Modular inverse (mod prime). Default mod = MOD. */
constexpr int mod_inv(const int a, const ll mod = MOD) {
  return mod_pow(a, mod - 2, mod);
}
constexpr int mod_div(const int a, const int b, const ll mod = MOD) {
  return mod_mul(a, mod_inv(b, mod), mod);
}

/** In-place mod ops; T,U can be int or ll. Optional mod defaults to MOD. */
template <typename T, typename U>
inline void mod_add_self(T &a, const U b, const ll mod = MOD) {
  a = mod_add((int)a, (int)b, mod);
}
template <typename T, typename U>
inline void mod_sub_self(T &a, const U b, const ll mod = MOD) {
  a = mod_sub((int)a, (int)b, mod);
}
template <typename T, typename U>
inline void mod_mul_self(T &a, const U b, const ll mod = MOD) {
  a = mod_mul((int)a, (int)b, mod);
}
template <typename T, typename U>
inline void mod_div_self(T &a, const U b, const ll mod = MOD) {
  a = mod_div((int)a, (int)b, mod);
}

// -------------------- Factorials / nCr --------------------
constexpr size_t FACT_LEN = static_cast<size_t>(MAXN);
inline std::array<int, FACT_LEN> fact{};
inline std::array<int, FACT_LEN> inv_fact{};

/** Precompute fact[] and inv_fact[]; call once (e.g. in main) when nCr needed.
 */
bm_always_inline inline void precompute_factorials() {
  if (FACT_LEN > 0)
    fact[0] = 1;
  for (size_t i = 1; i < FACT_LEN; ++i)
    fact[i] = mod_mul(fact[i - 1], (int)i);
  if (FACT_LEN > 0) {
    inv_fact[FACT_LEN - 1] = mod_inv(fact[FACT_LEN - 1]);
    for (size_t i = FACT_LEN - 1; i-- > 0;)
      inv_fact[i] = mod_mul(inv_fact[i + 1], (int)(i + 1));
  }
}

/**
 * @brief Binomial coefficient (n choose r) modulo MOD
 * @return C(n,r) % MOD, or 0 if r > n or r < 0
 */
bm_always_inline inline int nCr(const ll n, const ll r) {
  if (r > n || r < 0)
    return 0;
  return mod_mul(mod_mul(fact[n], inv_fact[r]), inv_fact[n - r]);
}

// -------------------- Prefix/Suffix Sum --------------------
/**
 * @brief Calculate prefix sum array
 * @param v Input vector
 * @return Vector where ps[i] = sum of v[0] to v[i-1]
 */
template <typename T> vector<T> prefix_sum(const vector<T> &v) {
  const size_t n = v.size();
  vector<T> ps(n + 1);
  rep(i, 0, n) ps[i + 1] = ps[i] + v[i];
  return ps;
}

/**
 * @brief Calculate suffix sum array
 * @param v Input vector
 * @return Vector where ss[i] = sum of v[i] to v[n-1]
 */
template <typename T> vector<T> suffix_sum(const vector<T> &v) {
  const int n = (int)v.size();
  vector<T> ss(n + 1);
  for (int i = n - 1; i >= 0; --i)
    ss[i] = ss[i + 1] + v[i];
  return ss;
}

// -------------------- Binary Search Helpers --------------------
/**
 * @brief Find first position where predicate is true
 * @param lo Lower bound (inclusive)
 * @param hi Upper bound (exclusive)
 * @param predicate Function that returns true for valid positions
 * @return First position where predicate(pos) is true
 */
template <typename T, typename F>
T binary_search_first(T lo, T hi, F predicate) {
  while (lo < hi) {
    const T mid = lo + (hi - lo) / 2;
    if (predicate(mid))
      hi = mid;
    else
      lo = mid + 1;
  }
  return lo;
}

/**
 * @brief Find last position where predicate is true
 * @param lo Lower bound (inclusive)
 * @param hi Upper bound (inclusive)
 * @param predicate Function that returns true for valid positions
 * @return Last position where predicate(pos) is true
 */
template <typename T, typename F>
T binary_search_last(T lo, T hi, F predicate) {
  while (lo < hi) {
    const T mid = lo + (hi - lo + 1) / 2;
    if (predicate(mid))
      lo = mid;
    else
      hi = mid - 1;
  }
  return lo;
}

/**
 * @brief Binary search on answer - find minimum value that satisfies condition
 * @param lo Lower bound (inclusive)
 * @param hi Upper bound (inclusive)
 * @param can_achieve Function that returns true if value is achievable
 * @return Minimum value where can_achieve(value) is true, or hi+1 if impossible
 */
template <typename T, typename F>
T binary_search_answer(T lo, T hi, F can_achieve) {
  T result = hi + 1; // Default to "impossible"
  while (lo <= hi) {
    const T mid = lo + (hi - lo) / 2;
    if (can_achieve(mid)) {
      result = mid;
      hi = mid - 1; // Try for smaller answer
    } else {
      lo = mid + 1;
    }
  }
  return result;
}

/**
 * @brief Binary search on floating point values
 * @param lo Lower bound
 * @param hi Upper bound
 * @param predicate Function that returns true for valid values
 * @param eps Precision (default 1e-9)
 * @return Value where predicate changes from false to true
 */
template <typename F>
double binary_search_real(const double lo_in, const double hi_in, F predicate,
                          const double eps = 1e-9) {
  double lo = lo_in, hi = hi_in;
  for (int iter = 0; iter < 100 && hi - lo > eps; iter++) {
    const double mid = (lo + hi) / 2.0;
    if (predicate(mid)) {
      hi = mid;
    } else {
      lo = mid;
    }
  }
  return (lo + hi) / 2.0;
}

/**
 * @brief Find kth smallest element in array (0-indexed)
 * @param arr Vector to search in (will be modified)
 * @param k Index of element to find (0-indexed)
 * @return The kth smallest element
 */
template <typename T> T kth_element(vector<T> arr, const int k) {
  nth_element(arr.begin(), arr.begin() + k, arr.end());
  return arr[k];
}

// -------------------- Templated I/O --------------------
template <typename T> istream &operator>>(istream &is, vector<T> &v) {
  for (auto &x : v)
    is >> x;
  return is;
}
template <typename T> ostream &operator<<(ostream &os, const vector<T> &v) {
  for (const auto &x : v)
    os << x << ' ';
  return os;
}
template <typename T1, typename T2>
ostream &operator<<(ostream &os, const pair<T1, T2> &p) {
  return os << "(" << p.first << ", " << p.second << ")";
}

// -------------------- Debugging (generic range-based) --------------------
template <typename T, typename = void> struct is_iterable : false_type {};
template <typename T>
struct is_iterable<
    T, void_t<decltype(begin(declval<T &>())), decltype(end(declval<T &>()))>>
    : true_type {};
template <typename T>
inline constexpr bool is_range_v =
    is_iterable<T>::value && !is_same_v<decay_t<T>, string>;

template <typename T> void debug_print(const T &x);

template <typename T1, typename T2> void debug_print(const pair<T1, T2> &p) {
  cout << "(";
  debug_print(p.first);
  cout << ", ";
  debug_print(p.second);
  cout << ")";
}

template <typename T> void debug_print(const T &x) {
  if constexpr (is_range_v<T>) {
    cout << "[ ";
    for (const auto &e : x) {
      debug_print(e);
      cout << " ";
    }
    cout << "]";
  } else {
    cout << x;
  }
}

template <typename T> void debug_print(const stack<T> &s) {
  stack<T> tmp = s;
  vector<T> v;
  while (!tmp.empty()) {
    v.push_back(tmp.top());
    tmp.pop();
  }
  debug_print(v);
}
template <typename T> void debug_print(const queue<T> &q) {
  queue<T> tmp = q;
  vector<T> v;
  while (!tmp.empty()) {
    v.push_back(tmp.front());
    tmp.pop();
  }
  debug_print(v);
}
template <typename T> void debug_print(const priority_queue<T> &pq) {
  priority_queue<T> tmp = pq;
  vector<T> v;
  while (!tmp.empty()) {
    v.push_back(tmp.top());
    tmp.pop();
  }
  debug_print(v);
}

inline void debug_print() {}
template <typename T, typename... Args>
void debug_print(const T &x, const Args &...args) {
  debug_print(x);
  cout << " ";
  debug_print(args...);
}

// -------------------- 2D Utilities --------------------
/**
 * @brief Read a 2D vector from input
 * @param vec 2D vector to fill (will be resized)
 * @param n Number of rows
 * @param m Number of columns
 */
template <typename T>
void read_2d(vector<vector<T>> &vec, const int n, const int m) {
  vec.resize(n, vector<T>(m));
  rep(i, 0, n) rep(j, 0, m) cin >> vec[i][j];
}

/**
 * @brief Print a 2D vector
 * @param vec 2D vector to print
 */
template <typename T> void print_2d(const vector<vector<T>> &vec) {
  for (const auto &row : vec) {
    for (const auto &val : row)
      cout << val << " ";
    cout << "\n";
  }
}

// -------------------- Ordered Set (PBDS) --------------------
template <typename T>
using ordered_set =
    tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

template <typename T>
using ordered_multiset = tree<T, null_type, less_equal<T>, rb_tree_tag,
                              tree_order_statistics_node_update>;

// -------------------- Bit Manipulation --------------------
/** @brief Count number of set bits in a number */
constexpr int count_bits(const ll x) { return __builtin_popcountll(x); }

/** @brief Find position of highest set bit (0-indexed from right) */
constexpr int highest_bit(const ll x) {
  return x == 0 ? -1 : 63 - __builtin_clzll(x);
}

/** @brief Find position of lowest set bit (0-indexed from right) */
constexpr int lowest_bit(const ll x) {
  return x == 0 ? -1 : __builtin_ctzll(x);
}

/** @brief Get value of lowest set bit (isolate rightmost 1) */
constexpr ll lowest_set_bit(const ll x) { return x & (-x); }

/** @brief Clear the lowest set bit */
constexpr ll clear_lowest_bit(const ll x) { return x & (x - 1); }

/** @brief Check if number is a power of 2 */
constexpr bool is_power_of_two(const ll x) {
  return x > 0 && (x & (x - 1)) == 0;
}

/** @brief Find next power of 2 greater than or equal to x */
constexpr ll next_power_of_two(const ll x) {
  return x <= 1 ? 1 : 1LL << (64 - __builtin_clzll(x - 1));
}

/**
 * @brief Count set bits for any integer type
 * @param x Number to count bits in
 * @return Number of set bits
 */
template <typename T> constexpr int count_bits_generic(T x) {
  if constexpr (sizeof(T) <= sizeof(int)) {
    return __builtin_popcount(x);
  } else if constexpr (sizeof(T) <= sizeof(long)) {
    return __builtin_popcountl(x);
  } else {
    return __builtin_popcountll(x);
  }
}

/**
 * @brief Extract bits from a range in number
 * @param x Source number
 * @param start Starting bit position (0-indexed from right)
 * @param length Number of bits to extract
 * @return Extracted bits shifted to right
 */
constexpr ll get_bits(const ll x, const int start, const int length) {
  return (x >> start) & ((1LL << length) - 1);
}

/**
 * @brief Set bits in a range of number
 * @param x Source number
 * @param start Starting bit position (0-indexed from right)
 * @param length Number of bits to set
 * @param value New value for the bit range
 * @return Number with modified bits
 */
constexpr ll set_bits(const ll x, const int start, const int length,
                      const ll value) {
  const ll mask = ((1LL << length) - 1) << start;
  return (x & ~mask) | ((value << start) & mask);
}

/**
 * @brief Calculate XOR of all numbers from 0 to n
 * @param n Upper bound (inclusive)
 * @return XOR of all numbers from 0 to n
 */
constexpr ll xor_upto(const ll n) {
  const ll mod = n % 4;
  if (mod == 0)
    return n;
  if (mod == 1)
    return 1;
  if (mod == 2)
    return n + 1;
  return 0;
}

/**
 * @brief Calculate XOR of all numbers in range [start, end]
 * @param start Starting number (inclusive)
 * @param end Ending number (inclusive)
 * @return XOR of all numbers from start to end
 */
constexpr ll xor_range(const ll start, const ll end) {
  return xor_upto(end) ^ xor_upto(start - 1);
}

/**
 * @brief Iterate through all subsets of a bitmask
 * @param mask The bitmask to generate subsets of
 * @param func Function to call for each subset
 */
template <typename F> void iterate_subsets(const ll mask, F func) {
  for (ll submask = mask;; submask = (submask - 1) & mask) {
    func(submask);
    if (submask == 0)
      break;
  }
}

// -------------------- Debug Logging --------------------
// Comment this out to disable debug logging
// #define BM_DEBUG

#ifdef BM_DEBUG
#define DEBUG_LOG(...)                                                         \
  do {                                                                         \
    cout << "[" << #__VA_ARGS__ << "]: ";                                      \
    debug_print(__VA_ARGS__);                                                  \
    cout << endl;                                                              \
  } while (0)
#else
#define DEBUG_LOG(...) ((void)0)
#endif

#ifdef BM_DEBUG
// -------------------- Timing (stderr); only with BM_DEBUG --------------------
inline void
log_case_time(const int tc, const int t,
              const chrono::high_resolution_clock::duration elapsed) {
  cerr << "Time (case " << tc << "/" << t
       << "): " << chrono::duration_cast<chrono::seconds>(elapsed).count()
       << " s, " << chrono::duration_cast<chrono::milliseconds>(elapsed).count()
       << " ms, "
       << chrono::duration_cast<chrono::microseconds>(elapsed).count()
       << " us, " << chrono::duration_cast<chrono::nanoseconds>(elapsed).count()
       << " ns\n";
}
#endif

// -------------------- Global Variables --------------------
ll n, m;
vector<pll> bc;
multiset<ll> a;

bool cmp(const pll &a, const pll &b) {
  bool az = (a.second == 0);
  bool bz = (b.second == 0);

  if (az != bz)
    return !az;

  return a.first < b.first;
}

// -------------------- Solve Function --------------------
/**
 * @brief Main solution function - implement your algorithm here
 * @note This function is called for each test case
 */
bm_always_inline inline void solve() {
  cin >> n >> m;
  a.clear();
  rep(i, 0, n) {
    ll x;
    cin >> x;
    a.insert(x);
  }
  bc.resize(m);
  rep(i, 0, m) { cin >> bc[i].first; }
  rep(i, 0, m) { cin >> bc[i].second; }
  sort(all(bc), cmp);
  DEBUG_LOG(bc);
  ll i = 0;
  ll ans = 0;
  for (auto it = a.begin(); it != a.end();) {
    if (i >= m) {
      break;
    }
    auto cur_sword = *it;
    auto &cur_monster = bc[i];
    if (cur_sword < cur_monster.first) {
      ++it;
      continue;
    }
    ++ans;
    ++i;
    if (cur_monster.second > 0) {
      auto new_sword = max(cur_sword, cur_monster.second);
      if (new_sword == cur_sword) {
        continue;
      }
      a.insert(new_sword);
      it = a.erase(it);
    } else {
      ++it;
    }
  }
  print(ans);
}

// -------------------- Main --------------------
int main() {
  fast_io();
  // precompute_factorials();

  int t = 1;
  cin >> t;
  for (int tc = 1; tc <= t; ++tc) {
#ifdef BM_DEBUG
    const auto start_time = chrono::high_resolution_clock::now();
    solve();
    const auto end_time = chrono::high_resolution_clock::now();
    log_case_time(tc, t, end_time - start_time);
#else
    solve();
#endif
  }
  return 0;
}
