#include <bits/stdc++.h>
using namespace std;
int main() {
    int t;
    cin >> t;
    while(t--) {
        int n, m;
        cin >> n >> m;
        priority_queue<int, vector<int>, greater<int>> s;
        for(int i=0;i<n;i++) {
            int g;cin >> g;
            s.push(g);
        }

        vector<pair<int, int>> b(m);
        for(int i=0;i<m;i++) {
            cin >> b[i].first;
        }
        for(int i=0;i<m;i++) {
            cin >> b[i].second;
        }
        sort(b.begin(), b.end());
        vector<int> d;
        int e=0;

        for(int j=0;j<m;j++) {
            if(s.empty()) break;
            int y = b[j].first;
            int upgrade = b[j].second;
            if(upgrade == 0) {
                d.push_back(y);
                continue;
            }
            int x=s.top();s.pop();
            while(x < y) {
                if(s.empty()) break;
                x=s.top();s.pop();
            }
            if(x >= y) {
                s.push(max(x, upgrade));
                e++;
            }
        }
        for(int j=0;j<d.size();j++) {
            if(s.empty()) break;
            int x=s.top();s.pop();
            while(d[j] > x) {
                if(s.empty()) break;
                x=s.top();s.pop();
            }
            if(x >= d[j]) {
                e++;
            }
        }
        cout << e << "\n";
    }
    return 0;
}