#include <bits/stdc++.h>
using namespace std;
int main() {
    int t;
    cin >> t;
    while(t--) {
        int n, m;
        cin >> n >> m;
        priority_queue<int, vector<int>, greater<int>> s;
        for(int i=0;i<n;i++) {
            int g;cin >> g;
            s.push(g);
        }

        vector<pair<int, int>> b(m);
        for(int i=0;i<m;i++) {
            cin >> b[i].first;
        }
        for(int i=0;i<m;i++) {
            cin >> b[i].second;
        }
        sort(b.begin(), b.end());
        vector<int> d;
        vector<int> s2;
        int e=0;

        for(int j=0;j<m;j++) {
            if(s.empty()) break;
            int y = b[j].first;
            int upgrade = b[j].second;
            if(upgrade == 0) {
                d.push_back(y);
                continue;
            }
            int x=s.top();
            while(x < y) {
                if(s.empty()) break;
                s2.push_back(x);
                s.pop();
                x=s.top();
            }
            if(x >= y) {
                s.pop();
                s.push(max(x, upgrade));
                e++;
            }
        }
        while(s.size()) {
            s2.push_back(s.top());s.pop();
        }
        int i = -1;
        for(int j=0;j<d.size();j++) {
            if(i == s2.size()) break;
            int x=0;
            while(d[j] > x) {
                i++;
                if(i == s2.size()) break;
                x=s2[i];
            }
            if(x >= d[j]) {
                e++;
            }
        }
        cout << e << "\n";
    }
    return 0;
}