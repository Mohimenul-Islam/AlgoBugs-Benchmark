#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
int const N=500000;
LL f[N],b[N],c[N];
bool st[N];
priority_queue<LL, vector<LL>, greater<LL>> heap;
priority_queue<LL, vector<LL>, greater<LL>> Heap;
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,m;
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++){
			scanf("%lld",&f[i]);	
			heap.push(f[i]);
		}	
//		cout<<1111<<endl;
		for(int i=1;i<=m;i++)scanf("%lld",&b[i]);
		for(int i=1;i<=m;i++)scanf("%lld",&c[i]);
		vector<int> a(m+1);
		for(int i=1;i<=m;i++){
			a[i]=i;
		}
//		cout<<11<<endl;
		sort(f+1,f+1+n);
		sort(a.begin()+1,a.end(),[&](int i,int j){
			return b[i]<b[j];
		});
		int ans=0;
//		for(int i=1;i<=m;i++){
//			cout<<b[a[i]]<<' ';
//		}
//		cout<<endl;
		for(int i=1;i<=m;i++)
		{
			int idx=a[i];
			if(c[idx]==0)continue;
			while(!heap.empty()){
				if(heap.top()>=b[idx]){
					ans++;
					heap.push(max(heap.top(),c[idx]));
					heap.pop();
					st[idx]=true;
					break;
				}else{
					Heap.push(heap.top());
					heap.pop();
				}
			}
			if(heap.empty())break;
		}
		while(!heap.empty()){
			Heap.push(heap.top());
			heap.pop();
		}
//		cout<<ans<<endl;
		for(int i=1;i<=m;i++)
		{
			int idx=a[i];
			if(Heap.empty())break;
			if(!st[idx]){
				while((!Heap.empty())&&Heap.top()<b[idx]){
					Heap.pop();
				}
				if(Heap.empty())break;
//				cout<<"bIdx:"<<b[idx]<<endl;
//				cout<<"top:"<<Heap.top()<<endl;
				Heap.pop();
				ans++;
			}
		}
		for(int i=1;i<=m;i++){
			st[i]=false;	
			f[i]=b[i]=c[i]=0;
		}
		while(!heap.empty())heap.pop();
		while(!Heap.empty())Heap.pop();
		
		cout<<ans<<endl;
	}	
}
