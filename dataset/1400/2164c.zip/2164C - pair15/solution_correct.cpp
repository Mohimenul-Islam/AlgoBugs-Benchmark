#include <bits/stdc++.h>
#define test int t;cin>>t;while(t--)
typedef long long ll;
using namespace std; 
   
void solve(){
     int n,m;cin>>n>>m;
     vector<int>b(m),c(m);
     multiset<int>swords;
     for(int i=0;i<n;i++){
        int x;cin>>x;
        swords.insert(x);
     }
     for(int i=0;i<m;i++) cin>>b[i];
     for(int i=0;i<m;i++) cin>>c[i];
     vector<pair<int,int>>a;
     vector<int>type2;
     for(int i=0;i<m;i++){
        if(c[i]>0){
            a.push_back({b[i],c[i]});
        }else{
            type2.push_back(b[i]);
        }
     }
     sort(a.begin(),a.end());
     ll ans=0;
     for(int i=0;i<a.size();i++){
        int req = a[i].first;
        int gain = a[i].second;
        auto it = swords.lower_bound(req);
        if(it!=swords.end()){
            int val = *it;
            val = max(val,gain);
            swords.erase(it);
            swords.insert(val);
            ans++;
        }else{
            break;
        }
     }
     sort(type2.begin(),type2.end());
     auto it=swords.begin();
     for(auto v:type2){
        while(it!=swords.end() && *it<v) it++;
        if(it==swords.end()) break;
        ans++;
        it++;        
     }
     cout<<ans<<"\n";
}
   
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    test{
        solve();
    }
return 0;
}