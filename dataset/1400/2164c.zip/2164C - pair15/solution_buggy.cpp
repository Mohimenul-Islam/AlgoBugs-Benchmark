#include <bits/stdc++.h>
#define test int t;cin>>t;while(t--)
typedef long long ll;
using namespace std; 

bool cmp(pair<int,int>&a,pair<int,int>&b){
    if(a.first==b.first) return a.second<b.second;
    return a.first>b.first;
}
   
void solve(){
     int n,m;cin>>n>>m;
     vector<int>a(n),b(m),c(m);
     vector<int>temp;
     for(int i=0;i<n;i++) cin>>a[i];
     for(int i=0;i<m;i++) cin>>b[i];
     for(int i=0;i<m;i++) cin>>c[i];
     vector<pair<int,int>>arr;
     for(int i=0;i<m;i++) arr.push_back({c[i],b[i]});
     sort(a.begin(),a.end());
     vector<int>swords;
     swords=a;
     sort(arr.begin(),arr.end(),cmp);
     for(int i=0;i<m;i++){
        auto it = lower_bound(a.begin(),a.end(),arr[i].second);
        if(it!=a.end()){
            int ind = it-a.begin();
            swords[ind] = max(swords[ind],arr[i].first);
        }
     }
     ll ans=0;
     sort(swords.begin(),swords.end());
     int maxi = swords[n-1];
     for(int i=0;i<m;i++){
        if(c[i]==0){
            temp.push_back(b[i]);
        }else{
            if(b[i]<=maxi) ans++;
        }
     }
     sort(temp.begin(),temp.end());
     int tsize=temp.size();
     int i=0;
     int j=0;
     while(i<n && j<tsize){
        if(a[i]>=temp[j]){
            ans++;
            i++;
            j++;
        }else{
            i++;
        }
     }
     cout<<ans<<"\n";
}
   
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    test{
        solve();
    }
return 0;
}