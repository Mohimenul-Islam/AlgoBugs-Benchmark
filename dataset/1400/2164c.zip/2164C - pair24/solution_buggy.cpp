#include <bits/stdc++.h>
using namespace std;
#define int long long
const int MAXN = 2e5+5;

int a[MAXN];
struct mons{
    int b;
    int c;
}mon[MAXN];

bool operator < (mons x, mons y) {
    if (x.b != y.b) return x.b < y.b;
    return x.c > y.c; 
}

void solve(){
    priority_queue<mons>e;

    priority_queue<int> q;
    multiset<int>sword;
    int n,m;
    cin >> n >> m;
    for (int i=1; i<=n; i++) {
        cin >> a[i];
        sword.insert(a[i]);
    }
    for (int i=1; i<=m; i++) {
        cin >> mon[i].b;
    }
    for (int i=1; i<=m; i++) {
        cin >> mon[i].c;
    }

    for (int i=1; i<=m; i++) {
        if (mon[i].c > 0) {
            e.push({mon[i].b, mon[i].c});
        }
        else q.push(mon[i].b);
    }
    int ans=0;

    while (!e.empty()){
        auto t = e.top();
        auto it = sword.lower_bound(t.b);
        if (it!=sword.end()) {
            if (*it < t.c) {
                sword.erase(it);
                sword.insert(t.c);
            }
            ans++;
        }
        else {
            q.push(t.b);
        }
        e.pop();
    }

    while (!q.empty()) {
        auto monster = q.top();
        auto it = sword.lower_bound(monster);
        if (it!=sword.end()) {
            ans++;
            sword.erase(it);
        }
        q.pop();
    }
    cout << ans << endl;
}

signed main(){
    int T;
    cin >> T;
    while (T--) {
        solve();
    }
    return 0;
}