#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;
typedef long long ll;
#define FAST_IO ios_base::sync_with_stdio(false); cin.tie(NULL);
#define yes cout << "Yes\n"
#define no cout << "No\n"
#define Oset tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update>
ll const inf = 1e17+1;
ll const M = 1e5+10;
ll const N = 1e6;
const int mod = 1e9+7;
ll dx[8]={-1,0,1,0,1,-1,-1,1};
ll dy[8]={0,1,0,-1,1,-1,1,-1};

ll gcd(ll a, ll b)
{
    return b==0 ? a : gcd(b,a%b);
}  

void solve(int te) {
    // cout << "Case #" << te << ": ";
    ll n,k; cin>>n>>k;
    vector<ll> a(n), b(n);
    for(ll i=0;i<n;i++)cin>>a[i];
    for(ll i=0;i<n;i++)cin>>b[i];
    
    ll sub_sum = -2e9, cur = 0;
    vector<ll> best_end_pre(n,-2e9), best_end_suff(n,-2e9), max_pre(n,0), max_suff(n,0);
    for(ll i=0;i<n;i++) {
        vector<ll> cur_b;
        if(cur <= 0) {
            cur = a[i];
        }
        else {
            cur += a[i];
        }
        
        best_end_pre[i] = cur;
        max_pre[i] = best_end_pre[i];
        sub_sum = max(sub_sum, cur);
        if(i)max_pre[i] = max(max_pre[i], max_pre[i-1]);
    }
    cur = 0;
    for(ll i=n-1;i>=0;i--) {
        if(cur <= 0)cur = a[i];
        else cur += a[i];

        best_end_suff[i] = cur;
        max_suff[i] = best_end_suff[i];
        if(i!=n-1)max_suff[i] = max(max_suff[i], max_suff[i+1]);
    }

   
    
    if(k&1) {
       ll ans = -2e9;
       cur = 0;
       for(ll i=0;i<n;i++) {
          cur = a[i] + b[i];
          if(i)cur += best_end_pre[i-1];
          if(i!=n-1)cur += best_end_suff[i+1];
          if(i)cur = max(cur, max_pre[i-1]);
          if(i!=n-1)cur = max(cur, max_suff[i+1]);
          ans = max(ans, cur);
       }
       cout<<ans<<endl;
    } else cout<<sub_sum<<endl;
};      
        
int main()
{
    FAST_IO
    // #ifndef ONLINE_JUDGE
    // freopen("input.txt","r",stdin);
    // freopen("output.txt","w",stdout);
    // // #endif
    int T;
    cin >> T ;
    for(int t = 1; t <= T; t++)solve(t);
    // solve(1);
}













