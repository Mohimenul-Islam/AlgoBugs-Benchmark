#include <bits/stdc++.h>
using namespace std;

int main() {
    int t; cin >> t;
    while (t--) {
        int n, k; cin >> n >> k;
        vector<int> a(n);
        vector<int> b(n);
        for (int i=0; i<n; i++) {
            cin >> a[i];
        }
        for (int i=0; i<n; i++) {
            cin >> b[i];
        }

        vector<long long> maxS(n);
        long long sum = 0;
        for (int j=0; j<n; j++) {
            sum = max((long long)a[j], sum + a[j]);
            maxS[j] = sum;
        }

        vector<long long> maxE(n);
        sum = 0;
        for (int j=n-1; j>=0; j--) {
            sum = max((long long)a[j], sum + a[j]);
            maxE[j] = sum;
        }

        if (k % 2 == 0) {
            long long best = maxS[0];
            for (int i=0; i<n; i++) {
                best = max(best, maxS[i]);
            }
            cout << best << "\n";
        }
        else {
            long long best = maxS[0] + maxE[0] - a[0] + b[0];
            for (int i=0; i<n; i++) {
                best = max(best, maxS[i] + maxE[i] - a[i] + b[i]);
            }
            cout << best << "\n";
        }
    }
}