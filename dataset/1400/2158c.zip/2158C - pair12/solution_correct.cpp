#include<bits/stdc++.h>
#define int long long
#define ull unsigned long long
#define pii pair<int,int>
#define endl '\n'
using namespace std;
const int N = 3e5 + 5, P = 131, mod  = 998244353, INF = 1e18;




void solve()
{
    int n, k;
    cin >> n >> k;
    vector<int> a(n + 1), b(n + 1);
    for (int i = 1; i <= n; i++) cin >> a[i];
    for (int i = 1; i <= n; i++) cin >> b[i];
    if (k % 2 == 0) {
        int ans = -INF, sum = 0;
        for (int i = 1; i <= n; i++) {
            sum += a[i];
            ans = max(ans, sum);
            if (sum < 0) sum = 0;
        }
        cout << ans << endl;
        return;
    }
    vector<int> sum1(n + 1), sum2(n + 2);
    for (int i = 1; i <= n; i++) sum1[i] = sum1[i - 1] + a[i];
    for (int i = n; i >= 1; i--) sum2[i] = sum2[i + 1] + a[i];
    vector<int> mn1(n + 1), mn2(n + 2);
    for (int i = 1; i <= n; i++) mn1[i] = min(mn1[i - 1], sum1[i]);
    for (int i = n; i >= 1; i--) mn2[i] = min(mn2[i + 1], sum2[i]);
    mn2[n + 1] = 0;
    int ans = -INF;
    for (int i = 1; i <= n; i++) {
        int cnt1 = sum1[i] - mn1[i - 1], cnt2 = sum2[i + 1] - mn2[i + 1];
        ans = max(ans, cnt1 + cnt2 + b[i]);
    }
    cout << ans << endl;
}
signed main()
{
    cin.tie(0);cout.tie(0);
    ios::sync_with_stdio(false);
    int t = 1;
    cin >> t;
    while (t--)
        solve();
    return 0 ^ 0;
}