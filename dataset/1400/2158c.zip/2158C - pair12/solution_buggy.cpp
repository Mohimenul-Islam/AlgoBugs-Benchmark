#include<bits/stdc++.h>
#define int long long
#define ull unsigned long long
#define pii pair<int,int>
#define endl '\n'
using namespace std;
const int N = 3e5 + 5, P = 131, mod  = 998244353, INF = 1e18;




void solve()
{
    int n, k;
    cin >> n >> k;
    vector<int> a(n + 1), b(n + 1);
    for (int i = 1; i <= n; i++) cin >> a[i];
    for (int i = 1; i <= n; i++) cin >> b[i];
    int ans = -INF;
    if (k % 2 == 0) {
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            sum += a[i];
            ans = max(ans, sum);
            if (sum < 0) sum = 0;
        }
        cout << ans << endl;
    }
    else {
        int sum = 0, mx = 0;
        for (int i = 1; i <= n; i++) {
            sum += a[i];
            mx = max(mx, b[i]);
            ans = max(ans, sum + mx);
            if (sum + mx < 0) sum = 0, mx = 0;
        }
        cout << ans << endl;
    }
}
signed main()
{
    cin.tie(0);cout.tie(0);
    ios::sync_with_stdio(false);
    int t = 1;
    cin >> t;
    while (t--)
        solve();
    return 0 ^ 0;
}