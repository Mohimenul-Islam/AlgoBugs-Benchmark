#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main() {
    cin.tie(nullptr);
    ios::sync_with_stdio(false);
    int tests; cin >> tests;
    for (int i = 0; i < tests; ++i) {
        int length; int turns; cin >> length >> turns;
        turns = abs(turns % 2);
        if (turns == 0) {
            vector<ll> elements(length);
            for (int j = 0; j < length; ++j) {
                cin >> elements[j];
            }
            vector<ll> useless(length);
            for (int j = 0; j < length; ++j) {
                cin >> useless[j];
            }
            vector<ll> dp(length);
            dp[0] = elements[0];
            ll ans; ans = dp[0];
            for (int j = 0; j < length; ++j) {
                if (j != 0) {
                    dp[j] = max(dp[j-1]+elements[j],elements[j]);
                    ans = max(ans,dp[j]);
                }
            }
            cout << ans << '\n';
        }
        else {
            vector<ll> elements(length);
            vector<ll> modifiers(length);
            for (int j = 0; j < length; ++j) {
                cin >> elements[j];
            }
            for (int j = 0; j < length; ++j) {
                cin >> modifiers[j];
            }
            vector<ll> dp(length);
            dp[0] = elements[0] + modifiers[0];
            ll ans; ans = dp[0];
            ll curr_mod; curr_mod = modifiers[0];
            for (int j = 0; j < length; ++j) {
                if (j != 0) {
                    dp[j] = max(dp[j-1] - curr_mod +max(curr_mod, modifiers[j])+elements[j],elements[j]+modifiers[j]);
                    if (dp[j] == dp[j-1] - curr_mod +max(curr_mod, modifiers[j])+elements[j]) {
                        if (dp[j-1] - curr_mod +max(curr_mod, modifiers[j])+elements[j] != elements[j] + modifiers[j]) {
                            curr_mod = max(curr_mod,modifiers[j]);
                        }
                    }
                    
                }
                ans = max(ans,dp[j]);
            }
            cout << ans << '\n';
        }
    }
}