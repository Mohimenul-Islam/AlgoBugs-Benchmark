/* **Ujjwal Khanna** */
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define mod 1000000007
#define vi vector<int>
#define vl vector<long long>
#define vc vector<char>
float log_a_to_base_b(ll a, ll b){
    return (float) log2(a)/log2(b);
}
ll gcd(ll a,ll b){if(b == 0)return a;return gcd(b, a % b);}
ll lcm(ll a, ll b){return (a/gcd(a,b)*b);}
vector<bool> comp(1e5+1);
vector<int> primes;
void sieve(){
    for(int i=2; i*i<=1e5; i++)
        if(!comp[i])
            for(int j=i*i; j<=1e5; j+=i)
                comp[j] = true;
    for(int i=2; i<=1e5; i++)
        if(!comp[i])
            primes.push_back(i);
}
class DisjointSet {
    vector<int> rank, parent, size;
public:
    DisjointSet(int n) {
        rank.resize(n + 1, 0);
        parent.resize(n + 1);
        size.resize(n + 1);
        for (int i = 0; i <= n; i++) {
            parent[i] = i;
            size[i] = 1;
        }
    }
    int findUPar(int node) {
        if (node == parent[node])
            return node;
        return parent[node] = findUPar(parent[node]);
    }
    void unionByRank(int u, int v) {
        int ulp_u = findUPar(u);
        int ulp_v = findUPar(v);
        if (ulp_u == ulp_v) return;
        if (rank[ulp_u] < rank[ulp_v]) {
            parent[ulp_u] = ulp_v;
        }
        else if (rank[ulp_v] < rank[ulp_u]) {
            parent[ulp_v] = ulp_u;
        }
        else {
            parent[ulp_v] = ulp_u;
            rank[ulp_u]++;
        }
    }
    void unionBySize(int u, int v) {
        int ulp_u = findUPar(u);
        int ulp_v = findUPar(v);
        if (ulp_u == ulp_v) return;
        if (size[ulp_u] < size[ulp_v]) {
            parent[ulp_u] = ulp_v;
            size[ulp_v] += size[ulp_u];
        }
        else {
            parent[ulp_v] = ulp_u;
            size[ulp_u] += size[ulp_v];
        }
    }
};

int sign(ll n){
    if(n>=0) return 1;
    if(n<0) return -1;
}
void solve() {
    
    int n,k;
    cin>>n>>k;
    vi a(n),b(n);
    for(int i=0;i<n;i++)    cin>>a[i];
    for(int i=0;i<n;i++)    cin>>b[i];

    if(!(k&1)){
        ll sum=0,maxi=INT_MIN;
        for(int i=0;i<n;i++){
            sum+=a[i];
            maxi=max(maxi,sum);
            sum=max(0LL,sum);
        }
        cout<<maxi<<endl;
        return;
    }

    vl seg,maxSeg;
    int i=0,j=0;

    while(i<n){
        ll sum=0;
        ll maxi=INT_MIN;
        while(j<n && (sign(a[j])==sign(a[i]))){ sum+=a[j]; maxi = max(maxi,(ll)b[j]);    j++;}
        seg.push_back(sum);
        maxSeg.push_back(maxi);
        i=j;
    }
    vl pre(n),suf(n);
    ll sum=0;
    for(int i=0;i<n;i++){
        pre[i] = sum;
        sum+=a[i];
        sum=max(0LL,sum);
    }
    sum=0;
    for(int i=n-1;i>=0;i--){
        suf[i] = sum;
        sum+=a[i];
        sum=max(0LL,sum);
    }

    ll maxi=INT_MIN;
    for(int i=0;i<n;i++){
        sum = a[i]+b[i]+pre[i]+suf[i];
        maxi = max(maxi,sum);
    }
    cout<<maxi<<endl;
    
}
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    //sieve();
    ll test;
    cin >> test;
    while (test--) {
        solve();
    }
    return 0;
}