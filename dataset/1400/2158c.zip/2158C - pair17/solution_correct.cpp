//
// Created by EZNARWHAL on 4/4/1984.
//
#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <map>
#include <deque>
#include <numeric>
#include <random>
#include <unordered_set>
#include <unordered_map>
#include <set>

using namespace std;
typedef long long ll;

const int INF = 2147483647;
const ll LLINF = 9223372036854775807;
const ll MOD = 1000000007;

vector<int> sieve;
void Sieve(int n) {
    sieve.resize(n+1);
    for (int i = 2; i <= n; i++) {
        for (int j = i * 2; j <= n; j+=i) {
            sieve[j] = 1;
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////// VVV THE GOOD PART STARTS HERE VVV //////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void sol(int n, int k, vector<ll>& a, vector<ll>& b) {
    vector<ll> pref(n), suf(n);
    ll temp = 0;
    for (int i = 0; i < n; i++) {
        temp = max(temp, 0LL);
        temp += a[i];
        pref[i] = max(a[i], temp);
    }
    temp = 0;
    for (int i = n-1; i >= 0; i--) {
        temp = max(temp, 0LL);
        temp += a[i];
        suf[i] = max(a[i], temp);
    }
    for (int i = 0; i < n; i++) {
        if (k % 2 == 0) {
            b[i] = 0;
        }
        else {
            b[i] = abs(b[i]);
        }
    }
    ll ans = -LLINF-1;
    for (int i = 0; i < n; i++) {
        ans = max(ans, pref[i] + suf[i] - a[i] + b[i]);
    }
    cout << ans << '\n';
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    Sieve(1e6);
    int tt;
    cin >> tt;
    while (tt--) {
        int n, k;
        cin >> n >> k;
        vector<ll> a(n), b(n);
        for (auto& i : a) cin >> i;
        for (auto& i : b) cin >> i;
        sol(n, k, a, b);
    }
}