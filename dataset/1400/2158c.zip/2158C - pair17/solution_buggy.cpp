//
// Created by EZNARWHAL on 4/4/1984.
//
#include <iostream>
#include <cmath>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <map>
#include <deque>
#include <numeric>
#include <random>
#include <unordered_set>
#include <unordered_map>
#include <set>

using namespace std;
typedef long long ll;

const int INF = 2147483647;
const ll LLINF = 9223372036854775807;
const ll MOD = 1000000007;

vector<int> sieve;
void Sieve(int n) {
    sieve.resize(n+1);
    for (int i = 2; i <= n; i++) {
        for (int j = i * 2; j <= n; j+=i) {
            sieve[j] = 1;
        }
    }
}

////////////////////////////////////////// VVV THE GOOD PART STARTS HERE VVV //////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void sol(int n, int k, vector<int>& a, vector<int>& b) {
    vector<ll> dp(n);
    for (int i = 0, j = 0; i < n; i++) {
        dp[i] = dp[max(0, i-1)] + a[i];
        while (dp[i] < 0 && j < i) {
            dp[i] -= dp[j];
            j++;
        }
    }
    if (k % 2 == 0) {
        for (int i = 0; i < n; i++) {
            if (k % 2 == 0) {
                b[i] = 0;
            }
            else {
                b[i] = abs(b[i]);
            }
        }
    }
    ll ans = -LLINF-1;
    for (int i = 0; i < n; i++) {
        if (dp[i] < 0 && dp[i] + b[i] >= 0) {
            ans = max(ans, i == 0 ? 0 : dp[i-1] + dp[i] + b[i] + dp[i+1]);
        }
        else {
            ans = max(ans, dp[i] + b[i]);
        }
    }
    cout << ans << '\n';
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    Sieve(1e6);
    int tt;
    cin >> tt;
    while (tt--) {
        int n, k;
        cin >> n >> k;
        vector<int> a(n), b(n);
        for (auto& i : a) cin >> i;
        for (auto& i : b) cin >> i;
        sol(n, k, a, b);
    }
}