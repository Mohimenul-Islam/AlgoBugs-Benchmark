#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
    
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int t;
    cin >> t;
    
    while (t--) {
        int n, k;
        cin >> n >> k;
        
        vector<ll> a(n), b(n);
        for (int i = 0; i < n; i++) cin >> a[i];
        for (int i = 0; i < n; i++) cin >> b[i];
        
        if (k % 2 == 0) {
            ll mS = a[0], cS = a[0];
            for (int i = 1; i < n; i++) {
                cS = max(a[i], cS + a[i]);
                mS = max(mS, cS);
            }
            cout << mS << "\n";
        } else {
            vector<ll> left(n), right(n);
            
            left[0] = 0;
            ll cur = 0;
            for (int i = 1; i < n; i++) {
                cur = max(0LL, cur + a[i-1]);
                left[i] = cur;
            }
            
            right[n-1] = 0;
            cur = 0;
            for (int i = n-2; i >= 0; i--) {
                cur = max(0LL, cur + a[i+1]);
                right[i] = cur;
            }
            
            ll ans = LLONG_MIN;
            for (int i = 0; i < n; i++) {
                ll val = left[i] + (a[i] + b[i]) + right[i];
                ans = max(ans, val);
            }
            cout << ans << "\n";
        }
    }
    return 0;
}
