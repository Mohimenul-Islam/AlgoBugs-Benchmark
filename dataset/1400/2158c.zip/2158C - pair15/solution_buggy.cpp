// Problem: CF 2158 C
// Contest: Codeforces - Codeforces Round 1067 (Div. 2)
// URL: https://codeforces.com/contest/2158/problem/C
// Memory Limit: 256 MB
// Time Limit: 2000 ms
// https://greasyfork.org/scripts/471106-atcoder-better/code/AtCoder%20Better!.user.js
// 
// Powered by CP Editor (https://cpeditor.org)

#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define endl '\n'
const ll N = 2e5+10;
ll a[N],b[N];
ll L[N],R[N];
void solve()
{
	
	ll n; cin >> n;
	ll k; cin >> k;
	L[0] = 0;
	R[n+1] = 0;
	for(ll i = 1; i <= n; i++) cin >> a[i];
	for(ll i = 1; i <= n; i++) cin >> b[i];
	ll sum = 0;
	for(ll i = 1; i <= n; i++){
		
		if(sum+a[i] < 0){
			
			sum = 0;
		}else{
			sum += a[i];
			
		}
		L[i] = max(sum,L[i-1]);
	}
	
	sum = 0;
	for(ll i = n; i >= 1; i--){
		
		if(sum+a[i] < 0){
			
			sum = 0;
		}else{
			sum += a[i];
			
		}
		R[i] = max(sum,R[i+1]);
	}
	if(k%2 == 0){
		sum = a[0];
		ll ans = a[0];
		for(ll i = 1; i <= n; i++){
			
			if(sum+a[i] < 0){
				sum = a[i];
			}else{
				sum += a[i];
			}
			ans = max(ans,sum);
	    }
	    cout << ans << endl;
	    return;
	}
	
	ll ans = -1e9-10;
	
	for(ll i = 1; i <= n; i++){
		ll c = L[i-1]+R[i+1]+a[i]+b[i];
		ans = max(ans,c);
	}
	cout << ans << endl;
}
int main() {
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	ll T = 1;
	cin >> T;
	while(T--)solve();
	return 0;
}