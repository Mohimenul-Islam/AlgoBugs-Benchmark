#include <bits/stdc++.h>
#include <iomanip>
#include <cstdio>
#include <string>
#include <cmath>
using namespace std;
#define ll long long
#define ull unsigned long long
#define all(x) x.begin(), x.end()
#define fast ios_base::sync_with_stdio(false), cin.tie(nullptr), cout.tie(nullptr)
#define cin(x) for(auto& i : x) cin >> i
#define cout(x) for(auto i : x) cout << i << " "
#define input freopen("input.txt", "r", stdin)
#define output freopen("output.txt", "w", stdout)
void Seif()
 {
    fast;
    #ifndef ONLINE_JUDGE
    input, output;
    #endif
 }

const int N = 2* 1e5 + 1;
ll n, a[N], dp[N][3][2], k, b[N];
bool vis[N][3][2];
ll f(int i, int state, int op)
{
	if (i == n) return state == 0 ? LLONG_MIN : 0;
	if (dp[i][state][op] != -1 || vis[N][state][op] == 1) return dp[i][state][op];
	if (state == 2) return dp[i][state][op] = f(i + 1, 2, op);
	vis[i][state][op] = 1;
	ll ch1 = LLONG_MIN, ch2 = LLONG_MIN, ch3 = LLONG_MIN;
	if (state == 0)
	{
		ch1 = f(i + 1, 1, op) + a[i];
		if (op == 1) ch2 = f(i + 1, 1, 0) + a[i] + b[i];
		ch3 = f(i + 1, 0, op);
	}
	if (state == 1)
	{
		ch1 = f(i + 1, 1, op) + a[i];
		ch2 = f(i + 1, 2, 0);
		if (op == 1) ch3 = f(i + 1, 1,  0) + a[i] + b[i];
	}
	return dp[i][state][op] = max({ch1, ch2, ch3});
}

void solve()
{
	cin >> n >> k;
	vis[N][3][2] = {0};
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			for (int k = 0; k < 2; k++) dp[i][j][k] = -1;
		}
	}
	for (int i = 0; i < n; i++) cin >> a[i];
	for (int i = 0; i < n; i++) cin >> b[i];
	cout << f(0, 0, k % 2) << '\n';
}

int main()
{
	int t = 1;
    Seif();
	cin >> t;
	while (t--)
	{
		solve();
	}
	return 0;
}

