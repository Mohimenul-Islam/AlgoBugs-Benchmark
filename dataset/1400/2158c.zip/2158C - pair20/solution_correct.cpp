#include <bits/stdc++.h>
#define endl "\n"
using namespace std;
using ll = long long;
using ull = unsigned long long;
using int128 = __int128;
const ll inf = 0x3f3f3f3f;
const ll mod = 998244353;

ll a[210000];
ll b[210000];
ll dp[2][210000];

void solve()
{
    ll n, k;
    cin >> n >> k;
    dp[0][0] = -1e18;
    dp[1][0] = -1e18;
    for (int i = 1; i <= n; i++)
    {
        dp[0][i] = -1e18;
        dp[1][i] = -1e18;
        cin >> a[i];
    }
    for (int i = 1; i <= n; i++)
    {
        cin >> b[i];
    }

    if (k % 2 == 0)
    {
        ll sum = 0;
        ll ans = -1e18;
        for (int i = 1; i <= n; i++)
        {

            sum = max(sum, 0ll);
            sum += a[i];
            ans = max(ans, sum);
        }
        cout << ans << endl;
        return;
    }

    ll sum = 0;
    ll ans = -1e18;

    for (int i = 1; i <= n; i++)
    {
        dp[0][i] = max(dp[0][i - 1] + a[i], a[i]);
        if (dp[1][i - 1] + a[i] > a[i])
        {
            dp[1][i] = dp[1][i - 1] + a[i];
        }
        dp[1][i] = max(dp[1][i], dp[0][i - 1] + a[i] + b[i]);
        dp[1][i] = max(dp[1][i], a[i] + b[i]);
        ans = max(ans, dp[0][i]);
        ans = max(ans, dp[1][i]);
    }

    cout << ans << endl;
    return;
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);

    ll t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }

    return 0;
}