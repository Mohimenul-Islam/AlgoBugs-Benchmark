// #define AC_LIBRARY

#include <bits/stdc++.h>
#ifdef AC_LIBRARY
#include <atcoder/all>
using namespace atcoder;
#endif
using namespace std;

using ll = long long;
using ull = unsigned long long;
using i64 = int64_t;
using u64 = uint64_t;
using i128 = __int128_t;
using u128 = __uint128_t;
const int inf = numeric_limits<int>::max();
const ll infll = numeric_limits<ll>::max();
const int ninf = numeric_limits<int>::min();
const ll ninfll = numeric_limits<ll>::min();
using uchar = unsigned char;

const int mod = 1000000007;
const int mod9 = 998244353;

template<typename T, typename U>
ostream& operator<<(ostream& out, const pair<T, U>& p);
template<typename T, size_t N>
ostream& operator<<(ostream& out, const array<T, N>& a);
template<typename T>
ostream& operator<<(ostream& out, const vector<T>& v);
template<typename T>
ostream& operator<<(ostream& out, const set<T>& s);

template<typename T, typename U>
ostream& operator<<(ostream& out, const pair<T, U>& p) {
    return out << "(" << p.first << ", " << p.second << ")";
}

template<typename T, size_t N>
ostream& operator<<(ostream& out, const array<T, N>& a) {
    if (N == 0) return out << "[]";
    out << "[" << a[0];
    for (size_t i = 1; i < N; ++i)
        out << ", " << a[i];
    return out << "]";
}

template<typename T>
ostream& operator<<(ostream& out, const vector<T>& v) {
    if (v.empty()) return out << "[]";
    out << "[" << v[0];
    for (size_t i = 1; i < v.size(); ++i)
        out << ", " << v[i];
    return out << "]";
}

template<typename T>
ostream& operator<<(ostream& out, const set<T>& s) {
    if (s.empty()) return out << "{}";
    out << "{" << *s.begin();
    for (auto it = ++s.begin(); it != s.end(); ++it)
        out << ", " << *it;
    return out << "}";
}

template<typename T, typename... Ts>
inline void dbg(const T& t, const Ts&... ts) {
#ifdef DEBUG
    cerr << "[dbg]: " << t;
    ((cerr << " " << ts), ...);
    cerr << endl;
#endif
}

struct egcdres {
    ll g, x, y;
};
egcdres egcd(int a, int b) {
    if (b == 0) return {a, 1, 0};
    egcdres res = egcd(b, a % b);
    tie(res.x, res.y) = make_pair(res.y, res.x - res.y * (a / b));
    return res;
}
int modinv(int a, int m) {
    ll res = egcd(a, m).x;
    return (res % m + m) % m;
}

ll binpow(ll a, ll b, ll m) {
    a %= m;
    ll res = 1;
    for (; b > 0; b >>= 1) {
        if (b & 1) {
            res = res * a % m;
        }
        a = a * a % m;
    }
    return res;
}

int msb(ll x) {
    return __lg(x);
}

int lsb(ll x) {
    return __builtin_ctzll(x);
}

template<typename T, typename Cmp = less<T>>
void sortunique(vector<T>& v, const Cmp& cmp = Cmp()) {
    sort(v.begin(), v.end(), cmp);
    v.erase(unique(v.begin(), v.end()), v.end());
}

/*

be organized
think about easier versions
careful with implementation
stress test if possible

stuck? try:
think reverse/opposite
consider extremes lb/ub
dp[freq]=constraint
flows/matchings
d&c
<=sqrt,>sqrt
segment tree with fancy node
bitset
guess lol
use induction and try proving guesses!

*/

void preprocess() {
}

void solve() {
    int n, k; cin >> n >> k;
    vector<int> a(n);
    for (int& x : a) {
        cin >> x;
    }
    vector<int> b(n);
    for (int& x : b) {
        cin >> x;
    }

    vector<ll> pre(n + 1);
    for (int i = 1; i <= n; ++i) {
        pre[i] = max(0ll, pre[i - 1]) + a[i - 1];
    }
    vector<ll> suf(n + 1);
    for (int i = n - 1; i >= 0; --i) {
        suf[i] = max(0ll, suf[i + 1]) + a[i];
    }

    ll ans = *max_element(pre.begin() + 1, pre.end());
    if (k % 2 == 1) {
        for (int i = 0; i < n; ++i) {
            ans = max(ans, max(0ll, pre[i]) + a[i] + b[i] + max(0ll, suf[i + 1]));
        }
    }
    cout << ans << "\n";
}
/*
g++ -Wall -Wl,--stack=268435456 -DDEBUG -I . -std=c++2a -O2 main.cpp -o main && main
*/

#define TEST_CASES
// #define OUTPUT_FILE

int main() {
#ifdef DEBUG
    freopen("input.txt", "r", stdin);
    using namespace chrono;
    auto start = high_resolution_clock::now();
#endif
    ios_base::sync_with_stdio(false); cin.tie(nullptr);
#ifdef OUTPUT_FILE
    freopen("output.txt", "w", stdout);
#endif
    preprocess();
#ifdef TEST_CASES
    int t; cin >> t;
    for (; t > 0; --t) {
        solve();
    }
#else
    solve();
#endif
#ifdef DEBUG
    auto elapsed = duration_cast<milliseconds>(
        high_resolution_clock::now() - start).count();
    clog << "time: " << elapsed << "ms\n";
#endif
}