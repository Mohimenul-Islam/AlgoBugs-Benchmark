#include <bits/stdc++.h>
using namespace std;

#define ll long long

void solve() {
    int n,k;
    cin>>n>>k;
    vector<ll> a(n), b(n), l(n), r(n);
    for (int i = 0; i < n; i++) cin>>a[i];
    for (int i = 0; i < n; i++) cin>>b[i];
    l[0]=a[0];
    ll maxm=l[0];
    for (int i=1;i<n;i++) {
        l[i]=a[i]+(l[i-1]>0 ? l[i-1] : 0);
        maxm=max(maxm,l[i]);
    }
    r[n-1]=a[n-1];
    for (int i=n-2;i>=0;i--) {
        r[i]=a[i]+(r[i+1]>0 ? r[i+1] : 0);
    }
    if (k%2==0) {
        cout<<maxm<<endl;
        return;
    }
    ll ans=-2e9-10;
    for (int i=0;i<n;i++) {
        ans=max(ans,l[i]+r[i]-a[i]+b[i]);
    }
    cout<<ans<<endl;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t=1;
    cin >> t;
    while (t--) solve();
    return 0;
}