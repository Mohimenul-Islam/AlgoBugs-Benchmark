#include<iostream>
#include<vector>
#include<set>
#include<map>
using namespace std;
#define ll long long
int main() {
	int t;
	cin >> t;
	while (t--) {
		ll n, k;
		cin >> n >> k;
		vector<ll> a(n + 1);
		vector<ll> b(n + 1);
		vector<ll> dp(n + 1);
		ll i;
		for (i = 1; i <= n; i++) {
			cin >> a[i];
		}
		for (i = 1; i <= n; i++) {
			cin >> b[i];
		}

		for (i = 1; i <= n; i++) {
			if (i == 1) {
				dp[i] = a[i];
			}
			else {
				dp[i] = max(a[i], dp[i - 1] + a[i]);
			}
		}


		vector<ll> dp1(n + 1);
		for (i = 1; i <= n; i++) {

			if (i == 1) {
				dp1[i] = max(dp[i] + b[i], dp[i]);
			}
			else {


				dp1[i] = max(dp[i], max(dp[i - 1] + a[i] + b[i], max(a[i] + b[i],dp1[i - 1] + a[i])));




				/*
				//证明dp1[i - 1]没选择加上b[i - 1]
				if (dp1[i-1] == dp[i-1]) {
					dp1[i] = max(dp1[i - 1] + a[i], max(dp[i] + b[i], dp[i]));
				}
				else {
					///this
					dp1[i] = max(dp[i-1] + a[i] + b[i], dp1[i - 1] + a[i]);
				}
				*/
			}

		}

		ll MAX1 = -1e9;
		ll MAX2 = -1e9;

		
		//cout << "          "; 
		for (i = 1; i <= n; i++) {
			//cout << dp[i] << " ";
			MAX1 = max(MAX1, dp[i]);
		}
		//cout << endl;
		//cout << "          ";
		for (i = 1; i <= n; i++) {
			//cout << dp1[i] << " ";
			MAX2 = max(MAX2, dp1[i]);
		}
		//cout << endl;
		
		if (k % 2 == 0) {
			cout << MAX1 << endl;
		}
		else {
			cout << MAX2 << endl;
		}














	}







	return 0;
}



