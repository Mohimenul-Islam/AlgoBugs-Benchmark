#include<bits/stdc++.h>
#define int long long
#define ent '\n'
#define db double
#define yes cout<<"YES"
#define no cout<<"NO"
#define ali cout<<"Alice"
#define bob cout<<"Bob"
using namespace std;
const int inf=2e18;
const int infm=-2e18;
const int N=1e6;
const int M=1e9+7;
void solve() {
    int n,k;
    cin>>n>>k;
    vector<int>a(n),b(n);
    for(int &val:a) cin>>val;
    for(int &val:b) cin>>val;
    if(k&1){
        vector<int>l(n);
        for(int i=0;i<n;i++){
            if(i==0) {l[i]=a[i];continue;}
            l[i]=max(l[i-1],0ll)+a[i];
        }
        vector<int>r(n);
        for(int i=n-1;i>=0;i--){
            if(i==n-1) {r[i]=a[i];continue;}
            r[i]=max(r[i+1],0ll)+a[i];
        }
        int ans=infm;
        for(int i=0;i<n;i++){
            ans=max(ans,l[i]+r[i]-a[i]+b[i]);
        }
        cout<<ans;
    }else{
        int best=infm;
        int s=0;
        for(int i=0;i<n;i++){
            if(s<0){
                s=0;
            }
            s+=a[i];
            best=max(best,s);
        }
        cout<<best;
    }
}
signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int t=1;
    cin>>t;
    while (t--) {
        solve();
        cout << ent;
    }
    return 0;
}