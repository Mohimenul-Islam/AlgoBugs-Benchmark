#include<bits/stdc++.h>
#define int long long
#define ent '\n'
#define db double
#define yes cout<<"YES"
#define no cout<<"NO"
#define ali cout<<"Alice"
#define bob cout<<"Bob"
using namespace std;
const int inf=2e18;
const int infm=-2e18;
const int N=1e6;
const int M=1e9+7;
void solve() {
    int n,k;
    cin>>n>>k;
    vector<int>a(n),b(n);
    for(int &val:a) cin>>val;
    for(int &val:b) cin>>val;
    if(k&1){
        int mx=infm;
        int best=infm;
        int s=0,x=0;
        bool f=0;
        for(int i=0;i<n;i++){
            if(b[i]>=mx&&f){
                s+=x;
                f=0;
            }
            mx=max(mx,b[i]);
            s+=a[i];
            best=max(best,s+mx);
            if(s+mx<0){
                s=0;
                mx=0;
            }else if(s<0){
                f=1;
                x=s;
            }
        }
        cout<<best;
    }else{
        int best=infm;
        int s=0;
        for(int i=0;i<n;i++){
            if(s<0){
                s=0;
            }
            s+=a[i];
            best=max(best,s);
        }
        cout<<best;
    }
}
signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int t=1;
    cin>>t;
    while (t--) {
        solve();
        cout << ent;
    }
    return 0;
}