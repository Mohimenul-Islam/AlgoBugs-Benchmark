# C. Annoying Game

**Time limit:** 2 seconds
**Memory limit:** 256 megabytes

## Problem Statement

You are given two integer arrays $$$a$$$ and $$$b$$$, both of length $$$n$$$, and a total number of turns $$$k$$$.

Alice and Bob play a game by taking turns modifying array $$$a$$$. Alice goes first. The game lasts for exactly $$$k$$$ turns.

On their turn, a player must choose an index $$$i$$$ ($$$1 \\leq i \\leq n$$$) and perform one of the following operations:

*   Add: Increase $$$a\_i$$$ by $$$b\_i$$$, i.e., set $$$a\_i := a\_i + b\_i$$$.
*   Subtract: Decrease $$$a\_i$$$ by $$$b\_i$$$, i.e., set $$$a\_i := a\_i - b\_i$$$.

After the $$$k$$$-th turn is complete, the final score is calculated as the maximum non-empty subarray sum of the modified array $$$a$$$. Alice's goal is to maximize the final score, while Bob's goal is to minimize the final score.

Assuming both players play optimally to achieve their respective goals, determine the final score.

The maximum non-empty subarray sum of $$$a$$$ is defined as $$$\\max\_{1 \\leq i \\leq j \\leq n} S(i, j)$$$, where $$$S(i, j) = a\_i + a\_{i+1} + \\cdots + a\_j$$$. Note that empty subarrays are not considered.

## Input

Each test contains multiple test cases. The first line contains the number of test cases $$$t$$$ ($$$1 \\le t \\le 10^4$$$). The description of the test cases follows.

The first line of each test case contains two integers $$$n$$$ and $$$k$$$ ($$$1 \\le n \\le 2\\cdot 10^5$$$, $$$1 \\le k \\le 2\\cdot 10^5$$$) — the length of the arrays and the total number of turns.

The second line contains $$$n$$$ integers $$$a\_1,a\_2,\\ldots,a\_{n}$$$ ($$$-10^9 \\le a\_i \\le 10^9$$$) — the elements of array $$$a$$$.

The third line contains $$$n$$$ integers $$$b\_1,b\_2,\\ldots,b\_{n}$$$ ($$$0 \\le b\_i \\le 10^9$$$) — the elements of array $$$b$$$.

It is guaranteed that the sum of $$$n$$$ over all test cases does not exceed $$$2\\cdot 10^5$$$.

## Output

For each test case, print a single integer — the final score after $$$k$$$ turns, assuming both players play optimally.

## Sample Tests

### Input
```
5
5 200000
3 -1 9 -5 4
0 0 0 0 0
4 5
10 10 10 10
1 1 1 1
3 1
2 -7 3
1 11 3
3 2
2 -7 3
1 11 3
1 1
-3
2
```

### Output
```
11
41
9
3
-1
```

## Note

For the first test case:

*   Any move can't change the array $$$a$$$ because all elements in $$$b$$$ are zero.
*   The maximum non-empty subarray sum of this final array is $$$3 + (-1) + 9 = 11$$$.

For the second test case, one of the possible optimal sequences of moves is:

*   Alice adds $$$b\_3=1$$$ to $$$a\_3$$$. Array $$$a$$$ becomes $$$\[10, 10, 11, 10\]$$$.
*   Bob subtracts $$$b\_1=1$$$ from $$$a\_1$$$. Array $$$a$$$ becomes $$$\[9, 10, 11, 10\]$$$.
*   Alice adds $$$b\_3=1$$$ to $$$a\_3$$$. Array $$$a$$$ becomes $$$\[9, 10, 12, 10\]$$$.
*   Bob subtracts $$$b\_1=1$$$ from $$$a\_1$$$. Array $$$a$$$ becomes $$$\[8, 10, 12, 10\]$$$.
*   Alice adds $$$b\_4=1$$$ to $$$a\_4$$$. Array $$$a$$$ becomes $$$\[8, 10, 12, 11\]$$$.
*   The maximum non-empty subarray sum of this final array is $$$8+10+12+11 = 41$$$.

For the third test case, one of the possible optimal sequences of moves is:

*   Alice adds $$$b\_2=11$$$ to $$$a\_2$$$. Array $$$a$$$ becomes $$$\[2, 4, 3\]$$$.
*   The maximum non-empty subarray sum of this final array is $$$2 + 4 + 3 = 9$$$.

For the fourth test case, one of the possible optimal sequences of moves is:

*   Alice adds $$$b\_2=11$$$ to $$$a\_2$$$. Array $$$a$$$ becomes $$$\[2, 4, 3\]$$$.
*   Bob subtracts $$$b\_2=11$$$ from $$$a\_2$$$. Array $$$a$$$ becomes $$$\[2, -7, 3\]$$$.
*   The maximum non-empty subarray sum of this final array is $$$3$$$.