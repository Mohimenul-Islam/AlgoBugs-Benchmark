#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using pii = pair<int, int>;

template <class T>
bool chmax(T& a, const T& b) {
    if (a < b) {
        a = b;
        return true;
    }
    return false;
}

template <class T>
bool chmin(T& a, const T& b) {
    if (b < a) {
        a = b;
        return true;
    }
    return false;
}

#ifdef LOCAL
#define dbg(x) cerr << #x << " = " << (x) << '\n'
#else
#define dbg(x) ((void)0)
#endif

/* Scrap

if k even, find the max non-empty subarray sum


if k odd, within the max subarray sum range, add the number that results in the greatest diff
or maybe check all possible combos

*/

ll maxSubarraySum(vector<ll>& a) {
    ll maxSum = a[0];
    ll currSum = a[0];
    for (int i = 1; i < a.size(); i++) {
        currSum = max(a[i], currSum + a[i]);
        maxSum = max(currSum, maxSum);
    }
    return maxSum;
}

void solve() {
    // solution here
    int n, k;
    cin >> n >> k;
    vector<ll> a(n);
    for (int i = 0; i < n; i++) cin >> a[i];
    vector<ll> b(n);
    for (int i = 0; i < n; i++) cin >> b[i];

    ll ans = LLONG_MIN;
    if (k % 2 == 0) {
        ans = maxSubarraySum(a);
    } else {
        for (int i = 0; i < n; i++) {
            a[i] += b[i];
            ans = max(ans, maxSubarraySum(a));
            a[i] -= b[i];
        }
    }

    cout << ans << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t = 1;
    cin >> t;
    while (t--) solve();
    return 0;
}
