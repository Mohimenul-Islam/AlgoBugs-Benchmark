#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using pii = pair<int, int>;

template <class T>
bool chmax(T& a, const T& b) {
    if (a < b) {
        a = b;
        return true;
    }
    return false;
}

template <class T>
bool chmin(T& a, const T& b) {
    if (b < a) {
        a = b;
        return true;
    }
    return false;
}

#ifdef LOCAL
#define dbg(x) cerr << #x << " = " << (x) << '\n'
#else
#define dbg(x) ((void)0)
#endif

/* Scrap

if k even, find the max non-empty subarray sum


if k odd, within the max subarray sum range, add the number that results in the greatest diff
or maybe check all possible combos

*/

ll maxSubarraySum(vector<ll>& a) {
    ll maxSum = a[0];
    ll currSum = a[0];
    for (int i = 1; i < (int)a.size(); i++) {
        currSum = max(a[i], currSum + a[i]);
        maxSum = max(currSum, maxSum);
    }
    return maxSum;
}

void solve() {
    // solution here
    int n, k;
    cin >> n >> k;
    vector<ll> a(n);
    for (int i = 0; i < n; i++) cin >> a[i];
    vector<ll> b(n);
    for (int i = 0; i < n; i++) cin >> b[i];

    ll ans = LLONG_MIN;
    if (k % 2 == 0) {
        // kadane's
        ans = maxSubarraySum(a);
    } else {
        vector<ll> l(n), r(n), pref(n), suff(n);
        l[0] = pref[0] = a[0];
        for (int i = 1; i < n; i++) {
            l[i] = max(a[i], l[i - 1] + a[i]);
            pref[i] = max(pref[i - 1], l[i]);
        }
        r[n - 1] = suff[n - 1] = a[n - 1];
        for (int i = n - 2; i >= 0; i--) {
            r[i] = max(a[i], r[i + 1] + a[i]);
            suff[i] = max(suff[i + 1], r[i]);
        }
        for (int i = 0; i < n; i++) {
            ans = max(ans, l[i] + r[i] - a[i] + b[i]);
            if (i > 0) ans = max(ans, pref[i - 1]);
            if (i + 1 < n) ans = max(ans, suff[i + 1]);
        }
    }

    cout << ans << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t = 1;
    cin >> t;
    while (t--) solve();
    return 0;
}
