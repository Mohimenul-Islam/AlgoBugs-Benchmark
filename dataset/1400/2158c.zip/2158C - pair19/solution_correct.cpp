#include <bits/stdc++.h>
using namespace std;
using ll = long long;

ll maxsum(vector<ll> &a) {
    int n = a.size();
    ll res = LLONG_MIN, sum = 0;
    for (int i = 0; i < n; i++) {
        sum = max(a[i], sum + a[i]);
        res = max(res, sum);
    }
    return res;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin >> t;
    while (t--) {
        int n, k;
        cin >> n >> k;
        vector<ll> a(n), b(n);
        for (int i = 0; i < n; i++) cin >> a[i];
        for (int i = 0; i < n; i++) cin >> b[i];

        if (k % 2 == 0) {
            cout << maxsum(a) << "\n";
        } else {
            vector<ll> pre(n), suf(n);
            ll cur = 0;
            for (int i = 0; i < n; i++) {
                cur = max(a[i], cur + a[i]);
                pre[i] = cur;
            }
            cur = 0;
            for (int i = n - 1; i >= 0; i--) {
                cur = max(a[i], cur + a[i]);
                suf[i] = cur;
            }

            ll maxanswer = maxsum(a);
            for (int i = 0; i < n; i++) {
                ll cur_val = a[i] + b[i];
                ll left = (i > 0) ? max(0LL, pre[i - 1]) : 0LL;
                ll right = (i < n - 1) ? max(0LL, suf[i + 1]) : 0LL;
                maxanswer = max(maxanswer, left + cur_val + right);
            }
            cout << maxanswer << "\n";
        }
    }
    return 0;
}
