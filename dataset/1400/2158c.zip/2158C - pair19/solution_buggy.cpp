#include <bits/stdc++.h>
using namespace std;
using ll = long long;

ll maxsum(vector <ll> &a){
    int n = a.size();
    ll maxsum = LLONG_MIN, sum = 0;
    for(int i = 0 ; i < n ; i++){
		sum = max(a[i], sum+a[i]);
		maxsum = max(sum , maxsum);
	}
	return maxsum;
}
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
	int t;
	cin>>t;
	while(t--){
	    int n , k;
	    cin>>n>>k;
	    vector <ll> a(n) , b(n);
	    for(int i = 0 ; i < n ; i++){
	        cin>>a[i];
	    }
	    for(int i = 0 ; i < n ; i++){
	        cin>>b[i];
	    }
	    if(k%2 == 0){
	        cout<<maxsum(a)<<endl;
	    }
	    else{
	        
	        ll maxanswer = LLONG_MIN;
	        for(int i = 0 ; i < n; i++){
	            ll val = a[i] + b[i];
	            ll temp = a[i];
	            a[i] = val;
	            maxanswer = max(maxanswer ,maxsum(a) );
	            a[i] = temp;
	        }
	        cout<<maxanswer<<endl;
	    }
	}
    

}
