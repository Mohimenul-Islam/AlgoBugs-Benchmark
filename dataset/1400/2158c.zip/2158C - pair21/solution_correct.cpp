#include<bits/stdc++.h>
using namespace std;

#define ll long long
#define cyes cout<<"YES"<<endl
#define cno cout<<"NO"<<endl

void solve(){
    ll n,k;
    cin>>n>>k;
    ll a[n],b[n];
      ll idx1,idx2,maxi=INT_MIN,mini=INT_MAX;
    for(ll i=0;i<n;i++) {
        cin>>a[i];
       
    }
    ll msum=INT_MIN,sum=0;
    for(ll i=0;i<n;i++) {
        cin>>b[i];
           if(maxi<b[i]){
            maxi=b[i];
            idx1=i;
           }
    }
    for(ll i=0;i<n;i++){
        sum+=a[i];
        msum=max(sum,msum);
        if(sum<0) sum=0;
    }
    if(k%2==0){
        cout<<msum<<endl;
        return;
    }
    vector<ll>pref(n+1,0),suff(n+1,0);
    pref[0]=a[0];
    suff[n-1]=a[n-1];
    for(ll i=1;i<n;i++){
        pref[i]=max(pref[i-1]+a[i],a[i]);
    }
    for(ll i=n-2;i>=0;i--){
        suff[i]=max(suff[i+1]+a[i],a[i]);
    }
    for(ll i=0;i<n;i++){
        msum=max(msum,pref[i]+suff[i]-a[i]+b[i]);
    }
    cout<<msum<<endl;
}

int main()
{
    ll t;
    cin>>t;
    while(t--){
        solve();
    }
}