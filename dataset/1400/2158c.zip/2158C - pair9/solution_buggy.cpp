#include <bits/stdc++.h>
#define ll long long
#define Will_of_D ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);
#define yes cout << "YES" << '\n';
#define no cout << "NO" << '\n';
#define all(v) v.begin(),v.end()
#define F first
#define S second
#define nl '\n'
#define gap ' '
using namespace std;


void solve(int test){
    int n , k ;
    cin >> n >> k;

    ll a[n + 1] , b[n + 1];
    for(int i = 1; i <= n; i++)cin >> a[i];
    for(int i = 1; i <= n; i++)cin >> b[i];
    ll ans = INT_MIN;

    if(k % 2 == 0){
        ll mx = a[1];
        ll mx_ans = a[1];

        for(int i = 2; i <= n; i++){
            mx_ans = max(a[i] , mx_ans + a[i]);
            mx = max(mx , mx_ans);
        }
        ans = mx;
    }else {
        for(int j = 1; j <= n; j++){

            ll mx = 0 , mx_ans = 0;

            if(j == 1)mx = a[1] + b[1];
            else mx = a[1];


            if(j == 1)mx_ans = a[1] + b[1];
            else mx_ans = a[1];

        for(int i = 2; i <= n; i++){
            ll x = a[i];
            if(i == j)x += b[i];
            mx_ans = max(x , mx_ans + x);
            mx = max(mx , mx_ans);
        }
        ans = max(ans , mx);
        }
    }

    cout << ans << nl;
}

int main()
{
    Will_of_D
    int test = 1;
    cin >> test;
    for(int i = 1; i <= test; i++)
        solve(i);
}