#include <bits/stdc++.h>
#define ll long long
#define Will_of_D ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);
#define yes cout << "YES" << '\n';
#define no cout << "NO" << '\n';
#define all(v) v.begin(),v.end()
#define F first
#define S second
#define nl '\n'
#define gap ' '
using namespace std;


void solve(int test){
    int n , k ;
    cin >> n >> k;

    ll a[n + 1] , b[n + 1];
    for(int i = 1; i <= n; i++)cin >> a[i];
    for(int i = 1; i <= n; i++)cin >> b[i];
    ll ans = INT_MIN;

    if(k % 2 == 0){
        ll mx = a[1];
        ll mx_ans = a[1];

        for(int i = 2; i <= n; i++){
            mx_ans = max(a[i] , mx_ans + a[i]);
            mx = max(mx , mx_ans);
        }
        ans = mx;
    }else {
        ll suf[n + 1] , pre[n + 1];

        for(int i = 1; i <= n; i++){
            if(i == 1){
                pre[i] = a[i];
            }else if(pre[i - 1] > 0){
                pre[i] = pre[i - 1] + a[i];
            }else pre[i] = a[i];
        }

        for(int i = n; i >= 1; i--){
            if(i == n){
                suf[i] = a[i];
            }else if(suf[i + 1] > 0){
                suf[i] = suf[i + 1] + a[i];
            }else suf[i] = a[i];
        }

        for(int i = 1; i <= n; i++){
            ans = max(ans , pre[i] + suf[i] - a[i] + b[i]);
        }
    }

    cout << ans << nl;
}

int main()
{
    Will_of_D
    int test = 1;
    cin >> test;
    for(int i = 1; i <= test; i++)
        solve(i);
}