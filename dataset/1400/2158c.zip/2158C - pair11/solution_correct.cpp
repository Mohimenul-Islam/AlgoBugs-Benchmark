#include <bits/stdc++.h>

using i64 = long long;

void solve() {
    int n, k;
    std::cin >> n >> k;

    std::vector<int> a(n), b(n);
    for (int i = 0; i < n; ++i) {
        std::cin >> a[i];
    }
    for (int i = 0; i < n; ++i) {
        std::cin >> b[i];
    }

    if (k % 2 == 0) {
        i64 ans = -1E9;
        i64 d = 0;
        for (int i = 0; i < n; ++i) {
            d = std::max<i64>(d, 0) + a[i];
            ans = std::max(d, ans);
        }
        std::cout << ans << "\n";
    } else {
        i64 ans = -1E9;
        i64 s = 0;
        i64 g = 1E-9;
        std::vector<i64> fs(n);
        for (int i = 0; i < n; ++i) {
            fs[i] = std::max(-s, i > 0 ? fs[i - 1] : 0LL);
            g = std::max(g, b[i] + fs[i]);
            s += a[i];
            ans = std::max(s + g, ans);
        }
        std::cout << ans << "\n";
    }
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int t;
    std::cin >> t;

    while (t--) {
        solve();
    }
}
