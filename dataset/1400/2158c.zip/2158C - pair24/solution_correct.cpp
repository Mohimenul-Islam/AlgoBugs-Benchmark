#include <bits/stdc++.h>
using namespace std;
#define int long long

const int MAXN = 1e6+5;
int a[MAXN], b[MAXN], l[MAXN], r[MAXN];

void solve(){
    int n,k;
    cin >> n >> k;
    l[0] = 0;
    r[n+1] = 0;
    for (int i=1; i<=n; i++) {
        cin >> a[i];
    }
    for (int i=1; i<=n; i++) cin >> b[i];
    int mx=-1e18;
    for (int i=1; i<=n; i++) {
        l[i] = max(l[i-1]+a[i], a[i]);
    }
    for (int i=n; i>=1; i--) {
        r[i] = max(r[i+1]+a[i], a[i]);
    }
    int ans = -1e18;
    if (k%2==0) {
        for (int i=1; i<=n; i++) {
            ans = max(ans, l[i]+r[i]-a[i]);
        }
    }
    else {
        for (int i=1; i<=n; i++) {
            ans = max(ans, l[i]+r[i]-a[i]+b[i]);
        }
    }
    cout << ans << endl;

}

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);
    int T;
    cin >> T;
    while (T--) {
        solve();
    }
    return 0;
}