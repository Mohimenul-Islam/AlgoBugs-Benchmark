#include <bits/stdc++.h>
#include <pthread.h>
using namespace std;
using ll = long long;

void solve() {
    int n, k;
    cin >> n >> k;
    vector<int> a(n), b(n);
    for (int i = 0; i < n; i++)
        cin >> a[i];
    for (int i = 0; i < n; i++)
        cin >> b[i];
    vector<ll> l(n), r(n), lc(n), rc(n);
    for (int i = 0; i < n; i++) {
        l[i] = a[i];
        lc[i] = a[i] + b[i];
        if (i != 0 && l[i - 1] > 0) {
            l[i] += l[i - 1];
            lc[i] += l[i - 1];
        }
    }
    for (int i = n - 1; i >= 0; i--) {
        r[i] = a[i];
        rc[i] = a[i] + b[i];
        if (i != n - 1 && r[i + 1] > 0) {
            r[i] += r[i + 1];
            rc[i] += r[i + 1];
        }
    }
    ll mx = -1e18;
    for (int i = 0; i < n; i++) {
        mx = max(mx, l[i] + r[i] - a[i]);
    }
    if (k % 2 == 0) {
        cout << mx << "\n";
        return;
    } else {
        mx = -1e18;
        for (int i = 0; i < n; i++) {
            mx = max(mx, rc[i] + lc[i] - a[i] - b[i]);
        }
        cout << mx << "\n";
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t = 1;
    cin >> t;
    while (t--)
        solve();
    return 0;
}