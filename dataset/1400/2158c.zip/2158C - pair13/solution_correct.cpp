#pragma GCC optimize("O3,unroll-loops,inline,fast-math,no-stack-protector")
#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ld = long double;
using ull = unsigned long long;
using pii = pair<int, int>;
using vi = vector<int>;
using i128 = __int128;

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define sz(x) ((int)(x).size())
#define pb push_back
#define mp make_pair
#define zhomik               \
    ios::sync_with_stdio(0); \
    cin.tie(0);              \
    cout.tie(0);

const int MAX_N = 1e5 + 5;
const ll MOD = 1e9 + 7;
const ll INF = 1e9;
const ld EPS = 1e-9;

void sol() {
    ll n, m;
    cin >> n >> m;
    vector<ll> a(n), b(n);
    for (auto& x : a) cin >> x;
    for (auto& x : b) cin >> x;
    vector<ll> dp1(n + 1), dp2(n + 1);
    dp1[0] = a[0];
    ll kadane = dp1[0];
    for (ll i = 1; i < n; ++i) {
        dp1[i] = dp1[i - 1] + a[i];
        if (a[i] > dp1[i]) {
            dp1[i] = a[i];
        }
    }
    dp2[n - 1] = a[n - 1];
    for (ll i = n - 2; i >= 0; --i) {
        dp2[i] = dp2[i + 1] + a[i];
        if (a[i] > dp2[i]) {
            dp2[i] = a[i];
        }
    }
    ll cur = dp1[0];
    for (ll i = 1; i < n; ++i) {
        cur += a[i];
        if (cur < a[i]) {
            cur = a[i];
        }
        kadane = max(kadane, cur);
    }
    if (m & 1) {
        for (ll i = 0; i < n; ++i) {
            ll l = (i > 0 ? max(0ll, dp1[i - 1]) : 0ll);
            ll r = (i < n - 1 ? max(0ll, dp2[i + 1]) : 0ll);
            kadane = max(kadane, a[i] + b[i] + l + r);
        }
    }

    cout << kadane << '\n';
}

int main() {
    zhomik;
    int tt = 1;
    cin >> tt;
    while (tt--) sol();
}
/*
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡠⠀⡀⠀⠀⠀⣠⡖⠐⣶⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡴⠀⡸⠁⢠⠃⠀⢀⣴⠟⠀⢀⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⢠⠃⠀⣏⣀⡤⠚⠁⠤⠤⠾⠤⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣀⣀⣧⢸⠀⠼⠋⠁⢀⣀⣀⣀⠀⠀⠀⠀⠀⢉⡓⠶⣤⣄⣀⣀⣀⠀⠀⠀
⠀⠀⠀⠀⠀⢀⠔⠋⠁⣠⠁⠀⠛⠋⠁⠀⠀⠀⠀⠀⠤⠤⣉⡒⠖⠤⢄⣈⠛⠛⠳⠤⢤⣤⣤⠄⠀⠀
⠀⠀⠀⠀⡜⠁⢀⡤⠊⠀⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠛⢷⠄⠀⠀⠉⠑⠒⠶⣈⡉⠁⠀⠀⠀
⣀⣀⣀⠤⠖⠊⠁⠀⠀⢸⠁⠀⢀⠀⠀⠀⠀⡄⠀⠀⢶⠀⠘⣆⠀⠳⡀⠀⡄⠀⠰⢤⣤⠬⡭⣶⡶⠶
⠀⠀⠀⠀⠀⣠⠏⠀⠀⠈⠀⠀⢸⡄⢠⠀⠀⣧⣷⠀⢸⡀⢠⠘⣆⠀⠱⡀⢻⠾⣆⢢⡹⣆⠀⠀⠀⠀
⠀⠀⢀⣤⡾⡟⠀⡄⠀⡆⠀⠀⠀⢧⠸⡄⠀⢻⢹⡇⢼⢷⠈⡆⢹⢣⡀⠱⣼⡳⡙⢆⠱⠙⡆⠀⠀⠀
⠰⠶⠟⠋⢰⠃⠀⡇⠀⢹⠀⢹⡘⡜⡆⢳⡀⠸⠈⣷⢸⣾⡆⠸⠸⡄⠑⡄⢻⡇⠱⡘⣷⣧⢹⡀⠀⠀
⠀⠀⠀⠀⡎⡸⠀⢱⠀⠈⢧⠀⢇⢷⣽⡌⢧⠀⡷⢾⡀⡇⠱⡀⠃⡷⠒⠛⣺⣷⢄⠙⣽⣏⢧⣧⠀⠀
⠀⠀⠀⢰⣿⡷⣧⠀⢣⡀⠈⡆⠸⢸⠙⣿⣄⣱⣷⣴⣧⣇⠀⠹⣿⣇⣴⣶⣿⣿⣈⢦⠘⣞⠘⠉⠀⠀
⠀⠀⣤⠟⣱⣷⡟⣶⡤⢷⣄⣰⣀⣿⣄⣘⣬⣿⣿⣿⣿⣿⣷⣤⣤⣿⣿⣿⣿⣿⣿⡀⠳⣌⡇⠀⠀⠀
⠀⠀⠀⠘⠋⣸⡷⡿⣇⡿⣶⡽⠏⠛⠉⠉⠙⢿⣿⣿⣿⣿⠏⠀⠀⠻⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢠⡟⠁⢳⣿⡦⠋⣧⡀⠀⠀⠀⠀⠀⠉⠉⠉⠁⠀⠀⠀⠀⠀⠉⠉⠀⡿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣆⠈⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠛⢻⠀⠑⠤⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⡇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣀⣸⡆⠀⠀⠈⠓⠀⠀⠀⠀⠀⠀⠀⠺⣍⢉⡟⠀⢀⣼⠟⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣇⡀⠀⠀⠀⠐⢦⣀⠀⠀⠀⠀⠀⠈⠉⢀⣴⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣶⣤⣀⠀⠀⠹⢿⣶⣤⣄⣀⣀⣀⠟⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣤⣀⠉⠻⣿⣷⡋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣬⣿⣿⣷⣤⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣾⣿⣻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⣴⡿⠛⠻⢿⣿⣿⣿⣿⣿⡿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢀⠞⠛⠁⠀⠀⠈⠉⠉⠀⠉⠉⠛⣿⣿⣿⣿⣿⣿⣿⠿⣿⣿⣿⣷⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
*/