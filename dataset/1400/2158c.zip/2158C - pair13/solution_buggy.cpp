#pragma GCC optimize("O3,unroll-loops,inline,fast-math,no-stack-protector")
#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ld = long double;
using ull = unsigned long long;
using pii = pair<int, int>;
using vi = vector<int>;
using i128 = __int128;

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define sz(x) ((int)(x).size())
#define pb push_back
#define mp make_pair
#define zhomik               \
    ios::sync_with_stdio(0); \
    cin.tie(0);              \
    cout.tie(0);

const int MAX_N = 1e5 + 5;
const ll MOD = 1e9 + 7;
const ll INF = 1e9;
const ld EPS = 1e-9;

void sol() {
    ll n, m;
    cin >> n >> m;
    vector<ll> a(n), b(n);
    for (auto& x : a) cin >> x;
    ll mx = -INF, I = 0;
    for (int i = 0; i < n; ++i) {
        cin >> b[i];
        if (b[i] > mx) {
            mx = b[i];
            I = i;
        }
    }
    if (m % 2) {
        a[I] = max(a[I] + b[I], a[I] - b[I]);
    }

    ll cur = a[0], ans = a[0];
    for (ll i = 1; i < n; ++i) {
        cur += a[i];
        if (a[i] > cur) cur = a[i];
        ans = max(ans, cur);
    }
    cout << ans << '\n';
}

int main() {
    zhomik;
    int tt = 1;
    cin >> tt;
    while (tt--) sol();
}
/*
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡠⠀⡀⠀⠀⠀⣠⡖⠐⣶⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡴⠀⡸⠁⢠⠃⠀⢀⣴⠟⠀⢀⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⢠⠃⠀⣏⣀⡤⠚⠁⠤⠤⠾⠤⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣀⣀⣧⢸⠀⠼⠋⠁⢀⣀⣀⣀⠀⠀⠀⠀⠀⢉⡓⠶⣤⣄⣀⣀⣀⠀⠀⠀
⠀⠀⠀⠀⠀⢀⠔⠋⠁⣠⠁⠀⠛⠋⠁⠀⠀⠀⠀⠀⠤⠤⣉⡒⠖⠤⢄⣈⠛⠛⠳⠤⢤⣤⣤⠄⠀⠀
⠀⠀⠀⠀⡜⠁⢀⡤⠊⠀⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠛⢷⠄⠀⠀⠉⠑⠒⠶⣈⡉⠁⠀⠀⠀
⣀⣀⣀⠤⠖⠊⠁⠀⠀⢸⠁⠀⢀⠀⠀⠀⠀⡄⠀⠀⢶⠀⠘⣆⠀⠳⡀⠀⡄⠀⠰⢤⣤⠬⡭⣶⡶⠶
⠀⠀⠀⠀⠀⣠⠏⠀⠀⠈⠀⠀⢸⡄⢠⠀⠀⣧⣷⠀⢸⡀⢠⠘⣆⠀⠱⡀⢻⠾⣆⢢⡹⣆⠀⠀⠀⠀
⠀⠀⢀⣤⡾⡟⠀⡄⠀⡆⠀⠀⠀⢧⠸⡄⠀⢻⢹⡇⢼⢷⠈⡆⢹⢣⡀⠱⣼⡳⡙⢆⠱⠙⡆⠀⠀⠀
⠰⠶⠟⠋⢰⠃⠀⡇⠀⢹⠀⢹⡘⡜⡆⢳⡀⠸⠈⣷⢸⣾⡆⠸⠸⡄⠑⡄⢻⡇⠱⡘⣷⣧⢹⡀⠀⠀
⠀⠀⠀⠀⡎⡸⠀⢱⠀⠈⢧⠀⢇⢷⣽⡌⢧⠀⡷⢾⡀⡇⠱⡀⠃⡷⠒⠛⣺⣷⢄⠙⣽⣏⢧⣧⠀⠀
⠀⠀⠀⢰⣿⡷⣧⠀⢣⡀⠈⡆⠸⢸⠙⣿⣄⣱⣷⣴⣧⣇⠀⠹⣿⣇⣴⣶⣿⣿⣈⢦⠘⣞⠘⠉⠀⠀
⠀⠀⣤⠟⣱⣷⡟⣶⡤⢷⣄⣰⣀⣿⣄⣘⣬⣿⣿⣿⣿⣿⣷⣤⣤⣿⣿⣿⣿⣿⣿⡀⠳⣌⡇⠀⠀⠀
⠀⠀⠀⠘⠋⣸⡷⡿⣇⡿⣶⡽⠏⠛⠉⠉⠙⢿⣿⣿⣿⣿⠏⠀⠀⠻⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢠⡟⠁⢳⣿⡦⠋⣧⡀⠀⠀⠀⠀⠀⠉⠉⠉⠁⠀⠀⠀⠀⠀⠉⠉⠀⡿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣆⠈⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠛⢻⠀⠑⠤⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⡇⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣀⣸⡆⠀⠀⠈⠓⠀⠀⠀⠀⠀⠀⠀⠺⣍⢉⡟⠀⢀⣼⠟⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣇⡀⠀⠀⠀⠐⢦⣀⠀⠀⠀⠀⠀⠈⠉⢀⣴⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣶⣤⣀⠀⠀⠹⢿⣶⣤⣄⣀⣀⣀⠟⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣤⣀⠉⠻⣿⣷⡋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣬⣿⣿⣷⣤⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣾⣿⣻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⣴⡿⠛⠻⢿⣿⣿⣿⣿⣿⡿⣷⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⢀⠞⠛⠁⠀⠀⠈⠉⠉⠀⠉⠉⠛⣿⣿⣿⣿⣿⣿⣿⠿⣿⣿⣿⣷⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
*/