#include <bits/stdc++.h>
#define int long long
#define ll long long
#define all(v) v.begin(),v.end()
const int MAX=2e5+5;
using namespace std;
const int INF=1e9+7;
void solve(){
     int n,k;cin>>n>>k;
     vector<int>v(n),b(n);
     for(int i=0;i<n;i++) cin>>v[i];
     for(int i=0;i<n;i++) cin>>b[i];
     vector<int>l(n+2,-1000),r(n+2,-1000);
     int sum=0,mn=0,res=v[0];
     for(int i=0;i<n;i++){
        sum+=v[i];
        l[i]=sum-mn;
        res=max(res,sum-mn);
        mn=min(mn,sum);
     }
     if(k%2==0){
        cout<<res<<endl;
        return;
     }
     int suff=0,suf=0;
     for(int i=n-1;i>=0;i--){
        suff+=v[i];
        r[i]=suff-suf;
        suf=min(suf,suff);
     }
     int ans=-100;
     for(int p=0;p<n;p++){
        int lsum=0;
        if(p>0) lsum=max(l[p-1],0LL);
        int rsum=0;
        if(p<n-1) rsum=max(r[p+1],0LL);
        ans=max(lsum+rsum+v[p]+b[p],ans);
     }
     cout<<ans<<endl;
}
signed main(){
    int t=1;cin>>t;
    while(t--){
        solve();
    }
}
