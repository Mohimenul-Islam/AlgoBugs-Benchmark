#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector<int> vi; typedef vector<bool> vb;
typedef vector<ll> vll;
typedef vector<vi> vvi; typedef vector<vll> vvll;
typedef vector<string> vs;
typedef pair<int,int> pii;
typedef pair<long long, long long> pll;
typedef pair<int,pair<int,int>> ppi;        // {int, pair<int,int>}
typedef vector<vector<char>> vvc;
typedef long double ld;

template <typename T> using min_heap = priority_queue<T, vector<T>, greater<T>>;
template <typename T> using max_heap = priority_queue<T>;

#define MOD 1000000007
#define pb push_back 
#define ff first
#define ss second
#define all(x) (x).begin(), (x).end()       //Forward
#define for0(i, n) for (int i = 0; i < (int)(n); i++)    // 0 based 
#define for1(i, n) for (int i = 1; i <= (int)(n); i++)              // 1 based 
#define forc(i, l, r) for (int i = (int)(l); i <= (int)(r); i++)    // closed interver from l to r r inclusive
#define forr0(i, n) for (int i = (int)(n) - 1; i >= 0; i--)         // reverse 0 based.
#define rall(x) (x).rbegin(), (x).rend()    //reverse
#define forr1(i, n) for (int i = (int)(n); i >= 1; i--)             // reverse 1 based
#define printv(a) {for(auto u:a) cout<<u<<" "; cout<<endl;}
#define sz(a) (int)(a.size())
#define bitcount(x) __builtin_popcountll(x)
#define yes cout<<"YES\n";
#define no cout<<"NO\n";

void solve(){
    ll n,k; cin>>n>>k;
    vll a(n), b(n);
    for0(i,n) cin>>a[i];
    for0(i,n) cin>>b[i];

    k %= 2;
    // agar 0 hogya, to, no effect on sum

    ll ans = LLONG_MIN;
    for0(i,n) ans = max(ans,a[i]);

    if(k==0){ //last move by bob
        vll lsum(n);
        lsum[0]=a[0];
        for1(i,n-1){
            lsum[i] = a[i];
            if(lsum[i-1]>0) lsum[i] += lsum[i-1];
        }
        for0(i,n) ans = max(ans,lsum[i]);
    }
    else{ // last move by Alice
        vll lsum(n), rsum(n);
        lsum[0] = a[0], rsum[n-1] = a[n-1];

        for1(i,n-1){
            lsum[i] = a[i];
            if(lsum[i-1]>0) lsum[i] += lsum[i-1];
        }
        for(int i=n-2; i>=0; i--){
            rsum[i] = a[i];
            if(rsum[i+1]>0) rsum[i] += rsum[i+1];
        }

        for0(i,n){
            ans = max(ans, lsum[i]+rsum[i]-a[i]+b[i]);
        }
    }
    
    cout<<ans<<"\n";
    return;
}

int main(){
    int T=1; 
    cin >> T;
    while(T--){
        solve();
    }
    return 0;
}

// int msb(ll n){   // most significant bit
//     if(n==0) return -1;
//     int ans=0;
//     while(n>1){
//         n >>= 1;
//         ans++;
//     }
//     return ans;
// }

// set<ll> sieve(ll n){
//     vector<bool> prime(n+1, true);
//     for(ll i=2; i<=n; i++){
//         if(!prime[i]) continue;
//         for(ll j = i*i; j<=n; j+=i){
//             prime[j] = false;
//         }
//     }
//     set<ll> v;
//     for(int i=2; i<=n; i++){
//         if(prime[i]) v.insert(i);
//     }
//     return v;
// }

// class DSU{
// public:
//     vi par,sz;
//     DSU(int n){
//         par.resize(n);
//         sz.resize(n);
//         for0(i,n){
//             par[i] = i;
//             sz[i] = 1;
//         }
//     }
//     int findpar(int node){
//         if(par[node] == node) return node;
//         return par[node] = findpar(par[node]);
//     }
//     void merge(int a, int b){
//         a = findpar(a); b = findpar(b);
//         if(a==b) return;
//         else if(sz[a] > sz[b]){
//             sz[a] += sz[b];
//             par[b] = a;
//         }
//         else{
//             sz[b] += sz[a];
//             par[a] = b;
//         }
//     }
// };

// ll gcd(ll a, ll b){
//     while(b!=0){
//         ll x = b;
//         b = a%b;
//         a = x;
//     }
//     return a;
// }

// ll lcm(ll x, ll y){
//     return (x/gcd(x,y)) * 1LL * y;
// }
