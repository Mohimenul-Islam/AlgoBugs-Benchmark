#include <bits/stdc++.h>

using namespace std;
using ll = long long;
using pii = pair<int, int>;
#define all(x) (x).begin(), (x).end()
#define sz(x) (int)(x).size()
#define fi first
#define se second
#define pb push_back
#define eb emplace_back
int dx[] = {0, 0, 1, -1};
int dy[] = {1, -1, 0, 0};
template<class X, class Y> bool ckmx (X &x, const Y &y) {return x < y ? x = y, 1 : 0;}
template<class X, class Y> bool ckmn (X &x, const Y &y) {return x > y ? x = y, 1 : 0;}
const int maxn = 5e5 + 5;
const int MOD = 1e9 + 7;
const int INF = 0x3f3f3f3f;

ll dp[maxn][2];
int main()
{
    ios::sync_with_stdio(false); cin.tie(0);
    //freopen(".INP", "r", stdin);
    //freopen(".OUT", "w", stdout);
    int t; cin >> t;
    while (t--) {
        int n, k; cin >> n >> k;
        vector<int> a(n+1, 0), b(n+1, 0);
        for (int i = 1; i <= n; ++i) cin >> a[i];
        for (int i = 1; i <= n; ++i) cin >> b[i];

        memset(dp, -0x3f, sizeof dp);
        dp[0][0] = dp[0][1] = 0;
        ll ans0 = LLONG_MIN, ans1 = LLONG_MIN;
        for (int i = 1; i <= n; ++i) {
            dp[i][0] = max(dp[i-1][0] + a[i], 1LL * a[i]);
            ans0 = max(ans0, dp[i][0]);
            dp[i][1] = max({dp[i-1][1] + a[i], dp[i-1][0] + a[i] + b[i], 1LL*a[i] + b[i]});
            ans1 = max(ans1, dp[i][1]);
        }
        cout << (k & 1 ? ans1 : ans0) << '\n';
    }
    return 0;
}
