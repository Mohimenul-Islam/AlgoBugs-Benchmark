/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>

using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        string s;
        cin >> s;
        
        // for each element maintain next open bracket position
        int lastOpenPos = -1;
        vector<int> nextOpenPos(n);
        for (int i = n - 1; i >= 0; i--) {
            nextOpenPos.at(i) = lastOpenPos;
            if (s.at(i) == '(') {
                lastOpenPos = i;
            }
        }
        
        // for each elment maintain next closing bracket cnt
        vector<int> cntClosingNext(n + 1);
        cntClosingNext.at(n) = 0;
        for(int i = n - 1; i >= 0; i--) {
            cntClosingNext.at(i) = cntClosingNext.at(i + 1);
            if (s.at(i) == ')') {
                cntClosingNext.at(i)++;
            }
        }
        
        int leftOpen = 0;
        int ans = -1;
        for(int i = 0; i < n; i++) {
            if (s.at(i) == ')') {
                int needClosing = leftOpen + 1;
                
                // get next opening bracket
                int currNextOpenPos = nextOpenPos.at(i);
                // cout << "nextOpenPos " << currNextOpenPos << endl; 
                if (currNextOpenPos == -1) {
                    break;
                }
                // get next closing cnt after the choosen opening bracket
                int currNextCloseCnt = cntClosingNext.at(currNextOpenPos);
                // cout << "currNextCloseCnt " << currNextCloseCnt << endl; 
                if (currNextCloseCnt >= needClosing) {
                    ans = max(ans, i + 1 + needClosing);
                }
                
                leftOpen--;
            } else {
                leftOpen++;
            }
        }
        cout << ans << endl;
    }
    return 0;
}