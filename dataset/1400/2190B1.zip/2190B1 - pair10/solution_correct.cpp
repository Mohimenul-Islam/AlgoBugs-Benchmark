#include<bits/stdc++.h>
#define                           FAST                                                     ios_base::sync_with_stdio(false), cin.tie(0), cout.tie(0);
#define                           int                                                      long long
#define                           ll                                                       long long
#define                           ld                                                       long double
#define                           ull                                                      unsigned long long
#define                           str                                                      string
#define                           con                                                      continue
#define                           dq                                                       deque
#define                           dw                                                       vector
#define                           sz                                                       size()
#define                           fir                                                      first
#define                           sec                                                      second
#define                           yes                                                      cout<<"YES"<<endl
#define                           no                                                       cout<<"NO"<<endl
#define                           rev                                                      reverse
#define                           sortl(a)                                                 sort((a).begin()+1,(a).end())
#define                           sortl1(a)                                                sort((a).begin(),(a).end())
#define                           sortr(a)                                                 sort((a).rbegin(),(a).rend())
#define                           revl(a)                                                  reverse((a).begin(),(a).end())
#define                           all(a)                                                   a.begin(), a.end()
#define                           rall(a)                                                  a.rbegin(), a.rend()
#define                           pb                                                       push_back
#define                           ppb                                                      pop_back
#define                           pf                                                       push_front
#define                           ppf                                                      pop_front
#define                           rtr                                                      return
#define                           open                                                     freopen ("paintbarn.in", "r", stdin);
#define                           close                                                    freopen("paintbarn.out", "w", stdout);
#define                           metis                                                    multiset
#define                           ins                                                      insert
#define                           endl                                                     "\n"
using namespace std;
//using namespace __gnu_pbds;
//#include <ext/pb_ds/assoc_container.hpp>
//#include <ext/pb_ds/tree_policy.hpp>
//#define ordered_multiset tree<long long, null_type,less_equal<long long>, rb_tree_tag,tree_order_statistics_node_update>
//#define ordered_set tree<long long, null_type,less<long long>, rb_tree_tag,tree_order_statistics_node_update>

//st.order_of_key
//st.find_by_order

//typedef tree<ll, null_type, less_equal<ll>, rb_tree_tag,tree_order_statistics_node_update> ordered_multiset;
//ll pow_q(ll a23, ll n23) {
//  if (n23 == 1) {
//    return a23;
//  } else if (n23 % 2 == 1) {
//    return (a23 * pow_q(a23, n23 - 1));
//  } else {
//    ll otvet = pow_q(a23, n23 / 2);
//    return (otvet * otvet);
//  }
//}

const unsigned long long MOD=1e9+7;
const unsigned long long mod=998244353;
ll binpow(ll a1, ll n, ll m)
{
    if(n == 0)
    {
        return 1;
    }
    else
    {

        if(n == 1)
        {
            return a1 % m;
        }
        else
        {

            if(n % 2 == 0)
            {
                ll x = binpow(a1, n / 2, m) % m;
                return (x * x) % m;
            }
            else
            {
                return a1 * binpow(a1, n - 1, m) % m;
            }
        }
    }
}
int pr(int x)
{
    int k=x;
    for(int o=2;o*o<=x;o++)
    {
        if(x%o==0)
        {
            return 0;
        }
    }
    return 1;
}
int lcm(int a1,int b)
{
    return a1*b/(__gcd(a1,b));
}
ld ras(ld x,ld y,ld x1,ld y1)
{
    ld q=sqrt((x-x1)*(x-x1)+(y-y1)*(y-y1));
    return q;
}
ld ras1(ld x,ld y,ld x1,ld y1)
{
    ld q=abs(x-x1)+abs(y-y1);
    return q;
}
bool liniya(int x1, int y1, int x2, int y2, int x3, int y3)
{
    int area=x1*(y2-y3)+x2*(y3-y1)+x3*(y1-y2);
    return area==0;
}

int C(int n,int k,int mod)
{
    int sum=1;
    for(int i=1;i<=k;i++)
    {
        sum=sum*(n-i+1)%mod;
        sum=(sum*binpow(i,mod-2,mod)%mod);
    }
    return sum;
}
int factorial(int n,int m)
{
    int x=1;
    for(int i=2;i<=n+1;i+=2)
    {
        x*=i-1;
        x%=m;
        if(i<=n)
        {
            x*=i;
            x%=m;
        }
    }
    return x;
}
int nesekunja(int a,int b,int c)
{
    int ok=1;
    if(a+b<=c)
    {
        ok=0;
    }
    if(c+b<=a)
    {
        ok=0;
    }
    if(a+c<=b)
    {
        ok=0;
    }
    return ok;
}
string to_binar(int x,int n)
{
    string a="";
    while(x>0)
    {
        a+=x%2+'0';
        x/=2;
    }
    while(a.sz<n)
    {
        a+='0';
    }
    revl(a);
    return a;
}
long long to_int(string a1)
{
    long long k=0,j=0;
    str a="";
    for(long long i=0;i<a1.size();i++)
    {
        if(a1[i]=='1')
        {
            j=1;
            a+='1';
        }
        else
        {
        	if(j==1)
        	{
        		a+='0';
        	}
        }
    }
    revl(a);
    for(int i=0;i<a.size();i++)
    {
        if(a[i]=='1')
        {
            k+=binpow(2,i,1e18);
        }
    }
    return k;
}
int MEX(dw<int >a)
{
    map<int ,int >mp;
    for(int i=0;i<a.size();i++)
    {
        mp[a[i]]++;
    }
    int k=0;
    while(mp[k]>0)
    {
        k++;
    }
    return k;
}
int sqrt1(int x)
{
    if(x==0)
    {
        return 1e8;
    }
    int u=sqrt(x);
    return u;
}
int divmod(ll a, ll b, ll mod) 
{
    rtr (a%mod)*(binpow(b,mod-2,mod))%mod;
}
int FACT(int x)
{
	int ans=1;
	for(int i=1;i<=x;i++)
	{
		ans*=i;
		ans%=mod;
	}
	rtr ans;
}
void lrdu(int &x,int &y,char u)
{
	if(u=='L')
	{
		x--;
	}
	if(u=='R')
	{
		x++;
	}
	if(u=='D')
	{
		y--;
	}
	if(u=='U')
	{
		y++;
	}
}
//  (a1 / b) mod M = (a1 * pow(b , M - 2)) mod M
int ook,ook1,po,N=2e5+17;
dw<int>asd[200017];
map<int ,int >mp,mp1,ot;
void dfs(int x,int g)
{
	mp1[x]++;
	mp[g]++;
	if(asd[x].sz>1||x==1)
	{
		ot[g]++;
	}
	for(auto to:asd[x])
	{
		if(!mp1[to])
		{
			dfs(to,g+1);
		}
	}
}
void Muhammad()
{
	int mn=1e18;
	int mx=-1e18;
	int n=0,m=0,x=0,y=0,k=0,k1=0,k2=0,k3=0,k4=0,step=1;
	cin>>n;
	string a;
	cin>>a;
	
	int pos=0;
	a='?'+a;
	dw<dw<int >>dp(2,dw<int >(n+17,0));
	for(int i=n;i>=1;i--)
	{
		dp[0][i]=dp[0][i+1];
		dp[1][i]=dp[1][i+1];
		if(a[i]==')')
		{
			dp[1][i]++;
		}
		else
		{
			dp[0][i]=i;
		}
	}
	string s,s1;
	k1=-1;
	for(int i=1;i<=n;i++)
	{
		if(a[i]=='(')
		{
			k++;
			s+=a[i];
		}
		else
		{
			if(dp[0][i]>0&&dp[1][dp[0][i]]>=k+1)
			{
				s1=s;
				s1+='(';
				k1=k+1;
			}
			k--;
			s+=a[i];
		}
	}
	if(k1==-1)
	{
		cout<<-1<<endl;
		rtr;
	}
	s=s1;
	k=k1;
	for(int i=s.sz+1;i<=n;i++)
	{
		if(k3==0)
		{
			if(a[i]=='(')
			{
				k3++;
			}
			con;
		}
		if(a[i]=='(')
		{
			k1++;
		}
		else
		{
			k2++;
		}
	}
	k2-=k;
	// cout<<s<<" "<<k<<" "<<k1<<" "<<k2<<endl;
	cout<<s.sz+k+min(k2,k1)*2<<endl;
}
signed main()
{
    FAST;
//    cout<<fixed<<setprecision(6);
    long long T=1;
    cin>>T;
    if(T>=100)
    {
        ook1=1;
    }
    while(T--)
    {
        po++;
        Muhammad();
   	}
}