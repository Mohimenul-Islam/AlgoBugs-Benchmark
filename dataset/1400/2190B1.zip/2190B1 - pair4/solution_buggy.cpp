#include <bits/stdc++.h>
#include <climits>
#include <vector>
using namespace std;
typedef long long ll;

void solve() {
    int n;cin >> n;
    string s;cin >> s;
    int cnt_open = 0;
    while (cnt_open < n && s[cnt_open] == '(') cnt_open++;
    vector<int> left(n);
    left[0] = (s[0] == '(');
    for(int i = 1;i < n;++i){
        left[i] = left[i-1] + (s[i] == '(');
    }
    vector<int> right(n);
    right[n-1] = (s[n-1] == ')');
    for(int i = n-2;i >= 0;--i){
        right[i] = right[i+1] + (s[i] == ')');
    }
    int ans = INT_MIN;
    for(int i = 0;i < n;++i){
        int mn = min(left[i], right[i]);
        if(mn > cnt_open){
            ans = max(ans, mn * 2);
        }
    }
    cout << (ans == INT_MIN ? -1 : ans) << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int t;
    cin >> t;
    while (t--) solve();
    return 0;
}
/*
考虑每个位置左侧左括号右侧全部右括号
取min*2就是这个位置的最佳
只要保证 min > 连续的s的左括号长度就行
否则返回-1

*/