#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

void solve() {
    int n;
    cin >> n;
    string s;
    cin >> s;

    // 预处理后缀中 '(' 的个数，suf[i] 表示从 i 开始到末尾有多少个 '('
    vector<int> suf(n + 1, 0);
    for (int i = n - 1; i >= 0; --i) {
        suf[i] = suf[i + 1] + (s[i] == '(');
    }

    int ans = -1;
    for (int i = 0; i < n - 1; ++i) {
        // 寻找 ")(" 的位置
        if (s[i] == ')' && s[i + 1] == '(') {
            // 在这个 '(' 之后还需要至少一个 '(' 来平衡删除
            if (suf[i + 2] > 0) {
                ans = n - 2;
                break;
            }
        }
    }
    cout << ans << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int t;
    cin >> t;
    while (t--) solve();
    return 0;
}