#include <bits/stdc++.h>
using namespace std;

void solve() {
  int n, ans = -1;
  string s;
  cin >> n >> s;
  for(int i = 1, f = 0; i < n; i++) {
    if(f && s[i] == '(') {
      ans = n - 2;
    }
    f |= (s[i - 1] == ')' && s[i] == '(');
  }
  cout << ans << '\n';
}

signed main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0); cout.tie(0);
  int _;
  cin >> _;
  for(int i = 1; i <= _; i++) {
    solve();
  }
  return 0;
}