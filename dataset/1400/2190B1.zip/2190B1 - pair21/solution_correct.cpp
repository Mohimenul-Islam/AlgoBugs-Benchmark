#include <bits/stdc++.h>
#define ll long long
#define Will_of_D ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);
#define yes cout << "YES" << '\n';
#define no cout << "NO" << '\n';
#define all(v) v.begin(),v.end()
#define F first
#define S second
#define nl '\n'
#define gap ' '
using namespace std;


void solve(int test){
    int n;
    cin >> n;
    string s;
    cin >> s;

    int lo = 0;
    while(lo < n and s[lo] == '(')lo++;

    lo++;
    int cnt = 2;

    while(lo < n and cnt > 0){
        if(s[lo] == '(')cnt--;

        lo++;
    }

    if(cnt)cout << -1 << nl;
    else cout << n - 2 << nl;
}

int main()
{
    Will_of_D
    int test = 1;
    cin >> test;
    for(int i = 1; i <= test; i++)
        solve(i);
}