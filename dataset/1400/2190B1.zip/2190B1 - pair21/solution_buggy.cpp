#include <bits/stdc++.h>
#define ll long long
#define Will_of_D ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);
#define yes cout << "YES" << '\n';
#define no cout << "NO" << '\n';
#define all(v) v.begin(),v.end()
#define F first
#define S second
#define nl '\n'
#define gap ' '
using namespace std;


void solve(int test){
    int n;
    cin >> n;
    string s;
    cin >> s;

    int idx = -1;
    for(int i = 0; i < n; i++){
        if(s[i] == ')'){
            idx = i;
            break;
        }
    }

    int pre[n];
    for(int i = 0 ; i < n; i++){
        if(s[i] == ')')pre[i] = 1;
        else pre[i] = 0;
    }

    for(int i = 1; i < n; i++){
        pre[i] = pre[i - 1] + pre[i];
    }

    int ans = -1;

    for(int i = idx + 1; i < n; i++){
        if(s[i] == '(' and pre[n - 1] - pre[i] >= idx + 1){
            ans = max(ans , n - 2 * (i - idx));
        }
    }

    cout << ans << nl;
}

int main()
{
    Will_of_D
    int test = 1;
    cin >> test;
    for(int i = 1; i <= test; i++)
        solve(i);
}