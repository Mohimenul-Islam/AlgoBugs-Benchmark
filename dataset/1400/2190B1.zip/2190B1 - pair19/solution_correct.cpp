#include<bits/stdc++.h>
using namespace std;
const int N = 2e5+5;

int dp[N];

void solve(){
    int n;
    string s;
    scanf("%d",&n);
    cin>>s;

    int last_left;
    for(int i=s.size()-1;i>=0;i--){
        if(s[i]=='('){
            last_left=i;
            break;
        }
    }

    for(int i=0;i<s.size();i++){
        if(s[i]==')'&&s[i+1]=='('&&i+1!=last_left){
            printf("%d\n",n-2);
            return;
        }
    }

    printf("-1\n");
}

int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        solve();
    }
    return 0;
}