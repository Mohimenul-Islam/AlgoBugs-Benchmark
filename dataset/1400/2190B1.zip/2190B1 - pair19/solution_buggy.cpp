#include<bits/stdc++.h>
using namespace std;
const int N = 2e5+5;

int dp[N];

void solve(){
    int n;
    string s;
    scanf("%d",&n);
    cin>>s;
    string str=s;

    for(int i=0;i<s.size()-2;i++){
        bool flag=0;
        while(s[i]==')'&&s[i+1]=='('&&!flag){
            int r=s.size()-1;
            flag=1;
            while(r>i+1){
                if(s[r]=='('){
                    s.erase(r,1);
                    s.erase(i,1);
                    flag=0;
                    i--;
                    break;
                }
                r--;
            }
        }
    }

    for(int i=0;i<s.size();i++){
        if(s[i]==str[i]) continue;
        if(s[i]=='('&&str[i]==')'){
            printf("%d\n",s.size());
            return;
        }
        else{
            printf("-1\n");
            return;
        }
    }

    printf("-1\n");
}

int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        solve();
    }
    return 0;
}