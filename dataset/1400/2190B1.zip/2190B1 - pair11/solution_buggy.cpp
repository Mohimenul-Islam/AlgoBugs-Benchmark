#include<iostream>
#include<vector>
#include<algorithm>
#include<unordered_set>
#include<set>
#include<queue>
#include<string>
#include<cmath>
#include<map>
using namespace std;
typedef long long ll;

ll n;
string s;

bool check(ll mid){
	
	ll p = 0;
	bool f = false;
	ll q = 0;
	for(int i = 0 ;i<n; i++){
		if(p==mid) f = true;
		
		if(f){
			if(s[i]==')') q++;
		}
		else {
			if(s[i]=='(') p++;
		}
	}
	
	return mid<=q;
	
}
void solve(){
	cin>>n;

	cin>>s;
	ll cnt = 0;
	for(ll i = 0; i<n; i++){
		if(s[i]=='(') cnt++;
		else break;
	}
	
	ll l = cnt+1;
	
	ll r = n/2;
	ll res = 0;
	while(r>=l){
		ll mid = (r+l)/2;
		if(check(mid)) {
			l = mid+1;
			res = mid;
		}
		else r = mid-1;
	}
	if(res==0)cout<<-1<<"\n";
	else cout<<2*res<<"\n";

		return;
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	ll t;
	cin>>t;
	while(t--){
		
		solve();
		
		
	}
	return 0;
}