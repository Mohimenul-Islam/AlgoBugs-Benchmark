#include<iostream>
#include<vector>
#include<algorithm>
#include<unordered_set>
#include<set>
#include<queue>
#include<string>
#include<cmath>
#include<map>
using namespace std;
typedef long long ll;

ll n;
string s;

bool check(ll mid){
	
	ll p = 0;
	bool f = false;
	ll q = 0;
	for(int i = 0 ;i<n; i++){
		if(p==mid) f = true;
		
		if(f){
			if(s[i]==')') q++;
		}
		else {
			if(s[i]=='(') p++;
		}
	}
	
	return mid<=q;
	
}
void solve(){
	cin>>n;

	cin>>s;
	int id1= -1;
	int id2 = n;
	for(int i = 0; i<n; i++){
		if(s[i]==')'){
			id1 = i;
			break;
		}
	}
	
	for(int i = n-1; i>=0; i--){
		if(s[i]=='(') {
			id2 = i;
			break;
		}
	}
	bool f = false;
	for(int i = id1+1; i<=id2-1; i++){
		if(s[i]=='(') {
			f = true;
			break;
			
		}
	}
	if(f) cout<<n-2<<"\n";
	else cout<<-1<<"\n";
		return;
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	ll t;                                
	cin>>t;
	while(t--){
		
		solve();
		
		
	}
	return 0;
}