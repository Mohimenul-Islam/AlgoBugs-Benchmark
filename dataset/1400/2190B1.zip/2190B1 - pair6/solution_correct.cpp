#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using pii = pair<int, int>;
using vi = vector<int>;

#define pb push_back
#define eb emplace_back
#define ff first
#define ss second
#define fast_io ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
#define all(x) (x).begin(), (x).end()
#define sz(x) (int)(x).size()
#define endl "\n"
#define ri(x) int x; cin >> x;
#define rll(x) ll x; cin >> x;

#include <iostream>
#include <string>
#include <vector>

using namespace std;

void solve() {
    int n;
    cin >> n;
    string s;
    cin >> s;

    // Find the index of the very first ')'
    int curr = 0;
    while(curr < n && s[curr] == '(') {
        curr++;
    }
    
    // Calculate how many '(' exist AFTER the first ')'
    int open = (n / 2) - curr; 

    // We need at least 2 opening brackets available after our dropped ')'
    if (open >= 2) {
        cout << n - 2 << "\n";
        return; // Don't forget to exit!
    }

    // If we reach here, we couldn't make a better string
    cout << -1 << "\n";
}

int main() {
    fast_io;
    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}