#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using pii = pair<int, int>;
using vi = vector<int>;

#define pb push_back
#define eb emplace_back
#define ff first
#define ss second
#define fast_io ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
#define all(x) (x).begin(), (x).end()
#define sz(x) (int)(x).size()
#define endl "\n"
#define ri(x) int x; cin >> x;
#define rll(x) ll x; cin >> x;

#include <iostream>
#include <string>
#include <vector>

using namespace std;

void solve() {
    int n;
    cin >> n;
    string s;
    cin >> s;

    vector<int> postClosing(n + 1, 0);
    for (int i = n - 1; i >= 0; i--)
        postClosing[i] = postClosing[i + 1] + (s[i] == ')' ? 1 : 0);

    string t = "";
    int open = 0;

    for (int i = 0; i < n; i++) {
        if (s[i] == '(') {
            if (open + 1 <= postClosing[i + 1]) {
                t += '(';
                open++;
            }
        } else {
            if (open > postClosing[i + 1]) {
                t += ')';
                open--;
            }
        }
    }

    for (int i = 0; i < t.length(); i++) {
        if (t[i] != s[i]) {
            cout << t.length() << endl;
            return;
        }
    }

    cout << -1 << endl;
}

int main() {
    fast_io;
    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}