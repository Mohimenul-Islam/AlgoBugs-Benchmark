#include<bits/stdc++.h>
using namespace std;

int n;
string s;

void solve() {
	cin>>n>>s;
	
	vector<int> pfBal(n,1);
	for(int i=1;i<n;i++) pfBal[i]=pfBal[i-1]+(s[i]=='('?1:-1);
	
	vector<array<int,2>> sfBal(n,{0,0});
	sfBal[n-1][1]=1;
	for(int i=n-2;i>=0;i--) {
		if(s[i]=='(') {
			sfBal[i][0]=sfBal[i+1][0]+1;
			sfBal[i][1]=sfBal[i+1][1];
		} else {
			sfBal[i][0]=sfBal[i+1][0];
			sfBal[i][1]=sfBal[i+1][1]+1;
		}
	}
	
	int ans=-1,openNext=-1;
	for(int i=n-1;i>=0;i--) {
		if(s[i]==')'&&openNext!=-1) {
			if(sfBal[openNext+1][1]<pfBal[i-1]+1) continue;
			ans=max(ans,i+1+min(pfBal[i-1]+1+sfBal[openNext+1][0],sfBal[openNext+1][1]));
		} 
		else if(s[i]=='(') openNext=i;
	}
	
	cout<<ans<<endl;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	
	int T; cin>>T;
	while(T--) solve();
}