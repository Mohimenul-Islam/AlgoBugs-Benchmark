#include <bits/stdc++.h>
using namespace std;

void solve() {
    int n;
    cin >> n;
    string s;
    cin >> s;
    vector<int>suf(n, 0);
    int cnt = s[n - 1] == ')';
    for(int i = n - 2; i >= 0; i--) {
        if(s[i] == ')') {
            suf[i] = suf[i + 1];
            cnt++;
        }
        else suf[i] = cnt;
    }
    
    int p = 0;
    for(int i = 0; i < n; i++) {
        if(s[i] == ')') {
            if(p < suf[i]) {
                cout << n - 2 << endl;
                return;
            }
            p--;
        }
        else p++;
    }
    cout << -1 << endl;
}
int main() {
	// your code goes here
    int t;
    cin >> t;
    while(t--) solve();
}
