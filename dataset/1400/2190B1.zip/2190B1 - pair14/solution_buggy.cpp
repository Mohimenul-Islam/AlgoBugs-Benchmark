#include <bits/stdc++.h>
using namespace std;

void solve() {
    int n;
    cin >> n;
    string s;
    cin >> s;
    int in = 0;
    while(in < n && s[in] == '(') in++;
    bool flag = false;
    int cnt = in + 1;
    while(in < n) {
        if(s[in] == '(') {
            flag = true;
        }
        if(s[in] == ')' && flag) cnt--;
        in++;
    }
    
    if(cnt <= 0) cout << n - 2 << endl;
    else cout << -1 << endl;
}
int main() {
	// your code goes here
    int t;
    cin >> t;
    while(t--) solve();
}
