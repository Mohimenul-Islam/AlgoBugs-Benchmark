#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<ll, ll> pll;
typedef pair<int, int> pii;

#define all(x)      (x).begin(),(x).end()
#define X           first
#define Y           second
#define sep         ' '
#define endl        '\n'
#define SZ(x)       (ll)(x).size()

const ll MAXN = 1e6 + 10;
const ll MOD = 1e9 + 7;
const ll INF = INT_MAX;
const ll LOG = 20;

int n;
string s;

int32_t main(){
  ios::sync_with_stdio(false),cin.tie(NULL),cout.tie(NULL);

  int tc;
  for(cin >> tc; tc > 0; tc--)
  {
    cin >> n >> s;
    vector<int> a(n);
    for(int i = n - 1, res = 0; i >= 0; i--)
    {
      a[i] = res;
      if(s[i] == ')') res++;
    }
    int ans = 0, res = -1;
    for(int i = 0; i < n; i++)
    {
      if(s[i] == '(') ans++;
      else{
        if(a[i] > ans) res = 2*a[i];
        ans--;
        break;
      }
    }
    cout << res << endl;
  }

  return 0;
}
/*

*/