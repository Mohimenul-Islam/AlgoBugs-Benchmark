#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#define fi first
#define se second
#define ll long long
#define lb long double

using namespace std;
using namespace __gnu_pbds;

template<class T1, class T2> bool maximize(T1 &a, T2 b) {
    return a < b ? a = b, 1 : 0;
}

template<class T1, class T2> bool minimize(T1 &a, T2 b) {	
    return a > b ? a = b, 1 : 0;
}


void solve(){
    int n; cin >> n;
    string s; cin >> s;
    s = " " + s;
    int a[n + 1];
    if (s[n] == '(') a[n] = n;
    else a[n] = -1;
    for (int i = n - 1; i >= 1; i--){
        a[i] = a[i + 1];
        if (s[i] == '(') a[i] = i;
    }
    int b[n + 1];
    if (s[n] == ')') b[n] = 1;
    else b[n] = 0;
    for (int i = n - 1; i >= 1; i--){
        b[i] = b[i + 1];
        if (s[i] == ')') b[i] += 1;
    }
    ll ans = -1;
    stack <char> st;
    for (int i = 1; i <= n - 1; i++){
        if (s[i] == '(') st.push(s[i]);
        else{
            ll j = a[i];
            if (j != -1){
                ll closed = b[j];
                ll m = st.size();
                if (closed >= m + 1){
                    maximize(ans, i + (closed - m - 1)*2 + (m + 1));
                }
            }

            st.pop();
        }
    }
    cout << ans << '\n';

}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);

    if (fopen("input.inp", "r")) {
        freopen("input.inp", "r", stdin);
        freopen("output.out", "w", stdout);
    }

    int t; cin >> t;
    while (t--) {
        solve();
    }
}