#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        string s;
        cin>>s;
        int ma=0;
        int ans;
        for(int i=0;i<n;i++)
        {
            if(s[i]==')')
            {
                int cnt=0;
                while(i<n&&s[i]==')')
                {
                    cnt++;
                    i++;
                }
                int num=0;
                while(i<n&&s[i]=='(')
                {
                    num++;
                    i++;
                }
                if(num>=cnt)
                {
                    ans=n-2*cnt;
                    ma=max(ma,ans);
                }
                i--;
            }
        }
        if(ma==0)
        {
            ma=-1;
        }
        cout<<ma<<"\n";
    }
    return 0;
}