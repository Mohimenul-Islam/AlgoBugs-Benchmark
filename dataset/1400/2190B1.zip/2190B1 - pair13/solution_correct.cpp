#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        string s;
        cin>>s;
        vector<int>nxt(n+10,n+10),cnt(n+10);
        for(int i=n-1;i>=0;i--)
        {
            cnt[i]=cnt[i+1];
            if(s[i]=='(')
            {
                cnt[i]++;
            }
        }
        for(int i=n-1;i>=0;i--)
        {
            if(s[i]=='(')
            {
                nxt[i]=i;
            }
            else
            {
                nxt[i]=nxt[i+1];
            }
        }
        int ma=-1;
        for(int i=0;i<n;i++)
        {
            if(s[i]==')'&&nxt[i]<n)
            {
                int w=nxt[i]-i;
                int q=cnt[nxt[i]];
                if(q>w)
                {
                    ma=max(ma,n-w*2);
                }
            }
        }
        cout<<ma<<"\n";
    }
    return 0;
}