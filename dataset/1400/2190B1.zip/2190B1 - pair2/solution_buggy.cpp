#include <bits/stdc++.h>
using namespace std;
#define ll long long int
#define vll vector<ll>
#define vpll vector<pair<ll, ll>>
#define vvll vector<vector<ll>>
#define pll pair<ll, ll>
#define mpll map<ll, ll>
#define ld long double
#define float double
#define f(i, x, n) for (ll i = x; i < n; i++)
#define rf(i, x, n) for (ll i = x; i >= n; i--)
#define pb push_back
#define all(a) (a).begin(), (a).end()
#define rall(a) (a).rbegin(), (a).rend()
#define sz(a) (ll) a.size()
#define pi (3.141592653589)
#define min3(a, b, c) min(a, min(b, c))
#define min4(a, b, c, d) min(a, min(b, min(c, d)))
#define max3(a, b, c) max(a, max(b, c))
#define max4(a, b, c, d) max(a, max(b, max(c, d)))
#define watch(x) cerr << (#x) << " is " << (x) << endl
#define fast                          \
    ios_base::sync_with_stdio(false); \
    cin.tie(NULL);                    \
    cout.tie(NULL)
ll countBinaryBits(ll n)
{
    if (n == 0)
        return 0;
    // Take absolute value to handle negatives
    ll x = (n < 0) ? -n : n;
    return 64 - __builtin_clzll(x);
}
string numToStr(ll num)
{
    return to_string(num);
}
string numToBinaryString(ll num)
{
    // O(1)
    if (num == 0)
    {
        return "0";
    }

    std::bitset<64> bs(num); // Use 64 bits for long long
    std::string str = bs.to_string();

    // Remove leading zeros
    auto pos = str.find('1');
    return str.substr(pos);
}
bool isPalindrome(const std::string &str)
{
    int left = 0;
    int right = str.length() - 1;

    while (left < right)
    {
        if (str[left] != str[right])
            return false;
        left++;
        right--;
    }

    return true;
}
bool isPrime(ll t)
{
    if (t <= 1)
        return false;
    ll limit = sqrt(t);
    for (ll i = 2; i <= limit; i++)
    {
        if (t % i == 0)
            return false;
    }
    return true;
}
ll fastprime(ll n)
{
    f(i, 2, (ll)sqrt(n)) if (n % i == 0) return 0;
    return 1;
}
ll countPrimes(ll n)
{
    vector<ll> isPrime(n + 1, 1);
    for (ll i = 2; i * i <= n; i++)
    {
        if (isPrime[i])
        {
            for (ll j = i * i; j <= n; j += i)
            {
                isPrime[j] = 0;
            }
        }
    }
    ll cnt = 0;
    for (ll i = 2; i <= n; i++)
    {
        if (isPrime[i])
        {
            cnt++;
        }
    }
    return cnt;
}
vector<ll> AllPrimeFactors(ll N)
{
    vector<ll> a;
    for (ll i = 2; i * i <= N; i++)
    {
        if (N % i == 0)
        {
            a.push_back(i);
            while (N % i == 0)
            {
                N = N / i;
            }
        }
    }
    if (N != 1)
        a.push_back(N);
    return a;
}
vector<ll> print_divisors_in_sorted_order(ll n)
{
    set<ll> st;
    vector<ll> ans;
    for (ll i = 1; i * i <= n; i++)
    {
        if (n % i == 0)
        {
            st.insert(i);
            if (n / i != i)
            {
                st.insert(n / i);
            }
        }
    }
    for (auto it : st)
    {
        ans.push_back(it);
    }
    return ans;
}
ll ceilDiv(ll num, ll denom)
{
    return (num + denom - 1) / denom;
}
ll myPow(ll x, ll n)
{
    ll num = n;
    num = abs(num);
    if (x == 0)
        return 0;
    ll ans = 1;
    while (num)
    {
        if (num & 1)
        {
            ans = ans * x;
            num--;
        }
        else
        {
            x = x * x;
            num = num >> 1;
        }
    }
    if (n < 0)
        return 1 / ans;
    return ans;
}
ll myPowMod(ll x, ll n, ll mod)
{
    ll num = n;
    num = abs(num);
    if (x == 0)
        return 0;
    ll ans = 1;
    while (num)
    {
        if (num & 1)
        {
            ans = (ans * x) % mod;
            num--;
        }
        else
        {
            x = (x * x) % mod;
            num >>= 1;
        }
    }
    if (n < 0)
    {
        // modular inverse needed
        // only valid if mod is prime AND gcd(x, mod) == 1
        return myPowMod(ans, mod - 2, mod);
    }
    return ans;
}
ll inverse(ll a, ll m)
{
    return myPowMod(a, m - 2, m);
}
vector<ll> factorialPreCompute(ll n, ll mod)
{
    vector<ll> fac(n + 1, 1);
    for (ll i = 2; i <= n; i++)
    {
        fac[i] = ((fac[i - 1] * i) % mod);
    }
    return fac;
}
ll nCkMod(ll n, ll k, ll mod, vector<ll> &fac)
{
    ll denom = (fac[n - k] * fac[k]) % mod;
    return (fac[n] * myPowMod(denom, mod - 2, mod)) % mod;
}
class modularArith
{
private:
    vector<ll> fac;
    ll n;
    ll mod;

public:
    modularArith(ll n, ll mod) : n(n), mod(mod)
    {
        fac.resize(n + 1, 1);
        for (ll i = 1; i <= n; i++)
        {
            fac[i] = (fac[i - 1] * i) % mod;
        }
    }
    ll nCkMod(ll n, ll k)
    {
        if (k > n)
            return 0;
        ll denom = (fac[k] * fac[n - k]) % mod;
        return (fac[n] * myPowMod(denom, mod - 2, mod)) % mod;
    }
    ll getFactorial(ll n, ll i)
    {
        if (i > n)
            return 0;
        return fac[i];
    }
};
class Graph
{
public:
    vector<vector<ll>> adj;
    ll V;
    Graph(ll n)
    {
        // TC->O(n)
        // SC->O(n)
        V = n;
        adj.resize(V);
    }
    Graph(ll n, vector<vector<ll>> &ad)
    {
        // Provided that adj is already an adjacency list
        V = n;
        adj = ad;
    }
    Graph(ll n, vector<pair<ll, ll>> edges, bool undirected)
    {
        // TC->O(Edges + Nodes) -> O(E + V)
        // SC->O(Node) -> O(V)
        V = n;
        adj.resize(V);
        for (auto &it : edges)
        {
            adj[it.first].push_back(it.second);
            if (undirected)
                adj[it.second].push_back(it.first);
        }
    }
    Graph(ll n, vector<vector<ll>> edges, bool undirected)
    {
        // TC -> O(Nodes + Edges) -> O(V + E)
        // SC -> O(Nodes) -> O(V)
        V = n;
        adj.resize(V);
        for (auto &it : edges)
        {
            adj[it[0]].push_back(it[1]);
            if (undirected)
                adj[it[1]].push_back(it[0]);
        }
    }
    vector<ll> bfsTraversal(bool zero)
    {
        // TC -> O(Nodes + 2 * Edges) -> O(V + 2*E)
        // SC -> O(3 * Nodes) -> O(3*V)
        vector<ll> visited(V + 1, 0);
        vector<ll> ans;
        for (ll i = (zero ? 0 : 1); i < (zero ? V : V + 1); i++)
        {
            if (!visited[i])
            {
                queue<ll> q;
                q.push(zero ? 0 : 1);
                visited[zero ? 0 : 1] = 1;
                while (!q.empty())
                {
                    ll cur = q.front();
                    q.pop();
                    // Any operation for bfs
                    ans.push_back(cur);
                    for (auto &it : adj[cur])
                    {
                        if (!visited[it])
                        {
                            visited[it] = 1;
                            q.push(it);
                        }
                    }
                }
            }
        }
        return ans;
    }
    void dfsUtil(ll node, vector<ll> &visited, vector<ll> &ans)
    {
        // TC -> O(Nodes + 2 * Edges) -> O(V + 2*E)
        // SC -> O(3 * Nodes) -> O(3*V)
        visited[node] = 1;
        // Any operation for dfs
        ans.push_back(node);
        for (auto it : adj[node])
        {
            if (!visited[it])
            {
                dfsUtil(it, visited, ans);
            }
        }
    }
    vector<ll> dfsTraversal(bool zero)
    {
        vector<ll> visited(V + 1, 0);
        vector<ll> ans;
        for (ll i = (zero ? 0 : 1); i < (zero ? V : V + 1); i++)
        {
            if (!visited[i])
            {
                dfsUtil(i, visited, ans);
            }
        }
        return ans;
    }
};
vector<ll> rabinKarpSingleHash(string &txt, string &pat, ll p, ll mod)
{
    ll n = txt.size();
    ll m = pat.size();
    if (n < m)
    {
        return {};
    }

    ll prePat = 0;
    for (ll i = 0; i < m; i++)
    {
        prePat = ((prePat * p) % mod + pat[i]) % mod;
    }

    ll p_m_1 = myPowMod(p, m - 1, mod);

    ll preTxt = 0;
    vector<ll> ans;
    for (ll i = 0; i < n; i++)
    {
        if (i < m)
        {
            preTxt = ((preTxt * p) % mod + txt[i]) % mod;
        }
        else
        {
            preTxt = ((preTxt - (txt[i - m] * p_m_1) % mod + mod) % mod * p % mod + txt[i]) % mod;
        }

        if (i >= m - 1 && preTxt == prePat)
        {
            bool same = true;
            for (ll j = i - m + 1; j <= i; j++)
            {
                if (txt[j] != pat[j - i + m - 1])
                {
                    same = false;
                    break;
                }
            }
            if (same)
            {
                ans.push_back(i - m + 1);
            }
        }
    }

    return ans;
}

vector<ll> rabinKarpDoubleHash(string &txt, string &pat, ll p1, ll mod1, ll p2, ll mod2)
{
    ll n = txt.size();
    ll m = pat.size();
    if (n < m)
    {
        return {};
    }

    ll prePat1 = 0, prePat2 = 0;
    for (ll i = 0; i < m; i++)
    {
        prePat1 = ((prePat1 * p1) % mod1 + pat[i]) % mod1;
        prePat2 = ((prePat2 * p2) % mod2 + pat[i]) % mod2;
    }

    ll p_m_1 = myPowMod(p1, m - 1, mod1);
    ll p_m_2 = myPowMod(p2, m - 1, mod2);

    ll preTxt1 = 0, preTxt2 = 0;
    vector<ll> ans;
    for (ll i = 0; i < n; i++)
    {
        if (i < m)
        {
            preTxt1 = ((preTxt1 * p1) % mod1 + txt[i]) % mod1;
            preTxt2 = ((preTxt2 * p2) % mod2 + txt[i]) % mod2;
        }
        else
        {
            preTxt1 = ((preTxt1 - (txt[i - m] * p_m_1) % mod1 + mod1) % mod1 * p1 % mod1 + txt[i]) % mod1;
            preTxt2 = ((preTxt2 - (txt[i - m] * p_m_2) % mod2 + mod2) % mod2 * p2 % mod2 + txt[i]) % mod2;
        }

        if (i >= m - 1 && preTxt1 == prePat1 && preTxt2 == prePat2)
        {
            bool same = true;
            for (ll j = i - m + 1; j <= i; j++)
            {
                if (txt[j] != pat[j - i + m - 1])
                {
                    same = false;
                    break;
                }
            }
            if (same)
            {
                ans.push_back(i - m + 1);
            }
        }
    }

    return ans;
}
void computeZArray(vector<ll> &z_arr,
                   const string &txt,
                   const string &pat)
{
    // Build concatenated string: pattern + '$' + text
    string s = pat + '$' + txt;
    ll n = s.size();

    // Allocate and zero‑initialize
    z_arr.assign(n, 0);

    ll l = 0, r = 0;
    for (ll i = 1; i < n; i++)
    {
        if (i <= r)
            z_arr[i] = min(r - i + 1, z_arr[i - l]);

        // Try to extend match at i
        while (i + z_arr[i] < n && s[z_arr[i]] == s[i + z_arr[i]])
            z_arr[i]++;

        // Update [l, r] if we've extended beyond r
        if (i + z_arr[i] - 1 > r)
        {
            l = i;
            r = i + z_arr[i] - 1;
        }
    }
}

vector<ll> zFunction(const string &txt,
                     const string &pat)
{
    // O(n + m)
    // O(n + m) + n(for ans array in computeZArr)

    ll n = txt.size();
    ll m = pat.size();

    // Compute Z array on pat + '$' + txt
    vector<ll> z_arr;
    computeZArray(z_arr, txt, pat);

    // Collect match positions
    vector<ll> ans;
    // Z-values for positions i = m+1 .. m+1 + n - 1
    for (ll i = m + 1; i < m + 1 + n; i++)
    {
        if (z_arr[i] == m)
            ans.push_back(i - (m + 1));
    }

    return ans;
}
class DisjointSet
{
    // TC ->  O(V)(for initializing using constructor)
    // SC -> O(V) (for storing rank and parent)
public:
    vector<ll> rank, parent, size;
    DisjointSet(ll n)
    {
        rank.resize(n + 1, 0);
        parent.resize(n + 1);
        size.resize(n + 1, 1);
        for (ll i = 0; i <= n; i++)
        {
            parent[i] = i;
        }
    }
    ll findUPar(ll node)
    {
        // TC -> O(4*alpha) ~= O(1)
        // SC -> O(1)
        if (node == parent[node])
            return node;
        return parent[node] = findUPar(parent[node]);
    }
    void unionByRank(ll u, ll v)
    {
        // TC -> O(4*alpha) ~= O(1)
        // SC -> O(1)
        ll ulp_u = findUPar(u);
        ll ulp_v = findUPar(v);
        if (ulp_u == ulp_v)
            return;
        if (rank[ulp_u] < rank[ulp_v])
        {
            parent[ulp_u] = ulp_v;
        }
        else if (rank[ulp_v] < rank[ulp_u])
        {
            parent[ulp_v] = ulp_u;
        }
        else
        {
            parent[ulp_v] = ulp_u;
            rank[ulp_u]++;
        }
    }
    void unionBySize(ll u, ll v)
    {
        // TC -> O(4*alpha) ~= O(1)
        // SC -> O(1)
        ll ulp_u = findUPar(u);
        ll ulp_v = findUPar(v);
        if (ulp_u == ulp_v)
            return;
        if (rank[ulp_u] <= rank[ulp_v])
        {
            parent[ulp_u] = ulp_v;
            size[ulp_v] += size[ulp_u];
        }
        else
        {
            parent[ulp_v] = ulp_u;
            size[ulp_u] += size[ulp_v];
        }
    }
    ll numOfConnectedComponentsZeroIndex()
    {
        // TC -> O(n)
        // SC -> O(1)
        ll n = parent.size();
        ll cnt = 0;
        for (ll i = 0; i < n - 1; i++)
        {
            if (parent[i] == i)
                cnt++;
        }
        return cnt;
    }
    ll numOfConnectedComponentsOneIndex()
    {
        // TC -> O(n)
        // SC -> O(1)
        ll n = parent.size();
        ll cnt = 0;
        for (ll i = 1; i < n; i++)
        {
            if (parent[i] == i)
                cnt++;
        }
        return cnt;
    }
};
ll ceilLog2(long long x)
{
    if (x <= 1)
        return 0;                       // log2(1) = 0
    return 64 - __builtin_clzll(x - 1); // 64 for long long
}

ll calcOnes(ll num)
{
    // Only works for non-negative numbers
    return __builtin_popcountll(num);
}
vector<bool> seive(ll n)
{
    // returns a bool vector determining whether a number is a prime number.
    vector<bool> isPrime(n + 1, 1);
    for (ll i = 2; i * i <= n; i++)
    {
        if (isPrime[i])
        {
            for (ll j = i * i; j <= n; j += i)
            {
                isPrime[j] = 0;
            }
        }
    }
    if (n >= 1)
        isPrime[1] = 0;
    return isPrime;
}
class SegmentTree
{
    // SC -> O(5 * n)
private:
    // input vector over which range queries are performed
    vector<ll> arr;
    // size of the vector
    ll n;
    // segment tree container
    vector<ll> seg;
    // operation (like max, min, gcd, sum, etc.)
    function<ll(ll, ll)> op;
    // identity element (neutral value for out-of-range queries)
    ll identity;

public:
    // custom constructor: user provides array, operation, and identity element
    SegmentTree(ll n, std::vector<ll> &arr,
                std::function<ll(ll, ll)> op,
                ll identity)
    {
        // TC -> O(4 * n)
        // SC -> O(log n)
        this->n = n;
        // deep copy of input array
        this->arr = arr;
        // copy user-defined operation
        this->op = op;
        // set identity element
        this->identity = identity;
        // allocate space for segment tree
        this->seg.resize(4 * n);
        // build the segment tree
        build(0, n - 1, 0);
    }

    // build the segment tree recursively
    ll build(ll low, ll high, ll index)
    {
        // TC -> O(4 * n)
        // SC -> O(log n)
        // base case: leaf node
        if (low == high)
        {
            return seg[index] = arr[low];
        }

        // recursive case: internal node
        ll mid = low + (high - low) / 2;
        ll left = build(low, mid, 2 * index + 1);
        ll right = build(mid + 1, high, 2 * index + 2);

        // apply operation on children
        return seg[index] = op(left, right);
    }

    // query the segment tree for range [l, r]
    ll query(ll l, ll r)
    {
        // TC -> O(log n)
        // SC -> O(log n)
        return queryHelper(l, r, 0, n - 1, 0);
    }

    void update(ll i, ll val)
    {
        // TC -> O(log n)
        // SC -> O(log n)
        updateHelper(i, val, 0, 0, n - 1);
        arr[i] = val;
        return;
    }

private:
    // recursive helper function for queries
    ll queryHelper(ll l, ll r, ll low, ll high, ll index)
    {
        // TC -> O(log n)
        // SC -> O(log n)
        // completely outside the range
        if (high < l || low > r)
            return identity;

        // completely inside the range
        if (low >= l && high <= r)
            return seg[index];

        // partial overlap: query both sides
        ll mid = low + (high - low) / 2;
        ll left = queryHelper(l, r, low, mid, 2 * index + 1);
        ll right = queryHelper(l, r, mid + 1, high, 2 * index + 2);

        return op(left, right);
    }

    void updateHelper(ll i, ll val, ll index, ll low, ll high)
    {
        // TC -> O(log n)
        // SC -> O(log n)
        if (low == high)
        {
            seg[index] = val;
            return;
        }

        ll mid = low + (high - low) / 2;
        if (i <= mid)
        {
            // move left
            updateHelper(i, val, 2 * index + 1, low, mid);
        }
        else
        {
            // move right
            updateHelper(i, val, 2 * index + 2, mid + 1, high);
        }

        seg[index] = op(seg[2 * index + 1], seg[2 * index + 2]);
        return;
    }
};
class SparseGCDTable
{
private:
    vector<vector<ll>> sp;
    void build(vector<ll> &nums)
    {
        ll n = nums.size();
        ll K = sp[0].size(); // log2(n) + 1

        // Initialize first column (length 1)
        for (ll i = 0; i < n; i++)
        {
            sp[i][0] = nums[i];
        }

        // Build the rest of the table
        for (ll j = 1; j < K; j++)
        {
            for (ll i = 0; i + (1 << j) <= n; i++)
            { // only valid ranges
                sp[i][j] = __gcd(sp[i][j - 1], sp[i + (1 << (j - 1))][j - 1]);
            }
        }
    }

public:
    SparseGCDTable(vector<ll> &v)
    {
        ll n = v.size();
        if (n == 0)
        {
            throw std::invalid_argument("Empty array not allowed");
        }

        sp.resize(n, vector<ll>((ll)(log2(n)) + 1));
        build(v);
    }

    ll query(ll l, ll r)
    {
        if (l < 0 || r >= sp.size() || l > r)
        {
            throw std::out_of_range("Invalid query range");
        }

        ll k = (ll)log2(r - l + 1);
        return __gcd(sp[l][k], sp[r - (1 << k) + 1][k]);
    }
};
void solve()
{
    ll n;
    cin >> n;
    string str;
    cin >> str;
    vector<ll> close(n, 0);
    for (ll i = n - 2; i >= 0; i--)
    {
        close[i] = close[i + 1] + (str[i + 1] == ')');
    }
    ll len = 0;
    ll req = 0;
    bool first = false;
    ll i = 0;
    for (; i < n; i++)
    {
        if (str[i] == '(')
            len++, req++;
        else if (str[i] == ')')
        {
            size_t pos = str.find('(', i + 1);
            if (pos == string::npos)
            {
                cout << -1 << "\n";
                return;
            }
            ll idx = (ll)pos;
            req++;
            len++;
            i = idx + 1;
            break;
        }
    }
    for (; i < n; i++)
    {
        if (str[i] == '(' && close[i] >= req + 1)
        {
            req++;
            len++;
        }
        else if (str[i] == ')')
        {
            len++;
            req--;
        }
    }
    if (req == 0)
        cout << len << "\n";
    else
        cout << -1 << "\n";
}
int main()
{
    fast;
    ll t;
    cin >> t;
    while (t--)
        solve();
    return 0;
}