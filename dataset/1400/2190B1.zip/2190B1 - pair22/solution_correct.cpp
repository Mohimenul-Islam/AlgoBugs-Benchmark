#include <bits/stdc++.h>
using namespace std;
#define FOR(i,a,b) for (int i = a; i < (b); i++)
#define F0R(i,a) for (int i = 0; i < (a); i++)
#define FORd(i,a,b) for (int i = (b)-1; i >= a; i--)
#define F0Rd(i,a) for (int i = (a)-1; i >= 0; i--)

void solve(void) {
	int n;
	cin >> n;
	string s;
	cin >> s;
	int openingCount = 0;
	int closingCount = 0;
	for (int i = n-1; i >= 0; i--) {
		if (s[i] == ')') {
			closingCount++;
		} else if (s[i] == '(') {
			openingCount++;
		}
		if (s[i] == ')' && openingCount >= 2) {
			cout << n-2 << '\n';
			return;
		}
	}
	cout << "-1\n";
}

int main(void) {
	int t;
	cin >> t;
	while (t--) {
		solve();
	}
}
