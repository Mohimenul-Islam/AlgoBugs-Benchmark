#include <bits/stdc++.h>
using namespace std;
#define FOR(i,a,b) for (int i = a; i < (b); i++)
#define F0R(i,a) for (int i = 0; i < (a); i++)
#define FORd(i,a,b) for (int i = (b)-1; i >= a; i--)
#define F0Rd(i,a) for (int i = (a)-1; i >= 0; i--)

void solve(void) {
	int n;
	cin >> n;
	string s;
	cin >> s;
	int i;
	for (i = n-1; i >= 0; i--) {
		if (s[i] == '(') {
			break;
		}
	}
	int j;
	for (j = i; j >= 0; j--) {
		if (s[j] == ')') {
			break;
		}
	}
	// j initial brackets
	// i-j extra opening brackets that can be used
	// n-i-1 closing brackets that can be used
	// need n-i closing brackets to use all i-j of them
	// so we use i-j-1 of them
	if (i-j-1 > 0) {
		cout << j+i-j-1+n-i-1 << '\n';
	} else {
		cout << -1 << '\n';
	}
}

int main(void) {
	int t;
	cin >> t;
	while (t--) {
		solve();
	}
}
