// #include<bits/stdc++.h>
// // #define int long long
// using namespace std;
// using ll = long long;

// int _ = 1;

// void solve() {
//     int n;
//     cin >> n;
//     string a;
//     cin >> a;
//     int ans = 1e9;
//     int numx = 0, num = 0;
//     bool flag = false;
//     for(int i = 0; i < n; i++) {
//         if(flag == false && a[i] == '(') {
//             flag = true;
//             numx = 1;
//             num = 1;
//         }
        
//         else if(flag == true) {
//             if(a[i] == '(') {
//                 numx++;
//                 num = numx;
//             }
//             else if(a[i] == ')') {
//                 flag = false;
//                 numx--;
//             }
//         }
//         else if(flag == false && a[i] == ')' && numx > -1) {
//             numx--;
//             if(numx == -1) ans = min(ans, num);
//         }
//     }
//     if(ans != 1e9) cout << n - ans << '\n';
//     else cout << -1 << '\n';
//     return;

// }

// signed main(){
//     ios::sync_with_stdio(false);
//     cin.tie(0),cout.tie(0);

//     cin >> _;

//     while(_--) solve();
//     return 0;
// }


#include<bits/stdc++.h>
// #define int long long
using namespace std;
using ll = long long;

int _ = 1;

void solve() {
    int n;
    cin >> n;
    string a;
    cin >> a;
    bool flag = false;
    int num = 0;
    for(int i = 0; i < n; i++) {
        if(a[i] == ')') {
            flag = true;
            num = 0;
        }
        else if(flag == true && a[i] == '(') {
            num++;
            if(num == 2) {
                cout << n - 2 << '\n';
                return;
            }
        }
    }
    cout << -1 << '\n';
    return;

}

signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);

    cin >> _;

    while(_--) solve();
    return 0;
}