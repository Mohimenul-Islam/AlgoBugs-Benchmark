#include<bits/stdc++.h>
using namespace std;
#define ll long long
const ll N=2e3+100;
ll mod = 998244353;
ll fac[N],b[N];
// ll qpow(ll x,ll b) {
//     ll res = 1;
//     while (b) {
//         if (b & 1) {
//             res = res * x %mod;
//         }
//         x = x * x %mod;
//         b >>= 1;
//     }
//     return res ;
// }
// void init(ll n1) {
//     fac[0] = 1;
//     for (int i=1;i<=n1;i++) {
//         fac[i] = i * fac[i-1] % mod;
//     }
// }
// ll inv(ll n1) {
//     return qpow(n1,mod-2)%mod;
// }
// ll getc(ll nn,ll kk) {
//     return ((fac[nn] * inv(fac[kk]))%mod * inv(fac[nn-kk])) %mod;
// }
ll p[N],sz[N],dist[N],col[N],val[N];
int find(int x) {
    if (p[x] != x) {
        int f = p[x];
        p[x] = find(p[x]);
        col[x] ^= col[f];
    }
    return p[x];
}
void solve() {
    int n;cin>>n;
    string s;cin>>s;
    s = " " +s ;
    vector<int>a(n+10,0);
    for (int i=n;i>=1;i--) {
        a[i] = a[i+1] + (s[i] == '(');
    }
    for (int i=1;i<=n;i++) {
        if (s[i] == '(') {
            
        } else {
            if (a[i] >= 2) {
                cout<<n-2<<'\n';
                return ;
            }
        }
    }
    cout<<"-1"<<'\n';
}
int main() {
    ios::sync_with_stdio(0),cin.tie(0); cout.tie(0);
    int t;cin>>t;
    while(t--) solve();
    return 0;
}