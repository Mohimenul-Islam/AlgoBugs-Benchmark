#include <bits/stdc++.h>

#pragma GCC optimize("O3")
#pragma GCC target("avx2")

using namespace std;
typedef long long ll;

void solve() {
  int n; cin >> n;
  string s; cin >> s;

  vector<char> used(n, 0);
  queue<int> q;
  stack<int> st;

  int j = s.find(')');
  for(int i = 0; i < j; ++i)
    q.push(i);
  
  size_t k = s.find('(', j);
  if(k == string::npos) {
    cout << "-1\n";
    return;
  }
  
  q.push((int) k);

  for(int i = (int) k + 1; i < n; ++i) {
    if(s[i] == '(') {
      st.push(i);
    } else if(!q.empty()) {
      used[q.front()] = true;
      used[i] = true;
      q.pop();
    } else if(!st.empty()) {
      used[st.top()] = true;
      used[i] = true;
      st.pop();
    }
  }

  string res;
  for(int i = 0; i < n; ++i) {
    if(used[i]) {
      res.push_back(s[i]);
    }
  }

  bool ok = false;
  for(int i = 0; i < (int) res.size(); ++i) {
    if(s[i] == ')' && res[i] == '(') {
      ok = true;
      break;
    }

    if(s[i] == '(' && res[i] == ')')
      break;
  }

  cout << (ok ? (int) res.size() : -1) << '\n';
}

int main() {
  ios::sync_with_stdio(false);
  cin.tie(nullptr); cout.tie(nullptr);

  int t; cin >> t;
  while(--t >= 0)
    solve();
  
  return 0;
}