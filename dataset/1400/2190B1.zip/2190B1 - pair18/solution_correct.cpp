#include <bits/stdc++.h>

#pragma GCC optimize("O3")
#pragma GCC target("avx2")

using namespace std;
typedef long long ll;

void solve() {
  int n; cin >> n;
  string s; cin >> s;
  vector<int> cnt(n + 1, 0);
  int ans = -1;
  for(int i = n - 1, j = n; i >= 0; --i) {
    cnt[i] = cnt[i + 1];
    if(s[i] == ')') {
      if(cnt[j] > j - i)
      ans = max(ans, n - 2 * (j - i));
    } else {
      ++cnt[i];
      j = i;
    }
  }
  cout << ans << '\n';
}

int main() {
  ios::sync_with_stdio(false);
  cin.tie(nullptr); cout.tie(nullptr);

  int t; cin >> t;
  while(--t >= 0)
    solve();
  
  return 0;
}