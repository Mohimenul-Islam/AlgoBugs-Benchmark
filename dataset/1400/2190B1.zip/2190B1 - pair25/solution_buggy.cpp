#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef double dl;
#define endl '\n'

#define _GORIBER_TURBO_MODE_ON()  \
    ios_base::sync_with_stdio(0); \
    cin.tie(0);                   \
    cout.tie(0);

#define fraction()                \
    cout.unsetf(ios::floatfield); \
    cout.precision(10);           \
    cout.setf(ios::fixed, ios::floatfield)

void _DIBBA()
{
  int  n;
  cin>> n;
  string  s;
  cin  >> s;
  
  if(n <= 4){
    cout << -1 << endl;
    return;
  }
  
  vector<int> v;
  v.reserve(n);
  
  int len = 1;
  for(int i = 1;i < n;i++){
    if(s[i-1] == s[i]){
      len++;
      continue;
    }
    
    v.push_back(len);
    len = 1;
  }
  
  v.push_back(len);
  
  int rm = -1;
  
  for(int i = 2;i < v.size();i+=2){

    if(v[i-1] > v[i])continue;
    
    if(rm == -1) rm = v[i-1];
    
    rm = min(v[i-1],rm);
  }
  
  if(rm ==  -1){
    cout<< -1 << endl;
    return;
  }
  
  cout<<  (n - (rm*2)) << endl;
}

int32_t main()
{
    _GORIBER_TURBO_MODE_ON();

    int t = 1;
    cin >> t;
    while (t--)
        _DIBBA();
    return 0;
}





















