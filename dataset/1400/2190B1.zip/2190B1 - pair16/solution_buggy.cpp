#include <bits/stdc++.h>
using namespace std;
#define ll long long

void solve(){
    ll n;
    cin >> n;
    string s;
    cin >> s;
    ll i = 0;
    ll cnt = 0;
    while(i < n){
        if(s[i] == ')'){
            while(i < n && s[i] == ')'){
                cnt++;
                i++;
            }
            i++;
            break;
        }
        else    i++;
    }
    ll open = 0;
    while(i < n){
        open += (s[i++] == '(');
    }
    if(open < cnt){
        cout << -1 << endl;
        return;
    }
    cout << n - 2 * cnt << endl;
}

int main()
{
    ll t = 1;
    cin >> t;
    while(t--){
        solve();
    }
}