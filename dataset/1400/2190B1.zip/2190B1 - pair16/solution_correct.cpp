#include <bits/stdc++.h>
using namespace std;
#define ll long long

void solve(){
    ll n;
    cin >> n;
    string s;
    cin >> s;
    ll i = 0;
    ll cnt = 0;
    while(i < n){
        if(s[i] == ')'){
            while(i < n && s[i] == ')'){
                i++;
            }
            i++;
            break;
        }
        else    i++;
    }
    ll flag = 0;
    while(i < n){
        if(s[i++] == '('){
            flag = 1;
            break;
        }
    }
    if(!flag){
        cout << -1 << endl;
        return;
    }
    cout << n - 2 << endl;
}

int main()
{
    ll t = 1;
    cin >> t;
    while(t--){
        solve();
    }
}