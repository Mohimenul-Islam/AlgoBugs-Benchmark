#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int tc;
	cin >> tc;
	while (tc--) {
		int n;
		cin >> n;
		string s;
		cin >> s;
		int count=0, tr=0;
		for (int i=n-1; i>0; i--) {
			if (s[i]=='(') count++;
			else if (count>1) {
				tr=1;
				break;
			}
		}
		if (tr) cout << n-2 << '\n';
		else cout << "-1\n";
	}
    
    return 0;
}
