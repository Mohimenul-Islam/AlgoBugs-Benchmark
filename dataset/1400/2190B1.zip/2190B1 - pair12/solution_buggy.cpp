#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int tc;
	cin >> tc;
	while (tc--) {
		int n;
		cin >> n;
		string s;
		cin >> s;
		int ans=0, det=0, tr=1;
		for (int i=0; i<n/2; i++) {
			if (s[i]=='(') {
				if (tr) det++;
				ans++;
			}
			else tr=0;
		}
		if (ans>det) cout << ans*2 << '\n';
		else cout << "-1\n";
	}
    
    return 0;
}
