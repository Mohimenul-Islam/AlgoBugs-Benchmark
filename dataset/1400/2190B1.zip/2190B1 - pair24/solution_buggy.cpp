#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define mod 1000000007
#define vi vector<int>
#define vl vector<long long>
#define vc vector<char>
#define for0(i,n)  for(int i=0;i<n;i++)
#define for1(i,n)  for(int i=1;i<=n;i++)

void forinpi(int st, int n, vi &arr) {
    for (int i = st; i < n; i++) {
        cin >> arr[i];
    }
}

void forinpl(int st, int n, vl &arr) {
    for (int i = st; i < n; i++) {
        cin >> arr[i];
    }
}

void forouti(int st, int n, vi &arr) {
    for (int i = st; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

void foroutl(int st, int n, vl &arr) {
    for (int i = st; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

float log_a_to_base_b(ll a, ll b){
    return (float) log2(a)/log2(b);
}

ll gcd(ll a,ll b){if(b == 0)return a;return gcd(b, a % b);}

ll lcm(ll a, ll b){return (a/gcd(a,b)*b);}

ll forinpisum(int start,int end,vector<int>& a){
   ll sum=0;
   for(int i=start;i<end;i++){
       cin>>a[i];
       sum+=a[i];
       }
   return sum;
}

vector<bool> comp(1e5+1);
vector<int> primes;

void sieve(){
    for(int i=2; i*i<=1e5; i++)
        if(!comp[i])
            for(int j=i*i; j<=1e5; j+=i)
                comp[j] = true;
    for(int i=2; i<=1e5; i++)
        if(!comp[i])
            primes.push_back(i);
}

void solve() {
    ll n;
    cin>>n;
    string s;
    cin>>s;
    vl suffc(n+1,0);
    vl suffo(n+1,0);
    
    for(ll i=n-1;i>=0;i--){
        if(s[i]==')') suffc[i]=suffc[i+1]+1;
        else suffc[i]=suffc[i+1];
    }
    for(ll i=n-1;i>=0;i--){
        if(s[i]=='(') suffo[i]=suffo[i+1]+1;
        else suffo[i]=suffo[i+1];
    }
    
    string a="";
    ll i=0;
    while(i<n && s[i]=='('){
        a+="(";
        i++;
    }
    while(i<n && s[i]==')'){
        i++;
    }
    
    ll ans=-1;
    
    for(ll j=i;j<n;j++){
        if(suffc[j]-(ll)a.length()>=suffo[j]){
            ans=max(ans,(ll)a.length()*2LL+suffo[j]);
        }else if(suffc[j]<(ll)a.length()){
            break;
        }else{
            ll rem=suffc[j]-(ll)a.length();
            ll mini=min(rem,suffo[j]);
            ans=max(ans,(ll)a.length()*2LL+mini*2LL);
        }
    }
    cout<<ans<<endl;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    ll test;
    cin >> test;
    while (test--) {
        solve();
    }
    return 0;
}