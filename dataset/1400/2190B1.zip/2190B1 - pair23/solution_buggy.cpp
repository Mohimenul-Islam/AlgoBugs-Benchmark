#include<bits/stdc++.h>
using namespace std;
using ll=long long;
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    ll t;
    cin>>t;
    while(t--){
    	ll n;
    	cin>>n;
    	string s;
    	cin>>s;
    	int sum=0;
    	bool ok=true;
    	for(int i=0;i<n;i++){
    		if(s[i]=='(') sum++;
    		else sum--;
		if(sum==0&&i!=n-1){
			ok=false;
		}
	}
		if(!ok||n==2){
			cout<<"-1\n";
		}
		else{
			cout<<n-2<<'\n';
		}
	}
    return 0;
}