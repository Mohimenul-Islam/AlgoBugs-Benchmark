#include<bits/stdc++.h>
using namespace std;
using ll=long long;
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    ll t;
    cin>>t;
    while(t--){
    	ll n;
    	cin>>n;
    	string s;
    	cin>>s;
    	vector<ll> a(n+1,n+1);
    	vector<ll> sum(n+1,0);
    	for(int i=n-1;i>=0;i--){
    		if(s[i]=='(') a[i]=i;
    		else{
    			a[i]=a[i+1];
			}
			if(s[i]=='(') sum[i]++;
			sum[i]+=sum[i+1];
		}
		ll ans=-1;
		for(int i=0;i<n;i++){
			if(s[i]==')'&&a[i]<=n){
				ll b=a[i]-i;
				if(sum[a[i]+1]>=b){
					ans=max(ans,n-2*b);
				}
			}
		}
		cout<<ans<<'\n';
	}
    return 0;
}