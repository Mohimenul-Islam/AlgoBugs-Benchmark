#include <bits/stdc++.h>


using namespace std;

void setup_io() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
}


using u64 = uint64_t;
using u128 = __uint128_t;


u64 power_mod(u64 base, u64 exp, u64 mod) {
    u64 res = 1;
    base %= mod;
    while (exp > 0) {
        if (exp % 2 == 1) res = (u128)res * base % mod;
        base = (u128)base * base % mod;
        exp /= 2;
    }
    return res;
}


bool isPrime(u64 n) {
    if (n < 2) return false;
    
    if (n == 2 || n == 3) return true;
    if (n % 2 == 0 || n % 3 == 0) return false;

    
    int witnesses[] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37};
    
    
    u64 d = n - 1;
    int s = 0;
    while ((d & 1) == 0) {
        d >>= 1;
        s++;
    }

    for (int a : witnesses) {
        if (a >= n) break;
        
        u64 x = power_mod(a, d, n);
        if (x == 1 || x == n - 1) continue;

        bool is_composite = true;
        for (int r = 1; r < s; ++r) {
            x = (u128)x * x % n;
            if (x == n - 1) {
                is_composite = false;
                break;
            }
        }
        if (is_composite) return false;
    }
    return true;
}

bool isPrimeT(long long N) {
    if (N <= 1) return false;           
    if (N % 2 == 0 || N % 3 == 0) return false;


    for (long long i = 5; i * i <= N; i += 6) {
        if (N % i == 0 || N % (i + 2) == 0)
            return false;
    }
    return true;
}

vector<long long> distinct_prime_factors(long long n) {
    vector<long long> factors;

    
    if (n % 2 == 0) {
        factors.push_back(2);
        while (n % 2 == 0) n /= 2;
    }

    
    for (long long i = 3; i * i <= n; i += 2) {
        if (n % i == 0) {
            factors.push_back(i);
            while (n % i == 0) n /= i;
        }
    }

    
    if (n > 2)
        factors.push_back(n);

    return factors;
}





vector<long long> pf;
void p_f(long long a) {
    for (long long i = 2; i*i <= a; i++) {
        if (a % i == 0) {
            pf.push_back(i);
        }
    }
}








void solve() {

    long long n;
    cin >> n;

    string s;
    cin >> s;

    s = "0" + s;

    bool poss = false;
    long long mx_sub = 0;

    for (long long i = 1; i <= n; i++) {

        if (s[i] == ')') {
            if ((i*2) < n) {
                poss = true;
                mx_sub = max(mx_sub, (i*2));
            }
        }
    }

    if (poss) {
        cout << mx_sub << endl;
    } else {
        cout << "-1" << endl;
    }


}



    




    

    
    

    

    


 

int main() {
    setup_io();
    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}