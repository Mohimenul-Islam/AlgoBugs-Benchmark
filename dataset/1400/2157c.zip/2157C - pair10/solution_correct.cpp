#include <bits/stdc++.h>

#define fi first
#define se second
#define pb push_back
#define sz(x) (ll)x.size()
#define all(x) x.begin(), x.end()

using ll = long long;
using ld = long double;

using namespace std;

const ll N = 5e5 + 52;
const ll INF = 1e18;

void solve(){
    ll n, m, k;
    ll i, j;
    string s;
    cin >> n >> k >> m;
    vector<ll> used(n+2,0);
    vector<pair<ll,ll>> p;
    vector<ll> a(n+2,1e9);
    while(m--){
        ll c;
        cin >> c;
        ll l, r;
        cin >> l >> r;
        if (c==1){
            for (i=l;i<=r;i++) used[i] = 1;
        }else{
            p.pb({l,r});
        }
    }
    for (auto [l,r] : p){
        for (i=l;i<=r;i++){
            if (used[i]){
                used[i] = 2;
            }
        }
    }
    sort(all(p));
    for (auto [l,r] : p){
        set<ll> b;
        for (i=0;i<=k+1;i++) b.insert(i);
        for (i=l;i<=r;i++){
            if (!used[i]){
                b.erase(a[i]);
            }
        }
        for (i=l;i<=r;i++){
            if (*b.begin()==k) break;
            if (!used[i] && a[i]==1e9){
                a[i] = *b.begin();
                b.erase(b.begin());
            }
        }
    }
    for (i=1;i<=n;i++){
        if (used[i]==1) a[i] = k;
        cout << a[i] << " ";
    }
    cout << endl;
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
#ifdef  LOCAL
    freopen("/Applications/system/system/input.txt", "r", stdin);
    freopen("/Applications/system/system/output.txt", "w", stdout);
#endif  LOCAL
    ll t = 1;
    cin >> t;
    while(t--) solve();
    return 0;
}
