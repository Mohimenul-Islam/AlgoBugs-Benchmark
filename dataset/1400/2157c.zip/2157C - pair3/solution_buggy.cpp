#include <bits/stdc++.h>
#define ll long long
#define Will_of_D ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);
#define yes cout << "YES" << '\n';
#define no cout << "NO" << '\n';
#define all(v) v.begin(),v.end()
#define F first
#define S second
#define nl '\n'
#define gap ' '
using namespace std;


void solve(int test){
    int n , k , q;

    cin >> n >> k >> q;

    vector<pair<int , int>> v[3];
    for(int i = 1; i <= q; i++){
        int c , l , r;
        cin >> c >> l >> r;
        v[c].push_back({l , r});
    }

    int a[n + 5];

    for(int i = 1; i <= n; i++)a[i] = k;

    for(auto x : v[2]){
        for(int i = x.F; i <= x.S; i++){
            a[i] = 0;
        }
    }

    for(auto x : v[1]){
        for(int i = x.F; i <= x.S; i++){
            if(a[i] == k)continue;
            else a[i] = 1000;
        }
    }

    for(auto x : v[2]){
        int vis[k + 1];
        for(int i = 0; i < k; i++)vis[i] = 0;
        for(int i = x.F; i <= x.S; i++){
            if(a[i] == 1000)continue;

            vis[a[i]] = 1;
        }

        int lo = 0;
        while(lo < k and vis[lo] == 1){
            lo++;
        }

        for(int i = x.F; i <= x.S; i++){
            if(a[i] == 1000)continue;

            if(lo == k)break;

            if(vis[a[i]] == 1){
                vis[a[i]] = 0;
            }else {
                a[i] = lo;
                lo++;
            }
        }
    }

    for(int i = 1; i <= n; i++)cout << a[i] << gap;
    cout << nl;
}

int main()
{
    Will_of_D
    int test = 1;
    cin >> test;
    for(int i = 1; i <= test; i++)
        solve(i);
}