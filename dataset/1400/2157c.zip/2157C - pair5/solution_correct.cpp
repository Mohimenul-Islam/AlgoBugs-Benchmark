// Ajax_niner --version
#include <bits/stdc++.h>
using namespace std;

// ------------------ Macros ------------------
#define f(i, n) for (int i = 0; i < n; i++)
#define vi vector<int>
#define vll vector<ll>
#define vvl vector<vector<ll>>
#define vp vector<pair<ll, ll>>
#define sortall(v) sort(v.begin(), v.end())
#define all(v) v.begin(), v.end()
#define pb push_back
#define ppb pop_back
#define mp make_pair
#define ff first
#define ss second
#define yes cout << "YES\n"
#define no cout << "NO\n"
#define iv(v, n)     \
    vector<ll> v(n); \
    f(i, n) cin >> v[i]

// ------------------ Typedefs ------------------
typedef long long ll;
typedef unsigned long long ull;
typedef long double lld;

// ------------------ Constants ------------------
const ll MOD = 1e9 + 7;
const ll inf = LLONG_MAX;

// ------------------ Debug ------------------
#ifndef Piyush
#define debug(x)       \
    cerr << #x << " "; \
    _print(x);         \
    cerr << endl;
#else
#define debug(x)
#endif

void _print(ll t) { cerr << t; }
void _print(int t) { cerr << t; }
void _print(string t) { cerr << t; }
void _print(char t) { cerr << t; }
void _print(lld t) { cerr << t; }
void _print(double t) { cerr << t; }
void _print(ull t) { cerr << t; }

template <class T, class V>
void _print(pair<T, V> p);
template <class T>
void _print(vector<T> v);
template <class T>
void _print(set<T> v);
template <class T>
void _print(multiset<T> v);
template <class T, class V>
void _print(map<T, V> v);

template <class T, class V>
void _print(pair<T, V> p)
{
    cerr << "{";
    _print(p.ff);
    cerr << ",";
    _print(p.ss);
    cerr << "}";
}

template <class T>
void _print(vector<T> v)
{
    cerr << "[ ";
    for (T i : v)
    {
        _print(i);
        cerr << " ";
    }
    cerr << "]";
}

template <class T>
void _print(set<T> v)
{
    cerr << "[ ";
    for (T i : v)
    {
        _print(i);
        cerr << " ";
    }
    cerr << "]";
}

template <class T>
void _print(multiset<T> v)
{
    cerr << "[ ";
    for (T i : v)
    {
        _print(i);
        cerr << " ";
    }
    cerr << "]";
}

template <class T, class V>
void _print(map<T, V> v)
{
    cerr << "[ ";
    for (auto i : v)
    {
        _print(i);
        cerr << " ";
    }
    cerr << "]";
}

// ------------------ Modular Helpers ------------------
ll add(ll a, ll b, ll m = MOD) { return ((a % m) + (b % m) + m) % m; }
ll sub(ll a, ll b, ll m = MOD) { return ((a % m) - (b % m) + m) % m; }
ll mul(ll a, ll b, ll m = MOD) { return ((a % m) * (b % m)) % m; }

ll modexp(ll a, ll e, ll m = MOD)
{
    a %= m;
    ll r = 1;
    while (e)
    {
        if (e & 1)
            r = mul(r, a, m);
        a = mul(a, a, m);
        e >>= 1;
    }
    return r;
}

ll inv(ll a, ll m = MOD) { return modexp(a, m - 2, m); }

// ------------------ GCD / LCM ------------------
ll gcd(ll a, ll b)
{
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

ll lcm(ll a, ll b)
{
    return a / gcd(a, b) * b;
}

// ------------------ Binary Search Helpers ------------------
int lb(const vector<ll> &v, ll x)
{
    return lower_bound(all(v), x) - v.begin();
}

int ub(const vector<ll> &v, ll x)
{
    return upper_bound(all(v), x) - v.begin();
}

// ------------------ Prefix Sum ------------------
vector<ll> prefix_sum(const vector<ll> &v)
{
    int n = v.size();
    vector<ll> pref(n, 0);
    pref[0] = v[0];
    for (int i = 1; i < n; i++)
        pref[i] = pref[i - 1] + v[i];
    return pref;
}

vector<ll> prefix_sumR(const vector<ll> &v)
{
    int n = v.size();
    vector<ll> pref(n, 0);
    pref[n - 1] = v[n - 1];
    for (int i = n - 2; i >= 0; i--)
        pref[i] = pref[i + 1] + v[i];
    return pref;
}

// ------------------ Sieve ------------------
const int MAXN = 1e6 + 5;
vector<bool> isprime(MAXN, true);
vector<int> primes;

void sieve()
{
    isprime[0] = isprime[1] = false;
    for (int i = 2; i < MAXN; i++)
    {
        if (isprime[i])
        {
            primes.pb(i);
            if ((ll)i * i < MAXN)
                for (ll j = (ll)i * i; j < MAXN; j += i)
                    isprime[j] = false;
        }
    }
}

// ------------------ DSU ------------------
struct DSU
{
    vector<int> parent, size;

    DSU(int n)
    {
        parent.resize(n);
        size.assign(n, 1);
        iota(parent.begin(), parent.end(), 0);
    }

    int find(int x)
    {
        if (parent[x] == x)
            return x;
        return parent[x] = find(parent[x]);
    }

    void unite(int a, int b)
    {
        a = find(a);
        b = find(b);
        if (a != b)
        {
            if (size[a] < size[b])
                swap(a, b);
            parent[b] = a;
            size[a] += size[b];
        }
    }
};

// ------------------ Graph BFS / DFS ------------------
vector<vector<int>> adj;
vector<bool> vis;

void dfs(int u)
{
    vis[u] = true;
    for (int v : adj[u])
        if (!vis[v])
            dfs(v);
}

void bfs(int src)
{
    queue<int> q;
    q.push(src);
    vis[src] = true;
    while (!q.empty())
    {
        int u = q.front();
        q.pop();
        for (int v : adj[u])
        {
            if (!vis[v])
            {
                vis[v] = true;
                q.push(v);
            }
        }
    }
}

// ------------------ Array Print Function ------------------

template <class T>
void print_array(const vector<T> &a)
{
    for (int i = 0; i < (int)a.size(); i++)
    {
        cout << a[i];
        if (i + 1 < (int)a.size())
            cout << " ";
    }
    cout << "\n";
}

// ------------------ Solve ------------------

void solve()
{
    ll n, k, q;
    cin >> n >> k >> q;
    vector<ll> a(n + 1, 0);

    vector<ll> mn(n + 1, 0), mx(n + 1, 0);
    while (q--)
    {
        ll c, l, r;
        cin >> c >> l >> r;
        for (ll i = l; i <= r; i++)
        {
            if (c == 1)
                mn[i] = 1;
            else
                mx[i] = 1;
        }
    }

    for (ll i = 1; i <= n; i++)
    {
        if (mn[i] == 1 && mx[i] == 1)
            a[i] = k + 1;
        else if (mx[i] == 1)
            a[i] = i % k;
        else
            a[i] = k;
    }

    for (ll i = 1; i <= n; i++)
        cout << a[i] << ' ';
    cout << "\n";
}

// logic is simple .

// ------------------ Main ------------------
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin >> t;
    while (t--)
    {
        solve();
    }
    return 0;
}