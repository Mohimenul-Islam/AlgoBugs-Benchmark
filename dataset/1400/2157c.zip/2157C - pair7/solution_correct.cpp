#include <bits/stdc++.h>
#define N 202
using namespace std;
int d[N], ban[N], b2[N];
struct query {
  int c, l, r;
} a[N];

int solve() {
  int n, k, q; cin >> n >> k >> q;
  for (int i = 1; i <= n; i++) {
    d[i] = 0, ban[i] = 0, b2[i] = 0;
  }
  for (int i = 1; i <= q; i++) {
    cin >> a[i].c >> a[i].l >> a[i].r; 
    if (a[i].c == 2) {
      ban[a[i].l]++;
      ban[a[i].r+1]--;
    } else {
      b2[a[i].l]++;
      b2[a[i].r+1]--;
    }
  }
  for (int i = 1; i <= n; i++) {
    ban[i] = ban[i] + ban[i-1];
    b2[i] = b2[i] + b2[i-1];
  }
  // b2 means can't be less than k. 
  // Ban means can't be k
  for (int i = 1; i <= n; i++) {
    if (b2[i] && ban[i]) d[i] = k + 1;
    else if (!ban[i]) d[i] = k;
  }
  int x = 0;
  for (int i = 1; i <= n; i++) {
    if (d[i]) continue;
    d[i] = x;
    x = (x + 1) % k;
  }
  for (int i = 1; i <= n; i++) {
    cout << d[i] << ' ';
  }
  cout << endl;
  return 0;
}

int main() {
  int T; cin >> T;
  while (T--) solve();
  return 0;
}
