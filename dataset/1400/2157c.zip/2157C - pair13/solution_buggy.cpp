#include<bits/stdc++.h>
#define int long long
using namespace std;
signed main()
{
    int t;cin>>t;
	while(t--){
		int n,k,q;cin>>n>>k>>q;
		vector<int> a(n+1,1000);
		vector<vector<int>> b;
		vector<bool> w(n+1,true);
		for(int i=0;i<q;i++){
			int c,l,r;cin>>c>>l>>r;
			if(c==1)
			{
				for(int j=l;j<=r;j++){
					a[j]=k;
					w[j]=false;
				}
			}
			else
			{
				b.push_back({l,r});
			}
		}
		for(int j=0;j<b.size();j++){
			int x=b[j][0],y=b[j][1],tem=0;
			for(int i=x;i<=y;i++){
				if(tem>=k)tem=0;
				if(k==0)break;
				if(w[i]==true)
				{
					if(a[i]==1000)
					{
						a[i]=tem;
						tem++;
					}
					else
					{
						tem=a[i]+1;
					}
				}
				else
				{
					a[i]++;
				}
			}
		}
		for(int i=1;i<=n;i++){
			cout<<a[i]<<" ";
		}
		cout<<endl;
	}
    return 0;
}