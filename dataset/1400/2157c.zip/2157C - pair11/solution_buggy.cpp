#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

void solve()
{
    int n,k,q;cin>>n>>k>>q;
    set<int> s,p;
    vector<int> nums(n);
    vector<pair<int,int>> pr;
    while(q--)
    {
        int a;cin>>a;
        if(a==1)
        {
            int l,r;cin>>l>>r;
            l--;r--;
            for(int i=l;i<=r;i++)
            s.insert(i);
        }else {
            int l,r;cin>>l>>r;
            l--;r--;
            pr.push_back(make_pair(l,r));
            for(int i=l;i<=r;i++)
            p.insert(i);
        }
    }
    for(int i=0;i<n;i++)
    {
        if(s.find(i)!=s.end())
        {
            if(p.find(i)==p.end())
            nums[i]=k;
            else nums[i]=1000;
            
        }else nums[i]=-1;
    }
    for(int i=0;i<pr.size();i++)
    {
        int c=0;
        for(int j=pr[i].first;j<=pr[i].second;j++)
        {
           if(nums[j]==-1)
           {
               if(c<k)
               nums[j]=c;
               else break;
               c++;
           }
           
        }
    }
    for(int i=0;i<n;i++)
    {
        if(nums[i]!=-1)
        cout<<nums[i]<<' ';
        else cout<<1000<<' ';
    }cout<<endl;
}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    long long t; cin >> t;
    while (t--) {
       solve();
    }
    return 0;
}