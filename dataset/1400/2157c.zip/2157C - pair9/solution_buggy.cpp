#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#include <climits>
using namespace std;
using namespace __gnu_pbds;

// ============= TYPE DEFINITIONS =============
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;

#define int long long
#define double long double
// Remove INT_MAX and INT_MIN redefinitions to avoid conflicts
// Use LLONG_MAX and LLONG_MIN directly instead

// ============= CONTAINERS =============
#define vi vector<ll>
#define vb vector<bool>
#define vvi vector<vi>
#define vvb vector<vb>
#define pll pair<ll, ll>
#define vp vector<pll>
#define vvp vector<vector<pll>>
#define mll map<ll,ll>
#define mci map<char,ll>
#define umi unordered_map<int,int>
#define vstr vector<string>

template<typename T1, typename T2>
using hash_map = gp_hash_table<T1, T2>;
#define ordered_set tree<ll, null_type, less<ll>, rb_tree_tag, tree_order_statistics_node_update>

// ============= SHORTCUTS =============
#define endl '\n'
#define nl '\n'
#define sp ' '
#define pb push_back
#define ppb pop_back
#define eb emplace_back
#define mp make_pair
#define ff first
#define ss second
#define F first
#define S second
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define sz(x) ((int)(x).size())
#define len(x) int((x).size())

// ============= LOOPS =============
#define fo(i,n) for(int i=0;i<n;i++)
#define f(a,b,i) for(int i=a;i<b;i++)
#define fr(i,a,b) for(int i=a;i<=b;i++)
#define wf(a,b,i) for(int i=a;i<=b;i++)
#define rf(a,b,i) for(int i=a;i>=b;i--)
#define rfo(i,n) for(int i=n-1;i>=0;i--)
#define rfr(i,b,a) for(int i=b;i>=a;i--)
#define trav(a,x) for(auto &a : x)

// ============= INPUT/OUTPUT MACROS =============
#define vin(a) for(int i=0;i<(a).size();i++) cin>>a[i];
#define vout(a) for(int i=0;i<a.size();i++) cout<<a[i]<<' '; cout<<endl;
#define in(a,n) vi a(n); fo(i,n) cin>>a[i];
#define vpin(a) for(int i=0;i<(a).size();i++) cin>>a[i].first; for(int i=0;i<(a).size();i++) cin>>a[i].second;
#define vpin2(a) for(int i=0;i<(a).size();i++) cin>>a[i].first>>a[i].second;
#define vpout(a) for(int i=0;i<a.size();i++) cout<<a[i].first<<' '<<a[i].second<<endl; cout<<endl;
#define pyes cout<<"YES"<<nl;
#define pno cout<<"NO"<<nl;
#define r(x) {cout<<x<<endl; return;}
#define done(i) (i+1==n?"\n":" ")
#define line cout<<endl;
#define BHEEM_KI_SHAKTI ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);

// ============= UTILITY FUNCTIONS =============
#define sumV(a) accumulate(all(a),0LL)
#define minV(a) *min_element(all(a))
#define maxV(a) *max_element(all(a))
#define lb lower_bound
#define ub upper_bound
#define sumlr(l,r) (((l)+(r))*((r)-(l)+1))/2
#define pc(x) __builtin_popcountll(x)

// ============= BIT MANIPULATION =============
bool getBit(int x,int k){return (x>>k)&1;}
int setBit(int x,int k){return x|(1LL<<k);}
int clearBit(int x,int k){return x&~(1LL<<k);}
int toggleBit(int x,int k){return x^(1LL<<k);}
bool isPowerOfTwo(int x){return x&&!(x&(x-1));}
int noOfSetBit(int x){return __builtin_popcountll(x);}
int msb_diff(int a,int b=0){return 64-__builtin_clzll(a^b);}
int lsb_diff(int a,int b=0){return __builtin_ffsll(a^b);}
vi getSetBits(int n){vi v; int i=0; while(n>0){if(n&1)v.pb(i); n>>=1; i++;} return v;}
string numToBinary(int n){if(n==0)return "0"; string s=""; while(n>0){s=char((n%2)+'0')+s; n/=2;} return s;}
bool odd(ll n){return ((n&1)==1);}
bool even(ll n){return ((n&1)==0);}

// ============= CONSTANTS =============
const int N = 1e5+10;
const int INF = 1e18;
const int NEG_INF = -1e18;
const int MOD = 998244353;
const int M = 1e9+7;
const double Eps = 1e-9;
const double PI = acos(-1.0);
const double pi = 2*acos(0.0);

// ============= DEBUG TEMPLATE =============
#ifdef ONLINE_JUDGE
#define debug(...)

#else
#define debug(...) cerr<<"["<<#__VA_ARGS__<<"] : ",_print(__VA_ARGS__),cerr<<endl;
#endif

void _print(ll t){cerr<<t;}
void _print(string t){cerr<<t;}
void _print(char t){cerr<<t;}
void _print(double t){cerr<<t;}
void _print(ull t){cerr<<t;}
void _print(){}
template<typename T,typename... Args>void _print(const T& t,const Args&... args){cerr<<t; if(sizeof...(args))cerr<<", "; _print(args...);}
template<class T,class V>void _print(pair<T,V>p);
template<class T>void _print(vector<T>v);
template<class T>void _print(set<T>v);
template<class T>void _print(multiset<T>v);
template<class T,class V>void _print(pair<T,V>p){cerr<<"{";_print(p.ff);cerr<<",";_print(p.ss);cerr<<"}";}
template<class T>void _print(vector<T>v){cerr<<"[ ";for(T i:v){_print(i);cerr<<" ";}cerr<<"]";}
template<class T>void _print(set<T>v){cerr<<"[ ";for(T i:v){_print(i);cerr<<" ";}cerr<<"]";}
template<class T>void _print(multiset<T>v){cerr<<"[ ";for(T i:v){_print(i);cerr<<" ";}cerr<<"]";}
template<class T,class V>void _print(map<T,V>v){cerr<<"[ ";for(auto i:v){_print(i);cerr<<" ";}cerr<<"]";}

// ============= NUMBER THEORY =============
ll gcd(ll a,ll b){if(b==0)return a; return gcd(b,a%b);}
ll lcm(ll a,ll b){return a*b/gcd(a,b);}
ll fastExpo(ll x,ll y,ll m){ll res=1; x=x%m; while(y>0){if(y&1)res=(res*x)%m; y=y>>1; x=(x*x)%m;} return res;}
ll powm(ll a,ll b,ll m){ll res=1; a%=m; while(b>0){if(b%2==1)res=(res*a)%m; a=(a*a)%m; b/=2;} return res;}
ll mod(ll x,ll m){return ((x%m+m)%m);}
ll addMod(ll a,ll b,ll m){return mod(mod(a,m)+mod(b,m),m);}
ll mulMod(ll a,ll b,ll m){return mod(mod(a,m)*mod(b,m),m);}
ll subMod(ll a,ll b,ll m){return mod(mod(a,m)-mod(b,m),m);}
ll divMod(ll a,ll b,ll m){return mod(mulMod(a,fastExpo(b,m-2,m),m),m);}

// ============= SIEVE (COMPRESSED) =============
const int SIEVE_N = 1e7+5;
bitset<SIEVE_N> isp;
vector<int> pr;
int spf[SIEVE_N];
void sieve(){
    isp.set(); isp[0]=isp[1]=0;
    for(int i=2;i<SIEVE_N;i++){
        if(isp[i]){
            pr.pb(i); spf[i]=i;
            if(1LL*i*i<SIEVE_N)
                for(int j=i*i;j<SIEVE_N;j+=i)
                    if(isp[j])isp[j]=0,spf[j]=i;
        }
    }
}
bool isPrime(int x){return isp[x];}
vector<int> factor(int x){vector<int>f; while(x>1)f.pb(spf[x]),x/=spf[x]; return f;}

vb sieveBool(int n){vb p(n+1,true); p[0]=p[1]=false; for(int i=2;i*i<=n;i++)if(p[i])for(int j=i*i;j<=n;j+=i)p[j]=false; return p;}
vi computeSPF(int n){vi spf(n); for(int i=1;i<n;i++)spf[i]=i; for(int i=2;i*i<n;i++)if(spf[i]==i)for(int j=i*i;j<n;j+=i)if(spf[j]==j)spf[j]=i; return spf;}

// ============= FACTORIZATION =============
vi getDivisors(ll n){vi d; for(ll i=1;i*i<=n;i++)if(n%i==0){d.pb(i); if(i!=n/i)d.pb(n/i);} sort(all(d)); return d;}
vp primeFactors(ll n){vp v; ll sqrt_n=sqrtl(n); for(ll j=2;j<=sqrt_n;j++){ll cnt=0; while(n%j==0)n/=j,cnt++; if(cnt)v.pb(mp(j,cnt));} if(n!=1)v.pb(mp(n,1)); return v;}

// ============= COMBINATORICS =============
vi fact(int n,int m){vi fact(n+1,1); for(int i=2;i<=n;i++)fact[i]=mulMod(fact[i-1],i,m); return fact;}
vi invFact(int n,int m){vi f=fact(n,m); vi inv(n+1); inv[n]=fastExpo(f[n],m-2,m); for(int i=n-1;i>=0;i--)inv[i]=mulMod(inv[i+1],i+1,m); return inv;}
int nCr(int n,int r,vi &fact,vi &invFact,int m){if(n<r||r<0)return 0; if(n==r||r==0)return 1; return mulMod(fact[n],mulMod(invFact[r],invFact[n-r],m),m);}

// ============= ARRAY UTILITIES =============
mll freq(vi v){mll freq; for(auto x:v)freq[x]++; return freq;}
mci S_freq(const string &s){mci freq; for(auto x:s)freq[x]++; return freq;}
vi prefix(const vi &arr){vi b(sz(arr)+1,0); f(1,sz(arr)+1,i)b[i]=b[i-1]+arr[i-1]; return b;}
vi suffix(const vi &arr){vi b(sz(arr)+1,0); rf(sz(arr)-1,0,i)b[i]=b[i+1]+arr[i]; return b;}
vi removeDuplicates(vi &a){unordered_set<int>seen; vi result; result.reserve(a.size()); for(int x:a)if(seen.insert(x).second)result.pb(x); return result;}

// ============= GRAPH UTILITIES =============
vvi adjList(int n,int m){vvi adj(n); f(0,m,i){int u,v; cin>>u>>v; u--,v--; adj[u].pb(v); adj[v].pb(u);} return adj;}
vvi adjListd(int n,int m){vvi adj(n); f(0,m,i){int u,v; cin>>u>>v; u--,v--; adj[u].pb(v);} return adj;}
vvp adjListpd(int n,int m){vvp adj(n); f(0,m,i){int u,v,w; cin>>u>>v>>w; u--,v--; adj[u].pb(mp(v,w));} return adj;}
vvp adjListpu(int n,int m){vvp adj(n); f(0,m,i){int u,v,w; cin>>u>>v>>w; u--,v--; adj[u].pb(mp(v,w)); adj[v].pb(mp(u,w));} return adj;}

vi dijkstra(int n,vvp&adj,int src){vi dist(n,INF); priority_queue<pll,vp,greater<pll>>pq; dist[src]=0; pq.push(mp(0,src)); while(!pq.empty()){auto[d,curr]=pq.top(); pq.pop(); if(d>dist[curr])continue; for(auto x:adj[curr]){int v=x.ff,w=x.ss; if(dist[v]>dist[curr]+w){dist[v]=dist[curr]+w; pq.push(mp(dist[v],v));}}} return dist;}

bool hasCycleUndirected(int n,const vvi &adj){vb visited(n,false); function<bool(int,int)>dfs=[&](int u,int parent){visited[u]=true; for(int v:adj[u]){if(!visited[v]){if(dfs(v,u))return true;}else if(v!=parent)return true;} return false;}; for(int i=0;i<n;i++)if(!visited[i]&&dfs(i,-1))return true; return false;}

bool hasCycleDirected(int n,const vvi &adj){vb visited(n,false),recStack(n,false); function<bool(int)>dfs=[&](int u){visited[u]=true; recStack[u]=true; for(int v:adj[u]){if(!visited[v]){if(dfs(v))return true;}else if(recStack[v])return true;} recStack[u]=false; return false;}; for(int i=0;i<n;i++)if(!visited[i]&&dfs(i))return true; return false;}

bool isBipartite(int n,const vvi &adj){vi color(n,-1); function<bool(int,int)>bfs=[&](int start,int c){queue<int>q; q.push(start); color[start]=c; while(!q.empty()){int u=q.front(); q.pop(); for(int v:adj[u]){if(color[v]==-1){color[v]=1-color[u]; q.push(v);}else if(color[v]==color[u])return false;}} return true;}; for(int i=0;i<n;i++)if(color[i]==-1&&!bfs(i,0))return false; return true;}

// ============= MISCELLANEOUS =============
int bin_search(vi &a,int target){int l=0,r=a.size()-1; while(l<=r){int m=(l+r)/2; if(a[m]==target)return m; else if(a[m]<target)l=m+1; else r=m-1;} return -1;}

/*                __  _ __        __       __       
   ___  _______ _/ /_(_) /__ ____/ /______/ /  ___ _
  / _ \/ __/ _ `/ __/ /  '_// __/  '_/ __/ _ \/ _ `/
 / .__/_/  \_,_/\__/_/_/\_\/_/ /_/\_\__/_//_ /\_,_/ 
/_/                                               */

void precalc(){
    // sieve();
}
void solve1() {
    int n, k, q;
    cin >> n >> k >> q;
    vector<int> a(n, -1);
    vector<bool> is_type1(n, false);
    vector<pair<int, int>> type2_queries;

    while (q--) {
        int c, l, r;
        cin >> c >> l >> r;
        if (c == 1) {
            for (int i = l - 1; i < r; i++) is_type1[i] = true;
        } else {
            type2_queries.push_back({l - 1, r - 1});
        }
    }

    // Apply Type 1 and handle Type 2 overlap
    for (int i = 0; i < n; i++) {
        if (is_type1[i]) a[i] = k;
    }
    for (auto& q : type2_queries) {
        for (int i = q.first; i <= q.second; i++) {
            if (is_type1[i]) a[i] = k + 1;
        }
    }

    // Fill missing MEX values for Type 2
    for (auto& q : type2_queries) {
        vector<bool> present(k, false);
        for (int i = q.first; i <= q.second; i++) {
            if (a[i] != -1 && a[i] < k) present[a[i]] = true;
        }
        
        int missing = 0;
        for (int i = q.first; i <= q.second && missing < k; i++) {
            if (a[i] == -1) {
                while (missing < k && present[missing]) missing++;
                if (missing < k) {
                    a[i] = missing;
                    present[missing] = true;
                }
            }
        }
    }

    // Fill remainders
    for (int i = 0; i < n; i++) if (a[i] == -1) a[i] = k + 1;
    
    for (int i = 0; i < n; i++) cout << a[i] << (i == n - 1 ? "" : " ");
    cout << endl;
}
void solve2(){

}
int32_t main(){
    BHEEM_KI_SHAKTI;
    precalc();
    int t;
    cin>>t;
    while(t--){
        solve1();
        //solve2();
    }
    return 0;
}