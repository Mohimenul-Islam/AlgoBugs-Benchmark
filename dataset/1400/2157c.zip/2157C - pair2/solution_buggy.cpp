#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define do double
#define str string
#define en '\n'
#define all(x) x.begin(),x.end()
#define rall(x) x.rbegin(),x.rend()
#define pb push_back
#define F first
#define S second
#define sz (ll)size
#define mms(var,arr) memset(arr,var,sizeof arr)
#define input(v) for(auto&it:v){cin>>it;}
#define sp ' '
#define isON(n,k) ((n) >> (k) & 1ll)    // check if the k th bit in n is on

void _3RBY_()
{
    ios_base::sync_with_stdio(0); cin.tie(0) , cout.tie(0);
#ifdef Clion
    freopen("input.txt", "r",stdin);
    freopen("output.txt", "w",stdout);
#endif
}

const int oo = 0x3f3f3f3f , mod = 1e9 + 7 , N = 2e5 + 5 , M = 1e6 + 5;
const ll OO = 0x3f3f3f3f3f3f3f3f;

void solve()
{
    ll n, k, q; cin >> n >> k >> q;
    vector<pair<ll,ll>> t;
    vector<ll> ans(n), state(n);
    while(q--)
    {
        ll c, l, r; cin >> c >> l >> r;
        l--, r--;
        if(c == 2) t.push_back({l, r});
        for (int i = l; i <= r; ++i)
            state[i] |= c;
    }

    for (int i = 0; i < n; ++i)
    {
        if(state[i] == 0)
            ans[i] = k+1;
        else if(state[i] == 1)
            ans[i] = k;
        else
            ans[i] = 1e9;
    }

    for(auto& [l, r] : t)
    {
        for (int i = 0; i < k; ++i)
        {
            bool exist = false;
            for (int j = l; j <= r; ++j)
            {
                if(ans[j] == i)
                    exist = true;
            }
            if(!exist)
            {
                for (int j = l; j <= r; ++j)
                {
                    if(state[j] == 2 && ans[j] == 1e9)
                    {
                        ans[j] = i;
                        break;
                    }
                }
            }
        }
    }

    for(auto& a : ans)
        cout << a << sp;
    cout << en;
}

signed main()
{
    _3RBY_();
    int t = 1;
    cin >> t;
    for (int i = 0; i < t; ++i)
        solve();
}