// I Trust In My God and In My Self I Will Be Great In This Life And This Field.
// Try Try Try ... Try forever always exit choice
// ------------------------------------------------------------------------
// ░██╗░░░░░░░██╗░█████╗░██████╗░██╗░░██╗  ██╗░░██╗░█████╗░██████╗░██████╗░
// ░██║░░██╗░░██║██╔══██╗██╔══██╗██║░██╔╝  ██║░░██║██╔══██╗██╔══██╗██╔══██╗
// ░╚██╗████╗██╔╝██║░░██║██████╔╝█████═╝░  ███████║███████║██████╔╝██║░░██║
// ░░████╔═████║░██║░░██║██╔══██╗██╔═██╗░  ██╔══██║██╔══██║██╔══██╗██║░░██║
// ░░╚██╔╝░╚██╔╝░╚█████╔╝██║░░██║██║░╚██╗  ██║░░██║██║░░██║██║░░██║██████╔╝
// ░░░╚═╝░░░╚═╝░░░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝  ╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═════╝░
// ----------------------------------------------------------------------
//*/TRUE OR FALSE
#include <bits/stdc++.h>
#include <numeric>
#pragma GCC optimize("Ofast")
#pragma GCC optimize("O3")
using namespace std;
#define dl long double
#define ll long long
#define pb push_back
#define nl "\n"
#define cut cout << "\n----------------------------\n"
#define here cout << "------------------->"
#define dbg(x) cerr << #x << " : " << x << nl
#define all(a) (a).begin(), (a).end()
#define maxi max_element
#define mini min_element
#define F first
#define S second
#define yes cout << "YES" << nl
#define no cout << "NO" << nl
#define pass continue
#define int1 __int128
#define flash ios::sync_with_stdio(false), cin.tie(0), cout.tie(0)
const ll MOD = 1e9 + 7;
const ll MAX = LLONG_MAX;
const int N = 1e6 + 2;
int t31 = 2147483647;
int nx[] = {1, 0, -1, 0};
int ny[] = {0, 1, 0, -1};
string see_binary_shape(ll n)
{
    string res = "";
    while (n != 0)
    {
        if (n % 2)
        {
            res += '1';
        }
        else
        {
            res += '0';
        }
        n /= 2;
    }
    reverse(all(res));
    return res;
}
ll decimal_shape(string s)
{
    ll l = s.size() - 1, p2 = 1, num = 0;
    for (int i = l; i >= 0; --i)
    {
        if (s[i] == '1')
        {
            num += p2;
        }
        p2 *= 2;
    }
    return num;
}
void see_map(map<ll, ll> mp)
{
    for (auto [val, fre] : mp)
        cout << "value = " << val << " frequency = " << fre << nl;
}
void see_vector_of_pair(vector<pair<ll, ll>> v)
{
    for (auto i : v)
        cout << i.F << " " << i.S << nl;
}
void see_set(set<ll> s)
{
    for (auto i : s)
        cout << i << " ";
    cout << nl;
}
void see_vector(vector<ll> a)
{
    for (auto i : a)
        cout << i << " ";
    cout << nl;
}
/*int n, m;
bool inside(int x, int y){
    return (x < n && x >= 0 && y >= 0 && y < m);
    }*/
ll add(ll a, ll b, ll m) { return ((a % m) + (b % m)) % m; }
ll sub(ll a, ll b, ll m) { return ((a % m) - (b % m) + m) % m; }
ll mul(ll a, ll b, ll m) { return ((a % m) * (b % m)) % m; }
ll modinv(ll x, ll m = MOD)
{
    ll res = 1, p = m - 2;
    while (p)
    {
        if (p & 1)
            res = mul(res, x, m);
        x = mul(x, x, m);
        p >>= 1;
    }
    return res;
}
ll divmod(ll a, ll b, ll m = MOD) { return mul(a, modinv(b, m), m); }

bool cmp(string a, string b)
{
    if (a.size() != b.size())
    {
        return a.size() < b.size();
    }
    return a < b;
}
void test()
{
}
/*
2157C
/*Hungry(•_- )*/
void NAH_I_WILL_EVOLVE() {
    int n, k, q;
    cin >> n >> k >> q;
    vector<pair<int, pair<int, int>>> v(q);
    vector<int> mn(n + 1, 0);
    vector<int> mx(n + 1, 0);

    for (int i = 0 ; i < q ; i++) {
        cin >> v[i].F >> v[i].S.F >> v[i].S.S;
        for (int j = v[i].S.F; j <= v[i].S.S; j++) {
            if (v[i].F == 1) mn[j] = 1;
            else mx[j] = 1;
        }
    }

    vector <int> ans(n + 1);
    for (int i = 1; i <= n; i++) {
        if (mn[i] && mx[i]) {
            ans[i] = k + 1;
        } else if (mn[i]) {
            ans[i] = k;
        } else {
            ans[i] = k + 1; 
        }
    }

    for (int i = 0 ; i < q ; i++) {
        if (v[i].F == 2) {
            int l = v[i].S.F;
            int r = v[i].S.S;
            for (int p = 0 ; p < k ; p++) {
                int ok = 0;
                for (int j = l ; j <= r ; j++) {
                    if (ans[j] == p) {
                        ok = 1;
                        break;
                    }
                }
                if (!ok) {
                    for (int j = l ; j <= r ; j++) {
                        if (!mn[j] && ans[j] == k + 1) {
                            ans[j] = p;
                            break;
                        }
                    }
                }
            }
        }
    }

    for (int i = 1 ; i <= n ; i++) {
        cout << ans[i] << " ";
    }
    cout << nl;
}
int main()
{
    flash;
    ll tt = 1;
    cin >> tt;
    while (tt--)
    {
        NAH_I_WILL_EVOLVE();
        // test();
    }
    return 0;
}
