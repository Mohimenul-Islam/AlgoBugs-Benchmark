#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

typedef long long int ll;
typedef long double ld;

typedef tree<ll, null_type, less<>, rb_tree_tag, tree_order_statistics_node_update> ordered_set;
typedef tree<pair<ll, ll>, null_type, less<>, rb_tree_tag, tree_order_statistics_node_update> ordered_multi_set;


#define IOS                                                                  \
    ios_base::sync_with_stdio(false);                                        \
    cin.tie(nullptr);                                                        \
    cout<<fixed<<setprecision(16);

#define el '\n'

#define pb push_back
#define mp make_pair
#define eb emplace_back

#define f1(i, a, b) for (ll i=a; i<=b; i++)
#define f2(i, a, b) for (ll i=a; i>=b; i--)

#define vll vector<ll>
#define pll pair<ll, ll>
#define sll set<ll>
#define usll unordered_set<ll>
#define msll multiset<ll>
#define pqueue priority_queue<ll>
#define pdqueue priority_queue<ll, vll ,greater<>>

#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()

#define sz(a) (ll)a.size()

#define YES cout << "YES" << endl
#define NO cout << "NO" << endl

template<typename T, typename U> bool chmax(T &a, U b) { return (a < b ? a = b, 1 : 0); }
template<typename T, typename U> bool chmin(T &a, U b) { return (a > b ? a = b, 1 : 0); }

template <typename T>
std::ostream& operator<<(std::ostream& os, const std::vector<T>& v) {
    for (size_t i = 0; i < v.size(); ++i) {
        os << v[i] << (i == v.size() - 1 ? "" : " ");
    }
    return os;
}




void solve() {
    ll n, k, q; cin >> n >> k >> q;

    vll a(n, -1);

    vector<vll> qu(q);
    f1(i, 0, q - 1) {
        ll c, l, r; cin >> c >> l >> r;
        qu[i] = {r, l , c};
    }

    sort(qu.begin(), qu.end());


    f1(i, 0, q - 1) {
        ll r = qu[i][0], l = qu[i][1], c = qu[i][2];

        if (c == 1)
            f1(j, l - 1, r - 1) a[j] = k;
    }

    f1(i, 0, q - 1) {
        ll r = qu[i][0], l = qu[i][1], c = qu[i][2];
        if (c == 2) {

            usll s;
            f1(j, 0, k - 1) s.insert(j);

            f1(j, l - 1, r - 1) {
                if (a[j] == k) a[j] = k + 1;
                else if (a[j] < k && a[j] >= 0) s.erase(a[j]);
            }

            f1(j, l - 1, r - 1) {
                if (a[j] == -1 && s.size()) {
                    a[j] = *s.begin();
                    s.erase(s.begin());
                }
            }
        }
    }

    f1(i, 0, n - 1) {
        if (a[i] == -1) a[i] = 0;
    }

    cout << a << el;


}

int main() {
    IOS
    int t;
    cin >> t;

    while(t--) solve();

    return 0;
}
