#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ull = unsigned long long;
using ld = long double;
using pii = pair<int, int>;
using vi = vector<int>;
using vll = vector<ll>;

// I/O overloads for ranges (vector, array, ...) and tuple-likes (pair, tuple).
// Excludes strings to avoid conflicting with existing overloads.
template <typename T>
concept MultiIOable = !is_convertible_v<decay_t<T>, string> &&
                      (ranges::range<T> || requires { tuple_size<decay_t<T>>::value; });

template <MultiIOable T> istream& operator>>(istream& is, T& v) {
    if constexpr (ranges::range<T>)
        for (auto& x : v) is >> x;
    else // tuple-like: unpack all elements
        apply([&](auto&... x) { ((is >> x), ...); }, v);
    return is;
}

template <MultiIOable T> ostream& operator<<(ostream& os, T const& v) {
    if constexpr (ranges::range<T>)
        for (auto const& x : v) os << x << ' ';
    else // tuple-like: unpack all elements
        apply([&](auto const&... x) { ((os << x << ' '), ...); }, v);
    return os;
}

// Prints variable name and value to stderr. Only active when compiled with -DLOCAL.
#ifdef LOCAL
#define debug(x) cerr << "[" << #x << "] = " << (x) << '\n'
#else
#define debug(x)
#endif

const int INF = 1e9 + 5;
const ll INFLL = 1e18 + 5;

/**
 * Observations:
 * - the following applies to all segment [l, r]
 *   - if has both c = 1 and c = 2, it means a_i must be > k.
 *   - if only has c = 1, just assign k
 *   - if only has c = 2, must contribute to mex
 *     - in this case, we should process from tuple with "smallest" number of unset a_i
 *   - otherwise, doesn't matter
 */

void solveCase() {
    int n, k, q;
    cin >> n >> k >> q;

    vector<int> c1(n + 2, 0), c2(n + 2, 0);
    vector<pii> mex;
    for (int i = 0; i < q; i++) {
        int c, l, r;
        cin >> c >> l >> r;

        if (c == 1) {
            c1[l]++;
            c1[r + 1]--;
        } else {
            c2[l]++;
            c2[r + 1]--;

            mex.push_back({l, r});
        }
    }


    vector<int> a(n + 1, -1); // -1 = unset
    int nv = 0;
    for (int i = 1; i <= n; i++) {
        c1[i] += c1[i - 1];
        c2[i] += c2[i - 1];

        if (c1[i] && c2[i]) {
            a[i] = k + 1;
        } else if (c1[i]) {
            a[i] = k;
        } else if (c1[i] == 0 && c2[i] == 0) {
            a[i] = 0;
        } else {
            a[i] = nv;
            nv = (nv + 1) % k;
        }
    }

    a.erase(a.begin());
    cout << a << '\n';
}

int main() {
    // note: don't mix with scanf/printf
    ios::sync_with_stdio(0), cin.tie(0);
    cin.exceptions(cin.failbit);

    int tc;
    cin >> tc;
    for (int cs = 1; cs <= tc; cs++) {
        solveCase();
    }
    return 0;
}
