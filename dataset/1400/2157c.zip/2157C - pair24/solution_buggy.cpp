#include <iostream>
#include <vector>

using namespace std;

void solve() {
    int sz, target, queries;
    cin >> sz >> target >> queries;
    vector<bool> req_min(sz + 1, false);
    vector<bool> req_mex(sz + 1, false);

    for (int j = 0; j < queries; ++j) {
        int type, L, R;
        cin >> type >> L >> R;
        if (type == 1) {
            for (int x = L - 1; x < R; ++x) req_min[x] = true;
        } else {
            for (int x = L - 1; x < R; ++x) req_mex[x] = true;
        }
    }

    for (int j = 1; j <= sz; ++j) {
        if (req_min[j] && req_mex[j]) cout << target + 1 << " ";
        else if (req_min[j]) cout << target << " ";
        else if (req_mex[j]) cout << j % target << " ";
        else cout << target + 1 << " ";
    }
    cout << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
