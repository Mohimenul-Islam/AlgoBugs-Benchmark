#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
template<typename T>using ordered_set=tree<T,null_type,less<T>,rb_tree_tag,tree_order_statistics_node_update>;
    //order_of_key(x);
#define int long long
#define ld long double
#define bitcnt(n) __builtin_popcountll(n)
#define go_abo() ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define endl '\n'
#define vin(v) for(auto &x:v)cin>>x;
#define vout(v) for(auto x:v)cout<<x<<' ';cout<<endl;
#define all(v) (v).begin(),(v).end()
#define yn(x) cout << ((x) ? "YES\n" : "NO\n")
#define gap <<' '<<
int factorial(int n){int f=1;for(int i=2;i<=n;i++)f*=i;return f;}
int nCr(int n,int r){return factorial(n)/(factorial(r)*factorial(n-r));}
int nPr(int n,int r){return factorial(n)/factorial(n-r);}
#define MOD 1000000007
#define add(a,b) (((a)%MOD + (b)%MOD)%MOD)
#define sub(a,b) (((a)%MOD - (b)%MOD + MOD)%MOD)
#define mul(a,b) (((a)%MOD * (b)%MOD)%MOD)
#define modpow(a,b) mod_exp((a)%MOD,b)
int mod_exp(int a,int b){int res=1;while(b){if(b&1)res=mul(res,a);a=mul(a,a);b>>=1;}return res;}
#define inv(a) mod_exp(a,MOD-2)
const int N=1e7+5;
vector<int> primes;int spf[N];
void sieve(){for(int i=2;i<N;i++){if(!spf[i])spf[i]=i,primes.push_back(i);for(int p:primes){if(p>spf[i]||i*p>=N)break;spf[i*p]=p;}}}
bool isPrime(int n){return n>1&&spf[n]==n;}
vector<int>getPrimes(int n){return vector<int>(primes.begin(),upper_bound(primes.begin(),primes.end(),n));}
vector<int> factor(int n){vector<int> f; for(int i=1;i*i<=n;i++){if(n%i==0){f.push_back(i); if(i!=n/i) f.push_back(n/i);}} sort(f.begin(),f.end()); return f;}
int kadane(vector<int>&v){int cur=v[0],mx=v[0];for(int i=1;i<v.size();i++)cur=max(v[i],cur+v[i]),mx=max(mx,cur);return mx;}
vector<int>pref(vector<int>&v){vector<int>p(v.size());partial_sum(v.begin(),v.end(),p.begin());return p;}
vector<int>suff(vector<int>&v){vector<int>s(v.size());partial_sum(v.rbegin(),v.rend(),s.rbegin());return s;}
vector<int> get_factors(int n) { vector<int> f; while(n > 1) { int p = spf[n]; f.push_back(p); while(n % p == 0) n /= p; } return f; }
vector<pair<int,int>> get_pf(int n) { vector<pair<int,int>> r; while(n > 1) { int p = spf[n], c = 0; while(n % p == 0) n /= p, c++; r.push_back({p, c}); } return r; }
#define mset(a) memset(a, 0, sizeof(a))
#define fil(a) fill(all(a),0);
#define lcm(a,b) (a*b)/__gcd(a,b)
void code();
signed main(){
    go_abo();
    sieve();
    int t=1;
    cin >> t;
    for(int i=0;i<t;i++){
        // cout << "Case " << i << ": ";
        code();
    }
}
/*
    Binary search khatbe?
*/
void code(){
    int n,k,q;cin>>n>>k>>q;
    vector<int>v(n+1);
    v[0]=-1;
    vector<pair<int,int>>mn,mx;
    for(int i=0;i<q;i++){
        int c,l,r;cin>>c>>l>>r;
        (c==1?mn.emplace_back(l,r):mx.emplace_back(l,r));
    }
    sort(all(mx));
    for(auto [x,y]:mn){
        for(int i=x;i<=y;i++)if(!v[i])v[i]=200;
    }
    for(auto [x,y]:mx){
        for(int i=x;i<=y;i++)v[i]=(!v[i]||v[i]==300?300:400);
    }
    // for(int i=1;i<=n;i++)if(!v[i])v[i]=k+1;
    for(auto [x,y]:mn){
        for(int i=x;i<=y;i++){
            if(v[i]==200){
                v[i]=k;break;
            }
        }
    }
    for(auto [x,y]:mx){
        set<int>st;
        queue<int>q;
        for(int i=x;i<=y;i++)if(v[i]<k)st.insert(v[i]);
        for(int i=0;i<k;i++)if(!st.count(i))q.push(i);
        for(int i=x;i<=y&&!q.empty();i++){
            if(v[i]==300)v[i]=q.front(),q.pop();
        }
    }
    for(int i=1;i<=n;i++)cout<<v[i]<<' ';cout<<endl;
}