#include <iostream>
#include <sstream>
#include <cstdio>
#include <iomanip>
#include <string>
#include <cstring>
#include <cctype>
#include <algorithm>
#include <functional>
#include <utility>
#include <bitset>
#include <vector>
#include <list>
#include <queue>
#include <stack>
#include <deque>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <cmath>
#include <cstdlib>
#include <numeric>
#include <ctime>
using namespace std;
using ll = long long;
using pii = pair<int, int>;
#define rep(i, a, b) for (int i = (a); i <= (b); i++)
#define per(i, a, b) for (int i = (a); i >= (b); i--)
#define endl '\n'
const int N = 2e5 + 5;
const int M = 4e5 + 5;

int n, m;
int head[N];
int ver[M], Next[M], tot;
void add(int u, int v) {
	++tot;
	ver[tot] = v;
	Next[tot] = head[u];
	head[u] = tot;
}
int c[N];
bool fail;
int sz[4];
void dfs(int u, int fu, int t) {
	if (c[u]) {
		if (c[u] != t) fail = true;
		return;
	}
	c[u] = t;
	sz[t]++;
	for (int i = head[u]; i; i = Next[i]) {
		int v = ver[i];
		if (v == fu) continue;
		dfs(v, u, t ^ 1);
	}
}
void solve() {
	cin >> n >> m;
	rep(i, 1, n) head[i] = 0, c[i] = 0;
	tot = 0;
	rep(i, 1, m) {
		int u, v;
		cin >> u >> v;
		add(u, v), add(v, u);
	}
	int ans = 0;
	rep(i, 1, n) if (!c[i]) {
		fail = false, sz[2] = sz[3] = 0;
		dfs(i, i, 2);
		if (!fail) ans += max(sz[2], sz[3]);
	}
	cout << ans << endl;
	return;
}
int main() {
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	int t;
	cin >> t;
	while (t--) solve();
	return 0;
}