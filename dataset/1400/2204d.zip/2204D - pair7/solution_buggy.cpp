# include <bits/stdc++.h>
# define int long long
# define vi vector<int>
# define pb push_back
# define pii pair<int, int>
# define fi first
# define se second
# define endl '\n'
# define jess ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

using namespace std;

int n, m, u[200005], v[200005], val[200005];
vi adj[200005];
bool vis[200005], st[200005];

void dfs(int x, int mp) {
    for(int i : adj[x]) {
        if(vis[i]) continue;
        vis[i]=1;
        st[i]=mp^1;
        dfs(i, mp^1);
    }
}

void tandain(int x) {
    val[x]=0;
    for(int i : adj[x]) {
        if(vis[i]) continue;
        vis[i]=1;
        tandain(i);
    }
}

void solve () {
    cin >> n >> m;
    for(int i=1; i<=n; i++) {
        vis[i]=0;
        st[i]=0;
        val[i]=1;
        adj[i].clear();
    }
    for(int i=1; i<=m; i++) {
        cin >> u[i] >> v[i];
        adj[u[i]].pb(v[i]);
        adj[v[i]].pb(u[i]);
    }
    for(int i=1; i<=n; i++) {
        if(vis[i]) continue;
        vis[i]=1;
        st[i]=0;
        dfs(i, 0);
    }
    for(int i=1; i<=n; i++) {
        vis[i]=0;
    }
    for(int i=1; i<=m; i++) {
        if(st[u[i]]==st[v[i]]) {
            if(vis[u[i]]) continue;
            vis[u[i]]=1;
            tandain(u[i]);
        }
    }
    int ans=0;
    for(int i=1; i<=n; i++) {
        if(val[i]>0 && st[i]==0) ans++;
    }
    cout << ans << endl;
}
 
signed main() {
   jess;
   int tc; cin >> tc;
   while(tc--) solve();
}