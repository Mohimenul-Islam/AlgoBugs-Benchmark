#include <bits/stdc++.h>
using namespace std;
#define ll long long
const ll N = 2e5+5;
const ll pN = 1e7+5;
const ll inf = 1e18;
const ll mod=1e9+7;
#define vi vector<ll>
#define forn(i,n) for(ll i=0;i<n;i++)
#define fore(i,n) for(ll i=0;i<=n;i++)
#define rloope(i,a,b) for(ll i=a;i>=b;i--)
#define mpr make_pair
#define ff first
#define ss second
#define pb push_back
#define ppb pop_back
#define pii pair<ll,ll>
#define pqas priority_queue<int, vector<int> , greater<int> >
#define mi map<ll,ll>
#define loop(i,a,b) for(ll i=a;i<b;i++)
#define loope(i,a,b) for(ll i=a;i<=b;i++)
#define asc(v) sort(v.begin(), v.end())
#define des(v) sort(v.begin(), v.end(), greater<int>())
#define all(x) x.begin(), x.end()
#define fastinput ios_base::sync_with_stdio(false);cin.tie(NULL);
#pragma GCC optimize("O3,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
ll dbg=1;
// GCD function
ll gcd(ll a, ll b) {
    if (a == 0)
        return b;
    return gcd(b % a, a);
}
// Binary exponentiation with mod
// ll binexp(ll x, ll y, ll p) {
//     ll res = 1;
//     x = x % p;
//     if (x == 0) return 0;
//     while (y > 0) {
//         if (y & 1) res = (res * x) % p;
//         y = y >> 1;
//         x = (x * x) % p;
//     }
//     return res;
// }
// Segment Tree class template (commented out)
// class SGTree {
//     vector<ll> seg;
// public:
//     SGTree(ll n) {
//         seg.resize(4 * n + 1);
//     }
//     void build(ll ind, ll low, ll high, vi &v) {
//         if (low == high) {
//             seg[ind] = v[low];
//             return;
//         }
//         ll mid = (low + high) / 2;
//         build(2 * ind + 1, low, mid, v);
//         build(2 * ind + 2, mid + 1, high, v);
//         seg[ind] = min(seg[2 * ind + 1], seg[2 * ind + 2]);
//     }
//     ll query(ll ind, ll low, ll high, ll l, ll r) {
//         if (r < low || high < l) return INT_MAX;
//         if (low >= l && high <= r) return seg[ind];
//         ll mid = (low + high) / 2;
//         ll left = query(2 * ind + 1, low, mid, l, r);
//         ll right = query(2 * ind + 2, mid + 1, high, l, r);
//         return min(left, right);
//     }
//     void update(ll ind, ll low, ll high, ll i, ll val) {
//         if (low == high) {
//             seg[ind] = val;
//             return;
//         }
//         ll mid = (low + high) / 2;
//         if (i <= mid) update(2 * ind + 1, low, mid, i, val);
//         else update(2 * ind + 2, mid + 1, high, i, val);
//         seg[ind] = min(seg[2 * ind + 1], seg[2 * ind + 2]);
//     }
// };
vi g[N];
ll barup[2];

void dfs(ll node,ll c, vi &col, int &fl)
{
    col[node] = c;
    barup[c]++;

    for(auto &child : g[node])
    {
        if(col[child] == -1)
        {
            dfs(child,1-c,col,fl);
        }
        else if(col[child] == c)
        {
            fl = 0;
        }
    }
}
void solve()
{
    // Your problem-solving logic
    
    ll n,m;cin>>n>>m;
    forn(i,n+5) g[i].clear();
    barup[0] = barup[1] = 0;
    vi col(n+1,-1);
    ll ans = 0;
    loop(i,0,m) 
    {
        ll u,v;cin>>u>>v;
        g[u].pb(v);
        g[v].pb(u);
    }
    for(int i=1;i<=n;i++)
    {
        if(col[i] == -1)
        {
            int fl = 1;
            barup[0] = barup[1] = 0;
            dfs(i,0,col,fl);
            if(fl) ans += (ll)fmax(barup[0],barup[1]);
        }
    }
    cout<<ans<<endl;
    
}
int main()
{
    fastinput
    auto begin = std::chrono::high_resolution_clock::now();
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
    int t = 1; cin >> t;
    loope(i, 1, t) {
        // cout << "Case #" << i << ": ";
        solve();
    }
    auto end = std::chrono::high_resolution_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin);
    // cerr << "Time measured: " << elapsed.count() * 1e-9 << " seconds.\n";
    return 0;
}