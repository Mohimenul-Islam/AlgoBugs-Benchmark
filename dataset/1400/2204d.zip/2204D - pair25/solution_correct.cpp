#include <bits/stdc++.h>
using ll = long long;
#define f(i, n) for (int i = 0; i < int(n); i++)
using namespace std;

const ll MOD = 1e9 + 7;

void solve() {
    ll n, m;
    cin >> n >> m;
    vector<set<ll>> g(n + 1); 
    f(i, m) {
        ll u, v;
        cin >> u >> v;
        g[u].insert(v);
        g[v].insert(u); 
    }
    vector<ll> color(n + 1, -1); 
    ll ans = 0; 
    for (ll i = 1; i <= n; i++) {
        if (color[i] == -1) {
            color[i] = 0; 
            queue<ll> q; 
            q.push(i);
            vector<ll> cnt(2);
            bool tr = true; 
            while (!q.empty()) {
                ll u = q.front();
                cnt[color[u]]++;
                q.pop();
                for (auto v : g[u]) {
                    if (color[v] == -1) {
                        color[v] = 1 - color[u]; 
                        q.push(v);
                    }
                    else if (color[v] == color[u]) {
                        tr = false; 
                    }
                }
            }
            if(tr) ans += max(cnt[0], cnt[1]); 
        }
    }
    cout << ans << '\n'; 
}

signed main() {
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#else
    std::ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
#endif
    int test_cases;
    cin >> test_cases;
    while(test_cases--) {
        solve();
    }
}
