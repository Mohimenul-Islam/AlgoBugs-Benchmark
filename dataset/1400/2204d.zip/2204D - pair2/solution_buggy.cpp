#include <bits/stdc++.h>

#define ll  long long

#define yes cout << "YES";
#define no cout << "NO";
#define endl '\n'
#define fi first
#define gcd __gcd
#define free freopen('input.tyt','r',stdin);freopen('output.tyt','w'	,stdout);
#define yoy_bratan ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define se second
using namespace std;
vector<ll>vc[200099];
map<ll,ll>mp;
void dfs(ll x)
{
	mp[x]=1;
	for(auto to:vc[x])
	{
		if(mp[to]==0)
		dfs(to);
	}
}
void func(ll test)
{
	ll n,m;
	cin>>n>>m;
	ll a,b;
	for(int i=1;i<=m;i++)
	{
		cin>>a>>b;
		vc[a].push_back(b);
		vc[b].push_back(a);
	}
	ll o=0;
	for(int i=1;i<=n;i++)
	{
		if(mp[i]==0)
		{
			o++;
			dfs(i);
		}
		vc[i].clear();
	}
	cout<<o;
	mp.clear();
}
main()
{
    yoy_bratan
    long long otvet=1;
   cin>>otvet;
    for (int test = 1; test <= otvet; ++test)
    {
        func(test);
        cout<<endl;
    }
}
/*
╔══╗╔╗╔╗╔══╗╔╗╔╗╔══╗╔╗╔╗╔══╗
║╔╗║║║║║║╔╗║║║║║║╔╗║║║║║║╔╗║
║╚╝║║║║║║╚╝║║║║║║╚╝║║║║║║╚╝║
║╔╗║║╚╝║║╔╗║║╚╝║║╔╗║║╚╝║║╔╗║
║║║║╚╗╔╝║║║║╚╗╔╝║║║║╚╗╔╝║║║║
╚╝╚╝─╚╝─╚╝╚╝─╚╝─╚╝╚╝─╚╝─╚╝╚╝
*/
// (((f-3*e+3*d-c)-(2*e-d*6+c*6-2*b))-(d-3*c+3*b-a))
	// f-5*e+8*d-c*4-b+a	for(int i=1;i<=n-2;i++)