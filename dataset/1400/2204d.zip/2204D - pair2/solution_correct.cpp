#include <bits/stdc++.h>

#define ll  long long

#define yes cout << "YES";
#define no cout << "NO";
#define endl '\n'
#define fi first
#define gcd __gcd
#define free freopen('input.tyt','r',stdin);freopen('output.tyt','w'	,stdout);
#define yoy_bratan ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define se second
using namespace std;
void func(ll test)
{
	ll n,m;
	cin>>n>>m;
	ll a,b;
	ll c[n+4];
	for(int i=1;i<=n;i++)c[i]=-1;
	vector<ll>vc[n+19];
	for(int i=1;i<=m;i++)
	{
		cin>>a>>b;
		vc[a].push_back(b);
		vc[b].push_back(a);
	}
	ll ans=0;
	deque<ll>dq;
	for(int i=1;i<=n;i++)
	{
		if(c[i]!=-1)continue;
		deque<ll>dq;
		dq.push_back(i);
		c[i]=0;
		ll p[10];
		p[0]=0;
		p[1]=0;
		ll oo=0;
		bool ok=1;
		while(dq.size()>0)
		{
			ll o=dq.front();
			dq.pop_front();
			p[c[o]]++;
			
			for(auto to:vc[o])
			{
				if(c[o]==c[to])
				{
					ok=0;
				}
				else
				{
					if(c[to]==-1)
					{
						c[to]=c[o]^1;
						dq.push_back(to);
					}
				}
			}
		}
		// cout<<i<<endl;
		if(ok)
		{
			ans+=max(p[0],p[1]);
		}
	}
	cout<<ans;
}
main()
{
    yoy_bratan
    long long otvet=1;
   cin>>otvet;
    for (int test = 1; test <= otvet; ++test)
    {
        func(test);
        cout<<endl;
    }
}
/*
╔══╗╔╗╔╗╔══╗╔╗╔╗╔══╗╔╗╔╗╔══╗
║╔╗║║║║║║╔╗║║║║║║╔╗║║║║║║╔╗║
║╚╝║║║║║║╚╝║║║║║║╚╝║║║║║║╚╝║
║╔╗║║╚╝║║╔╗║║╚╝║║╔╗║║╚╝║║╔╗║
║║║║╚╗╔╝║║║║╚╗╔╝║║║║╚╗╔╝║║║║
╚╝╚╝─╚╝─╚╝╚╝─╚╝─╚╝╚╝─╚╝─╚╝╚╝
*/
// (((f-3*e+3*d-c)-(2*e-d*6+c*6-2*b))-(d-3*c+3*b-a))
	// f-5*e+8*d-c*4-b+a	for(int i=1;i<=n-2;i++)