#include <iostream>
#include <vector>
#include <queue>

int main() {
	int t;
	std::cin >> t;

	for (int i = 0; i < t; i++) {
		int n, m;
		std::cin >> n >> m;

		std::vector<std::vector<int>> graph(n, std::vector<int>());

		for (int e = 0; e < m; e++) {
			int u, v;
			std::cin >> u >> v;
			u--;
			v--;
			graph[u].emplace_back(v);
			graph[v].emplace_back(u);
		}

		std::vector<int> colors(n, -1);
		int invalid = 0;
		for (int i = 0; i < n; i++) {
			int curInvalid = 0;
			if (colors[i] != -1) {
				continue;
			}
			std::queue<int> q;
			q.push(i);
			colors[i] = 0;
			bool isBipartite = true;
			curInvalid++;

			while (!q.empty()) {
				int u = q.front();
				q.pop();

				for (const auto v : graph[u]) {
					if (colors[v] == -1) {
						colors[v] = colors[u] ^ 1;
						q.push(v);
						if (colors[v] == 0) {
							curInvalid++;
						}
					}
					else {
						isBipartite &= colors[u] != colors[v];
					}
				}
			}
			if (!isBipartite) {
				invalid += curInvalid;
			}
		}
		int res = 0;
		for (auto c : colors) {
			res += c == 0;
		}

		std::cout << res - invalid << std::endl;
	}

}