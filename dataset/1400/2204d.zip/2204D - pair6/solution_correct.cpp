#include <bits/stdc++.h>
using namespace std;
#define ALL(x) std::begin(x), std::end(x)
#define See(b, e, v) for(int i = b; i < e; i++)cerr<<v[i]<<" "; cerr<<endl;
#define ll long long
const int inf = 1e9;
const ll linf = 1e18;
const long long MOD = 998244353;
const int MAXN = 1e6 + 5;


void solve(){
    int n,m;
    cin>>n>>m;
    //col 标记颜色 
    vector<int>g[n + 1], col(n + 1,-1);
    int u,v;
    //u -- > v 建图
    for(int i = 1; i <= m; i++){
        cin>>u>>v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    int ans = 0;
    for (int i = 1; i <= n; i++) {
        if (col[i] != -1) continue;
        queue<int> q;
        q.push(i);
        col[i] = 0;
        int cnt[2] = {0, 0};  
        bool ok = true;       
        while (!q.empty()) {
            int now = q.front(); q.pop();
            cnt[col[now]]++;  
            for (int to : g[now]) {
                if (col[to] == col[now]) {
                    ok = false;  
                } 
                else if (col[to] == -1) {
                    col[to] = col[now] ^ 1;
                    q.push(to);
                }
            }
        }
        if(ok)ans += max(cnt[0], cnt[1]);
    }
    cout<<ans<<endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    //freopen("E:\\test.txt","r",stdin);

    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
        
    return 0;
}