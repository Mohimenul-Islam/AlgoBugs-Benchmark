#include <bits/stdc++.h>
using namespace std;
#define ALL(x) std::begin(x), std::end(x)
#define See(b, e, v) for(int i = b; i < e; i++)cerr<<v[i]<<" "; cerr<<endl;
#define ll long long
const int inf = 1e9;
const ll linf = 1e18;
const long long MOD = 998244353;
const int MAXN = 1e6 + 5;


void solve(){
    int n,m;
    cin>>n>>m;
    //col 标记颜色 
    vector<int>g[n + 1], col(n + 1,-1);
    int u,v;
    //u -- > v 建图
    for(int i = 1; i <= m; i++){
        cin>>u>>v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    // for(auto v : g){
    //     for(auto x : v){
    //         cout<<x<<" ";
    //     }
    //     cout<<endl;
    // }
    int ans = 0;
    for(int i = 1; i <= n; i++){
        if(col[i] != -1)continue;
        col[i] = 0;
        int size = 1;
        bool ok = true;
        queue<int>q;
        q.push(i);
        while(!q.empty()){
            int now = q.front();q.pop();
            for(auto &to : g[now]){
                if(col[to] == col[now]){
                    ok = false;
                }
                else if(col[to] == (col[now] ^ 1)){
                    continue;
                }
                else{
                    col[to] = col[now] ^ 1;
                    q.push(to);
                    size++;
                }
            }
        }
        if(ok)ans += (size + 1)/ 2;
        // if(size == 1)ans++;
    }
    // See(1,n,col);
    cout<<ans<<endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    //freopen("E:\\test.txt","r",stdin);

    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
        
    return 0;
}