#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;

int T;
int n,m;
vector<int> to[N];

int v[N];

int cnt[5],cv;

void cc(int x)
{
    v[x]=-1;
    for(int i=0;i<to[x].size();i++)
    {
        int y=to[x][i];
        if(v[y]!=-1)
            cc(y);
    }
}

void dfs(int x,int c)
{
    v[x]=c;
    cnt[c]++;
    for(int i=0;i<to[x].size();i++)
    {
        int y=to[x][i];
        if(v[y]==0)
            dfs(y,3-c);
        else if(v[y]==c)
        {
            cv=1;
            cc(y);
        }
    }
}

int main()
{
    cin>>T;
    while(T--)
    {
        cin>>n>>m;
        int p,q;
        for(int i=1;i<=n;i++)
        {
            to[i].clear();
            v[i]=0;
        }
        for(int i=1;i<=m;i++)
        {
            cin>>p>>q;
            to[p].push_back(q);
            to[q].push_back(p);
        }
        int ans=0;
        for(int i=1;i<=n;i++)
        {
            if(v[i]==0)
            {
                cnt[1]=cnt[2]=0,cv=0;
                dfs(i,1);
                if(cv==0)
                {
                    ans+=max(cnt[1],cnt[2]);
                }
            }
        }
        cout<<ans<<'\n';
    }
    return 0;
}