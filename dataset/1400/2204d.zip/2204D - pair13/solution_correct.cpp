#include <bits/stdc++.h>
using namespace std;

int flag=0;
int no_node=0;
int no_res=0;
void func(int node,vector<vector<int>>&adj,vector<int>&vis,int ct, int f){
    vis[node]=ct;
    no_node++;
    if(f==0) no_res++;
    for(auto it: adj[node]){
        if(!vis[it]){
            func(it,adj,vis,ct+1,(f+1)%2);
        }
        else{
            if((ct-vis[it]+1)%2==1){
                flag=1;
            }
        }
    }
}

void solve(){
    int n,m;
    cin>>n>>m;
    vector<vector<int>>adj(n+1);
    for(int i=0; i<m; i++){
        int u,v;
        cin>>u>>v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    vector<int>vis(n+1,0);
    int ans=0;
    for(int i=1; i<=n; i++){
        if(!vis[i]){
            flag=0;
            no_node=0;
            no_res=0;
            func(i,adj,vis,1,0);
            // cout<<no_node<<" "<<i<<" "<<flag<<endl;
            if(flag==0) ans+=max(no_res,no_node-no_res);
        }
    }
    cout<<ans;
}

int main() {
	// your code goes here
	int t;
	cin>>t;
	while(t--){
	    solve();
	    cout<<endl;
	}

}
