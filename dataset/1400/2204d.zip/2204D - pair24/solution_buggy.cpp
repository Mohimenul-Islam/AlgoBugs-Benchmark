#include "bits/stdc++.h"
using namespace std;
#define int long long

const int N = 3e5+5;
vector<int> g[N];
int c[N];
array<int, 2> cnt;
bool ok = true;

void color(int u, int C){
    cnt[C]++;
    c[u] = C;
    for(int to: g[u]){
        if(!c[to]) color(to, -C);
        else if(c[u] == c[to]) ok = false;
    }
}

void solve(){
    int n, m; cin >> n >> m;
    for(int i=1; i<=n; i++) g[i].clear(), c[i] = 0;
    for(int i=1; i<=m; i++) {
        int x, y; cin >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    
    int ans = 0;
    for(int i=1; i<=n; i++) {
        if(c[i]) continue;
        ok = true, cnt[0] = cnt[1] = 0;
        color(i, 1);
        ans += max(cnt[0], cnt[1]) * ok;
    }
    cout << ans << endl;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    #ifndef ONLINE_JUDGE
    freopen("input", "r", stdin);
    freopen("output", "w", stdout);
    #endif

    int t = 1; cin >> t;
    while(t--) solve();
}