#include<bits/stdc++.h>
#if __has_include("tool/local.hpp")
#include "tool/local.hpp"
#undef assert
#define assert(_Expression) LocalAssert(_Expression)
#else
#define Testcases(T) while(T--) solve();
    #ifndef ONLINE_JUDGE
    #define listen(...) freopen("data.in","r",stdin),freopen("data.out","w",stdout);
    #else
    #define listen(...)
    #endif
#endif
#define inf 4000000000000000000LL
#define endl '\n'
#define x first
#define y second
#define MOD 1000000007
#define mod 998244353
#define int long long
// #define lc(x) tr[x].ch[0]
// #define rc(x) tr[x].ch[1]
#define lc u<<1
#define rc u<<1|1

using namespace std;
template<typename T> ostream& operator<<(ostream& out, vector<T>& a) {for(auto &x : a) out << x << ' '; return out;};
using pii=pair<int,int>;
using ll=long long;

void debug() {cout << endl;}

template<typename T, typename... Args>
void debug(T first, Args... args) {
    std::cout << first << " ";
    debug(args...);
}
int T=1;

struct node{
    int l,r;
};

void solve()
{
    int n,m=0;
    int res=0;
    string s;
    cin>>n>>m;
    vector<vector<int>> G(n+1);
    vector<int> color(n+1);
    for(int i=1;i<=m;i++)
    {
        int a,b;
        cin>>a>>b;
        G[a].push_back(b);
        G[b].push_back(a);
    }
    
    for(int i=1;i<=n;i++){
        if(!color[i])
        {
            int cnt1=0,cnt2=0;
            bool f=0;
            auto dfs=[&](auto &&self,int u,int val)->void{
                color[u]=val;
                if(val==1) cnt1++;
                else cnt2++;
                for(int v:G[u])
                {
                    if(!color[v])
                    {
                        self(self,v,3-val); 
                    }
                    else if(color[v]==val)  f=1;
                }
            };
            dfs(dfs,i,1);
            if(!f) res+=max(cnt1,cnt2);
        }
    }
    cout<<res;
    
}

signed main()
{
    ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
    listen(_TIMER,_FILE,_CHECKER);
    cin>>T;
    //cin.ignore();
	while(T--) solve(),cout<<endl;
	return 0;
}