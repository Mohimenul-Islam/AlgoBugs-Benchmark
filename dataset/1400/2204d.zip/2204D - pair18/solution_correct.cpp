#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <map>
#include <stack>
#include <set>
#include <queue>
#include <utility>
#include <numeric>

using namespace std;
typedef long long ll;

bool is_alternating = true;
int count_all = 0;
int count_st = 0;

void dfs(int v, int last, vector<vector<int> >& a, vector<int>& used) {
    used[v] = -last;
    if (used[v] == 1) ++count_st;
    count_all++;
    for (auto& to : a[v]) {
        if (!used[to]) {
            dfs(to, -last, a, used);
        } else if (used[to] == -last) {
            is_alternating = false;
        }
    }
}

void solve() {
    int n, m; cin >> n >> m;
    vector<vector<int> > a(n + 1, vector<int>());
    for (int i = 0; i < m; ++i) {
        int index; cin >> index;
        int vertex; cin >> vertex;
        a[index].push_back(vertex);
        a[vertex].push_back(index);
    }
    vector<int> used(n + 1, 0);
    int answer = 0;
    for (int i = 1; i < n + 1; ++i) {
        if (!used[i]) {
            dfs(i, -1, a, used);
            if (is_alternating) {
                answer += max(count_st, count_all - count_st);
            }
            count_all = 0;
            count_st = 0;
            is_alternating = 1;
        }
    } 
    cout << answer << "\n";
}

int main() {
    int t; cin >> t;
    while (t--) {
        solve();
    } 
}
