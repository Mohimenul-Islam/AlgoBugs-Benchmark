#include <bits/stdc++.h>
// #include <ext/pb_ds/assoc_container.hpp>
// #include <ext/pb_ds/tree_policy.hpp>
#include <climits>
#include <random>
using namespace std;
// using namespace __gnu_pbds;
#define ordered_set tree<ll, null_type, less<ll>, rb_tree_tag, tree_order_statistics_node_update>
typedef long long ll;
typedef unsigned long long ull;
typedef long double lld;
#define int long long 
#define double long double
#define INT_MAX LLONG_MAX
#define INT_MIN LLONG_MIN
#define endl '\n'
#define vin(a) for (int i = 0; i < (a).size(); i++) cin >> a[i];
#define vout(a) for (int i = 0; i < a.size(); i++) cout << a[i] << ' '; cout << endl;
#define vpin(a) for (int i = 0; i < (a).size(); i++) cin >> a[i].first; for (int i = 0; i < (a).size(); i++) cin >> a[i].second;
#define vpinr(a) for (int i = 0; i < (a).size(); i++) cin >> a[i].second; for (int i = 0; i < (a).size(); i++) cin >> a[i].first;
#define vpin2(a) for (int i = 0; i < (a).size(); i++) cin >> a[i].first >> a[i].second;
#define vpin2r(a) for (int i = 0; i < (a).size(); i++) cin >> a[i].second >> a[i].first;
#define vpout(a) for (int i = 0; i < a.size(); i++) cout << a[i].first << ' ' << a[i].second << endl; cout << endl;
#define cout(x) cout << fixed << setprecision(20) << x << endl
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).begin(), (x).end(), greater<int>()
#define r(x) { cout << x << endl; return; }
#define sz(x) ((int)(x).size())
#define trav(a, x) for (auto &a : x)
#define fsh(x) { cout << x << endl; cout.flush(); }
#define f(a, b, i) for (int i = a; i < b; i++)
#define wf(a, b, i) for (int i = a; i <= b; i++)
#define rf(a, b, i) for (int i = a; i >= b; i--)
#define line cout << endl;
#define vi vector<ll>
#define vb vector<bool>
#define vvi vector<vi>
#define vvb vector<vb>
#define vvp vector<vector<pll> >
#define pll pair<ll, ll>
#define vp vector<pll>
#define mll map<ll,ll>
#define mci map<char,ll>
#define Matrix array
#define pb push_back
#define ppb pop_back
#define mp make_pair
#define ff first
#define ss second
#define lb lower_bound
#define ub upper_bound
#define sumV(a) accumulate(all(a), 0LL)
#define minV(a) min_element(all(a))
#define maxV(a) max_element(all(a))
#define done(i) (i + 1 == n ? "\n" : " ")
#define sumlr(l,r) (((l)+(r))*((r)-(l)+1))/2
#define gr(x) greater<x>
#ifdef ONLINE_JUDGE
#define debug(...)
#else
#define debug(...) cerr << "[" << #__VA_ARGS__ << "] : ", _print(__VA_ARGS__), cerr << endl;
#endif
void _print(ll t) {cerr << t;}
void _print(string t) {cerr << t;}
void _print(char t) {cerr << t;}
void _print(double t) {cerr << t;}
void _print(ull t) {cerr << t;}
void _print() {}
template <typename T, typename... Args> void _print(const T& t, const Args&... args) {cerr << t; if (sizeof...(args)) cerr << ", "; _print(args...);}
template <class T, class V> void _print(pair <T, V> p);
template <class T> void _print(vector <T> v);
template <class T> void _print(set <T> v);
template <class T> void _print(multiset <T> v);
template <class T, class V> void _print(pair <T, V> p) {cerr << "{"; _print(p.ff); cerr << ","; _print(p.ss); cerr << "}";}
template <class T> void _print(vector <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(set <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(multiset <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T, class V> void _print(map <T, V> v) {cerr << "[ "; for (auto i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T, class V> void _print(vector<pair<T, V> >v) {cerr << "[ "; for (auto p : v) { _print(p); cerr << " ";}cerr << "]";}
template <class T> void _print(priority_queue<T, vector<T>, greater<T> > pq){vector<T> v;while (!pq.empty()) {v.push_back(pq.top());pq.pop();}_print(v);}
template <class T> void _print(priority_queue<T> pq) {vector<T> v;while (!pq.empty()) {v.push_back(pq.top());pq.pop();}_print(v);}
template <class T> void _print(stack<T> s) {vector<T> v;while (!s.empty()) {v.push_back(s.top());s.pop();}_print(v);}
template <class T> void _print(queue<T> q) {vector<T> v;while (!q.empty()) {v.push_back(q.front());q.pop();}_print(v);}
template <class T> void _print(deque<T> q) {vector<T> v;while (!q.empty()) {v.push_back(q.front());q.pop_front();}_print(v);}
template <class T> void _print(list<T> l) {vector<T> v;for (auto x : l) {v.push_back(x);}_print(v);}
void _printTreeDebug(int u, int parent, vector<vector<int>> &adj, string prefix = "", bool isLast = true) {cerr << prefix; if (parent != -1) {cerr << (isLast ? "??? " : "??? ");} cerr << u << "\n"; vector<int> children; for (int v : adj[u]) {if (v != parent) children.push_back(v);} for (int i = 0; i < (int)children.size(); i++) {int v = children[i]; bool last = (i == (int)children.size() - 1); _printTreeDebug(v, u, adj, prefix + (parent == -1 ? "" : (isLast ? "    " : "?   ")), last);}}
void debugTree(vector<vector<int>> &adj){if(adj.empty()){cerr << "[]";return;}cerr << "\n";_printTreeDebug(0, -1, adj);}
const int NEG_INF=-1e18;
const int MOD = 998244353;
const int INF=1e18;
const int M = 1e9 + 7;
const double Eps=1e-9;
const double PI = acos(-1.0);
const int G = 3;
const int N = 2e5 + 10;
vi sieve(int n) {vb p(n + 1, true); p[0] = p[1] = false;for (int i = 2; i * i <= n; i++) if (p[i]) for (int j = i * i; j <= n; j += i) p[j] = false;vi primes; for (int i = 2; i <= n; i++) if (p[i]) primes.pb(i); return primes;}
vi segmentedSieve(int L, int R) {int lim = sqrt(R) + 1; vi basePrimes = sieve(lim); vb mark(R - L + 1, true);for (int i : basePrimes) { ll start = max(1LL * i * i, ((L + i - 1) / i) * 1LL * i); for (ll j = start; j <= R; j += i) mark[j - L] = false; }if (L == 1) mark[0] = false; vi primes; for (int i = 0; i < mark.size(); i++) if (mark[i]) primes.pb(L + i); return primes;}
vb sieveBool(int n)	{vb p(n + 1, true);p[0] = p[1] = false;for (int i = 2; i * i <= n; i++) if (p[i]) for (int j = i * i; j <= n; j += i) p[j] = false;return p;}
vb segmentedSieveBool(int L,int R){int lim=sqrt(R)+1;vb mark(R-L+1,true),prime=sieveBool(lim);for(int i=2;i<=lim;i++)if(prime[i]){ll start=max(1LL*i*i,((L+i-1)/i)*1LL*i);for(ll j=start;j<=R;j+=i)mark[j-L]=false;}if(L==1)mark[0]=false;return mark;}
vi computeSPF(int n) {vi spf(n);for (int i = 1; i < n; i++) spf[i] = i;for (int i = 2; i * i < n; i++)if (spf[i] == i)for (int j = i * i; j < n; j += i)if (spf[j] == j) spf[j] = i; return spf;}
vi getDivisors(ll n) {vi d;for(ll i=1;i*i<=n;i++)if(n%i==0){d.pb(i);if(i!=n/i)d.pb(n/i);}sort(all(d));return d;}
vp primeFactors(ll n){ vp v; ll sqrt_n = sqrtl(n); for (ll j = 2; j <= sqrt_n; j++){ ll cnt = 0; while(n%j == 0) n /= j, cnt++; if(cnt)v.pb(mp(j,cnt)); } if(n!=1) v.pb(mp(n,1)); return v;}
vp factorizeUsingSpf(int n,vi &spf) {vector<pair<int,int>> factors;while (n > 1) {int p = spf[n], cnt = 0;while (n % p == 0) { n /= p;cnt++;}factors.push_back({p, cnt});}return factors;}
int phiUsingSpf(int n,vi spf) {auto factors=factorizeUsingSpf(n,spf);int result = n;for (auto &f : factors) {int p = f.first;result -= result / p;}return result;}
vi computeTotient(int N) {vi phi(N + 1);for (int i = 0; i <= N; i++) phi[i] = i;for (int i = 2; i <= N; i++) {if (phi[i] == i) {for (int j = i; j <= N; j += i) {phi[j] -= phi[j] / i;}}}return phi;}
ll gcd(ll a, ll b){if(b == 0) return a; return gcd(b, a%b);}
ll lcm(ll a, ll b){return a*b/gcd(a,b);}
ll fastExpo(ll x, ll y, ll m){ ll res = 1; x = x % m; while (y > 0){ if (y & 1) res = (res * x) % m; y = y>>1; x = (x * x) % m; } return res; }
ll mod(ll x,ll m){ return ((x % m + m) % m); }
ll addMod(ll a, ll b, ll m){ return mod(mod(a, m) + mod(b, m), m); }
ll mulMod(ll a, ll b, ll m){ return mod(mod(a, m) * mod(b, m), m); }
ll subMod(ll a, ll b, ll m){ return mod(mod(a, m) - mod(b, m), m); }
ll divMod(ll a, ll b, ll m){ return mod(mulMod(a, fastExpo(b, m - 2, m), m), m); }
vi fact(int n, int m){vi fact(n+1,1);for(int i=2;i<=n;i++) fact[i]=mulMod(fact[i-1],i,m);return fact;}
vi invFact(int n, int m){vi f=fact(n,m);vi inv(n+1);inv[n]=fastExpo(f[n],m-2,m);for(int i=n-1;i>=0;i--) inv[i]=mulMod(inv[i+1],i+1,m);return inv;}
int nCr(int n, int r, vi &fact, vi &invFact, int m){if (n<r||r<0) return 0;if (n==r||r==0) return 1;return mulMod(fact[n], mulMod(invFact[r], invFact[n-r], m), m);}
vp countArr(vi &arr, ll n){ vp v1; f(0,n,i){ ll cnt = 1; while(i < n-1 && arr[i] == arr[i+1]){ cnt++, i++; } v1.pb(mp(arr[i], cnt)); } if((n > 1 && arr[n-1] != arr[n-2]) || n == 1) v1.pb(mp(arr[n-1], 1)); return v1;}
vi factors(ll n){ vi fac; for (ll i = 1; i * i <= n; i++){ if (n % i == 0){ fac.pb(i); if (i * i != n)fac.pb(n / i); } } return fac; }
ll maxPow2(ll n){n |= n >> 1; n |= n >> 2; n |= n >> 4; n |= n >> 8; n |= n >> 16; return (n + 1);}
vvi merge(vvi& a) {if (a.empty()) return {}; sort(all(a));vvi ans;ans.pb(a[0]);f(1,sz(a),i)if (ans.back()[1]>=a[i][0]) ans.back()[1] = max(ans.back()[1], a[i][1]);else ans.push_back(a[i]);return ans;}
vvi intersection(vvi& a) {if (a.empty()) return a;vvi ans;int s=a[0][0],e=a[0][1];f(0,sz(a),i){s=max(s,a[i][0]);e=min(e,a[i][1]);if(s>e)return ans;}vi temp(2);temp[0]=s;temp[1]=e;ans.pb(temp);return ans;}
mll freq(vi v) {mll freq;for (auto x : v) freq[x]++;return freq;}
mll index(vi v) {mll ind;for (int i=0;i<v.size();i++) ind[v[i]]=i;return ind;}
mci S_freq(const string &s) {mci freq;for (auto x : s) freq[x]++;return freq;}
vi removeDuplicates(vi &a) {unordered_set<int> seen;vi result;result.reserve(a.size()); for (int x : a) {if (seen.insert(x).second) result.push_back(x);}return result;}
vi prefix(const vi &arr){vi b(sz(arr)+1, 0);f(1, sz(arr)+1, i) b[i] = b[i-1] + arr[i-1];return b;}
vi prefixXor(const vi &arr) {vi b(sz(arr)+1, 0);f(1, sz(arr)+1, i) b[i] = b[i-1] ^ arr[i-1];return b;}
vi suffix(const vi &arr){ vi b(sz(arr)+1, 0);rf(sz(arr)-1,0,i) b[i] = b[i+1] + arr[i];return b;}
vi getSetBits(int n) {vi v;int i = 0;while(n>0){if(n&1){v.push_back(i);}n >>= 1;i++;}return v;}
void szSubTree(int u,int p,vi &siz,const vvi &adj) {siz[u] = 1;for(int v:adj[u]){if (v==p) continue;szSubTree(v, u, siz, adj);siz[u] += siz[v];}}
void depth(int u,int p,int d,vi &dep,const vvi &adj) {dep[u]=d;for(int v:adj[u]){if (v==p)continue;depth(v, u, d+1, dep, adj);}}
vi degree(const vvi &adj) {vi deg(sz(adj), 0);f(0, sz(adj), i) deg[i] = sz(adj[i]); return deg;}
vvi adjList(int n,int m){vvi adj(n);f(0,m,i){int u,v;cin>>u>>v;u--,v--;adj[u].pb(v);adj[v].pb(u);}return adj;}
vvi adjListd(int n,int m){vvi adj(n);f(0,m,i){int u,v;cin>>u>>v;u--,v--;adj[u].pb(v);}return adj;}
vvp adjListpd(int n,int m){vvp adj(n);f(0,m,i){int u,v,w;cin>>u>>v>>w;u--,v--;adj[u].pb(mp(v,w));}return adj;}
vvp adjListpu(int n,int m){vvp adj(n);f(0,m,i){int u,v,w;cin>>u>>v>>w;u--,v--;adj[u].pb(mp(v,w));adj[v].pb(mp(u,w));}return adj;}
pll intersection(pll a, pll b) {int s = max(a.ff, b.ff);int e = min(a.ss, b.ss);if (s <= e) return mp(s, e);return mp(-1, -1);}
pll uni(pll a, pll b) {if (max(a.ff, b.ff) <= min(a.ss, b.ss))return mp(min(a.ff, b.ff), max(a.ss, b.ss));return mp(-1, -1);}
vi dijkstra(int n,vvp&adj,int src){vi dist(n,INF);priority_queue<pll,vp,gr(pll)>pq;dist[src]=0;pq.push(mp(0,src));while(!pq.empty()){auto[d,curr]=pq.top();pq.pop();if(d>dist[curr])continue;for(auto x:adj[curr]){int v=x.ff,w=x.ss;if(dist[v]>dist[curr]+w){dist[v]=dist[curr]+w;pq.push(mp(dist[v],v));}}}return dist;}
vvi floydwarshell(int n, vvp &adj) {vvi d(n, vi(n, INF));f(0, n, i) d[i][i] = 0;f(0, n, u) trav(e, adj[u]) d[u][e.ff] = min(d[u][e.ff], e.ss);f(0, n, k)f(0, n, i)if (d[i][k] < INF)f(0, n, j)if (d[k][j] < INF)d[i][j] = min(d[i][j], d[i][k] + d[k][j]);return d;}
vi bellmanFord(int n, vvp &adj, int src) {vi dist(n, INF); dist[src] = 0;f(0, n-1, i) f(0, n, u) trav(e, adj[u]) {int v = e.ff, w = e.ss;if (dist[u] != INF && dist[v] > dist[u] + w)dist[v] = dist[u] + w;}f(0, n, u) trav(e, adj[u]) {int v = e.ff, w = e.ss;if (dist[u] != INF && dist[v] > dist[u] + w)return vi();}return dist;}
int minXorSumBestX(int n){int x=0;for(int b=0;(1LL<<b)<=n*2;b++){int cycle=1LL<<(b+1);int ones=((n+1)/cycle)*(1LL<<b)+std::max(0LL,(n+1)%cycle-(1LL<<b));int zeros=n-ones;if(ones>zeros) x|=(1LL<<b);}if(x<1||x>n) return 1; return x;}
int msb_diff(int a, int b=0) { return 64 - __builtin_clzll(a ^ b); }
int lsb_diff(int a, int b=0) { return __builtin_ffsll(a ^ b);}
bool getBit(int x, int k) {return (x >> k) & 1;}
int setBit(int x, int k) {return x | (1LL << k);}
int clearBit(int x, int k) {return x & ~(1LL << k);}
int toggleBit(int x, int k) {return x ^ (1LL << k);}
bool isPowerOfTwo(int x) {return x && !(x & (x - 1));}
int noOfSetBit(int x) {return __builtin_popcountll(x);}
bool hasCycleUndirected(int n, const vvi &adj) {vb visited(n, false);function<bool(int, int)> dfs = [&](int u, int parent) {visited[u] = true;for (int v : adj[u]) {if (!visited[v]) {if (dfs(v, u)) return true;} else if (v != parent) {return true;}}return false;};for (int i = 0; i < n; i++) if (!visited[i] && dfs(i, -1)) return true;return false;}
bool hasCycleDirected(int n, const vvi &adj) {vb visited(n, false), recStack(n, false);function<bool(int)> dfs = [&](int u) {visited[u] = true;recStack[u] = true;for (int v : adj[u]) {if (!visited[v]) {if (dfs(v)) return true;} else if (recStack[v]) {return true;}}recStack[u] = false;return false;};for (int i = 0; i < n; i++) if (!visited[i] && dfs(i)) return true;return false;}
bool isBipartite(int n, const vvi &adj) {vi color(n, -1);function<bool(int, int)> bfs = [&](int start, int c) {queue<int> q;q.push(start);color[start] = c;while (!q.empty()) {int u = q.front();q.pop();for (int v : adj[u]) {if (color[v] == -1) {color[v] = 1 - color[u];q.push(v);} else if (color[v] == color[u]) {return false;}}}return true;};for (int i = 0; i < n; i++) if (color[i] == -1 && !bfs(i, 0)) return false;return true;}
string numToBinary(int n) {if (n == 0) return "0";string binary = "";while (n > 0) {binary = char((n % 2) + '0') + binary;n /= 2;}return binary;}
vp queries(int q) {vp qu(q);f(0, q, i) cin >> qu[i].first >> qu[i].second;return qu;}
int stringHash(string const& s,int p,int m) { int hash_value = 0; int p_pow = 1; for (char c : s) { hash_value = (hash_value + (c - 'a' + 1) * p_pow) % m;p_pow = (p_pow * p) % m;}return hash_value;}
vi prefix_function(string s) {int n = (int)s.length();vi pi(n);f(0,n,i){int j = pi[i-1];while (j > 0 && s[i] != s[j])j = pi[j-1];if (s[i] == s[j])j++; pi[i] = j;}return pi;}
int getRandom(int l, int r) {static random_device rd;static mt19937 gen(rd());uniform_int_distribution<int> dist(l, r);return dist(gen);}
vi generateZobrist(int n) {vi z(n);f(0,n,i){z[i] = getRandom(1LL, (1LL << 62));}return z;}

void solve(){
    int n , k;
    cin>>n>> k;
    vector<vector<int>> adj(n+1);
    
    for(int i = 0; i < k; i++){
        int l , r;
        cin >> l >> r;
        adj[l].push_back(r);
        adj[r].push_back(l);
    }

    vector<int> col(n+1, -1);
    vector<int> vis(n+1, false);
    bool is_bp = true;
    function<bool(int,int,int&,int&)> bi_part = [&](int node, int c, int &c0, int &c1){
        vis[node] = true;
        col[node] = c;
        if(c == 0) c0++;
        else c1++;
        for(auto &nbr : adj[node]){
            if(!vis[nbr]){
                if(!bi_part(nbr, 1 - c, c0, c1)){
                    is_bp = false;
                }
            }
            else{
                if(col[nbr] == col[node]) {
                    is_bp = false;
                }
            }
        }
        return true;
    };
    
    int ans = 0;
    for(int i = 1; i <= n; i++){
        bool ok = true;
        if(!vis[i]){
            int c0 = 0, c1 = 0;
            bi_part(i, 0, c0, c1);
            if(is_bp){
                ans += max(c0, c1);
            }
        }
    
    }
    cout<<ans<<endl;
}

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
	// your code goes here
	int t;
	cin>>t;
        while(t--){
          solve();
        }
}