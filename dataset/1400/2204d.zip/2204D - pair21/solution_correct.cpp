#include <bits/stdc++.h>
using namespace std;
#define int long long
const int mod = 998244353;
typedef pair<int, int> PII;
const int N = 2e5 + 10, M = 2 * N, INF = 1e18;
int idx, e[M], h[N], ne[M], d[N], cnt1, cnt2;
bool st[N], f;
void add(int a, int b)
{
   e[idx] = b, ne[idx] = h[a], h[a] = idx++;
}
int dfs(int u, int t)
{
   st[u] = 1;
   d[u] = t;
   if (t)
      cnt1++;
   else
      cnt2++;
   int res = t;
   for (int i = h[u]; ~i; i = ne[i])
   {
      int j = e[i];
      // if (j != fa)
      //    cout << u << " " << j << "\n";
      if (!st[j])
      {
         res += dfs(j, t ^ 1);
      }
      else if (d[j] == d[u])
      {
         // cout << u << " " << j << "\n";
         f = false;
      }
   }
   return res;
}
void solve()
{
   int n, m;
   cin >> n >> m;
   for (int i = 1; i <= n; i++)
      h[i] = -1, st[i] = 0, d[i] = -1;
   idx = 0;
   while (m--)
   {
      int a, b;
      cin >> a >> b;
      add(a, b);
      add(b, a);
   }
   int res = 0;
   for (int i = 1; i <= n; i++)
      if (!st[i])
      {
         f = 1;
         cnt1 = 0, cnt2 = 0;
         int t = dfs(i, 1);
         if (f)
         {
            res += max(cnt1, cnt2);
         }
      }
   cout << res << "\n";
}
signed main()
{
   ios::sync_with_stdio(0);
   cin.tie(0);
#ifndef ONLINE_JUDGE
   freopen("in.txt", "r", stdin);
   freopen("out.txt", "w", stdout);
#endif
   int T = 1;
   cin >> T;
   while (T--)
   {
      solve();
   }
   return 0;
}