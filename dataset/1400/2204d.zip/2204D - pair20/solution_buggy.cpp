#include <bits/stdc++.h>
#include <iostream>
using namespace std;
 
#define int long long

pair<int,bool> dfs(int curr, vector<vector<int>>& adj, vector<int>& visited, int color){
    if(visited[curr] != -1){
        return {0,true};
    }
    
    visited[curr] = color;
    int cnt = 1;
    int sub_color = color ^ 1;
    bool poss = true;
    
    for(auto nd : adj[curr]){
        if(visited[nd] == -1){
            auto res = dfs(nd,adj,visited,sub_color);
            cnt += res.first;
            poss = poss & res.second;
        }else if(visited[nd] != sub_color){
            poss = false;
        }
    } 
    
    return {cnt,poss};
}


void solve(){
    int n,m;
    cin>>n>>m;
    
    vector<vector<int>> adj(n+1);
    
    for(int i=0;i<m;i++){
        int a,b;
        cin>>a>>b;
        
        adj[a].push_back(b);
        adj[b].push_back(a);
    }
    
    
    vector<int> visited(n+1,-1);
    
    long long ans = 0;
    for(int i=1;i<=n;i++){
        if(visited[i] == -1){
            auto res = dfs(i,adj,visited,0);
            if(res.second == true){
                int num = res.first;
                
                if(num%2){
                    ans += ceil(num/2.0);
                }else{
                    ans += num/2;
                }
                
            }
        }
        
    }
    
    cout<<ans<<endl;
    
    return;
}
 
signed main()
{
    int t;
    cin>>t;
    
    while(t--){
        solve();
    }
 
    return 0;
}