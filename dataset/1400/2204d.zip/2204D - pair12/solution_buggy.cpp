#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define int long long int
#define pb push_back
#define yes "YES\n"
#define no "NO\n"
#define speed std::ios::sync_with_stdio(false), cin.tie(NULL), cout.tie(NULL)
#define endl "\n"
#define ff first

#define ss second
#define all(v) (v).begin(),(v).end()
#define bsort(v) sort(all(v),greater<int>())
typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> pbds; 
// find_by_order, order_of_key
const int MOD = 1e9+7;
const int MOD1=998244353;
 
#define lll uint64_t
struct my_hsh {
 
    static lll hsh_func(lll x){
        x += 0x9e3779b97f4a7c15;
        x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;
        x = (x ^ (x >> 27)) * 0x94d049bb133111eb;
        return x ^ (x >> 31);
    }
 
    size_t operator()(lll x) const {
        static const lll random = chrono::steady_clock::now().time_since_epoch().count();
        return hsh_func(x+random);
    }
};
/*----------------------------------------------------------------------------------


      ______     _   __
     /  __  \   | | / /
     | |__| |   | |/ / 
     |  __  |   |    \ 
     | |  \ \   | |\  \
     |_|   \_\  \_| \_/ 
   



 ----------------------------------------------------------------------------------*/
  
/*----------------------------------------------------------------------------------*/
void dfs(int u,vector<int>&vis,vector<int>&dis,vector<vector<int>>&g,int &od,int &ev,int &f) {
    vis[u]=1;
    for(auto v:g[u]) {
        if(!vis[v]) {
            dis[v]=dis[u]+1;
            if(dis[v]%2==0) ev++;
            else od++;
            dfs(v,vis,dis,g,od,ev,f);
        }
        else {
            if(dis[v]%2==dis[u]%2) {
                f=1;
                return;
            }
        }
    }
}

void solve() {
    int n;
    cin>>n;
    int m;
    cin>>m;
    vector<vector<int>>g(n);
    for (int i = 0; i < m; ++i)
    {
        int u,v;
        cin>>u>>v;
        u--;v--;
        g[u].pb(v);
        g[v].pb(u);
        /* code */
    }
    vector<int>dis(n,0);
    vector<int>vis(n,0);
    int ans=0;
    for (int i = 0; i < n; ++i)
    {
        if(!vis[i]) {
            int od=0,ev=1,f=0;
            dfs(i,vis,dis,g,od,ev,f);
            if(f!=1) {
                ans+=max(od,ev);
            }
        }
        /* code */
    }
    cout<<ans;
}




/*----------------------------------------------------------------------------------*/




int32_t main() {
    speed;
    int t=1;
    cin >> t;
    while (t--) {
        solve();
        cout << "\n";
    }
    return 0;
}