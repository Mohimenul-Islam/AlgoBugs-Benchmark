#include<bits/stdc++.h>
using namespace std;
#define ll long long
const ll N=3e5+100;
ll mod = 998244353;
ll fac[N],b[N];
// ll qpow(ll x,ll b) {
//     ll res = 1;
//     while (b) {
//         if (b & 1) {
//             res = res * x %mod;
//         }
//         x = x * x %mod;
//         b >>= 1;
//     }
//     return res ;
// }
// void init(ll n1) {
//     fac[0] = 1;
//     for (int i=1;i<=n1;i++) {
//         fac[i] = i * fac[i-1] % mod;
//     }
// }
// ll inv(ll n1) {
//     return qpow(n1,mod-2)%mod;
// }
// ll getc(ll nn,ll kk) {
//     return ((fac[nn] * inv(fac[kk]))%mod * inv(fac[nn-kk])) %mod;
// }
ll p[N],sz[N],dist[N],col[N],val[N];
int find(int x) {
    if (p[x] != x) {
        int f = p[x];
        p[x] = find(p[x]);
        col[x] ^= col[f];
    }
    return p[x];
}
vector<ll> g[N];
ll vis[N];
int f = 0,cnt0 = 0,cnt1 = 0;
void dfs(ll u,ll fa) {
    vis[u] = 1;
    if (col[u] == 0) cnt0++;
    else cnt1++;
    for (auto &v:g[u]) {
        if (v == fa) continue;
        if (col[v] == col[u]) {
            f = 1;
            continue;
        }
        if (col[v] != -1) continue;
        col[v] = col[u] ^ 1;
        dfs(v,u);
    }
}
void solve() {
    ll n,m;cin>>n>>m;
    for (int i=0;i<=n+1;i++) g[i].clear(),vis[i] = 0,col[i] = -1;
    for (int i=1;i<=m;i++) {
        int u,v;cin>>u>>v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    ll ans = 0;
    for (int i=1;i<=n;i++) {
        if (!vis[i]) {
            f = 0,cnt0 = 0,cnt1 = 0;
            col[i] = 0;
            dfs(i,-1);
            //cout<<f<<" "<<cnt0<<" "<<cnt1<<'\n';
            if (!f) ans = ans + max(cnt0,cnt1);
        }
    }
    cout<<ans<<'\n';
}
int main() {
    ios::sync_with_stdio(0),cin.tie(0); cout.tie(0);
    int t ;cin>>t;
    while(t--) solve();
    return 0;
}