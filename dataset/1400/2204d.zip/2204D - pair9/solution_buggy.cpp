#include <bits/stdc++.h>
using namespace std;

const int MAXN = 2e5 + 5;
vector<int> a[MAXN];
int t[MAXN], d[MAXN];
int ok;
long long res, black, white;
// Sử dụng map để giữ logic f[u][v] mà không bị tràn bộ nhớ nếu n lớn
map<pair<int, int>, int> f;

struct Node {
    int number = 0;
    int value = 0;
};

void dfs(int u, int x) {
    // cout << u << " " << x << "\n";
    t[u] = 1;

    if (d[u] == 0) {
        d[u] = x;
        black += (x == -1 ? 1 : 0);
        white += (x == 1 ? 1 : 0);
    }
    else if (d[u] != x) {
        ok = 0;
    }

    for (int i = 0; i < a[u].size(); i++) {
        int v = a[u][i];
        if (f[{u, v}] == 0 && f[{v, u}] == 0) {
                f[{u, v}] = 1;
                f[{v, u}] = 1;
                dfs(v, 0 - d[u]);
        }
    }
}

void solve() {
    int n, m;
    cin >> n >> m;

    // Reset dữ liệu cho mỗi test case
    res = 0;
    f.clear();
    for (int i = 1; i <= n; i++) {
        a[i].clear();
        t[i] = 0;
        d[i] = 0;
    }

    int u, v;
    for (int i = 0; i < m; i++) {
        cin >> u >> v;
        a[u].push_back(v);
        a[v].push_back(u);
        f[{u, v}] = 0;
        f[{v, u}] = 0;
    }

    for (int i = 1; i <= n; i++) {
        if (t[i] == 0) {
            ok = 1;
            black = 0;
            white = 0;
            dfs(i, 1);
            if (ok == 1) {
                res += max(black, white);
            }
        }
    }

    cout << res << "\n";
}

int main() {
    #ifndef ONLINE_JUDGE
    freopen("inp.txt", "r", stdin);
    #endif

    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int test_cases;
    cin >> test_cases;

    while (test_cases--) {
        solve();
    }

    return 0;
}
