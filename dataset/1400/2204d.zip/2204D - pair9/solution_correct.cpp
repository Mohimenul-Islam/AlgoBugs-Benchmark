#include <bits/stdc++.h>
using namespace std;

const int MAXN = 2e5 + 5;
vector<int> a[MAXN];
int d[MAXN];
int ok;
int res, black, white;

struct Node {
    int number = 0;
    int value = 0;
};

void dfs(int u, int x) {

    d[u] = x;
    black += (x == -1 ? 1 : 0);
    white += (x == 1 ? 1 : 0);

    for (int i = 0; i < a[u].size(); i++) {
        int v = a[u][i];
        if (d[v] == 0) {
            dfs(v, 0 - d[u]);
        } else if (d[v] == d[u]) {
            ok = 0;
        }
    }
}

void solve() {
    int n, m;
    cin >> n >> m;

    // Reset dữ liệu cho mỗi test case
    res = 0;
    for (int i = 1; i <= n; i++) {
        a[i].clear();
        d[i] = 0;
    }

    int u, v;
    for (int i = 0; i < m; i++) {
        cin >> u >> v;
        a[u].push_back(v);
        a[v].push_back(u);
    }

    for (int i = 1; i <= n; i++) {
        if (d[i] == 0) {
            ok = 1;
            black = 0;
            white = 0;
            dfs(i, 1);
            if (ok == 1) {
                res += max(black, white);
            }
        }
    }

    cout << res << "\n";
}

int main() {
    #ifndef ONLINE_JUDGE
    freopen("inp.txt", "r", stdin);
    #endif

    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int test_cases;
    cin >> test_cases;

    while (test_cases--) {
        solve();
    }

    return 0;
}
