#include <algorithm>
#include <iostream>
#include <bits/stdc++.h>

bool is_bipartite_component(std::unordered_map<int, std::vector<int>>& graph, int curr, int curr_color, std::vector<int>& colors, int& a, int& b) {
    if (colors[curr] != 0) {
        return colors[curr] == curr_color;
    }

    if (curr_color == 1) a++;
    else if (curr_color == 2) b++;

    colors[curr] = curr_color;

    for (int child : graph[curr]) {
        int next_color = curr_color == 1 ? 2 : 1;
        if (!is_bipartite_component(graph, child, next_color, colors, a, b)) {
            return false;
        }
    }

    return true;
}

void solve() {
    int n, m; std::cin >> n >> m;

    std::unordered_map<int, std::vector<int>> graph;

    for (int i = 0; i < m; ++i) {
        int a, b; std::cin >> a >> b;
        a--; b--;
        graph[a].push_back(b);
        graph[b].push_back(a);
    }

    std::vector<int> colors(n);

    int cnt{};

    for (int i = 0; i < n; ++i) {
        if (colors[i] != 0) continue;

        int color_1{};
        int color_2{};

        if (is_bipartite_component(graph, i, 1, colors, color_1, color_2)) {
            cnt += std::max(color_1, color_2);
        }
    }

    std::cout << cnt << std::endl;
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int t; std::cin >> t;
    while (t--) solve();
    return 0;
}