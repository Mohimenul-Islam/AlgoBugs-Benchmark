#include<bits/stdc++.h>
#define mk std::make_pair

using namespace std;
using pii = pair<int, int>;

const int N = 2e5+7;

typedef long long LL;

void solve()
{
    int n,m;
    cin >> n >> m;
    vector<vector<int>> e(n+1);
    for(int i = 0; i < m; i++){
        int u,v;
        cin >> u >> v;
        e[u].push_back(v);
        e[v].push_back(u);
    }
    vector<int> vis(n+1);
    int ans = 0;
    for(int i = 1; i <= n; i++){
        if(vis[i]) continue;
        if(!vis[i]){
            int num1 = 1;
            int num2 = 0;
            vis[i] = 1;
            queue<int> q;
            q.push(i);
            bool flag = 0;
            while(!q.empty()){
                int u = q.front();
                q.pop();
                for(auto v : e[u]){
                    if(vis[v]){
                        if(vis[v] == vis[u])
                            flag = 1;
                        continue;
                    }
                    vis[v] = (vis[u] % 2) + 1;
                    if(vis[v] == 1) num1++;
                    else num2++;
                    q.push(v);
                }
            }
            if(!flag)
                ans += max(num1, num2);
        }
    }
    cout << ans << '\n';
}

int main()
{
    int T = 1;
    cin >> T;
    while(T--){
        solve();
    }
    return 0;
}