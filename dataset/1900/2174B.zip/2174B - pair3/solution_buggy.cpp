#include <bits/stdc++.h>

using namespace std;

template<typename A, typename B> ostream& operator<<(ostream &os, const pair<A, B> &p) { return os << '(' << p.first << ", " << p.second << ')'; }
template<typename T_container, typename T = typename enable_if<!is_same<T_container, string>::value, typename T_container::value_type>::type> ostream& operator<<(ostream &os, const T_container &v) { os << '{'; string sep; for (const T &x : v) os << sep << x, sep = ", "; return os << '}'; }
void dbg_out() { cerr << endl; }
template<typename Head, typename... Tail> void dbg_out(Head H, Tail... T) { cerr << ' ' << H; dbg_out(T...); }
#ifdef LOCAL
#define dbg(...) cerr << "(" << #__VA_ARGS__ << "):", dbg_out(__VA_ARGS__)
#else
#define dbg(...)
#endif

#define ar array
#define ll long long
#define ld long double
#define sza(x) ((int)x.size())
#define all(a) (a).begin(), (a).end()

const int MAX_N = 1e5 + 5;
const ll MOD = 1e9 + 7;
const ll INF = 1e9;
const ld EPS = 1e-9;

void solve() {
	ll n;
	cin>>n;
	ll kk;
	cin>>kk;
	vector<ll> a(n+1);
	for(int i=1;i<=n;i++)cin>>a[i];
	
	vector<pair<ll,ll>> transform;
	ll curr=0;
	ll f=0;
	transform.push_back({0,0});
	for(int i=1;i<=n;i++){
		if(a[i]>curr){
			transform.push_back({a[i],i});
			curr=max(curr,a[i]);
			f+=a[i];
		}
	}
	kk=min(f,kk);
	transform.push_back({0,n+1});
	
	ll sum=0;
	vector<vector<ll>> dp(kk+1,vector<ll>(kk+1,-1));	
	dp[0][0]=0;
	// i need to store the max i got till here
	//dp[i][j][k]
	ll prev=0;
	for(int i=1;i<transform.size()-1;i++){
		sum+=transform[i].first;
		vector<vector<ll>> next_dp(kk+1,vector<ll>(kk+1,-1));
		
		for(int j=0;j<=min(kk,sum);j++){
			for(int k=0;k<=min(transform[i].first,kk);k++){
				if(j-k<=prev && j-k>=0){
					for(int old_m=0;old_m<=kk;old_m++){
						if(dp[j-k][old_m]!=-1){
							ll m=max((ll)k,(ll)old_m);
							ll g=dp[j-k][old_m]+m*(transform[i+1].second-transform[i].second);
							if(g>next_dp[j][m]){
								next_dp[j][m]=g;
							}
						}
					}
				}
			}
		}
		dp=next_dp;
		prev+=transform[i].first;
	}
	
	ll ans=0;
	for(int j=0;j<=kk;j++){
		for(int m=0;m<=kk;m++){
			ans=max(ans,dp[j][m]);
		}
	}
	cout<<ans<<'\n';
}

int main() {
	ios_base::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
	int tc = 1;
	cin >> tc;
	for (int t = 1; t <= tc; t++) {
		solve();
	}
}