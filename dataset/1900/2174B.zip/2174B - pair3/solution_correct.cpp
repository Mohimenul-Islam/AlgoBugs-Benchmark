#include <bits/stdc++.h>

using namespace std;

template<typename A, typename B> ostream& operator<<(ostream &os, const pair<A, B> &p) { return os << '(' << p.first << ", " << p.second << ')'; }
template<typename T_container, typename T = typename enable_if<!is_same<T_container, string>::value, typename T_container::value_type>::type> ostream& operator<<(ostream &os, const T_container &v) { os << '{'; string sep; for (const T &x : v) os << sep << x, sep = ", "; return os << '}'; }
void dbg_out() { cerr << endl; }
template<typename Head, typename... Tail> void dbg_out(Head H, Tail... T) { cerr << ' ' << H; dbg_out(T...); }
#ifdef LOCAL
#define dbg(...) cerr << "(" << #__VA_ARGS__ << "):", dbg_out(__VA_ARGS__)
#else
#define dbg(...)
#endif

#define ar array
#define ll long long
#define ld long double
#define sza(x) ((int)x.size())
#define all(a) (a).begin(), (a).end()

const int MAX_N = 1e5 + 5;
const ll MOD = 1e9 + 7;
const ll INF = 1e9;
const ld EPS = 1e-9;


void solve() {
	//dp[i][j][k]=max value till i with j gifts and max value
	int n,k;
	cin>>n>>k;
	vector<ll> push(n+1);
	int nn=0;
	for(int i=1;i<=n;i++){
		cin>>push[i];
	}
	vector<pair<ll,ll>> a(1);
	a.push_back({push[1],1});
	ll mx=a[1].first;
	nn++;
	for(int i=2;i<=n;i++){
		if(push[i]>mx){
			mx=push[i];
			nn++;
			a.push_back({mx,i});
		}
	}
	a[0]={0,0};
	ll f=0;
	a.push_back({0,n+1});
	vector<vector<vector<ll>>> dp(a.size(),vector<vector<ll>>(k+1,vector<ll>(k+1,0)));
	vector<vector<ll>> dpp(a.size(),vector<ll>(k+1,0));
	for(int i=1;i<=nn;i++){
		for(int j=0;j<=k;j++){
			for(int kk=0;kk<=j;kk++){
				if(kk<=a[i-1].first){
					dp[i][j][kk]=dp[i-1][j][kk]+kk*(a[i+1].second-a[i].second);
				}else if(kk<=a[i].first){
					dp[i][j][kk]=kk*(a[i+1].second-a[i].second)+dpp[i-1][j-kk];
				}else dp[i][j][kk]=dp[i][j][a[i].first];

				dpp[i][j]=max(dpp[i][j],dp[i][j][kk]);
			}
		}
	}
	cout<<dpp[nn][k]<<'\n';

	

}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    int tc = 1;
     cin >> tc;
    for (int t = 1; t <= tc; t++) {
        // cout << "Case #" << t << ": ";
        solve();
    }
    
}