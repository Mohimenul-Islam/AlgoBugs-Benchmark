using namespace std;
#include <bits/stdc++.h>
 
#define yes cout << "YES" << endl;
#define no cout << "NO" << endl;
 
#define ll long long
#define read(arr) for (auto &x: arr) cin >> x;
#define print_vec(arr) for (auto arr_val: arr) { cout << arr_val << " "; } cout << endl
 
// https://codeforces.com/blog/entry/70327, written 5 years ago
ll mod_pow(ll a, ll b, ll m){
    int ans = 1;
    while(b){
        if (b&1) ans = (ans*a) % m;
        b /= 2;
        a = (a*a) % m;
    }
    return ans;
}

// https://usaco.guide/gold/hashing?lang=cpp
long long rng() {
	static std::mt19937 gen(
	    std::chrono::steady_clock::now().time_since_epoch().count());
	return std::uniform_int_distribution<long long>(0, INT64_MAX)(gen);
}
#define int long long
signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int t;
    cin >> t;

    while (t--) {
        int n, k;
        cin >> n >> k;

        vector<int> vec(n); read(vec);
        vector<int> first_idx(k + 1, LLONG_MAX);
        for (int i = 0; i < n; i++) {
            if (first_idx[vec[i]] == LLONG_MAX) first_idx[vec[i]] = i;
        }

        for (int i = k-1; i >= 0; i--) {
            first_idx[i] = min(first_idx[i+1], first_idx[i]);
        }

        int dp[k+1][k+1];
        for (int i = 0; i < k+1; i++) {
            for (int j = 0; j < k+1; j++) {
                dp[i][j] = LLONG_MIN;
            }
        }

        ll best = 0;
        for (int i = 0; i <= vec[0]; i++) {
            dp[i][i] = 0;
            best = max(best, i * n);
        }

        for (int maxi = 0; maxi <= k; maxi++) {
            if (first_idx[maxi] == LLONG_MAX) continue;
           // cout << maxi << " " << 1 << "\n";
            for (int cost = maxi; cost <= k; cost++)  {
                for (int i = 0; i < maxi; i++) {
                    if (dp[i][cost - maxi] != LLONG_MIN && first_idx[i] != first_idx[maxi]) {
                        ll score = dp[i][cost - maxi] + i * (first_idx[maxi] - first_idx[i]);
                       // cout << maxi << " " << cost << " " << i << " " << score << "\n";
                        best = max(best, score + (n - first_idx[maxi]) * maxi);
                        if (dp[maxi][cost] < score) {
                            dp[maxi][cost] = score;
                        }
                        
                    }
                }
            }
        }

        cout << best << "\n";
    }
}
