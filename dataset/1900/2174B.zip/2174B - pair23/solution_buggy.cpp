#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

typedef long long ll;
const ll NEG_INF = -1e18;

void solve() {
    int n, k;
    if (!(cin >> n >> k)) return;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++) cin >> a[i];

    vector<int> first_idx(k + 1, n + 1);
    for (int i = 1; i <= n; i++) {
        if (a[i] > k) continue;
        if (first_idx[a[i]] == n + 1) first_idx[a[i]] = i;
    }
    for (int v = k - 1; v >= 0; v--) {
        first_idx[v] = min(first_idx[v], first_idx[v + 1]);
    }

    vector<vector<ll>> dp(k + 1, vector<ll>(k + 1, NEG_INF));
    
    ll best = 0;
    for (int v = 0; v <= k; v++) {
        if (first_idx[v] > n) continue;
        dp[v][v] = v;
        best = max(best, (ll)v * n);
    }

    for (int v = 1; v <= k; v++) {
        if (first_idx[v] > n) continue;
        for (int c = v; c <= k; c++) {
            for (int prev_v = 0; prev_v < v; prev_v++) {
                if (dp[prev_v][c - v] != NEG_INF) {
                    ll score = dp[prev_v][c - v] + (ll)prev_v * (first_idx[v] - first_idx[prev_v]);
                    dp[v][c] = max(dp[v][c], score);
                    best = max(best, score + (ll)v * (n - first_idx[v] + 1));
                }
            }
        }
    }
    cout << best << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    if (!(cin >> t)) return 0;
    while (t--) {
        solve();
    }
    return 0;
}
