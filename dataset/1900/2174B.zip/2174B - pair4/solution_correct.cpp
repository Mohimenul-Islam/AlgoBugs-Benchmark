#include <bits/stdc++.h>
using namespace std ; 
typedef long long ll ;
const ll inf = (ll)-0x3f3f3f3f3f;
int main(){
 ios::sync_with_stdio(false);
 cin.tie(0) ;
 int tt ; cin >> tt ; 
 while(tt--){
  int n , k ; 
  cin >> n >> k ;
  vector<int> a(n + 1 , 0) ;
  for(int i = 1 ; i <= n ; i++) cin >> a[i] ;
  vector<pair<int , int >> wor ; 
  wor.push_back({0 , 0}) ;
  int curr = 0 ;
  for(int i = 1 ; i <= n ; i++){
    if(a[i] > curr){
     wor.emplace_back(a[i] , i);
     curr = a[i]; 
    }
  }
  wor.emplace_back(0 , n) ;
  // this give me array of atmost k size ; 
  vector<vector<ll>> dp(k + 1 , vector<ll>(k + 1 , inf)) ,
           best(k + 1 , vector<ll>(k + 1 , inf)) ;

  /* dp[sum][beauty] , best[sum][bea] stores max value among all cards
     such that total card used are sum and max(value among all t <= bea)
  */
  dp[0][0] = 0 ; best[0][0] = 0 ;
  fill(best[0].begin() , best[0].end() , 0LL) ;
  for(int i = 1 ; i < wor.size(); i++){
     int fac = wor[i].second - wor[i - 1].second ;
     vector<vector<ll>> ndp(k + 1 , vector<ll>(k + 1 , inf)) , 
         temp_best(k + 1 , vector<ll>(k + 1 , inf)) ;
     for(int sum = 0 ; sum <= k ; sum++){
        for(int bea = 0 ; bea <= k ; bea++){
            ndp[sum][bea] = dp[sum][bea] + (fac * 1LL * bea) ;
            // need max dp[sum - bea][t] where t <= bea and bea <= a[i]
            if(sum - bea >= 0 && bea <= wor[i].first){
                ndp[sum][bea] = max(ndp[sum][bea] , 
                   best[sum - bea][bea] + bea) ;
            }
        }
     }
     dp.swap(ndp) ;
     // to compute for best 
     if(i == (int)wor.size() - 1) break ;
     int nxt = wor[i + 1].second - wor[i].second ;
     temp_best[0][0] = 0 ;
     for(int sum = 0 ; sum <= k ; sum++){
       for(int bea = 1 ; bea <= k ; bea++){
           temp_best[sum][bea] = max(temp_best[sum][bea - 1] 
                    , dp[sum][bea] + (nxt - 1) * 1LL * bea) ;
       }
     }
     best.swap(temp_best); 
  }
  ll ans = inf ; 
  for(int sum = 0 ; sum <= k ; sum++){
    for(int bea = 0; bea <= k ; bea++){
      ans = max(ans , dp[sum][bea]) ;
    }
  }
  cout << ans << '\n' ;
 }
 return 0 ;
}