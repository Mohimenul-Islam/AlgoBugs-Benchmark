

// ///////////////////////////////////////////////////////////////////////////

#include <bits/stdc++.h>
using namespace std;
using ll = long long;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int tt; 
    cin >> tt;
    while(tt--){
        int n, k;
        cin >> n >> k;

        vector<int> a(n);
        for(int i = 0; i < n; i++) cin >> a[i];

        // Build blocks: (capacity, number of followers)
        vector<pair<int,int>> blocks;
        int curMax = 0;
        int cnt = 0;
        for(int i = 0; i < n; i++){
            if(a[i] > curMax){
                if(curMax != 0)
                    blocks.push_back({curMax, cnt});
                curMax = a[i];
                cnt = 0;
            } else {
                cnt++;
            }
        }
        blocks.push_back({curMax, cnt});

        int M = min(k, curMax);
        const ll NEG = -(ll)4e18;

        // dp[j][m] = max happiness
        // j cards used, current maximum m
        vector<vector<ll>> dp(k+1, vector<ll>(M+1, NEG));
        dp[0][0] = 0;

        for(auto [cap, followers] : blocks){
            vector<vector<ll>> ndp(k+1, vector<ll>(M+1, NEG));

            for(int j = 0; j <= k; j++){
                for(int m = 0; m <= M; m++){
                    if(dp[j][m] == NEG) continue;

                    for(int r = 0; r <= min(cap, k - j); r++){
                        int nj = j + r;
                        int nm = max(m, r);

                        // Correct timing:
                        // 1 critical friend + followers
                        ll gain = 1LL * (followers + 1) * nm;

                        ndp[nj][nm] = max(
                            ndp[nj][nm],
                            dp[j][m] + gain
                        );
                    }
                }
            }
            dp.swap(ndp);
        }

        ll ans = 0;
        for(int j = 0; j <= k; j++)
            for(int m = 0; m <= M; m++)
                ans = max(ans, dp[j][m]);

        cout << ans << '\n';
    }
    return 0;
}



