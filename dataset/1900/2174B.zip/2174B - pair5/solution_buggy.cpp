#include<bits/stdc++.h>
using namespace std;

// Ordered set
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> ordered_set;
// less ascending, greater descending **also less_equal, greater_equal**
// op -> *A.find_by_order(x) -> A.order_of_key(x)


#define ll long long
#define ld long double
#define all(n)  n.begin(),n.end()
#define len(n) (ll) n.size()
#define endl '\n'
const ll mod = 1e9 + 7;

// Don't_modify_map_when_iterating
// function<return_type(parameters)>
// to_remove_only_one_element_from_multiset_use_iterator
// substr(i,len)_from_i_take_len_O(len)
// cout_<<_fixed_<<_setprecision()
// priority_queue(type,container,comp)
// rotate(v.begin(),v.end()-rot,v.end()); rotate clockwise by rot
// sort(all(v)) -> v.erase(unique(all(v)),v.end())
// v.erase(unique(all(v)),v.end())
// int to string to_string()

ll binpow(ll a, ll b, const ll &m) {
    a %= m;
    ll res = 1;
    while (b > 0) {
        if (b & 1)
            res = res * a % m;
        a = a * a % m;
        b >>= 1;
    }
    return res;
}

ll inverse(ll a, const ll &m) {
    return binpow(a, m - 2, m);
}


//ll binomial_coefficient(ll n, ll k, const ll &m) {
//    // precompute the factorials before use
//    if (n < k || k < 0) return 0;
//    ll denom = (factorial[k] * factorial[n - k]);
//    return (factorial[n] * inverse(denom, m)) % m;
//}



ll n,k;
vector<ll> v;
ll pull_dp();

void test_case(int &tc) {
//    cout << "Case " << tc << ": " << endl;
    cin >> n >> k;
    v.resize(n+1,0);
    for (ll i=1; i<=n; i++) cin >> v[i];
    cout << pull_dp() << endl;
}

ll pull_dp() {
    vector<ll> pre;
    for (ll i=0; i<n; i++) {
        if (pre.empty()) pre.push_back(i);
        ll x = pre.back();
        if (v[x] < v[i]) pre.push_back(i);
    }
    pre.push_back(n);
    ll sz = len(pre);

    ll dp[sz][k+1][k+1];
    memset(dp, -1, sizeof(dp));
    dp[0][0][0] = 0;


    ll best[k+1][k+1];
    memset(best, -1, sizeof(best));

    for (ll i=1; i<sz; i++) {
        ll now = pre[i];
        //cout << now << endl;
        ll bef = pre[i-1];
        ll gap = now - bef - 1;

        for (ll j=0; j<=k; j++) {
            for (ll mx=0; mx<=k; mx++) {
                ll can = -1;
                if (mx > 0) can = best[j][mx-1];
                if (dp[i-1][j][mx] != -1) can = max(can, dp[i-1][j][mx] + gap*mx);
                best[j][mx] = can;
            }
        }


        for (ll j=0; j<=k; j++) { // How many cards
            for (ll mx=0; mx<=k; mx++) { // max
                ll val = -1;
                if (j >= mx) {
                    if (dp[i-1][j][mx] != -1) val = max(dp[i-1][j][mx] + gap*mx + mx,val);
                }
                if ((j-mx >= 0) && (v[now] >= mx)) {
                    if (best[j-mx][mx] != -1) val = max(val, best[j-mx][mx] + mx);
                }
                dp[i][j][mx] = val;
            }
        }
    }


    ll ans = 0;
    for (ll j=0; j<=k; j++) {
        for (ll mx=0; mx<=k; mx++) {
            if (dp[sz-1][j][mx] != -1) {
                ans = max(ans, dp[sz-1][j][mx]);
            }
        }
    }

    return ans;
}


int32_t main() {
//  freopen("input.txt","r", stdin);
//  freopen("output.txt","w", stdout);
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    ll t = 1;
    cin >> t;
    int tc = 1;
    while(t--) {
        test_case(tc);
        tc++;
    }
}
