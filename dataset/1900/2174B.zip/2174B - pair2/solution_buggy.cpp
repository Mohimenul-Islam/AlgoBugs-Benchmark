#include <bits/stdc++.h>
//#define int int64_t
#define f first
#define s second
#define opt1 ios_base::sync_with_stdio(false)
#define opt2 cin.tie(NULL)
#define optimize opt1; opt2
#define pb push_back
#define endl "\n"
#define sz(v) (int)v.size()
using namespace std;
typedef pair<int, int> ii;
typedef pair<int, ii> i3;
typedef pair<ii, ii> i4;
typedef pair<int, i4> i5;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<i3> vi3;
typedef vector<i4> vi4;
const int inf = 0x6f6f6f6f6f6f;
const int MAX = 100005;
const int LOG = 21;
const int mod = 998244353;

int dp[365][365], a[MAX], b[365];

int32_t main () {
    optimize;
    int t;
    cin >> t;
    while (t--) {
        int n, k;
        cin >> n >> k;
        for (int i = 1; i <= n; i++)
            cin >> a[i];
        int ind = 1, curr = -1;
        for (int i = 1; i <= n; i++) {
            if (a[i] > curr) {
                curr = a[i];
                b[ind] = i;
                ind++;
            }
        }
        for (int i = 0; i <= k; i++)
            for (int j = 0; j <= k; j++)
                dp[i][j] = -inf;
        dp[k][0] = 0;
        int aux;
        for (int i = 1; i < ind; i++) {
            for (int j = 0; j <= k; j++) {
                for (int g = 0; g <= k; g++) {
                    for (int v = g+1; v <= min(j, a[b[i]]); v++) {
                        dp[j-v][v] = 
                            max(dp[j-v][v],
                            dp[j][g]+(n-b[i]+1)*(v-g));
                    }
                }
            }
        }
        int ans = 0;
        for (int i = 0; i <= k; i++)
            for (int j = 0; j <= k; j++)
                ans = max(ans, dp[i][j]);
        cout << ans << endl;
    }
    return 0;
}
/*

dp i,j,k = felicidade maxima ate i, 
            sobrando j, maximo atual k

dp i+1,j,k = max(dp i,j,k, dp i+1,j,k)
dp i+1,j-a[i],a[i] = max(dp i+1,j-a[i],a[i], dp i,j,k + ...)

*/
