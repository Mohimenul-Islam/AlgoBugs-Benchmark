#include <bits/stdc++.h>
//#define int int64_t
#define f first
#define s second
#define opt1 ios_base::sync_with_stdio(false)
#define opt2 cin.tie(NULL)
#define optimize opt1; opt2
#define pb push_back
#define endl "\n"
#define sz(v) (int)v.size()
using namespace std;
typedef pair<int, int> ii;
typedef pair<int, ii> i3;
typedef pair<ii, ii> i4;
typedef pair<int, i4> i5;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<i3> vi3;
typedef vector<i4> vi4;
const int inf = 0x6f6f6f6f6f6f;
const int MAX = 100005;
const int LOG = 21;
const int mod = 998244353;

int dp[365][365], a[MAX], b[365], V[365];

int32_t main () {
    optimize;
    int t;
    cin >> t;
    while (t--) {
        int n, k;
        cin >> n >> k;
        for (int i = 1; i <= n; i++)
            cin >> a[i];
        int ind = 1, curr = -1;
        for (int i = 1; i <= n; i++) {
            if (a[i] > curr) {
                curr = a[i];
                b[ind] = i;
                ind++;
            }
        }
        for (int i = 0; i <= k; i++)
            for (int j = 0; j <= k; j++)
                dp[i][j] = -inf;
        dp[k][0] = 0;
        for (int j = 0; j <= k; j++)
            V[j] = -inf;
        for (int j = 0; j <= k; j++)
            for (int g = 0; g <= k; g++)
                V[j] = max(V[j], dp[j][g]+g);
        int x, y, var1, var2;
        b[ind] = n+1;
        a[n+1] = 0;
        for (int i = 1; i <= ind; i++) {
            for (int j = 0; j <= k; j++) {
                for (int g = 0; g <= a[b[i]]; g++) {
                    x = b[i], y = b[i-1];
                    var1 = dp[j][g]+(x-y)*g;
                    if (j+g <= k) {
                        var2 = V[j+g];
                        dp[j][g] = max(var1, var2); 
                    } else dp[j][g] = var1;
                    //cerr << i << " " << j << " " << g << " " << dp[j][g] << endl;
                }
            }
            for (int j = 0; j <= k; j++)
                V[j] = -inf;
            int next = b[i+1];
            for (int j = 0; j <= k; j++)
                for (int g = 0; g <= k; g++)
                    V[j] = max(V[j], dp[j][g]+(next-b[i])*g);
        }
        int ans = 0;
        for (int i = 0; i <= k; i++)
            for (int j = 0; j <= k; j++)
                ans = max(ans, dp[i][j]);
        cout << ans << endl;
    }
    return 0;
}
/*

dp(i,j,g) = max(dp(last,j,g), A) + (x-y)*g

A = max(dp(last, j+g, a)+(x-y)*a)

*/
