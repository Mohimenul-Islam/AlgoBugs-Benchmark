#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <ctime>
#include <cassert>
#include <complex>
#include <string>
#include <cstring>
#include <chrono>
#include <numeric>
#include <random>
#include <bitset>
#include <array>
#include <climits>
using namespace std;
// #define LOCAL
#ifdef ONLINE_JUDGE
    #include <bits/stdc++.h>
#endif

#ifdef ONLINE_JUDGE
    #define debug(x)
#else
    #define debug(x) cout << #x << " = " << x << "\n";
#endif

#define int long long
#define pi 3.141592653589793238
#define pb(e) push_back(e)
#define all(x) x.begin(), x.end()
#define cin(v) for(auto &i : v) cin >> i;
#define sv(a) sort(a.begin(), a.end())
#define forn(i,n) for(int i=0;i<n;i++)
#define vi vector<int>
#define vii vector<vector<int>>
#define vc vector<char>
#define vcc vector<vector<char>>
#define F first
#define S second
#define pii pair<int,int>

const int mod = 1e9+7;
const int INF = 1e18;

/* -------------------- FAST POWER -------------------- */

int binpow(int a,int b){
    a%=mod;
    int res=1;
    while(b>0){
        if(b&1) res=res*a%mod;
        a=a*a%mod;
        b>>=1;
    }
    return res;
}

int inverse(int a){ return binpow(a,mod-2); }


/* -------------------- RANDOM -------------------- */

mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());

/* =========================================================
                    DSU
========================================================= */

vector<int> par, sz;

int find_par(int a){
    if(par[a]==a) return a;
    return par[a]=find_par(par[a]);
}

void unite(int a,int b){
    a=find_par(a);
    b=find_par(b);
    if(a==b) return;
    if(sz[b]>sz[a]) swap(a,b);
    sz[a]+=sz[b];
    par[b]=a;
}

void make_dsu(int n){
    par.assign(n+1,0);
    sz.assign(n+1,1);
    for(int i=1;i<=n;i++) par[i]=i;
}

/* =========================================================
                MONOTONIC STACK
========================================================= */

vector<int> nextGreater(vector<int>& arr,int n){
    stack<int> s;
    vector<int> res(n,n);
    for(int i=0;i<n;i++){
        while(!s.empty() && arr[s.top()]<arr[i]){
            res[s.top()]=i;
            s.pop();
        }
        s.push(i);
    }
    return res;
}

vector<int> prevGreater(vector<int>& arr,int n){
    stack<int> s;
    vector<int> res(n,-1);
    for(int i=n-1;i>=0;i--){
        while(!s.empty() && arr[s.top()]<arr[i]){
            res[s.top()]=i;
            s.pop();
        }
        s.push(i);
    }
    return res;
}

/* =========================================================
                SEGMENT TREE (Range Max)
========================================================= */

class SegmentTree{
private:
    vector<int> tree,data;
    int n;

    void build(int node,int l,int r){
        if(l==r){
            tree[node]=data[l];
        }else{
            int mid=(l+r)/2;
            build(2*node,l,mid);
            build(2*node+1,mid+1,r);
            tree[node]=max(tree[2*node],tree[2*node+1]);
        }
    }

    void update_util(int node,int l,int r,int idx,int val){
        if(l==r){
            data[idx]=val;
            tree[node]=val;
        }else{
            int mid=(l+r)/2;
            if(idx<=mid)
                update_util(2*node,l,mid,idx,val);
            else
                update_util(2*node+1,mid+1,r,idx,val);
            tree[node]=max(tree[2*node],tree[2*node+1]);
        }
    }

    int query_util(int node,int l,int r,int ql,int qr){
        if(qr<l || r<ql) return LLONG_MIN;
        if(ql<=l && r<=qr) return tree[node];
        int mid=(l+r)/2;
        return max(query_util(2*node,l,mid,ql,qr),
                   query_util(2*node+1,mid+1,r,ql,qr));
    }

public:
    SegmentTree(const vector<int>& input){
        data=input;
        n=data.size();
        tree.resize(4*n);
        build(1,0,n-1);
    }

    void update(int idx,int val){
        update_util(1,0,n-1,idx,val);
    }

    int query(int l,int r){
        return query_util(1,0,n-1,l,r);
    }
};

/* =========================================================
                    BRIDGE FINDER
========================================================= */

/*vector<vector<int>> graph;
vector<int> tin, low;
vector<bool> visited;
int timer;
set<pair<int,int>> bridges;
void dfs_bridge(int u,int parent){
    visited[u]=true;
    tin[u]=low[u]=++timer;
    for(int v:graph[u]){
        if(v==parent) continue;
        if(visited[v]){
            low[u]=min(low[u],tin[v]);
        }else{
            dfs_bridge(v,u);
            low[u]=min(low[u],low[v]);
            if(low[v]>tin[u]){
                bridges.insert({u,v});
            }
        }
    }
}
*/

/* =========================================================
                        MATH LIB
========================================================= */

const int MAXN = 1e6+5;

struct mint{
    int val;

    mint(long long v=0){
        if(v<0) v=v%mod+mod;
        if(v>=mod) v%=mod;
        val=v;
    }

    mint& operator+=(const mint& other){
        val+=other.val;
        if(val>=mod) val-=mod;
        return *this;
    }

    mint& operator-=(const mint& other){
        val-=other.val;
        if(val<0) val+=mod;
        return *this;
    }

    mint& operator*=(const mint& other){
        val=(1LL*val*other.val)%mod;
        return *this;
    }

    mint pow(long long exp) const{
        mint base=*this,res=1;
        while(exp>0){
            if(exp&1) res*=base;
            base*=base;
            exp>>=1;
        }
        return res;
    }

    mint inv() const{
        return mint(binpow(val,mod-2));
    }

    mint& operator/=(const mint& other){
        return (*this)*=other.inv();
    }

    friend mint operator+(mint a,const mint& b){ return a+=b; }
    friend mint operator-(mint a,const mint& b){ return a-=b; }
    friend mint operator*(mint a,const mint& b){ return a*=b; }
    friend mint operator/(mint a,const mint& b){ return a/=b; }
};

vector<mint> fact(MAXN),invfact(MAXN);

void precompute_factorials(){
    fact[0]=1;
    for(int i=1;i<MAXN;i++)
        fact[i]=fact[i-1]*i;
    invfact[MAXN-1]=fact[MAXN-1].inv();
    for(int i=MAXN-2;i>=0;i--)
        invfact[i]=invfact[i+1]*(i+1);
}

mint nCr(int n,int r){
    if(r<0 || r>n) return 0;
    return fact[n]*invfact[r]*invfact[n-r];
}

std::uniform_int_distribution<> distrib(1, 100000000);

/*

*/

int gcd(int a, int b){
    while(b){
        a %= b;
        swap(a,b);
    }
    return a;
}

void print(vector<int> v) {
    for(auto j:v) cout<<j<<" ";
        cout<<endl;
}

int lcm(int a,int b) {
    return a*(b/gcd(a,b));
}

/*
if thier is no other index which share the same val as the special val then reverse all the arr and then reverse the 
special indx in groups

if not 
*/


void solve(){
   int n,k;cin>>n>>k;
   vi v(n);cin(v);
   vi a(k);cin(a);
   vi special(n,0);
   forn(i,k) special[a[i]-1]=1;
   int spei=-1;
   int ans=0;
   for(int i=0;i<n;i++) {
    if(v[i]==v[a[0]-1]&&(!special[i])) continue;
    int x=0;
    int ans1=0;
    int y=0;
    int prevz=1;
    // cout<<"Change "<<i<<endl;
    if(special[i]) {
        spei=i;
        i++;
        y++;
    }
    int z=0;
     while(i<n) {
        // cout<<i<<endl;
       if(v[i]!=v[a[0]-1]) {
        x++;i++;
       } else if(v[i]==v[a[0]-1]) {
        if(special[i]) {
            spei=i;
            if(i&&!special[i-1]) y++;
            i++;
        }
        else {
            if(i&&spei==(i-1)) special[i-1]=2,i++;
            else if(i+1<n&&special[i+1]) special[i+1]=2,i++;
            else if(!y) {
                if(!z&&!prevz) ans++;
                else if(z) ans+=2;
                else ans++,z++;
                i++;
            }
            else break;
        }
       }
     }
     // debug(i);
     i--;
     if(!x) {
        prevz=z;
        i++;continue;
        
     }
     while(i>=0&&y>1) {
        if(special[i]==1||v[i]==v[a[0]-1]) i--,y--;
        else break;
     }
     if(i<0) i=0;
     if(x) {
        ans+=(1+y);
     } else i++;
     prevz=z;
     // cout<<ans<<endl;
   }
   cout<<ans<<endl;
}

signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    
    int t=1;
    cin>>t;
    while(t--){
        solve();
    }
}