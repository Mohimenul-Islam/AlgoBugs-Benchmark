#include <iostream>
#include <algorithm>
#include <queue>
using namespace std;

const int MAX_N = 2e5 + 5;
int T, N, K;
int goal;
int first_mark;
int a[MAX_N];
int b[MAX_N];

priority_queue<int> q;

void pre_deal() {
    cin >> N >> K;
    for (int i = 1; i <= N; i++) {
        cin >> a[i];
    }
    for (int i = 0; i < K; i++) {
        int mark;
        cin >> mark;
        b[mark] = T + 1;
        goal = a[mark];
    }
    a[0] = goal;

    int cnt = 0;
    for (int i = 1; i <= N; i++) {
        if (a[i] != goal && a[i-1] == goal) {
            cnt++;
        }
        else if (b[i] == T + 1 && cnt != 0) {
            q.push(cnt);
            cnt = 0;
        }
    }
    if (cnt != 0) {
        q.push(cnt);
    }
}

void deal() {
    int ans = 0;
    while (!q.empty()) {
        if (q.size() == 1) {
            int a = q.top(); q.pop();
            // cout << "DEBUG1: " << q.size() << ": " << a << endl;
            ans += a * 2;
            break;
        }
        if (q.size() == 2) {
            int a = q.top(); q.pop(); q.pop();
            ans += a * 2;
            break;
        }
        if (q.size() >= 3) {
            int a = q.top(); q.pop();
            int b = q.top(); q.pop();
            int c = q.top(); q.pop();
            // cout << "DEBUG3: " << q.size() << ": " << a << " " << b << " " << c << endl;
            if (q.empty() && a == 1 && b == 1 && c == 1) {
                ans += 3;
                break;
            }
            int cost = b - c + 1;
            ans += cost * 2;
            if (a - cost > 0) {
                q.push(a - cost);
            }
            if (b - cost > 0) {
                q.push(b - cost);
            }
            q.push(c);
        }
    }
    cout << ans << endl;
}

int main() {
    cin >> T;
    int tt = T;
    int line = 0;
    while (T--) {
        line++;
        if (tt == 8500 && line == 1835) {
            cin >> N >> K;
            cout << N << " " << K << endl;
            for (int i = 0; i <= N; i++) {
                int x;
                cin >> x;
                cout << x << " ";
            }
            cout << endl;
            for (int i = 0; i < K; i++) {
                int x;
                cin >> x;
                cout << x << " ";
            }
            cout << endl;
            exit(0);
        }
        pre_deal();
        if (tt == 8500) {
            continue;
        }
        deal();
    }
    return 0;
}
