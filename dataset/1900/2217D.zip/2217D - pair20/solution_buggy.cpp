#include <bits/stdc++.h>
using namespace std;

const int MAXN = 200050;
const long long MOD = 1e9 + 7;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

//    freopen("input.txt", "r", stdin);

    int t;
    cin >> t;
    while(t--){
        int n, k, prev = 1, sum = 0, cnt = 0, mx = 0;
        cin >> n >> k;
        vector<int> a(n + 2), p(k + 1);
        set<int> st;
        for(int i = 1; i <= n; i++) cin >> a[i];
        for(int i = 1; i <= k; i++) {int x; cin >> x; st.insert(x);}
        st.insert(n + 1);
        prev = (*st.begin());

        for(int i = 1; i <= n + 1; i++){
//            cout << i <<" - "<<a[i]<<" "<<cnt<<'\n';
            if(st.find(i) != st.end())
            {
                sum += cnt;
                mx = max(mx, cnt);
//                cout <<"->"<< sum <<" "<<mx<<" "<<cnt<<'\n';
                cnt = 0;
                prev = a[i];
                continue;
            }
            if(a[i] != prev) cnt = max(2, cnt + 1);
            prev = a[i];
        }
//        cout << mx <<" "<<sum<<" ";

        if(mx > (sum - mx)) cout << sum - mx + mx<<'\n';
        else cout << sum / 2 << '\n';
    }

    return 0;
}
