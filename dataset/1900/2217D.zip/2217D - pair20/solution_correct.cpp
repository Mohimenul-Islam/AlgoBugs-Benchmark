#include <bits/stdc++.h>
using namespace std;



int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);


    int t;
    cin >> t;
    while (t--) {
        int n, k, prev = 1, sum = 0, cnt = 0, mx = 0;
        cin >> n >> k;
        vector<int> a(n + 2);
        set<int> st;
        for(int i = 1; i <= n; i++) cin >> a[i];
        for(int i = 1; i <= k; i++)
        {
            int x;
            cin >> x;
            prev = a[x];
            st.insert(x);
        }

        st.insert(n + 1);

        for(int i = 1; i <= n + 1; i++){
            if(a[i] != prev && i <= n) cnt++;
            if(st.find(i) != st.end()){
                sum += cnt;
                mx = max(mx, cnt);
                cnt = 0;
            }
            prev = a[i];
        }

        if((sum - mx) < mx) cout << mx + mx % 2 << '\n';
        else cout << (sum + 1) / 2 << '\n';
    }
    return 0;
}
