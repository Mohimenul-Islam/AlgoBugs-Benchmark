#include <bits/stdc++.h>
#define int long long
#define all(v) v.begin(), v.end()
#define popc(x) __builtin_popcount(x)
#define debug(x) cerr << #x << " : " << x << '\n'
using namespace std;
using ll = long long;
using lll = __int128;
using pii = array<int, 2>;
using Tt = tuple<int, int, int>;
using db = long double;
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
const int Maxn = 1e3 + 5, Maxm = 1e6 + 5, INF = 4e18, inf = 1e9, Mod = 1e9 + 7;
ll qmi(ll a, ll k, int m)
{
	lll res = 1;
	while (k)
	{
		if (k & 1)
			res = res * a % m;
		a *= a % m;
		k >>= 1;
	}
	return (ll)res;
}
vector<array<int, 3>> G[Maxn];
int n, m, k, x, y, q;
string s, Map[Maxn];
ll inv(int x) { return qmi(x, Mod - 2, Mod);}

// 区间内有多少个变化点？每次选择区间都能最多选两个配对，而每个块内的所有点都要消除，
// 那么答案的操作次数最少也要 max(cnt[k]) 次，就是这个区间内的最多变化点数量
void sol(){
	cin >> n >> k;
	vector<int> a(n + 1), b = a, p({0});
	
	b.push_back(0);
	for(int i = 1; i <= n; ++i) cin >> a[i];
	for(int i = 0; i < k; ++i) cin >> x, p.push_back(x);
	p.push_back(n + 1);

	int tar = a[p[1]];
	vector<int> pre(n + 5);
	for(int i = 1; i <= n + 1; ++i) {
		if(i <= n) b[i] = (a[i] ^ tar);
		pre[i] = pre[i - 1] + (b[i] != b[i-1]);
	}

	int mx = 0;
	
	for(int i = 1; i < p.size(); ++i) {
		int v = p[i-1], u = p[i];
		mx = max(mx, pre[u] - pre[v]);
	}

	cout << max(mx, pre[n + 1]/2) << '\n';
}

signed main()
{
	// freopen(".in", "r", stdin);
	// freopen(".out", "w", stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	int t = 1;
	cin >> t;
	while (t--)
		sol();
	return 0;
}
/**
 *  心中无女人
 *  比赛自然神
 *  模板第一页
 *  忘掉心上人
 **/