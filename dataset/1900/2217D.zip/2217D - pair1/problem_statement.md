# D. Flip the Bit (Hard Version)

**Time limit:** 1.5 seconds
**Memory limit:** 256 megabytes

## Problem Statement

This is the hard version of the problem. The difference between the versions is that in this version, there can be multiple special indices ($$$1 \\le k \\le n$$$). You can hack only if you solved all versions of this problem.

You are given a binary array $$$a$$$ of length $$$n$$$ and $$$k$$$ special indices $$$p\_1, p\_2, \\ldots, p\_k$$$ ($$$1 \\le p\_i \\le n$$$). It is given that the values $$$a\_i$$$ of all elements at special indices are the same (i. e., $$$a\_{p\_1} = a\_{p\_2} = \\ldots = a\_{p\_k}$$$).

In one operation, you can choose a range $$$\[l, r\]$$$ ($$$1 \\le l \\le r \\le n$$$) such that the range contains at least one special index ($$$l \\le p\_i \\le r$$$) and flip all bits $$$a\_j$$$ for $$$l \\le j \\le r$$$. Flipping a bit changes $$$0$$$ to $$$1$$$ and $$$1$$$ to $$$0$$$.

Let $$$x$$$ denote the value at special indices before any operations are applied. Find the minimum number of operations required to make all elements of the array equal to $$$x$$$.

## Input

Each test contains multiple test cases. The first line contains the number of test cases $$$t$$$ ($$$1 \\le t \\le 10^4$$$). The description of the test cases follows.

The first line of each test case contains two integers $$$n$$$ and $$$k$$$ ($$$1 \\le k \\le n \\le 2 \\cdot 10^5$$$) — the length of the array and the number of special indices.

The second line contains $$$n$$$ integers $$$a\_1, a\_2, \\ldots, a\_n$$$ ($$$0 \\le a\_i \\le 1$$$) — the elements of the array.

The third line contains $$$k$$$ integers $$$p\_1, p\_2, \\ldots, p\_k$$$ ($$$1 \\le p\_1 \\lt p\_2 \\lt \\ldots \\lt p\_k \\le n$$$) — the special indices. It is guaranteed that $$$a\_{p\_1} = a\_{p\_2} = \\ldots = a\_{p\_k}$$$.

It is guaranteed that the sum of $$$n$$$ over all test cases does not exceed $$$2 \\cdot 10^5$$$.

## Output

For each test case, output a single integer — the minimum number of operations required.

## Sample Tests

### Input
```
6
2 1
1 0
1
3 2
0 1 0
1 3
5 5
1 1 1 1 1
1 2 3 4 5
9 5
0 1 0 0 1 0 0 1 0
3 4 6 7 9
13 4
1 0 0 1 0 1 0 1 1 0 1 0 1
4 8 11 13
15 3
1 0 1 0 1 0 1 0 1 0 1 0 1 0 1
3 11 13
```

### Output
```
2
2
0
3
5
8
```

## Note

For the first test case, you can choose the range $$$\[1, 2\]$$$ and flip both the bits to get $$$\[0, 1\]$$$. Then you can choose the range $$$\[1, 1\]$$$ and flip the first bit to get $$$\[1, 1\]$$$.

For the second test case, you can choose the range $$$\[1, 2\]$$$ and flip the bits to get $$$\[1, 0, 0\]$$$. Then you can choose the range $$$\[1, 1\]$$$ and flip the first bit to get $$$\[0, 0, 0\]$$$.

For the fourth test case, you can choose the range $$$\[2, 8\]$$$ and flip the bits to get $$$\[0, 0, 1, 1, 0, 1, 1, 0, 0\]$$$. Then you can choose the range $$$\[3, 4\]$$$ and flip the bits to get $$$\[0, 0, 0, 0, 0, 1, 1, 0, 0\]$$$. Then you can choose the range $$$\[6, 7\]$$$ and flip the bits to get $$$\[0, 0, 0, 0, 0, 0, 0, 0, 0\]$$$. Note that, while there can be other ways to achieve this, it can be proved that the minimum number of operations is $$$3$$$.