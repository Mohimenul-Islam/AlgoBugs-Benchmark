#include <bits/stdc++.h>
#pragma GCC optimize("O3,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,popcnt,lzcnt")
#define se second
#define pb push_back
#define fi first
#define fo(var, n) for (long long var = 0; var < n; var++)
#define fore(var, n) for (long long var = n - 1; var >= 0; var--)
using namespace std;
using ll = long long;
using ld = long double;
using vl = vector<ll>;
using pii = pair<ll, ll>;


int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0);

    #ifdef codefors
    ifstream cin("in.in");
    #endif

    int tt = 1;
    cin >> tt;
    while(tt--)
    {
        int n, k;cin>>n>>k;
        int a[n], b[n], fit;
        fo(i, n) cin>>a[i], b[i] =0;
        fo(i,k) cin>>fit, b[fit-1]=1;
        int gungus = 0;
        fo(i, n) if(b[i] == 1) if(a[i] == 0) gungus = 1; // whata the pointa
        fo(i, n) a[i] ^= gungus;
        vector<pii> c;
        fo(i, n)
        {
           if(c.size()==0&&a[i]==1) continue;
          if(c.size() == 0 || c.back().fi!= a[i]) c.pb({a[i], 0}) ;
          c.back().se |= b[i];}
          if(c.size()==0)
          {
          cout << gungus << endl;continue;}
        if(c.back().fi==1) c.pop_back();
        int mi =1e9, mj=1e9;
        fo(i, c.size()) if(c[i].se)
        {
          if(i<c.size()/2) mi=i;
          else {mj=i;break;}
        }
        if(mi==mj&&mi==1e9) cout<<c.size()+1 <<endl;
        else if(mi!=1e9&&mj!=1e9)
        {
        int c1=mj-mi;
        cout << max(mj-mi, (int) c.size()/2+1)<< endl;
        }
        else if(mi<1e7) cout<<max(mi,(int) c.size()-mi-1)+1 <<endl;
        else cout<<max(mj,(int) c.size()-mj-1)+1<<endl;
    }


    return 0;
}
