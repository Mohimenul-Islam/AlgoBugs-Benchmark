#include <iostream>
#include<vector>
#include<algorithm>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<cstdint>
#include<numeric>
#include<cmath>
#include<unordered_map>
#include<bit>
using namespace std;
#define ll long long
#define ld long double
#define pl pair<ll, ll>
#define vl vector<ll>
#define vpl vector<pl>
#define vb vector<bool>
#define vvl vector<vl>
#define vvpl vector<vpl>
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define f(i,a,b) for (ll i = (a); i < (b); ++i)
#define rf(i,a,b) for (ll i = (a); i >= (b); --i)
#define each(x,a) for (auto &x : a)
#define uniq(x) x.resize(unique(all(x)) - x.begin())
#define yes cout << "YES\n"
#define no cout << "NO\n";
ll M = 998244353;

char inv(char a) {
    if (a == '0') {
        return '1';
    }
    else {
        return '0';
    }
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    ll t;
    cin >> t;
    while (t--) {
        ll n, k, ans = 0,x,c=0,s=0;
        cin >> n >> k;
        vl a(n);
        set<ll> p;
        f(i, 0, n) {
            cin >> a[i];
        }
        f(i, 0, k) {
            cin >> x;
            p.insert(x);
        }
        if (a[0] != a[*p.begin()]) {
            c++;
        }
        f(i, 1, n) {
            if (a[i] != a[i - 1]) {
                c++;
            }
            if (p.count(i)) {
                s += c;
                ans = max(ans, c);
                c = 0;
            }
        }
        s += c;
        ans = max(ans, c);
        cout << max(ans,s/2) << endl;
    }
}