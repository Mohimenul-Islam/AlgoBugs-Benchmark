#include <bits/stdc++.h>

void solve() {
    int n, k;
    std::cin >> n >> k;
    std::vector<int> a(n + 2), p(k + 1), diff(n + 2);
    for (int i = 1; i <= n; i++) {
        std::cin >> a[i];
    }
    for (int i = 1; i <= k; i++) {
        std::cin >> p[i];
    }
    int tar = a[p[1]];
    int cnt1 = 0;
    for (int i = 1; i <= n; i++) {
        a[i] ^= tar;
    }
    for (int i = 1; i <= n + 1; i++) {
        diff[i] = a[i] ^ a[i - 1];
        cnt1 += diff[i];
    }
    int cnt2 = 0;
    int temp;
    for (int i = 1; i <= k; i++) {
        temp = 0;
        for (int j = p[i - 1] + 1; j <= p[i]; j++) {
            temp += diff[j];
        }
        cnt2 = std::max(cnt2, temp);
    }
    temp = 0;
    for (int i = p[k] + 1; i <= n + 1; i++) {
        temp += diff[i];
    }
    cnt2 = std::max(cnt2, temp);
    if (cnt2 <= cnt1 / 2) {
        std::cout << cnt1 / 2 << "\n";
    } else {
        std::cout << cnt1 - cnt2 + cnt2 * 2 - cnt1 << "\n";
    }
    // for (int i = 1; i <= n + 1; i++) {
    //     std::cout << diff[i] << " ";
    // }
    // std::cout << "\n";
}

signed main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int t = 1;
    std::cin >> t;

    while (t--) {
        solve();
    }

    return 0;
}
