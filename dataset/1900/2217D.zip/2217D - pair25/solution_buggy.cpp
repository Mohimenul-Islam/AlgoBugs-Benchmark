﻿#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int t;
    cin >> t;
    while (t--) {
        int n, m;
        cin >> n >> m;
        vector<bool> isSpecial(n, 0);
        vector<int>  dane(n);
        for (int i = 0; i < n; i++) {
            cin >> dane[i];
        }
        int goodColor;
        for (int i = 0; i < m; i++) {
            int a;
            cin >> a;
            isSpecial[a - 1] = true;
            goodColor = dane[a - 1];
        }
        vector<int> blocks;
        bool begun = false;
        int licznik = 0, calk = 0;
        for (int i = 0; i < n; i++) {
            if (isSpecial[i]) {
                if (licznik != 0) {
                    blocks.push_back(licznik);
                }
                licznik = 0;
                begun = false;
            }
            else {
                if (!begun && dane[i] != goodColor) {
                    begun = true;
                    licznik++;
                    calk++;
                }
                else if (dane[i] == goodColor) {
                    begun = false;
                }
            }
        }
        if (licznik != 0) {
            blocks.push_back(licznik);
        }
        sort(blocks.begin(), blocks.end());
        /*cout << "mam bloki wielkosci: " << endl;
        for (int &a : blocks) {
            cout << a << " ";
        }
        cout << endl << "wszystkich jest " << calk << endl;*/
        if (blocks.size() == 0) {
            cout << "0" << endl;
            continue;
        }
        int wynik = 0;
        while (blocks.size() > 1) {
            int idx = blocks.size() - 1;
            int first = blocks[idx - 1], second = blocks[idx];
            if (blocks.size() == 3 && calk & 1 && calk < 5) {
                wynik += 3;
                calk -= 3;
                blocks[idx]--;
                blocks[idx - 1]--;
                blocks[idx - 2]--;
                while (blocks.size() > 0 && blocks[blocks.size() - 1] == 0) {
                    blocks.pop_back();
                }
                continue;
            }
            int mini = min(first, second);
            wynik += 2 * mini;
            calk -= 2 * mini;
            first -= mini;
            second -= mini;
            if (first == 0 && second == 0) {
                blocks.pop_back();
                blocks.pop_back();
            }else if (second == 0) {
                blocks.pop_back();
            }
            else {
                blocks[idx - 1] = second;
                blocks.pop_back();
            }
        }
        if (blocks.size() > 0) {
            wynik += 2 * blocks[0];
        }
        cout << wynik << endl;
    }
}