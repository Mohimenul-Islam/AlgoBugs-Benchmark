﻿#include <iostream>
#include <vector>
#include <algorithm>
#include <set>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int t;
    cin >> t;
    while (t--) {
        int n, m;
        cin >> n >> m;
        vector<bool> isSpecial(n, 0);
        vector<int>  dane(n);
        for (int i = 0; i < n; i++) {
            cin >> dane[i];
        }
        int goodColor;
        for (int i = 0; i < m; i++) {
            int a;
            cin >> a;
            isSpecial[a - 1] = true;
            goodColor = dane[a - 1];
        }
        multiset<int, greater<int>> ms;
        bool begun = false;
        int licznik = 0, calk = 0;
        for (int i = 0; i < n; i++) {
            if (isSpecial[i]) {
                if (licznik != 0) {
                    ms.insert(licznik);
                }
                licznik = 0;
                begun = false;
            }
            else {
                if (!begun && dane[i] != goodColor) {
                    begun = true;
                    licznik++;
                    calk++;
                }
                else if (dane[i] == goodColor) {
                    begun = false;
                }
            }
        }
        if (licznik != 0) {
            ms.insert(licznik);
        }
        /*cout << "mam bloki o wielkosciach: " << endl;
        for (auto& a : ms) {
            cout << a << " ";
        }
        cout << endl;*/
        if (ms.size() == 0) {
            cout << "0" << endl;
            continue;
        }
        int wynik = 0;
        while (ms.size() > 1) {
            if(ms.size() == 3 && calk == 3){
                wynik += 3;
                ms.clear();
                continue;
            }
            int first = *ms.begin(), second = *(next(ms.begin()));
            wynik += 2;
            calk -= 2;
            ms.erase(ms.begin());
            ms.erase(ms.begin());
            if (first != 1) {
                ms.insert(first - 1);
            }
            if (second != 1) {
                ms.insert(second - 1);
            }
        }
        if (ms.size() > 0) {
            wynik += 2 * *ms.begin();
        }
        cout << wynik << endl;
    }
}