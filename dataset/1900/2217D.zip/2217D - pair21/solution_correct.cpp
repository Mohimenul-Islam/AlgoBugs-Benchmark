#include<bits/stdc++.h>
using namespace std;
 
const int MAXN=2e5+10;
 
int t,n,k,now,cnt,maxn;
int a[MAXN],p[MAXN];
bool flag;
 
int main(){
	cin >>t;
	while (t--){
		cin >>n >>k;
		for (int i=1;i<=n;i++)
			cin >>a[i];
		for (int i=1;i<=k;i++)
			cin >>p[i];
		a[0]=a[n+1]=a[p[1]],p[k+1]=n+1,now=cnt=maxn=0;
		for (int i=1;i<=k+1;i++){
			int res=0;
			while (now<p[i])
				{
				if (a[now]!=a[now+1]) res++;now++;}
			cnt+=res,maxn=max(maxn,res);
		}
		cout <<max(cnt/2,maxn) <<endl;
	}
	return 0;
}