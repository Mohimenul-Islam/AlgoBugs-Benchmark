#include<bits/stdc++.h>
using namespace std;
 
const int MAXN=2e5+10;
 
int t,n,k,l,r,ans,now;
int a[MAXN],p[MAXN],len[MAXN];
bool flag;
 
int main(){
	cin >>t;
	while (t--){
		cin >>n >>k;
		for (int i=1;i<=n;i++)
			cin >>a[i];
		for (int i=1;i<=k;i++)
			cin >>p[i];
		p[k+1]=n+1;
		l=-1;
		for (int i=1;i<=n;i++){
			if (a[i]!=a[p[1]]){
				l=i;
				break;
			}
		}
		if (l==-1){
			cout <<'0' <<endl;
			continue;
		}
		for (int i=n;i>0;i--){
			if (a[i]!=a[p[1]]){
				r=i;
				break;
			}
		}
//		if (l==r){
//			cout <<'2' <<endl;
//			continue;
//		}
		flag=0,ans=1,now=0;
		while (p[now]<l) now++;
		now--;
		memset(len,0,sizeof(len));
		for (int i=l+1;i<=r;i++){
			if (a[i]==a[p[1]]){if (p[now+1]==i) flag=1,now++;}
			else if (a[i-1]==a[p[1]]){
				if (flag) ans++;
				else len[now]++;
				flag=0;
			}
		}
//		cout <<len[] <<endl;
		if (ans==1){
			ans+=len[now]*2+1;
		} else{
			for (int i=1;i<=now;i++){
				if (len[i]<len[i+1]) ans+=len[i]*2-(len[i]!=0||len[i+1]!=0),len[i+1]-=len[i];
				else ans+=len[i]*2-(len[i]!=0||len[i+1]!=0)*(i!=now)-(max(len[i],len[i+1])>1)*(i!=now),len[i+1]=0;
			}
		}
		cout <<ans <<endl;
	}
	return 0;
}