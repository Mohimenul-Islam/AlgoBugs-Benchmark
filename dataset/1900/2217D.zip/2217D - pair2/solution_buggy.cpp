#include <bits/stdc++.h>
using namespace std;
 
#define    ll              long long
#define    endl            "\n"
#define    fast_io         ios_base::sync_with_stdio(false);cin.tie(NULL); cout.tie(NULL)
#define    pb              push_back
using      vl=vector<ll>;
#define    vvl             vector<vl>
#define    asort(v)        sort(v.begin(),v.end())
#define    dsort(v)        sort(v.rbegin(),v.rend())
#define    pll             pair<ll,ll>
#define    vpl             vector<pll> 
#define    rev(v)          reverse (v.begin(),v.end())
#define    upb(vec, val)   ((upper_bound((vec).begin(), (vec).end(), (val))) - (vec).begin())
#define    lwb(vec, val)   ((lower_bound((vec).begin(), (vec).end(), (val))) - (vec).begin())
#define    sl              set<ll> 
#define    spl             set<pll> 
#define    in              insert
#define    c1              __builtin_popcountll

const int N = 5000+10;
const ll mod = 1e9 + 7;

ll cnt[N], f[N], mob[N], pow2[N];

void mobius() {
    mob[1] = 1;
    for (ll i = 2; i < N; i++) {
        mob[i]--;
        for (ll j = i + i; j < N; j += i) {
            mob[j] -= mob[i];
        }
    }
}

ll exp(ll b , ll p){

  ll res=1;
  while(p){
    if(p&1) res=(res*b)%mod;
    b=(b*b)%mod;
    p>>=1ll;
  }

  return res;
}

ll fact[N], mod_inv[N];

void preprocess() {

    fact[0] = 1;
    for(ll i = 1; i < N; i++) fact[i] = (fact[i - 1] * i) % mod;
    
    mod_inv[N- 1] = exp(fact[N - 1], mod - 2);
    for (ll i = N - 2; i >= 0; i--)  mod_inv[i] = (mod_inv[i + 1] * (i + 1)) % mod;
    
}

ll nCr(ll n, ll r){
  if(n<r) return 0;
  if(r==0) return 1;
  return fact[n]%mod*mod_inv[r]%mod*mod_inv[n-r]%mod ;
}

int main() {
    fast_io;

    #ifndef ONLINE_JUDGE
      freopen("input.txt", "r", stdin);
      freopen("output.txt", "w", stdout);
    #endif

    ll q;
    cin>>q;
    while(q--){
       
      ll n , m;
      cin>>n>>m;
      vl v(n) , id(n,0);

      for(auto &d:v) cin>>d;

      for(ll d,i=0;i<m;i++){
        cin>>d;
        d--;
        id[d]=1;
      }

      ll sum=0 , mx=0 , cnt=0 , i=0;
    
        for(i=0;i<n-1;i++){
          if(id[i]){
            if(cnt%2)cnt++;
            sum+=cnt;
            mx=max(mx,cnt);
            cnt=0;
            break;
          }
          if(v[i]!=v[i-1])cnt++;
        }
        if(cnt){
            if(cnt%2)cnt++;
            sum+=cnt;
            mx=max(mx,cnt);
            cnt=0;
            i++;
        }

        i++;
        for( ;i<n;i++){
          if(id[i]){
            if(cnt%2)cnt++;
            sum+=cnt;
            mx=max(mx,cnt);
            cnt=0;
          }
          else if(v[i]!=v[i-1]) cnt++;
        }

        if(cnt%2)cnt++;
        sum+=cnt;
        mx=max(mx,cnt);


        cout<<max(mx,sum/2)<<endl;
        

    }
    return 0;
}