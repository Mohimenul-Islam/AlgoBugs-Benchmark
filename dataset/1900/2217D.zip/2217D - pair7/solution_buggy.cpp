#include <bits/stdc++.h>
using namespace std;
typedef vector<int> vi;
#define rep(i,a,b) for(int i = a; i < b; i++)
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while(t--){
        int n,k;
        cin >> n >> k;
        vi ar(n);
        set<int> specials;;
        rep(i,0,n){
            cin >> ar[i];
        }
        int target;
        rep(i,0,k){
            int tp;
            cin >> tp;
            tp--;
            if(i == 0) target = ar[tp];
            specials.insert(tp);
        }
        
        int ans = 0;
        int ct = 0;
        bool decreasing = false;
        bool free1 = false, free2 = false;
        bool done = false;
        rep(i,0,n){
            if(i == 0 || ar[i-1] == target){
                if(ar[i] != target){
                    if(decreasing){ 
                        ct--;
                        if(ct == 0){
                            free1 = true;
                            decreasing = false;
                        }
                        continue;
                    }
                    else if(free1 && free2){
                        ans += 1;
                        done = true;
                    }
                    else ct++;
                    free1 = false;
                    free2 = false;
                }
            }
            if(specials.count(i) && !decreasing){
                if(free1) free2 = true;
                ans += 2 * ct;
                decreasing = ct > 0;
            }
        }
        if(!decreasing)
            ans += 2 * ct;
            if(ct > 0 && done) ans--;
        cout << ans << endl;
    }
}