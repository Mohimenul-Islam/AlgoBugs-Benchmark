#include <bits/stdc++.h>
using namespace std;
typedef vector<int> vi;
#define rep(i,a,b) for(int i = a; i < b; i++)
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while(t--){
        int n,m;
        cin >> n >> m;
        vi bs(n); rep(i,0,n) cin >> bs[i];
        vi stars(m + 1); rep(i,0,m) cin >> stars[i];
        stars[m] = -1;
        int target = bs[stars[0]-1];
        priority_queue<int, vector<int>, less<int>> pq;
        int ans = 0;
        int cur = 0;
        int j = 0;
        bool is_0 = false;
        rep(i,0,n){
            int x = bs[i];
            if(x != target){
                if(!is_0){
                    cur += 2;
                    is_0 = true;
                }
            }else{
                is_0 = false;
                if(stars[j] == i + 1){
                    if(cur > 0){
                        pq.push(cur);
                        cur = 0;
                    }
                    j++;
                }
            }
        }
        if(cur > 0){
            pq.push(cur);
        }
        while(pq.size()){
            int x = pq.top();
            pq.pop();
            if(pq.size() == 0){
                ans += x;
            }
            else{
                int y = pq.top();
                pq.pop();
                ans++;
                x--; y--;
                if(x > 0) pq.push(x);
                if(y > 0) pq.push(y);
            }
        }
        cout << ans << endl;
    }
}