#include<bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
using namespace __gnu_pbds;
using namespace std;
typedef tree<int, null_type, less_equal<int>, rb_tree_tag,tree_order_statistics_node_update> ordered_multiset;
#define ll long long
#define int ll
#define str string
#define vll __int128
#define nl "\n" 
#define pii pair<int,int>
#define vi vector<int>
long long mod=1e9+7;
long long mod2=998244353;
// int get_random(){
//     random_device rd;
//     mt19937_64 gen(rd());
//     uniform_int_distribution<int> distrib(0, LONG_LONG_MAX);
//     return distrib(gen);
// }
// long long modpow(long long a, long long b,long long m){
//     if(b==0) return 1%m;
//     long long temp=modpow(a,b/2,m);
//     long long result=(temp*temp)%m;
//     if(b%2==1) result=(result*a)%m;
//     return result;
// }
// vector<int> minprime(2e7);
// vector<int> primes;
// void sieve(){
//     iota(minprime.begin(),minprime.end(),0);
//     for(int i=2;i*i<2e7;i++){
//         if(minprime[i]==i){
//             for(int j=i;j<2e7;j+=i){
//                 if(minprime[j]==j)minprime[j]=i;
//             }
//         }
//     }
// }
// bool cmp(pair<int,int>&a,pair<int,int>&b){
//     if(a.first==b.first)return a.second>b.second;
//     return a.first<b.first;
// }
// vector<int> fact(2e6,1);
// ll inv(ll a, ll p){
//     return modpow(a, p-2,p);
// }
// ll nCk(ll n, ll k, ll p){
//     return ((fact[n] * inv(fact[k], p) % p) * inv(fact[n-k], p)) % p;
// }
// ll lcm(ll a,ll b){
//     return 1LL*a*b/__gcd(a,b);
// }
/*

     
*/
void solve(){
    int n,k;
    cin>>n>>k;
    vector<int> arr(n),sp(k);
    for(auto &i:arr)cin>>i;
    for(auto &i:sp)cin>>i;
    vector<int> b(n+2);
    b.front()=1;
    b.back()=1;
    for(int i=1;i<=n;i++){
        if(arr[i-1]==arr[sp.front()-1]){
            b[i]=1;
        }
    }
    int cnt=0;
    int ind=0;
    int tot=0;
    int mx=0;
    for(int i=1;i<n+2;i++){
        if(b[i]!=b[i-1]){
            cnt++;
        }
        if(ind<k && i==sp[ind]){
            mx=max(mx,cnt);
            tot+=cnt;
            ind++;
            cnt=0;
        }
    }
    mx=max(mx,cnt);
    tot+=cnt;
    cout<<max(mx,tot/2)<<nl;
}
int32_t main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int t=1,tt=1;
    cin>>t;
    while(t--){
        // cout<<"Case #"<<tt++<<": ";
        solve();
        
    }    
    return 0;
}