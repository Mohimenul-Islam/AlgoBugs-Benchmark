#include <bits/stdc++.h>
using namespace std;
using i64=long long;
using i128=__int128;
#define ll long long 
#define poly vector<ll>
#define frac pair<ll,ll>

namespace DBG
{
    template <class T>
    ostream& operator << (ostream& os,const vector<T> &v)
    {
        os<<"[ ";
        for (int i=0;i<v.size();i++)
        {
            os<<v[i];
            if (i+1<v.size())
                os<<", ";
        }

        os<<" ]";
        return os;
    }

    template <class T,size_t N>
    ostream& operator << (ostream& os,const array<T,N> &v)
    {
        os<<"[ ";
        for (int i=0;i<v.size();i++)
        {
            os<<v[i];
            if (i+1<v.size())
                os<<", ";
        }

        os<<" ]";
        return os;
    }

    template <class T>
    void _dbg(const char *f,T t)
    {
        cerr<<f<<'='<<t<<'\n';
    }

    template <class A,class... B>
    void _dbg(const char *f,A a,B... b)
    {
        while (*f!=',') cerr<<*f++;
        cerr<<'='<<a<<',';
        _dbg(f+1,b...);
    }

    #define dbg(...) _dbg(#__VA_ARGS__, __VA_ARGS__)
}

using namespace DBG;

void R()
{
    ll n,k;
    cin>>n>>k;
    poly s(n+2);
    ll dl,dr;
    dl=dr=0;
    ll ans=0;
    for(int i=1;i<=n;i++) cin>>s[i];
    poly pos(k+2);
    for(int i=1;i<=k;i++) cin>>pos[i];
    s[0]=s[n+1]=s[pos[1]];
    pos[k+1]=n+1;
    for(int i=0;i<=k;i++){
        i64 res=0;
        for(int j=pos[i];j<pos[i+1];j++){
            if(s[j]!=s[j+1]){
                res++;
            }
        }
        dl=max(dl,res);
        res>>=1;
        ans+=res;
    }
    ans=max(ans,dl);
    cout<<ans<<"\n";
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    i64 T=1;
    cin>>T;
    while (T--) R();
    return 0;
}