#include <bits/stdc++.h>
#define sz size()
#define bk back()
#define fi first
#define se second

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int t;
    cin >> t;

    while (t--) {
        int n, m;
        cin >> n >> m;

        vector<int> v(n + 2);
        for (int i = 1; i <= n; i++)
            cin >> v[i];

        vector<int> w(m);
        for (int i = 0; i < m; i++)
            cin >> w[i];

        v[0] = v[w[0]];
        v[n + 1] = v[w[0]];

        int sum = 0;
        int mx = 0;
        int k = 0;
        int idx = 0;
        for (int i = 1; i <= n + 1; i++) {
            if (v[i - 1] != v[i])
                k++;

            if (i == w[idx]) {
                sum += k;
                mx = max(mx, k);
                k = 0;
                idx++;
            }
        }
        sum += k;
        mx = max(mx, k);

        cout << max(sum / 2, mx) << '\n';
    }
}