#include<bits/stdc++.h>
using namespace std;

typedef long long int ll;
typedef long double ld;
typedef vector<ll> vi;
typedef vector<vi> vvi;
typedef pair<ll,ll> pl;
typedef priority_queue<ll, vi> pq;
typedef priority_queue<ll, vi, greater<ll> > pqm;
typedef unordered_map<ll, ll> um;

#define mul(a,b) (((a) * (b)) % MOD)
#define mod(a) ((a % MOD + MOD) % MOD)
#define fori(i,a,b) for(ll i=a;i<b;i++)
#define ford(i,a,b) for(ll i=a;i>b;i--)
#define getv(a) for(auto &x : a) cin>>x;
#define putv(a) {for(auto &x : a) cout<<x<<" "; cout<<"\n";}
#define ub(a, s) upper_bound(a.begin(), a.end(), s)
#define all(a) a.begin(), a.end()
#define check cout<<"yo"<<flush;
#define MAXN 10000001
#define MOD 998244353

void solve() {
    ll n, k, s = 0, x = 0, y;
    char c = '1';
    cin>>n>>k;
    vector<char> a(n);
    vi p(k+2); p[0] = 1; p[k+1] = n;
    getv(a);
    fori(i,0,k) cin>>p[i+1];
    fori(i,0,k+1) {
        y = 0;
        fori(j,p[i],p[i+1]) {
            if(a[j] != c) y++;
            c = a[j];
        }
        y += y&1;
        s += y;
        x = max(x, y);
    }
    cout<<max(s/2, x)<<"\n";
}

int main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    #ifndef ONLINE_JUDGE
    freopen("./input.txt", "r", stdin);
    freopen("./output.txt", "w", stdout);
    #endif
    ll t; cin>>t; while(t--) solve();
    return 0;
}
