#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define ull unsigned long long
#define eb emplace_back
#define ff first
#define ss second
const int N=2e5+5;
int T,n,K,a[N],b[N],vis[N],vis2[N],len[N];
int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	cin>>T;
	while(T--){
		cin>>n>>K;
		for(int i=1;i<=n;i++)cin>>a[i],vis[i]=vis2[i]=0;
		for(int i=1;i<=K;i++)cin>>b[i],vis[b[i]]=1;
		if(a[b[1]])for(int i=1;i<=n;i++)a[i]^=1;
		int ind=1;
		while(!a[ind]&&ind<=n)ind++;
		if(ind>n){cout<<"0\n";continue;}
		int m=0;
		for(int i=ind;i<=n;i++){
			if(a[i]!=a[i-1])m++;
			if(vis[i])vis2[m]=1;
		}
//		if(!(m&1))m--;
		int t=0,lst=0;
		for(int i=1;i<=m;i++){
			if(vis2[i])len[++t]=i-lst,lst=i;
		}
		len[++t]=m+1-lst;
		if(m%2==0)len[t]--;
		int sum=0;
		for(int i=1;i<=t;i++)sum+=len[i];
		int mx=*max_element(len+1,len+t+1);
		cout<<max(sum/2,mx)<<'\n';
	}
	return 0;
}