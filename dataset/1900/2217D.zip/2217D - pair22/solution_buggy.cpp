#include<bits/stdc++.h>
#define ll long long
#define N 11000
using namespace std;
const int mod=10086001;
struct tool
{
	inline ll read()
	{
		ll x=0,f=1;
		char ch;
		ch=getchar();
		while(ch>'9'||ch<'0')
		{
			if(ch=='-') f=-1;
			ch=getchar(); 
		}
		while('0'<=ch&&ch<='9')
		{
			x*=10;
			x+=ch-'0';
			ch=getchar();
		}
		return x*f;
	} 
	void write(ll x)
	{
		if(x/10) write(x/10);
		putchar(x%10+'0');
	}
	void print(ll x)
	{
		if(x) write(x);
		else putchar('0');
		putchar('\n');
	}
}t;
ll T=1,n,k,x,ans=0;
ll a[N],p[N],num[N];
void scan()
{
	n=t.read(),k=t.read();
	for(int i=1;i<=n;i++) a[i]=t.read();
	for(int i=1;i<=k;i++) p[i]=t.read();
}
void solve()
{
	ll x=0,s=0,now=0;
	a[0]=a[n+1]=a[p[1]];
	p[k+1]=n+1;
	for(int i=1;i<=k+1;i++)
	{
		ll cnt=0;
		while(now<p[i])
		{
			if(a[now]!=a[now+1])cnt+=1;
			now++; 
		}
		s+=cnt;
		x=max(x,cnt);
	}
	cout<<max(s/2,x)<<"\n";
}
void print()
{
	
}
int main()
{
//	freopen("T1.in","r",stdin);
//	freopen("T1.out","w",stdout);
//	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	T=t.read();
	while(T--)
	{
		scan();
		solve();
		print();
	}
	return 0;
} 