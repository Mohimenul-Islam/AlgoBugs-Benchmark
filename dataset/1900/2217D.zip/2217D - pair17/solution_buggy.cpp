#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back

void solve()
{
    ll n,k;
    cin>>n>>k;
    ll a[n],b[k];

    vector<ll>v(n);
    char x='1';
    for(int i=0;i<n;i++)cin>>a[i];
    for(int i=0;i<k;i++){
        cin>>b[i];
        b[i]--;
        v[b[i]]=1;
        x=a[b[i]];
    }

    vector<ll>vv(n);

    for(int i=0;i<n;i++){
        if(v[i]){
            ll j=i+1;
            for(;j<n;j++){
                if(a[j]!=x){
                    break;
                }
                v[j]=1;
            }
            i=j-1;
            vv[i]=1;
        }
    }

    vector<ll>suff(n+5);
    for(int i=n-1;i>=0;i--){
        suff[i]=suff[i+1];
        if(a[i]!=x)suff[i]++;
    }

    // for(int i=0;i<n;i++){
    //     cout<<vv[i]<<" ";
    // }
    // cout<<endl;

    ll cnt=0,st=0,ans=0;

    for(int i=0;i<n;i++){
        if(a[i]==x){ 
            if(vv[i]){
                if(cnt>0){
                    ans+=(2*cnt);
                    ll j=i+1;
                    ll on=1;
                    while(j<n&&a[j]!=x)j++;
                    while(j<n&&a[j]==x)j++;
                    while(j<n&&on&&suff[j]>0){
                        on=0;
                        ans++;
                        for(;j<n;j++){
                            if(a[j]==x){
                                while(j<n&&a[j]==x){
                                    if(vv[j])on=1;
                                    j++;
                                }
                                break;
                            }
                        }
                    }
                    i=j-1;
                }
                cnt=0;
            }
            st=0;
        }
        else{
            if(!st)cnt++;
            st=1;
        }
    }
    ans+=cnt*2;
    cout<<ans<<endl;


// 010101
// 010101
// 0001001010111010101101010101010101010

// 2 + 1 +
// 1 1 [1] 1 1 1 1 1 1 1 [1] 1 [1] 1 1


}
int main()
{
    ios_base::sync_with_stdio(false); 
    cin.tie(0);cout.tie(0);
    ll t=1;
    cin>>t;
    while(t--)solve();
}