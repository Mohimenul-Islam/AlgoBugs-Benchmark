#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back

void solve()
{
    ll n,k;
    cin>>n>>k;
    ll a[n+1],b[k];

    vector<ll>v(n+1);
    ll x=1;
    for(int i=0;i<n;i++)cin>>a[i];
    for(int i=0;i<k;i++){
        cin>>b[i];
        b[i]--;
        v[b[i]]=1;
        x=a[b[i]];
    }
    a[n]=0;
    if(x==1){
        for(int i=0;i<n;i++){
            a[i]=a[i]^1;
        }
    }
    v[n]=1;
    vector<ll>d(n+1);
    d[0]=a[0];
    for(int i=1;i<=n;i++){
        d[i]=(a[i-1]^a[i]);
    }
    vector<ll>vp;
    ll ans=0;
    for(int i=0;i<n;i++){
        // cout<<i<<":";
        ll j=i;
        ll cnt=0;
        while(true){
            cnt+=d[j];
            if(v[j])break;
            j++;
        }
        i = j;
        vp.pb(cnt);
        ans+=cnt;
    }
    sort(vp.begin(),vp.end());
    // for(auto g:vp)cout<<g<<" ";
    // cout<<endl;
    cout<<max(vp.back(),((ans+1)/2))<<endl;
}
int main()
{
    ios_base::sync_with_stdio(false); 
    cin.tie(0);cout.tie(0);
    ll t=1;
    cin>>t;
    while(t--)solve();
}