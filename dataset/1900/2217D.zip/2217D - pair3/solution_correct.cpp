#include<cstdio>
#include<algorithm>
using namespace std;
const int N=200005;
int n,k,a[N],b[N],p[N];
inline void solve(){
	scanf("%d%d",&n,&k);
	for (int i=1;i<=n;i++) scanf("%d",&a[i]);
	for (int i=1;i<=k;i++) scanf("%d",&p[i]);
	p[++k]=n+1;
	int x=a[p[1]];
	for (int i=1;i<=n;i++) a[i]^=x;
	b[1]=a[1];
	for (int i=2;i<=n;i++) b[i]=a[i-1]^a[i];
	b[n+1]=a[n];
	int now=0,ptr=1,mx=-1,ans=0;
	for (int i=1;i<=k;i++){
		while (ptr<=p[i]){
			now+=b[ptr];
			ptr++;
		}
		mx=max(mx,now);
		ans+=now;
		now=0;
	}
	printf("%d\n",max(ans>>1,mx));
}
int main(){
	int T;scanf("%d",&T);
	while (T--) solve();
	return 0;
} 