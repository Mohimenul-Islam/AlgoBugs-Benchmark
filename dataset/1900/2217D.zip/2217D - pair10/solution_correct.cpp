#include <bits/stdc++.h>
#define ll long long
#define db double
#define ld long double
#define mp make_pair
using namespace std;

typedef pair<ll, ll> PII;
typedef pair<ll, pair<ll,ll>> PIII;
typedef array<ll ,3> arr;

const ll N = 1e6 + 5, U = 1e6, M = 998244353;

struct dr {
    ll a,b,c;
};

void work() {
    int n, k;
    cin >> n >> k;

    vector<PII> a(n), b, c;

    for(int i = 0; i < n; i++){
        cin >> a[i].first;
    }

    int flag = 0;

    for(int i = 0; i < k; i++){
        int t;
        cin >> t;
        a[t - 1].second = 1;
        flag = a[t - 1].first;
    }

    b.emplace_back(a[0]);

    for(int i = 1; i < n; i++){
        if(a[i].first != b.back().first) {
            b.emplace_back(a[i]);
        } else {
            b.back().second = max(b.back().second, a[i].second);
        }
    }

    if(flag != b[0].first) {
        c.emplace_back(mp(flag, 0));
    }

    for(auto e : b) {
        c.emplace_back(e);
    }

    if(c.back().first != flag) {
        c.emplace_back(mp(flag, 0));
    }

    b = c;
    n = b.size();

    vector<int> q;

    for(int i = 0; i < n; i++){
        if(b[i].second){
            q.emplace_back(i);
        }
    }

    int tot = n - 1;
    int mx = 0;
    int last = 0;

    for(auto e : q){
        mx = max(mx, e - last);
        last = e;
    }

    mx = max(mx, n - 1 - last);

    int ans = tot / 2 + max(0, mx - (tot - mx)) / 2;

    cout << ans << endl;
}

int main() {    
    ll tt;
    ios::sync_with_stdio(0);
    cin >> tt;

    while (tt--) {
        work();
    }

    return 0;
}