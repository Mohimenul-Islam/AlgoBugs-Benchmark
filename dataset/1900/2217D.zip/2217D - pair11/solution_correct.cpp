#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define rall(x) (x).rbegin(),(x).rend()
#define srt(x) sort(all(x))
#define rev(x) reverse(all(x))
#define rsrt(x) sort(rall(x))
#define sz(x) (int)(x.size())
#define lb(v,x) (int)(lower_bound(all(v),x)-v.begin())
#define ub(v,x) (int)(upper_bound(all(v),x)-v.begin())
#define uni(v) v.resize(unique(all(v))-v.begin())
#define FOR(i, s, n) for (int i = s; i < n; i++)
#define FORR(i, s, n) for (int i = n - 1; i >= s; i--)

using ll = long long; 
using ld = long double;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using vpii = vector<pii>;
using vpll = vector<pll>;
using vvi = vector<vi>;
using vvll = vector<vll>;
using qi = queue<int>;
using vc = vector<char>;
using vvc = vector<vc>;
using vs = vector<string>;
using vb = vector<bool>;
using vvb = vector<vb>;
using vf = vector<float>;
using vvf = vector<vf>;
using vd = vector<double>;
using vvd = vector<vd>;

constexpr ll MOD = 998244353;
constexpr ll BIG18 = 1e18;
constexpr ll BIG9 = 1e9;
constexpr int MX = (int)2e5+5;

void solve() {
    int n, k;
    cin >> n >> k;
    vector<int> arr(n+2);
    for (int i = 1; i <= n; i++) {
        cin >> arr[i];
    }
    vector<int> pivots(k+2);
    for (int i = 1; i <= k; i++) {
        cin >> pivots[i];
    }
    arr[0] = arr[n+1] = arr[pivots[1]];
    pivots[k+1] = n+1;
 
    int S = 0, X = 0;
    for (int i = 0; i <= k; i++) {
        int count = 0;
        for (int j = pivots[i]; j < pivots[i+1]; j++) {
            if (arr[j] != arr[j+1]) {
                count++;
            }
        }
        S += count;
        X = max(X, count);
    }
 
    cout << max(S / 2, X) << "\n";
}

int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);

    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }    
    return 0;
}