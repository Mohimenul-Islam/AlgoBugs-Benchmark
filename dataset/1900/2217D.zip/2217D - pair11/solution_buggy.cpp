#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define rall(x) (x).rbegin(),(x).rend()
#define srt(x) sort(all(x))
#define rev(x) reverse(all(x))
#define rsrt(x) sort(rall(x))
#define sz(x) (int)(x.size())
#define lb(v,x) (int)(lower_bound(all(v),x)-v.begin())
#define ub(v,x) (int)(upper_bound(all(v),x)-v.begin())
#define uni(v) v.resize(unique(all(v))-v.begin())
#define FOR(i, s, n) for (int i = s; i < n; i++)
#define FORR(i, s, n) for (int i = n - 1; i >= s; i--)

using ll = long long; 
using ld = long double;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using vi = vector<int>;
using vll = vector<ll>;
using vpii = vector<pii>;
using vpll = vector<pll>;
using vvi = vector<vi>;
using vvll = vector<vll>;
using qi = queue<int>;
using vc = vector<char>;
using vvc = vector<vc>;
using vs = vector<string>;
using vb = vector<bool>;
using vvb = vector<vb>;
using vf = vector<float>;
using vvf = vector<vf>;
using vd = vector<double>;
using vvd = vector<vd>;

constexpr ll MOD = 998244353;
constexpr ll BIG18 = 1e18;
constexpr ll BIG9 = 1e9;
constexpr int MX = (int)2e5+5;

void solve(){
    //write here
    int n, k;
    cin >> n >> k;
    vi a(n), p(k);
    FOR(i, 0, n)
        cin >> a[i];
    FOR(i, 0, k){
        cin >> p[i];
        p[i]--;
    }

    int ans = 0;
    int l = 0;
    bool b = a[p[0]];
    vi x;
    x.pb(a[0] == b ? 1 : 0);
    if (0 == p[l]){
        l++;
        x[0] = 2;
    }
    FOR(i, 1, n){
        if (a[i] != a[i - 1]){
            x.pb(a[i] == b);
        }
        if (l < k && i == p[l]){
            l++;
            x[x.size() - 1] = 2;
        }
    }
    int N = x.size();
    int c1 = 0, c2 = 0;
    vpii y;
    FOR(i, 0, N){
        if (x[i] == 0){
            if ((i > 0 && x[i - 1] == 2) || (i < N - 1 && x[i + 1] == 2)){
                c1++;
                if (c2 > 0){
                    y.pb({2, c2});
                }
                c2 = 0;
            }else{
                c2++;
                if (c1 > 0){
                    y.pb({1, max(c1, 2)});
                }
                c1 = 0;
            }
        }
    }
    if (c2 > 0)
        y.pb({2, c2});
    if (c1 > 0)
        y.pb({1, max(c1, 2)});
    N = y.size();

    FOR(i, 0, N){
        if (y[i].first == 1){
            ans += y[i].second;
        }else{
            ans += y[i].second * 2 - ((i > 0 && y[i - 1].second > 2) || (i < N - 1 && y[i + 1].second > 2));
        }
    }
    cout << ans << endl;      
}
int main(){
    ios_base::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);

    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }    
    return 0;
}