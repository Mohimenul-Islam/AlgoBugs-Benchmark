#include <bits/stdc++.h>
#define ll long long
//#define int long long
#define IOS ios::sync_with_stdio(false);cin.tie(nullptr);
#define endl '\n' 
#define pii pair<int,int>
#define pll pair<ll,ll>
const int INF = 0x3f3f3f3f;
const ll INFLL = 0x3f3f3f3f3f3f3f3f;
const double PI = acos(-1.0);
using namespace std;
//ifstream fin("input.txt");
//ofstream fout("output.txt");
//#define cin fin
//#define cout fout

int n,k;
const int N = 2E5+5;
int a[N],b[N],p[N];


void solve() {
    cin>>n>>k;
    for(int i=1;i<=n;i++) cin>>a[i];
    for(int i=1;i<=k;i++) cin>>p[i];
    int x = a[p[1]];
    for(int i=1;i<=n;i++) {
        b[i] = (a[i] == x ? 1 : 0);
    }
    b[n+1] = 1;
    vector<int> bound;int tot =0;
    for(int i=1;i<=n;i++) {
        if(b[i] != b[i+1]) {
            bound.push_back(i);
            tot++;
        }
    }
    int seg1 = lower_bound(bound.begin(),bound.end(),p[1]) - bound.begin();
    int maxseg = seg1;
    for(int i=1;i<k;i++) {
        int seg = (lower_bound(bound.begin(),bound.end(),p[i+1]) - lower_bound(bound.begin(),bound.end(),p[i]));
        maxseg = max(maxseg,seg);
    }
    int segn = bound.end() - lower_bound(bound.begin(),bound.end(),p[k]);
    maxseg = max(maxseg,segn);
    cout << max(tot/2,maxseg) << endl;

}

signed main()
{
    IOS
    int t;cin>>t;
    while (t--)
    {
        solve();
    }
    
    //fin.close(),fout.close();
    return 0;
}
