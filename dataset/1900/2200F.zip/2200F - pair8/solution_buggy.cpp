//########

//WhySoSerious16 ;)

//########

#include <vector>
using namespace std;
#include <iostream>
#include <string>
#include <bits/stdc++.h>
#include <map>
#include <algorithm>
#include <cmath>
#include <queue>
#define pb push_back
#define pbk pop_back
#define bk back
#define lbb lower_bound
#define ubb upper_bound
#define sz(x) lli(x.size())
#define precision(x) fixed << setprecision(x)
#define fast ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
#define all(a) (a).begin(), (a).end()
#define sortf(x) sort(all(x))
#define rall(a) (a).rbegin(), (a).rend()

#define rep0(i, n) for (int i = 0; i < (n); i++)
#define rep1(i, n) for (int i = 1; i <= (n); i++)
#define rep2(i, n) for (int i = 2; i <= (n); i++)
#define repr(i, n) for (int i = (n); i >= 1; i--)
#define repr0(i, n) for (int i = (n)-1; i >= 0; i--)
#define repmf(i, a, b) for (int i = (a); i<=(b); i++)
#define repmb(i, a, b) for (int i = (b); i>=(a); i--)
#define repmfk(i, a, b, k) for (int i = (a); i<=(b); i+=k)
#define repmbk(i, a, b, k) for (int i = (b); i>=(a); i-=k)

#define rep0l(i, n) for (lli i = 0; i < (n); i++)
#define rep1l(i, n) for (lli i = 1; i <= (n); i++)
#define rep2l(i, n) for (lli i = 2; i <= (n); i++)
#define reprl(i, n) for (lli i = (n); i >= 1; i--)
#define repr0l(i, n) for (lli i = (n)-1; i >= 0; i--)
#define repmfl(i, a, b) for (lli i = (a); i<=(b); i++)
#define repmbl(i, a, b) for (lli i = (b); i>=(a); i--)
#define repmfkl(i, a, b, k) for (lli i = (a); i<=(b); i+=k)
#define repmbkl(i, a, b, k) for (lli i = (b); i>=(a); i-=k)

#define fi first
#define se second
#define lmao(v,n,m) v.resize(n+1); fill(all(v),m);
#define inra() cout << "!" << ' '
#define inrq() cout << "?" << ' '
#define chop(x) cout << ((x) ? "Yes" : "No") << endl
#define chopc(x) cout << ((x) ? "YES" : "NO") << endl
#define opn(x) cout << (x) << endl
#define ops(x) cout << (x) << ' '
#define opnt(x) cout << (x)
#define opx() cout << endl
 
using lli = long long;
using ull = unsigned long long;
using ld = long double;
 
using vi = vector<int>;
using vl = vector<lli>;
using vpi = vector<pair<int, int>>;
using vpl = vector<pair<lli,lli>>;
using vvi = vector<vi>;
using vvl = vector<vl>;

lli xx = lli(1e9+7);
lli xxx = 998244353;
 
template<class T> void ckmin(T& a, T& b){if (b < a) swap(a,b);}
template<class T> void ckmax(T& a, T& b){if (b > a) swap(a,b);}
template<class T> void chmin(T& a, T b) {if (b < a) a = b;}
template<class T> void chmax(T& a, T b) {if (b > a) a = b;}
template<class T> T mag(T a) {if (a > 0) return a; return -1*a;}

template<class T> T mymax(T a, T b) {return max(a,b);}
template<class T> T mymin(T a, T b) {return min(a,b);}
template<class T> T mygcd(T a, T b) {return gcd(a,b);}
template<class T> T mysum(T a, T b) {return a+b;}

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());


// what is the constraint on y's of the chosen subsets ??
// min(y) should be >= size of subset ?? thats all
// if we fix a particle i among n, we can only choose max y[i] elements whose y is >= y;
// 

lli n,m;
vl dp;
vvl qu,d;
vl ans;
priority_queue<lli,vl,greater<lli>> r,s;
lli mx = 1e18, tot;
lli cr,cs;

void solve(){

  cin >> n >> m;
  lmao(d,n,vl(2,-1));
  lmao(qu,m,vl(3,-1));
  lmao(ans,m,0);
  lmao(dp,n,0);
  r = s = {};
  cr = cs = 0;
  tot = 0;

  rep1(i,n) cin >> d[i][1] >> d[i][0];
  sortf(d);

  rep1(i,m) {

    cin >> qu[i][1] >> qu[i][0];
    qu[i][2] = i;

  }

  sortf(qu);
  lli pq = m;

  // r is for current
  // s is for qu

  repr(i,n) {

    s.push(d[i][1]);
    cs += d[i][1];

    if (d[i][0] != d[i-1][0]) {

      while (pq) {

        vl nv = qu[pq];

        if (nv[0] > d[i][0]) pq--;

        else if (nv[0] <= d[i-1][0]) break;

        else {

          while (sz(s) > nv[0]) {cs -= s.top(); s.pop();}
          chmax(ans[nv[2]],cs+nv[1]);
          pq--;

        }

      } 

    }

    while (sz(r) > d[i][0]) {cr -= r.top(); r.pop();}
    chmax(tot,d[i][1]+cr);
    lli cm = d[i][1];
    if (sz(r)) chmin(cm,r.top());
    if (sz(r) < d[i][0]) cm = 0;
    dp[i] = d[i][1] + cr - cm;
    if (d[i][0] == 0) dp[i] = -mx;
    r.push(d[i][1]); cr += d[i][1];

  }

  pq = 1;
  lli mdp = -mx;
  d.pb(vl(3,mx));
  dp[0] = -mx;

  rep0(i,n+1) {

    chmax(mdp,dp[i]);

    while (pq <= m) {

      vl nv = qu[pq];

      if (nv[0] == 0) chmax(ans[nv[2]],nv[1]);

      else if (nv[0] <= d[i][0]) {;}

      else if (nv[0] <= d[i+1][0]) chmax(ans[nv[2]],nv[1]+mdp);

      else break;

      pq++;

    }

  }

  rep1(i,m) chmax(ans[i],tot);
  rep1(i,m) ops(ans[i]); opx();

}


int main(){

  fast;

  int t; cin>>t;

  while(t--){

    solve();

  }
  
}
