#include<bits/stdc++.h>
#define ll long long
#define i128 __int128
#define pa pair<int,int>
#define tp tuple<int,int,int>
#define inf (1e9+5e5)
#define N 100010
#define mid ((l+r)>>1)
#define rep(d,o,p) for(int i=o;i<=p;i+=d)
using namespace std;
//保留x位小数输出 cout << std::fixed << std::setprecision( x );
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	int t;cin>>t;
	while(t--){
		int n,m;cin>>n>>m;
		vector<vector<int>>a(n+2);
		rep(1,1,n){
			int x,y;cin>>x>>y;
			y++;
			a[y].push_back(x);
		}
		priority_queue<ll,vector<ll>,greater<ll>>pq;
		vector<ll>f(n+2),mn(n+2);
		ll sum=0;
		for(int i=n+1;i;i--){
			for(int x:a[i])pq.push(x),sum+=x;
			while((int)pq.size()>i) sum-=pq.top(),pq.pop();
			f[i]=sum;
			if(!pq.empty() && pq.size()==i)mn[i]=pq.top();
		}
		vector<ll>g(n+2),fr(n+2);
		ll mx=0;
		for(int i=1;i<=n+1;i++){
			g[i] = f[i]-mn[i];
			fr[i] = max(fr[i-1],g[i]);
			mx=max(mx,f[i]);
		}
		while(m--){
			int x,y;cin>>x>>y;
			y++;
			cout<<max(mx,fr[y]+x)<<' ';	
		}
		cout<<'\n';
		//按y排序，设f为：选上了第i个元素后的最大值
		//f后面部分的y个元素，选取前y个最大值
		//不足y个并不重要，一定会被前者包含
		//此时对于新加入元素{x.y}：
		//对于y以前，必须替换最小值，因此是f[i]-最小值
		//否则可以直接加入，插入最大值
	}
}