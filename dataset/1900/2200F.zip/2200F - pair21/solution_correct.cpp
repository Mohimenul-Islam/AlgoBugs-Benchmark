#include <bits/stdc++.h>
using namespace std;
#define int long long

void solve() {
    int n, m;
    cin >> n >> m;

    vector<vector<int>> p(n + 1);
    for (int i = 0; i < n; i++) {
        int x, y;
        cin >> x >> y;
        p[min(y, n)].push_back(x);
    }

    multiset<int> s;
    int c = 0, b = 0;
    vector<int> f(n + 1, 0);

    for (int y = n; y >= 0; y--) {
        for (int x : p[y]) {
            s.insert(x);
            c += x;
        }

        while (s.size() > y + 1) {
            c -= *s.begin();
            s.erase(s.begin());
        }

        b = max(b, c);

        if (s.size() == y + 1) {
            f[y] = c - *s.begin();
        } else {
            f[y] = c;
        }
    }

    vector<int> g(n + 1, 0);
    g[0] = f[0];
    for (int i = 1; i <= n; i++) {
        g[i] = max(g[i - 1], f[i]);
    }

    for (int i = 0; i < m; i++) {
        int x, y;
        cin >> x >> y;
        y = min(y, n);
        int a = max(b, x + g[y]);
        cout << a << " ";
    }
    cout << "\n";
}

int32_t main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    int t;
    cin >> t;
    while (t--) solve();

    return 0;
}