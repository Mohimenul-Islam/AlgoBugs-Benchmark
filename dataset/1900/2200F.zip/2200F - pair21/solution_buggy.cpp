#include<bits/stdc++.h>
using namespace std;
#define int long long

struct Item {
    int y, x, id;
};

bool cmp(Item a, Item b) {
    if (a.y == b.y) {
        if ((a.id == -1) != (b.id == -1)) {
            return a.id == -1; 
        }
        return a.x > b.x;
    }
    return a.y > b.y;
}

void solve() {
    int n, m;
    cin >> n >> m;

    vector<Item> v;
    for (int i = 0; i < n; i++) {
        int x, y;
        cin >> x >> y;
        v.push_back({y, x, -1});
    }

    for (int i = 0; i < m; i++) {
        int x, y;
        cin >> x >> y;
        v.push_back({y, x, i}); 
    }

    vector<int> ans(m);
    sort(v.begin(), v.end(), cmp);

    multiset<int> ms1;
    multiset<int> ms2;

    int currsum = 0;

    for (int i = 0; i < n + m; i++) {
        auto [y, x, id] = v[i];
        int sp = (id != -1); 
        while (ms2.size() > y + 1) {
            int mini = *ms2.begin();
            currsum -= mini;
            ms1.insert(mini);
            ms2.erase(ms2.begin());
        }

        if (sp == 1) {
            if (ms2.size() == y + 1) {
                int mini = *(ms2.begin());
                if (x >= mini) ans[id] = currsum - mini + x;
                else ans[id] = currsum;
            } else {
                ans[id] = currsum + x;
            }
        } else {
            if (ms2.size() == y + 1) {
                int mini = *(ms2.begin());
                if (x >= mini) {
                    ms2.erase(ms2.begin());
                    currsum += x - mini;
                    ms2.insert(x);
                    ms1.insert(mini);
                } else {
                    ms1.insert(x);
                }
            } else {
                ms1.insert(x);
                while (ms1.size() > 0 && ms2.size() <= y) {
                    auto it = prev(ms1.end());
                    ms2.insert(*it);
                    currsum += *it;
                    ms1.erase(it);
                }
            }
        }
    }

    for (auto i : ans) {
        cout << i << " ";
    }
    cout <<endl;
}

int32_t main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    int t;
    cin >> t;
    while (t--) solve();
}