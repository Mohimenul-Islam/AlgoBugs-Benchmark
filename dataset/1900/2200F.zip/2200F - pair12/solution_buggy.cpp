#include<bits/stdc++.h>
#define int long long
#define rep(i,a,b) for(int i=(a);i<=(int)(b);i++)
#define per(i,a,b) for(int i=(a);i>=(int)(b);i--)
#define inf 1e18
#define all(v) v.begin(),v.end()
using namespace std;

struct node
{
    int x,y,op,num;
};
void solve()
{
    int n,m,sum=0,res=0; cin>>n>>m;
    vector<node> a(n+m);
    vector<int> ans(m,0),val(n+m,-inf);
    rep(i,0,n+m-1)
    {
        int x,y; cin>>x>>y;
        if(i<n) a[i]={x,y,0,0};
        else a[i]={x,y,1,i-n};
    }
    sort(all(a),[](node x,node y){return x.y>y.y;});
    priority_queue<int,vector<int>,greater<int>>pq;
    rep(i,0,n+m-1)
    {
        while((int)pq.size()>a[i].y) sum-=pq.top(),pq.pop();
        if(a[i].op) ans[a[i].num]=sum+a[i].x;
        else
        {
            if(!pq.empty())
            {
                if((int)pq.size()==a[i].y) val[i]=sum-pq.top()+a[i].x;
                else val[i]=sum+a[i].x;
            }
            res=max(res,sum+a[i].x);
        }
        if(!a[i].op) pq.push(a[i].x),sum+=a[i].x;
    }
    per(i,n+m-2,0) val[i]=max(val[i],val[i+1]);
    rep(i,0,n+m-1) if(a[i].op) ans[a[i].num]=max(ans[a[i].num],val[i]+a[i].x);
    for(auto x:ans) cout<<max(x,res)<<" ";
    cout<<"\n";
}
signed main()
{
    ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
    int T; cin>>T;
    while(T--) solve();
    return 0;
}