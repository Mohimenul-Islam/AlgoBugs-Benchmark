#include<bits/stdc++.h>
#define int long long
#define rep(i,a,b) for(int i=(a);i<=(int)(b);i++)
#define per(i,a,b) for(int i=(a);i>=(int)(b);i--)
#define pb emplace_back
#define inf 1e18
#define all(v) v.begin(),v.end()
using namespace std;
using vii=vector<int>;

void solve()
{
    int n,m,ans=0; cin>>n>>m;
    vector<vii> val(n+1);
    rep(i,1,n)
    {
        int x,y; cin>>x>>y;
        val[y].pb(x);
    }
    vector<int> g(n+1,-inf);
    priority_queue<int,vector<int>,greater<int>>pq;
    int sum=0;
    per(i,n,0)
    {
        for(auto x:val[i]) pq.push(x),sum+=x;
        while((int)pq.size()>i+1) sum-=pq.top(),pq.pop();
        ans=max(ans,sum);
        if(!pq.empty())
        {
            if((int)pq.size()==i+1) g[i]=sum-pq.top();
            else g[i]=sum;
        }
    }
    rep(i,1,n) g[i]=max(g[i],g[i-1]);
    rep(_,1,m)
    {
        int x,y; cin>>x>>y;
        cout<<max(ans,g[y]+x)<<" ";
    }
    cout<<"\n";
}
signed main()
{
    ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
    int T; cin>>T;
    while(T--) solve();
    return 0;
}