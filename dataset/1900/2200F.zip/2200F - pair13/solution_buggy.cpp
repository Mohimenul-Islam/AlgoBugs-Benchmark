//thatsramen

#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#define eb emplace_back
#define pb push_back
#define ft first
#define sd second
#define pi pair<int, int>
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define dbg(...) dbg_out(__VA_ARGS__)

using ll = long long;
using ld = long double;
using namespace std;
using namespace __gnu_pbds;

//Constants
const ll INF = 5 * 1e18;
const int IINF = 2 * 1e9;
// const ll MOD = 1e9 + 7;
const ll MOD = 998244353;
const ll dx[4] = {1, 0, -1, 0}, dy[4] = {0, 1, 0, -1};
const ld PI = 3.14159265359;

//Templates
template<typename A, typename B> ostream& operator<<(ostream &os, const pair<A, B> &p) {return os << '(' << p.first << ", " << p.second << ')';}
template<typename T_container, typename T = typename enable_if<!is_same<T_container, string>::value, typename T_container::value_type>::type> ostream& operator<<(ostream &os, const T_container &v) {os << '['; string sep; for (const T &x : v) os << sep << x, sep = ", "; return os << ']';}
void dbg_out() {cerr << endl;}
template<typename Head, typename... Tail> void dbg_out(Head H, Tail... T) { cerr << H << ' '; dbg_out(T...); }
template<typename T> bool mins(T& x, T y) { if (x > y) { x = y; return true; } return false; }
template<typename T> bool maxs(T& x, T y) { if (x < y) { x = y; return true; } return false; }
template<typename T> using oset = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template<typename T> using omset = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>;

//order_of_key(k): number of elements strictly less than k
//find_by_order(k): k-th element in the set

void setPrec() {cout << fixed << setprecision(15);}
void unsyncIO() {cin.tie(0)->sync_with_stdio(0);}
void setIn(string s) {freopen(s.c_str(), "r", stdin);}
void setOut(string s) {freopen(s.c_str(), "w", stdout);}
void setIO(string s = "") {
    unsyncIO(); setPrec();
    if(s.size()) setIn(s + ".in"), setOut(s + ".out");
}

#define TEST_CASES

struct SegmentTree {

    vector<ll> tre;
    int sz;

    SegmentTree(vector<ll> &a) {
        int n = (int) a.size();
        sz = 1;
        while (sz < n) sz *= 2;
        tre.assign(2 * sz, -INF);
        build(a, 1, 0, sz);
    }

    void rcl(int x) {
        tre[x] = max(tre[2 * x], tre[2 * x + 1]);
    }

    void build(vector<ll> &a, int x, int lx, int rx) {
        if (rx - lx == 1) {
            if (lx < a.size()) {
                tre[x] = a[lx];
            }
            return;
        }
        int m = (lx + rx) / 2;
        build(a, 2 * x, lx, m);
        build(a, 2 * x + 1, m, rx);
        rcl(x);
    }

    void set(int i, ll v, int x, int lx, int rx) {
        if (rx - lx == 1) {
            tre[x] = v;
            return;
        }
        int m = (lx + rx) / 2;
        if (i < m) {
            set(i, v, 2 * x, lx, m);
        } else {
            set(i, v, 2 * x + 1, m, rx);
        }
        rcl(x);
    }

    void set(int i, ll v) {
        set(i, v, 1, 0, sz);
    }

    ll get(int l, int r, int x, int lx, int rx) {
        if (rx <= l || lx >= r) {
            return -INF;
        }
        if (l <= lx && r >= rx) {
            return tre[x];
        }
        int m = (lx + rx) / 2;
        ll s1 = get(l, r, 2 * x, lx, m);
        ll s2 = get(l, r, 2 * x + 1, m, rx);
        return max(s1, s2);
    }

    ll get(int l, int r) {
        return get(l, r, 1, 0, sz);
    }
};


void solve() {
    int n, m;
    cin >> n >> m;
    vector<pi> a(n);
    for (int i = 0; i < n; i++) {
        cin >> a[i].ft >> a[i].sd;
    }
    vector<pi> b(m);
    for (int i = 0; i < m; i++) {
        cin >> b[i].ft >> b[i].sd;
    }
    sort(rall(a));
    multiset<int> have;
    vector<vector<int>> del(n + m + 1);
    vector<ll> pp(n + m + 1, -INF);
    pp[0] = 0;
    ll sum = 0, ans = 0;
    for (int i = 1, j = 0; i <= n + m; i++) {
        for (auto x : del[i]) {
            have.erase(have.find(x));
            sum -= x;
        }
        while (j < n && (int)have.size() < i) {
            auto [x, y] = a[j];
            if (y >= i - 1) {
                if (y + 2 <= n) {
                    del[y + 2].pb(x);
                }
                have.insert(x);
                sum += x;
            }
            j++;
        }
        maxs(ans, sum);
        // dbg(i, sum, have);
        pp[i] = sum - (have.size() < i ? 0 : *have.begin());
    }
    // dbg(pp);
    SegmentTree st(pp);
    for (int _ = 0; _ < m; _++) {
        auto [x, y] = b[_];
        ll res = st.get(0, y + 2) + x;
        maxs(res, ans);
        cout << res << ' ';
    }
    cout << '\n';
}

int main() {
    setIO();

    int tt = 1;
    #ifdef TEST_CASES
        cin >> tt;
    #endif

    while (tt--)
        solve();

    return 0;
}