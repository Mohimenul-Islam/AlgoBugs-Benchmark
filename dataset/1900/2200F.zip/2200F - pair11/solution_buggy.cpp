#include<iostream>
#include<cmath>
#include<vector>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
const int N=2e5+10;

vector<int>A[N];
vector<pair<int,int>>B[N];

priority_queue<int,vector<int>,greater<int>>q;

int cmp(int a,int b){
    return a>b;
}

long long ans[N];
int main(){
    int i,n,t,m,x,y;
    cin>>t;
    while(t--){
        cin>>n>>m;
        for(i=0;i<=n;i++){
            A[i].clear();
            B[i].clear();
        }
        while(q.size()) q.pop();

        for(i=1;i<=n;i++){
            cin>>x>>y;
            A[y].push_back(x);
        }
        for(i=1;i<=m;i++){
            cin>>x>>y;
            B[y].push_back({x,i});
        }
    
        long long sum=0,ma=0;
        for(i=n;i>=0;i--){
            sort(A[i].begin(),A[i].end(),cmp);

            while(q.size()>i){
                sum-=q.top();
                q.pop();
            } //cout<<sum<<endl;
            for(auto xx: A[i]){
                ma=max(sum+xx,ma);
                if(q.size()<i){
                    sum+=xx;
                    q.push(xx); 
                }else{
                    if(q.size()&&q.top()<xx){
                        sum=sum-q.top()+xx;
                        q.pop();
                        q.push(xx);
                    }
                }
            }

           

            for(auto xx: B[i]) ans[xx.second]=xx.first+sum;
        }

        for(int i=1;i<=m;i++) cout<<max(ans[i],ma)<<" ";
        cout<<endl;

    }


}
/*
1
1 2
6 1
7 0
8 1
*/