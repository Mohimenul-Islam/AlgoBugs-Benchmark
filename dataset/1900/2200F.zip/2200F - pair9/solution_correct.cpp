#include <iostream>
//#include <bits/stdc++.h>
#include <iomanip>
#include <random>
using namespace std;

typedef  long long ll;
typedef unsigned long long ull;
typedef long double lld;
#include <cassert>
#include <vector>
#include <map>
#include <list>
#include <set>
#include <unordered_map>
#include <unordered_set>



#define fastInputOutput ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
void solve();
void build();
void comp_facts();
void reset();
void sieve(ll n);


int main() {
    fastInputOutput
    ll t;
    t = 1;

 cin >> t;

    //build();

    while (t--) {
        solve();
    }


}


void solve() {

    ll n,m;
    cin >> n >> m;
    vector<pair<ll,ll>> v(n);
    multiset<pair<ll,ll>> all, need;
    for (ll i = 0; i < n; i++) {
        cin >> v[i].first >> v[i].second;
        all.insert(v[i]);
    }

    ll mx = 0;
    ll curr = 0;
    vector<vector<pair<ll,ll>>> here(n+1);
    for (ll i = 0; i <= n; i++) {
        while (need.size() <= i && !all.empty()) {
            pair<ll,ll> a = *all.rbegin();
            if ((a).second < i) {
                all.erase(all.find(a));
                continue;
            }
            need.insert(a);
            curr+= a.first;
            all.erase(all.find(a));
            here[a.second].push_back(a);
        }
        mx = max(mx,curr);
        for (auto a: here[i]) {
            curr-=a.first;
            need.erase(need.find(a));
        }
    }

    vector<ll> ans(n+1,0);

    all.clear(), need.clear();
    for (ll i = 0; i < n; i++) {
        all.insert(v[i]);
    }
    here.clear();
    here.resize(n+1);
    curr = 0;
    for (ll i = 0; i <= n; i++) {
        while (need.size() < i && !all.empty()) {
            if ((*all.rbegin()).second < i) {
                all.erase(all.find(*all.rbegin()));
                continue;
            }
            pair<ll,ll> a = *all.rbegin();
            need.insert(a);
            curr+= a.first;
            all.erase(all.find(a));
            here[a.second].push_back(a);
        }
        ans[i] = curr;
        for (auto a: here[i]) {
            curr-=a.first;
            need.erase(need.find(a));
        }
    }

    for (ll i = 1; i <=n; i++) {
        ans[i] = max(ans[i],ans[i-1]);
    }
    for (ll i = 0; i < m; i++) {
        ll x,y;
        cin >> x >> y;


            cout << max(x + ans[y], mx) << " ";

    }
    cout << endl;


}