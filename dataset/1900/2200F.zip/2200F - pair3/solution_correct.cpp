#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;
typedef long long ll;

struct Particle {
    int x, y;
    Particle() : x(0), y(0) {}
    Particle(int x, int y) : x(x), y(y) {}

    friend bool operator<(const Particle& p1, const Particle& p2) {
        if (p1.y == p2.y) { return p1.x < p2.x; }
        return p1.y < p2.y;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int tc;
    cin >> tc;
    for (int z = 0; z < tc; z++) {
        int n, m;
        cin >> n >> m;
        vector<Particle> has(n), buy(m);
        for (int i = 0; i < n; i++) { cin >> has[i].x >> has[i].y; }
        sort(has.begin(), has.end()); reverse(has.begin(), has.end());
        for (int i = 0; i < m; i++) { cin >> buy[i].x >> buy[i].y; }

        priority_queue<int, vector<int>, greater<int>> pq;
        vector<ll> full(n+10, 0), drop(n+10, 0);
        ll it = 0, temp = 0;
        for (int i = n+1; i > 0; i--) {
            while (it < n && has[it].y >= i-1) {
                pq.push(has[it].x);
                temp += has[it].x; it++;
            }
            while (pq.size() > i) { temp -= pq.top(); pq.pop(); }
            full[i] = drop[i] = temp;
            if (pq.size() == i) { drop[i] -= pq.top(); }
        }
        const ll ans = *max_element(full.begin(), full.end());
        while (!pq.empty()) { pq.pop(); }
        for (int i = 1; i < n+10; i++) { drop[i] = max(drop[i-1], drop[i]); }

        for (int i = 0; i < m; i++) {
            if (i > 0) { cout << " "; }
            cout << max(ans, buy[i].x + drop[buy[i].y + 1]);
        }
        cout << "\n";
    }
    return 0;
}