#include <iostream>
#include <vector>
#include <algorithm>
#include <set>

using namespace std;

typedef long long ll;

void solve() {
    int n, m;
    if (!(cin >> n >> m)) return;
    vector<pair<int, int>> p(n);
    for (int i = 0; i < n; i++) cin >> p[i].first >> p[i].second;

    sort(p.begin(), p.end(), [](const pair<int, int>& a, const pair<int, int>& b) {
        return a.second < b.second;
    });

    vector<ll> A(n + 2, 0); 
    vector<ll> B(n + 2, 0); 
    
    multiset<int> s;
    int current_sum = 0;
    int ptr = n - 1;

    for (int k = n + 1; k >= 1; k--) {
        while (ptr >= 0 && p[ptr].second >= k - 1) {
            s.insert(p[ptr].first);
            current_sum += p[ptr].first;
            ptr--;
        }
        while ((int)s.size() > k) {
            current_sum -= *s.begin();
            s.erase(s.begin());
        }
        if ((int)s.size() == k) A[k] = current_sum;
        
        ll tmp_sum = current_sum;
        if ((int)s.size() == k) tmp_sum -= *s.begin();
        B[k] = tmp_sum;
    }

    ll max_A = 0;
    for (int k = 1; k <= n + 1; k++) max_A = max(max_A, A[k]);
    
    vector<ll> max_B(n + 2, 0);
    for (int k = 1; k <= n + 1; k++) max_B[k] = max(max_B[k - 1], B[k]);

    for (int i = 0; i < m; i++) {
        int x, y;
        cin >> x >> y;
        ll ans = max_A;
        ans = max(ans, (ll)x + max_B[min(n + 1, y + 1)]);
        cout << ans << (i == m - 1 ? "" : " ");
    }
    cout << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    if (!(cin >> t)) return 0;
    while (t--) {
        solve();
    }
    return 0;
}
