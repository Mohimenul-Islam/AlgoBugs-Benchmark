#include <bits/stdc++.h>
using namespace std;
#define int long long
#define fi first
#define se second
#define pb push_back

int n,m;
int x,y;
void sol(){
    cin >> n >> m;
    vector<pair<int,int>> pr;

    for(int i=0;i<n;i++){
        cin >> x >> y;
        pr.pb({x,y});
    }

    sort(pr.begin(), pr.end(), [](pair<int,int> a, pair<int,int> b){
        return a.se>b.se;
    });

    multiset<pair<int,int>> st;
    int best=0, tmp=0;
    for(int i=0;i<n;i++){
        tmp+=pr[i].fi;
        st.insert(pr[i]);

        while(st.size()>pr[i].se+1){
            auto[a,b]=*st.begin();
            tmp-=a;
            st.erase(st.begin());
        }

        best=max(best,tmp);
    }

    st.clear(); tmp=0;
    int ite=0;
    vector<int> sum(n+1,0);
    for(int i=n;i>=0;i--){
        while(ite<n && pr[ite].se>=i){
            tmp+=pr[ite].fi;
            st.insert(pr[ite]);
            ite++;
        }

        while(st.size()>i){
            auto[a,b]=*st.begin();
            tmp-=a;
            st.erase(st.begin());
        }

        sum[i]=max(sum[i], tmp);
    }

    for(int i=1;i<=n;i++) sum[i]=max(sum[i-1], sum[i]);
    while(m--){
        cin >> x >> y;

        cout << max(best, sum[y]+x) << ' ';
    }
    cout << '\n';

    // for(int i=0;i<=n;i++) cout << sum[i] << ' ';
    // cout << '\n';
    // for(int i=0;i<=n;i++) cout << mx[i] << ' ';
    // cout << "\n\n";
}

signed main(){
    ios_base::sync_with_stdio(false); cin.tie(nullptr);

    int tc=1;
    cin >> tc;
    while(tc--) sol();
}