#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define F first
#define S second
#define ii pair <int, int>

struct Trie
{
    Trie* one;
    Trie* zero;
    int cnt = 0;
    ll sum = 0;

    Trie()
    {
        one = NULL;
        zero = NULL;
        cnt = sum = 0;
    }

    void add(Trie* t,int bit,int x,int inc)
    {
        t->cnt += inc;
        t->sum += 1LL*x*inc;

        if( bit == -1 )
            return;

        if(x&(1<<bit))
        {
            if( t->one == NULL)
                t->one = new Trie();
            add(t->one,bit-1,x,inc);
        }
        else
        {
            if( t->zero == NULL)
                t->zero = new Trie();
            add(t->zero,bit-1,x,inc);
        }
    }

    ll getSum(Trie *t,int bit,int x)
    {
        if (!t || x <= 0) return 0;

        if(bit == -1)
            return 1LL*t->sum/t->cnt * x;

        int onecnt = (t->one ? t->one->cnt : 0);
        if( onecnt >= x )
            return getSum(t->one,bit-1,x);

        ll res = (t->one ? t->one->sum : 0);
        return getSum(t->zero,bit-1,x-onecnt) + res;
    }
};

const int N = 200100;

bool hasLessThanN;
int T,n,m;
ll ans1[N],ans2[N],ans,mx[N];
ii p[N];

void _clear()
{
    ans = 0;
    hasLessThanN = 1;
}

int main()
{
    Trie* trie = new Trie();

    scanf("%d", &T);
    while(T--)
    {
        _clear();

        scanf("%d%d",&n,&m);
        for(int i=1;i<=n;i++)
        {
            scanf("%d%d",&p[i].S,&p[i].F);
            trie->add(trie,31,p[i].S,1);

            if( p[i].F != n )
                hasLessThanN = 0;
        }

        sort(p+1,p+n+1);
        int l = 1;

        for(int take=1;take<=n+2;take++)
        {
            while( p[l].F < take-1 && l != n+1 )
            {
                trie->add(trie,31,p[l].S,-1);
                l++;
            }

            ans1[take] = trie->getSum(trie,31,take);
            ans = max(ans,ans1[take]);
            ans2[take] = trie->getSum(trie,31,take-1);
            mx[take] = max(mx[take-1],ans2[take]);
        }

        for(int i=1;i<=m;i++)
        {
            int x,y;
            scanf("%d%d",&x,&y);
            printf("%lld ",max(ans,mx[y+1]+x));
        }
        printf("\n");
    }
}
