// Jan Zakrzewski
#include <bits/stdc++.h>
using namespace std;

using i32 = int32_t;
using i64 = int64_t;
using u32 = uint32_t;
using u64 = uint64_t;
using i32vec = vector<i32>;
using i32que = queue<i32>;
#define SIZE(x) i32((x).size())
using i64vec = vector<i64>;
using i32pque = priority_queue<i32>;

void solve() {
    i32 n, m;
    cin >> n >> m;
    vector<i32vec> p(n + 1);
    for(i32 i = 0; i <= n - 1; ++i) {
        i32 x, y;
        cin >> x >> y;
        p[y].push_back(x);
    }
    i64vec a(n + 1);
    i32vec b(n + 1);

    i64 sum = 0;
    i64 sum_max = 0;
    i32 Count = 0;
    i32pque PQ;
    for(i32 y = n; y >= 0; --y) {
        for(i32 x : p[y]) {
            sum += x;
            ++Count;
            PQ.push(-x);
        }
        while(Count > y + 1) {
            i32 x = -PQ.top();
            PQ.pop();
            sum -= x;
            --Count;
        }
        a[y] = sum;
        sum_max = max(sum_max, sum);
        if(Count == y + 1) b[y] = -PQ.top();
        else b[y] = 0; // TODO: does that really work?
    }

    vector<vector<pair<i32,i32>>> q(n + 1);
    for(i32 i = 0; i <= m - 1; ++i) {
        i32 x, y;
        cin >> x >> y;
        q[y].emplace_back(x, i);
    }

    i64vec ans(m);
    i64 acc = 0;
    for(i32 y = 0; y <= n; ++y) {
        acc = max(acc, a[y] - b[y]);
        for(pair<i32,i32> elm : q[y]) {
            i32 x, i;
            tie(x, i) = elm;
            ans[i] = max(sum_max, acc + x);
        }
    }

    for(i32 i = 0; i <= m - 1; ++i)
        cout << ans[i] << " ";
    cout << "\n";
}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    signed t; cin >> t;
    while(t--) solve();
}
