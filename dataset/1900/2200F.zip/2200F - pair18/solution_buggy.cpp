#include<bits/stdc++.h>
using namespace std;
const int maxN=200000+7;
pair<int,int> store[maxN];
pair<int,int> shop[maxN];
int arr[maxN][2];
bool Comp(pair<int,int>&p1,pair<int,int>&p2)
{
	return p1.second>p2.second;
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(NULL);
	int tt;cin>>tt;
	while(tt--)
	{
		int N,M;
		cin>>N>>M;
		for(int i=0;i<N;i++){
			cin>>store[i].first>>store[i].second;
		}
		for(int i=0;i<M;i++){
			cin>>shop[i].first>>shop[i].second;
		}
		sort(store,store+N,Comp);
		multiset<int>st;
		int s=0,i=0;
		int maxs=0;
		for(int k=N+1;k>0;k--)
		{
			while(store[i].second>=k-1 and i<N){
				st.insert(store[i].first);
				s+=store[i++].first;
			}
			while((int)st.size()>k){
				s-=*st.begin();
				st.erase(st.begin());
			}
			arr[k][0]=arr[k][1]=s;
			maxs=max(maxs,s);
			if((int)st.size()==k)arr[k][1]=s-*st.begin();
		}
		
		for(int i=1;i<=N;i++)
		{
			arr[i+1][1]=max(arr[i][1],arr[i+1][1]);
		}
		for(int i=0;i<M;i++)
		{
			int s0;
			s0=shop[i].first+arr[shop[i].second+1][1];
			cout<<max(maxs,s0)<<" ";
		}
		cout<<endl;
		
		
	}
}