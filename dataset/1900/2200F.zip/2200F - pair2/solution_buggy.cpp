#include <cstring>
#include <string>
#include <iostream>
#include <algorithm>
#include <vector>
#include <cmath>
#include <iomanip>
#include <queue>
#include <stack>
#include <random>
#include <chrono>
#include <map>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <ctime>
#include <bitset>
#include <array>
using namespace std;

typedef unsigned int UINT;
typedef long long LL;
typedef unsigned long long ULL;
typedef pair<int, int> PII;
typedef pair<double, double> PDD;
typedef pair<long long, long long> PLL;

#define lp p << 1
#define rp p << 1 | 1
#define lowbit(x) (x & (-x))
#define i128 __int128
#define ent "\n"
#define cc(x) cout << fixed << setprecision(x)

const int mod = 1e9 + 7;
const double eps = 1e-8;
const int oo = 0x3f3f3f3f;
const LL INF = 2e18;

void solve() {
    // auto seed = std::chrono::system_clock::now().time_since_epoch().count();
    // mt19937_64 gen(seed);  
    // uniform_int_distribution<LL> dist(1, 1e18);

    // freopen("114514.in", "r", stdin);
    // freopen("114514.out", "w", stdout);
    
    /*   /\_/\
    *   (= ._.)
    *   / >  \>
    */

    int n, m; cin >> n >> m;
    vector<vector<int>> a(n + 2);
    for (int i = 1; i <= n; ++ i) {
        int x, y; cin >> x >> y; ++ y;
        a[y].push_back(x);
    }
    for (int i = 1; i <= n + 1; ++ i) {
        sort(a[i].begin(), a[i].end(), greater<>());
    }
    vector<LL> f(n + 2), g(n + 2, -INF);
    int cnt = 0;
    LL sum = 0;
    multiset<int> S;
    for (int i = n + 1; i >= 1; -- i) {
        while (cnt > i) {
            int u = *S.begin();
            S.erase(S.find(u));
            sum -= u;
            -- cnt;
        }
        for (int v : a[i]) {
            if (cnt < i) {
                sum += v;
                S.insert(v);
                cnt ++;
            } else if (cnt == i) {
                int u = *S.begin();
                if (v > u) {
                    S.erase(S.find(u));
                }
                S.insert(v);
                sum += v - u;
            }
        }
        f[i] = sum;
        if (cnt == i) {
            g[i] = sum - *S.begin();
        } else if (cnt < i) {
            g[i] = sum;
        }
    }
    LL mx = 0;
    for (int i = 1; i <= n + 1; ++ i) {
        mx = max(mx, f[i]);
        g[i] = max(g[i], g[i - 1]);
    }
    while (m -- ) {
        int x, y; cin >> x >> y; ++ y;
        cout << max(mx, g[y] + x) << ' ';
    }
    cout << ent;
}

int main() {
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    
    int T = 1;
    bool flag = 1;
    if (flag) cin >> T;
    while (T --) {
        solve();
    }
    return 0;
}
