#include <bits/stdc++.h>
using namespace std;

using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int t;
    cin >> t;
    while (t--) {
        int n, m;
        cin >> n >> m;

        vector<pair<ll,int>> a(n);
        for (int i = 0; i < n; i++) {
            cin >> a[i].first >> a[i].second;
        }

        ll best = 0, sum = 0;
        multiset<int> ms;

        for (int i = n - 1; i >= 0; i--) {
            ll x = a[i].first;
            int y = a[i].second;

            ms.insert(x);
            sum += x;

            // cần lấy tối đa y+1 phần tử (bao gồm chính nó)
            while ((int)ms.size() > y + 1) {
                auto it = ms.begin();
                sum -= *it;
                ms.erase(it);
            }

            best = max(best, sum);
        }

        vector<tuple<ll,int,int>> b(m); // x, y, id
        for (int i = 0; i < m; i++) {
            ll x; int y;
            cin >> x >> y;
            b[i] = {x, y, i};
        }

        // sort a theo y tăng
        sort(a.begin(), a.end(), [](auto &l, auto &r){
            return l.second < r.second;
        });

        // sort b theo y tăng
        sort(b.begin(), b.end(), [](auto &l, auto &r){
            return get<1>(l) < get<1>(r);
        });

        vector<ll> ans(m, 0);

        sum = 0;
        ms.clear();
        int j = n - 1;

        // duyệt b từ y lớn -> nhỏ
        for (int i = m - 1; i >= 0; i--) {
            ll x = get<0>(b[i]);
            int y = get<1>(b[i]);
            int id = get<2>(b[i]);

            // thêm các phần tử của a có y >= current y
            while (j >= 0 && a[j].second >= y) {
                ms.insert(a[j].first);
                sum += a[j].first;
                j--;
            }

            // giữ tối đa y phần tử tốt nhất từ n hạt
            while ((int)ms.size() > y) {
                auto it = ms.begin();
                sum -= *it;
                ms.erase(it);
            }

            // trường hợp:
            // - không dùng hạt shop
            ll res = sum;

            // - dùng hạt shop
            res = max(res, sum + x);

            ans[id] = max(res, best);
        }

        for (auto v : ans) cout << v << " ";
        cout << "\n";
    }

    return 0;
}
