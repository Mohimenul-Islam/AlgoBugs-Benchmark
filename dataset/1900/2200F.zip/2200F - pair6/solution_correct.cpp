#include <iostream>
#include <vector>
#include <algorithm>
#include <set>

using namespace std;

struct Particle {
    long long x;
    int y;
    int id; // Lưu ID để in đúng thứ tự cho shop
};

bool compareYDesc(const Particle& a, const Particle& b) {
    if (a.y != b.y) return a.y > b.y;
    return a.x > b.x;
}

void solve() {
    int n, m;
    if (!(cin >> n >> m)) return;

    vector<Particle> has(n);
    for (int i = 0; i < n; ++i) cin >> has[i].x >> has[i].y;

    vector<Particle> shop(m);
    for (int i = 0; i < m; ++i) {
        cin >> shop[i].x >> shop[i].y;
        shop[i].id = i;
    }

    // --- TH0: Tính max_n_only (Chỉ dùng n hạt sẵn có) ---
    // Sort y giảm dần để hạt đang xét là hạt có y bé nhất
    sort(has.begin(), has.end(), compareYDesc);
    long long max_n_only = 0;
    multiset<long long> ms0;
    long long sum0 = 0;
    for (int i = 0; i < n; ++i) {
        ms0.insert(has[i].x);
        sum0 += has[i].x;
        while (ms0.size() > (size_t)has[i].y + 1) {
            sum0 -= *ms0.begin();
            ms0.erase(ms0.begin());
        }
        max_n_only = max(max_n_only, sum0);
    }

    // --- TH2: Shop KHÔNG là bé nhất (Sử dụng dp tính từ trước) ---
    // Tận dụng mảng has đã sort y giảm dần
    vector<long long> dp(n + 2, 0);
    multiset<long long> ms2;
    long long sum2 = 0;
    for (int i = 0; i < n; ++i) {
        ms2.insert(has[i].x);
        sum2 += has[i].x;
        int k = has[i].y;
        // Hạt shop không bé nhất -> có hạt has[i] gánh mức y = k
        // Ta lấy hạt has[i], hạt shop, và k-1 hạt tốt nhất khác
        while (ms2.size() > (size_t)k) {
            sum2 -= *ms2.begin();
            ms2.erase(ms2.begin());
        }
        dp[k] = max(dp[k], sum2);
    }
    for (int i = 1; i <= n; i++) dp[i] = max(dp[i], dp[i-1]);

    // --- TH1: Shop LÀ hạt bé nhất (Dùng Two Pointers + Multiset) ---
    vector<Particle> sorted_shop = shop;
    sort(sorted_shop.begin(), sorted_shop.end(), compareYDesc);

    vector<long long> final_results(m);
    multiset<long long> ms1;
    long long sum1 = 0;
    int ptr = 0;

    for (int i = 0; i < m; ++i) {
        int sy = sorted_shop[i].y;
        long long sx = sorted_shop[i].x;

        // Thêm các hạt có y_has >= y_shop vào multiset
        while (ptr < n && has[ptr].y >= sy) {
            ms1.insert(has[ptr].x);
            sum1 += has[ptr].x;
            ptr++;
        }

        // Lấy tối đa sy hạt tốt nhất từ multiset (vì shop là hạt thứ sy+1)
        while (ms1.size() > (size_t)sy) {
            sum1 -= *ms1.begin();
            ms1.erase(ms1.begin());
        }

        long long res_th1 = sx + sum1;
        long long res_th2 = (sy > 0) ? sx + dp[min(sy - 1, n)] : 0;

        final_results[sorted_shop[i].id] = max({max_n_only, res_th1, res_th2});
    }

    for (int i = 0; i < m; ++i) {
        cout << final_results[i] << (i == m - 1 ? "" : " ");
    }
    cout << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
