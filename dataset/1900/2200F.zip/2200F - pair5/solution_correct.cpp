#include <map>
#include <set>
#include <deque>
#include <stack>
#include <queue>
#include <cmath>
#include <cstdio>
#include <vector>
#include <string>
#include <bitset>
#include <climits>
#include <numeric>
//#include <cassert>
#include <iostream>
#include <stdint.h>
#include <algorithm>
#include <unordered_map>
#define ll long long

ll read(){
    ll x = 0, f = 1; char ch = getchar();
    for(; !isdigit(ch); ch = getchar()) f ^= (ch == '-');
    for(; isdigit(ch); ch = getchar()) x = (x << 3) + (x << 1) + (ch xor 48);
    return f ? x : -x;
}

ll min(ll a, ll b){return a < b ? a : b;}
ll max(ll a, ll b){return a > b ? a : b;}
ll abs(ll x){return x > 0 ? x : -x;}
ll power(ll a, ll b, ll mod){
    a %= mod; ll res = 1;
    for(; b; b >>= 1, a = a * a % mod) if(b & 1) res = res * a % mod;
    return res;
}

void solve(){
    int n = read(), m = read();
    std::vector<std::pair<ll, ll>> a(n), b(m);
    for(auto& [x, y] : a) x = read(), y = read();
    for(auto& [x, y] : b) x = read(), y = read();

    std::sort(a.begin(), a.end(), [](const auto& A, const auto& B){
        if(A.second != B.second) return A.second < B.second; 
        return A.first > B.first;
    });
    std::vector<std::vector<ll>> clf(n + 2);
    for(auto& [x, y] : a) clf[y + 1].push_back(x);

    std::vector<ll> p(n + 2), pp(n + 2);
    std::priority_queue<ll, std::vector<ll>, std::greater<ll>> q;
    ll sum = 0;

    for(int k = n + 1; k; --k){
        for(auto& x : clf[k]) sum += x, q.push(x);
        while(q.size() > k) sum -= q.top(), q.pop();
        p[k] = sum;
        if(q.size() == k) pp[k] = q.top();
    }

    std::vector<ll> pre(n + 2); pre[1] = p[1] - pp[1];
    for(int i = 2; i <= n + 1; ++i) pre[i] = std::max(pre[i - 1], p[i] - pp[i]);

    ll maxx = *std::max_element(p.begin(), p.end());

//    printf("!!! "); for(int i = 1; i <= n + 1; ++i) printf("%lld ", p[i]); puts(""); return;

    for(auto& [x, y] : b){
        printf("%lld ", std::max(maxx, pre[y + 1] + x));
    }
    puts("");
}
signed main(){
    #ifdef LOCAL
        freopen("in.txt", "r", stdin);
    #endif
    int T = read();
    while(T--) solve();
}

/*
5 5 10 6 3
0 2
5 10
3 6
5 9
2 3
1
7
2
10
5
*/
