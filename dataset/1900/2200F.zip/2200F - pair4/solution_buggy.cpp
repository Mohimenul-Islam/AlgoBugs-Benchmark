#include <iostream>
#include <string>
#include <vector>
#include <stack>
#include <deque>
#include <queue>
#include <algorithm>
#include <cmath>
#include <array>
#include <bitset>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <functional>
using namespace std;

using i128 = __int128;
using i64 = long long;
using pii = pair<int, int>;
using pll = pair<long long, long long>;
using pdd = pair<double, double>;
// #define int long long
const int inf = 1e9+7;
const i64 lnf = 2e18+7;
const i64 mod = 1e9+7;
// const i64 mod = 998244353;

// =========================================
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp> 
using namespace __gnu_pbds;
typedef __gnu_pbds::tree<int, __gnu_pbds::null_type, less<int>, __gnu_pbds::rb_tree_tag, __gnu_pbds::tree_order_statistics_node_update> ordered_set;

// ordered_set s
// s.find_by_order(k) 返回第 k 小位置的迭代器
// s.ordered_set(k) 返回严格小于k的元素个数

template <typename T>
using ordered_multiset = tree<
    pair<T, int>,    // 存储 pair(值, 唯一id)
    null_type,
    less<pair<T, int>>,
    rb_tree_tag,
    tree_order_statistics_node_update
>;
// ordered_multiset<int> oms;
// int cp = 0; // 来保证唯一性
// oms.insert({a[i], cp ++});
//// 查询第 k 小元素（0开始）
// cout << s.find_by_order(1)->first << endl;  // 输出 5
// ================================================


i64 qsm(i64 a, i64 k) {
    i64 res = 1, base = a;
    while(k) {
        if((k & 1) == 1) res = res * base % mod;
        base = base * base % mod;
        k >>= 1;
    }
    return res;
}
int dx[4] = {0, 0, 1, -1};
int dy[4] = {1, -1, 0, 0};
i64 gcd(i64 a, i64 b) { if(!b) return a; else return gcd(b, a%b); }
i64 lcm(i64 a, i64 b) { return a*b/gcd(a, b);}
int T = 1;
void zyb() {
    int n, m;
    cin >> n >> m;

    vector<pii> v(n + 1);
    for(int i = 1; i <= n; i ++) {
        cin >> v[i].first >> v[i].second;
        v[i].second ++;
    }
    sort(v.begin() + 1, v.end(), [&](pii p, pii q){
        return p.second > q.second;
    });
    vector<i64> f(n + 2); // f[i]:当粒子数最多为 i 时，能产生的最多能量
    vector<i64> g(n + 2); // g[i]: 1.当粒子数为i时，g[i] = f[i] - min(s)  2, 当粒子数小于i时，g[i] = f[i]
    int idx = 1;
    i64 S = 0, mx = 0;
    priority_queue<int, vector<int>, greater<int>> heap;
    for(int i = n + 1; i >= 1; i --) {
        while(idx <= n && v[idx].second >= i) {
            S += v[idx].first;
            heap.push(v[idx].first);
            idx ++;
        }
        while(heap.size() > i) {
            S -= heap.top();
            heap.pop();
        }
        f[i] = S;
        mx = max(mx, f[i]);
        if(heap.size() < i) {
            g[i] = f[i];
        } else {
            g[i] = f[i] - heap.top();
        }
    }

    vector<i64> mxg(n + 2);
    for(int i = 1; i <= n+1; i ++) {
        mxg[i] = max(mxg[i-1], g[i]);
    }

    for(int i = 0; i < m; i ++) {
        int x, y;
        cin >> x >> y;

        y ++;
        i64 ans = mx; // 不选
        ans = max(ans, x + g[y]);

        cout << ans << " ";
    }

    cout << "\n";
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> T;
    while(T --) {
        zyb();
    }
    return 0;
}

/*
我求你了，没思路就想想二分吧
被过穿了的题没思路，再读题！！！
不要盲目猜结论，只会wa和对这场比赛失去信心！！！
被过穿了的题没思路，猜结论
被过穿了的题过不了，加特判
模拟复杂/没思路，想 dp
问题复杂描述简单，贪心猜结论再推公式
*/

