using namespace std;
#include <bits/stdc++.h>
#define ll long long
#define pii pair<int, int>
#define pll pair<long long, long long>
#define vi vector<int>
#define vll vector<long long>
#define vc vector<char>
#define vs vector<string>
#define mii map<int, int>
#define si set<int>
#define sll set<long long>
#define sc set<char>
#define ss set<string>
#define pii pair<int, int>
#define pll pair<long long, long long>
#define f(i,s,e) for(int i = s; i < e; i++)
#define cf(i,s,e) for(int i = s; i <= e; i++)
#define rf(i,e,s) for(int i = e-1; i >= s; i--)
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
#define pb push_back
#define eb embrace_back
#define mp make_pair
#define fi first
#define se first
#define ub upper_bound
#define lb lower_bound
#define sz(x) (int)(x).size()
#define afastio ios::sync_with_stdio(0); cin.tie(0); freopen("a.in", "r", stdin); freopen("a.out", "w", stdout);
#define fastio ios::sync_with_stdio(0); cin.tie(0);
#define read(x) cin >> x
#define print(x) cout << x << "\n"
#define debug(x) cerr << #x << " = " << x << "\n"
int gcd(int a,int b) { if (b==0) return a; return gcd(b, a%b); }
int lcm(int a,int b) { return a/gcd(a,b)*b; }
ll gcd_ll(ll a,ll b) { if (b==0) return a; return gcd(b, a%b); }
ll lcm_ll(ll a,ll b) { return a/gcd_ll(a,b)*b; }
bool prime(int a) { if (a==1) return 0; for (int i=2;i<=round(sqrt(a));++i) if (a%i==0) return 0; return 1; }
bool prime_ll(ll a) { if (a==1) return 0; for (int i=2;i<=round(sqrt(a));++i) if (a%i==0) return 0; return 1; }
#define MOD 1000000007
#define inf 1e9  // Use for int (e.g., distance)
#define inf_ll 1e18  // Use for long long
#define eps 1e-9  // Precision for floating-point comparison

vector<int> spf((int)1e6+ 1, 1);

// Calculating SPF (Smallest Prime Factor) for every number till MAXN.
void sieve()
{
    // stores smallest prime factor for every number
    spf[0] = 0;
    for (int i = 2; i <= (int)1e6; i++) {
        if (spf[i] == 1) { 
            
            // if the number is prime ,mark
            // all its multiples who havent
            // gotten their spf yet
            for (int j = i; j <= (int)1e6; j += i) {
                if (spf[j]== 1) 
                
                    // if its smallest prime factor is
                    // 1 means its spf hasnt been
                    // found yet so change it to i
                    spf[j] = i;
            }
        }
    }
}

void solve()
{
    int N, M; cin >> N >> M; 
    map<int, vector<int>> bessieInventory;
    for (int i = 0; i < N; i++)
    {
        int val, reactivity; cin >> val >> reactivity;
        bessieInventory[reactivity].pb(val);
    }

    vector<pii> shop;

    for (int i = 0; i < M; i++)
    {
        int val, reactivity; cin >> val >> reactivity;
        shop.pb({val, reactivity});
    }


    auto prev = bessieInventory.end();
    
    ll mx = 0;
    ll max_val[N + 2];
    ll max_val_2[N + 2];
    memset(max_val, 0, sizeof(max_val));
    memset(max_val_2, 0, sizeof(max_val_2));
    priority_queue<ll, vector<ll>, greater<ll>> candidates;
    
    for (int k = N; k >= 0; k--)
    {
        //fix usage at k
        auto curr = bessieInventory.lower_bound(k);
        max_val_2[k] = max_val_2[k + 1];
        max_val[k] = max_val[k + 1];
        if (curr != prev)
        {
            // if new candidates then add new candidates 
            for (auto it = curr; it != prev; it++)
            {
                //new ones that are now possible because lower value of k
                for (int item : it->second)
                {
                    candidates.push(item);
                    max_val_2[k] += item;
                    max_val[k] += item;
                }
            
            }
            // int initial = candidates.size();
            // //all can be paired with k + 1 total particles
            // vector<ll> r; ll sum = 0;
            // for (int i = 0; i < min(k + 1, initial); i++)
            // {
            //     ll good = candidates.top();
            //     candidates.pop();
            //     sum += good;
            //     if (i < k) max_val_2[k] += good; r.pb(good);
            // }
            
            //max_val[k] = sum;
            // for (int item : r) 
            // {
            //     candidates.push(item);
            // }
        }
        while (candidates.size() > k + 1)
        {
            int item = candidates.top();
            max_val_2[k] -= item;
            max_val[k] -= item;
            candidates.pop();
        }
        if (candidates.size() > k) max_val_2[k] -= candidates.top();
        
        
        mx = max(max_val[k], mx);
        
        prev = curr;
    }
    for (int i = 1; i <= N; i++) max_val_2[i] = max(max_val_2[i], max_val_2[i - 1]);
    for (auto [x, y] : shop)
    {
        cout << max(mx, x + (y > 0 ? max_val_2[y] : 0)) << " ";
    }
    cout << "\n";

}
int main()
{
    //afastio
    int T; cin >> T;
    while (T--) solve();
}