#include<bits/stdc++.h>
//#define pii pair<int,int>
//#define fi first
//#define se second
//#define int long long
#define ls now*2
#define rs now*2+1
using namespace std;
int a[500005];
set<int>v[500005];
int mi,ans=0;
struct Tree{
	struct o{
		int l,r,sum;
	}t[2000005];
	void up(int now){
		t[now].sum=min(t[ls].sum,t[rs].sum);
	}
	void init(int now,int l,int r){
		t[now].l=l,t[now].r=r;
		if(l==r){
			t[now].sum=a[l];
			return;
		}
		int mid=(l+r)/2;
		init(ls,l,mid);
		init(rs,mid+1,r);
		up(now);
	}
	void add(int now,int x,int y,int z){
		int l=t[now].l,r=t[now].r;
		if(x<=l&&r<=y){
			t[now].sum=z;
			return;
		}
		int mid=(l+r)/2;
		if(x<=mid)
			add(ls,x,y,z);
		if(y>mid)
			add(rs,x,y,z);
		up(now);
	}
	void qz(int now,int x,int y){
		int l=t[now].l,r=t[now].r;
		if(ans!=0)return;
		if(x<=l&&r<=y){
			if(min(mi,t[now].sum)>r-x){
				mi=min(mi,t[now].sum);
				return;
			}
			if(l==r){
				if(min(mi,t[now].sum)==r-x)ans=1;
				else ans=0;
				return;
			}
			if(t[ls].r-x+1>min(t[ls].sum,mi)){
				qz(ls,x,y);
				if(ans!=1)
					ans=-1;
			}
			else{
				mi=min(t[ls].sum,mi);
				qz(rs,x,y);
				if(ans!=1)
					ans=-1;
			}
			return;
		}
		int mid=(l+r)/2;
		if(x<=mid)
			qz(ls,x,y);
		if(y>mid)
			qz(rs,x,y);
		return;
	}
}t;
signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int T;
	cin>>T;
	while(T--){
		int n,q;
		cin>>n>>q;
		for(int i=1;i<=n;i++){
			cin>>a[i];
		}
		t.init(1,1,n);
		while(q--){
			int op;
			cin>>op;
			if(op==1){
				int x,y;
				cin>>x>>y;
				t.add(1,x,x,y);
			}
			else{
				int x,y;
				cin>>x>>y;
				mi=INT_MAX;
				ans=0;
				t.qz(1,x,y);
				cout<<max(ans,0)<<"\n";
//				if(v[x].empty()||*v[x].begin()>y||(t.qz(1,x,y)<*v[x].begin())){
//					cout<<"0\n";
//				}
//				else
//					cout<<*v[x].begin()<<"\n";
			}
		}
	}
	return 0;
}
/*
  1
  6 2
  1 2 3 4 5 6
  2 1 5
  2 3 5
 */