#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define eb emplace_back
const int N=2e5+5;
int T,n,q,a[N],tr[N<<2];
void up(int id){
	tr[id]=min(tr[id<<1],tr[id<<1|1]);
}
void build(int id,int l,int r){
	if(l==r)return tr[id]=a[l],void();
	int mid=(l+r)>>1;
	build(id<<1,l,mid);build(id<<1|1,mid+1,r);
	up(id);
}
void update(int id,int l,int r,int x,int k){
	if(l==r)return tr[id]=k,void();
	int mid=(l+r)>>1;
	if(x<=mid)update(id<<1,l,mid,x,k);
	else update(id<<1|1,mid+1,r,x,k);
	up(id); 
}
int ask(int id,int l,int r,int x,int y){
	if(x<=l&&r<=y)return tr[id];
	int mid=(l+r)>>1,ret=1e9;
	if(x<=mid)ret=min(ret,ask(id<<1,l,mid,x,y));
	if(y>mid)ret=min(ret,ask(id<<1|1,mid+1,r,x,y));
	return ret;
}
int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	cin>>T;
	while(T--){
		cin>>n>>q;
		for(int i=1;i<=n;i++)cin>>a[i];
		build(1,1,n);
		while(q--){
			int op;
			cin>>op;
			if(op==1){
				int x,k;cin>>x>>k;update(1,1,n,x,k);
			}else{
				int l,r;cin>>l>>r;
				if(ask(1,1,n,l,r)>r-l){cout<<"0\n";continue;}
				int L=l,R=r,mid;
				while(L<R){
					mid=(L+R+1)>>1;
					if(ask(1,1,n,l,mid)>mid-l)L=mid;
					else R=mid-1;
				}
				int ind1=L;
				L=l,R=r;
				while(L<R){
					mid=(L+R)>>1;
					if(ask(1,1,n,l,mid)<mid-l)R=mid;
					else L=mid+1;
				}
				int ind2=L;
				cout<<ind2-ind1-1<<'\n';
			}
		}
	}
	return 0;
}