#include <bits/stdc++.h>
#define debug(a) cout<<#a<<"="<<a<<"\n";
#define rep(i,a,b) for(long long i=a;i<=b;++i)
using namespace std;
const long long N=2e5+7;
long long n,m,a[N];
struct Tre{
	long long mi;
	Tre(long long x=1e18){mi=x;}
	friend Tre operator+(const Tre &a,const Tre &b){
		Tre sss;
		sss.mi=min(a.mi,b.mi);
		return sss;
	}
};
class segmenttree{
	private:
		struct tre{
			long long l,r,lson,rson;
			long long lazy;
			Tre s;
		};
		vector<tre> tre;
		void init(int x,int l,int r){
			tre[x].l=l,tre[x].r=r,tre[x].lazy=tre[x].lson=tre[x].rson=0;
			tre[x].s.mi=1e18;
		}
		void pu(int x){
			tre[x].s=tre[tre[x].lson].s+tre[tre[x].rson].s;
		}
		void pt(long long x,long long y){
			tre[x].s.mi=y;
			tre[x].lazy=y;
		}
		void pd(long long x){
			pt(tre[x].lson,tre[x].lazy),pt(tre[x].rson,tre[x].lazy),tre[x].lazy=0;
		}
	public:
		void add(int x,int l,int r){
			init(x,l,r);
			if(l==r){
				tre[x].s.mi=a[l];
				return;
			}
			int mid=(l+r)/2;
			tre[x].lson=x*2,add(x*2,l,mid);
			tre[x].rson=x*2+1,add(x*2+1,mid+1,r);
			pu(x);
		}
		segmenttree(long long x){
			tre.resize(x*4+1),add(1,1,x);
		}
		void adg2(long long x,long long l,long long r,long long xx,long long yy,long long p){
			if(xx<=l&&r<=yy){
				pt(x,p);
				return;
			}
			if(tre[x].lazy) pd(x);
			long long mid=(l+r)/2;
			if(mid>=xx) adg2(x*2,l,mid,xx,yy,p);
			if(mid+1<=yy) adg2(x*2+1,mid+1,r,xx,yy,p);
			pu(x);
		}
		Tre find(long long x,long long l,long long r,long long xx,long long yy){
			if(xx<=l&&r<=yy) return tre[x].s;
			long long mid=(l+r)/2;
			if(tre[x].lazy) pd(x);
			Tre sum;
			if(mid>=xx) sum=sum+find(x*2,l,mid,xx,yy);
			if(mid+1<=yy) sum=sum+find(x*2+1,mid+1,r,xx,yy);
			return sum;
		}
};
signed main(){
	int T;
	cin>>T;
	while(T--){
		cin>>n>>m;
		rep(i,1,n){
			cin>>a[i];
		}
		segmenttree s(n);
		rep(i,1,m){
			int id;
			cin>>id;
			if(id==1){
				int x,y;
				cin>>x>>y;
				s.adg2(1,1,n,x,x,y);
			}
			if(id==2){
				int l,r;
				cin>>l>>r;
				int ll=0,rr=r-l+1;
				while(ll<rr){
					int mid=(ll+rr+1)/2;
					if(s.find(1,1,n,l,l+mid-1).mi>=mid) ll=mid;
					else rr=mid-1;
				}
				long long ans=ll;
				ll=0,rr=r-l+1;
				while(ll<rr){
					int mid=(ll+rr+1)/2;
					if(s.find(1,1,n,l,l+mid-1).mi>mid) ll=mid;
					else rr=mid-1;
				}
				cout<<ans-ll<<"\n";
			}
		}
	}
	return 0;
}