//                                              <<--KALKI-->>    
#include<bits/stdc++.h>
using namespace std;
 
#define fast ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
#define int long long
#define ld long double
#define ss second
#define ff first
#define pb push_back
#define lb lower_bound
#define ub upper_bound
#define cout(v) for(auto i:v){cout<<i<<" ";}cout<<endl;
#define gcd(a,b) __gcd(a,b);
#define cin(v) for(auto &i:v){cin>>i;}
#define all(a) a.begin(),a.end()
#define rall(a) a.rbegin(),a.rend()
const int N=2*1e5+5;
const int mod=1e9+7;
const int mod1=998244353;
long double eps=1e-5;
// function starts here------------------------------------------------------------------------------------ 

class SegmentTree {
private:
    int n;
    vector<int> seg;

    void build(int idx, int low, int high, vector<int>& arr) {
        if (low == high) {
            seg[idx] = arr[low];
            return;
        }
        int mid = (low + high) / 2;
        build(2 * idx + 1, low, mid, arr);
        build(2 * idx + 2, mid + 1, high, arr);
        seg[idx] = min(seg[2 * idx + 1], seg[2 * idx + 2]);
    }

    int query(int idx, int low, int high, int l, int r) {
        // no overlap
        if (r < low || high < l) return INT_MAX;

        // complete overlap
        if (l <= low && high <= r) return seg[idx];

        int mid = (low + high) / 2;
        int left = query(2 * idx + 1, low, mid, l, r);
        int right = query(2 * idx + 2, mid + 1, high, l, r);
        return min(left, right);
    }

    void update(int idx, int low, int high, int pos, int val) {
        if (low == high) {
            seg[idx] = val;
            return;
        }

        int mid = (low + high) / 2;
        if (pos <= mid)
            update(2 * idx + 1, low, mid, pos, val);
        else
            update(2 * idx + 2, mid + 1, high, pos, val);

        seg[idx] = min(seg[2 * idx + 1], seg[2 * idx + 2]);
    }

public:
    SegmentTree(vector<int>& arr) {
        n = arr.size();
        seg.resize(4 * n);
        build(0, 0, n - 1, arr);
    }

    int rangeMin(int l, int r) {
        return query(0, 0, n - 1, l, r);
    }

    void pointUpdate(int pos, int val) {
        update(0, 0, n - 1, pos, val);
    }
};


signed main(){
    
    int tc;cin>>tc;
    while(tc--){
        int n,q;cin>>n>>q;
        vector<int>v(n);cin(v);
        SegmentTree st(v);
        while(q--){
        	int t;cin>>t;
        	if(t==1){
        		int ind,x;cin>>ind>>x;ind--;
        		st.pointUpdate(ind,x); 
        	}
        	else{
        		int l,r;cin>>l>>r;
        		l--;r--;
        		int ans=0;
        		while(l<=r){
        			int m=(l+r)/2;
        			int val=st.rangeMin(l,m);
        			if(val==m-l+1){ans=1;break;}
        			else if(val>m-l+1){
        				l=m+1;
        			}
        			else{r=m-1;}
        		}
        		cout<<ans<<endl;
        	}
        }
    }

}