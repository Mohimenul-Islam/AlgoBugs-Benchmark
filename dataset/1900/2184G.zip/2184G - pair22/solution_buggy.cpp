#include <bits/stdc++.h>
using namespace std;
#define ull unsigned long long
#define int long long
#define prq priority_queue
#define pb push_back
#define pf push_front
#define pr pair<int,int>
#define ff first
#define ss second
#define sorta sort(a,a+n)
#define reversea reverse(a,a+n)
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
#define hurryup ios::sync_with_stdio(0); cin.tie(nullptr); cout.tie(nullptr);
const int INF=1e18;
const int MOD=1e9 + 7;
const int N=2e5 + 1;
int a[N], tree[4*N], n, q;


void build(int node, int l, int r) {
    if(l==r) {
        tree[node]=a[l];
        return;
    }
    int mid=(l+r)/2;
    build(2*node,l,mid);
    build(2*node+1,mid+1,r);
    tree[node]=min(tree[2*node], tree[2*node+1]);
}


void update(int node, int l, int r, int i, int x) {
    if(l==r) {
        a[l]=x;
        tree[node]=a[l];
        return;
    }
    int mid=(l+r)/2;
    if(mid>=i) {
        update(2*node,l,mid,i,x);
    }
    else {
        update(2*node+1,mid+1,r,i,x);
    }
    tree[node]=min(tree[2*node], tree[2*node+1]);
}


int query(int node, int start, int end, int l, int r) {
    if(start>r || end<l) return INF;
    if(start>=l && end<=r) return tree[node];
    int mid=(start+end)/2;
    return min(query(2*node,start,mid,l,r), query(2*node+1,mid+1,end,l,r));
}


signed main() {
    hurryup;
    int t;
    cin>>t;
    while(t--) {
        cin>>n>>q;
        for(int i=0; i<n; i++) cin>>a[i];
        build(1,0,n-1);

        while(q--) {
            int t;
            cin>>t;
            if(t==1) {
                int i,x;
                cin>>i>>x;
                i--;
                update(1,0,n-1,i,x);
            }
            else {
                int ql,qr;
                cin>>ql>>qr;
                ql--; qr--;
                int l=ql, r=qr, res=0;
                while(l<=r) {
                    int mid=(l+r)/2;
                    int x=query(1,0,n-1,ql,mid);
                    if(x<mid) {
                        r=mid-1;
                    }
                    else if(x>mid) {
                        l=mid+1;
                    }
                    else {
                        res=1;
                        break;
                    }
                }
                cout<<res<<'\n';
            }
        }
    }
}
// by Maharram Gurbanzada
