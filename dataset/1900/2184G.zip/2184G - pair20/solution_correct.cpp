//g++ -std=c++17 -Wl,--stack,268435456 Ahoyy.cpp -o Ahoyy.exe
//g++ -std=c++17 main.cpp -o main.exe


#include <algorithm>
#include<bits/stdc++.h>
#pragma GCC optimize("Ofast")
#pragma GCC optimize("unroll-loops")
#pragma GCC target("sse4")
using namespace std;
typedef long double ld;
typedef long long ll;
typedef unsigned long long ull;
#define pii pair<int,int>
#define pll pair<ll,ll>
#define pld pair<ld,ld>
#define pb push_back
#define fi first
#define se second
#define UP(a,b,c) for(ll (a)=(b);(a)<(c);++(a))
#define UU(a,b,c) for(ll (a)=(b);(a)<=(c);++(a))
#define DN(a,b,c) for(ll (a)=(b);(a)>(c);--(a))
#define DU(a,b,c) for(ll (a)=(b);(a)>=(c);--(a))
#define lc(i) i+1
#define rc(i) i+(m-l+1)*2
#define debug(x) cout << #x << " = " << x << endl;

template<class A, class B>
ostream& operator<<(ostream& os, const pair<A, B> &p) {
    os <<  '(' << p.first << ',' << p.second << ')';
    return os;
}
template<class T>
ostream& operator<<(ostream& os, const vector<T> &v) {
    bool fs = 1; os << '{';
    for(auto &i : v) { if(!fs) os << ", "; os << i; fs = 0; }
    os << '}'; return os;
}

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;

#define ordered_set tree<int, null_type, less_equal<int>, rb_tree_tag, tree_order_statistics_node_update>


mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

ll expo(ll a, ll b, ll mod) {
    if(b == 0) return 1;
    if(b == 1) return a % mod;
    ll ret = expo(a, b>>1, mod);
    ret *= ret;
    if(ret >= mod) ret %= mod;
    if(b & 1) {
        ret *= a;
        if(ret >= mod) ret %= mod;
    }
    return ret;
}

ll inv(ll v, ll mod) {
    return expo(v, mod - 2, mod);
}

const int N = 2e5;
int n, q, a[N+5], st[2*N+5];

void reset() {
}

void upd(int i, int l, int r, int x, int v) {
    if(l == r)
    return void(st[i] = a[l] = v);
int m = (l + r) >> 1;
    if (x <= m) upd(i+1, l, m, x, v);
    else upd(i+((m-l+1)<<1), m+1, r, x, v);
    st[i] = min(st[i+1], st[i+((m-l+1)<<1)]);
}

int ans = 0, cMn = 1e9;
int getMn(int i, int l, int r, int tl, int tr) {
    if (tl > r || tr < l) return 1e9;
    if (tl <= l && r <= tr) return st[i];
    int m = (l + r) >> 1;
    return min(getMn(i+1, l, m, tl, tr), getMn(i+((m-l+1)<<1), m+1, r, tl, tr));
}

int que(int i, int l, int r, int tl, int tr) {
    if(l > tr || r < tl) return 0;
    if(l == r) {
        cMn = min(cMn, a[l]);
        return l - tl == cMn;
    }
    int m = (l + r) >> 1;
    int len = m - tl + 1;
    // cur minimum > len from tl then, go right
    // else go left.
    int lMn = getMn(i + 1, l, m, tl, m);
    int nMn = min(cMn, lMn);
    if (nMn >= len) {
        cMn = nMn;
        return que(i+((m-l+1)<<1), m+1, r, tl, tr);
    } else {
        return que(i+1, l, m, tl, tr);
    }
}

void input() {
    cin >> n >> q;
    UU(i, 1, n) {
        cin >> a[i];
        upd(1, 1, n, i, a[i]);
    }
}

void solve() {
    while(q--) {
        int t, x, y;
        cin >> t >> x >> y;
        if(t == 1) {
            upd(1, 1, n, x, y);
        } else {
            cMn = 1e9;
            cout << que(1, 1, n, x, y) << "\n";
        }
    }

}

void Ahoy() {
    solve();
}

int main() {
    ios_base::sync_with_stdio(false);cin.tie(NULL);

    int TC = 1;
    cin >> TC;
    UU(t, 1, TC) {
        // cout << "Case #" << t << ": ";
        reset();
        input();
        Ahoy();
    }

    return 0;
}