#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=2e5+5;
int n,q;
int a[N];
int tree[N<<2];
int ls(int k){return 2*k;}
int rs(int k){return 2*k+1;}
void Push_up(int k){
    tree[k]=min(tree[ls(k)],tree[rs(k)]);
    return ;
}
void build_tree(int k,int l,int r){
    if(l==r){
        tree[k]=a[l];
        return ;
    }
    int mid=(l+r)/2;
    build_tree(ls(k),l,mid);
    build_tree(rs(k),mid+1,r);
    Push_up(k);
    return ;
}
void modify(int k,int l,int r,int pos,int val){
    if(l==r){
        tree[k]=val;
        return ;
    }
    int mid=(l+r)/2;
    if(pos<=mid)modify(ls(k),l,mid,pos,val);
    if(mid+1<=pos)modify(rs(k),mid+1,r,pos,val);
    Push_up(k);
    return ;
}
int query(int k,int l,int r,int L,int R){
    if(L<=l&&r<=R){
        return tree[k];
    }
    int mid=(l+r)/2;
    int minn=1e18;
    if(L<=mid)minn=min(minn,query(ls(k),l,mid,L,R));
    if(mid+1<=R)minn=min(minn,query(rs(k),mid+1,r,L,R));
    return minn;
}
void solve(){
    cin>>n>>q;
    for(int i=1;i<=n;i++)cin>>a[i];
    build_tree(1,1,n);
    while(q--){
        int op,x,y;
        cin>>op>>x>>y;
        if(op==1){
            modify(1,1,n,x,y);
        }else{
            int l=-1,r=y-x;
            while(l+1<r){
                int mid=(l+r)/2;
                if(query(1,1,n,x,x+mid)<=mid)r=mid;
                else l=mid;
            }
            if(query(1,1,n,x,x+r)!=r){
                cout<<0<<endl;
            }else{
                cout<<1<<endl;
            }
        }
    }
    return ;
}
signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int T=1;
    cin>>T;
    while(T--)solve();
    return 0;
}
