#include <bits/stdc++.h>
using namespace std;
typedef long long  ll;
typedef double ld;
const ld PI=acos(-1.0);
void Mohammed_Khaled()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
}
struct SegTree
{
    // all functions 0-based and l,r inclusive
    struct Node {
        ll val;
        Node() {
            val = 1e18;
        }
        Node(ll x) {
            val = x;
        }
    };
    vector<Node>tree;ll sz;
    SegTree(ll n) {
        sz=1;
        while (sz<n)sz*=2;
        tree.resize(2*sz);
    }
    SegTree(vector<ll>&v)
    {
        sz=1;
        while (sz<v.size())sz*=2;
        tree.resize(2*sz);
        build(v);
    }
    Node Merge(Node a,Node b) {
        return Node(min(a.val,b.val));
    }
    void build(vector<ll>&v,ll node,ll lx,ll rx) {
        if (lx==rx) {
            if (lx<v.size())tree[node]=Node(v[lx]);
            return ;
        }
        ll mid=(lx+rx)/2,left=2*node+1,right=2*node+2;
        build(v,left,lx,mid);
        build(v,right,mid+1,rx);
        tree[node]=Merge(tree[left],tree[right]);
    }
    void build(vector<ll>&v)
    {
        build(v,0,0,sz-1);
    }
    void update(int p,ll val,ll node,ll lx,ll rx)
    {
        if (p>rx or p<lx)return ;
        if (lx==rx) {
            tree[node]=Node(val);
            return ;
        }
        ll mid=(lx+rx)/2,left=2*node+1,right=2*node+2;
        update(p,val,left,lx,mid);
        update(p,val,right,mid+1,rx);
        tree[node]=Merge(tree[left],tree[right]);
    }
    void update(ll p,ll val)
    {
        update(p,val,0,0,sz-1);
    }
    Node query(ll l,ll r,ll node,ll lx,ll rx)
    {
        if (rx<l || lx>r) return Node();
        if (l<=lx and r>=rx) return tree[node];
        ll mid=(lx+rx)/2,left=2*node+1,right=2*node+2;
        Node L=query(l,r,left,lx,mid),R=query(l,r,right,mid+1,rx);
        return Merge(L,R);
    }
    Node query(ll l,ll r)
    {
        return query(l,r,0,0,sz-1);
    }
};
int main()
{
    Mohammed_Khaled();
    ll t;cin >> t;
    while (t--) {
        ll n;cin >> n;
        vector<ll>a(n);
        for (auto &x : a) cin >> x;
        SegTree seg(a);
        ll q;cin >> q;
        while (q--) {
            ll type;cin >> type;
            if (type == 1) {
                ll i,x;cin >> i >> x;
                seg.update(i - 1,x);
            }
            else {
                int l,r;cin >> l >> r;
                l--;r--;
                int lo = l, hi = r;
                bool ok = false;
                while (lo <= hi) {
                    int mid = (lo + hi) >> 1,mn = seg.query(l, mid).val,d = mid - l;
                    if (mn > d) lo = mid + 1;
                    else if (mn < d)hi = mid - 1;
                    else {
                        ok = true;
                        break;
                    }
                }
                cout << (ok ? 1 : 0) << '\n';
            }
        }
    }
    return 0;
}