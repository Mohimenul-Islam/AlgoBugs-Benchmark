#include<bits/stdc++.h>
using namespace std;
const int N=2e5+5;
int n,k,l,r,q,opt,x,y,t,ans,a[N],mid,tr[N*4],T,tmid;
void build(int id,int l,int r){
    if(l==r){
        tr[id]=a[l];
        return ;
    }
    int mid=l+r>>1;
    build(id*2,l,mid);
    build(id*2+1,mid+1,r);
    tr[id]=min(tr[id*2],tr[id*2+1]);
}
void add(int id,int l,int r,int x,int k){
    if(l==r){
        tr[id]=k;
        return ;
    }
    int mid=l+r>>1;
    if(x<=mid){
        add(id*2,l,mid,x,k);
    }else{
        add(id*2+1,mid+1,r,x,k);
    }
    tr[id]=min(tr[id*2],tr[id*2+1]);
}
int query(int id,int l,int r,int x,int y){
    if(x<=l&&r<=y){
        return tr[id];
    }
    int mid=l+r>>1;
    int sum=1e9;
    if(x<=mid){
        sum=min(query(id*2,l,mid,x,y),sum);
    }
    if(y>mid){
        sum=min(query(id*2+1,mid,r,x,y),sum);
    }
    return sum;
}
bool pd(int l){

    return query(1,1,n,x,x+l)>=l;
}
int main(){
    cin>>T;
    while(T--){
        cin>>n>>q;
        for(int i=1;i<=n;i++){
            cin>>a[i];
        }
        build(1,1,n);
        while(q--){
            cin>>opt>>x>>y;
            if(opt==1){
                add(1,1,n,x,y);
            }else{
                l=0;
                r=y-x;
                // cout<<pd(2)<<'\n';
                while(l<r){
                    tmid=(l+r+1)>>1;
                    if(pd(tmid)){
                        l=tmid;
                    }else{
                        r=tmid-1;
                    }
                }
                if(query(1,1,n,x,x+l)==l){
                    cout<<1<<"\n";
                }else{
                    cout<<0<<"\n";
                }
            }
        }
    }
    return 0;
}