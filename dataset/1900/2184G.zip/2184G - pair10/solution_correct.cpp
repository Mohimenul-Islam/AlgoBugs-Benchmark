#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<ll, ll> pii;
typedef vector<ll> vi;
typedef vector<vi> matrix;
#define rep(i, a, b) for(ll i = a; i < b; i++)
#define down(i, b, a) for(ll i = b - 1; i >= a; i--)

// ─── CONFIGURE HERE ──────────────────────────────────────────────────────────
using T = ll;

T combine(T a, T b) { return min(a, b); }

const T IDENTITY = LLONG_MAX;          // min  → LLONG_MAX
                                       // max  → LLONG_MIN
                                       // sum  → 0
                                       // product → 1
// ─────────────────────────────────────────────────────────────────────────────

struct SegTree {
    ll n;
    vi tree;

    SegTree(ll n) : n(n), tree(2 * n, IDENTITY) {}

    SegTree(vi& arr) : n(arr.size()), tree(2 * arr.size()) {
        rep(i, 0, n)
            tree[n + i] = arr[i];
        down(i, n, 1)
            tree[i] = combine(tree[2*i], tree[2*i+1]);
    }

    void update(ll i, T val) {
        tree[n + i] = val;
        for (ll p = (n + i) / 2; p >= 1; p /= 2)
            tree[p] = combine(tree[2*p], tree[2*p+1]);
    }

    T query(ll l, ll r) {           // [l, r) half-open
        T left = IDENTITY, right = IDENTITY;
        for (l += n, r += n; l < r; l /= 2, r /= 2) {
            if (l & 1) left  = combine(left,  tree[l++]);
            if (r & 1) right = combine(tree[--r], right);
        }
        return combine(left, right);
    }
};

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    ll t;
    cin >> t;

    while(t--){
        ll n, q;
        cin >> n >> q;

        vi a(n);
        rep(i, 0, n) cin >> a[i];

        SegTree seg = SegTree(a);

        while(q--){
            ll idx;
            cin >> idx;

            if(idx == 1){
                ll i, x;
                cin >> i >> x;
                i--;
                seg.update(i, x);
            }
            else{
                ll ls, rs;
                cin >> ls >> rs;
                ls--; rs--;

                ll best = LONG_LONG_MAX;
                ll l = 0, r = rs - ls;
                while(l <= r){
                    ll d = (l + r) / 2;

                    ll ans = d - seg.query(ls, ls + d + 1);
                    if(ans >= 0){
                        best = min(best, ans);
                        r = d - 1;
                    }
                    else{
                        l = d + 1;
                    }
                }

                if(best){
                    cout << 0 << endl;
                }
                else{
                    cout << 1 << endl;
                }
            }
        }
    }
}