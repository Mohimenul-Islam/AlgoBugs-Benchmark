#include <bits/stdc++.h>

using namespace std;
#define ll long long
#define ull unsigned long long
#define db double
#define all(x) x.begin(), x.end()
#define inf (1 << 30)
#define lnf (1LL << 60)
typedef pair<int, int> PII;
constexpr int N = 2e5 + 7;
constexpr int P = 998244353;

int n, q, a[N];

ll t[N * 4];
int lc(int x) { return (x << 1); }
int rc(int x) { return (x << 1 | 1); }

void pushup(int id) { t[id] = min(t[lc(id)], t[rc(id)]); }

void build(int id, int l, int r) {
    t[id] = lnf;
    if (l == r) {
        t[id] = a[l];
        return;
    }
    int mid = (l + r) >> 1;
    build(lc(id), l, mid);
    build(rc(id), mid + 1, r);
    pushup(id);
}

void update(int id, int l, int r, int idx, int v) {
    if (r < idx || l > idx) return;
    if (l == r) {
        t[id] = v;
        return;
    }
    int mid = (l + r) >> 1;
    update(lc(id), l, mid, idx, v);
    update(rc(id), mid + 1, r, idx, v);
    pushup(id);
}

ll query(int id, int l, int r, int ql, int qr) {
    if (r < ql || l > qr) return lnf;
    if (ql <= l && r <= qr) {
        return t[id];
    }
    int mid = (l + r) >> 1;
    return min(query(lc(id), l, mid, ql, qr), query(rc(id), mid + 1, r, ql, qr));
}

void solve() {
    scanf("%d%d", &n, &q);
    for (int i = 1; i <= n; i++) {
        scanf("%d", &a[i]);
    }
    build(1, 1, n);
   
    while (q--) {
        int type, l, r;
        scanf("%d%d%d", &type, &l, &r);
        if (type == 1) {
            update(1, 1, n, l, r);
        } else {
            int le = 0, ri = r - l;
            while (le < ri) {
                int mid = (ri + le) / 2;
                if (query(1, 1, n, l, l + mid) <= mid) ri = mid;
                else le = mid + 1;
            }
            if (query(1, 1, n, l, l + le) != le) {
                puts("0");
                continue;
            }
//            printf("l = %d r = %d\n", l, r);
//            printf("ans = %d\n", L);
            printf("%d\n", le);
        }
    } 
    fill(t + 1, t + 4 * n + 1, lnf);
}

signed main() {
    int T;
    scanf("%d", &T);
    while (T--) solve();
    return 0;
}
/*
5 5
1 2 3 4 5
2 1 5
1 1 5
1 2 5
1 3 1
2 1 5
*/
/*
1
1 1
2 2
2 1 2
*/