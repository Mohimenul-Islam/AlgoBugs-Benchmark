#include <bits/stdc++.h>
using namespace std;

#define f first
#define s second
#define ll long long
#define pii pair<int,int>
#define pli pair<ll,int>
#define pll pair<ll,ll>
#define tiii tuple<int,int,int>
#define tiiii tuple<int,int,int,int>
#define pb push_back
#define eb emplace_back
#define emp emplace
#define mkp make_pair
#define mkt make_tuple
#define vctr vector
#define arr array
#define all(x) x.begin(), x.end()
#define amin(a,b) a = min(a,b)
#define amax(a,b) a = max(a,b)
#define brick(x) cout << #x << " = " << (x) << " | "
#define dbg(x) cout << #x << " = " << (x) << '\n'
#define vdbg(a) cout << #a << " = "; for(auto _x : a)cout << _x << ' '; cout << '\n'
#define adbg(a,n) cout << #a << " = "; for(int _i = 1; _i <= n; ++_i)cout << a[_i] << ' '; cout << '\n'
#define adbg0(a,n) cout << #a << " = "; for(int _i = 0; _i < n; ++_i)cout << a[_i] << ' '; cout << '\n'
mt19937 rng(static_cast<uint32_t>(chrono::steady_clock::now().time_since_epoch().count()));
int uid(int a, int b) { return uniform_int_distribution<int>(a,b)(rng); }
ll uld(ll a, ll b) { return uniform_int_distribution<ll>(a,b)(rng); }

const int MOD = 1e9+7; // 998244353;

struct Segtree {
	using T = int;
	T tree[800005];

	T merge(const T l, const T r) {
		T res = min(l,r);
		return res;
	}

	void build(int n, int l, int r, int *_a) {
		if (l == r) {
			tree[n] = _a[l];
			return;
		}
		build(2*n,l,(l+r)/2,_a);
		build(2*n+1,(l+r)/2+1,r,_a);
		tree[n] = merge(tree[2*n],tree[2*n+1]);
		return;
	}

	void upd(int n, int l, int r, int x, T val) {
		if (x < l || r < x)return;
		if (l == r) {
			tree[n] = val;
			return;
		}
		upd(2*n,l,(l+r)/2,x,val);
		upd(2*n+1,(l+r)/2+1,r,x,val);
		tree[n] = merge(tree[2*n],tree[2*n+1]);
		return;
	}

	T qry(int n, int l, int r, int x, int y) {
		if (l > r || r < x || y < l)return 2e9;
		if (x <= l && r <= y) {
			return tree[n];
		}
		T q1 = qry(2*n,l,(l+r)/2,x,y);
		T q2 = qry(2*n+1,(l+r)/2+1,r,x,y);
		return merge(q1,q2);
	}

	int qry2(int n, int l, int r, int x, int val) {
		if (l > r || r < x)return 0;
		if (x <= l) {
			if (tree[n] >= val)return 0;
			if (l == r)return l;
		}
		int q1 = qry2(2*n,l,(l+r)/2,x,val);
		if (q1)return q1;
		return qry2(2*n+1,(l+r)/2+1,r,x,val);
	}
} tree, tree2;

int a[200005];

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	int tt;
	cin >> tt;
	while (tt--) {
		int n, q;
		cin >> n >> q;
		for (int i = 1; i <= n; ++i) {
			cin >> a[i];
		}
		tree.build(1,1,n,a);
		for (int i = 1; i <= n; ++i) {
			a[i] -= i;
		}
		tree2.build(1,1,n,a);
		for (int i = 1; i <= n; ++i) {
			a[i] += i;
		}
		while (q--) {
			int o, l, r;
			cin >> o >> l >> r;
			if (o == 1) {
				tree.upd(1,1,n,l,r);
				tree2.upd(1,1,n,l,r-l);
			} else {
				int idx = tree2.qry2(1,1,n,l,-l);
				if (idx == 0)idx = n+1;
				if (tree.qry(1,1,n,l,min(r,idx-1)) <= min(r,idx-1)-l) {
					cout << 1 << '\n';
				} else {
					cout << 0 << '\n';
				}
			}
		}
	}
	return 0;
}