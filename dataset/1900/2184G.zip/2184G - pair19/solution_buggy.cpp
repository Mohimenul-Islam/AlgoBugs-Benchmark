#include<bits/stdc++.h>
using namespace std;

#define int long long

struct trea
{
    struct node
    {
        int l;
        int r;
        int mn;
    };
    vector<node>t;
    vector<int>a;
    int n;
    void push_up(int p)
    {
        t[p].mn = min(t[p << 1].mn,t[p << 1 | 1].mn);
    }
    void build(int p,int l,int r)
    {
        t[p] = {l,r,0x3f3f3f};
        if(l == r)
        {
            t[p].mn = a[l];
            return;
        }
        int mid = (l + r) >> 1;
        build(p << 1,l,mid);
        build(p << 1 | 1,mid + 1,r);
        push_up(p);
    }
    trea(int len,vector<int> &arr)
    {
        n = len;
        t.resize((len << 2) + 1);
        a = arr;
        build(1,1,n);
    }
    void update(int p,int pos,int k)
    {
        if(t[p].l == t[p].r && t[p].l == pos)
        {
            t[p].mn = k;
            return;
        }
        int mid = (t[p].l + t[p].r) >> 1;
        if(pos <= mid)update(p << 1,pos,k);
        else update(p << 1 | 1,pos,k);
        push_up(p);
    }
    int query(int p,int nl,int nr)
    {
        if(nl <= t[p].l && t[p].r <= nr)
            return t[p].mn;
        int mid = (t[p].l + t[p].r) >> 1,res = 0x3f3f3f;
        if(nl <= mid)res = min(res,query(p << 1,nl,nr));
        if(nr > mid)res = min(res,query(p << 1 | 1,nl,nr));
        return res;
    }
};

void solve(){
	int n,q;
    cin >> n >> q;
    vector<int>arr(n + 1);
    for(int i = 1;i <= n;i++)
    	cin >> arr[i];
    trea t = trea(n,arr);
    while(q--)
    {
        int op;
        cin >> op;
        if(op == 1)
        {
            int id,x;
            cin >> id >> x;
            t.update(1,id,x);
        }
        else
        {
            int l,r;
            cin >> l >> r;
            int L = l,R = r + 1;
            while(L + 1 != R)
            {
                int mid = (L + R) >> 1;
                int d = mid - l;
                if(t.query(1,l,mid) >= d)L = mid;
                else R = mid;
            }
            cout << ((L - 1)== t.query(1,l,L)) <<endl;
        }
    }
}

signed main(){
	int t;
	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}