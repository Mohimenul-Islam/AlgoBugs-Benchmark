//UPDATERA ARRAY STORLEKEN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
 
const ll INF=1e15;
const ll MAXN=200006;//UPDATERA ARRAY STORLEKEN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
ll t,n,lst[MAXN],ans,m;

ll tree[4*MAXN];

inline ll lc(ll p){return p<<1;}//left child
inline ll rc(ll p){return p<<1|1;}//right child

void push_up(ll p){
    tree[p]=min(tree[lc(p)],tree[rc(p)]);//update p
}

void build(ll root,ll l,ll r){
    if(l==r){
        tree[root]=lst[l];
        return;
    }

    ll mid=(l+r)>>1;
    build(lc(root),l,mid);//recurse left
    build(rc(root),mid+1,r);//recurse right
    push_up(root);
}

void update(ll nl,ll nr,ll l,ll r,ll p,ll k){
    if(nl<=l&&r<=nr){//entire segment with in then process
        tree[p]=k;
        return;
    }
    ll mid=(l+r)>>1;

    if(nl<=mid) update(nl,nr,l,mid,lc(p),k);//recurse left
    if(nr>mid) update(nl,nr,mid+1,r,rc(p),k);//recurse right

    push_up(p);
}

ll query(ll q_l,ll q_r,ll l,ll r,ll p){
    ll res=INF;
    if(q_l<=l&&r<=q_r) return tree[p];
    ll mid=(l+r)>>1;
    if(q_l<=mid) res=min(res,query(q_l,q_r,l,mid,lc(p)));
    if(q_r>mid) res=min(res,query(q_l,q_r,mid+1,r,rc(p)));

    return res;    
}

void init(){
    for(int i=0;i<=n+5;i++){
        lst[i]=0;
    }
    for(int i=0;i<=4*n+5;i++){
        tree[i]=0;
    }
    ans=0;
}

bool binary(ll l,ll r){
    ll start=l,end=r+1;
    while(start<end){
        ll mid=start+(end-start)/2;

        ll mini=query(l,mid,1,n,1);
        if(mini==mid-l){
            return true;
        }else{
            if(mini<mid-l){
                end=mid;
            }else{
                start=mid+1;
            }
        }
    }
    return false;
}

void solve(){
    cin>>n>>m;
    init();
    for(int i=1;i<=n;i++) cin>>lst[i];

    build(1,1,n);

    for(int i=1;i<=m;i++){
        ll op;
        cin>>op;

        if(op==1){
            ll pos,x;
            cin>>pos>>x;
            update(pos,pos,1,n,1,x);
        }else{
            ll l,r;
            cin>>l>>r;

            bool exist=binary(l,r);

            if(exist) cout<<1<<'\n';
            else cout<<0<<'\n';
        }
    }
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>t;
    while(t--){
        solve();
    }
}