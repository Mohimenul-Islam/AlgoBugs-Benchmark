#include<bits/stdc++.h>
#define Guo using
#define Weiqian namespace
#define Code std
#define ll long long
#define N (int)(2e5 + 10)
#define FIO(IN, OUT); freopen(IN, "r", stdin);freopen(OUT, "w", stdout);
Guo Weiqian Code;
int tr[N * 4], lt[N * 4], a[N];

void build(int s, int t, int u){
    tr[u] = 1e9;
	if(s == t){
		tr[u] = a[s];
		return;
	}
	int mid = (s + t) / 2;
	build(s, mid, u * 2);
	build(mid + 1, t, u * 2 + 1);
	tr[u] = min(tr[u * 2], tr[u * 2 + 1]);
} 

void update(int l, int r, int s, int t, int u, int k){
	if(l <= s && t <= r){
		tr[u] = k;
		return;
	}
	int mid = (s + t) / 2;
	if(l <= mid){
		update(l, r, s, mid, u * 2, k);
	}
	if(r > mid){
		update(l, r, mid + 1, t, u * 2 + 1, k);
	}
	tr[u] = min(tr[u * 2], tr[u * 2 + 1]);
}

int getmn(int l, int r, int s, int t, int u){
	if(l <= s && t <= r){
		return tr[u];
	}
	int mid = (s + t) / 2, mn = 1e9;
	if(l <= mid){
		mn = min(mn, getmn(l, r, s, mid, u * 2));
	}
	if(r > mid){
		mn = min(mn, getmn(l, r, mid + 1, t, u * 2 + 1));
	}
	return mn;
}

void work(){
	int n, m;
	cin >> n >> m;
	for(int i = 1; i <= n; i++){
		cin >> a[i];
	} 
	build(1, n, 1);
	while(m--){
		int op;
		cin >> op;
		if(op == 1){
			int x, y;
			cin >> x >> y;
			update(x, x, 1, n, 1, y);
		}else{
			int x, y;
			cin >> x >> y;
            int l1 = 0, r1 = y - x;
			while(l1 < r1){
			    int mid = (l1 + r1 + 1) / 2;
//			    cout << mid << " " << getmn(x, x + mid, 1, n, 1) << "\n";
			    if(getmn(x, x + mid, 1, n, 1) < mid){
			        r1 = mid - 1;
			    }else{
			        l1 = mid;
			    }
			}
			if(getmn(x, x + l1, 1, n, 1) != l1){
			    cout << 0 << "\n";
			    continue;
			}
			int l = 0, r = y - x;
			while(l < r){
			    int mid = (l + r) / 2;
//			    cout << mid << " " << getmn(x, x + mid, 1, n, 1) << "\n";
			    if(getmn(x, x + mid, 1, n, 1) <= mid){
			        r = mid;
			    }else{
			        l = mid + 1;
			    }
			}
			if(getmn(x, x + l, 1, n, 1) != l){
			    cout << 0 << "\n";
			    continue;
			}
			cout << l1 - l + 1 << "\n";
	    }
	}
}

int main(){
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	int oT_To = 1;
	cin >> oT_To;
	while(oT_To--){
		work();
	}
	return 0;
}
