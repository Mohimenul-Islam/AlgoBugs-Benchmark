#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long 
using namespace std;
const ll N = 2e5 + 5;
const ll M = 1e5 + 5;
const ll INF = 1e9;
const ll MOD = 1e9 + 7;
int n,q,a[N],t[N << 2];
int ls(int x){
    return x << 1;
}
int rs(int x){
    return (x << 1) | 1;
}
void pushup(int id){
    t[id] = min(t[ls(id)],t[rs(id)]);
}
void build(int id,int l,int r){
    t[id] = INF;
    if(l == r){
        t[id] = a[l];
        return;
    }
    int mid = (l + r) >> 1;
    build(ls(id),l,mid);
    build(rs(id),mid + 1,r);
    pushup(id);
}
void modify(int id,int l,int r,int x,int k){
    if(r < x || l > x) return;
    if(l == r){
        t[id] = k;
        return;
    }
    int mid = (l + r) >> 1;
    if(x <= mid){
		modify(ls(id),l,mid,x,k);
	}else{
		modify(rs(id),mid + 1,r,x,k);
	}
    pushup(id);
}
int query(int id,int l,int r,int ql,int qr){
    if(ql <= l && r <= qr){
        return t[id];
    }
    int mid = (l + r) >> 1,ans = INF;
    if(ql <= mid){
		ans = query(ls(id),l,mid,ql,qr);
	}
	if(qr > mid){
		ans = min(ans,query(rs(id),mid + 1,r,ql,qr));
	}
    pushup(id);
    return ans;
}
void work(){
    cin >> n >> q;
    for(int i = 1;i <= n;i++){
        cin >> a[i];
    }
    build(1,1,n);
    while(q--){
        int op;
        cin >> op;
        if(op == 1){
            int x,k;
            cin >> x >> k;
            modify(1,1,n,x,k);
        }else{
            int L,R;
            cin >> L >> R;
            int l = 0,r = R - L,mid;
            while(l + 1 < r){
                mid = (l + r) >> 1;
                if(query(1,1,n,L,L + mid) >= mid){
                    l = mid;
                }else{
                    r = mid;
                }
            }
            if(query(1,1,n,L,L + l) == l || query(1,1,n,L,L + r) == r){
				cout << "1\n";
			}else{
				cout << "0\n";
			}
        }
    }
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
	//freopen(".in","r",stdin);
	//freopen(".out","w",stdout);
	int oT_To = 1;
	cin >> oT_To;
	while(oT_To--){ work();}
	return 0;
}