#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long 
using namespace std;
const ll N = 2e5 + 5;
const ll M = 1e5 + 5;
const ll INF = 1e18;
const ll MOD = 1e9 + 7;
ll n,q,a[N],t[N << 2];
ll ls(ll x){
    return x << 1;
}
ll rs(ll x){
    return (x << 1) | 1;
}
void pushup(ll id){
    t[id] = min(t[ls(id)],t[rs(id)]);
}
void build(ll id,ll l,ll r){
    t[id] = INF;
    if(l == r){
        t[id] = a[l];
        return;
    }
    ll mid = (l + r) >> 1;
    build(ls(id),l,mid);
    build(rs(id),mid + 1,r);
    pushup(id);
}
void modify(ll id,ll l,ll r,ll x,ll k){
    if(r < x || l > x) return;
    if(l == r){
        t[id] = k;
        return;
    }
    ll mid = (l + r) >> 1;
    if(x <= mid){
		modify(ls(id),l,mid,x,k);
	}else{
		modify(rs(id),mid + 1,r,x,k);
	}
    pushup(id);
}
ll query(ll id,ll l,ll r,ll ql,ll qr){
    if(ql <= l && r <= qr){
        return t[id];
    }
    ll mid = (l + r) >> 1,ans = INF;
    if(ql <= mid){
		ans = query(ls(id),l,mid,ql,qr);
	}
	if(qr > mid){
		ans = min(ans,query(rs(id),mid + 1,r,ql,qr));
	}
    pushup(id);
    return ans;
}
void work(){
    cin >> n >> q;
    for(int i = 1;i <= n;i++){
        cin >> a[i];
    }
    build(1,1,n);
    while(q--){
        ll op;
        cin >> op;
        if(op == 1){
            ll x,k;
            cin >> x >> k;
            modify(1,1,n,x,k);
        }else{
            ll L,R;
            cin >> L >> R;
            ll l = 0,r = R - L,mid;
            while(l + 1 < r){
                mid = (l + r) >> 1;
                if(query(1,1,n,L,L + mid) >= mid){
                    l = mid;
                }else{
                    r = mid;
                }
            }
            if(query(1,1,n,L,L + l) == l || query(1,1,n,L,L + r) == r){
				cout << "1\n";
			}else{
				cout << "0\n";
			}
        }
    }
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
	//freopen(".in","r",stdin);
	//freopen(".out","w",stdout);
	ll oT_To = 1;
	cin >> oT_To;
	while(oT_To--){ work();}
	return 0;
}