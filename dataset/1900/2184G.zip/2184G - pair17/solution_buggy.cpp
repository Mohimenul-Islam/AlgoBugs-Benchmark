#include<bits/stdc++.h>
#define x first
#define y second
#define endl "\n"
#define MAX INT_MAX
#define LMAX LLONG_MAX
#define ll long long
#define pii pair<int,int>
#define pdd pair<double,double>
#define ull unsigned long long
#ifndef ONLINE_JUDGE
#define debug(...) [](auto... a) { ((cout << a << ' '), ...) << endl; }(#__VA_ARGS__, ":", __VA_ARGS__)
#define debugv(v)                                     \
    do {                                              \
        cout << #v << " : {";                         \
        for (int qiuyu = 0; qiuyu < v.size(); ++qiuyu) { \
            cout << v[qiuyu];                          \
            if (qiuyu + 1 != v.size())                 \
                cout << ",";                          \
        }                                             \
        cout << "}" << endl;                          \
    } while (0)
#else
#define debug(...)
#define debugv(v)
#endif
using namespace std;
template < const int M = 1000000000 + 7 >
struct MInt {
    using LL = long long;
    int x;
    MInt(int x = 0) : x(norm(x)) {}
    MInt(LL x) : x(norm(x % M)) {}
    inline int norm(LL x) const {
        if (x < 0) x += M;
        if (x >= M) x -= M;
        return x;
    }
    inline MInt ksm(MInt x, LL y) const {
        return x ^= y;
    }
    inline int val() const {
        return x;
    }
    inline MInt operator - () const {
        return MInt(norm(M - x));
    }
    inline MInt inv() const {
        assert(x != 0 );
        return *this ^ (M - 2);
    }
    inline MInt& operator *= (const MInt& rhs) {
        x = LL(x) * rhs.x % M;
        return *this;
    }
    inline MInt& operator += (const MInt& rhs) {
        x = norm(x + rhs.x);
        return *this;
    }
    inline MInt& operator -= (const MInt& rhs) {
        x = norm(x - rhs.x);
        return *this;
    }
    inline MInt& operator /= (const MInt& rhs) {
        return *this *= rhs.inv();
    }
    inline MInt& operator ^= (LL y) {
        LL ans = 1;
        while (y) {
            if (y & 1) ans = ans * x % M;
            x = LL(x) * x % M;
            y >>= 1;
        }
        x = ans;
        return *this;
    }
    inline friend MInt operator * (const MInt& lhs, const MInt& rhs) {
        MInt res = lhs;
        res *= rhs;
        return res;
    }
    inline friend MInt operator + (const MInt& lhs, const MInt& rhs) {
        MInt res = lhs;
        res += rhs;
        return res;
    }
    inline friend MInt operator - (const MInt& lhs, const MInt& rhs) {
        MInt res = lhs;
        res -= rhs;
        return res;
    }
    inline friend MInt operator / (const MInt& lhs, const MInt& rhs) {
        MInt res = lhs;
        res /= rhs;
        return res;
    }
    inline friend MInt operator ^ (const MInt& lhs, LL y) {
        MInt res = lhs;
        res ^= y;
        return res;
    }
    inline friend istream& operator >> (istream& is, MInt& a) {
        LL v;
        is >> v;
        a = MInt(v);
        return is;
    }
    inline friend ostream& operator << (ostream& os, const MInt& a) {
        return os << a.val();
    }
};
using Z = MInt<>;
struct SafeProd {
    int zero = 0;
    Z prod = 1;
    void mul(const Z& x) {
        if (x.val() == 0) zero++;
        else prod *= x;
    }
    void div(const Z& x) {
        if (x.val() == 0) zero--;
        else prod /= x;
    }
    Z val() const {
        return zero ? Z(0) : prod;
    }
};

//正难则反
//注意题意中的隐含关系
const int N=2e5+10;
const ll MOD=1e9+7;
const ll mod=998244353;
#define int long long
#define lc p<<1
#define rc p<<1|1 
vector<int>mp(N);
struct node{
    int l,r,v;
}tr[N<<2];
void pushup(int p){
    tr[p].v=min(tr[lc].v,tr[rc].v);
}
void init(int p,int l,int r){
    tr[p]={l,r,MAX};
    if(l==r){
        tr[p].v=mp[l];
        return ;
    }
    int mid=(l+r)/2;
    init(lc,l,mid);
    init(rc,mid+1,r);
    pushup(p);
}
void updata(int p,int c,int d){
    if(tr[p].l==c&&tr[p].r==c){
        tr[p].v=d;
        return ;
    }
    int mid=(tr[p].l+tr[p].r)/2;
    if(c<=mid)updata(lc,c,d);
	else updata(rc,c,d);
    pushup(p);
}
int query(int p,int xx,int yy){
    if(tr[p].l>=xx&&tr[p].r<=yy){
        return tr[p].v;
    }
    int res=MAX;
    int mid=(tr[p].l+tr[p].r)/2;
    if(xx<=mid)res=min(res,query(lc,xx,yy));
	if(yy>mid)res=min(res,query(rc,xx,yy));
	return res;
}
signed main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int tt;
    cin>>tt;
    while(tt--){
        int n,q;
        cin>>n>>q;
        for(int i=1;i<=n;i++){
            cin>>mp[i];
        }
        init(1,1,n);
        while(q--){
            int p,xx,yy;
            cin>>p>>xx>>yy;
            if(p==1){
                updata(1,xx,yy);
            }
            else {
                int res=0;
                int l=xx;
                int r=yy;
                while(l<=r){
                    int mid=(l+r)/2;
                    int u=query(1,xx,mid);
                    if(u==mid){
                        res++;
                        break;
                    }
                    else if(u>mid){
                        l=mid+1;
                    }
                    else {
                        r=mid-1;
                    }
               }
                cout<<res<<endl;
            }
        }
    }
    return 0;
}
