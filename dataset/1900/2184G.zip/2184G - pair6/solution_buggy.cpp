#include<bits/stdc++.h>
#define pre(i, l, r)    for(int i = (l); i <= (r); ++i)
#define fpre(i, r, l)   for(int i = (r); i >= (l); --i)
#define ll long long

using namespace std;

const int maxn = 1e6 + 5;
const int inf = 1e9;
const ll lnf = 2e18;

int t, n, q;
int mi[maxn];

void push_up(int p)
{
    mi[p] = min(mi[p << 1], mi[p << 1 | 1]);
}

void add(int p, int s, int t, int k, int c)
{
    if(s == t)
    {
        mi[p] = c;
        return;
    }
    int mid = (s + t) / 2;
    if(k <= mid)
        add(p << 1, s, mid, k, c);
    else
        add(p << 1 | 1, mid + 1, t, k, c);
    push_up(p);
}

int get_min(int p, int s, int t, int l, int r)
{
    if(l <= s && t <= r)
        return mi[p];
    int mid = (s + t) / 2, res = inf;
    if(l <= mid)
        res = min(res, get_min(p << 1, s, mid, l, r));
    if(r > mid)
        res = min(res, get_min(p << 1 | 1, mid + 1, t, l, r));
    return res;
} 

int main()
{
    scanf("%d", &t);
    while(t--)
    {
        scanf("%d%d", &n, &q);
        pre(i, 1, n)
        {
            int x;
            scanf("%d", &x);
            add(1, 1, n, i, x);
        }
        while(q--)
        {
            int idx;
            scanf("%d", &idx);
            if(idx == 1)
            {
                int i, x;
                scanf("%d%d", &i, &x);
                add(1, 1, n, i, x);
            }
            else
            {
                int l, r;
                scanf("%d%d", &l, &r); 
                int L = 1, R = r - l + 1;
                while(L + 1 < R)
                {
                    int M = (L + R) / 2;
                    if(get_min(1, 1, n, l, l + M) >= M)
                        L = M;
                    else
                        R = M;
                }
                if(get_min(1, 1, n, l, l + L) == L)
                    puts("1");
                else
                    puts("0");
            }
        }
    }
    return 0;
}
