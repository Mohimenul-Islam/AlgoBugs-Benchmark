#include <string>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <numeric>
#include <bitset>
#include <list>
#include <stdexcept>
#include <functional>
#include <utility>
#include <iomanip>
#include <ctime>
#include <valarray>
#include <iostream>
#include <sstream>
#include <fstream>
using namespace std;
typedef long long LL;
typedef unsigned long long ULL;
#define MEM(a,b) memset((a),(b),sizeof(a))
const LL INF = 1e9 + 7;
const int N = 2e5 + 10;
class SegmentTree
{
public:
	int minv[N * 4];
	int ql, qr, qx;
	void set(int l, int r, int x = 1)
	{
		ql = l, qr = r, qx = x;
	}
	void update(int l, int r, int o = 1)
	{
		if (ql <= l && r <= qr)
		{
			minv[o] = qx;
			return;
		}
		int mid = (l + r) / 2;
		if (ql <= mid) update(l, mid, o << 1);
		if (mid < qr) update(mid + 1, r, o << 1 | 1);
		minv[o] = min(minv[o << 1], minv[o << 1 | 1]);
	}
	int query(int l, int r, int o = 1)
	{
		if (ql <= l && r <= qr)
		{
			return minv[o];
		}
		int mid = (l + r) / 2;
		int ret = INF;
		if (ql <= mid) ret = min(ret, query(l, mid, o << 1));
		if (mid < qr) ret = min(ret, query(mid + 1, r, o << 1 | 1));
		return ret;
	}

} st;
int main()
{
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	int ncase;
	scanf("%d", &ncase);
	while (ncase--)
	{
		int n, q;
		scanf("%d%d", &n, &q);
		for (int i = 1; i <= n; i++)
		{
			int x;
			scanf("%d", &x);
			st.set(i, i, x);
			st.update(1, n);
		}
		while (q--)
		{
			int op, x, y;
			scanf("%d%d%d", &op, &x, &y);
			if (op == 1)
			{
				st.set(x, x, y);
				st.update(1, n);
			}
			else
			{
				int l = 1, r = y - x;
				int ans = 0;
				while (l <= r)
				{
					int mid = (l + r) / 2;
					st.set(x, x + mid);
					int minv = st.query(1, n);
					if (minv == mid)
					{
						ans = 1;
						break;
					}
					if (minv < mid) r = mid - 1;
					else l = mid + 1;
				}
				printf("%d\n", ans);
			}
		}
	}
	return 0;
}