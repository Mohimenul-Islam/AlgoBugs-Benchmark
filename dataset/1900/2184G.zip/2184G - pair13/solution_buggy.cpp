#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
using ll = long long;
const ll mod = 1e9 + 7;
const ll inf = 1e18;
const int N = 2e5 + 10;
ll n, q, a[N];
ll tr[N * 4];

void pushup(int i)
{
    tr[i] = min(tr[i * 2], tr[i * 2 + 1]);
}

void build(int i, int l, int r)
{
    if (l == r)
    {
        tr[i] = a[l];
        return;
    }
    int mid = (l + r) >> 1;
    build(i * 2, l, mid);
    build(i * 2 + 1, mid + 1, r);
    pushup(i);
}

void change(int i, int l, int r, int x, int k)
{
    if (l == r)
    {
        tr[i] = k;
        return;
    }
    int mid = (l + r) >> 1;
    if (x <= mid)
        change(i * 2, l, mid, x, k);
    else
        change(i * 2 + 1, mid + 1, r, x, k);
    pushup(i);
}

ll query(int i, int l, int r, int L, int R)
{
    if (l >= L && r <= R)
    {
        return tr[i];
    }
    ll sum = inf;
    int mid = (l + r) >> 1;
    if (mid >= L)
        sum = min(sum, query(i * 2, l, mid, L, R));
    if (mid < R)
        sum = min(sum, query(i * 2 + 1, mid + 1, r, L, R));
    return sum;
}

void solve()
{
    cin >> n >> q;
    for (int i = 1;i <= n;i++)
        cin >> a[i];
    build(1, 1, n);
    while (q--)
    {
        int idx;
        cin >> idx;
        if (idx == 1)
        {
            int x;
            ll k;
            cin >> x >> k;
            change(1, 1, n, x, k);
        }
        else
        {
            int x, y;
            cin >> x >> y;
            int l = 0, r = r - l;
            int ans = 0;
            while (l <= r)
            {
                int mid = (l + r) >> 1;
                int mi = query(1, 1, n, x, mid + x);
                if (mi == mid)
                {
                    ans = 1;
                    break;
                }
                else if (mi > mid)
                {
                    l = mid + 1;
                }
                else
                {
                    r = mid - 1;
                }
            }
            cout << ans << '\n';
        }
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int t;
    cin >> t;
    while (t--)
        solve();
}