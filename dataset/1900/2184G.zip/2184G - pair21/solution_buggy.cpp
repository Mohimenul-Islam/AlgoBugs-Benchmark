//Code-> B87678
/*----- ॐ नमः शिवाय -----*/
#include <bits/stdc++.h>
#include <fstream>
#include <chrono>
using namespace std;

#pragma GCC optimize("O3")
#pragma GCC target("avx2")

// find_by_order(k) returns iterator to kth element starting from 0;
// order_of_key(k) returns count of elements strictly smaller than k;
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
template <class T>
using ordered_set = tree<T,
                         null_type, less<T>, rb_tree_tag,
                         tree_order_statistics_node_update>;
template <class T>
using ordered_multiset = tree<T,
                              null_type, less_equal<T>, rb_tree_tag,
                              tree_order_statistics_node_update>;

typedef __int128_t i128;
typedef long long ll;
typedef string str;
typedef pair<ll, ll> pii;
typedef vector<ll> vi;
#define INF 1e18 + 7
#define rep(i, a, b) for (ll i = a; i <= b; i++)
#define repb(i, b, a) for (ll i = b; i >= a; i--)
const ll N = 5e5+10;
const ll bN = 1e6 + 10;
const ll mod = 998244353;
#define in(x) cin >> x
#define yes cout << "Yes" << endl
#define no cout << "No" << endl
#define show(x) cout << x << endl
#define space(x) cout << x << " "
#define nl cout << endl
#define func(x) x
#define inf (1e18+70)

ll findMSB(ll num)
{
    if (num == 0)
        return 0;

    ll msbPos = static_cast<ll>(log2(num));
    return msbPos;
}

ll roof(ll a, ll b)
{
    if (a < 0)
    {
        a = abs(a);
        if (a % b == 0)
            return -1 * (a / b);
        else
        {
            return -1 * (a / b);
        }
    }
    if (a % b == 0)
        return a / b;
    else
        return (a / b) + 1;
}

ll gcd(ll a, ll b)
{
    return b ? gcd(b, a % b) : a;
}

ll gcd_euclid(ll a, ll b, ll &x, ll &y)
{
    if (b == 0)
    {
        x = 1;
        y = 0;
        return a;
    }
    ll x1, y1;
    ll d = gcd_euclid(b, a % b, x1, y1);
    x = y1;
    y = x1 - (a / b) * y1;
    return d;
}
ll lcm(ll a, ll b)
{   
    ll g = gcd(a,b);
    // if(roof(inf,b)<(a/g)) return inf;
    return (a / g) * b;
}

ll mod_inv(ll a, ll m)
{
    ll x, y;
    ll g = gcd_euclid(a, m, x, y);
    if (g != 1)
        return -1;
    return (x % m + m) % m;
}

ll mod_mul(ll a, ll b, ll m)
{
    ll res = 0;
    a %= m;
    while (b)
    {
        if (b & 1)
            res = (res + a) % m;
        a = (a * 2) % m;
        b >>= 1;
    }
    return res;
}

// agar mod aisa hai ki mod^2 overflow kare then uncomment the mod mul lines
ll binpow(ll a, ll b, ll m = mod)
{
    if (b < 0)
        return 0;
    ll ans = 1;
    ll temp = a;
    while (b)
    {
        if (b & 1)
            ans = mod_mul(ans, temp, m);
        // if(b&1) ans = (ans*temp)%m;
        temp = mod_mul(temp, temp, m);
        // temp=(temp*temp)%m;
        b >>= 1;
    }
    return ans;
}

// ll fact[N];
// ll inv_fact[N];
// void factorial() {
//     fact[0]=fact[1]=1;
//     rep(i,2,N-1) fact[i]=(fact[i-1]*i)%mod;
//     rep(i,0,N-1) inv_fact[i]=mod_inv(fact[i],mod);

// }

// ll ncr(ll n, ll r) {
//     //cout << n << " " << r << endl;
//     if(r>n) return 0;
//     if(n==0 && r==0) return 1;
//     //return NCR[n][r];
//     return ((fact[n]*inv_fact[n-r])%mod*inv_fact[r])%mod;
// }

// ll phi[bN+1];
// //vi primes;
// void sieve() {
//     phi[0] = 0;
//     phi[1] = 1;
//     for (int i = 2; i <= bN; i++)
//         phi[i] = i - 1;

//     for (int i = 2; i <= bN; i++)
//         for (int j = 2 * i; j <= n; j += i)
//               phi[j] -= phi[i];
// }

struct node
{
    ll mn;
    node() = default;
    node(ll _mn) : mn(_mn) {}

};

node combine(const node& A, const node& B, ll l, ll r)
{   
    return node(min(A.mn,B.mn));
}


class segTree
{
public:
    ll n;
    vector<node> t;

    segTree(vi &arr)
    {
        n = arr.size() - 1;
        t.resize(4 * n);
        build(1, 1, n, arr);
    }

    void build(ll ind, ll l, ll r, vi &arr)
    {
        if (l > r)
            return;
        if (l == r)
        {
            t[ind] = node(arr[l]);
            //cout << ind << " " << l <<" "<<r<<": "<<t[ind].f<<" "<<t[ind].ifirst<<" "<<t[ind].ilast<<endl;
            return;
        }
        ll mid = l + (r - l) / 2;
        build(ind * 2, l, mid, arr);
        build(ind * 2 + 1, mid + 1, r, arr);
        // if(ind==2) {
        //     cout<<t[2*ind].f<<" "<<t[2*ind].ilast<<" "<<t[2*ind+1].ifirst<<" "<<(val[t[2*ind].ilast]*(func((t[2*ind+1].ifirst-1))-func((t[2*ind].ilast))))<<endl;
        // }
        // t[ind].mn = min(t[2*ind].mn,t[2*ind+1].mn);
        t[ind] = combine(t[ind*2],t[ind*2+1],l,r);
    
        //cout << ind << " " << l <<" "<<r<<": "<<t[ind].f<<" "<<t[ind].ifirst<<" "<<t[ind].ilast<<endl;
    }

    //a[i]=x
    void update(ll ind, ll tl, ll tr, ll i, ll x)
    {
        if (tl > tr)
            return;
        if (tl == tr)
        {
            t[ind] = node(x);
            return;
        }
        ll mid = tl + (tr - tl) / 2;
        if (i <= mid)
            update(ind * 2, tl, mid, i, x);
        else
            update(ind * 2 + 1, mid + 1, tr, i, x);
        
        t[ind] = combine(t[ind*2],t[ind*2+1],tl,tr);
        
        // t[ind].b = min(t[ind*2].b,t[ind*2+1].b);
    }

    node query(ll ind, ll tl, ll tr, ll l, ll r)
    {
        if (tl > tr)
            return node(INF);
        if (tl > r || tr < l)
            return node(INF);
        if (l == tl && tr == r)
        { /*cout << tl << " " << tr << endl; cout << t[ind].zer<<" "<< t[ind].one<<" "<< t[ind].ans << endl; nl;*/
            return t[ind];
        }
        ll mid = tl + (tr - tl) / 2;
        auto lf = query(ind * 2, tl, mid, l, min(r, mid));
        auto rt = query(ind * 2 + 1, mid + 1, tr, max(l, mid + 1), r);
        return combine(lf,rt,l,r);
    }
};

void solve() 
{   
    ll n,q; cin>>n>>q;
    vi a(n+1);
    rep(i,1,n) cin>>a[i];
    segTree st(a);
    while(q--) {
        ll id; cin>>id;
        if(id==1) {
            ll i,x; cin>>i>>x;
            st.update(1,1,n,i,x);
            a[i]=x;
        }
        else {
            ll l,r; cin>>l>>r;
            ll id = 0;
            for(ll b=(r-l); b>0; b/=2) {
                while((id+b<=r) and ((st.query(1,1,n,l,l+id+b).mn-(id+b)) >= 0)) id+=b;
            }
            cout<<(st.query(1,1,n,l,l+id).mn==id)<<endl;
        }
    }

}


signed main()
{
    srand(time(0));
    ios_base::sync_with_stdio(0);
    cin.tie(NULL);
    cout.tie(0);
    //auto start = chrono::high_resolution_clock::now();
    ll t = 1;
    //comp();
    //sieve();
    //  primes.resize(primes.size());
    // cout<<primes[100001]<<endl;
    //factorial();
    
    cin >> t;
    ll case_no = 1;
    while (case_no <= t)
    {   
        solve();
        case_no++;
    }

    // auto end = chrono::high_resolution_clock::now();
    // chrono::duration<double> duration = end - start;
    // cout << "Execution time: " << duration.count() << " seconds" << endl;
}