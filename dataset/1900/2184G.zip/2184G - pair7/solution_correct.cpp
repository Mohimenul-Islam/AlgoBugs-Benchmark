#include<bits/stdc++.h>
#define LL long long
#define UInt unsigned int
#define ULL unsigned long long
#define LD long double
#define pii pair<int,int>
#define pLL pair<LL,LL>
#define pDD pair<LD,LD>
#define fr first
#define se second
#define pb push_back
#define isr insert
#define _i128 __int128
using namespace std;
const int N = 2e5+5;
const int INF = 0x3f3f3f3f;
LL T,n,Q,a[N],mn[N*4];
LL read(){
    LL su=0,pp=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')pp=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){su=su*10+ch-'0';ch=getchar();}
    return su*pp;
}
int ls(int u){return (u<<1);}
int rs(int u){return (u<<1|1);}
void push_up(int u){
    mn[u]=min(mn[ls(u)],mn[rs(u)]);return;
}
void build(int u,int l,int r){
    if(l==r){mn[u]=a[l];return;}
    int mid=(l+r)>>1;
    build(ls(u),l,mid);build(rs(u),mid+1,r);
    push_up(u);return;
}
void change(int u,int l,int r,int LR,int k){
    if(l>LR||LR>r)return;
    if(l==r&&l==LR){mn[u]=k;return;}
    int mid=(l+r)>>1;
    if(LR<=mid)change(ls(u),l,mid,LR,k);
    else change(rs(u),mid+1,r,LR,k);
    push_up(u);return;
}
int ask(int u,int l,int r,int L,int R){
    if(l>R||L>r)return INF;
    if(L<=l&&r<=R)return mn[u];
    int mid=(l+r)>>1,res=INF;
    if(L<=mid)res=min(res,ask(ls(u),l,mid,L,R));
    if(R>mid)res=min(res,ask(rs(u),mid+1,r,L,R));
    return res;
}
int Sol(int L,int R){
    int l=0,r=R-L,res=0;
    while(l<=r){
        int mid=(l+r)>>1;
        int sol=ask(1,1,n,L,L+mid);
        if(sol>=mid)res=mid,l=mid+1;
        else r=mid-1;
    }int jy=ask(1,1,n,L,L+res);
    return (jy==res);
}
int main(){
    T=read();
    while(T--){
        n=read(),Q=read();
        for(int i=1;i<=n;i++)a[i]=read();
        build(1,1,n);
        while(Q--){
            int opt=read();
            if(opt==1){
                int p=read(),k=read();
                change(1,1,n,p,k);
            }else{
                int l=read(),r=read();
                cout<<Sol(l,r)<<"\n";
            }
        }
    }
    return 0;
}
