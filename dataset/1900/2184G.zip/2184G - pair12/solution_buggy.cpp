#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

void debug(auto arr) {
    for (auto i : arr) cout << i << ' ';
    cout << endl;
}

const ll mod = 998244353;
const int maxn = 2e5 + 10;
const int INF = 2e9;
pair<int, int> t[4*maxn];

pair<int, int> combine(pair<int, int> a, pair<int, int> b) {
    if (a.first < b.first) 
        return a;
    if (b.first < a.first)
        return b;
    return make_pair(a.first, a.second + b.second);
}

void build(int a[], int v, int tl, int tr) {
    if (tl == tr) {
        t[v] = make_pair(a[tl], 1);
    } else {
        int tm = (tl + tr) / 2;
        build(a, v*2, tl, tm);
        build(a, v*2+1, tm+1, tr);
        t[v] = combine(t[v*2], t[v*2+1]);
    }
}

pair<int, int> get_min(int v, int tl, int tr, int l, int r) {
    if (l > r)
        return make_pair(+INF, 0);
    if (l == tl && r == tr)
        return t[v];
    int tm = (tl + tr) / 2;
    return combine(get_min(v*2, tl, tm, l, min(r, tm)), 
                   get_min(v*2+1, tm+1, tr, max(l, tm+1), r));
}

void update(int v, int tl, int tr, int pos, int new_val) {
    if (tl == tr) {
        t[v] = make_pair(new_val, 1);
    } else {
        int tm = (tl + tr) / 2;
        if (pos <= tm)
            update(v*2, tl, tm, pos, new_val);
        else
            update(v*2+1, tm+1, tr, pos, new_val);
        t[v] = combine(t[v*2], t[v*2+1]);
    }
}

void solve() {
    int n, q;
    cin >> n >> q;
    int arr[n];
    for (int i = 0; i < n; i++) cin >> arr[i];
    build(arr, 1, 0, n - 1);

    while (q--) {
        int idx; cin >> idx;
        if (idx == 1) {
            int i, x;
            cin >> i >> x;
            update(1, 0, n - 1, i - 1, x);
        } else {
            int l, r;
            cin >> l >> r;
            l--, r--;
            bool found = false;
            int t = 10;
            int L = l;
            while (l <= r and t--) {
                int m = (l + r) / 2;
                int d = m - L;

                // cout << m << " " << d << " " << L << endl;
                auto val = get_min(1, 0, n - 1, L, m);
                // cout << m << " " << d << " " << val.first << endl;
                if (l == r) {
                    if (val.first != d) break;
                }
                if (val.first == d) {
                    cout << 1 << endl; 
                    found = true;
                    break;
                }
                if (val.first < d) {
                    r = m - 1;
                } else {
                    l = m + 1;
                }
            }
            if (!found) cout << 0 << endl;
            
            // auto val = get_min(1, 0, n - 1, l - 1, r - 1);
            // cout << val.first << " " << val.second << endl;
            // if (val.first <= r - l) {
            //     cout << val.second << endl;
            // } else {
            //     cout << 0 << endl;
            // }

        }
    }
}

int32_t main() {
    #ifndef ONLINE_JUDGE
      freopen("input.txt", "r", stdin);
      freopen("output.txt", "w", stdout);
    #endif
    ios::sync_with_stdio(false), cin.tie(NULL), cout.tie(NULL);
    cout << setprecision(12) << fixed;

    int t = 1;
    cin >> t;

    while (t--)
        solve();

    return 0;
}