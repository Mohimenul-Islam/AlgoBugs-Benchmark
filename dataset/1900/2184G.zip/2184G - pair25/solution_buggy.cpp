#include <bits/stdc++.h>
using namespace std;
struct SegmentTree {
    int n;
    vector<int> seg;

    SegmentTree(vector<int>& arr) {
        n = arr.size();
        seg.resize(4 * n);
        build(0, 0, n - 1, arr);
    }

    void build(int idx, int low, int high, vector<int>& arr) {
        if (low == high) {
            seg[idx] = arr[low];
            return;
        }
        int mid = (low + high) / 2;
        build(2 * idx + 1, low, mid, arr);
        build(2 * idx + 2, mid + 1, high, arr);
        seg[idx] = min(seg[2 * idx + 1], seg[2 * idx + 2]);
    }

    int query(int idx, int low, int high, int l, int r) {
        if (r < low || high < l) return INT_MAX; // no overlap
        if (l <= low && high <= r) return seg[idx]; // complete overlap

        int mid = (low + high) / 2;
        int left = query(2 * idx + 1, low, mid, l, r);
        int right = query(2 * idx + 2, mid + 1, high, l, r);
        return min(left, right);
    }

    int getMin(int l, int r) {
        return query(0, 0, n - 1, l, r);
    }

    void update(int idx, int low, int high, int pos, int val) {
        if (low == high) {
            seg[idx] = val;
            return;
        }
        int mid = (low + high) / 2;
        if (pos <= mid) update(2 * idx + 1, low, mid, pos, val);
        else update(2 * idx + 2, mid + 1, high, pos, val);

        seg[idx] = min(seg[2 * idx + 1], seg[2 * idx + 2]);
    }

    void update(int pos, int val) {
        update(0, 0, n - 1, pos, val);
    }
};
bool check(int l , int r , SegmentTree &st){
    int low = l ; int high = r;
    while(low<=high){
        int mid = (low+high)/2;
        int pfxmin = st.getMin(l,mid);
        int size = mid-l+1;
        if(pfxmin<size){
            high = mid-1;
        }
        else if(pfxmin>size){
            low= mid+1;
        }
        else{
            return true;
        }
    }
    return false;
}
void solve(){
    int n ; cin>>n;
    int q;cin>>q;
    vector<int> arr(n);
    for(int i = 0; i <n ;i++){
        cin>>arr[i];
    }
    SegmentTree st(arr);
    for(int i = 0 ; i<q ; i++){
        int idx;
        cin>>idx;
        if(idx==1){
            int index ; cin>>index;
            index--;
            int value ; cin>>value;
            st.update(index,value);
        }
        else{
            int l,r;cin>>l>>r;
            l--;r--;
            if(check(l,r,st)){
                cout<<1<<endl;
            }
            else cout<<0<<endl;
        }    
    }
}
int main() {
    int t ;cin>>t;
    while(t-->0) solve();
}
