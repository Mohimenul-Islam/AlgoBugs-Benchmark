#include <bits/stdc++.h>
#define pi pair <int, int>
#define fi first
#define se second
#define pb emplace_back
using namespace std;
typedef long long LL;
typedef unsigned long long ull;
constexpr int N = 1e6 + 5, mod = 998244353, inf = 1e9;
void add(int &x, int y) {
    x = x + y >= mod ? x + y - mod : x + y;
}
int qpow(int a, int b = mod - 2) {
    int res = 1;
    while (b) {
        if (b & 1) res = 1LL * res * a % mod;
        a = 1LL * a * a % mod;
        b >>= 1;
    }
    return res;
}
bool Mbe;
int n, q, a[N];
struct SGT {
    #define lc x << 1
    #define rc x << 1 | 1
    #define m ((l + r) >> 1)
    int t[N << 2];
    void pushup(int x) {
        t[x] = min(t[lc], t[rc]);
    }
    void build(int x, int l, int r) {
        t[x] = inf;
        if (l == r) {
            t[x] = a[l];
            return;
        }
        build(lc, l, m);
        build(rc, m + 1, r);
        pushup(x);
    }
    void mdf(int x, int l, int r, int p, int v) {
        if (l == r) {
            t[x] = v;
            return;
        }
        if (p <= m)
            mdf(lc, l, m, p, v);
        else
            mdf(rc, m + 1, r, p, v);
        pushup(x);
    }
    bool qry(int x, int l, int r, int ql, int qr, int &cur, int v) {
        // cerr << l << " " << r << " " << ql << " " << qr << " " << cur << " " << v << "\n";
        if (ql > r || qr < l)
            return false;
        if (ql <= l && qr >= r) {
            int tcur = min(cur, t[x]); 
            if (tcur - r > v) {
                cur = tcur;
                return false;
            }
            if (l == r) {
                cur = tcur;
                return (cur - l) == v;
            }
            bool res = false;
            if (min({cur, t[lc], a[m + 1]}) - (m + 1) >= v) {
                cur = min(cur, t[lc]);
                res = qry(rc, m + 1, r, ql, qr, cur, v);
            } else {
                res = qry(lc, l, m, ql, qr, cur, v);
            }
            cur = tcur;
            return res;
        }
        if (qr <= m)
            return qry(lc, l, m, ql, qr, cur, v);
        if (ql > m)
            return qry(rc, m + 1, r, ql, qr, cur, v);
        return qry(lc, l, m, ql, qr, cur, v) || qry(rc, m + 1, r, ql, qr, cur, v);
    }
    void debug(int x, int l, int r) {
        if (l == r) {
            cerr << t[x] << " ";
            return;
        }
        debug(lc, l, m);
        debug(rc, m + 1, r);
    }
} sgt;
bool Med;
void mian() {
    cin >> n >> q;
    for (int i = 1; i <= n; i++)
        cin >> a[i];
    sgt.build(1, 1, n);
    while (q--) {
        int op, x, y;
        cin >> op >> x >> y;
        if (op == 1) {
            sgt.mdf(1, 1, n, x, y);
            a[x] = y;
        } else {
            int cur = inf;
            cout << (sgt.qry(1, 1, n, x, y, cur, -x) ? "1\n" : "0\n");
        }
        // sgt.debug(1, 1, n); cerr << "\n";
    }
}
int main() {
    // fprintf(stderr, "%.9lfMb\n", 1.0 * (&Mbe - &Med) / 1048576.0);
    ios :: sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
    int t = 1; 
    cin >> t;
    while (t--) mian();
    // fprintf(stderr, "%.3lf ms\n", 1e3 * clock() / CLOCKS_PER_SEC);
    return 0;
}
/*
1
5 5
1 2 3 4 5
2 1 5
1 1 5
1 2 5
1 3 1
2 1 5

*/