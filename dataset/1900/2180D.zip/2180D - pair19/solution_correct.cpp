#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define all(a) a.begin(), a.end()
#define allr(a) a.rbegin(), a.rend()
#define ia(a, n)                   \
        ll a[n];                   \
        for (ll i = 0; i < n; ++i) \
                cin >> a[i];
#define iv(v, n)          \
        vector<ll> v(n);  \
        for (auto &i : v) \
                cin >> i;
#define print(a)                    \
        for (auto &val : a)         \
                cout << val << ' '; \
        cout << endl;
#define noSolution                  \
        {                           \
                cout << -1 << endl; \
                return;             \
        }
#define Yes cout << "Yes\n"
#define No cout << "No\n"
#define YES cout << "YES\n"
#define NO cout << "NO\n"
#define check cout << "CHECK\n"
const ll INF = 1e18, MOD = 1e9 + 7;
const ll ze = 0ll, mod = 998244353;

void printBinary(ll n, ll c)
{
        for (ll i = c; i >= 0; --i)
                cout << ((n >> i) & 1);
        cout << endl;
}

/* Observations

***/

void main_sol()
{
        int n; cin >> n;
        iv(a, n); ll ans = 0;
        ll l = 0, r = n > 1 ? a[1] - a[0] : 0;
        for (ll i = 1; i < n; ++i) {
                ll tl = max(ze, a[i] - a[i - 1] - r);
                ll tr = max(ze, a[i] - a[i - 1] - l);
                if (i < n - 1) { 
                        tr = min(tr, a[i + 1] - a[i]);
                        tl = min(tl, a[i + 1] - a[i]);
                }
                // cout << tl << ' ' << tr << endl;
                if (tr > tl) {
                        ans ++;
                        l = tl;
                        r = tr;
                } else {
                        l = 0;
                        r = (i < n - 1 ? a[i + 1] - a[i] : 0);
                }
        }
        cout << ans << endl;
}

int main()
{
        ios_base ::sync_with_stdio(false);
        cin.tie(NULL);
        ll testcase = 1;
        cin >> testcase;
        while (testcase--)
                main_sol();
        return 0;
}