#include<bits/stdc++.h>
using namespace std;
#define ll long long

void main_sol(){
    ll n; cin >> n;
    vector<ll> a(n);
    for(auto &i: a) cin >> i;
    
    vector<ll> dif(n, 1e10);
    for(ll i = 0; i < n - 1; ++i) 
        dif[i] = a[i + 1] - a[i];
    
    ll s = dif[0], ans = 0;
    for(ll i = 1; i < n; ++i){
        ll low, high;
        
        if(i % 2 == 1) {  
            low = s - dif[i];
            high = s;
        } else { 
            low = -s;
            high = dif[i] - s;
        }
        
        if(high >= low && high > 0){
            s = dif[i] - s;
            ans++;
        } else {
            s = dif[i];
        }
    }
    
    cout << ans << endl;
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    ll testcase = 1;
    cin >> testcase;
    while(testcase--) {
        main_sol();
    }
    
    return 0;
}