#include <bits/stdc++.h>
using namespace std;

// -------------------- Typedefs --------------------
using ll = long long;
using ld = long double;
using pii = pair<int,int>;
using vi = vector<int>;
using vll = vector<ll>;
using pll = pair<ll,ll>;

// -------------------- Constants --------------------
const int INF = 1e9;
const ll LINF = 1e18;
const int MOD = 1e9+7;

// -------------------- Macros --------------------
#define all(x) (x).begin(), (x).end()
#define sz(x) (int)(x).size()

// -------------------- Fast IO --------------------
void fastio() {
ios::sync_with_stdio(false);
cin.tie(nullptr);
}

// -------------------- Debug (remove in contest if needed) --------------------
#ifdef LOCAL
#define debug(x) cerr << #x << " = " << (x) << endl;
#else
#define debug(x)
#endif

// -------------------- Math Utils --------------------
ll gcdll(ll a, ll b) { return b ? gcdll(b, a % b) : a; }
ll lcmll(ll a, ll b) { return a / gcdll(a,b) * b; }

ll modexp(ll a, ll b, ll mod = MOD) {
    ll res = 1 % mod;
    while (b) {
    if (b & 1) res = res * a % mod;
    a = a * a % mod;
    b >>= 1;
}
return res;
}

ll modinv(ll a, ll mod = MOD) {
    return modexp(a, mod - 2, mod); // mod must be prime
}
string ye="YES\n";
string no="NO\n";
void ye_no(bool input){
    if (input) cout<<ye;
    else cout<<no;
}
// -------------------- Main Solve --------------------
void solve() {
    int n;cin>>n;
    
    vll a(n);
    for (ll &i:a) cin>>i;
    a.push_back(LLONG_MAX);
    ll res=0;
    ll mi=a[0],ma=a[1];
    for (int i=1;i<n;i++){
        if (mi>=a[i]){
            
            mi=a[i];ma=2*a[i]-a[i-1];
        }
        else{
            ma=min(ma,a[i]);
            ll nmi,nma;
            nmi=a[i]-ma+a[i];
            nma=a[i]-mi+a[i];
            ma=nma;mi=nmi;
            res++;
        }
        
    }
    cout<<res<<endl;
}

// -------------------- Main --------------------
int main() {
fastio();

    int t = 1;
     cin >> t;
    while (t--) solve();

    return 0;


}
