#include<iostream>
#include<vector>
using namespace std;
void solve(){
	int n, ans = 0;
	cin >> n;
	vector <double> a(n + 2);
	for(int i = 1; i <= n; i++){
		cin >> a[i];
	}
	a[n + 1] = 1e18, a[0] = -1e18;
	double l = 0.00001, r = 1e18;
	for(int i = 2; i <= n; i++){
		r = min(r, a[i] - a[i - 1] - 0.0001);
		if(r < l){
			l = 0.0001, r = a[i] - a[i - 1] - 0.00001;
		}else{
			ans ++;
			double pl = l;
			l = a[i] - a[i - 1] - r;
			r = a[i] - a[i - 1] - pl;
		}
	}
	cout << ans << endl;
}
int main(){
	int t;
	cin >> t;
	while(t--){
		solve();
	}
	return 0;
} 