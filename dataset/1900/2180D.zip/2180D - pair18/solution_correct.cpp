#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m;
template<typename T>
inline void read(T &x) {
    x = 0;
    register char c = getchar();
    register short f = 1;
    while (c < '0' || c > '9') {
        if (c == '-') f = -1;
        c = getchar();
    }
    while (c >= '0' && c <= '9') {
        x = (x << 1) + (x << 3) + (c ^ 48);
        c = getchar();
    }
    x *= f;
}
template <typename T, typename... Args>
inline void read(T &x, Args &...temps)
{
	read(x), read(temps...);
}
void write(int x) {
	static int sta[35];
	int top = 0;
	do {
		sta[top++] = x % 10;
		x /= 10;
	} while (x);
	while (top) putchar(sta[--top] + '0');
}
const int N=2e6+5;
int a[N];
void solve()
{
	read(n);
	for(int i=1;i<=n;i++){
		read(a[i]);
	}
	if(n==1){
		cout<<0<<endl;
		return;
	}
	if(n==2){
		cout<<1<<endl;
		return;
	}
	if(n==3){
		cout<<2<<endl;
		return;
	}
	int ans=2;
	int now;
	int l=0,r=0;	
	if(a[3]-a[2]>a[2]-a[1]){
		l=a[3]-a[2]-a[2]+a[1];
		r=a[3]-a[2];
	}
	else{
		l=0;
		r=a[3]-a[2];
	}

	for(int i=4;i<=n;i++){
		if(a[i]-a[i-1]<=l){
			l=max(0ll,a[i]-2*a[i-1]+a[i-2]);
			r=a[i]-a[i-1];
			continue;
		}
		else if(l<a[i]-a[i-1]&&a[i]-a[i-1]<r){
			ans++;
			r=a[i]-(a[i-1]+l);
			l=0;
		}
		else{
			ans++;
			int nl=l,nr=r;
			l=a[i]-(a[i-1]+nr);
			r=a[i]-(a[i-1]+nl);
		}
	}
	cout<<ans<<endl;
}
signed main(){
	int T;
	read(T);
	while(T--){
		solve();
	}
	return 0;
}
