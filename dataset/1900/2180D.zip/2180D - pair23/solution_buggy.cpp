#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

typedef long long ll;

void solve() {
    int n;
    if (!(cin >> n)) return;
    vector<ll> x(n);
    for (int i = 0; i < n; i++) cin >> x[i];

    if (n <= 1) {
        cout << 0 << "\n";
        return;
    }

    vector<ll> d(n - 1);
    for (int i = 0; i < n - 1; i++) d[i] = x[i+1] - x[i];

    ll ans = 0;
    int i = 0;
    while (i < n - 1) {
        ans++;
        ll L = 0, R = d[i];
        ll current_sum = d[i];
        int j = i + 1;
        while (j <= n - 1) {
            current_sum = d[j] - current_sum;
            int k = j - i + 1;
            if (k % 2 == 1) {
                R = min(R, current_sum);
            } else {
                L = max(L, -current_sum);
            }
            
            if (L >= R) break;
            ans++;
            j++;
        }
        i = j;
    }
    cout << ans << "\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    if (!(cin >> t)) return 0;
    while (t--) {
        solve();
    }
    return 0;
}
