#include <bits/stdc++.h>
#include <cmath>
using namespace std;

#define int long long
#define rep(i,a,b) for (int i = a; i <= b; i++)
#define per(i,a,b) for (int i = a; i >= b; i--)
#define all(v) (v).begin(), (v).end()

const int MAXN = 2e6+10;
const int INF = 1e18+10;
int d[MAXN],a[MAXN],up[MAXN];

void solve() {
    int n; cin >> n;
    rep(i,1,n) cin >> a[i];
    rep(i,2,n) d[i] = a[i]-a[i-1];
    d[1] =d[n+1]= INF;
    rep(i,1,n) up[i] = min(d[i],d[i+1]);

    int L=0,R=up[1], ans = n-1,cur = 0,sig = 0;
    rep(i,2,n) {
        cur = d[i]-cur;
        if(sig==1) {
            L = max(L,-cur);
            R = min(R,up[i]-cur);
        }
        else {
            L = max(L,cur-up[i]);
            R = min(R,cur);
        }
        sig = 1-sig;


        if(L>=R) {
            sig=0;
            ans--;
            L=0;
            R=up[i];
            cur = 0;
        }
    }
    cout << ans << endl;
}

int32_t main() {
    ios_base::sync_with_stdio(0);cin.tie(nullptr);
    int tt = 1;
    cin >> tt;

    while (tt--) solve();
}