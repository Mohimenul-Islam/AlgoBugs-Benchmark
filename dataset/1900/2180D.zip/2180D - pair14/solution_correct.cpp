#include <bits/stdc++.h>
using namespace std;
#define int long long

void solve()
{
    int n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i++)
        cin >> a[i];
    a.push_back(1e18);
    vector<int> d(n);
    for (int i = 0; i < n; i++)
        d[i] = a[i + 1] - a[i];

    int ans = 0;
    int l = 0, r = d[0];
    for (int i = 1; i < n; i++)
    {
        int l1 = d[i - 1] - r;
        int r1 = d[i - 1] - l;
        r1 = min(r1, d[i]);

        if (l1 >= d[i])
        {
            l1 = 0;
        }
        else
            ans++;
        l = l1;
        r = r1;
    }

    cout << ans << endl;
}

int32_t main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int tc;
    cin >> tc;
    while (tc--)
    {
        solve();
    }

    return 0;
}