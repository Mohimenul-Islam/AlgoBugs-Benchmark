#pragma GCC optimize("Ofast")
#include<bits/stdc++.h>
#define ll long long
#define ld long double 
#define se second
#define fi first
#define pb push_back
#define fr front
#define bk back
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define watch(x) cout << #x << " = " << (x) << '\n'
using namespace std;
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

const ll md = 1e9 + 7, md2 = 998244353;

const ll mod = md2;	

const ll MX = 2e5 + 20, inf = 1e9, LOG = 30;
///--------------------
ll dp[MX][5][5];
void Ali(){
	ll n;
	cin >> n;
	ll x[n + 19] = {}, a[n + 19] = {};
	for(ll i = 1;i <= n;i ++){
		cin >> x[i];
	}
	
	ll l = 1, r = x[2] - x[1], ans = 0;
	for(ll i = 2;i <= n;i ++){
		auto [s, t] = make_pair(l, r);
		l = max(1ll, x[i] - x[i - 1] - t);
		r = x[i] - x[i - 1] - s;
		if(i < n and l + x[i] > x[i + 1]){
			ans ++;l = 1;
		}
	}
	cout << n - ans - 1 << '\n';
}
int main(){
	ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
    ll T = 1;
    // cout << fixed << setprecision(7);
	cin >> T;
    while(T --) Ali();
}/// no