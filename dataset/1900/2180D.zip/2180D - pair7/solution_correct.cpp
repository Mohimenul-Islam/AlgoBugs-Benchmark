#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#define int long long
#define ll long long
#define ld long double
#define pb push_back
#define pf push_front
#define ppb pop_back()
#define ppf pop_front()
#define len(x) (int)x.size()
#define vi vector<int>
#define vpii vector<pair<int,int>>
#define vvi vector<vi>
#define all(x) x.begin(),x.end()
#define rall(x) x.rbegin(),x.rend()
#define mii map<int,int>
#define y1 SemeyBilimInnovationLyceum
#define tm (tl+tr>>1)
#define ls v<<1,tl,tm
#define rs v<<1|1,tm+1,tr
#define pii pair<int,int>
#define lb lower_bound
#define ub upper_bound
#define f first
#define s second
#define str string
#define ins insert
#define elif else if
using namespace std;
using namespace __gnu_pbds;
template<typename T>using ordered_set=tree<T,null_type,less<T>,rb_tree_tag,tree_order_statistics_node_update>;
const int maxn=2e6+5,mod=1e9+7,inf=1e18,bir=1,nol=0;
const bool TEST=1;
const str DastanulyMagzhan[15]={"NO\n","YES\n","-1\n","0\n"};
ld vertexofaparabola(int a,int b,int c){return -b/(2*a);}
void at(int ok){cout<<DastanulyMagzhan[ok];}
bool bit(int mask,int i){return (mask>>i)&1;}
int gcd(int a,int b){while(b){if(a>b)swap(a,b);b%=a;}return a;}
int lcm(int a,int b){return a/gcd(a,b)*b;}
int bpm(int a,int b){a%=mod;if(b==0)return 1;if(b&1)return bpm(a,b-1)*a%mod;int x=bpm(a,b>>1);return x*x%mod;}
int bp(int a,int b){if(b==0)return 1;if(b&1)return bp(a,b-1)*a;int x=bp(a,b>>1);return x*x;}
int n,a[maxn],d[maxn];
void whyareucopying(){
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i],d[i]=a[i]-a[i-1];
	int ans=0,l=0,r=1e9;
	for(int i=2;i<=n;i++){
		int wl=l,wr=r;
		if(l>=d[i])l=0,r=d[i];
		elif(r>=d[i])l=0,r=d[i]-wl,ans++;
		else l=d[i]-wr,r=d[i]-wl,ans++;
	}
	cout<<ans<<'\n';
}
signed main(){
//	freopen("txt.in","r",stdin),freopen("txt.out","w",stdout);
	ios_base::sync_with_stdio(false),cin.tie(nullptr);
	srand(time(0));
	int T=1;
	if(TEST)cin>>T;
	for(int i=1;i<=T;i++){
//		cout<<"Case "<<i<<": ";
		whyareucopying();
	}
}