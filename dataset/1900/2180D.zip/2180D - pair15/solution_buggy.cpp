#include <bits/stdc++.h>
using namespace std;
//#define int long long
const int kk = 1e5 + 7;
typedef long long ll;
int n, x[kk],ans;
void solve()
{
    scanf("%d", &n);
    ans = 0;
    for (int i = 1; i <= n; ++i)
        scanf("%lld", &x[i]);
    x[n + 1] = 1e18, x[0] = -1e18;
    double l(0.00001), r(1e18);
    for (int i = 2; i <= n; ++i)
    {
        r = min(r, x[i] - x[i - 1] - 0.0001);
        if (r < l)
            l = 0.0001, r = x[i] - x[i - 1] - 0.00001;
        else
        {
            ++ans;
            double pl = l;
            l = x[i] - x[i - 1] - r, r = x[i] - x[i - 1] - pl;
        }
    }
    printf("%d\n", ans);
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        solve();
    }

    return 0;
}