#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M = (1e9 + 7);
#define yy cout << "YES" << endl;
#define nn cout << "NO" << endl;
#define fi for (int i = 1; i <= n; i++)
#define int long long
#define INT_MAX (int)1e17
#define via               \
    vector<int> a(n + 1); \
    fii;
#define fii                      \
    for (int i = 1; i <= n; i++) \
    {                            \
        cin >> a[i];             \
    };
int bpm(ll a, ll n)
{
    a = a % M;
    int res = 1;
    while (n > 0)
    {
        if (n % 2 == 1)
        {
            res = (res * a) % M;
        }
        a = (a * a) % M;
        n /= 2;
    }
    return res;
}
int bp(ll a, ll n)
{
    int res = 1;
    while (n > 0)
    {
        if (n % 2 == 1)
        {
            res = (res * a);
        }
        a = (a * a);
        n /= 2;
    }
    return res;
}
ll inverse(ll a, ll m)
{
    return bpm(a, M - 2);
}
int32_t main()
{
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        via;
        int ans = 0 , ct = 0, sum = 0,cur = 0;
        ans = n-1;
        // int ct = 0;
        int ind = 1;
        int l = 0,r = 1e15;
        for(int i = 2;i<=n;i++)
        {
            cur = a[i]-a[i-1]-cur;
            int x = INT_MIN,y = INT_MAX;
            if(ind%2)
            {
                y = cur;
                if(i+1<=n)
                {
                    x = cur -(a[i+1]-a[i]);
                }
            }
            else
            {
                x = - cur;
                if(i+1<=n)
                {
                    y = (a[i+1]-a[i]) - cur;
                }
            }
            l = max(l,x);
            r = min(r,y);
            if(l<r)
            {
                ind++;
            }
            else
            {
                ans--;
                ind = 1;
                l =0;
                r = 1e15;
                cur = 0;
            }
        }
        cout<<ans<<endl;
    }
}