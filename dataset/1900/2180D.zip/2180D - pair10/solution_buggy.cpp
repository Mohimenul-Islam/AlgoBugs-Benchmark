#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int M = (1e9 + 7);
#define yy cout << "YES" << endl;
#define nn cout << "NO" << endl;
#define fi for (int i = 1; i <= n; i++)
#define int long long
#define INT_MAX (int)1e17
#define via               \
    vector<int> a(n + 1); \
    fii;
#define fii                      \
    for (int i = 1; i <= n; i++) \
    {                            \
        cin >> a[i];             \
    };
int bpm(ll a, ll n)
{
    a = a % M;
    int res = 1;
    while (n > 0)
    {
        if (n % 2 == 1)
        {
            res = (res * a) % M;
        }
        a = (a * a) % M;
        n /= 2;
    }
    return res;
}
int bp(ll a, ll n)
{
    int res = 1;
    while (n > 0)
    {
        if (n % 2 == 1)
        {
            res = (res * a);
        }
        a = (a * a);
        n /= 2;
    }
    return res;
}
ll inverse(ll a, ll m)
{
    return bpm(a, M - 2);
}
int32_t main()
{
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        via;
        int ans = 0 , ct = 0, sum = 0;
        a.push_back((int)1e17);
        int l = 0 , r = 1e10;
        for(int i = 1;i<=n;i++)
        {
            ct++;
            int x,y;
            int add = 0;
            int d= a[i+1]-a[i];
            if(ct%2)
            {
                x = -sum;
                y = d - sum;
                add = -d;
            }
            else
            {
                x = -sum -d;
                y = -sum;
                add = d;
            }
            l = max(l,x);
            r = min(r,y);
            sum+=add;
            if(l>=r)
            {
                ans+=ct-2;
                sum = add;
                ct = 1;
                l = 0;
                r = 1e10;
            }
        }
        ans+=ct-1;
        cout<<ans<<endl;
    }
}