#include <iostream>
#include <vector>
#include <numeric>
#include <unordered_map>
#include <cstdint>
#include <cstdio>
#include <queue>

using namespace std;

#define ll long long

int main() {
    int tt; cin >> tt;
    while (tt--) {
        int n; cin >> n;
        vector <int> a(n);
        for (int i = 0; i < n; i++) cin >> a[i];
        if (n == 1) {
            cout << 0 << endl;
            continue;
        }
        int ans = 0;
        int l = -1, r = a[1] + 1, sum = 0, m = 1;
        for (int i = 0; i < n - 1; i++) {
            if (m == 1) {
                l = max(l, sum);
                r = min(r, sum + (a[i + 1] - a[i]));
            } else {
                l = max(l, sum - (a[i + 1] - a[i]));
                r = min(r, sum);
            }
            sum += m * (a[i + 1] - a[i]);
            m *= -1;
            if (l >= r) {
                l = 0;
                r = 100000000;
                i++;
                sum = 0;
                m = 1;
            } else {
                ans++;
            }
        }
        cout << ans << endl;
    }
    return 0;
}