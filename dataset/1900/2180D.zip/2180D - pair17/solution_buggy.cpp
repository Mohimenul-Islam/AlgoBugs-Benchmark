#include<bits/stdc++.h>
using namespace std;

// #include<bits/extc++.h>
// using namespace __gnu_cxx;

/** region Templates */
namespace Mine {

#define rep(i, l, r) for(ll i = (l); i <= (r); i++)
#define per(i, r, l) for(ll i = (r); i >= (l); i--)

#define all(a) a.begin(), a.end()
#define all1(a) a.begin() + 1, a.end()

    typedef long long ll;
    typedef long long i64;

    template<typename T = ll> vector<T> INN(int n){
        std::vector<T> a(n);
        for (int i = 0; i < n; i++) std::cin >> a[i];
        return a;
    }

    template<typename T = ll> vector<T> INN1(int n){
        std::vector<T> a(n + 1);
        for (int i = 1; i <= n; i++) std::cin >> a[i];
        return a;
    }

    template<typename T = ll> void OUT(vector<T> &a, const char *gap = " ", bool edl = true){
        int n = a.size();
        for (int i = 0; i < n; i++) std::cout << a[i] << gap;
        if (edl) cout << endl;
    }

    template<typename T = ll> void OUT1(vector<T> &a, const char *gap = " ", bool edl = true){
        int n = a.size();
        for (int i = 1; i < n; i++) std::cout << a[i] << gap;
        if (edl) cout << endl;
    }

    long long fpow(long long x, long long p,const long long & mod) {
        long long ans = 1;
        while (p) {
            if (p & 1) ans = ans * x % mod;
            x = x * x % mod, p >>= 1;
        }
        return ans;
    }

    template<typename T, typename Z>
    inline void chkmax(T &x, const Z &y) { x = x > y ? x : y; }

    template<typename T, typename Z>
    inline void chkmin(T &x, const Z &y) { x = x < y ? x : y; }


    long long *Fac, *Inv, Cmod;
    void Cinit(int n, const long long mod) {
        Cmod = mod;
        Fac = new long long[n];
        Inv = new long long[n];
        Fac[0] = 1;
        for (ll i = 1; i < n ; i++)    Fac[i] = Fac[i - 1] * i       % mod;
        Inv [n - 1] =                  fpow(Fac[n - 1], mod - 2, mod);
        for (ll i = n - 2; i >= 0; i--)Inv[i] = Inv[i + 1] * (i + 1) % mod;
    }
    long long C(long long n, long long m){return Fac[n] * Inv[m] % Cmod * Inv[n - m] % Cmod;}


    template <typename T>
    class BIT {
    private:
        int n;
        T *a, val;
        function<T(T, T)> op;
    public:
        BIT(int size, function<T(T, T)> option ,const T &val): n(size), val(val), op(option) {
            a = new T[n];
            for (int i = 0 ; i < n ; i++) a[i] = val;
        }

        void add(int p, const T &v) {
            if (p == 0) a[0] = op(a[0], v);
            else for (int i = p ; i < n; i += (i & -i)) a[i] = op(a[i], v);
        }

        T ask(ll p) {
            T ans = (p == 0) ? a[0] : val;
            for (int i = p ; i; i -= (i & -i)) ans = op(ans, a[i]);
            return ans;
        }
    };

}
/** endregion */

using namespace Mine;

bool Mbe;
const ll N = 2e6 + 10, M = 360 + 10, mod = 998'244'353;
ll n, k, m, x, y, q, h, p;

void init() {

    // Cinit(N, mod);
}


// #define DEBUG
#define SYNC
#define MULTI
const double eps = 1e-6;
typedef double db;
ll a[N];

inline void solve() {
    cin >> n;
    rep(i, 1, n) cin >> a[i];
    double L = eps, R = 1e10;
    ll ans = n - 1;
    rep(i, 2, n) {
        db d = (db)a[i] - (db)a[i - 1];
        db l = L, r = R;
        R = min(R, d);
        if (L > R) l = eps, r = d - eps, ans--;
        else l = d - R, r = d - L;
        L = l, R = r;

    }
    cout << ans << endl;
}

bool Med;


int main() {
#ifdef SYNC
    ios::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);
#endif
    ll q = 1, clk1 = clock();

#ifdef MULTI
    cin >> q;
#endif
    init();
    while (q--) {
        solve();
    }
#ifdef DEBUG
    cerr << ((&Mbe - &Med) / 1024.0 / 1024.0) << " Mb" << endl;
    cerr << ((clock() - clk1) * 1.0 / CLOCKS_PER_SEC ) << " S" << endl;
#endif
    return 0;
}
//为什么这里总是乱报错