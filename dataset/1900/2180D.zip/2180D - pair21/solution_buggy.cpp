#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;

typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> pbds;
// x.insert(5);  0th element => *x.find_by_order(0)  ; number of elements smaller than5 => x.order_of_key(5); x.erase(5);
#define int long long
#define endl '\n'
#define vi vector<int>
#define vvi vector<vi>
#define pi pair<int,int>
#define all(v) (begin(v), end(v))
#define rep(i,a,b) for (int i=(int)(a); i<(int)(b); ++i)
#define in(c) for (auto &x : (c)) cin >> x;
#define out(c) for (auto &x : (c)) cout << x << " "; cout << '\n';
#define yes cout << "YES\n"
#define no cout << "NO\n"

template <typename T, typename U> inline void mi(T& x, const U& a){ if(a < x) x = a; }
template <typename T, typename U> inline void mx(T& x, const U& a){ if(x < a) x = a; }

void sol(){
    int n;
    cin>>n;

    vi a(n);
    in(a);

    a.push_back(1e18*2);

    int ans=n;

    auto f = [&](int ind)->int{
        int ct=0; int d = a[ind+1]-a[ind];
        for(int i=ind+1;i<n;i++){
            ct = (a[i]-a[i-1])-ct;
            if((i-ind-1)%2==0){
                // ct-d, ct
                if(ct-d>=a[i+1]-a[i]){ans--; return i;}
            }else{
                // ct , ct+d
                if(ct>=a[i+1]-a[i]){ans--; return i;}
            }
        }
        ans--;
        return n;
    };


    int i=0;
    while(i!=n){
        // cout<<i<<endl;
        i=f(i);
    }

    cout<<ans<<endl;
}


signed main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t = 1;
    cin >> t;
    for(int tc = 1; tc <= t; ++tc){
        sol();  
    }
    
    return 0;
}
