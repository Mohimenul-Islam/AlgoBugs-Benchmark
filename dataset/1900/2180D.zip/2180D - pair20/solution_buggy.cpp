// please be patient i have autism

#include <iostream>
#include<math.h>
#include <vector>
#include <map>
#include <set>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <stack>
#include <string>
#include <bitset>
#include <deque>
#include <memory>
#include <random>
#include <algorithm>
#include <iterator>
#include <numeric>
#include <tuple>
#include <thread>
#include <chrono>
#include <iomanip>  

using namespace std;

const int64_t bound = 1e9 + 7;
const int64_t mod = 998244353;
const int64_t inf = 1e18;
 
int64_t gcd(int64_t a, int64_t b) {
    return b ? gcd(b, a % b) : a;
}
 
int64_t binexp(int64_t a, int64_t b) {
    if (!b) return 1;
    int64_t res = binexp(a, b / 2);
    res = (res * res) % mod;
    if (b % 2) res = (res * a) % mod;
    return res;
}
 
int64_t inv(int64_t x) {
    return binexp(x, mod - 2);
}
 
int64_t Cnk(int n, int k, vector<int64_t>& fact,
            vector<int64_t>& inv_fact) {
    return (((fact[n] * inv_fact[k]) % mod) * inv_fact[n - k]) % mod;
}
 
vector<int64_t> get_inv_fact(int n) {
    vector<int64_t> inv_fact(n + 1, 0);
    inv_fact[0] = 1;
    for (int i = 1; i <= n; i++) {
        inv_fact[i] = (inv_fact[i - 1] * inv(i)) % mod;
    }
    return inv_fact;
}


int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        vector<int> x(n + 1, 0), diff(n + 2, 0);
        for (int i = 1; i <= n; i++) {
            cin >> x[i];
        }
        diff[1] = diff[n + 1] = 1e9 + 1;
        vector<pair<int, int>> components;
        for (int i = 2; i <= n; i++) {
            diff[i] = x[i] - x[i - 1];
        }
        int answer = 0;
        double mn = 0, mx = 2e9;
        for (int i = 1; i < n; i++) {
            // cout << " i = " << i << " mn = " << mn << " mx = " << mx << endl;
            // cout << "answer = " << answer << endl;
            if (mn >= diff[i + 1]) {
                mx = diff[i + 1] - mn;
                mn = 0;
            } else {
                answer++;
                double new_mx = (double)diff[i + 1] - mn;
                double new_mn = 0;
                if (mx < diff[i + 1]) {
                    new_mn = (double)diff[i + 1] - mx;
                }
                mn = new_mn;
                mx = new_mx;
            }
        }
        cout << answer << endl;
    }
}