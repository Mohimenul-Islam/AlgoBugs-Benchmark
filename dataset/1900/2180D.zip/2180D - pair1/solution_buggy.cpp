#include<bits/stdc++.h>

#define int long long

using namespace std;

main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int t;
    cin>>t;
    while(t--){
    	int n;
    	cin>>n;
    	vector<int> x(n+1),d(n+1);
    	for(int i=1;i<=n;++i){
    		cin>>x[i];
    		d[i-1]=x[i]-x[i-1];
    	}
    	int a,b=d[1],ans=1,k=1,l=0,r=d[1];
    	for(int i=2;i<n;++i){
    		a=d[i]-b;
    		k++;
    		if(k%2){
    			r=min(r,a);
				l=max(l,-b);
    		}else{
    			l=max(l,-a);
				r=min(r,b);
    		}
			if(l>=r){
				l=0,r=d[i];
				k=1;
				b=d[i];
			}else{
				ans++;
				b=a;
			}
    	}
    	cout<<ans<<"\n";
    }
}
