#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    int t;
    cin >> t;

    while (t--) {
        int n;
        cin >> n;

        vector<int> x(n);
        for (int i = 0; i < n; i++) cin >> x[i];

        int ans = n - 1;
        long long lo = 0, hi = 2e9 + 1;
        long long C = 0;
        int clusterParity = 1;

        for (int i = 1; i < n; i++) {
            C = (x[i] - x[i-1]) - C;

            bool isEvenPos = (i % 2 == clusterParity % 2);

            if (isEvenPos) {
                hi = min(hi, C);
                if (i < n - 1) lo = max(lo, C - (long long)(x[i+1] - x[i]));
            } else {
                lo = max(lo, -C);
                if (i < n - 1) hi = min(hi, (long long)(x[i+1] - x[i]) - C);
            }

            if (lo >= hi) {
                ans--;
                lo = 0;
                hi = 2e9 + 1;
                C = 0;
                clusterParity = i + 1;
            }
        }

        cout << ans << "\n";
    }
}