#include <bits/stdc++.h>
 
using namespace std;
 
#ifdef LOCAL
#include "algo/debug.h"
#else
#define debug(...) 25
#endif

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int tt; cin >> tt;
    while (tt--) {
        int n; cin >> n;
        vector<int> x(n), dp(n, 0);
        for (int i = 0; i < n; i++) {
            cin >> x[i];
        }
        dp[0] = 1;
        dp[n - 1] = -1;
        for (int i = 1; i < n - 1; i++) {
            dp[i] = x[i] - x[i - 1] < x[i + 1] - x[i] ? -1 : 1;
        }
        int result = 0;
        int i = 0;
        // debug(dp);
        for (int i = 0; i < n - 1; i++) {
            // debug(i);
            result += !(dp[i] == -1 && dp[i + 1] == 1);
            // debug(result);
        }
        cout << result << "\n";
    }
    return 0;
}