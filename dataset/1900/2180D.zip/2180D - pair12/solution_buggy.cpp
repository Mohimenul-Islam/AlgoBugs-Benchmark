#pragma GCC optimize("O3")
#include <bits/stdc++.h>

using namespace std;
#define int long long

const int maxN = 2e5+1;
const int mod = 1e9+7;

void solve() {
    int n;
    cin >> n;
    vector<int> x(n);
    for (int i = 0;i < n; i++) {
        cin >> x[i];
    }
    int cur = 0, ans = n - 1, l = 0, r = 1e18, lst = 0;
    for (int i = 1; i < n; i++) {
        cur = x[i] - x[i - 1] - cur;
        if (i - lst &1) {
            r = min(r, cur);
        } else {
            l = max(l, -cur);
        }
        if (l >= r) {
            l = 0; r = 1e18;
            cur = 0;
            ans --;
            lst = i + 1;
        }
    }
    cout << ans << "\n";
}

signed main() {
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif

    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int t = 1;
    cin >> t;
    while(t--){
        solve();
    }
}