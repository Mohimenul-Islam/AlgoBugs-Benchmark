#pragma GCC optimize("Ofast")
#include<bits/stdc++.h>
#include<ext/pb_ds/tree_policy.hpp>
#include<ext/pb_ds/assoc_container.hpp>
#define Imron ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
#define TXT freopen ("input.txt", "r", stdin), freopen("output.txt", "w", stdout);
#define ll long long
#define ld long double
#define ull unsigned long long
#define se second
#define fi first
#define order_set tre<ll, null_type, less<ll>, rb_tre_tag, tre_order_statistics_node_update>
const ll mod = 1e9 + 7;
const ld pi = 3.1415926535;
using namespace __gnu_pbds;
using namespace std;
ll __lcm(ll x, ll y)
{
    return x * y / __gcd(x, y);
}
bool gb(ll x, ll i)
{
    return x & (1ll << i);
}
ll binpow(ll a, ll n, ll m)
{
    if(n < 0)
    {
        return -1;
    }
    if(n == 0)
    {
        return 1 % mod;
    }
    else if(n == 1)
    {
        return a % m;
    }
    else if(n % 2 == 0)
    {
        ll x = binpow(a, n / 2, m);
        return (x * x) % m;
    }
    else
    {
        return (a * binpow(a, n - 1, m)) % m;
    }
}
ll add(ll x, ll y)
{
    x += y;
    if(x < 0)
    {
        x += mod;
    }
    return x % mod;
}
ll mul(ll x, ll y)
{
    return x * y % mod;
}
ll divide(ll x, ll y)
{
    return mul(x, binpow(y, mod - 2, mod));
}
ll fact[200017], inv[200017];
ll C(ll n, ll k)
{
	if(n < k || k < 0) return 0;
	else return mul(mul(fact[n], inv[k]), inv[n - k]);
}
ll t_n;
void IM()
{
	ll n;
	cin >> n;
	ll a[n + 17];
	for(ll i = 1; i <= n; i++)
	{
		cin >> a[i];
	}
	pair<ll, ll> b[n + 17];
	ll ans = n - 1;
	b[1].fi = 1;
	b[1].se = a[2] - a[1];
	for(ll i = 2; i <= n; i++)
	{
		b[i].fi = max(1ll, a[i] - a[i - 1] - b[i - 1].se);
		b[i].se = a[i] - a[i - 1] - b[i - 1].fi;
		if(i + 1 <= n && a[i] + b[i].fi > a[i + 1])
		{
			b[i].fi = 1;
			ans--;
		}
	}
	cout << ans << '\n';
}
signed main()
{
	fact[0] = 1;
	for(ll i = 1; i <= 200000; i++)
	{
		fact[i] = mul(fact[i - 1], i);
	}
	inv[200000] = binpow(fact[200000], mod - 2, mod);
	for(ll i = 200000; i > 0; i--)
	{
		inv[i - 1] = mul(inv[i], i);
	}
    Imron
    //TXT
    ll T = 1;
    cin >> T;
    for(t_n = 1; t_n <= T; t_n++)
    {
        IM();
    }
}	