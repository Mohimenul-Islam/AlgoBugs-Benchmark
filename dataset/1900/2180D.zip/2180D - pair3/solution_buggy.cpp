#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define N 2000005
ll t, n, k, a[N];

void solve(){
    cin >> n;
    for(int i = 0; i < n; i++) {
        cin >> a[i];
        // if(t == 10000 - 55) cout << a[i] << "|";
    }
    for(int i = n - 1; i >= 1; i--){
        a[i] -= a[i - 1];
    }
    ll mi = 0, ma = a[1], ans = n - 1;
    for(int i = 2; i < n; i++){
        if(mi >= a[i]){
            ans--;
            mi = 0;
            ma = a[i];
        }
        else {
            ll tmp = ma;
            ma = a[i] - mi;
            mi = a[i] - tmp;
        }
    }
    cout << ans << "\n";
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL), std::cout.tie(NULL);
    cin >> t;
    while(t--){
        solve();
    }
    return 0;
}
/*

1 2 3 5 6
1 1 2 1


*/