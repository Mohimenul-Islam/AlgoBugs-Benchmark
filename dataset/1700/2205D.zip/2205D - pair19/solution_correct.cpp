#include <bits/stdc++.h>
using namespace std;
#define int long long
void solve(){
    int n;
    cin>>n;
    vector<int> v(n+1);
    for(int i=1;i<=n;i++) cin>>v[i];
    vector<int> nge(n+1,n+1),pge(n+1,0);
    stack<int> st,st1;
    for(int i=1;i<=n;i++){
        while(!st.empty()&&v[i]>v[st.top()]){
            nge[st.top()]=i;
            st.pop();
        }
        st.push(i);
    }
    for(int i=n;i>=1;i--){
        while(!st1.empty()&&v[i]>v[st1.top()]){
            pge[st1.top()]=i;
            st1.pop();
        }
        st1.push(i);
    }
    int id=n+1;
    vector<int> dp1(n+2,0),dp2(n+2,0);
    for(int i=n-1;i>1;i--){
        if(v[i]>v[i+1]&&v[i]>v[i-1]){
            int nx=nge[i];
            dp1[i]=nx-i-1+dp1[nx];
            id=i;
        }
        else dp1[i]=dp1[id];
    }
    id=0;
    for(int i=2;i<=n-1;i++){
        if(v[i]>v[i+1]&&v[i]>v[i-1]){
            int px=pge[i];
            dp2[i]=i-px-1+dp2[px];
            id=i;
        }
        else dp2[i]=dp2[id];
    }
    int ans=LLONG_MAX;
    dp1[1]=dp1[2];
    dp1[0]=dp1[2];
    dp2[n]=dp2[n-1];
    dp2[n+1]=dp2[n-1];
    for(int i=0;i<=n;i++) ans=min(ans,dp2[i]+dp1[i+1]);
    cout<<ans;
}
signed main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin>>t;
    while(t--){
        solve();
        cout<<'\n';
    }
}