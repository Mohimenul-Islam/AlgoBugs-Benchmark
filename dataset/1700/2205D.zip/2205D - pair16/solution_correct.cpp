#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N = 5e5 + 10;

int pos[N], a[N], n;
int tree[N << 2];

void build(int p, int l, int r) {
    if(l == r) {
        tree[p] = a[l];
        return ;
    }
    int mid = (l + r) >> 1;
    build(p << 1, l, mid);
    build(p << 1 | 1, mid + 1, r);
    tree[p] = max(tree[p << 1], tree[p << 1 | 1]);
}

int query(int p, int l, int r, int s, int e) {
    if(s <= l && r <= e) {
        return tree[p];
    }
    int mid = (l + r) >> 1;
    int res = 0;
    if(s <= mid) res = max(res, query(p << 1, l, mid, s, e));
    if(e > mid)  res = max(res, query(p << 1 | 1, mid + 1, r, s, e));
    return res;
}

int f(int l, int r) {
    if(l >= r) return 0;
    int id = pos[query(1, 1, n, l, r)];
    int res = min(id - l + f(id + 1, r), r - id + f(l, id - 1));
    return res;
}

void work() {
    cin >> n;
    for(int i = 1; i <= n; i++) {
        cin >> a[i];
        pos[a[i]] = i;
    }
    build(1, 1, n);
    cout << f(1, n) << endl;
}

signed main() {
    ios::sync_with_stdio(0), cin.tie(0);
    int T; cin >> T;
    while(T--) work();
}