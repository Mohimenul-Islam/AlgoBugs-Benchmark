#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

#define vi vector<ll>
#define vvi vector<vi>
#define endl '\n'
vi a;
map<pair<ll,ll>,ll>dp;

ll f(int l, int r)
{
	if(l>=r) return 0;

	if(dp.find(make_pair(l,r))!=dp.end()) return dp[make_pair(l,r)];
	int k = l;
	for(int i=l+1;i<=r;i++)
	{
		if(a[i]>a[k])k=i;

	}
  
   int ans =  min((r-k)+f(l,k-1),(k-l)+f(k+1, r));
  
    return dp[make_pair(l,r)] = ans;
}
void solve()
{
	ll n;
	cin>>n;
	a.clear();
	a.resize(n);
	for(auto &x:a)cin>>x;
		dp.clear();
	cout<<f(0,n-1)<<endl;
}

signed main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);

	int t;cin>>t; while(t--)
	solve();

	return 0;
}