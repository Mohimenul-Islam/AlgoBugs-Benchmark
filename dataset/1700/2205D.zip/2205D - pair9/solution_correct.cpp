#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

#define vi vector<ll>
#define vvi vector<vi>
#define endl '\n'

vi a;
ll n;
map<pair<ll,ll>,ll> dp;

struct node
{
	ll mxi;
};

node st[4000010];

node merge(node a1, node b1)
{
	if(a1.mxi == 1e7) return b1;
	if(b1.mxi == 1e7) return a1;
	if(a[a1.mxi] > a[b1.mxi]) return a1;
	return b1;
}

void build(ll id,ll l, ll r)
{
	if(l > r) return;

	if(l == r)
	{
		st[id].mxi = l;
		return;
	}

	ll m = l + (r - l) / 2;

	build(2*id+1, l, m);
	build(2*id+2, m+1, r);

	st[id] = merge(st[2*id+1], st[2*id+2]);
}

node query(ll id, ll l,ll r, ll lq, ll rq)
{
	// FIX 1: correct no-overlap condition
	if(r < lq || l > rq)
	{
		node t;
		t.mxi = 1e7;
		return t;
	}

	// FIX 2: correct full overlap condition
	if(lq <= l && r <= rq)
	{
		return st[id];
	}

	ll m = l + (r - l) / 2;

	// FIX 3: correct ranges
	node left = query(2*id+1, l, m, lq, rq);
	node right = query(2*id+2, m+1, r, lq, rq);

	return merge(left, right);
}

ll f(int l, int r)
{
	if(l >= r) return 0;

	if(dp.find(make_pair(l,r)) != dp.end()) 
		return dp[make_pair(l,r)];

	int k = query(0,0,n-1,l,r).mxi;

	if(k == 1e7) return 0;

	int ans = min((r-k) + f(l,k-1), (k-l) + f(k+1,r));

	return dp[make_pair(l,r)] = ans;
}

void solve()
{
	cin >> n;

	a.clear();
	a.resize(n);

	for(auto &x : a) cin >> x;

	build(0,0,n-1);

	dp.clear();

	cout << f(0,n-1) << endl;
}

signed main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int t; cin >> t;
	while(t--) solve();

	return 0;
}