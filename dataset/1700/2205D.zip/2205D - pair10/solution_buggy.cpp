/*------------@T_CrB-------------*/
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
typedef double db;
#define FS fixed << setprecision
#define VC vector
#define endl "\n"
#define NO cout << "No" << endl
#define YES cout << "Yes" << endl
#define BOB cout << "Bob" << endl
#define ALICE cout << "Alice" << endl
#define MAYBE cout << "MAYBE" << endl
const ll INF = (1ll << 63) - 1;
const ll E18 = 1000000000000000000;
const ll mod7 = 1000000007;
const ll mod3 = 998244353;
const ll mod = mod7;
const double eps = 1e-12;
/*********记得开ll***********/
void solve() {
    int n;
    cin >> n;
    VC<int> a(n + 1, 0);
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    VC<int> nxt(n + 1, 0), nyt(n + 1, 0);
    stack<int> st1, st2;
    for (int i = n; i >= 1; i--) {
        while (!st1.empty() && a[st1.top()] <= a[i]) {
            st1.pop();
        }
        if (!st1.empty()) {
            nxt[i] = st1.top();
        } else {
            nxt[i] = n + 1;
        }
        st1.push(i);
    }
    for (int i = 1; i <= n; i++) {
        while (!st2.empty() && a[st2.top()] <= a[i]) {
            st2.pop();
        }
        if (!st2.empty()) {
            nyt[i] = st2.top();
        } else {
            nyt[i] = 0;
        }
        st2.push(i);
    }
    int cnt = 0;
    for (int i = 2; i <= n - 1; i++) {
        if (a[i] == -1) {
            continue;
        }
        if (a[i] == max({a[i - 1], a[i], a[i + 1]})) {
            if (nxt[i] - i <= i - nyt[i]) {
                for (int j = i + 1; j <= nxt[i] - 1; j++) {
                    a[j] = -1;
                    cnt++;
                }
            } else {
                for (int j = i - 1; j >= nyt[i] + 1; j--) {
                    a[j] = -1;
                    cnt++;
                }
            }
        }
    }
    cout << cnt << endl;
}
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
    return (0 - 0); // qwq
}
