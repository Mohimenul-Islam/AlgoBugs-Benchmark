#include <bits/stdc++.h>
using namespace std;
#define ll long long
vector<ll> compute(vector<ll>& v){
    ll n=v.size()-1;
    vector<ll> sub(n+2),nge(n+2);
    vector<bool> mx(n+2);

    for(ll i=2;i<n;i++) if(v[i]>v[i-1]&&v[i]>v[i+1]) mx[i]=1;

    stack<ll> st;
    for(ll i=n;i>=1;i--){
        while(!st.empty()&&v[st.top()]<=v[i]) st.pop();
        nge[i]=st.empty()?-1:st.top();
        st.push(i);
    }

    for(ll i=n;i>=1;i--){
        if(mx[i]){
            ll j=nge[i];
            if(j==-1) sub[i]=n-i;
            else{
                ll d=j-i-1;
                sub[i]=mx[j]?d+sub[j]:d;
            }
        }
        else{
            ll j=nge[i];
            while(j!=-1&&!mx[j]) j=nge[j];
            sub[i]=(j==-1?0:sub[j]);
        }
    }
    return sub;
}
void solve(){
    ll n;cin>>n;
    vector<ll> v(n+1);
    for(ll i=1;i<=n;i++) cin>>v[i];

    ll mn_cnt=0,mx_cnt=0,mid=-1;

    for(ll i=2;i<n;i++){
        if(v[i]<v[i-1]&&v[i]<v[i+1]) mn_cnt++;
        if(v[i]>v[i-1]&&v[i]>v[i+1]){
            mx_cnt++;
            mid=i;
        }
    }

    if(mx_cnt==1 && mn_cnt==0){
        ll left=mid-1;
        ll right=n-mid;
        cout<<min(left,right)<<"\n";
        return;
    }

    if(mn_cnt<=1 && mx_cnt==0){
        cout<<0<<"\n";
        return;
    }

    vector<ll> sub=compute(v);

    vector<ll> vr(n+1);
    for(ll i=1;i<=n;i++) vr[i]=v[n-i+1];

    vector<ll> subr=compute(vr);

    vector<ll> sub2(n+1);
    for(ll i=1;i<=n;i++) sub2[i]=subr[n-i+1];

    ll ans=LLONG_MAX;

    for(ll i=2;i<n;i++){
        ans=min(ans,sub[i]+sub2[i]);
        
    }


    cout<<(ans==LLONG_MAX?0:ans)<<"\n";
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    ll t;cin>>t;
    while(t--) solve();
}