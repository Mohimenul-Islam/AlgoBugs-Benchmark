#include <bits/stdc++.h>
using namespace std;
#define ll long long

const ll nmax=500005,lgmax=20;
ll st[nmax][lgmax],lg[nmax],a[nmax];
void pre(){
    lg[1]=0;
    for(ll i=2;i<nmax;i++) lg[i]=lg[i/2]+1;
}
void build(ll n){
    for(ll i=1;i<=n;i++) st[i][0]=i;
    for(ll j=1;j<lgmax;j++)
        for(ll i=1;i+(1<<j)-1<=n;i++){
            ll l=st[i][j-1],r=st[i+(1<<(j-1))][j-1];
            st[i][j]=(a[l]>a[r]?l:r);
        }
}
ll qry(ll l,ll r){
    ll j=lg[r-l+1];
    ll x=st[l][j],y=st[r-(1<<j)+1][j];
    return (a[x]>a[y]?x:y);
}
ll dfs(ll l,ll r){
    if(l>r) return 0;
    if(l==r) return 1;
    ll m=qry(l,r);
    return 1+max(dfs(l,m-1),dfs(m+1,r));
}
void solve(){
    ll n;cin>>n;
    for(ll i=1;i<=n;i++) cin>>a[i];
    build(n);
    cout<<n-dfs(1,n)<<"\n";
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    pre();
    ll t;cin>>t;
    while(t--) solve();
}