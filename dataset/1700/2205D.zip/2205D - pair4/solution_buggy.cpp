#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define int long long
#define ll long long
#define INF 0x3f3f3f3f3f3f3f3f
const int dxy[5] = {-1, 0, 1, 0, -1};
const char dc[4] = {'U', 'R', 'D', 'L'};
#define DEBUG(x) cerr << #x << " = " << x << endl
const int MAXN = 505;
const int mod = 1e9 + 7;

void solve(){
    int n;
    cin >> n;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; ++i) cin >> a[i];
    int ans = INF;

    auto dfs = [&](auto &&dfs, int l, int r) -> int
    {
        if(l == r) return 0;
        int mid = l;
        for (int i = l; i <= r; ++i){
            if(a[i] > a[mid]) mid = i;
        }
        if(mid == l) return dfs(dfs, mid + 1, r);
        if(mid == r) return dfs(dfs, l, mid - 1);
        return min(mid - l + dfs(dfs, mid + 1, r), r - mid + dfs(dfs, l, mid - 1));
    };
    cout << dfs(dfs, 1, n) << endl;
}

signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int _ = 1;
    cin >> _;
    while(_--){
        solve();
    }
    return 0;
}