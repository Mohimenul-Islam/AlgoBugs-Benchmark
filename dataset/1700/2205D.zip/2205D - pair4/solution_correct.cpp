#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define int long long
#define ll long long
#define INF 0x3f3f3f3f3f3f3f3f
const int dxy[5] = {-1, 0, 1, 0, -1};
const char dc[4] = {'U', 'R', 'D', 'L'};
#define DEBUG(x) cerr << #x << " = " << x << endl
const int MAXN = 5e5 + 1;
const int mod = 1e9 + 7;

int mx_idx[MAXN * 4], a[MAXN];
void build(int l, int r, int i){
    if(l == r) {
        mx_idx[i] = l;
        return;
    }
    int mid = (r + l) >> 1;
    build(l, mid, i << 1);
    build(mid + 1, r, i << 1 | 1);
    mx_idx[i] = a[mx_idx[i << 1]] > a[mx_idx[i << 1 | 1]] ? mx_idx[i << 1] : mx_idx[i << 1 | 1];
}
int query(int aim_l, int aim_r, int l, int r, int i){
    if(r < aim_l || aim_r < l) return 0;
    if(aim_l <= l && r <= aim_r) return mx_idx[i];
    int mid = (r + l) >> 1;
    int x = query(aim_l, aim_r, l, mid, i << 1);
    int y = query(aim_l, aim_r, mid + 1, r, i << 1 | 1);
    return a[x] > a[y] ? x : y;
}
void solve(){
    int n;
    cin >> n;
    for (int i = 1; i <= n; ++i) cin >> a[i];
    build(1, n, 1);

    auto dfs = [&](auto &&dfs, int l, int r) -> int
    {
        if(l == r) return 0;
        int mid = query(l, r, 1, n, 1);
        if(mid == l) return dfs(dfs, mid + 1, r);
        if(mid == r) return dfs(dfs, l, mid - 1);
        return min(mid - l + dfs(dfs, mid + 1, r), r - mid + dfs(dfs, l, mid - 1));
    };
    cout << dfs(dfs, 1, n) << endl;
}

signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int _ = 1;
    cin >> _;
    while(_--){
        solve();
    }
    return 0;
}