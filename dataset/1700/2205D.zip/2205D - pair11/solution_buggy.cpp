#include<bits/stdc++.h>
using namespace std;

#define int long long
#define vi vector<int>

#define el '\n'
#define sz(v) (int)(v).size()

// 右边第一个比它大的
vi getR(vi &a){
    int n=sz(a)-1;
    vi r(n+2,n+1);
    stack<int> st;
    for(int i=1;i<=n;i++){
        while(!st.empty() && a[st.top()]<a[i]){
            r[st.top()]=i;
            st.pop();
        }
        st.push(i);
    }
    return r;
}

// 左边第一个比它大的
vi getL(vi &a){
    int n=sz(a)-1;
    vi l(n+2,0);
    stack<int> st;
    for(int i=n;i>=1;i--){
        while(!st.empty() && a[st.top()]<a[i]){
            l[st.top()]=i;
            st.pop();
        }
        st.push(i);
    }
    return l;
}

void solve(){
    int n;cin>>n;
    vi a(n+1);
    for(int i=1;i<=n;i++) cin>>a[i];

    vi l=getL(a), r=getR(a);

    vi peak(n+1,0);
    for(int i=2;i<n;i++){
        if(a[i]>a[i-1] && a[i]>a[i+1]){
            peak[i]=1;
        }
    }

    int ans=0;
    for(int i=1;i<=n;i++){
        if(peak[i]){
            int ll=i-l[i]-1;
            int rr=r[i]-i-1;
            if(ll<rr){
                ans+=ll;
            }else{
                ans+=rr;
                i=r[i]-1;
            }
        }
    }

    int res=0;
    for(int i=n;i>=1;i--){
        if(peak[i]){
            int ll=i-l[i]-1;
            int rr=r[i]-i-1;
            if(ll<rr){
                res+=ll;
                i=l[i]+1;
            }else{
                res+=rr;
            }
        }
    }

    cout<<min(ans,res)<<el;
}

signed main(){
    ios::sync_with_stdio(0);
    cin.tie(0);

    int T;cin>>T;
    while(T--) solve();
}