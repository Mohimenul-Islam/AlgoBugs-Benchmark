#include<bits/stdc++.h>
using namespace std;

#define int long long
#define uint unsigned long long
#define i128 __int128_t
#define ld long double
#define str string
#define vi vector<int>
#define vvi vector<vi>
#define vvvi vector<vvi>
#define pii pair<int,int>
#define tiii tuple<int,int,int>
#define mii map<int,int>
#define vs vector<str>
#define vb vector<bool>
#define vpii vector<pii>

#define F first
#define S second
#define el '\n'
#define kel(x,y) " \n"[x==y]
#define strk(s) s=" "+s

#define sz(v) (int)(v).size() 
#define all(v) v.begin(),v.end()
#define all1(v) v.begin()+1,v.end()
#define down [&](const auto& x,const auto& y){return x>y;}

#define fix(x) fixed << setprecision(x)
#define YES cout << "YES" << el
#define Yes cout << "Yes" << el
#define NO cout << "NO" << el
#define No cout << "No" << el

#define ciallo return

template<class... T>void debug(T... x) {std::cerr << "--->"; ((std::cerr << x << " "), ...); std::cerr << "\n";}
#define vdebug(a) {std::cerr << "--->"; std::cerr << #a << " = "; for(auto x: a) std::cerr << x << " "; std::cerr << "\n";}
#define bd std::cerr << "===============" << el;

// int dx[]={0,1,0,-1};
// int dy[]={1,0,-1,0};
// int dx[]={-1,-1,-1,0,0,1,1,1};
// int dy[]={-1,0,1,-1,1,-1,0,1};

// const int N=2e5+5;
const int INF=0x3f3f3f3f3f3f3f3f;
// const int mod=1e9+7;
const int mod=998244353;

vi fuck(vi a){
    int n=sz(a);
    vi res(n,n);
    res[0]=0;
    stack<int> st;
    for(int i=1;i<n;i++){
        if(st.empty()){
            st.push(i);
            continue;
        }
        while(!st.empty()&&a[st.top()]<a[i]){
            res[st.top()]=i;
            st.pop();
        }
        st.push(i);
    }
    res[n-1]=n;
    return res;
}

vi cnm(vi a){
    int n=sz(a);
    vi res(n,0);
    stack<int> st;
    for(int i=n-1;i>=1;i--){
        if(st.empty()){
            st.push(i);
            continue;
        }
        while(!st.empty()&&a[st.top()]<a[i]){
            res[st.top()]=i;
            st.pop();
        }
        st.push(i);
    }
    return res;
}

void Ciallo(){
    int n;cin >> n;
    vi a(n+1);
    for(int i=1;i<=n;i++) cin >> a[i];
    vi l(n+1,0),r(n+1,n+1);
    stack<int> st;
    for(int i=1;i<=n;i++){
        while(!st.empty()&&a[i]>a[st.top()]){
            r[st.top()]=i;
            st.pop();
        }
        if(!st.empty()) l[i]=st.top();
        st.push(i);
    }
    int ans=0;
    vi fl(n+1),fr(n+1);
    for(int i=1;i<=n;i++){
        fl[i]=(l[i]==0?0:1+fl[l[i]]);
    }
    for(int i=n;i>=1;i--){
        fr[i]=(r[i]==n+1?0:1+fr[r[i]]);
    }
    for(int i=1;i<=n;i++){
        ans=max(ans,fl[i]+1+fr[i]);
    }
    ans=n-ans;
    cout << ans << el;
    ciallo;
}

signed main(){
    ios::sync_with_stdio(0);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int T=1;
    cin >> T;
    while(T--) Ciallo();
    ciallo 0;
}