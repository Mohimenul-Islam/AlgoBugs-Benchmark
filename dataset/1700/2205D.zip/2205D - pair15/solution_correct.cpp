#include <bits/stdc++.h>
#define int long long
#define fi first
#define se second
#define pb push_back
#define debug(c) cout << #c << " = " << c << endl
using namespace std;
typedef pair<int, int> pii;
typedef pair<int, pii> ipii;
const int INF = 2e18+10;
const int MAXN = 5e5+5;
const int MOD = 1e9+7;

int a[MAXN], n;
vector<pii> seg;

pii merge(pii a, pii b) {
	if (a.fi > b.fi) return a;
	else return b;
}

void build(int idx, int l, int r) {
	if (l == r) {
		seg[idx] = {a[l], l}; return;
	}
	int mid = (l+r)/2;
	build(2*idx, l, mid); build(2*idx+1, mid+1, r);
	seg[idx] = merge(seg[2*idx], seg[2*idx+1]);
}

pii que(int idx, int l, int r, int ql, int qr) {
	if (l > qr || r < ql) return {0, 0};
	if (ql <= l && r <= qr) return seg[idx];
	int mid = (l+r)/2;
	return merge(que(2*idx, l, mid, ql, qr), que(2*idx+1, mid+1, r, ql, qr));
}

int run(int l, int r) {
	if (abs(l-r) <= 1) return 0;
	auto [mx, idx] = que(1, 1, n, l, r);
	if (idx == r) return run(l, r-1);
	if (idx == l) return run(l+1, r);
	return min(run(l, idx-1)+r-idx, run(idx+1, r)+idx-l);
}

void solve() {
	cin >> n;
	for (int i = 1; i <= n; i++) cin >> a[i];
	seg.assign(4*n+5, {0, 0});
	build(1, 1, n);
	cout << run(1, n) << endl;
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr); cout.tie(nullptr);
	int tc; cin >> tc; while(tc--) solve();
	return 0;
}