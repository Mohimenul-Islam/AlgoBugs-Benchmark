//#include <budka>
#include <vector>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <bitset>
#include <iomanip>
#include <complex>
#include <random>
#include <stdio.h>
#include <time.h>
#include <string>
#include <queue>
#include <stack>
#include <map>
#include <cmath>
#include <memory>
#include <set>
#include <deque>
#include <unordered_set>
#include <unordered_map>
#include <functional>
//#include <ext/pb_ds/assoc_container.hpp>

#define all(x) x.begin(), x.end()
#define dall(x) x.rbegin(), x.rend()
#define forv(g, obj) for(auto& g: obj)
#define forn(i, idx, n) for(int i = idx; i <= n; ++i)
#define nforn(i, idx, n) for (int i = idx; i < n; ++i)
#define dforn(i, idx, n) for(int i = idx; i >= n; --i)
#define yes cout << "yes" << endl
#define no  cout << "no" << endl
#define pli pair<ll, int>
#define pil pair<int, ll>
#define vl vector<ll>
#define vvl vector<vector<ll>>
#define vi vector<int>
#define vvi vector<vector<int>>
#define vpii vector<pair<int, int>>
#define vpli vector<pli>
#define vpil vector<pil>
#define vs vector<string>
#define vpll vector<pair<ll, ll>>
#define vvpll vector<vector<pair<ll, ll>>>
#define vvpii vector<vector<pair<int, int>>>
#define vvpil vector<vector<pair<int, ll>>>
#define vvpli vector<vector<pair<ll, int>>>
#define vvvi vector<vector<vector<int>>>
#define vvvl vector<vector<vector<ll>>>
#define print(obj) cerr << obj << endl;

#define pii pair<int, int>
#define fst first
#define piii pair<int, pair<int, int>>
#define sec second
#define pll pair<ll, ll>

#define sz(obj) (int)(obj.size())

#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using namespace std;
using ll = int64_t;
//using namespace __gnu_pbds;

//typedef tree<int,null_type,less<int>, rb_tree_tag,
//tree_order_statistics_node_update> ordered_set;


template<typename T, typename U>
ostream& operator << (ostream& os, const pair<T, U>& a) {
    os << a.first << ' ' << a.second;
    return os;
}

template<typename T, typename U>
istream& operator >> (istream& is, pair<T, U>& a) {
    is >> a.first >> a.second;
    
    return is;
}


const double PI = 3.14159265;
const int iinf = 1e9;
const ll inf = 1e18;
const double eps = 1e-10;
const string abc = "abcdefghijklmnopqrstuvwxyz";

template<typename T>
T gcd(T a, T b)
{
    while(a > 0 && b > 0)
    {
        if(a > b) a %= b;
        else b %= a;
    }

    return a | b;
}

template<typename T>
T nok(T a, T b)
{
    return (a*b)/gcd(a, b);
}

template<typename T>
T binPow(T x, T y, T mod) {
    T ans = 1;
    
    while (y) {
        if (y & 1LL) ans = (ans * x) % mod;
        x = (x * x) % mod;
        y >>= 1LL;
    }
    
    return ans;
}

struct Node {
    ll val = 0;
    bool mod = false;
};


struct SegTree {
    vector<Node> t;
    int size;
    SegTree(int size) : size(size) {
        int i = 1;
        while ((1 << i) < size) ++i;
        t.resize((1 << (i + 1)));
        build(0, 0, size);
    }
    
    Node merge(Node& l, Node& r) {
        Node res;
        res.val = l.val + r.val;
        return res;
    };
    
    void build(int v, int l, int r) {
        if (l + 1 == r) {
            t[v].val = 1;
            return;
        }
        
        int m = l + (r - l) / 2;
        build(2 * v + 1, l, m);
        build(2 * v + 2, m, r);
        
        t[v] = merge(t[2 * v + 1], t[2 * v + 2]);
    }
    
    void push(int v, int l, int r) {
        if (!t[v].mod) return;
        t[v].val = 0;
        if (r - l > 1) {
            t[2 * v + 1].mod = true;
            t[2 * v + 2].mod = true;
        }
        
        t[v].mod = false;
    }
    
    ll get(int v, int l, int r, int a, int b) {
        push(v, l, r);
        if (l >= b || r <= a) return 0;
        if (a <= l && r <= b) return t[v].val;
        
        int m = l + (r - l) / 2;
        
        return (get(2 * v + 1, l, m, a, b) + get(2 * v + 2, m, r, a, b));
    }
    
    
    void upd(int v, int l, int r, int a, int b) {
        push(v, l, r);
        if (r <= a || l >= b) return;
        if (a <= l && r <= b) {
            t[v].mod = true;
            push(v, l, r);
            return;
        }
        
        int m = (r + l) >> 1;
        upd(2 * v + 1, l, m, a, b);
        upd(2 * v + 2, m, r, a, b);
        t[v] = merge(t[2 * v + 1], t[2 * v + 2]);
    }
    
    
    void upd(int l, int r) {
        upd(0, 0, size, l, r);
    }
    
    ll get(int l, int r) {
        return get(0, 0, size, l, r);
    }
};




void solve() {
    int n;
    cin >> n;
    
    vi a(n);
    forv(nxt, a) cin >> nxt;
    SegTree seg(n);
    vi pos(n);
    stack<int> st;
    st.push(0);
    
    forn(i, 0, n - 1) {
        while (!st.empty() && a[st.top()] <= a[i]) st.pop();
        pos[i] = st.empty() ? 0 : st.top() + 1;
        st.push(i);
    }
    
    while (!st.empty()) st.pop();
    st.push(n - 1);
    vi suff_pos(n);
    
    dforn(i, n - 1, 0) {
        while (!st.empty() && a[st.top()] <= a[i]) st.pop();
        suff_pos[i] = st.empty() ? n : st.top();
        st.push(i);
    }
    
    suff_pos[n - 1] = n;
    
    int ans = 0;
    vi t;
    forn(i, 1, n - 2)
    if (a[i] > a[i + 1] && a[i - 1] < a[i]) t.push_back(i);
    
    sort(all(t), [&] (int i, int j) {return a[i] > a[j];});
    
    forv(nxt, t) {
        ll pref = seg.get(pos[nxt], nxt), suff = seg.get(nxt + 1, suff_pos[nxt]);
        ans += min(pref, suff);
        if (pref < suff) {
            seg.upd(pos[nxt], nxt);
        } else {
            seg.upd(nxt + 1, suff_pos[nxt]);
        }
    }
    
    
    
    cout << ans << endl;
}

    



 


/*   /\_/\
*   (= ._.)
*   / >  \>
*/

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    
 #ifdef _DEBUG
    freopen("input.txt", "rt", stdin);
//    freopen("output.txt", "wt", stdout);
 #endif
    
    int t = 1;
    cin >> t;
    
    while (t --> 0)
        solve();

    return 0;
}
