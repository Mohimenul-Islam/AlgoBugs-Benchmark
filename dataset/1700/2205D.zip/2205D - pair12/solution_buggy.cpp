#include <bits/stdc++.h>

using namespace std;
 
#define ll long long
#define ld long double
#define ull unsigned long long
#define pll pair<ll, ll>
#define ppll pair< pair<long long, long long>, long long >
#define ff first
#define ss second
#define pb push_back
#define pf push_front
 
const ll DIM = 5e5 + 7;
const ll INF = 1e18;
const ll mod = 1e9 + 7;
const ll maxlog = 20;
const ll bsize = 350;

ll sp[maxlog][DIM], pos[DIM], st[DIM];
ll n;

ll solve (ll L, ll R) {

    if (L >= R) return 0;

    ll level = st[R-L+1];
    ll m = pos[max(sp[level][L], sp[level][R-(1<<level)+1])];


    ll r1 = solve(L, m-1) + R - m;

    ll r2 = solve(m+1, R) + (m-1) - (L-1);

    return min(r1, r2);

}

void solve() {

    cin >> n;

    memset(sp[0], 0, sizeof(sp[0]));

    for (int i=1; i<=n; i++) {
        cin >> sp[0][i];
        pos[sp[0][i]] = i;
    }

    for (int level=1; level<maxlog; level++) {
        for (int i=1; i<=n; i++) {
            sp[level][i] = max(sp[level-1][i], sp[level-1][i+(1LL << (level-1))]);
        }
    }


    cout << solve(1, n) << endl;

}
 
int main() {
    //ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);

    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);

    for (int i=2; i<DIM; i++) st[i] = st[i/2] + 1;
 
    int ntest = 1;
    cin >> ntest;
    while (ntest--) {
        solve();
    }
    return 0;
 
}
;