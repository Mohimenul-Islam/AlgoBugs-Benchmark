#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define int long long
typedef long long ll;
typedef unsigned long long ull;
#define F(i,l,r) for(int i = (l);i<=(r);i++)
typedef unsigned long long ull;
#define lowbit(x) ((x)&-(x))
#define cer(x) cerr<<x<<'\n';
typedef pair<int,int> PII;
#define pub push_back
#define heap priority_queue//大根堆
template<class T> using heapi =  priority_queue<T,vector<T>,greater<T>>;
#define f1 first
#define f2 second
const int N = 5e5+9;//全局2e8,局部2e5
const int M = 998244353;
const int INF = 0x3f3f3f3f3f3f3f3f;
// INF = 1e9+06,2^30 = 1e9+07,哈希131,状态取反用和值去减
//double 1e-11,long double 1e-15,__float128 1e-29

int dp[20][N],ans;
int get(int l,int r){
	int k = __lg(r-l+1);
	return max(dp[k][l],dp[k][r-(1<<k)+1]);
}
void dfs(int l,int r,int cnt){
	if(l==r){
		ans = min(ans,cnt);
		return;
	}else if(cnt>=ans) return;
	int mx = get(l,r);
	if(mx == dp[0][l]){
		dfs(l+1,r,cnt);
	}else if(mx==dp[0][r]){
		dfs(l,r-1,cnt);
	}else{
		int i = l;
		while(dp[0][++i] != mx);
		dfs(l,i-1,cnt + r-i);
		dfs(i+1,r,cnt + i-l);
	}
}
void mains(){
	int n;cin>>n;
	F(i,1,n){
		cin>>dp[0][i];
	}
	F(i,1,19){
		F(j,1,n){
			if(j+(1<<i)-1<=n) dp[i][j] = max(dp[i-1][j],dp[i-1][j+(1<<(i-1))]);
		}
	}
	ans = INF;
	dfs(1,n,0);
	cout<<ans;
}
signed main(){
	cin.tie(0)->sync_with_stdio(0);
	int T = 1;
	cin>>T;
	while(T--){
		mains();
		cout<<endl;
	}
	return 0;
}