#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define int long long
typedef long long ll;
typedef unsigned long long ull;
#define F(i,l,r) for(int i = (l);i<=(r);i++)
typedef unsigned long long ull;
#define lowbit(x) ((x)&-(x))
#define cer(x) cerr<<x<<'\n';
typedef pair<int,int> PII;
#define pub push_back
#define heap priority_queue//大根堆
template<class T> using heapi =  priority_queue<T,vector<T>,greater<T>>;
#define f1 first
#define f2 second
const int N = 5e5+9;//全局2e8,局部2e5
const int M = 998244353;
const int INF = 0x3f3f3f3f3f3f3f3f;
// INF = 1e9+06,2^30 = 1e9+07,哈希131,状态取反用和值去减
//double 1e-11,long double 1e-15,__float128 1e-29

void mains(){
	int n;cin>>n;
	vector<int>a(n+1),ls(n+1),rs(n+1),st;
	st.reserve(n);
	F(i,1,n){
		cin>>a[i];
	}
	F(i,1,n){
		int last = 0;
		while(!st.empty() && a[st.back()]<a[i]){
			last = st.back();
			st.pop_back();
		}
		if(!st.empty()) rs[st.back()] = i;
		if(last) ls[i] = last;
		st.pub(i);
	}
	int root = st[0];
	vector<int>ord,h(n+1);
	ord.reserve(n);
	st.clear();
	st.pub(root);
	while(!st.empty()){
		int u = st.back();
		st.pop_back();
		ord.pub(u);
		if(ls[u]) st.pub(ls[u]);
		if(rs[u]) st.pub(rs[u]);
	}
	for(int i = (int)ord.size()-1;i>=0;i--){
		int u = ord[i];
		h[u] = max(h[ls[u]],h[rs[u]]) + 1;
	}
	cout<<n-h[root];
}
signed main(){
	cin.tie(0)->sync_with_stdio(0);
	int T = 1;
	cin>>T;
	while(T--){
		mains();
		cout<<endl;
	}
	return 0;
}
