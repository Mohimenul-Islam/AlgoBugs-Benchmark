/*
 -stuff you should look for-
* int overflow, array bounds
* special cases (n=1?)
* do something instead of nothing and stay organized
* WRITE STUFF DOWN
* DON'T GET STUCK ON ONE APPROACH
*/

#include <bits/stdc++.h>
using namespace std;
// #define int long long
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;

const int MOD = 1e9+7;
const ll INF = 5e18+69;

int n;
vector<int> a(5e5+10), cleft(5e5+10), cright(5e5+10), tree(2e6+10);

void update(int id, int l, int r, int pos, int val){
    if (!(l <= pos && pos <= r)) return;
    if (l == r && r == pos){
        tree[id] = val;
        return;
    }
    int mid = (l+r)/2;

    update(id*2, l, mid, pos, val); update(id*2+1, mid+1, r, pos,val);
    tree[id] = max(tree[id*2],tree[id*2+1]);
}

int getmax(int id, int l, int r, int u, int v){
    if (r < u || l > v || u > v) return 0;
    if (u <= l && r <= v) return tree[id];

    int mid = (l+r)/2;
    return max(getmax(id*2,l,mid,u,v),getmax(id*2+1,mid+1,r,u,v));
}

void updatemin(int id, int l, int r, int pos, int val){
    if (!(l <= pos && pos <= r)) return;
    if (l == r && r == pos){
        tree[id] = val;
        return;
    }
    int mid = (l+r)/2;

    updatemin(id*2, l, mid, pos, val); updatemin(id*2+1, mid+1, r, pos,val);
    tree[id] = min(tree[id*2],tree[id*2+1]);
}

int getmin(int id, int l, int r, int u, int v){
    if (r < u || l > v || u > v) return n+1;
    if (u <= l && r <= v) return tree[id];

    int mid = (l+r)/2;
    return min(getmin(id*2,l,mid,u,v),getmin(id*2+1,mid+1,r,u,v));
}


void solve(){

    cin >> n;
    for (int i = 1; i <= n; i++) cin >> a[i];

    for (int i = 1; i <= 4*n; i++) tree[i] = 0;
    cleft[1] = 1; update(1,1,n,a[1],1);
    for (int i = 2; i <= n; i++){
        cleft[i] = cleft[getmax(1,1,n,a[i]+1,n)]+1;
        update(1,1,n,a[i],i);
    }

    ////////////////
    for (int i = 1; i <= 4*n; i++) tree[i] = n+1;
    cright[n] = 1; updatemin(1,1,n,a[n],n);
    for (int i = n-1; i >= 1; i--){
        cright[i] = cright[getmin(1,1,n,a[i]+1,n)]+1;
        updatemin(1,1,n,a[i],i);
    }

    //for (int i = 1; i <= n; i++) cout << cleft[i] << ' '; cout << endl;
    //for (int i = 1; i <= n; i++) cout << cright[i] << ' '; cout << endl;

    int ans = max(cright[1],cleft[n]);

    for (int i = 2; i < n; i++){
        if (a[i-1] > a[i] && a[i] < a[i+1]) ans = max({ans,cleft[i-1]+cright[i+1]+1});
    }

    cout << n-ans << endl;
    //~~~~~~~~RESET~~~~~~~~~~~~

    //~~~~~~DONE_RESET~~~~~~~~~
}

signed main(){
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    #ifndef ONLINE_JUDGE
    freopen("D:/Desktop/Workspace/C++/INPUT.INP","r",stdin);
    freopen("D:/Desktop/Workspace/C++/OUTPUT.OUT","w",stdout);
    #endif
    int t; cin >> t; while (t--)
    solve();
}
