#pragma region template
#include <bits/stdc++.h>
using namespace std;
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;

using ll = long long;
using ull = unsigned long long;
#define ceil(n, m) (((n) + (m) - 1) / (m))
#define sub(a, b, m) (((a % m) - (b % m) + m) % m)
#define all(vec) vec.begin(), vec.end()
#define rall(vec) vec.rbegin(), vec.rend()
#define fi first
#define se second
#define _ ' '
#define endl '\n'

template <class A, class B>
struct Pair {
  A x;
  B y;

  constexpr Pair() : x(), y() {}
  constexpr Pair(const A& a, const B& b) : x(a), y(b) {}

  template <class U1, class U2>
  constexpr Pair(U1&& a, U2&& b)
      : x(std::forward<U1>(a)), y(std::forward<U2>(b)) {}

  template <class U1, class U2>
  constexpr Pair(const Pair<U1, U2>& p) : x(p.x), y(p.y) {}

  template <class U1, class U2>
  constexpr Pair(Pair<U1, U2>&& p)
      : x(std::forward<U1>(p.x)), y(std::forward<U2>(p.y)) {}

  template <class U1, class U2>
  constexpr Pair(const std::pair<U1, U2>& p) : x(p.first), y(p.second) {}

  template <class U1, class U2>
  constexpr Pair(std::pair<U1, U2>&& p)
      : x(std::forward<U1>(p.first)), y(std::forward<U2>(p.second)) {}

  constexpr Pair(const Pair&) = default;
  constexpr Pair(Pair&&) = default;
  constexpr Pair& operator=(const Pair&) = default;
  constexpr Pair& operator=(Pair&&) = default;

  template <class U1, class U2>
  constexpr Pair& operator=(const std::pair<U1, U2>& p) {
    x = p.first;
    y = p.second;
    return *this;
  }

  template <class U1, class U2>
  constexpr Pair& operator=(std::pair<U1, U2>&& p) {
    x = std::forward<U1>(p.first);
    y = std::forward<U2>(p.second);
    return *this;
  }

  constexpr operator std::pair<A, B>() const { return {x, y}; }

  constexpr void swap(Pair& other) noexcept(noexcept(std::swap(x, other.x)) &&
                                            noexcept(std::swap(y, other.y))) {
    using std::swap;
    swap(x, other.x);
    swap(y, other.y);
  }

  friend constexpr bool operator==(const Pair& a, const Pair& b) {
    return a.x == b.x && a.y == b.y;
  }
  friend constexpr bool operator!=(const Pair& a, const Pair& b) {
    return !(a == b);
  }
  friend constexpr bool operator<(const Pair& a, const Pair& b) {
    return (a.x < b.x) || (!(b.x < a.x) && a.y < b.y);
  }
  friend constexpr bool operator>(const Pair& a, const Pair& b) {
    return b < a;
  }
  friend constexpr bool operator<=(const Pair& a, const Pair& b) {
    return !(b < a);
  }
  friend constexpr bool operator>=(const Pair& a, const Pair& b) {
    return !(a < b);
  }
};

template <class A, class B>
Pair(A, B) -> Pair<A, B>;

template <std::size_t I, class A, class B>
constexpr auto& get(Pair<A, B>& p) noexcept {
  static_assert(I < 2);
  if constexpr (I == 0)
    return p.x;
  else
    return p.y;
}

template <std::size_t I, class A, class B>
constexpr const auto& get(const Pair<A, B>& p) noexcept {
  static_assert(I < 2);
  if constexpr (I == 0)
    return p.x;
  else
    return p.y;
}

template <std::size_t I, class A, class B>
constexpr auto&& get(Pair<A, B>&& p) noexcept {
  static_assert(I < 2);
  if constexpr (I == 0)
    return std::move(p.x);
  else
    return std::move(p.y);
}

template <std::size_t I, class A, class B>
constexpr const auto&& get(const Pair<A, B>&& p) noexcept {
  static_assert(I < 2);
  if constexpr (I == 0)
    return std::move(p.x);
  else
    return std::move(p.y);
}

namespace std {
template <class A, class B>
struct tuple_size<Pair<A, B>> : integral_constant<size_t, 2> {};

template <class A, class B>
struct tuple_element<0, Pair<A, B>> {
  using type = A;
};

template <class A, class B>
struct tuple_element<1, Pair<A, B>> {
  using type = B;
};

template <class A, class B>
struct hash<Pair<A, B>> {
  size_t operator()(const Pair<A, B>& p) const {
    size_t h1 = std::hash<A>{}(p.x);
    size_t h2 = std::hash<B>{}(p.y);
    return h1 ^ (h2 + 0x9e3779b97f4a7c15ULL + (h1 << 6) + (h1 >> 2));
  }
};
};  // namespace std

#define pair Pair

template <class T>
using ordered_set =
    tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

pair<int, int> dir[]{{-1, 0}, {0, 1}, {1, 0}, {0, -1}};
pair<int, int> diag[]{
    {-1, 0}, {-1, 1}, {0, 1}, {1, 1}, {1, 0}, {1, -1}, {0, -1}, {-1, -1},
};

template <typename T>
istream& operator>>(istream& in, vector<T>& v) {
  for (T& x : v) in >> x;
  return in;
}

template <typename T>
ostream& operator<<(ostream& out, const vector<T>& v) {
  for (const T& x : v) out << x << ' ';
  return out;
}

#ifdef LOCAL
#include "../tools/debug.h"
#else
#define DBG(...)
#define CHK(...)
#endif

#pragma endregion template

constexpr int MOD = 998244353, N = 2e5 + 67;

#pragma region segtree
enum class Q { GCD, Min, Max, Sum };
template <class T, Q Q>
class Segtree {
 private:
  int n = 0;
  int base = 1;
  T identity;
  vector<T> tree;

  static constexpr T combine(const T& a, const T& b) {
    if constexpr (Q == Q::GCD) {
      return std::gcd(a, b);
    } else if constexpr (Q == Q::Min) {
      return std::min(a, b);
    } else if constexpr (Q == Q::Max) {
      return std::max(a, b);
    } else {
      return a + b;
    }
  }

  static constexpr T default_identity() {
    if constexpr (Q == Q::Min) {
      return numeric_limits<T>::max();
    } else if constexpr (Q == Q::Max) {
      return numeric_limits<T>::lowest();
    } else {
      return T{};
    }
  }

  void pull(int p) {
    for (p >>= 1; p >= 1; p >>= 1)
      tree[p] = combine(tree[p << 1], tree[p << 1 | 1]);
  }

 public:
  explicit Segtree(int n_ = 0, const T& id = default_identity())
      : n(n_), identity(id) {
    while (base < n) base <<= 1;
    tree.assign(base << 1, identity);
  }

  explicit Segtree(const vector<T>& a, const T& id = default_identity())
      : identity(id) {
    build(a);
  }

  int size() const { return n; }
  bool empty() const { return n == 0; }

  void build(const vector<T>& a) {
    n = a.size();
    base = 1;
    while (base < n) base <<= 1;
    tree.assign(base << 1, identity);

    for (int i = 0; i < n; ++i) tree[base + i] = a[i];
    for (int i = base - 1; i >= 1; --i) {
      tree[i] = combine(tree[i << 1], tree[i << 1 | 1]);
    }
  }

  // query on [l, r)
  T query(int l, int r) const {
    l = clamp(l, 0, n);
    r = clamp(r, 0, n);

    T L = identity, R = identity;
    for (l += base, r += base; l < r; l >>= 1, r >>= 1) {
      if (l & 1) L = combine(L, tree[l++]);
      if (r & 1) R = combine(tree[--r], R);
    }
    return combine(L, R);
  }

  bool set(int i, const T& x) {
    if (i < 0 || i >= n) return false;
    int p = base + i;
    tree[p] = x;
    pull(p);
    return true;
  }

  bool add(int i, const T& delta) {
    if (i < 0 || i >= n) return false;
    int p = base + i;
    tree[p] = tree[p] + delta;
    pull(p);
    return true;
  }

  T get(int i) const {
    if (i < 0 || i >= n) return identity;
    return tree[base + i];
  }

  T qall() const { return n ? tree[1] : identity; }

  vector<T> dump() const {
    return vector<T>(tree.begin() + base, tree.begin() + base + n);
  }
};
#pragma endregion segtree

int n;
vector<int> a;
Segtree<int, Q::Max> st;
map<int, set<int>> pos;

int ans(int l, int r) {
  if (l >= r) return 0;
  int v = st.query(l, r + 1);
  int m = *pos[v].lower_bound(l);
  return min(m - l + ans(m + 1, r), r - m + ans(l, m - 1));
}

void solve() {
  cin >> n;
  a.resize(n);
  for (int& x : a) cin >> x;
  for (int i = 0; i < n; ++i) pos[a[i]].insert(i);
  st.build(a);
  cout << ans(0, n - 1) << '\n';
}

int main() {
  ios::sync_with_stdio(false);
  cin.tie(0);
  int tc = 1;
  cin >> tc;
  for (int t = 1; t <= tc; t++) {
    // cout << "Case #" << t << ": ";
    solve();
  }
}