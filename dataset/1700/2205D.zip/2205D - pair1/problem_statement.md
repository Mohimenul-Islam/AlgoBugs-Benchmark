# D. Simons and Beating Peaks

**Time limit:** 2 seconds
**Memory limit:** 512 megabytes

## Problem Statement

My loveliest wishes dissolved into the air; At eighteen, I poured my dreams into the mic to share.

— SHUN, [720](https://open.spotify.com/track/3bhQrFuaaPk8pMMb7TcU2d)

We call an array $$$b$$$ of length $$$m$$$ cool if and only if:

*   There exists no index $$$i$$$ ($$$1 \\lt i \\lt m$$$) such that $$$b\_i=\\max(\\{b\_{i-1}, b\_i, b\_{i+1}\\})$$$.

Simons has an array $$$a$$$ of size $$$n$$$. Initially, the array is a permutation$$$^{\\text{∗}}$$$.

He must perform the following operation until the array is cool:

*   Choose an index $$$i$$$ ($$$1 \\lt i \\lt n$$$) such that $$$a\_i=\\max(\\{a\_{i-1}, a\_i, a\_{i+1}\\})$$$.
*   Then, he can remove either $$$a\_{i-1}$$$ or $$$a\_{i+1}$$$ from the array. After removal, a gap appears in the array, and the left and right sides of the gap will be rejoined.

Find the minimum number of operations for Simons to perform.

$$$^{\\text{∗}}$$$A permutation of length $$$n$$$ is an array consisting of $$$n$$$ distinct integers from $$$1$$$ to $$$n$$$ in arbitrary order. For example, $$$\[2,3,1,5,4\]$$$ is a permutation, but $$$\[1,2,2\]$$$ is not a permutation ($$$2$$$ appears twice in the array), and $$$\[1,3,4\]$$$ is also not a permutation ($$$n=3$$$ but there is $$$4$$$ in the array).

## Input

Each test contains multiple test cases. The first line contains the number of test cases $$$t$$$ ($$$1 \\le t \\le 5\\cdot 10^4$$$). The description of the test cases follows.

The first line contains an integer $$$n$$$ ($$$3\\le n\\le 5\\cdot 10^5$$$) — the size of $$$a$$$.

The second line contains $$$n$$$ integers $$$a\_1,a\_2,\\ldots,a\_n$$$ ($$$1\\le a\_i\\le n$$$, all $$$a\_i$$$-s are distinct) — the array Simons has initially.

It is guaranteed that the sum of $$$n$$$ over all test cases does not exceed $$$5\\cdot 10^5$$$.

## Output

For each test case, print a single integer — the minimum number of operations for Simons to perform.

## Sample Tests

### Input
```
5
3
1 2 3
5
4 1 3 2 5
6
4 5 3 6 2 1
7
6 5 1 7 4 2 3
15
7 4 10 12 9 14 5 3 8 11 1 15 2 13 6
```

### Output
```
0
1
3
3
9
```

## Note

In the first test case, the array is cool initially, so Simons can't perform any operation. The answer is $$$0$$$.

In the second test case, Simons can perform as follows:

*   Choose index $$$3$$$, because $$$a\_3=\\max(\\{a\_2,a\_3,a\_4\\})$$$. Then, he removes $$$a\_{2}$$$ from the array. The array becomes $$$\[4,3,2,5\]$$$.

We can see the array is cool now. Thus, the answer is $$$1$$$.

In the third test case, Simons can perform as follows:

*   Choose index $$$2$$$. Then, he removes $$$a\_1$$$ from the array. The array becomes $$$\[5,3,6,2,1\]$$$.
*   Choose index $$$3$$$. Then, he removes $$$a\_2$$$ from the array. The array becomes $$$\[5,6,2,1\]$$$.
*   Choose index $$$2$$$. Then, he removes $$$a\_1$$$ from the array. The array becomes $$$\[6,2,1\]$$$.

Thus, Simons makes the array cool in $$$3$$$ operations.