#include <bits/stdc++.h>
using namespace std;
using ll = long long;
void printArr(vector<int> &A){
    for(auto a: A){
        cout<<a<<" ";
    }
    cout<<"\n";
}
ll fast_pow(ll a, ll b){
    ll res = 1;
    while (b>0){
        if (b%2==1)res*=a;
        a*=a;
        b/=2;
    }
    return res;
}

/*
123 234 
876 769 69-
    763 632
*/

int n;
vector<int> A;
vector<ll> lis(int st, int end){
    vector<int> lis;
    ll idx = 0;
    for(int i = st; i<end; i++){
        int j = lower_bound(lis.begin(), lis.end(), A[i])-lis.begin();
        if (j==lis.size()){
            lis.push_back(A[i]);
            idx = i;
        }
        else{
            lis[j] = A[i];
        }
    }
    return {(ll)lis.size(), idx};
}

vector<ll> lds(int st, int end){
    vector<int> lds;
    ll idx = 0;
    for(int i = st; i<end; i++){
        int j = lower_bound(lds.begin(), lds.end(), -A[i])-lds.begin();
        if (j==lds.size()){
            lds.push_back(-A[i]);
            idx = i;
        }
        else{
            lds[j] = -A[i];
        }
    }
    return {(ll)lds.size(), idx};
}
void solve(){
    int mx = max_element(A.begin(), A.end())-A.begin();
    vector<ll> l = lds(0, mx);
    vector<ll> al = lis(l[1]+1, mx+1);
    vector<ll> r = lds(mx, n);
    vector<ll> ar = lis(r[1]+1, n);
    cout<<n-max<ll>(
        max<ll>(l[0]+al[0], r[0]+ar[0]), 
        lis(0, mx+1)[0]
)<<"\n";
    
}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(nullptr);
    int t;
    cin>>t;
    while (t--){
        cin>>n;
        A.clear();
        for(int i = 0; i<n; i++){
            int a;
            cin>>a;
            A.push_back(a);
        }
        solve();
    }
}