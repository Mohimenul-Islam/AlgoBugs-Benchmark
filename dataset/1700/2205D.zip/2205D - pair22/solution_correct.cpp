#include <bits/stdc++.h>
using namespace std;
using ll = long long;
void printArr(vector<int> &A){
    for(auto a: A){
        cout<<a<<" ";
    }
    cout<<"\n";
}
ll fast_pow(ll a, ll b){
    ll res = 1;
    while (b>0){
        if (b%2==1)res*=a;
        a*=a;
        b/=2;
    }
    return res;
}

/*
*/

int n;
vector<int> A;
void solve(){
    vector<int> l(n, 0), r(n, 0);
    stack<int> sl, sr;
    for(int i = 0; i<n; i++){
        while(!sl.empty() && sl.top()<A[i])sl.pop();
        l[i] = sl.size();
        sl.push(A[i]);
    }
    for(int i = n-1; i>=0; i--){
        while(!sr.empty() && sr.top()<A[i])sr.pop();
        r[i] = sr.size();
        sr.push(A[i]);
    }
    ll res = INT_MAX;
    for(int i = 0; i<n; i++){
        res = min<ll>(res, n-(l[i]+r[i]+1));
    }
    cout<<res<<"\n";
}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(nullptr);
    int t;
    cin>>t;
    while (t--){
        cin>>n;
        A.clear();
        for(int i = 0; i<n; i++){
            int a;
            cin>>a;
            A.push_back(a);
        }
        solve();
    }
}