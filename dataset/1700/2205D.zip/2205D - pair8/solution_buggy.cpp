#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N = 2e5 + 10, M = 20;

int a[N], st[N][M];

int query(int l, int r) {
	int k = log2(r - l + 1);
	return max(st[l][k], st[r - (1 << k) + 1][k]);	
}

void solve() {	
	int n;
	cin >> n;
	
	vector<int> idx(n + 1);
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
		st[i][0] = a[i];
		idx[a[i]] = i;
	}
	
	for (int j = 1; j <= log2(n); j++) {
		for (int i = 1; i + (1 << j) - 1 <= n; i++) {
			st[i][j] = max(st[i][j - 1], st[i + (1 << j - 1)][j - 1]);
		}
	}
	
	function<int(int, int)> dp = [&] (int l, int r) {
		if (r - l + 1 <= 2) {
			return 0;
		}
		int p = idx[query(l, r)];
		return min(dp(l, p - 1) + r - p, dp(p + 1, r) + p - l);
	};
	
	cout << dp(1, n) << "\n";
}

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);

	int T = 1;
	cin >> T;

	while (T--) {
		solve();
	}

	return 0;
}
