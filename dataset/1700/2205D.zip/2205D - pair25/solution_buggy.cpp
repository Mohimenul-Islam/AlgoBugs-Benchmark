#pragma GCC optimize("O3","inline","unroll-loops", "tree-vectorize")
#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/tree_policy.hpp>
#include<ext/pb_ds/hash_policy.hpp>
#include<ext/pb_ds/priority_queue.hpp>
using namespace std;
using ll=long long;
using ld=long double;
using vs=vector<string>;
using vll=vector<ll>;
using vvll=vector<vll>;
using v3ll=vector<vvll>;
using pll=pair<ll,ll>;
using p3l=pair<ll,pll>;
using vpll=vector<pll>;
const ll seed=chrono::steady_clock::now().time_since_epoch().count();
mt19937_64 rng(seed);
constexpr ll inf=numeric_limits<ll>::max()>>1;
#define mp make_pair
#define pb push_back
#define ist insert
#define fi first
#define sc second
#define endl '\n'
#define f(x,y,z) for(ll x=(y);x<(z);++x)
#define rf(x,y,z) for(ll x=(y);x>=(z);--x)
#define fe(x,y) for(auto &x:(y))
#define sz(v) ((ll)(v).size())
#define all(v) (v).begin(),(v).end()
#define rall(v) (v).rbegin(),(v).rend()
#define pcnt(x) (__builtin_popcountll(x))
#define lg2(x) ((x)?63-__builtin_clzll(x):-1)
#define ctz(x) ((x)?__builtin_ctzll(x):64)
#define rll(l,r) uniform_int_distribution<ll>(l,r)(rng)
#define rld(l,r) uniform_real_distribution<ld>(l,r)(rng)
#define in(x,y,h,w) (0<=(x)&&(x)<h&&0<=(y)&&(y)<w)
#define dsc(v) do{sort(all(v));(v).erase(unique(all(v)),(v).end());}while(0)
#define fix(x) cout<<fixed<<setprecision(x)
#define tmax(x,...) ((x)=max({(x),__VA_ARGS__}))
#define tmin(x,...) ((x)=min({(x),__VA_ARGS__}))
struct chash{
    ll operator()(ll x)const{
        x+=seed+0x9e3779b97f4a7c15;
        x=(x^(x>>30))*0xbf58476d1ce4e5b9;
        x=(x^(x>>27))*0x94d049bb133111eb;
        return x^(x>>31);
    }
    template<class T,class S>ll operator()(const pair<T,S>&p)const{
        ll h1=(*this)(p.first),h2=(*this)(p.second);
        return h1^(h2+0x9e3779b9+(h1<<6)+(h1>>2));
    }
};
#define pbds __gnu_pbds
template<class T,class M=pbds::null_type,class C=less<T>>
using rbt=pbds::tree<T,M,C,pbds::rb_tree_tag,pbds::tree_order_statistics_node_update>;
template<class K,class V>
using gph=pbds::gp_hash_table<K,V,chash>;
template<class K,class V>
using cch=pbds::cc_hash_table<K,V,chash>;
template<class T,class C=less<T>>
using heap=pbds::priority_queue<T,C,pbds::pairing_heap_tag>;
template<class T1,class T2>
ostream&operator<<(ostream&o,const pair<T1,T2>&p);
template<class T>
auto operator<<(ostream& o,const T&v)->
typename enable_if<!is_same<T,string>::value,decltype(v.end(),o)>::type{
    o<<"[";
    fe(u,v)o<<u<<", ";
    return o<<"]";
}
template<class T1,class T2>
ostream&operator<<(ostream&o,const pair<T1,T2>&p){
    o<<"{"<<p.fi<<", "<<p.sc;
    return o<<"}";
}
#ifdef LOCAL
    void _print(){cerr<<endl;}
    template<class H,class...T>
    void _print(H h,T...t){cerr<<h<<", ";_print(t...);}
    #define dbg(...) cerr<<"#"<<__LINE__<<"# "<<#__VA_ARGS__<<" = ",_print(__VA_ARGS__);
    #define blk cerr<<"---------------\n";
#else
    #define dbg(...) ;
    #define blk ;
#endif
void prep();
void test();
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    #ifdef LOCAL
        // freopen("in.txt","r",stdin);
        // freopen("out.txt","w",stdout);
    #endif
    prep();
    ll t=1;
    cin>>t;
    while(t--){
        test();
        blk
    }
    cout.flush();
    return 0;
}
constexpr ll mod=998244353;
constexpr ll dx[]={-1,0,1,0},dy[]={0,-1,0,1};

void prep(){

    return;
}
struct node{
    // ll parent=-1;
    ll lson=-1;
    ll rson=-1;
}stu[500000+10];
void test(){
    ll n;cin>>n;
    f(i,1,n+1){
        stu[i].lson=-1;
        stu[i].rson=-1;
        // stu[i].parent=-1;
    }
    vll a(n);
    vll dep(n+1);
    f(i,0,n) cin>>a[i];
    vll b(n,-1);
    ll x=0;
    f(i,0,n){
        if(x==0){
            b[x]=a[i];
            x++;
        }else{
            while(x-1>=0&&b[x-1]<a[i]) x--;
            if(x==0){
                stu[a[i]].lson=b[0];
                // stu[b[0]].parent=a[i];
                b[x]=a[i];
                x++;
            }else{
                if(b[x]!=-1){
                    stu[a[i]].lson=b[x];
                    // stu[b[x]].parent=a[i];
                }
                stu[b[x-1]].rson=a[i];
                // stu[a[i]].parent=b[x-1];
                b[x]=a[i];
                x++;
            }
        }
    }
    dep[n]=1;
    x=0;
    b[x]=n;
    x++;
    while(x){
        ll o=b[x-1];
        x--;
        if(stu[o].lson!=-1){
            b[x]=stu[o].lson;
            x++;
            dep[b[x-1]]=dep[o]+1;
            // stu[o].lson=-1;
        }
        if(stu[o].rson!=-1){
            b[x]=stu[o].rson;
            x++;
            dep[b[x-1]]=dep[o]+1;
            // stu[o].rson=-1;
        }
        // cout<<o<<" "<<stu[o].lson<<" "<<stu[o].rson<<endl;
    }
    ll ma=0;
    f(i,1,n){
        ma=max(ma,dep[i]);
    }
    cout<<n-ma<<endl;
    return;
}