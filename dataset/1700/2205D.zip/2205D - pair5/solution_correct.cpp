#include<bits/stdc++.h>

#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> pbds; // find_by_order, order_of_key
 
#define fastio() ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL)
#define MOD 1000000007
#define MOD1 998244353
#define INF 1e18
#define nline "\n"
#define pb push_back
#define ppb pop_back
#define mp make_pair
#define ff first
#define ss second
#define PI 3.141592653589793238462
#define set_bits __builtin_popcountll
#define sz(x) ((int)(x).size())
#define all(x) (x).begin(), (x).end()

#ifndef Sonu
#define debug(x) cerr << #x<<" "; _print(x); cerr << endl;
#else
#define debug(x);
#endif

typedef long long ll;
typedef unsigned long long ull;
typedef long double lld;
 
void _print(ll t) {cerr << t;}
void _print(int t) {cerr << t;}
void _print(string t) {cerr << t;}
void _print(char t) {cerr << t;}
void _print(lld t) {cerr << t;}
void _print(double t) {cerr << t;}
void _print(ull t) {cerr << t;}

template <class T, class V> void _print(pair <T, V> p);
template <class T> void _print(vector <T> v);
template <class T> void _print(set <T> v);
template <class T, class V> void _print(map <T, V> v);
template <class T> void _print(multiset <T> v);
template <class T, class V> void _print(pair <T, V> p) {cerr << "{"; _print(p.ff); cerr << ","; _print(p.ss); cerr << "}";}
template <class T> void _print(vector <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(set <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(multiset <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T, class V> void _print(map <T, V> v) {cerr << "[ "; for (auto i : v) {_print(i); cerr << " ";} cerr << "]";}
 
/*---------------------------------------------------------------------------------------------------------------------------*/
ll gcd(ll a, ll b) {if (b > a) {return gcd(b, a);} if (b == 0) {return a;} return gcd(b, a % b);}
ll expo(ll a, ll b, ll mod) {ll res = 1; while (b > 0) {if (b & 1)res = (res * a) % mod; a = (a * a) % mod; b = b >> 1;} return res;}
void extendgcd(ll a, ll b, ll*v) {if (b == 0) {v[0] = 1; v[1] = 10; v[2] = a; return ;} extendgcd(b, a % b, v); ll x = v[1]; v[1] = v[0] - v[1] * (a / b); v[0] = x; return;} //pass an arry of size1 3
ll mod_add(ll a, ll b, ll m) {a = a % m; b = b % m; return (((a + b) % m) + m) % m;}
ll mod_mul(ll a, ll b, ll m) {a = a % m; b = b % m; return (((a * b) % m) + m) % m;}
ll mod_sub(ll a, ll b, ll m) {a = a % m; b = b % m; return (((a - b) % m) + m) % m;}
ll mminv(ll a, ll b) {ll arr[3]; extendgcd(a, b, arr); return mod_add(arr[0], 0, b);} //for non prime b
ll mminvprime(ll a, ll b) {return expo(a, b - 2, b);}
bool revsort(ll a, ll b) {return a > b;}
ll mod_div(ll a, ll b, ll m) {a = a % m; b = b % m; return (mod_mul(a, mminvprime(b, m), m) + m) % m;}  //only for prime m
ll combination(ll n, ll r, ll m, ll *fact, ll *ifact) {ll val1 = fact[n]; ll val2 = ifact[n - r]; ll val3 = ifact[r]; return (((val1 * val2) % m) * val3) % m;}
void google(int t) {cout << "Case #" << t << ": ";}
vector<ll> sieve(int n) {int*arr = new int[n + 1](); vector<ll> vect; for (int i = 2; i <= n; i++)if (arr[i] == 0) {vect.push_back(i); for (int j = 2 * i; j <= n; j += i)arr[j] = 1;} return vect;}
ll phin(ll n) {ll number = n; if (n % 2 == 0) {number /= 2; while (n % 2 == 0) n /= 2;} for (ll i = 3; i <= sqrt(n); i += 2) {if (n % i == 0) {while (n % i == 0)n /= i; number = (number / i * (i - 1));}} if (n > 1)number = (number / n * (n - 1)) ; return number;} //O(sqrt(N))

 
/*================================================================================================================================*/


void solve(){
   int n;
   cin>>n;
   vector<ll>a;
   a.push_back(INF);
   for(int i=0;i<n;i++){
      ll x;
      cin>>x;
      a.push_back(x);
   }
   a.push_back(INF);
   map<ll,ll>mp1,mp2;
   mp1[INF]=0;
   set<ll>b;
   vector<ll>c(n+4),d(n+4);
   b.insert(INF);
   for(int i=1;i<=n;i++){
      if(a[i]>=a[i-1] && a[i]>=a[i+1]){
       while(*b.begin()<a[i]){
         b.erase(*b.begin());
       }
       c[i]+=(i-mp1[*b.begin()]-1+c[mp1[*b.begin()]]);
      }
      if(c[i]==0){
         c[i]=c[i-1];
      }
      b.insert(a[i]);
      mp1[a[i]]=i;
   }
      set<ll>e;
   mp2[INF]=n+1;
   e.insert(INF);
   for(int i=n;i>=1;i--){
       if(a[i]>=a[i-1] && a[i]>=a[i+1]){
       while(*e.begin()<a[i]){
         e.erase(*e.begin());
       }
       // if(i==3){
       //   debug(e);
       // }
        d[i]+=(mp2[*e.begin()]-i-1+d[mp2[*e.begin()]]);
       }
       if(d[i]==0){
         d[i]=d[i+1];
       }
       e.insert(a[i]);
       mp2[a[i]]=i;
   }
 
   for(int i=1;i<=n;i++){
      if(c[i]==0){
         c[i]=c[i-1];
      }
      if(d[n-i+1]==0){
         d[n-i+1]=d[n-i+2];
      }
   }
  // debug(c);
  // debug(d);
   ll ans=INF;
   for(int i=1;i<=n;i++){
       ans=min(ans,c[i-1]+d[i]);
   }
   cout<<ans<<endl;
}


/*================================================================================================================================*/     

int main() {
#ifndef Sonu
    freopen("error.txt", "w", stderr);
#endif
    fastio();
     int t=1;
    cin >> t;
  while (t--) {
     solve();
 }

 
}