#include <iostream>
#include <cmath>
#include <vector>
#include <map>
#include <stack>
#include <string>
#include <queue>
#include <set>
#include <algorithm>
#include <numeric>
using namespace std;
typedef long long ll;
#define endl '\n';
const ll nmax=1e18, mod=1e9+7, mod1=998244353, ng=2e5+2;

ll solve(ll l, ll r, vector <vector <ll> > &st, vector <ll> &a){
    
    ll cn = r-l+1;
    ll d = log2(r-l+1);
    ll i1 = st[d][l], i2 = st[d][r-(1<<d)+1], i;
    if(a[i1] > a[i2]){
        i = i1;
    }else{
        i = i2;
    }
    ll al = 1, ar = 1;
    if(l < i)al += solve(l, i-1, st, a);
    if(r > i)ar += solve(i+1, r, st, a);
    return max(al, ar);
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);cout.tie(NULL);

    ll t;cin >> t;
    while(t--){

        ll n;cin >> n;
        vector <ll> a(n);
        for(ll i=0; i<n; i++)cin >> a[i];

        vector <vector <ll> > st(25);
        for(ll i=0; i<n; i++)st[0].push_back(i);
        for(ll i=1; (1<<i)<=n; i++)for(ll j=0; j+(1<<i) <= n; j++){
            ll a1 = a[st[i-1][j]], a2 = a[st[i-1][j+(1<<(i-1))]];
            if(a1 > a2){
                st[i].push_back(st[i-1][j]);
            }else{
                st[i].push_back(st[i-1][j+(1<<(i-1))]);
            }
        }

        ll ans = (n-solve(0, n-1, st, a));
        cout << ans << endl;
    }

    return 0;
}
