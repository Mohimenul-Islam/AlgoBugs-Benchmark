#include <bits/stdc++.h>
using namespace std;

#define IOS ios::sync_with_stdio(false),cin.tie(nullptr)
using ll = long long;
#define int long long

void solve() {
    int n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }

    vector<int> pref(n);
    stack<int> st1;
    for (int i = 0; i < n; i++) {
        while (!st1.empty() && st1.top() < a[i]) {
            st1.pop();
        }
        st1.push(a[i]);
        pref[i] = st1.size();
    }

    vector<int> suff(n);
    stack<int> st2;
    for (int i = n - 1; i >= 0; i--) {
        while (!st2.empty() && st2.top() < a[i]) {
            st2.pop();
        }
        st2.push(a[i]);
        suff[i] = st2.size();
    }

    int max_retain = 0;
    for (int i = 0; i < n; i++) {
        max_retain = max(max_retain, pref[i] + suff[i] - 1);
    }

    cout << n - max_retain << '\n';
}

signed main() {
    IOS;
    int T;
    cin >> T;
    while (T--) {
        solve();
    }
    return 0;
}