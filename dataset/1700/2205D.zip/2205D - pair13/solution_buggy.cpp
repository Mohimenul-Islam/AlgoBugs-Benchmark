//
// Created by awake on 2026/4/19.
//
// clang-format off
#include <bits/stdc++.h>
using namespace std;
struct { auto operator()(auto &i) { cin >> i; } } IN; // NOLINT
struct { auto operator()(auto &i) { cout << i << ' '; } } OUT; // NOLINT
#define IOS ios::sync_with_stdio(false),cin.tie(nullptr)// NOLINT
using pii=pair<int,int>;//NOLINT
using ll = long long;//NOLINT
#define int long long
// #define endl '\n'
// #define all(x) x.begin(),x.end()//NOLINT
// clang-format on
constexpr int INF = 0x3f3f3f3f;
constexpr int MOD = 998244353;
constexpr int N = 1e6 + 5;


void solve()
{
    int n;
    cin >> n;
    vector<int> a(n);
    int ans1 = 1, ans2 = 1;
    pii mx = {-1, -1};
    for (const auto i : views::iota(0, n))
    {
        cin >> a[i];
        if (mx.second < a[i])mx = {i, a[i]};
    }
    //mx在左边
    stack<int> st;
    st.push(mx.second);
    for (int i = mx.first + 1; i < n - 1; i++)
    {
        while (st.top() < a[i])
            st.pop();
        st.push(a[i]);
        ans1 = max(ans1, static_cast<int>(st.size()));
    }
    stack<int> st2;
    st2.push(mx.second);
    //mx在右边
    for (int i = mx.first - 1; i >= 1; i--)
    {
        while (st2.top() < a[i])
            st2.pop();
        st2.push(a[i]);
        ans2 = max(ans2, static_cast<int>(st2.size()));
    }
    cout << n - (max(ans1, ans2) + 1) << endl;
}

signed main()
{
    IOS;
    int T;
    cin >> T;
    while (T--)
        solve();

    return 0;
}
