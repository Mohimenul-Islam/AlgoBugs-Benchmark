#include<bits/stdc++.h>
using namespace std;
 
#define int long long
const int N = 5e5 + 5;
const int mod7 = 1e9 + 7;

int rem[N], a[N], stk[N], top, ans;

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
 
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif

    int T = 1;
    cin >> T;
    while(T--){
        int n;
        cin>>n;
        for(int i=1;i<=n;i++){
            rem[i] = 0;
        }
        ans = n;
        for(int i = 1 ; i <= n ; i++){
            cin>>a[i];
        }
        top = 0;
        for(int i = 1 ; i <= n ; i++){
            while(top && a[stk[top]] < a[i]){
                top--;
            }
            top++;
            stk[top] = i;
            rem[i] += i - top;
        }
        top = 0;
        for(int i = n ; i >= 1 ; i--){
            while(top && a[stk[top]] < a[i]){
                top--;
            }
            top++;
            stk[top] = i;
            rem[i] += n - i - top + 1;
        }
        for(int i = 1 ; i <= n ; i++){
            ans = min(ans, rem[i]);
        }
        cout<<ans<<'\n';
        
    }
    return 0;
}