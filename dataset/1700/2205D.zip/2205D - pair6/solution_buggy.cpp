#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ull = unsigned long long;

const int N = 1e6 + 10;
const ll INF = (1LL << 60);

int n;
int a[N], p[N];
ll ans;

unordered_map<ull, ll> best;

inline ull pack(int u, int l, int r) {
    return ( (ull)u << 42 ) | ( (ull)l << 21 ) | (ull)r;
}

void dfs(int u, int l, int r, ll cnt) {
    if (cnt >= ans) return;
    if (u == 0 || l > r) {
        ans = min(ans, cnt);
        return;
    }

    ull key = pack(u, l, r);
    auto it = best.find(key);
    if (it != best.end() && it->second <= cnt) return;
    best[key] = cnt;

    if (p[u] < l || p[u] > r) {
        dfs(u - 1, l, r, cnt);
    } else if (p[u] == l) {
        dfs(u - 1, l + 1, r, cnt);
    } else if (p[u] == r) {
        dfs(u - 1, l, r - 1, cnt);
    } else {
        dfs(u - 1, p[u] + 1, r, cnt + (p[u] - l));
        dfs(u - 1, l, p[u] - 1, cnt + (r - p[u]));
    }
}

void solve() {
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> a[i], p[a[i]] = i;

    ans = INF;
    best.clear();
    best.reserve(1 << 20);
    best.max_load_factor(0.7);

    dfs(n, 1, n, 0);
    cout << ans << '\n';
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T;
    while (T--) solve();
    return 0;
}