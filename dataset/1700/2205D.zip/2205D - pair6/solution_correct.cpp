#include <bits/stdc++.h>
#define int long long

using namespace std;

typedef pair<int, int> PII;

const int N = 1e6 + 10, mod = 1e9 + 7, INF = 1e18;

int n, m, k, Q;
int a[N], p[N];
int f[N][22];


int query(int l, int r)
{
	int len = (r - l) + 1;
	int k = log2(len);
	return max(f[l][k], f[r - (1 << k) + 1][k]);
}

int dfs(int l, int r)
{
	if(l >= r) return 0;
	int d = query(l, r);
	return min(p[d] - l + dfs(p[d] + 1, r), r - p[d] + dfs(l, p[d] - 1));
}

void solve() 
{
	cin >> n;
	for(int i = 1; i <= n; i++) cin >> a[i], p[a[i]] = i;
	
	
	for(int i = 0; i <= 20; i++)
	{
		for(int j = 1; j + (1 << i) - 1 <= n; j++)
		{
			if(i == 0) f[j][i] = a[j];
			else f[j][i] = max(f[j][i - 1], f[j + (1 << (i - 1))][i - 1]);
		}
	}
	
	cout << dfs(1, n) << endl;
}   

signed main() 
{
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	int T = 1;
	cin >> T;
	while (T--) solve();
	return 0;
}