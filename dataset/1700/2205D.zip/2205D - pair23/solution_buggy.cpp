#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds; 
#define ordered_set tree<ll, null_type,less<ll>, rb_tree_tag,tree_order_statistics_node_update> 
#define ordered_multiset tree<ll, null_type, less_equal<ll>, rb_tree_tag, tree_order_statistics_node_update>
#define fastio ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
#define ll long long
#define ld long double
#define endl "\n"
#define pb push_back
#define ub upper_bound
#define lb lower_bound
#define setbits(x) __builtin_popcountll(x)
#define leadz(x) __builtin_clzll(x)
#define trailz(x) __builtin_ctzll(x)
#define max_ele(vec) *(max_element(vec.begin(),vec.end()))
#define min_ele(vec) *(min_element(vec.begin(),vec.end()))
#define scanv(v) for (ll i = 0; i < v.size(); i++) cin >> v[i];
#define vl vector<ll>
#define vvl vector<vector<ll>>
#define vvc vector<vector<char>>
#define vc vector<char>
ld pi=3.1415926535897932;
const ll mod=676767677;
const ll inf=1e18;
const ll ninf=-1e18;

ll binexp(ll a, ll b)
{
    ll result = 1;
    while (b) {
        if (b & 1)
            result = (result * a) % mod;
        a = (a * a) % mod;
        b >>= 1;
    }
    return result;
}

int main(){
  fastio;
  ll t=1;
  cin>>t;
  while(t--){
    ll n; cin>>n;
    vl v(n);
    scanv(v);
    vl pref(n,0);
    map<ll,ll>mp;
    set<ll>st;
    for(ll i=0;i<n;i++){
        mp[v[i]]=i;
        st.insert(v[i]);
    }
    for(ll i=1;i<n-1;i++){
        ll num=0;
        if(v[i]>v[i-1] && v[i]>v[i+1]) num=1;
        pref[i]=pref[i-1]+num;
    }
    pref[n-1]=pref[n-2];
    ll left=0, right=n-1, ans=0;
    for(ll j=n;j>=1;j--){
        if(st.find(j)==st.end()) continue;
        else{
            ll ind=mp[j];
            if(ind==left){
                left++;
                st.erase(v[ind]);
                continue;
            }
            if(ind==right){
                right--;
                st.erase(v[ind]);
                continue;
            }
            ll num1=ind-left;
            ll num2=right-ind;
            if(num1<num2){
                ans+=num1;
                for(ll i=left;i<=ind;i++) st.erase(v[i]);
                left=ind+1;
            }
            else if(num2<num1){
                ans+=num2;
                for(ll i=right;i>=ind;i--) st.erase(v[i]);
                right=ind-1;
            }
            else{
                ll lft=pref[ind]-pref[left];
                ll rt=pref[right]-pref[ind];
                if(lft>rt){
                    ans+=num1;
                    for(ll i=left;i<=ind;i++) st.erase(v[i]);
                    left=ind+1;
                }
                else{
                    ans+=num2;
                    for(ll i=right;i>=ind;i--) st.erase(v[i]);
                    right=ind-1;                    
                }
            }
        }
    }
    cout<<ans<<endl;
  }
}