#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds; 
#define ordered_set tree<ll, null_type,less<ll>, rb_tree_tag,tree_order_statistics_node_update> 
#define ordered_multiset tree<ll, null_type, less_equal<ll>, rb_tree_tag, tree_order_statistics_node_update>
#define fastio ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
#define ll long long
#define ld long double
#define endl "\n"
#define pb push_back
#define ub upper_bound
#define lb lower_bound
#define setbits(x) __builtin_popcountll(x)
#define leadz(x) __builtin_clzll(x)
#define trailz(x) __builtin_ctzll(x)
#define max_ele(vec) *(max_element(vec.begin(),vec.end()))
#define min_ele(vec) *(min_element(vec.begin(),vec.end()))
#define scanv(v) for (ll i = 0; i < v.size(); i++) cin >> v[i];
#define vl vector<ll>
#define vvl vector<vector<ll>>
#define vvc vector<vector<char>>
#define vc vector<char>
ld pi=3.1415926535897932;
const ll mod=676767677;
const ll inf=1e18;
const ll ninf=-1e18;

ll binexp(ll a, ll b)
{
    ll result = 1;
    while (b) {
        if (b & 1)
            result = (result * a) % mod;
        a = (a * a) % mod;
        b >>= 1;
    }
    return result;
}

const ll MAXN = 500005;
const ll LOG = 20;
ll st[MAXN][LOG];
void build_sparse_table(ll n, vl &v) {
    for (ll i = 0; i < n; i++) {
        st[i][0] = i;
    }
    for (ll j = 1; (1 << j) <= n; j++) {
        for (ll i = 0; i + (1 << j) <= n; i++) {
            ll left_idx = st[i][j - 1];
            ll right_idx = st[i + (1 << (j - 1))][j - 1];
            st[i][j] = (v[left_idx] > v[right_idx]) ? left_idx : right_idx;
        }
    }
}
ll query_sparse_table(ll l, ll r, vl &v) {
    ll j = __builtin_clzll(1) - __builtin_clzll(r - l + 1); // Fast log2
    ll left_idx = st[l][j];
    ll right_idx = st[r - (1 << j) + 1][j];
    return (v[left_idx] > v[right_idx]) ? left_idx : right_idx;
}

ll func(ll l, ll r, vl &v, vl &dp) {
    if (l >= r) return 0;
    ll k = query_sparse_table(l, r,v); 
    if (dp[k] != -1) return dp[k];

    // way1: cost to delete the entire left side + cost to make right side cool
    ll way1 = (k - l) + func(k + 1, r, v, dp);
    
    // way2: cost to delete the entire right side + cost to make left side cool
    ll way2 = (r - k) + func(l, k - 1, v, dp);
    
    return dp[k] = min(way1, way2);
}

int main(){
  fastio;
  ll t=1;
  cin>>t;
  while(t--){
    ll n; cin>>n;
    vl v(n);
    scanv(v);
    build_sparse_table(n,v);
    vl dp(n+1,-1);
    cout<<func(0,n-1,v,dp)<<endl;
  }
}