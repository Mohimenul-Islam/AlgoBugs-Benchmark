#include <bits/stdc++.h>
using ll = long long;
const int N = 5e4 + 5;
int n;
int a[N], idx[N];
int tree[N << 2];
void build(int node, int l, int r)
{
    if (l == r)
    {
        tree[node] = a[l];
        return;
    }
    int mid = l + ((r - l) >> 1);
    build(node << 1, l, mid);
    build(node << 1 | 1, mid + 1, r);
    tree[node] = std::max(tree[node << 1], tree[node << 1 | 1]);
}

int qry(int node, int l, int r, int ql, int qr)
{
    if (ql <= l && qr >= r)
        return tree[node];
    int mid = l + ((r - l) >> 1);
    int mx = -1;
    if (ql <= mid)
        mx = qry(node << 1, l, mid, ql, qr);
    if (qr > mid)
        mx = std::max(mx, qry(node << 1 | 1, mid + 1, r, ql, qr));
    return mx;
}
int query(int ql,int qr){
    return qry(1,0,n-1,ql,qr);
}

int f(int l,int r){
    if(r<=l)return 0;
    int mx=query(l,r);
    int p=idx[mx];
    return std::min(p-l+f(p+1,r),r-p+f(l,p-1));
}
void fc()
{
    std::cin >> n;
    for (int i = 0; i < n; i++)
        std::cin >> a[i], idx[a[i]] = i;
    build(1,0,n-1);
    std::cout<<f(0,n-1)<<"\n";
}

int main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    int t = 1;
    std::cin >> t;
    while (t--)
        fc();
}