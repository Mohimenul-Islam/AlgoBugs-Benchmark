#include<bits/stdc++.h>
#define int long long
using namespace std;

const int N=2e5+5;
int n,q;
int a[N];
int sum[N];
int val[N];

void solve() {
    cin>>n>>q;
    for (int i=1;i<=n;i++) {
        cin>>a[i];
    }

    auto cal=[&](int x)->int {
        int res=0;
        while (x!=1) {
            x>>=1;
            res++;
            if (x==1) break;
            x++;
        }
        return res;
    };

    for (int i=1;i<=n;i++) {
        sum[i]=cal(a[i]);
        val[i]=cal(a[i]+1)-sum[i];
    }
    for (int i=1;i<=n;i++) {
        sum[i]+=sum[i-1];
        val[i]+=val[i-1];
    }

    while (q--) {
        int l,r; cin>>l>>r;
        cout<<sum[r]-sum[l-1]+(val[r]-val[l-1])/2<<endl;
    }
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
    int t=1;
    cin>>t;
    while (t--) solve();
    return 0;
}