#include <bits/stdc++.h>
#define ll long long
#define no {cout<<"No\n";return;}

using namespace std;

const ll N=1e6+7,INF=2e18+7,mod=998244353;

ll a[N],p[N],g[N],n,q,l,r;

ll f(ll x){
    ll n1=0,n2=0,x1=x,x2=x;
    while(x1>1){
        if(x1&1)++x1;
        x1/=2,++n1;
    }
    while(x2>1){
        if(x2&1 && x2!=x)++x2;
        x2/=2,++n2;
    }
    return (n1!=n2);
}

void solve(){
    cin>>n>>q;
    for(ll i=1;i<=n;++i)p[i]=0;
    for(ll i=1;i<=n;++i){
        cin>>a[i];
        p[i]+=p[i-1],g[i]=g[i-1]+f(a[i]);
        while(a[i]>1){
            if(a[i]&1)++a[i];
            a[i]/=2,++p[i];
        }
    }
    while(q--){
        cin>>l>>r;
        cout<<p[r]-p[l-1]-min(1ll,g[r]-g[l-1])<<'\n';
    }
}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);

    //freopen("berries.in","r",stdin);
    //freopen("berries.out","w",stdout);

    ll tt=1;
    cin>>tt;
    while(tt--){
        solve();
        //if(tt)cout<<'\n';
    }
}
