#include <bits/stdc++.h>
#define ll long long
#define f first
#define s second

using namespace std;

const ll N=1e6+7,INF=2e18+7,mod=998244353;

ll a[N],p[N],g[N],n,q,l,r,x;

ll f(ll k){
    x=0;
    while(k>1)++x,k/=2;
    return x;
}

bool ok(ll k){
    for(ll i=0;(1ll<<i)<=k;++i){
        if((1ll<<i)==k)return 1;
    }
    return 0;
}

void solve(){
    cin>>n>>q;
    for(ll i=1;i<=n;++i){
        cin>>a[i];
        g[i]=g[i-1],p[i]=p[i-1];
        if(a[i]>2 && ok(a[i]-1))++g[i];
        else if(!ok(a[i]))++p[i];
        p[i]+=f(a[i]);
    }
    while(q--){
        cin>>l>>r;
        --l;
        cout<<p[r]-p[l]+(g[r]-g[l])/2<<'\n';
    }
}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);

    //freopen("helpcross.in","r",stdin);
    //freopen("helpcross.out","w",stdout);

    int tt=1;
    cin>>tt;
    while(tt--){
        solve();
        //if(tt)cout<<'\n';
    }
}
