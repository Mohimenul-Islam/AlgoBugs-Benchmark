#include <bits/stdc++.h>
#define Sandevistan   ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define int long long int
#define double long double
#define py {cout << "YES" << endl; return;}
#define pn {cout << "NO" << endl; return;}
#define px {cout << -1 << endl; return;}
#define fr(i, n) for (int i = 0; i < n; i++)
#define test() cout<<"OK!"<<endl;
#define pb push_back
#define sze(x) x.size()
#define all(v) v.begin(), v.end()
#define gcd(a, b) __gcd(a, b)
#define lcm(a, b) (a * b) / gcd(a, b)
#define comb(n,a,b) (n-a+1)*(n-b+1)
#define ff first
#define ss second
#define MX(x) *max_element(all(x));
#define MN(x) *min_element(all(x));
#define nobits(x) __builtin_popcountll(x)
#define print(x) for(auto &it:x) cout<<it<<" ";
const int INF = 1e18;
const int NN = 1e6 + 10;
const int MOD = 1e9+7;
const int dx[8] = {1, -1, 0, 0, 1, 1, -1, -1};
const int dy[8] = {0, 0, 1, -1, 1, -1, 1, -1};
using namespace std;
using namespace __gnu_pbds;
template <typename T>
using ordered_set = tree<T,null_type,less<T>,rb_tree_tag,tree_order_statistics_node_update>;

void printQ(int r){
    cout<<r<<endl;
    cout.flush();
}

int binPow(int a, int b, int mod) {
    a %= mod;
    int res = 1;
    while (b > 0) {
        if (b & 1) res = (res * a) % mod;
        a = (a * a) % mod;
        b >>= 1;
    }
    return res;
}
 
//--- -----,---

void solve(){
    int n,q; cin>>n>>q;
    vector<int>arr(n); fr(i,n) cin>>arr[i];
    vector<int>pre(n+1,0);
    vector<int>cnt(n+1,0);
    for(int i=0;i<n;i++){
        int val = arr[i]+1;
        int steps = 0;
        while(val>1){
            steps++; val>>=1;
            if(val!=1) val++;
        }
        pre[i+1]=pre[i]+steps;
        int lstep = 0; int temp=0;
        val = arr[i];
        while(val>1){
            lstep++; val>>=1;
            if(val!=1) val++;
        }
        if(lstep<steps) temp=1;
        cnt[i+1]=cnt[i]+temp;
    }
    //print(pre); cout<<endl;
    while(q--){
        int l,r; cin>>l>>r;
        int res = pre[r]-pre[l-1];
        int poss = cnt[r]-cnt[l-1];
        if(poss) res--;
        cout<<res<<endl;
    }
}



#undef int
signed main()
{
    Sandevistan
    int TT = 1;
    cin >> TT;
    while (TT--) { //cout<<TT+1<<endl;
         solve();}
    return 0;
}
