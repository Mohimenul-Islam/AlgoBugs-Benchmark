#include <bits/stdc++.h>

using namespace std;

#define mid (l + ((r - l) / 2))
#define pb push_back
#define F first
#define S second

int64_t mod = 676767677 ;

void solve(int64_t tt)
{
    int64_t n, m, k, x = 0, y = 0, z = 0, ans = 1e18, sum = 0, p = 0, cnt = 0, cnt0 = 0, cnt1 = 0, mx = -1, mn = 1e18 ;
    string s, t = "" ;
    bool ok = 1 ;
    cin >> n >> k ;
    vector<int64_t> a(n + 1), pr(n + 1), od(n + 1) ;
    for(int64_t i = 1 ; i <= n ; i++) cin >> a[i] ;
    for(int64_t i = 1 ; i <= n ; i++)
    {
        cnt = a[i], od[i] = od[i - 1] + (a[i] % 2), pr[i] = pr[i - 1] ;
        while(cnt > 1) cnt /= 2, cnt += (cnt > 1), pr[i]++ ;
    }

    while(k--)
    {
        cin >> x >> y ;
        cout << pr[y] - pr[x - 1] + (od[y] != od[x] && (od[y] - od[x - 1]) % 2 == 0) << endl;
    }
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    /*freopen("defining_prizes_validation_input.txt", "r", stdin);
    freopen("BVout.txt", "w", stdout);*/
    int tt = 1 ;
    cin >> tt ;
    for(int64_t i = 1 ; i <= tt ; i++) solve(i) ;
}


/*
 *      https://codeforces.com/blog/entry/146051
 *      https://codeforces.com/blog/entry/22616
 */
