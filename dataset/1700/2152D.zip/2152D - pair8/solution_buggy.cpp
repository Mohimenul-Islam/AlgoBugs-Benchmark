#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;

typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> pbds; //// find_by_order, order_of_key
typedef long long int ll;

const ll MOD = 1e9 + 7;

// Fast exponentiation (base^exp % MOD)
ll modexp(ll base, ll exp, ll mod = MOD) {
    ll result = 1;
    base %= mod;
    while (exp > 0) {
        if (exp & 1) result = result * base % mod;
        base = base * base % mod;
        exp >>= 1;
    }
    return result;
}

// Modular inverse (works when MOD is prime)
ll modinv(ll x, ll mod = MOD) {
    return modexp(x, mod - 2, mod);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--) {
        ll n,q;
        cin>>n>>q;
        vector<ll>a(n);
        for(int i = 0; i < n; i++) {
            cin>>a[i];
        }
        vector<pair<ll,ll>>b(n,{0,0});
        for(int i = 0; i < n; i++) {
            ll tempsz=floor(log2(a[i]));
            if(a[i]%2==1 && (a[i]-1==(1<<tempsz))){
                b[i]={tempsz,1};
            }
            else if((1<<tempsz)!=a[i]){
                b[i]={tempsz+1,0};
            }
            else{
                b[i]={tempsz,0};
            }
            if(i>0){
                b[i].first+=b[i-1].first;
                b[i].second+=b[i-1].second;
            }
        }
        
        for(int i = 0; i < q; i++) {
            ll l,r;
            cin>>l>>r;
            l--,r--;
            ll temp1=b[r].first;
            ll temp2=b[r].second;
            if(l>0){
                temp1-=b[l-1].first;
                temp2-=b[l-1].second;
                
            }
            if(temp2>0){
                temp1+=temp2-1;
            }
            cout<<temp1<<endl;
        }
        
    }
    return 0;
}