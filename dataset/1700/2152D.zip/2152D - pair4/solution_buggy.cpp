#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <random>
#include <queue>
#include <numeric>
#include <array>
#include <iomanip>
#include <stack>
#include <chrono>
#include <climits>
#include <bitset>

using namespace std;

using ll = long long;
using ld = long double;
using vd = vector<ld>;
using vi = vector<ll>;
using vii = vector<vi>;
using viii = vector<vii>;
using pi = pair<ll, ll>;
using vpi = vector<pi>;
using vb = vector<bool>;
using vs = vector<string>;

#define vec vector
#define cmax(x, ...) x = max({x, __VA_ARGS__})
#define cmin(x, ...) x = min({x, __VA_ARGS__})
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()

const ll N = 1e3 + 5, MOD = 998244353, INF = 1e18, K = 22;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

void solve() {
	ll n, q; cin >> n >> q;

	vi a(n + 1); for (ll i = 1; i <= n; i++) cin >> a[i];

	vi cost(n + 1); cost[0] = 0;
	for (ll i = 1; i <= n; i++) {
		cost[i] = cost[i - 1] + (ll)floor(log2(a[i]));
	}

	vi f(n + 1, 0), s(n + 1, 0); // f - ne точно, s - точно
	for (ll i = 1; i <= n; i++) {
		f[i] += f[i - 1];
		s[i] += s[i - 1];

		if (__builtin_popcountll(a[i]) == 1) continue;
		//if (__popcnt64(a[i]) == 1) continue;

		ll prev = -1;
		for (ll j = K; j >= 0; j--) {
			if (!(a[i] >> j & 1)) continue;

			if (prev == -1) {
				prev = j;
			}
			else {
				if (j == 0) f[i]++;
				else s[i]++;
				break;
			}
		}
	}

	while (q--) {
		ll l, r; cin >> l >> r;
		ll sum = cost[r] - cost[l - 1];

		cout << sum + (s[r] - s[l - 1]) + (f[r] - f[l - 1]) / 2 << '\n';
	}
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);

	long long tt = 1;
	cin >> tt;

	while (tt--) {
		solve();
		cout << '\n';
	}

	return 0;
}

/*

























































Темы выучить(повторить):
1) кхт
2) вайвлет три
3) 2сат
4)

*/