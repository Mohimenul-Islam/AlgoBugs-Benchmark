#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

typedef long long ll;

struct Node {
    ll cnt = 0;
    ll oddC = 0;
};

ll count_moves(ll x) {
    ll moves = 0;
    while (x != 1) {
        x /= 2;
        moves++;
        if (x > 1 && x % 2 != 0) x++;
    }
    return moves;
}

void solve() {
    int n, q;
    if (!(cin >> n >> q)) return;
    vector<ll> a(n + 1);
    vector<Node> prefix(n + 1);
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        ll m1 = count_moves(a[i]);
        ll m2 = count_moves(a[i] + 1);
        prefix[i].cnt = prefix[i - 1].cnt + m1;
        prefix[i].oddC = prefix[i - 1].oddC + (m1 != m2 ? 1 : 0);
    }

    while (q--) {
        int l, r;
        cin >> l >> r;
        ll total_cnt = prefix[r].cnt - prefix[l - 1].cnt;
        ll total_odd = prefix[r].oddC - prefix[l - 1].oddC;
        cout << total_cnt << "\n";
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    if (!(cin >> t)) return 0;
    while (t--) {
        solve();
    }
    return 0;
}
