#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef vector<ll> vll;

void solve() {
    ll n,q;
    cin>>n>>q;
    vll a(n);
    vector<pair<ll,ll>> p(q);
    for (int i=0;i<n;i++) cin>>a[i];
    for (int i=0;i<q;i++) cin>>p[i].first>>p[i].second;
    vll p1(n+1,0); // log sum
    vll p2(n+1,0);// pow 2 +1
    vll p3(n+1,0); // pow 2 + m
    for (int i=0;i<n;i++) {
        ll k=63-__builtin_clzll(a[i]);
        p1[i+1]=p1[i]+k;
        p2[i+1]=p2[i];
        p3[i+1]=p3[i];
        if (a[i]==(1LL<<k)+1) {
            p2[i+1]++;
        }
        else if (a[i]!=(1LL<<k)) {
            p3[i+1]++;
        }

    }
    for (int i=0;i<q;i++) {
        ll l=p[i].first;
        ll r=p[i].second;
        ll ans=p1[r]-p1[l-1];
        ans+=(p2[r]-p2[l-1])/2+(p3[r]-p3[l-1]);
        cout<<ans<<"\n";
    }
}

int main() {
    int t;
    cin>>t;
    // int t=1;
    while (t--) {
        solve();
    }
}
