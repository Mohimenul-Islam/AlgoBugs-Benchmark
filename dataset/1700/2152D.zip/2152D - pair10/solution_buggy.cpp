#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef vector<ll> vll;
bool check(ll n) {
    if (n<=2) return false;
    int k=63-__builtin_clzll(n);
    return (n>>(k-1))==3;
}

void solve() {
    ll n,q;
    cin>>n>>q;
    vll a(n);
    vll pb(n+1,0);//pref for special num
    vll pb2(n+1,0);// pref for another type of spec
    vector<pair<ll,ll>> p(q);
    vll pr(n+1,0);//pref for num of values
    for (int i=0;i<n;i++) cin>>a[i];
    for (int i=0;i<q;i++) cin>>p[i].first>>p[i].second;
    for (int i=0;i<n;i++) {
        ll ct=0;
        ll tmp=a[i];
        while (tmp>=2) {
            tmp/=2;
            ct++;
            if (tmp>=2) {
                tmp++;
            }
        }

        pr[i+1]=pr[i]+ct;
        pb[i+1]=pb[i];
        pb2[i+1]=pb2[i];
        if (a[i]==3) pb[i+1]++;
        else if (a[i]==5) pb[i+1]++;
        else if (!check(a[i]) and check(a[i]+1)) pb2[i+1]++;
    }
    for (int i=0;i<q;i++) {
        ll l=p[i].first,r=p[i].second;
        ll res=pr[r]-pr[l-1];
        if (pb[r]-pb[l-1]>1) res++;
        else if (pb2[r]-pb[l-1]>0) res++;
        cout<<res<<endl;
    }
}

int main() {
    int t;
    cin>>t;
    // int t=1;
    while (t--) {
        solve();
    }
}
