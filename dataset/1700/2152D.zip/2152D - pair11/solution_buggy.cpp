#include<bits/stdc++.h>
using namespace std ;
using ll = long long ; 

void solve(){
    ll n, q; 
    cin >> n >> q ; 
    
    vector<ll> arr(n) ; 
    for(int i = 0; i < n; i++) cin >> arr[i] ; 
    
    vector<ll> dp(n), problematic(n), tof(n,0) ; 
    
    for(ll i = 0; i < n; i++){
        
        ll takes = 0; 
        ll x = arr[i]  ;
        bool odd_at_any_pt = false; 
        while(x != 1){
            if(x%2 == 1) odd_at_any_pt = true ; 
            x /= 2; 
            takes++ ; 

        }
        
        dp[i] = takes ; 
        problematic[i] = (odd_at_any_pt == true ? 1 : 0) ; 
        
        if(arr[i] == 3 || arr[i] == 5) tof[i] = 1;         
    }
    
    for(ll i = 1; i < n; i++){
        dp[i] += dp[i-1] ; 
        problematic[i] += problematic[i-1] ;
        tof[i] += tof[i-1] ;
    }
    
    while(q--){
        ll l, r; 
        cin >> l >> r; 
        --r , --l ; 
        
        ll sum = dp[r] ; 
        if(l-1 >= 0) sum -= dp[l-1] ; 
        
        ll probs = problematic[r] ; 
        if(l-1 >= 0) probs -= problematic[l-1];
        
        ll tof_curr = tof[r] ; 
        if(l-1 >= 0) tof_curr -= tof[l-1] ; 
        
        ll tof_save = (tof_curr + 1) /2 ; 
        // cout << sum << " " << probs << " " << tof_save << endl; 

        cout << sum + probs - tof_save << endl; 
    }
}

int main(){
    int t;
    cin >> t ;
    while(t--){
        solve() ; 
    }
}