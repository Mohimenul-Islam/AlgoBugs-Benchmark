#include<bits/stdc++.h>
using namespace std ;
using ll = long long ; 

void solve(){
    ll n, q; 
    cin >> n >> q ; 
    
    vector<ll> arr(n) ; 
    for(int i = 0; i < n; i++) cin >> arr[i] ; 
    
    vector<ll> dp(n), problematic(n), can_save(n,0) ; 
    
    for(ll i = 0; i < n; i++){
        
        ll takes = 0; 
        ll x = arr[i]  ;
        bool odd_at_any_pt = false; 
        while(x != 1){
            if(x%2 == 1) odd_at_any_pt = true ; 
            x /= 2; 
            takes++ ; 

        }
        
        dp[i] = takes ; 
        problematic[i] = (odd_at_any_pt == true ? 1 : 0) ; 
        
        if(arr[i] == pow(2, takes) + 1) can_save[i] = 1 ;        
    }
    
    for(ll i = 1; i < n; i++){
        dp[i] += dp[i-1] ; 
        problematic[i] += problematic[i-1] ;
        can_save[i] += can_save[i-1] ;
    }
    
    while(q--){
        ll l, r; 
        cin >> l >> r; 
        --r , --l ; 
        
        ll sum = dp[r] ; 
        if(l-1 >= 0) sum -= dp[l-1] ; 
        
        ll probs = problematic[r] ; 
        if(l-1 >= 0) probs -= problematic[l-1];
        
        ll to_save = can_save[r] ; 
        if(l-1 >= 0) to_save -= can_save[l-1] ; 
        
        ll saved = (to_save + 1) /2 ; 
        // cout << sum << " " << probs << " " << tof_save << endl; 

        cout << sum + probs - saved << endl; 
    }
}

int main(){
    int t;
    cin >> t ;
    while(t--){
        solve() ; 
    }
}