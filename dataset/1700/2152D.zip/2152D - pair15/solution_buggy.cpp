#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define int long long
#define INF 0x3f3f3f3f3f3f3f3f
#define inf INFINITY
#define pii pair<int,int>

const int N=2e5+10;

int a[N];
int cnt1[N],cnt2[N],sum[N];

int cal(int x) {
    int ret=0;
    while (x) {
        x>>=1;
        ret++;
    }
    return ret-1;
}

int judge(int x) {
    int tmp=x>>1;
    if (x==(x&-x))return 0;
    else if (x&1&&tmp==(tmp&-tmp))return 1;
    else return 2;
}

void solve() {
    int n,q;
    cin>>n>>q;
    for (int i=1;i<=n;i++) {
        cin>>a[i];
        sum[i]=cnt1[i]=cnt2[i]=0;
    }
    for (int i=1;i<=n;i++) {
        sum[i]=sum[i-1]+cal(a[i]);
        cnt1[i]+=cnt1[i-1];
        cnt2[i]+=cnt2[i-1];
        int j=judge(a[i]);
        if (j==1)cnt1[i]++;
        else if (j==2)cnt2[i]++;
    }
    while (q--) {
        int l,r;
        cin>>l>>r;
        int ans=sum[r]-sum[l-1];
        int add=(cnt1[r]-cnt1[l-1])/2+cnt2[r]-cnt2[l-1];
        cout<<ans+add<<endl;
    }
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
    int t = 1;
    cin >> t;
    while (t--)
        solve();
    return 0;
}