#include <bits/stdc++.h>

#pragma GCC optimize("Ofast")
#pragma GCC optimize("unroll-loops")
using namespace std;
#define int long long
// #define double long double

struct x {
    int cnt;
    int cnt1;
    int oddC;
    int val;
};

void Solve() {
    int n, q;
    cin >> n >> q;
    vector<x> v(n + 1);
    for (int i = 1; i <= n; i++) {
        cin >> v[i].val;
        int val = v[i].val + 1;
        while (v[i].val != 1) {
            v[i].val /= 2;
            v[i].cnt++;
            if (v[i].val > 1 && v[i].val % 2 != 0) {
                v[i].val++;
            }
        }
        while (val != 1) {
            val /= 2;
            v[i].cnt1++;
            if (val > 1 && val % 2 != 0) {
                val++;
            }
        }
        if (v[i].cnt != v[i].cnt1) {
            v[i].oddC++;
        }
    }
    for (int i = 1; i <= n; i++) {
        v[i].cnt += v[i - 1].cnt;
        v[i].cnt1 += v[i - 1].cnt1;
        v[i].oddC += v[i - 1].oddC;
    }
    // cout << v[10].cnt << endl;
    // cout << v[10].oddC << endl;

    while (q--) {
        int l, r;
        cin >> l >> r;
        int cnt = v[r].cnt - v[l - 1].cnt;
        int oddC = v[r].oddC - v[l - 1].oddC;

        cnt += max(oddC / 2, 0ll);

        cout << cnt << endl;
    }
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t = 1;
    cin >> t;
    while (t--) {
        Solve();
    }
    return 0;
}
