#include<bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;

void solve() {
    ll n,q;
    cin >> n >> q;
    vector<ll> a(n+1);
    vector<ll> opcnt(n+1,0);
    vector<ll> cnt1(n+1,0);
    vector<ll> cntab1(n+1,0);
    for(ll i=1;i<=n;i++){
        cin >> a[i];
        opcnt[i] = 63-__builtin_clzll(a[i]);
        if(a[i]-(1LL<<opcnt[i])==1){
            cnt1[i]++;
        }else if(a[i]-(1LL<<opcnt[i])>1){
            cntab1[i]++;
        }
    }
    for(ll i=1;i<=n;i++){
        cnt1[i]+=cnt1[i-1];
        cntab1[i]+=cntab1[i-1];
        opcnt[i]+=opcnt[i-1];
    }
    while(q--){
        ll l,r;
        cin >> l >> r;
        ll cop=opcnt[r]-opcnt[l-1];
        ll c1=cnt1[r]-cnt1[l-1];
        ll cab1=cntab1[r]-cntab1[l-1];
        cop+=c1/2;
        cop+=cab1;
        cout << cop << "\n";
    }
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    int t = 1;
    cin >> t;
    while(t--){
        solve();
    }
    return 0;
}