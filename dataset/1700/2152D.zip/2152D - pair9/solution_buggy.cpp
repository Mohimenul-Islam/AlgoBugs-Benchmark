#include <bits/stdc++.h>
using namespace std;
const int N = 3e5;
vector<int> val;
bool poww(int x) {
  if (x <= 2)
    return false;
  return ((x - 1) & (x - 2)) == 0;
}
void precomp(vector<int> &a) {
  for (int i = 0; i < a.size(); i++) {
    val[i] = __lg(a[i] - 1) + 1;
  }
}
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  int t;
  cin >> t;
  while (t--) {
    int n, q;
    cin >> n >> q;
    val.assign(n, 0);
    vector<int> a(n);
    for (auto &x : a)
      cin >> x;
    precomp(a);
    vector<int> c(n);
    for (int i = 0; i < n; i++) {
      if (poww(a[i]))
        c[i] = 1;
    }
    vector<int> summ(n);
    summ[0] = val[0];
    for (int i = 1; i < n; i++) {
      summ[i] = summ[i - 1] + val[i];
    }
    vector<int> pref(n);
    pref[0] = c[0];
    for (int i = 1; i < n; i++) {
      pref[i] = pref[i - 1] + c[i];
    }
    while (q--) {
      int l, r;
      cin >> l >> r;
      l--;
      r--;
      if (pref[r] - pref[l] + c[l] > 0) {
        cout << summ[r] - summ[l] + val[l] - 1 << "\n";
      } else {
        cout << summ[r] - summ[l] + val[l] << "\n";
      }
    }
  }
}