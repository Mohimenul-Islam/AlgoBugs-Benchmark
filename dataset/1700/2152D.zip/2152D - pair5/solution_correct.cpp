#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

#define ll long long
#define ld long double
#define loop(g, t) for (ll g = 0; g < t; g++)
#define loop1(g, t) for (ll g = 1; g <= t; g++)
#define loopr(g, t) for (ll g = t - 1; g >= 0; g--)
#define loop1r(g, t) for (ll g = t; g > 0; g--)
#define cyes cout << "YES" << endl
#define cno cout << "NO" << endl
#define F first
#define S second
#define sort(v) sort(v.begin(), v.end())
#define reverse(v) reverse(v.begin(), v.end())
const ll N = 4e5 + 10;
const ll inf = 1e16;
const ll mod = 1e9 + 7;

ll score(ll x){
    ll m = 0;
    while(x > 1){
        m++;
        x /= 2;
        if(x == 1) break;
        x++;
    }
    return m;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    //cout << fixed << setprecision(12);

    ll t = 1; 
    cin >> t; 

    ll n;
    string s;

    while (t--) 
    {   
        ll n, q; cin >> n >> q; 
        //1001 1001 1001
        //100 1001 1001
        vector<ll> a(n + 1, 0), b(n + 1, 0), pref(n + 1, 0), p(n + 1, 0);
        loop1(i, n){ 
            cin >> a[i]; 
            b[i] = score(a[i]);
            p[i] = (score(a[i] + 1) - b[i]);
        }

        loop1(i, n){ 
            pref[i] = pref[i - 1] + b[i];
            p[i] = p[i] + p[i - 1];
        }

        while(q--){
            ll l, r; cin >> l >> r; 
            ll add = max(0LL, p[r] - p[l - 1]);
            cout << pref[r] - pref[l - 1] + add / 2 << "\n";
        }
    }
}