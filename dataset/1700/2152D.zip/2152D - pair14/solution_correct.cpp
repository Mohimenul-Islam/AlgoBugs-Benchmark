#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

void solve(){
    ll n,q;
    cin>>n>>q;
    vector<ll> vec(n);
    for(ll i=0; i<n; i++){
        cin>>vec[i];
    }
    vector<ll> bits(n);
    vector<ll> a(n);
    vector<ll> b(n);
    for(ll i=0; i<n; i++){
        ll temp=vec[i];
        ll num=0;
        while(temp>0){
            num++;
            temp/=2;
        }
        bits[i]=num;
        ll haha=0;
        if(i!=0) haha=a[i-1];
        if(vec[i]==(1<<(num-1))){
            a[i]=1+haha;
        }
        else{
            a[i]=haha;
        }
        haha=0;
        if(i!=0) haha=b[i-1];
        if(vec[i]==(1<<(num-1))+1){
            b[i]=1+haha;
        }
        else{
            b[i]=haha;
        }
    }
    for(ll i=1; i<n; i++){
        bits[i]+=bits[i-1];
    }
    while(q--){
        ll l,r;
        cin>>l>>r;
        l--; r--;
        ll ans=bits[r];
        if(l!=0) ans-=bits[l-1];
        ans-=(r-l+1);
        ll minus=a[r];
        if(l!=0) minus-=a[l-1];
        ll temp=(r-l+1);
        temp-=minus;
        ans+=temp;
        ll check=b[r];
        if(l!=0) check-=b[l-1];
        ans-=((check+1)/2);
        cout<<ans<<"\n";
    }
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ll tt;
    cin>>tt;
    while(tt--){
        solve();
    }
}