 
#include<bits/stdc++.h>
using namespace std;
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
template<class T> using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template<class T> using ordered_multiset = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>;


#define fi(i,x,n) for(auto i=x;i<n;i++)
#define all(x) (x).begin(), (x).end()
#define allr(x) (x).rbegin(), (x).rend()
#define ll long long
#define ull unsigned long long
#define vi vector<int> 
#define vl vector<ll> 
#define pi pair<int,int>
#define pl pair<ll,ll>
#define PI 3.14159265358979323846
const ll M= 1e9+7;
const ll M1=998244353;
#define vii(v,n) for(ll i=0;i<n;i++)cin>>v[i]
#define print(v,n) for(ll i=0;i<n;i++)cout<<v[i]<<" "
#define npos string::npos
#define gcd(a,b) __gcd(a,b)
#define endl '\n'
#define F first
#define S second
#define pb push_back
// ans = a ? b : c;
// ans = min(ans, new_computation);
//__builtin_popcount(unsigned int) returns the number of set bits (__builtin_popcount(0b0001'0010'1100) == 4)
//builtin_ffs(int) finds the index of the first (most right) set bit (__builtin_ffs(0b0001'0010'1100)==3)
//builtin_clz(unsigned int) the count of leading zeros (__builtin_clz(0b0001'0010'1100) == 23) 
// 64- would give 1 based 63 would give 0 based (for power of 2)
//builtin_ctz(unsigned int) the count of trailing zeros (__builtin_ctz(0b0001'0010'1100) == 2) 
// __builtin_ctzll(x) -> for long long
//builtin_parity(x) the parity (even or odd) of the number of ones in the bit representation
// 97 for 'a' and 65 for 'A' <= ascii value ;
// s.find_by_order(k) <= it is a iterator to kth element(0 based) in sorted set
// s.order_of_key(l) <= it is the position of element l in set(0 based)

//builtin_clz = gives 00010 -> 3
//builtin_ctz = gives 00010 -> 1


//..........................DSU.......................//
class DSU {
public:
    vector<ll> parent, size;

    // Constructor to initialize DSU for n elements
    DSU(ll n) {
        parent.resize(n);
        size.resize(n, 1); // Initially, size of every component is 1
        for (int i = 0; i < n; i++) {
            parent[i] = i;  // Each node is its own parent initially
        }
    }

    // Find function with path compression
    ll get(ll v) {
        if (v == parent[v])
            return v;
        return parent[v] = get(parent[v]);  // Path compression
    }

    // Union by size
    void union_set(ll a, ll b) {
        a = get(a);
        b = get(b);
        if (a != b) {
            if (size[a] < size[b])
                swap(a, b);
            parent[b] = a;
            size[a] += size[b];
        }
    }
};

//........................MERGE/INVERSIONS.................//
ll merge(vl &arr,ll l,ll mid,ll r){
    ll cnt=0;
    ll n1=mid-l+1,n2=r-mid;
    vl left(n1),right(n2);
    for (int i = 0; i <n1; ++i)
    {
        left[i]=arr[i+l];
    }
    for (int i = 0; i < n2; ++i)
    {
        right[i]=arr[i+mid+1];
    }

    ll i=0,j=0,k=l;
    while(i<n1 && j<n2){
        if(left[i]>right[j]){
            cnt+= n1-i;
            arr[k]=right[j];
            j++;
        }
        else{
            arr[k]=left[i];
            i++;
        }
        k++;
    }

    while(i<n1){
        arr[k++]=left[i++];
    }

    while(j<n2){
        arr[k++]=right[j++];
    }

    return cnt;
}

ll cnt_inversions(vl &v,ll l,ll r){
    ll cnt=0;
    if(l<r){
        ll mid=(l+r)/2;
        cnt+= cnt_inversions(v,l,mid);
        cnt+=cnt_inversions(v,mid+1,r);
        cnt+=merge(v,l,mid,r);

    }
    return cnt;
}


// ....................Segment Tree....................//

// // can be max,min, pair<max,freq of max>,gcd,lcm
// // no of x in a range and finding the position of kth occurence of x
// // search for an array prefix with a given amount x basically smallest i such that pref[i]>=x
// // searching for the first element greater than a given amount x in (l,r)




// // child of i at 2*i, 2*i +1
// // parent of i at i/2
// // this is bfs type storing of vertices 
// // size is kept 4*n it will used fully only when n is power of 2 
// // to make it memory efficient we can make array of size 2*n since for n size array the 
// // max no of vertices required is 2*n -1 we can store in preorder traversal 
// // vertex v for(l,r) ,left child at v+1, right child at v+2*(mid-l+1) since the no of vertices in left child is 2*(mid-l+1)-1
// // finding subsegments with maximal sum in (l,r) if all negative elements then return 0
// // make a combine function and for the vertex store four values sum,maxprefsum,maxsuffsum,maxsubsegment sum
// // the answer for a range would be max(maxsub(left),maxsub(right),maxpref(left)+maxsuff(right)) 

// void build(vl &a, ll v,ll tl,ll tr,vl &q){
//     if(tl==tr){
//         q[v]=a[tl];
//     }
//     else{
//         ll mid=(tl+tr)/2;
//         build(a,v*2,tl,mid,q);
//         build(a,v*2 +1,mid+1,tr,q);
//         q[v]=max(q[2*v] , q[2*v +1]);
//     }
// }

// // here we make extra calls for l>r

// ll sum(ll v,ll tl, ll tr, ll l,ll r,vl &q){
//     if(l>r){
//         return -1;
//     }
//     if(tl==l && tr==r){
//         return q[v];
//     }
//     ll mid=(tl+tr)/2;
//     return max(sum(2*v,tl,mid,l,min(r,mid),q),sum(2*v +1,mid+1,tr,max(l,mid+1),r,q));
// }

// void update(ll v,ll tl,ll tr,ll pos,ll x,vl &q){
//     if(tl==tr){
//         q[v]=x;
//     }
//     else{
//         ll mid=(tl+tr)/2;
//         if(pos<=mid){
//             update(2*v,tl,mid,pos,x,q);
//         }
//         else{
//             update(2*v +1,mid+1,tr,pos,x,q);
//         }
//         q[v]=max(q[v*2],q[v*2 +1]);
//     }
// }

// ll get(ll v,ll tl,ll tr,ll x,vl &q){
//     if(q[v]<x)return -1;
//     if(tl==tr)return tl;
//     ll mid=(tl+tr)/2;
//     ll le=get(2*v,tl,mid,x,q);
//     if(le!=-1){
//         return le; 
//     }
//     else return get(2*v +1,mid+1,tr,x,q);
// }


//....................MATHS......................//
long long binpow(long long a, long long b) {
    long long res = 1;
    while (b > 0) {
        if (b & 1)
            res = res * a ;
        a = a * a ;
        b >>= 1;
    }
    return res;
}

long long binpow_mod(long long a, long long b,long long m) {
     a %= m;
    long long res = 1;
    while (b > 0) {
        if (b & 1)
            res = res * a %m;
        a = a * a %m;
        b >>= 1;
    }
    return res;
}


ll modinv(ll a,ll b){
 return binpow_mod(a,b-2,M);
}

// const ll fact_size=1e5+10;
// ll fact[fact_size];
// void prefcompute_fact(){
//     fact[0]=0;fact[1]=1;
//     for (int i = 2; i <fact_size; ++i)
//     {
//         fact[i]=(fact[i-1]*i)%M;
//     }
// }

// ll ncr(ll n,ll r){
//     return ((((fact[n]%M)*(modinv(fact[r],M)%M))%M)*((modinv(fact[n-r],M)%M))%M)%M;
// }

// const ll T=1e7+10;
// vector<bool>  is_prime(T ,1);
// vector<ll> spf(T),hpf(T);
// void seive(){
//     is_prime[0]=false;is_prime[1]=false;
//     for (ll i = 2; i<T; ++i)
//     {
//         if(is_prime[i]==true){
//             spf[i]=hpf[i]=i;
//             for (ll j = 2*i; j<T; j+=i)
//             {
//                 is_prime[j]=false;   // O(n*log(log(n)))
//                 hpf[j]=i;
//                 if(spf[j]==0){
//                     spf[j]=i;
//                 }
//             }
//         }
//     }
// }

// vector<ll> prime_fact(ll x){
//     vector<ll> prime_factors;
//     map<ll,ll> mp; //to store the count of prime factors
//     while(x>1){
//         ll prime_factor=hpf[x];             // O(logn)
//         while(x%prime_factor==0){
//             prime_factors.push_back(prime_factor);
//             mp[prime_factor]++;
//             x/=prime_factor;
//         }
//     }
//     return prime_factors;
// }


 ll lcm(ll a,ll b){
        return (a*b)/gcd(a,b);
 }
 
void solve(){
    ll n,q;cin>>n>>q;
    vl v(n);vii(v,n);
    vl cnt(n);
    for (int i = 0; i < n; ++i)
    {
        cnt[i]=63-__builtin_clzll(v[i]);
    }

    vl vis(n,0);
    for (int i = 0; i < n; ++i)
    {
        if((1LL<<cnt[i])+1==v[i]){
            vis[i]=1;
        }
    }


    for (int i = 1; i < n; ++i)
    {
        vis[i]+=vis[i-1];
    }
    for (int i = 0; i < n; ++i)
    {
        if(v[i]&(v[i]-1)){
            cnt[i]++;
        }
        if(i>0){
            cnt[i]+=cnt[i-1];
        }
        
    }
    while(q--){
        ll l,r;cin>>l>>r;
        l--;r--;
        if(l==0){
            ll ans=cnt[r];
            if(vis[r]){
                ans--;
            }
            cout<<ans<<endl;
        }
        else{
            ll ans=cnt[r]-cnt[l-1];
            if(vis[r]-vis[l-1]){
                ans--;
            }
            cout<<ans<<endl;

        }

    }
}

int main(){

ios_base::sync_with_stdio(false);
cin.tie(NULL);
   
  int t;cin>>t;
  while(t--){

            solve();

  }

}       