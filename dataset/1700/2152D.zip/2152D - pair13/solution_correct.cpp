#include <bits/stdc++.h>
using namespace std;
#define itn int
#define icn cin
#define int long long
#define unsigned long long ull
#define endl '\n'
typedef pair<int,int> PII;
const int N=2e3+10;
const int INF=1e9;
const int MOD=1e9+7;
//#define ll __int128

void solve() {
	itn n,q;
	cin>>n>>q;
	vector<int>a(n+1),pre(n+1,0);
	for(itn i=1;i<=n;i++){
		cin>>a[i];
	} 
	
	pre[0]=0;//统计区间特殊数个数 当2进制为 10001这种即为特殊 R先手就会使答案+1 
	for(itn i=1;i<=n;i++){
	  for(int j=1;j<=30;j++){
	  	if((1<<j)+1==a[i]){
	  		pre[i]=pre[i-1]+1;break;
		  }
	  }
	  if(!pre[i])pre[i]=pre[i-1]; 
	}

	vector<int>ans(n+1);//如果正常处理一个数让他为1 需要的操作次数 
	ans[0]=0;
	
    for(itn i=1;i<=n;i++){
    	int x=a[i];
    	int ci=0;
    	int f=1;
    	while(x!=1){//1e9 大概是2的30次方 所以不会超时 
    		if(f&1)x/=2,ci++;
    		else x++;
    		f=!f;
		}
		ans[i]=ci;
	}
	for(int i=1;i<=n;i++)ans[i]+=ans[i-1];
	
	while(q--){
		int l,r;
		cin>>l>>r;
		int x=pre[r]-pre[l-1];
		x/=2;//有一部分R操作后 会使结果+1
		
		cout<<ans[r]-ans[l-1]+x<<endl; 
	}
}

signed main() {
    
    cin.tie(0)->sync_with_stdio(0);

	int T=1;
	cin>>T;
//   mt19937 rand(time(nullptr));
	while(T--)solve();

	return 0;
}

/*

2 1
299406837 2097153
1 2

**/

/*
ac : 50 now : 51
*/