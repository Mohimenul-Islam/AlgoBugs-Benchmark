#include <bits/stdc++.h>
#define IOS                  \
    ios::sync_with_stdio(0); \
    cin.tie(0);              \
    cout.tie(0)
using namespace std;
void solve()
{

    int n, q;
    cin >> n >> q;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    vector<int> cnt(n + 1, 0);
    vector<int> ta(n + 1, 0);
    vector<int> tb = ta;
    vector<int> tc = ta;
    for (int i = 1; i <= n; i++)
    {
        int ti = a[i];
        if ((ti & (ti - 1)) == 0)
        {
            ta[i] = 1;
        }
        else if (((ti - 1) & (ti - 2)) == 0)
        {
            tb[i] = 1;
        }
        else
        {
            tc[i] = 1;
        }
        cnt[i] = log2(ti);
    }
    // for (int i = 1; i <= n; i++)
    // {
    //     cout << ta[i] << " ";
    // }
    // cout << endl;
    // for (int i = 1; i <= n; i++)
    // {
    //     cout << tb[i] << " ";
    // }
    // cout << endl;
    // for (int i = 1; i <= n; i++)
    // {
    //     cout << tc[i] << " ";
    // }
    // cout << endl;
    vector<int> sa(n + 1, 0);
    vector<int> sb = sa;
    vector<int> sc = sa;
    for (int i = 1; i <= n; i++)
    {

        sa[i] = sa[i - 1] + cnt[i];
        sb[i] = sb[i - 1] + tb[i];
        sc[i] = sc[i - 1] + tc[i];
    }
    while (q--)
    {
        int l, r;
        cin >> l >> r;
        int sum = sa[r] - sa[l - 1];
        int B = sb[r] - sb[l - 1];
        int C = sc[r] - sc[l - 1];
        int ans = sum + B / 2 + C;
        cout << ans << endl;
    }
}
int main()
{
    IOS;
    // init();
    int T;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}