#include <bits/stdc++.h>
#define IOS                  \
    ios::sync_with_stdio(0); \
    cin.tie(0);              \
    cout.tie(0)
using namespace std;
vector<int> p2(31, 1);
void init()
{
    for (int i = 2; i <= 30; i++)
    {
        p2[i] = 2 * p2[i - 1];
    }
}
void solve()
{

    int n, q;
    cin >> n >> q;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    vector<int> cnt(n + 1, 0);
    vector<int> tg(n + 1, 0);
    int sum = 0;
    for (int i = 1; i <= n; i++)
    {
        int ti = a[i];
        int c = 0;
        while (ti > 1)
        {
            c++;
            ti /= 2;
            if (ti == 1)
                break;
            ti++;
        }
        ti = a[i];
        int c1 = 0;
        while (ti > 1)
        {
            c1++;
            ti++;
            ti /= 2;
        }
        if (c1 != c)
        {
            tg[i] = 1;
        }
        ti = a[i];
        // vector<int> tmp;
        // while (ti)
        // {
        //     tmp.push_back(ti % 2);
        //     ti /= 2;
        // }
        // for (int i = tmp.size() - 1; i >= 0; i--)
        //     cout << tmp[i];
        // sum += tmp.size();
        // cout << " ";
        //  cout << endl;
        // cout << c << " ";
            cnt[i] = c1;
    }
    // cout << sum;
    // cout << endl;
    // for (int i = 1; i <= n; i++)
    // {
    //     cout << cnt[i] << " ";
    // }
    // cout << endl;
    // for (int i = 1; i <= n; i++)
    // {
    //     cout << tg[i];
    // }
    // cout << endl;
    vector<int> s(n + 1, 0), stg(n + 1, 0);
    for (int i = 1; i <= n; i++)
    {
        s[i] = s[i - 1] + cnt[i];
        stg[i] = stg[i - 1] + tg[i];
    }
    // cout << endl;
    while (q--)
    {
        int l, r;
        cin >> l >> r;
        // cout << l << " " << r << endl;
        int tag = stg[r] - stg[l - 1];
        int ans = s[r] - s[l - 1];
        if (tag >= 1)
            ans--;
        cout << ans << endl;
    }
}
int main()
{
    IOS;
    init();
    int T;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}