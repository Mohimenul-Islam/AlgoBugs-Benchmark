﻿#define _CRT_SECURE_NO_WARNINGS
#include<bits/stdc++.h>
#include <unordered_set>
#include <algorithm>
using namespace std;
using ll = long long;
using ld = long double;
using ull = unsigned long long;
using vi = vector<int>;
using vii = vector<pair<int, int>>;
using pii = pair<int, int>;
using pll = pair<ll, ll>;

constexpr ll inf = (1ll << 62);
constexpr double INF = 1e18;
#define i128 __int128_t
#define PI acos(-1.0)
#define mem(x,a) memset(x, a, sizeof(x))
#define MOD 676767677
#define ER 0.000001
#define MAXN 250005
#define MAXM 100005
int dir[4][2] = { {-1,0}, {0,1}, {1,0}, {0,-1} };

int ok(int x)
{
    if (x == (x & -x))return 1;
    x--;
    if (x == (x & -x))return 2;
    return 3;
}

int b[MAXN], c[MAXN], he[MAXN];

void solve() 
{
    int n, q;
    cin >> n >> q;
    
    for (int i = 1; i <= n; i++)
    {
        int x;
        cin >> x;
        int op = ok(x);
        b[i] = c[i] = he[i] = 0;
        if (op == 2)b[i]++;
        if (op == 3)c[i]++;
        he[i] = he[i - 1] + (int)log2(x);
        b[i] += b[i - 1];
        c[i] += c[i - 1];
    }
    while (q--)
    {
        int l, r;
        cin >> l >> r;
        cout << he[r] - he[l - 1] + c[r] - c[l - 1] + (b[r] - b[l - 1]) / 2 << "\n";
    }

    

}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int test = 1;
    //build();

    cin >> test;

    while (test--)
    {
        solve();
    }

    return 0;
}