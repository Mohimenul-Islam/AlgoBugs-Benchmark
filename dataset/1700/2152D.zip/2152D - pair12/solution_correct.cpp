#include <bits/stdc++.h>
#define fir first
#define sec second
using namespace std;
typedef long long ll;
const int N=5e5+10;
ll a[N];

void solve() {
    ll n,q;cin>>n>>q;
    for(int i=1;i<=n;i++) {
        cin>>a[i];
    }
    vector<ll> s(n+1),ans(n+1),t(n+1);
    for(int i=1;i<=n;i++) {
        ans[i]=ans[i-1];
        ans[i]+=__lg(a[i]);
    }
    for(int i=1;i<=n;i++) {
        s[i]=s[i-1];
        t[i]=t[i-1];
        ll j=__lg(a[i]);
        ll x=1<<j;
        if(a[i]==x) t[i]++;
        else if(a[i]==x+1) s[i]++;
    }
    for(int i=1;i<=q;i++) {
        ll l,r;cin>>l>>r;
        ll x=s[r]-s[l-1],y=t[r]-t[l-1];
        cout<<ans[r]-ans[l-1]+x/2+(r-l+1-x-y)<<'\n';
    }

}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ll t;cin>>t;
    while(t--) solve();
    return 0;
}