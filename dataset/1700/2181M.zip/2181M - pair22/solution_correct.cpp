#include <bits/stdc++.h>
#include <bits/extc++.h>
#define debug(x) std::cerr << "debug: " << #x << " = " << x << std::endl
#define debug_checker(arg_name, x) std::cerr << arg_name << ": " << x << std::endl
#define iter(x, y) x.begin() + y, x.end()
#define all(x) x.begin(), x.end()
#define vecin(vec, a, b) for (int i = a; i <= b; i++) std::cin >> vec[i]
#define vecoutln(vec, a, b) for (int i = a; i <= b; i++) std::cout << vec[i] << " \n"[i == b]

using i128 = __int128_t;
using u128 = __uint128_t;
using i64 = long long;
using u64 = unsigned long long;
using i32 = signed;
using u32 = unsigned;

using pii = std::pair<int, int>;
using piii = std::pair<int, pii>;

const int MOD = 998244353;
const int MAXN = 200000;
const i64 INF64 = 1LL << 60;
const int INF = 1 << 30;

using namespace __gnu_pbds;
using namespace __gnu_cxx;

template <typename T> void write(T x);
template <typename T> inline void read(T& x);

#define IS_MULTIPLE_TEST_CASES 1
void solve() {
    std::string a, b;
    std::cin >> a >> b;

    int n = a.size();
    std::vector<int> x(n + 1), y(n + 1);
    for (int i = 0; i < n; i++) {
        x[i + 1] = a[i] - '0';
        y[i + 1] = b[i] - '0';
    }

    std::vector<std::array<int, 2>> dp(n + 1, { INF, INF });
    dp[0][0] = 0;

    for (int i = 1; i <= n; i++) {
        for (int j = 0; j < 2; j++) {
            dp[i][j] = std::min(dp[i][j], dp[i - 1][j] + (x[i] != 0) + (y[i] != j));
            dp[i][j] = std::min(dp[i][j], dp[i - 1][(j + 1) % 2] + (x[i] != 1) + (y[i] != j));
        }
    }

    std::cout << std::min(dp[n][0], dp[n][1]) << "\n";
}

signed main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    int T = 1;
    if (IS_MULTIPLE_TEST_CASES) std::cin >> T;
    while (T--) solve();
    return 0;
}

template <typename T>
void write(T x) {
    if (x < 0) x = -x, putchar('-');
    if (x > 9) write(x / 10);
    putchar(x % 10 ^ '0');
}

template<typename T>
inline void read(T& x) {
    x = 0; int f = 1; char c = getchar();
    while (c < '0' || c > '9') { if (c == '-') f = -1; c = getchar(); }
    while (c >= '0' && c <= '9') { x = (x << 1) + (x << 3) + (c ^ '0'); c = getchar(); }
    x *= f;
}