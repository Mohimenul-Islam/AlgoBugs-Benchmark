#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;

typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> pbds; //// find_by_order, order_of_key
typedef long long int ll;

const ll MOD = 1e9 + 7;

// Fast exponentiation (base^exp % MOD)
ll modexp(ll base, ll exp, ll mod = MOD) {
    ll result = 1;
    base %= mod;
    while (exp > 0) {
        if (exp & 1) result = result * base % mod;
        base = base * base % mod;
        exp >>= 1;
    }
    return result;
}

// Modular inverse (works when MOD is prime)
ll modinv(ll x, ll mod = MOD) {
    return modexp(x, mod - 2, mod);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--) {
        string a,b;
        cin>>a>>b;
        ll n=a.size();
        vector<vector<ll>>ans(n,vector<ll>(2,1e7));
        ans[0]={0,0};
        if(a[0]!=b[0]){
            ans[0][0]=1;
            ans[0][1]=1;
        }
        
        for(int i = 1; i < n; i++) {
            char temp1=b[i];
            ll temp2=temp1-'0';
            if(a[i]=='1'){
                
                ans[i][temp2]=ans[i-1][1-temp2];
                ans[i][1-temp2]=1+ans[i-1][temp2];
                ans[i][temp2]=min(ans[i][temp2],1+ans[i-1][temp2]);

            }
            else{
                ans[i][temp2]=ans[i-1][temp2];
                ans[i][1-temp2]=1+ans[i-1][1-temp2];
                ans[i][temp2]=min(ans[i][temp2],1+ans[i-1][1-temp2]);
            }
        }
        cout<<min(ans[n-1][0],ans[n-1][1])<<endl;


        
    }
    return 0;
}