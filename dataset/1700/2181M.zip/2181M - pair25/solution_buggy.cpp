#include <bits/stdc++.h>
using namespace std;
using ll=long long;
using i128=__int128;
constexpr ll INF=0x3f3f3f3f3f3f3f3f;
constexpr ll MOD=998244353;
// constexpr ll MOD=1e9+7;
int T;
string x,y;
int n;
int main() {
    // ifstream cin("input.txt");
    // ofstream cout("output.txt");
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin>>T;
    while (T--) {
        cin>>x>>y;
        n=x.size();
        x=' '+x;
        y=' '+y;
        vector<int> yy(n+2);
        int cnt1=0;
        for (int i=1;i<=n;i++) {
            cnt1+=(x[i]=='1');
            if (y[i]-'0'==cnt1%2) {
                yy[i]=1;
            }
        }
        vector<int> suf(n+2);
        for (int i=n;i>=1;i--) {
            suf[i]=suf[i+1]+yy[i];
        }
        //x翻转一次，对前缀1的个数影响为1
        //对x进行翻转，会使得后面y原来符合的变为不符合，原来不符合的变为符合
        int ans=0;
        int c=0;
        int f=0;
        for (int i=1;i<=n;i++) {
            c+=(x[i]=='1');
            if (f==0) {
                if (c%2!=y[i]-'0') {
                    if (suf[i+1]>=n-i-suf[i+1]) {
                        //后面符合条件的多，改y
                    }
                    else {
                        //后面不符合条件的多，改x
                        ++c;
                        f^=1;
                    }
                    ++ans;
                }
            }
            else {
                if (c%2!=y[i]-'0') {
                    if (n-i-suf[i+1]>=suf[i+1]) {
                        //后面符合条件的多，改y
                    }
                    else {
                        //后面不符合条件的多，改x
                        ++c;
                        f^=1;
                    }
                    ++ans;
                }
            }
        }
        cout<<ans<<'\n';
    }

    return 0;
}