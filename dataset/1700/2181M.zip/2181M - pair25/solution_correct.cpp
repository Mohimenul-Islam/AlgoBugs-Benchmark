#include <bits/stdc++.h>
using namespace std;
using ll=long long;
using i128=__int128;
constexpr ll INF=0x3f3f3f3f3f3f3f3f;
constexpr ll MOD=998244353;
// constexpr ll MOD=1e9+7;
int T;
string x,y;
int n;
int main() {
    // ifstream cin("input.txt");
    // ofstream cout("output.txt");
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin>>T;
    while (T--) {
        cin>>x>>y;
        n=x.size();
        x=' '+x;
        y=' '+y;
        //x翻转一次，对前缀1的个数影响为1
        //对x进行翻转，会使得后面y原来符合的变为不符合，原来不符合的变为符合
        //dp[i][j]表示长度为i的满足条件的前缀，最后一个y为0(j=0)，最后一个y为1(j=1)的最小次数
        vector dp(n+2,vector<ll>(2,0));
        dp[0][0]=0;
        dp[0][1]=INF;
        //y[i]无非只有0/1两种情况，我们都算出来
        //y[i]由y[i-1]和x[i]共同确定
        //如果y[i-1]==1，如果x[i]==1,则y[i]==0;如果x[i]==0,则y[i]==1;
        //如果y[i-1]==0，如果x[i]==1,则y[i]==1;如果x[i]==0,则y[i]==0;
        for (int i=1;i<=n;i++) {
            //固定y[i]==0;
            if (x[i]=='1') {
                if (y[i]=='0') {
                    dp[i][0]=min(dp[i-1][1],dp[i-1][0]+1);
                    dp[i][1]=min(dp[i-1][0]+1,dp[i-1][1]+1);
                }
                else if (y[i]=='1') {
                    dp[i][0]=min(dp[i-1][1]+1,dp[i-1][0]+1);
                    dp[i][1]=min(dp[i-1][0],dp[i-1][1]+1);
                }
            }
            if (x[i]=='0') {
                if (y[i]=='0') {
                    dp[i][0]=min(dp[i-1][1]+1,dp[i-1][0]);
                    dp[i][1]=min(dp[i-1][0]+1,dp[i-1][1]+1);
                }
                else if (y[i]=='1') {
                    dp[i][0]=min(dp[i-1][1]+1,dp[i-1][0]+1);
                    dp[i][1]=min(dp[i-1][0]+1,dp[i-1][1]);
                }
            }
        }
        ll ans=min(dp[n][0],dp[n][1]);
        cout<<ans<<'\n';
    }

    return 0;
}