#include <bits/stdc++.h>
using namespace std;
#define int long long
string s1,s2;
vector<int> a;
int ans;

void dfs(int pos, int cnt ,int cs, int err) {
    while (pos!=s1.size()) {
        if (a[pos]<err) return;
        a[pos]=err;
        if (cs) {
            if (cs==1) {
                if (s1[pos]=='1')cnt--;
                else cnt++;
            }
            cs=0;
            pos++;
        }
        else {
            if (s1[pos]=='1') cnt++;
            if (cnt%2!=s2[pos]-'0') {
                a[pos]=err+1;
                dfs(pos,cnt,1,err+1);
                dfs(pos,cnt,2,err+1);
                break;
            }
            pos++;
        }
    }
    if (pos==s1.size())
        ans=min(ans,a[s1.size()-1]);
}

void sol() {
    ans=1e9;
    cin>>s1>>s2;
    int n=s1.size();
    a.assign(n+1,1e9);
    dfs(0,0,0,0);
    cout<<ans<<endl;
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--) sol();

    return 0;
}