#include <bits/stdc++.h>
using namespace std;
#define int long long


void sol() {
    string s1,s2;
    cin>>s1>>s2;
    int n=s1.size();
    int a[n+1][2];
    a[0][0]=0;a[0][1]=1e9;
    for (int p=0;p<n;p++) {
        int i=p+1;
        if (s1[p]=='0') {
            if (s2[p]=='0') {
                a[i][0]=min(a[i-1][0],a[i-1][1]+1);
                a[i][1]=min(a[i-1][0]+2,a[i-1][1]+1);
            }
            else {
                a[i][0]=min(a[i-1][0]+1,a[i-1][1]+2);
                a[i][1]=min(a[i-1][0]+1,a[i-1][1]);
            }
        }
        else {
            if (s2[p]=='0') {
                a[i][0]=min(a[i-1][0]+1,a[i-1][1]);
                a[i][1]=min(a[i-1][0]+1,a[i-1][1]+2);
            }
            else {
                a[i][0]=min(a[i-1][0]+2,a[i-1][1]+1);
                a[i][1]=min(a[i-1][0],a[i-1][1]+1);
            }
        }
    }
    cout<<min(a[n][0],a[n][1])<<endl;
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--) sol();

    return 0;
}