#include<bits/stdc++.h>

using namespace std; 
int main(int argc, char const *argv[])
{

	int q; cin >> q; 
	while (q --){
		string s, t; cin >> s >> t;
		s = "@" + s; 
		t = "@" + t;  
		int dp[s.size() + 5]; 
		dp[0] = 0;
		dp[1] = s[1] == t[1] ? 0 : 1;
		int cnt = (int) s[1];  
		for(int i = 2; i < s.size(); i++){
			if(s[i] == '1') cnt++; 
			if(cnt % 2 == 0){
				if(t[i] != '0') dp[i] = min(dp[i-1] + 1, dp[i-2] + 1);
				else dp[i] = dp[i-1];  
			}
			else{
				if(t[i] != '1') dp[i] = min(dp[i-1] + 1, dp[i-2] + 1);
				else dp[i] = dp[i-1];
			}
		}
		cout << dp[s.size()-1] << endl; 
	}	
	return 0;
}