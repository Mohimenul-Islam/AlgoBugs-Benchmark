#include <bits/stdc++.h>
using namespace std;
const int maxn=1e6+5;
string x,y;
int t,n,dp[maxn][2];

int main(){
	ios::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
	cin >> t;
	while(t--){
		cin >> x >> y;
		n=x.size();
		if(x[0]!=y[0]) dp[0][0]=dp[0][1]=1;
		else dp[0][(y[0]-'0')^1]=n;
		for(int i=1;i<n;i++){
			if(x[i]=='0' && y[i]=='1'){
				dp[i][0]=dp[i-1][0]+1;
				dp[i][1]=min(dp[i-1][0]+1,dp[i-1][1]);
			}
			if(x[i]=='1' && y[i]=='1'){
				dp[i][0]=dp[i-1][1]+1;
				dp[i][1]=min(dp[i-1][0],dp[i-1][1]+1);
			}
			if(x[i]=='1' && y[i]=='0'){
				dp[i][1]=dp[i-1][0]+1;
				dp[i][0]=min(dp[i-1][1],dp[i-1][0]+1);
			}
			if(x[i]=='0' && y[i]=='0'){
				dp[i][1]=dp[i-1][1]+1;
				dp[i][0]=min(dp[i-1][0],dp[i-1][1]+1);
			}
		}cout << min(dp[n-1][0],dp[n-1][1]) << '\n';
		memset(dp,0,sizeof(dp));
	}
	return 0;
} 