#include <string>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <numeric>
#include <bitset>
#include <list>
#include <stdexcept>
#include <functional>
#include <utility>
#include <iomanip>
#include <ctime>
#include <valarray>
#include <iostream>
#include <sstream>
#include <fstream>
using namespace std;
typedef long long LL;
typedef unsigned long long ULL;
#define MEM(a,b) memset((a),(b),sizeof(a))
const LL INF = 1e9 + 7;
const int N = 2e5 + 10;
char s1[N];
char s2[N];
int dp[N][2];
int main()
{
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	int ncase;
	scanf("%d", &ncase);
	while (ncase--)
	{
		scanf("%s%s", s1 + 1, s2 + 1);
		int n = strlen(s1 + 1);
		dp[0][0] = 0;
		dp[0][1] = INF;
		for (int i = 1; i <= n; i++)
		{
			dp[i][0] = dp[i][1] = INF;
			for (int o1 = 0; o1 < 2; o1++)
			{
				for (int o2 = 0; o2 < 2; o2++)
				{
					int cnt = 0;
					if (o2 + '0' != s1[i]) cnt++;
					if ((o1 ^ o2) + '0' != s2[i]) cnt++;
					dp[i][o1 ^ o2] = min(dp[i][o1 ^ o2], dp[i - 1][o1] + cnt);
				}
			}
		}
		printf("%d\n", min(dp[n][0], dp[n][1]));
	}
	return 0;
}