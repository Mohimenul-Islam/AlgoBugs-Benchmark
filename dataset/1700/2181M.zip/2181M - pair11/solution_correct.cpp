#include <bits/stdc++.h>

#define debug(x) cout << #x << ": " << x << endl
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define PI 3.14159265358979323846
#define lb '\n'

using namespace std;
using ll = long long;
using ull = unsigned long long;
using pii = pair<int, int>;
using flt = float;
using db = double;

const int INF = 2e9;
const ll LINF = 4e18;
const ll MOD = 998244353;
const double EPS=1E-2; 

#define int ll
void 
solve()
{
    /*
    01100
    10110
    ero
    1 1 1 1 0
    len
    
    */
    string x, y; cin >> x >> y;
    int now = 0, n = x.size();
    vector<int> ero(n), len(n);
    for (int i = 0; i < n; i++)
    {
        now ^= x[i] - '0';
        if (y[i] != now + '0') ero[i] = 1;
    } now = 1, len[n - 1] = 1;
    for (int i = n - 2; i > -1; i--)
    {
        if (ero[i] == ero[i + 1])
            now++;
        else
            now = 1;
        len[i] = now;
    }
    int dp = 0, re = 0;
    for (int i = 0; i < n; i++)
    {
        if (ero[i] ^ dp)
        {
            if (len[i] > 1)
                dp ^= 1;
            re++;                
        }
    }
    cout << re << lb;
    
}


signed
main()
{
    ios::sync_with_stdio(0);cin.tie(0);
    int T = 1;
    cin >> T;
    while (T--) solve();
    return 0;
}