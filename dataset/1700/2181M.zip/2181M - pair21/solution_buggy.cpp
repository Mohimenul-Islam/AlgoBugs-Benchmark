#include <iostream>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <vector>
#include <string>
#include <queue>
#include <map>
#include <random>
#include <set>
#define x first
#define y second
#define int long long
using namespace std;
typedef long long LL;
typedef pair<int, int> PII;
const int N = 1000010, M = 2 * N, INF = 1e18, mod = 998244353;
int dx[4] = {-1, 0, 1, 0}, dy[4] = {0, 1, 0, -1};
vector<int> nums;
int get(int x){
    return lower_bound(nums.begin(), nums.end(), x) - nums.begin();
}
void read(int &x){
    int f = 1;
    x = 0;
    char s = getchar();
    while (s < '0' || s > '9'){
        if (s == '-')
            f = -1;
        s = getchar();
    }
    while (s >= '0' && s <= '9'){
        x = x * 10 + s - '0';
        s = getchar();
    }
    x *= f;
}
int gcd(int a, int b){
    return a % b == 0 ? b : gcd(b, a % b);
}     
int n, m, k;
int dp[N][2];
// char a[N], b[N];
void solve(){
    string a, b;
    cin >> a >> b;
    int len = a.size();
    a = " " + a, b = " " + b;
    memset(dp, 0x3f, sizeof dp);
    dp[0][0] = 0;
    for(int i = 1; i <= len; i ++ ) {
        if(a[i] == '0') {
            if(b[i] == '1') {
                dp[i][1] = min(dp[i - 1][1], dp[i - 1][0] + 1);
                dp[i][0] = min(dp[i - 1][0] + 1, dp[i - 1][1] + 2);
            } else {
                dp[i][1] = min(dp[i - 1][1] + 1, dp[i - 1][0] + 2);
                dp[i][0] = min(dp[i - 1][0], dp[i - 1][1] + 1);
            }
        } else {
            if(b[i] == '1') {
                dp[i][1] = min(dp[i - 1][0], dp[i - 1][1] + 1);
                dp[i][0] = min(dp[i - 1][1] + 1, dp[i - 1][0] + 2);
            } else {
                dp[i][1] = min(dp[i - 1][0] + 1, dp[i - 1][1] + 2);
                dp[i][0] = min(dp[i - 1][1], dp[i - 1][0] + 1);
            }
        }
    }
    int res = min(dp[len][0], dp[len][1]);
    cout << res << endl;
}
signed main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    // mt19937 mt(727);                         // 种子可以固定
    // uniform_int_distribution<int> uni(1, 3); // 随机选择 1~3
    int T;
    cin >> T;
    while (T--) {
        solve();
    }
}