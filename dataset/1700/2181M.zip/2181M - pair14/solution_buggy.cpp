// Source: https://usaco.guide/general/io

#include <bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(0)->sync_with_stdio(false);
    long long t;
    cin >> t;
    while(t--){
        long long n, i;
        string x, y;
        cin >> x >> y;
        n = x.size();
        bool flipped = false;
        long long sum = 0;
        bool check[n];
        long long util[n];
        long long utilConv[n];
        for(i = 0; i < n; ++i){
            if(x[i] == '1') sum++;
            sum%=2;
            if(sum == (y[i]-'0')) check[i] = true;
            else check[i] = false;
        }
        sum = 0;
        for(i = n-1; i >= 0; --i){
            if(check[i]) sum++;
            util[i] = sum;
            utilConv[i] = (n-i)-util[i];
        }
        long long ans = 0;
        for(i = 0; i < n; ++i){
            if(check[i] == flipped){
                if(!flipped){
                    // cout << util[i] << " " << utilConv[i] << endl;
                    //check is false
                    //the current one is not correct under util
                    if(util[i] <= utilConv[i]-1) flipped = true;
                }else{
                    //check is true
                    //util[i] is the amount in the next after i
                    if(util[i]-1 >= utilConv[i]) flipped = false;
                }
                ++ans;
                // cout << i << " " << flipped << endl;
            }
        }
        cout << ans << '\n';
    }
}
