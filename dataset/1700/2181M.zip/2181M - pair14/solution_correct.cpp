// Source: https://usaco.guide/general/io

#include <bits/stdc++.h>
using namespace std;

int main() {
    cin.tie(0)->sync_with_stdio(false);
    int t;
    cin >> t;
    while(t--){
        int n, i;
        string x, y;
        cin >> x >> y;
        n = x.size();
        bool flipped = false;
        int sum = 0;
        int dp[n][2];
        //dp[i] if y[i] = 1
        //dp[i] if y[i] = 0
        if(x[0] == y[0]){
            int current = x[0]-'0';
            dp[0][current] = 0;
            dp[0][1-current] = 2;
        }else{
            dp[0][0] = 1;
            dp[0][1] = 1;
        }
        bool check[n];
        for(i = 1; i < n; ++i){
            if(x[i] == y[i]){
                if(y[i] == '0'){
                    //x[i] == 0
                    dp[i][0] = min(dp[i-1][0], dp[i-1][1]+1);
                    dp[i][1] = min(dp[i-1][0]+1, dp[i-1][1])+1;
                }else{
                    //y[i] == 1; x[i] == 1;
                    dp[i][0] = min(dp[i-1][0]+1, dp[i-1][1])+1;
                    dp[i][1] = min(dp[i-1][0], dp[i-1][1]+1);
                }
            }else{
                if(y[i] == '0'){
                    //x[i] == 1
                    dp[i][0] = min(dp[i-1][0]+1, dp[i-1][1]);
                    dp[i][1] = min(dp[i-1][0], dp[i-1][1]+1)+1;
                }else{
                    //x[i]= 0;
                    //y[i] = 1;
                    dp[i][0] = min(dp[i-1][0], dp[i-1][1]+1)+1;
                    dp[i][1] = min(dp[i-1][0]+1, dp[i-1][1]);
                }
            }
        }
        cout << min(dp[n-1][0], dp[n-1][1]) << endl;
    }
}