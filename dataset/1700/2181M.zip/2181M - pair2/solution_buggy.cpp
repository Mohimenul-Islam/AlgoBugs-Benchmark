#include<bits/stdc++.h>
using namespace std;
using ll = long long;
#define vi  vector<int>
#define vll  vector<ll>
#define vvi vector<vector<int>>
#define vvll vector<vector<ll>>
#define vs vector<string>
#define vms vector<mys>
#define pii pair<int,int>
#define vpii vector<pii>
#define vpll vector<pll>
#define pll pair<ll,ll>
#define mpii map<int,int>
#define umpii unordered_map<int,int>
#define mpsi map<string,int>
#define mpll map<ll,ll>
#define umpll unordered_map<ll,ll>
#define si set<int>
#define usi unordered_set<int>
#define sll set<ll>
#define sti stack<int>
#define ab arr.begin()
#define ae arr.end()
#define be begin()
#define ed end()
#define fi first
#define se second
const int mod = 1e9+7;
const int INF = 1e9+1;
double pi = 3.1415926536;

typedef struct mys{

}mys;

int dp[2];//dp[1]表示目前为止翻转上面为奇数次，dp[0]表示为偶数次

void code(){
     string s1,s2;
     cin>>s1>>s2;
     int f=0;
     int st=0;
     dp[0]=0;
     dp[1]=0;
     for(int i=0;i<s1.size();++i){
          if(s1[i]=='1') f++;
          if((f%2)!=(s2[i]-'0')){
               st=i+1;
               dp[1]=1;
               dp[0]=1;
               break;
          }
     }
     for(int i=st;i<s1.size();++i){
          if(s1[i]=='1') f++;
          if((f%2)==s2[i]-'0') dp[1]++;
          else dp[0]++;
     }
     cout<<(st?min(dp[0],dp[1]):0)<<'\n';
}

int main(){
     ios::sync_with_stdio(false);
     cin.tie(nullptr);
     cout.tie(nullptr);
     int t=1;
     cin>>t;
     while(t--) code();
}