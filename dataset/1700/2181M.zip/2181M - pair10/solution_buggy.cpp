#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define vll vector<ll>
#define vp vector<pair<ll,ll>>
#define pll pair<ll,ll>
#define vvll vector<vector<ll>>
#define vvp vector<vector<pair<ll,ll>>>
#define pb push_back
#define fo(i, n) for (ll i = 0; i < n; i++)
#define yes cout << "YES\n"
#define no cout << "NO\n"
#define F first
#define S second

ll modPow(ll base, ll exp, ll mod) {
    ll res = 1;
    base %= mod;
    while (exp > 0) {
        if (exp % 2 == 1) res = (res * base) % mod;
        base = (base * base) % mod;
        exp /= 2;
    }
    return res;
}

ll modInversePrime(ll a, ll m) {
    return modPow(a, m - 2, m);
}

const int MOD = 1e9 + 7;

void precompute() {
    
}

// READ THE FU*KING COMMENTS YOU B*TCH

void solve() {
    string S;cin>>S;
    string T;cin>>T;
    auto topcs = [&](string s1)->string{
        string t1="";
        ll parity = 0;
        for(ll i = 0 ;i <s1.size();i++){
            if(s1[i]=='1'){
                parity++;
            }
            if(parity%2==0){
                t1+='0';
            }else {
                t1+='1';
            }
        }
        return t1;
    };
    auto frompcs = [&](string t2)->string{
        string s2 = "" ;
        if(t2[0]=='0'){
            s2+='0';
        } else {
            s2+='1';
        }
        for(ll i = 1 ;i<t2.size();i++){
            if(t2[i]!=t2[i-1]){
                s2+='1';
            } else {
                s2+='0';
            }
        }
        return s2;
    };
    string ss = topcs(S);
    string tt = frompcs(T);
    ll ans = LLONG_MAX;
    ll count = 0;
    fo(i,ss.size()){
        if(T[i]!=ss[i]){
            count++;
        }
    }
    ans = min(ans, count);
    count = 0;
    fo(i,tt.size()){
        if(S[i]!=tt[i]){
            count++;
        }
    }
    ans = min(ans, count);
    cout<<ans<<"\n";
} // CHECK FOR GRAPH EDGES COUNT FOR INPUT


void fast_io() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);
    std::cout.tie(NULL);
}

int main(){

    // freopen("mootube.in","r",stdin);
    // freopen("mootube.out","w",stdout);
    fast_io();
    precompute();
    ll t; cin>>t; while(t--)solve();
    // solve();
    return 0;
}