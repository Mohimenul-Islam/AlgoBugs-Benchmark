#include<bits/stdc++.h>
using namespace std;

int rec(string& x, string& y, vector<vector<int>>& dp, int i, char py){
	int n = x.size();
	if (i == n) return 0;
	
	if (dp[i][py-'0'] != -1) return dp[i][py-'0'];
	
	int res = 1e9;
	int same = rec(x, y, dp, i+1, y[i]);
	int diff = rec(x, y, dp, i+1, '1'+'0'-y[i]);
	if (x[i] == '0'){
		if (y[i] == py) res = same;
		else{
			int nxt = min(same, diff);
			res = 1 + nxt;
		}
	}else{
		if (y[i] == py){
			int nxt = min(same, diff);
			res = 1 + nxt;
		}else{
			res = same;
		}
	}
	
	return dp[i][py-'0'] = res;
}

void solve(){
	string x, y; cin>>x>>y;
	int n = x.size();
	vector<vector<int>> dp(n, vector<int>(2, -1));
	int res = rec(x, y, dp, 0, '0');
	cout<<"\t"<<res<<endl;
}

int main(){
	int t; cin>>t;
	while(t--) solve();
}