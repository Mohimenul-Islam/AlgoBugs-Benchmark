#include<bits/stdc++.h>
using namespace std;

int rec(string& x, string& y, int i, char py){
	int n = x.size();
	if (i == n) return 0;
	
	int res = 1e9;
	if (x[i] == '0'){
		if (y[i] == py) res = rec(x, y, i+1, y[i]);
		else{
			int nxt = min(rec(x, y, i+1, y[i]), rec(x, y, i+1, '1'+'0'-y[i]));
			res = min(res, 1 + nxt);
		}
	}else{
		if (y[i] == py){
			int nxt = min(rec(x, y, i+1, y[i]), rec(x, y, i+1, '1'+'0'-y[i]));
			res = min(res, 1 + nxt);
		}else{
			res = min(res, rec(x, y, i+1, y[i]));
		}
	}
	
	return res;
}

void solve(){
	string x, y; cin>>x>>y;
	int res = rec(x, y, 0, '0');
	cout<<"\t"<<res<<endl;
}

int main(){
	int t; cin>>t;
	while(t--) solve();
}