#include <bits/stdc++.h>
#define fir first
#define sec second
using namespace std;
typedef long long ll;

void solve() {
    string x,y;cin>>x>>y;
    ll n=x.size();
    vector<ll> a(n+1),b(n+1);
    for(int i=1;i<=n;i++) {
        a[i]=a[i-1];
        if(x[i-1]=='1') {
            a[i]++;
        }
    }
    for(int i=1;i<=n;i++) {
        ll t=a[i]%2,o=y[i-1]-'0';
        if(t==o) b[i]=1;
        else b[i]=0;
    }
    for(int i=1;i<=n;i++) {
        // cerr<<b[i]<<" \n"[i==n];
    }
    ll pre=0,ans=0;
    for(int i=1;i<=n;i++) {
        if((b[i]^pre)==1) continue;
        ll j=i;
        while(j<=n && (b[j]^pre)==0) j++;
        if(j-i>1) {
            ans++;
            pre^=1;
        }else ans++;
        i=j-1;
        // cerr<<j<<' '<<pre<<' ';
    }
    cout<<ans<<'\n';
}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ll t;cin>>t;
    while(t--) solve();
    return 0;
}