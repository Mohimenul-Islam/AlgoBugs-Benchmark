#include <bits/stdc++.h>
#define fir first
#define sec second
using namespace std;
typedef long long ll;

void solve() {
    string x,y;cin>>x>>y;
    ll n=x.size();
    vector<ll> a(n+1),b(n+1);
    for(int i=1;i<=n;i++) {
        a[i]=a[i-1];
        if(x[i-1]=='1') {
            a[i]++;
        }
    }
    for(int i=1;i<=n;i++) {
        ll t=a[i]%2,o=stoi(y.substr(i-1,1));
        if(t==o) b[i]=1;
        else b[i]=0;
    }
    ll m=n;
    for(int i=n;i>=1;i--) {
        m=i;
        if(b[i]==1) break;
    }
    ll m1=0,m2=0,cnt=1;
    for(int i=1;i<=m;i++) {
        bool ok=(i==m || b[i]!=b[i+1]);
        if(ok) {
            if(b[i]==0) {
                if(cnt>1) m2++;
                else m1++;
            }
            cnt=1;
        }else cnt++;
    }
    ll ans=m2*2+m1;
    if(m<n) ans++;
    cout<<ans<<'\n';

}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ll t;cin>>t;
    while(t--) solve();
    return 0;
}