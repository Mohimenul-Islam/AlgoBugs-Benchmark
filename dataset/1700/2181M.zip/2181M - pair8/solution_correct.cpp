#include <bits/stdc++.h>
using namespace std;
int main() {
  int t;
  cin >> t;
  while (t--) {
    string x, y;
    cin >> x;
    cin.ignore();
    cin >> y;
    int n = x.size();
    vector<int> a(n, 0), b(n, 0);
    for (int i = 0; i < n; i++) {
      if (x[i] == '1')
        a[i] = 1;
    }
    for (int i = 0; i < n; i++) {
      if (y[i] == '1')
        b[i] = 1;
    }
    vector<int> il(n);
    il[0] = a[0] == 1 ? 1 : 0;
    for (int i = 1; i < n; i++) {
      int g = (a[i] == 1) ? 1 : 0;
      il[i] = il[i - 1] + g;
    }
    for (int i = 0; i < n; i++) {
      il[i] = il[i] % 2;
    }
    vector<pair<int, int>> seg;
    int l = -1;
    for (int i = 0; i < n; i++) {
      if (b[i] != il[i]) {
        if (l == -1) {
          l = i;
        }
      } else {
        if (l != -1) {
          seg.push_back({l, i - 1});
          l = -1;
        }
      }
    }
    vector<int> c(n, 0);
    for (int i = 0; i < n; i++) {
      if (b[i] != il[i])
        c[i] = 1;
    }
    vector<int> e(n);
    e[0] = c[0];
    for (int i = 1; i < n; i++) {
      e[i] = c[i] ^ c[i - 1];
    }
    int ans = 0;
    for (int i = 0; i < n; i++) {
      if (e[i] == 1) {
        ans++;
        if (i + 1 < n && e[i + 1] == 1) {
          i++;
        }
      }
    }
    cout << ans << "\n";
  }
}