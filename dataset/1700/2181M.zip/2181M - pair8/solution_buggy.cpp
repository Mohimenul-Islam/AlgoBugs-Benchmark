#include <bits/stdc++.h>
using namespace std;
struct Node {
  long long val;
  Node() { val = 0; }
  Node(long long v) { val = v; }
};
struct SegTree {
  int n;
  vector<Node> tree;
  Node merge(Node a, Node b) {
    Node res;
    res.val = a.val + b.val;
    return res;
  }
  SegTree(int _n) {
    n = _n;
    tree.assign(4 * n, Node());
  }
  void build(const vector<int> &a, int node, int start, int end) {
    if (start == end) {
      tree[node] = Node(a[start]);
      return;
    }
    int mid = (start + end) / 2;
    build(a, 2 * node, start, mid);
    build(a, 2 * node + 1, mid + 1, end);
    tree[node] = merge(tree[2 * node], tree[2 * node + 1]);
  }
  void build(const vector<int> &a) { build(a, 1, 0, n - 1); }
  void update(int node, int start, int end, int idx, long long val) {
    if (start == end) {
      tree[node] = Node(val);
      return;
    }
    int mid = (start + end) / 2;
    if (idx <= mid) {
      update(2 * node, start, mid, idx, val);
    } else {
      update(2 * node + 1, mid + 1, end, idx, val);
    }
    tree[node] = merge(tree[2 * node], tree[2 * node + 1]);
  }
  void update(int idx, long long val) { update(1, 0, n - 1, idx, val); }
  Node query(int node, int start, int end, int l, int r) {
    if (r < start || end < l)
      return Node();
    if (l <= start && end <= r)
      return tree[node];
    int mid = (start + end) / 2;
    Node p1 = query(2 * node, start, mid, l, r);
    Node p2 = query(2 * node + 1, mid + 1, end, l, r);
    return merge(p1, p2);
  }
  long long query(int l, int r) { return query(1, 0, n - 1, l, r).val; }
};
int main() {
  int t;
  cin >> t;
  while (t--) {
    string x, y;
    cin >> x;
    cin.ignore();
    cin >> y;
    int n = x.size();
    vector<int> a(n, 0), b(n, 0);
    for (int i = 0; i < n; i++) {
      if (x[i] == '1')
        a[i] = 1;
    }
    for (int i = 0; i < n; i++) {
      if (y[i] == '1')
        b[i] = 1;
    }
    vector<int> il(n);
    il[0] = a[0] == 1 ? 1 : 0;
    for (int i = 1; i < n; i++) {
      int g = (a[i] == 1) ? 1 : 0;
      il[i] = il[i - 1] + g;
    }
    for (int i = 0; i < n; i++) {
      il[i] = il[i] % 2;
    }
    vector<pair<int, int>> seg;
    int l = -1;
    for (int i = 0; i < n; i++) {
      if (b[i] != il[i]) {
        if (l == -1) {
          l = i;
        }
      } else {
        if (l != -1) {
          seg.push_back({l, i - 1});
          l = -1;
        }
      }
    }
    vector<int> c(n, 0);
    for (int i = 0; i < n; i++) {
      if (b[i] != il[i])
        c[i] = 1;
    }
    int ans = 0;
    SegTree st(n);
    st.build(c);
    for (int i = 0; i < seg.size(); i++) {
      int l = seg[i].first;
      int r = seg[i].second;
      if (r - l + 1 > 2) {
        if ( r == n - 1)
          ans += 1;
        else
          ans += 2;
      } else
        ans += r - l + 1;
    }
    cout << ans << "\n";
  }
}