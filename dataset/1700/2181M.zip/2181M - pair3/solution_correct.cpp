#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <string>
#include <unordered_map>
#include <stack>
#include <map>
#include <queue>
#include <utility>
#include <numeric>
#include <set>
#include <iomanip>
#include <tuple>
#include <bitset>
using namespace std;

typedef long long int ll;
typedef long double lld;
// Flush the output after printing to ensure the judge receives your output immediately.
#define flush cout.flush()

#ifndef ONLINE_JUDGE
    #include <iostream>
    #include <vector>
    #include <string>
    #define debug(x) std::cerr << #x << " = "; _print(x); std::cerr << std::endl;
#else
    #define debug(x)
#endif

// Function to print a simple variable

void _print(int a){
    std::cerr<<a;
}
void _print(ll a){
    std::cerr<<a;
}
void _print(bool a){
    std::cerr<<a;
}
void _print(char a){
    std::cerr<<a;
}
void _print(double a){
    std::cerr<<a;
}
void _print(std::string a){
    std::cerr<<a;
}

template <typename T>
void _print(std::vector<T> v) {
    std::cerr<<"[ ";
    for(T i:v){
        _print(i);std::cerr<<" ";
    }
    std::cerr<<" ]";
}
template <typename T>
void _print(std::set<T> v) {
    std::cerr<<"[ ";
    for(T i:v){
        _print(i);std::cerr<<" ";
    }
    std::cerr<<" ]";
}
template <typename T, typename K>
void _print(const std::pair<T, K>& p) {
    std::cerr << "(";
    _print(p.first);
    std::cerr << ", ";
    _print(p.second);
    std::cerr << ")";
}
template <typename T,typename K>
void _print(std::unordered_map<T,K> &mp) {
    std::cerr<<"[ ";
    for(auto i:mp){
        _print(i.first);std::cerr<<" ";_print(i.second);
        std::cerr<<std::endl;
    }
    std::cerr<<" ]";
}
template <typename T,typename K>
void _print(std::vector<std::pair<T,K> >&v) {
    std::cerr<<"[ ";
    for(auto i:v){
        _print(i.first);std::cerr<<" ";_print(i.second);
        std::cerr<<std::endl;
    }
    std::cerr<<" ]";
}
template <typename T,typename K>
void _print(std::map<T,K> &mp) {
    std::cerr<<"[ ";
    for(auto i:mp){
        _print(i.first);std::cerr<<" ";_print(i.second);
        std::cerr<<std::endl;
    }
    std::cerr<<" ]";
}
template <typename T, typename K>
void _print(const std::unordered_map<T, std::unordered_map<K, T> >& mp) {
    std::cerr << "{ ";
    for (const auto& i : mp) {
        _print(i.first);  // Print key of outer map
        std::cerr << " : "; 
        _print(i.second);  // Print value of outer map (which is another map)
        std::cerr << " ";  // Add space between key-value pairs of outer map
    }
    std::cerr << "}";
}

#define CO(x) std::cout<<x<<std::endl;
#define COS(x) std::cout<<x<<" ";
#define fl(i,n) for( ll i=0;i<n;i++)
#define so(v) std::sort(begin(v),end(v));


bool cmp_first_asc_second_desc(const pair<int,int>& a,
                               const pair<int,int>& b) {
    if (a.first != b.first)
        return a.first < b.first;   // first ↑
    return a.second > b.second;     // second ↓
}
bool cmp_first_desc_second_desc(const pair<int,int>& a,
                                const pair<int,int>& b) {
    if (a.first != b.first)
        return a.first > b.first;   // first ↓
    return a.second > b.second;     // second ↓
}

ll gcd(ll a, ll b) {
    while (b != 0) {
        long long temp = b;
        b = a % b; // Get the remainder
        a = temp;  // Update a to b's previous value
    }
    return a; // When b is 0, a contains the GCD
}
vector<ll> fact(51,1);
void factorial(ll mod=998244353){
for(int i=1;i<=50;i++){
    fact[i] = (fact[i-1] * i) % mod;
}
}
ll power(ll a, ll b, ll mod) {
    ll res = 1;
    a %= mod;
    while (b > 0) {
        if (b & 1) res = res * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return res;
}
ll modInverse(ll a, ll mod) {
    // Fermat's little theorem only works if mod is prime
    return power(a, mod - 2, mod);
}
ll nCrmod(ll n, ll r, ll mod) {
    if (r > n) return 0;
    if (r > n - r) r = n - r;

    ll numerator = 1, denominator = 1;
    for (ll i = 0; i < r; ++i) {
        numerator = (numerator * (n - i)) % mod;
        denominator = (denominator * (i + 1)) % mod;
    }

    return (numerator * modInverse(denominator, mod)) % mod;
}

long long isum(long long x) {
    long long l = 0, r = 1e9, ans = 0;
    while (l <= r) {
        long long mid = (l + r) / 2;
        if (mid <= 2*x/ (mid+1)) {   // avoids overflow
            ans = mid;
            l = mid + 1;
        } else {
            r = mid - 1;
        }
    }
    return ans;
}

ll mex(set<ll> &st){
    int m=0;
    for(auto it:st){
        if(it==m) m++;
        else{break;}
    }
    return m;
}
void fun(vector<int> &v, set<int> &s){
    s.insert(0);
    if(v.empty()) return;
    ll mini=1;
    ll sum=0;
    int i=0;
    while(i<v.size()){
        if(sum+v[i]>=1){
            sum=0;
        }else{
            sum+=v[i];
        }
        mini=min(sum,mini);
        i++;
    }
    debug(mini);
    ll maxi=0;
    sum=0; i=0;
    while(i<v.size()){
        if(sum+v[i]<0){
            sum=0;
        }else{
            sum+=v[i];
        }
        maxi=max(sum,maxi);
        i++;
    }
    debug(mini);debug(maxi);
    for(ll i=mini;i<=maxi;i++){
        s.insert(i);
    }

}
void solve(int t, ll &x){
    
    /*if(t==10000-43){
        debug("here");
        
    }*/
    string s1,s2;
    cin>>s1>>s2;
    int n=s1.size();
    vector<int> dp1(n+1,0);
    vector<int> dp2(n+1,0);
    int xx=0;
    string s3="";
    string s4="";
    for(int i=0;i<n;i++){
        if(s1[i]=='1') xx++;
        
        s3.push_back((xx%2)+'0');
        s4.push_back(((xx%2)+1)%2+'0');
    }
    for(int i=n-1;i>=0;i--){
        if(s3[i]==s2[i]){
            dp1[i]=min(dp1[i+1],1+dp2[i+1]);
            dp2[i]=min(dp1[i+1]+1,1+dp2[i+1]);
            //update dp2[i] here
        }else{
            dp1[i]=min(dp1[i+1]+1,1+dp2[i+1]);
            dp2[i]=min(dp2[i+1],1+dp1[i+1]);
             //update dp2[i] here
        }
    }
    cout<<dp1[0]<<'\n';
    /*if(t==3369-149){
        cout<<n<<"*";
        fl(i,n){
        fl(j,n){
            cout<<v[i][j]<<"%";
            }
            cout<<"^^";
        }
        return;
        
    }*/
   //cout<<min((ll)n,mex+1)<<'\n';
    /*ll sum=0;
    for(int i=0;i<=99;i++){
        int y=i;
        while(y!=0){
            sum+=y%10;
            y/=10;
        }
    }
    debug(sum);
    sum=0;
    for(int i=0;i<=999;i++){
        int y=i;
        while(y!=0){
            sum+=y%10;
            y/=10;
        }
    }debug(sum);
    sum=0;
    for(int i=0;i<=9999;i++){
        int y=i;
        while(y!=0){
            sum+=y%10;
            y/=10;
        }
    }debug(sum);
    sum=0;
    for(int i=0;i<=99999;i++){
        int y=i;
        while(y!=0){
            sum+=y%10;
            y/=10;
        }
    }debug(sum);*/


}

int main(){
    //ll mod=1e9+7;
    std::ios::sync_with_stdio(false); // FAST IO
    std::cin.tie(nullptr); 
    #ifndef ONLINE_JUDGE
        freopen("Error.txt","w",stderr);
    #endif
    int t;
    //t=1;
    ll x=0;
    std::cin>>t;
    while(t--){
        
        solve(t,x);
        //if(t==10000-8686) break;
        
    }
    return 0;
}

