#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define ld long double
#define pii pair<int,int>
#define pb push_back
#define F first
#define S second


void solve() {
    string S, pS;
    cin >> S;
    cin >> pS;
    string P;
    int N = S.size();
    
    int cnt = 0;
    for(int i = 0; i < N; i++){
        if(S[i] == '1') cnt++;
        if(cnt%2 == (pS[i]-'0')) P[i] = 1;
        else P[i] = 0;
    }
    vector<int> F(N,0);
    F[N-1] = N;
    for(int i = N-2; i >= 0; i--){
        if(P[i] != P[i+1])  F[i] = i+1;
        else    F[i] = F[i+1];
    }

    vector<int> dp(N+1,0); // mins ops if we did not do anything to the string
    vector<int> dpf(N+1,0); // min ops if we did a full flip from i to end

    for(int i = N-1; i >= 0; i--){
        if(P[i] == 1) {
            // match
            dp[i] = dp[i+1];
            dpf[i] = min(dpf[i+1], dp[F[i]])+1;
        }else{
            // mismatch
            dp[i] = min(dp[i+1], dpf[F[i]])+1;
            dpf[i] = dpf[i+1];
        }
    }
    cout << dp[0] << endl;
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    int t; cin >> t;
    while(t--)
        solve();
    
}