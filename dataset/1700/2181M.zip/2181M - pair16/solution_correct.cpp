#include<bits/stdc++.h>
using namespace std;
#define ll long long 

int main() {
ll t;
cin>>t;

while(t--)
{
string x,y;
cin>>x>>y;
vector<ll> xa;
vector<ll> ya;
ll n = x.size();
vector<ll> ye(x.size(),0);
for(int i=0;i<n;i++) xa.push_back(int(x[i]) - int('0'));
for(int i=0;i<n;i++) ya.push_back(int(y[i]) - int('0'));
ll flag2 = 0;




for(int i=0;i<n;i++)
{
    if(x[i]=='1'){
        flag2++;
    }
    if(flag2%2==1){
ye[i] = 1;
    }
}



ll ans = 0;
ll flag = 0;
// flag 0 denotes aage wala will be not flipped
ll i = 0;
while(i<n){
    ll ye1,ye2;
if(i==n-1){
if(ye[n-1]!=ya[n-1] && flag==0){
    ans++;
}
if(ye[n-1]==ya[n-1] && flag==1){
    ans++;
}
break;
}
if(flag==0){
ye1 = ye[i];

ye2 = ye[i+1];

}
else{
    ye1 = 1 - ye[i];

    ye2 = 1 - ye[i+1];

}




if(ye1!=ya[i] && ye2!=ya[i+1])
{
    flag = 1 - flag;
ye[i] = ya[i];
ye[i+1] = ya[i+1];
    i = i+2;
    ans++;
}
else if(ye1==ya[i] && ye2!=ya[i+1]){
    i++;
}
else if(ye1!=ya[i] && ye2==ya[i+1]){
    ans++;
    ye[i] = ya[i];
ye[i+1] = ya[i+1];
    i = i+2;
}
else{
    i = i+ 2;
}

}

cout<<ans<<endl;










}}





