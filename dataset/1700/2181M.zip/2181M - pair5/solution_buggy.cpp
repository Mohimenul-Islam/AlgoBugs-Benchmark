#include <bits/stdc++.h>
using namespace std;
#define int long long
const int MOD = 998244353;
int32_t main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--)
    {
        string s1;
        cin >> s1;
        string s2;
        cin >> s2;
        int n = (int)s1.size();
        int t1 = 0;
        vector<int> arr1;
        vector<int> arr2;
        int cnt1 = 0;
        int id = 0;
        while (id < n)
        {
            cnt1 += (s1[id] == '1');
            if (cnt1 % 2)
            {
                if (s2[id] == '0')
                {
                    t1 = 1;
                    int cnt3 = 0;
                    cnt3++;
                    id++;
                    while (id < n)
                    {
                        cnt1 += (s1[id] == '1');
                        if (cnt1 % 2)
                        {
                            if (s2[id] == '0')
                                cnt3++;
                            else
                            {
                                cnt1 -= (s1[id] == '1');
                                break;
                            }
                        }
                        else
                        {
                            if (s2[id] == '1')
                                cnt3++;
                            else
                            {
                                cnt1 -= (s1[id] == '1');
                                break;
                            }
                        }
                        id++;
                    }
                    arr1.push_back(cnt3);
                }
                else
                {
                    if (t1)
                    {
                        int cnt3 = 0;
                        cnt3++;
                        id++;
                        while (id < n)
                        {
                            cnt1 += (s1[id] == '1');
                            if (cnt1 % 2)
                            {
                                if (s2[id] == '0')
                                {
                                    cnt1 -= (s1[id] == '1');
                                    break;
                                }
                                else
                                    cnt3++;
                            }
                            else
                            {
                                if (s2[id] == '1')
                                {
                                    cnt1 -= (s1[id] == '1');
                                    break;
                                }
                                else
                                    cnt3++;
                            }
                            id++;
                        }
                        arr2.push_back(cnt3);
                    }
                    else
                        id++;
                }
            }
            else
            {
                if (s2[id] == '1')
                {
                    t1 = 1;
                    int cnt3 = 0;
                    cnt3++;
                    id++;
                    while (id < n)
                    {
                        cnt1 += (s1[id] == '1');
                        if (cnt1 % 2)
                        {
                            if (s2[id] == '0')
                                cnt3++;
                            else
                            {
                                cnt1 -= (s1[id] == '1');
                                break;
                            }
                        }
                        else
                        {
                            if (s2[id] == '1')
                                cnt3++;
                            else
                            {
                                cnt1 -= (s1[id] == '1');
                                break;
                            }
                        }
                        id++;
                    }
                    arr1.push_back(cnt3);
                }
                else
                {
                    if (t1)
                    {
                        int cnt3 = 0;
                        cnt3++;
                        id++;
                        while (id < n)
                        {
                            cnt1 += (s1[id] == '1');
                            if (cnt1 % 2)
                            {
                                if (s2[id] == '0')
                                {
                                    cnt1 -= (s1[id] == '1');
                                    break;
                                }
                                else
                                    cnt3++;
                            }
                            else
                            {
                                if (s2[id] == '1')
                                {
                                    cnt1 -= (s1[id] == '1');
                                    break;
                                }
                                else
                                    cnt3++;
                            }
                            id++;
                        }
                        arr2.push_back(cnt3);
                    }
                    else
                        id++;
                }
            }
        }
        int sz1 = (int)arr1.size();
        int sz2 = (int)arr2.size();
        if (sz1 == 0)
            cout << "0" << endl;
        else
        {
            if (sz1 > sz2)
                arr2.push_back(0);
            // cout << sz1 << endl;
            vector<pair<int, int>> dp1(sz1);
            vector<pair<int, int>> dp2(sz1);
            dp1[0] = {min(arr1[0], 1LL + min(arr2[0], 1LL)), 0};
            dp2[0] = {1 + arr2[0], 1};
            // cout << arr1[0] << " " << arr1[1] << " " << arr2[0] << " " << arr2[1] << endl;
            for (int i = 1; i < sz1; i++)
            {
                if (dp1[i - 1].second % 2 == 1 && dp2[i - 1].second % 2 == 1)
                {
                    int val = min(dp1[i - 1].first + arr2[i], dp2[i - 1].first + arr2[i]);
                    dp1[i] = {val, 1};
                    val = min(dp1[i - 1].first + min(1LL, arr2[i]), dp2[i - 1].first + min(1LL, arr2[i]));
                    dp2[i] = {val, 2};
                }
                else if (dp1[i - 1].second % 2 == 1)
                {
                    if (dp1[i - 1].first + arr2[i] <= dp2[i - 1].first + min(arr1[i], 1LL + min(arr2[i], 1LL)))
                        dp1[i] = {dp1[i - 1].first + arr2[id], 1};
                    else
                        dp1[i] = {dp2[i - 1].first + min(arr1[i], 1LL + min(arr2[i], 1LL)), 2};
                    if (dp1[i - 1].first + min(1LL, arr2[i]) <= dp2[i - 1].first + 1 + arr2[i])
                        dp2[i] = {dp1[i - 1].first + min(1LL, arr2[i]), 2};
                    else
                        dp2[i] = {dp2[i - 1].first + 1 + arr2[i], 1};
                }
                else if (dp2[i - 1].second % 2 == 1)
                {
                    if (dp1[i - 1].first + min(arr1[i], 1LL + min(arr2[i], 1LL)) <= dp2[i - 1].first + arr2[i])
                        dp1[i] = {dp1[i - 1].first + min(arr1[i], 1LL + min(arr2[i], 1LL)), 2};
                    else
                        dp1[i] = {dp2[i - 1].first + arr2[i], 1};
                    if (dp2[i - 1].first + min(1LL, arr2[i]) <= dp1[i - 1].first + 1 + arr2[i])
                        dp2[i] = {dp2[i - 1].first + min(1LL, arr2[i]), 2};
                    else
                        dp2[i] = {dp1[i - 1].first + 1 + arr2[i], 1};
                }
                else
                {
                    int val = min(dp1[i - 1].first + min(arr1[i], 1LL + min(arr2[i], 1LL)), dp2[i - 1].first + min(arr1[i], 1LL + min(arr2[i], 1LL)));
                    dp1[i] = {val, 2};
                    val = min(dp1[i - 1].first + 1 + arr2[i], dp2[i - 1].first + 1 + arr2[i]);
                    dp2[i] = {val, 1};
                }
            }
            cout << min(dp1[sz1 - 1].first, dp2[sz1 - 1].first) << endl;
        }
    }
    return 0;
}