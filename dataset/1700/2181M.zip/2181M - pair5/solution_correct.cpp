#include <bits/stdc++.h>
using namespace std;
#define int long long
const int MOD = 998244353;
int32_t main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        string s1;
        cin >> s1;
        int n = (int)s.length();
        int id = -1;
        int cnt = 0;
        for (int i = 0; i < n; i++)
        {
            if (s[i] == '1')
            {
                cnt++;
                cnt %= 2;
            }
            if ((cnt == 1 && s1[i] == '0') || (cnt == 0 && s1[i] == '1'))
            {
                id = i;
                break;
            }
        }
        if (id == -1)
            cout << "0" << endl;
        else
        {
            vector<pair<int, int>> dp1(n);
            vector<pair<int, int>> dp2(n);
            dp1[id] = {1, (cnt + 1) % 2};
            dp2[id] = {1, cnt % 2};
            for (int i = id + 1; i < n; i++)
            {
                int val1 = dp1[i - 1].first;
                int val2 = dp2[i - 1].first;
                int val3 = (dp1[i - 1].second + (s[i] == '1')) % 2;
                int val4 = (dp2[i - 1].second + (s[i] == '1')) % 2;
                if ((val3 == 0 && s1[i] == '0') || (val3 == 1 && s1[i] == '1'))
                {
                    dp1[i] = {val1, val3};
                    dp2[i] = {val1, val3};
                }
                else
                {
                    dp1[i] = {val1 + 1, (val3 + 1) % 2};
                    dp2[i] = {val1 + 1, val3};
                }
                if ((val4 == 0 && s1[i] == '0') || (val4 == 1 && s1[i] == '1'))
                {
                    if (val2 < dp1[i].first)
                        dp1[i] = {val2, val4};
                    if (val2 < dp2[i].first)
                        dp2[i] = {val2, val4};
                }
                else
                {
                    if (val2 + 1 < dp1[i].first)
                        dp1[i] = {val2 + 1, (val4 + 1) % 2};
                    if (val2 + 1 < dp2[i].first)
                        dp2[i] = {val2 + 1, val4};
                }
            }
            cout << min(dp1[n - 1].first, dp2[n - 1].first) << endl;
        }
    }
    return 0;
}