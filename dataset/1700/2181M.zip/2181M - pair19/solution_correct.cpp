#include <bits/stdc++.h>
using namespace std;

#ifndef ONLINE_JUDGE
#include "Debug.h"
#else
#define debug(...)
#endif

#define int long long

int n;
string x , y;
vector<vector<int>> dp;

int rec(int level , int cur) {
    if (level == n) return 0;
    if (dp[level][cur] != -1) return dp[level][cur];
    
    int orig_cur = cur;

    int ans = 1e9;
    cur += (x[level] == '1');
    cur %= 2;

    if ((y[level] - '0') == cur) {
        ans = min(ans , rec(level + 1 , cur));
        ans = min(ans , 1 + rec(level + 1 , (cur + 1) % 2));
    }
    else {
        ans = min(ans , 1 + rec(level + 1 , cur));
        ans = min(ans , 1 + rec(level + 1 , (cur + 1) % 2));
    }

    return dp[level][orig_cur] = ans;
}

void solve() {
    cin >> x;
    cin >> y;

    n = x.size();
    dp.assign(n + 1 , vector<int> (2 , -1));
    cout << rec(0 , 0) << '\n';
}

int32_t main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}