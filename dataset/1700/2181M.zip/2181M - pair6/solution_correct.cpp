#include <bits/stdc++.h>
 
using namespace std;
 

void solve (){
   string x,y;
    cin>>x>>y;
    int n=x.size();
   int  dp[n][2];
   if(x[0]==y[0]){
    if(x[0]=='0'){
        dp[0][0]=0;
        dp[0][1]=2;
    }
    else{
       dp[0][0]=2;
        dp[0][1]=0; 
    }
   }
   else{
        dp[0][0]=1;
        dp[0][1]=1;
}
   
     for(int i=1;i<n;i++){
    if(x[i]==y[i]){
    if(x[i]=='0'){
        dp[i][0]=min(dp[i-1][0],dp[i-1][1]+1);
        dp[i][1]=min(dp[i-1][0]+2,dp[i-1][1]+1);
    }
    else{
        dp[i][0]=min(dp[i-1][0]+2,dp[i-1][1]+1);
        dp[i][1]=min(dp[i-1][0],dp[i-1][1]+1);
      
    }
   }
   else{
        if(x[i]=='1'){
        dp[i][0]=min(dp[i-1][0]+1,dp[i-1][1]);
        dp[i][1]=min(dp[i-1][0]+1,dp[i-1][1]+2);
        }
        else{
        dp[i][0]=min(dp[i-1][0]+1,dp[i-1][1]+2);
        dp[i][1]=min(dp[i-1][0]+1,dp[i-1][1]);
        }
}
     }

     cout<<min(dp[n-1][0],dp[n-1][1])<<"\n";
     


}

int main() {
 
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int t;
    cin >> t;

    while (t--) {
        solve();
    }

    return 0;
}