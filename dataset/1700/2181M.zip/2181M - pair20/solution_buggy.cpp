#include "bits/stdc++.h"
using namespace std;
typedef long long ll;
const ll N = 1e5+5;
const ll mod = 1e9+7;

/* FOR SEGMENT TREE (max based)
    needs to call presgt for initilization
    tree acces via sgt max length can be N
    updsgt to update val at index ind
    qrsgt to query the segment tree from ql to qr inclusive
*/
vector<ll> sgt(4*N);

void presgt(ll n){
    for(ll i=0;i<4*n+5;i++){
        sgt[i] = 0; // base condition
    }
}

void updsgt(ll rt, ll sl, ll sr, ll ind, ll val){
    if(sr<sl) return;
    if(sl==sr){
        sgt[rt] = val;
        return;
    }

    ll mid = (sl+sr)/2ll;
    if(ind<=mid) updsgt(2*rt+1,sl,mid,ind,val);
    else updsgt(2*rt+2,mid+1,sr,ind,val);
    sgt[rt] = max(sgt[2*rt+1], sgt[2*rt+2]);  // segment result here max
}

ll qrsgt(ll rt, ll sl, ll sr , ll ql, ll qr){
    if(sr<sl) return 0; // base condition
    if(qr<sl || ql>sr) return 0; // base condition;
    if(ql<=sl && qr>=sr) return sgt[rt];

    ll mid = (sl+sr)/2ll;
    return max(qrsgt(2*rt+1,sl,mid,ql,qr), qrsgt(2*rt+2,mid+1,sr,ql,qr));  // segment result here max
}

// SEGMENT TREE CODE END


/* DSU CODE START
    call predsu to initilize max capacity N
    pardsu to store parent and sizedsu to store size
*/

vector<ll> pardsu(N), sizedsu(N);

void predsu(ll n){
    for(ll i=0;i<n;i++){
        pardsu[i]=i;
        sizedsu[i]=1ll;
    }
}

ll findpardsu(ll a){
    if(pardsu[a]==a) return a;
    return pardsu[a] = findpardsu(pardsu[a]);
}

void uniondsu(ll a, ll b){
    a = findpardsu(a);
    b = findpardsu(b);
    if(a==b) return;
    if(sizedsu[a]<sizedsu[b]) swap(a,b);
    sizedsu[a]+=sizedsu[b];
    pardsu[b]=a;
}

// DSU CODE END


/* Seive
    For Storing Prime number till N
    called preprime for initilization
    prime store in vector PRIME
*/

vector<ll> prime;

void preprime(){
    vector<bool> temp(N,1);
    for(ll i=2;i<N;i++){
        if(!temp[i]) continue;
        for(ll j=i*i;j<N;j+=i){
            temp[j]=0;
        }
    }

    for(ll i=2;i<N;i++){
        if(temp[i]) prime.push_back(i);
    }
}


/* for storing divisors till N
    divisior store in vector vector<ll> divisors[N]
    must called predivisors to initilize
*/

vector<ll> divisors[N];

void predivisors(){
    for(ll i=1;i<N;i++){
        for(ll j=i;j<N;j+=i){
            divisors[j].push_back(i);
        }
    }
}

// SEIVE end

ll poww(ll a, ll p){
    ll ans = 1ll;
    while(p){
        if(p&1ll){
            ans*=a;
            ans%=mod;
        }
        p>>=1ll;
        a*=a;
        a%=mod;
    }
    return ans;
}

ll gcd(ll a,ll b) {
    while (b != 0) {
        a %= b;
        swap(a, b);
    }
    return a;
}

// -----------------------------------------------------------------------------
/*
N = global N
mod = global mod
segment tree:
    vector<ll> sgt for tree
    presgt(ll n) to initiliaze;
    updsgt(ll rt, ll sl, ll sr, ll ind, ll val) for update ind with value val
    qrsgt(ll rt, ll sl, ll sr , ll ql, ll qr) to get value from ql to qr inclusive

DSU 
    vector<ll>pardsu, vector<ll>sizedsu for parent and size
    predsu(ll n) to initialize
    findpardsu(ll a) for parent of a
    uniondsu(ll a, ll b) for union of a, b

SEIVE
    vector<ll>prime for primes
    preprime() to initiliaze;
    vector<ll>divisors[N] for divisors
    predivisors() to initilize

GCD call gcd(ll a, ll b)
Power call poww(ll a, ll p)
*/


ll fn(string &a, string &b, ll n){
    ll ans=0;
    for(ll i=0;i<n;i++){
        if(a[i]!=b[i])ans++;
    }
    return ans;
}

void solve(){
    string a, b;
    cin>>a>>b;
    ll n = a.length();
    string x, y;
    for(ll i=0;i<n;i++){
        char pr = '0';
        if(i>0) pr = b[i-1];
        if(b[i]==pr)x+='0';
        else x+='1';
    }
    vector<ll>cnt(n);
    for(ll i=0;i<n;i++){
        if(i>0) cnt[i] = cnt[i-1];
        cnt[i]+= a[i]-'0';
    }
    for(ll i=0;i<n;i++){
        y+= to_string((cnt[i]%2));
    }

    ll ans = min(fn(a,x,n),fn(b,y,n));
    // cout<<x<<" "<<fn(a,x,n)<<endl;
    // cout<<y<<" "<<fn(b,y,n)<<endl;

    cout<<ans<<endl;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    ll t;
    cin>>t;
    while(t--){
        solve();
    }
}