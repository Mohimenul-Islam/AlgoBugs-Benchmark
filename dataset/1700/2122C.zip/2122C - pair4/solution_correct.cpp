#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    ll t;
    cin >> t;
    while (t--){
        ll n;
        cin >> n;

        vector<pair<ll,ll>> arr(n);
        vector<pair<ll,ll>> brr(n);

        for(ll i =0; i<n; i++){
            cin >> arr[i].first;
            cin >> brr[i].first;

            arr[i].second = i;
            brr[i].second = i;
        }
        sort(arr.begin(), arr.end());
        sort(brr.begin(), brr.end());

        vector<ll> c(n);
        vector<ll> d(n);
        for(ll i = 0;i<n; i++){
            c[arr[i].second] = i;
            d[brr[i].second] = i;
        }

        vector<ll> t1, t2,t3,t4;
        for(ll i = 0; i<n; i++){
            // see where is the point i thik na
            if(c[i]<n/2 && d[i]<n/2){
                t3.push_back(i);
            }
            else if(c[i]<n/2 && d[i]>=n/2){
                t4.push_back(i);
            }else if(c[i]>=n/2 && d[i]>=n/2){
                t1.push_back(i);
            }else if(c[i]>=n/2 && d[i]<n/2){
                t2.push_back(i);
            }
        }
        for(ll i=0; i<t1.size(); i++){
            cout << t1[i]+1 << " "<< t3[i]+1<<endl;
        }
        for(ll i=0; i<t2.size(); i++){
            cout << t2[i]+1<< " "<< t4[i]+1 <<endl;
        }
        
        
    }
}