#include<bits/stdc++.h>
using namespace std;
#define int long long
#define all(x) (x).begin(),(x).end()
#define pb push_back
#define lower_bound lb
#define upper_bound ub
const int inf=1e18+9;
//const int mod=998244353;
const int mod=1e9+7;

 void solve(){
      int n;cin>>n;
      
      vector<int> x(n),y(n);
      for(int i=0;i<n;i++) {
        cin>>x[i]>>y[i];
      }
      vector<int> o(n),ord(n);
      for(int i=0;i<n;i++) o[i]=ord[i]=i;
      sort(o.begin(),o.end(),[&](int a,int b){
        if(y[a]!=y[b]) return x[a]<x[b];
        return y[a]<y[b];
      });
      sort(all(ord),[&](int a,int b){
        if(x[a]!=x[b]) return y[a]<y[b];
        return x[a]>x[b];
      });
      set<int> a,b,c,d;
      for(int i=0;i<n/2;i++){
        a.insert(o[i]);c.insert(ord[i]);
      }
      for(int i=n/2;i<n;i++){ b.insert(o[i]);d.insert(ord[i]);}

      vector<int> t1,t2,t3,t4;
      for(int i=0;i<n;i++){
        if(a.count(i)&&c.count(i)) t1.pb(i);
        if(a.count(i)&&d.count(i)) t2.pb(i);
        if(b.count(i)&&c.count(i)) t3.pb(i);
        if(b.count(i)&&d.count(i)) t4.pb(i);
      }
      int t1s=t1.size(),t2s=t2.size();
      for(int i=0;i<t1s;i++){
        cout<<t1[i]+1<<' '<<t4[i]+1<<'\n';
      }
      for(int i=0;i<t2s;i++){
        cout<<t2[i]+1<<' '<<t3[i]+1<<'\n';
      }
    
      
      
 }
  signed main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
      int t=1;  
      cin>>t;
      while(t--) solve();
      return 0;
  }