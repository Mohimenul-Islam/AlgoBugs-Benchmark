#include <iostream>
#include <bits/stdc++.h>
#define ll long long int
#define ld long double
using namespace std;

void solve(){
    int n;
    cin >> n;
    vector<pair<ll, ll>> points(n);
    vector<pair<ll, ll>> Y(n), X(n);
    for (int i = 0; i < n; ++i){
        ll x, y;
        cin >> x >> y;
        Y[i] = {y, i};
        X[i] = {x, i};
        points[i] = {x, y};
    }

    /*

        
        each x and y value contributes exactly once to the total sum

        |a - b|

        a and b are x values

        as hinted at by the editorial, lets look at the 1D case, where 
        there are n points along the X-axis 

        a < b < c < d < e < f 

        lets say a, b, c < 0

        for x E {a, b, c}, x gives a contribution of abs(x) if it is the 
        leftmost value in the pair

        for x E {d, e, f}, x gives a contribution of abs(x) if it is the
        rightmost value in the pair

        so an optimal pairing would be: 
            (a, d) (b, e) (c, f)

        

        but what if the number of negative values is less than the number of
        positive values in our 1D example?


        each negative value will contribute a positive amount,
        we pair these negative values with the largest positive values

        the remaining positive values that are not paired yet will 
        be paired now, lets say there are 2k remaining elements, then
        the smallest k will be paired with the largest k in this set


        A + 2K + A = N


        (A+K) + (A+K) = N

        A + K = N / 2

        we simply need to pair the smallest N/2 elements with the largest
        N / 2 elements, any pairing that satisfies this condition is valid


        now that we have the pairing for one dimension, 

        we can try to achieve the same pairing for the other dimension

        is it possible to achieve both a an optimal value for BOTH dimensions?


        let X(l) represent the set of points with smaller x values 
        let X(r) represent the set of points with larger x values

        let Y(l) represent the set of points with smaller y values
        let Y(r) represent the set of points with larger y values

        an optimal pair of points can either be:
        A: point, B: point

        the pair (A, B) satisfies one of the type conditions:
            { [ X(l) , Y(l) ]     [ X(r) , Y(r) ] }
            { [ X(l) , Y(r) ]     [ X(r) , Y(l) ] }

        here we are not considering (B, A) as that is only a duplicate

        now we need to see if all points in one category can 
        be paired with another point in its complement category        

        |X(l)| = |X(r)| = n/2

        |Y(l)| = |Y(r)| = n/2

        [X(l) n Y(l)] u [X(l) n Y(r)] =
        |X(l) n (Y(l) u Y(r))| = |X(l) n Y| = n/2

        since |X(l)| = n/2 and Y = X, 
        where Y and X both denote the set of all points

        similarly,
        
        X(r) n (Y(l) u Y(r)) = X(r) n Y = n/2


        if we label the 4 respective intersections a, b, c, d:
            
        a + c = n/2
        b + d = n/2

        

        similarly, using the distributivity set laws, we can also
        derive the result:

        a + d = n/2
        b + c = n/2

        since a+d = a+c, --> d = c
        and since c = d, a+c = b+d = b+c -> a = b

        therefore, we can obtain the max possible value accross both dimensions
        and come up with a possible pairing of points
    */
        


    sort(Y.begin(), Y.end());
    sort(X.begin(), X.end());

    vector<ll> A, B, C, D;

    for (int i = 0; i < n; ++i){
        auto [x, y] = points[i];

        if (x < X[n/2 - 1].first && y < Y[n/2 - 1].first){
            A.push_back(i);
            continue;
        }

        if (x > X[n/2 - 1].first && y > Y[n/2 - 1].first){
            B.push_back(i);
            continue;
        }

        bool low_y = true, low_x = true;
        if (x == X[n/2 - 1].first){
            if (i > X[n/2 - 1].second){
                low_x = false;
            }else{
                low_x = true;
            }
        }else low_x = x < X[n/2 - 1].first;  

        if (y == Y[n/2 - 1].first){
            if (i > Y[n/2 - 1].second){
                low_y = false;
            }else{
                low_y = true;
            }
        }else low_y = y < Y[n/2 - 1].first;


        if (low_x && low_y) A.push_back(i);
        else if (low_x) C.push_back(i);
        else if (low_y) D.push_back(i);
        else B.push_back(i);
    }
        

    for (int i = 0; i < (int) A.size(); ++i)
        cout << A[i]+1 << " " << B[i]+1 << '\n';

    for (int i = 0; i < (int) C.size(); ++i)
        cout << C[i]+1 << " " << D[i]+1 << '\n';
}


int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int tests = 1;
    cin >> tests;
    while (tests--) solve();
}
