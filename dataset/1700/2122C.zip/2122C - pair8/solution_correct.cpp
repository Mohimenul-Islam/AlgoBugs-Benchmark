#include <bits/stdc++.h>
using namespace std;

using i64 = long long;
bool comp(pair<pair<i64,i64>,i64>&a,pair<pair<i64,i64>,i64>&b)
{
    if(a.first.first<b.first.first)
    return true;
    return false;
}
bool comp1(pair<pair<i64,i64>,i64>&a,pair<pair<i64,i64>,i64>&b)
{
    if(a.first.second<b.first.second)
    return true;
    return false;
}
void solve() {
    int n;
    cin>>n;
    vector<pair<pair<i64,i64>,i64>>v,a,b;
    for(int i=0;i<n;i++)
    {
        i64 x,y;
        cin>>x>>y;
        v.push_back({{x,y},i});
    }
    sort(v.begin(),v.end(),comp);
    for(int i=0;i<n;i++)
    {
        if(i<n/2)
        a.push_back(v[i]);
        else
        b.push_back(v[i]);
    }
    sort(a.begin(),a.end(),comp1);
    sort(b.begin(),b.end(),comp1);
    reverse(b.begin(),b.end());
    int ans=0;
    for(int i=0;i<n/2;i++)
    cout<<a[i].second+1<<" "<<b[i].second+1<<"\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;

    while (t--)
        solve();

    return 0;
}