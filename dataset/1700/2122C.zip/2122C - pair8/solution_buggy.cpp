#include <bits/stdc++.h>
using namespace std;

using i64 = long long;

void solve() {
    int n;
    cin>>n;
    vector<pair<pair<i64,i64>,i64>>v;
    for(int i=0;i<n;i++)
    {
        i64 x,y;
        cin>>x>>y;
        v.push_back({{x,y},i});
    }
    sort(v.begin(),v.end());
    for(int i=0;i<n/2;i++)
    cout<<v[i].second+1<<" "<<v[i+n/2].second+1<<"\n";
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;

    while (t--)
        solve();

    return 0;
}