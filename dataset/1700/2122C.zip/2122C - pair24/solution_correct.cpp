#include <bits/stdc++.h>
#define ll long long
#define vll vector<ll>
using namespace std;

/* ============================= COMPETITIVE PROGRAMMING NOTES ============================= */
// Number Theory Essentials:
// 1. gcd(a,b) = gcd(b, a%b); Extended Euclid → ax+by=gcd(a,b).
// 2. Modular Inverse exists only if gcd(a,m)=1. Use Fermat’s little theorem if m is prime: a^(m-2) mod m.
// 3. Euler Totient φ(n): count of integers ≤n coprime to n.
// 4. Sieve of Eratosthenes → O(n log log n).
// 5. Lowest Prime Factor sieve helps factorize in O(log n).
// 6. Binomial Coefficients (nCr) require precomputed factorials + modular inverses.
// 7. Modular exponentiation (binpow) is essential for large powers.
// 8. Chinese Remainder Theorem (CRT) useful for solving x ≡ a1 mod m1, etc.
// 9. Prefix sum / prefix XOR often simplify subarray problems.
// 10. Digit DP, Subset DP, SOS DP are common in Codeforces DP problems.
// 11. Always check overflow → use 1LL * a * b % mod.
// 12. Probability problems often reduce to modular inverse of denominator.
/* ========================================================================================= */

// ---------------- Disjoint Set Union ----------------
class disjointset
{
    vll rank, parent, size;

public:
    disjointset(ll n)
    {
        rank.resize(n + 1, 0);
        parent.resize(n + 1);
        size.resize(n + 1, 1);
        for (ll j = 0; j <= n; j++)
            parent[j] = j;
    }
    ll findUParent(ll node)
    {
        if (parent[node] == node)
            return node;
        return parent[node] = findUParent(parent[node]);
    }
    void UnionByRank(ll u, ll v)
    {
        ll ulp_u = findUParent(u);
        ll ulp_v = findUParent(v);
        if (ulp_u == ulp_v)
            return;
        if (rank[ulp_u] > rank[ulp_v])
            parent[ulp_v] = ulp_u;
        else if (rank[ulp_v] > rank[ulp_u])
            parent[ulp_u] = ulp_v;
        else
        {
            parent[ulp_u] = ulp_v;
            rank[ulp_v]++;
        }
    }
    void UnionBySize(ll u, ll v)
    {
        ll ulp_u = findUParent(u);
        ll ulp_v = findUParent(v);
        if (ulp_u == ulp_v)
            return;
        if (size[ulp_u] > size[ulp_v])
        {
            parent[ulp_v] = ulp_u;
            size[ulp_u] += size[ulp_v];
        }
        else
        {
            parent[ulp_u] = ulp_v;
            size[ulp_v] += size[ulp_u];
        }
    }
};

// ---------------- Math & Number Theory ----------------
ll gcdll(ll a, ll b) { return (b == 0 ? a : gcdll(b, a % b)); }

ll extendedgcd(ll a, ll b, ll &x, ll &y)
{
    x = 1, y = 0;
    ll x1 = 0, y1 = 1, a1 = a, b1 = b;
    while (b1)
    {
        ll q = a1 / b1;
        tie(x, x1) = make_tuple(x1, x - q * x1);
        tie(y, y1) = make_tuple(y1, y - q * y1);
        tie(a1, b1) = make_tuple(b1, a1 - q * b1);
    }
    return a1;
}

// ---------------- Fast Exponentiation ----------------
ll binpow(ll a, ll b, ll m = LLONG_MAX)
{
    ll res = 1;
    while (b)
    {
        if (b & 1)
            res = (res * a) % m;
        a = (a * a) % m;
        b >>= 1;
    }
    return res;
}

// ---------------- Modular Arithmetic ----------------
const ll MOD = 1e9 + 7;
ll mod_add(ll a, ll b, ll m = MOD) { return ((a % m + b % m) % m + m) % m; }
ll mod_sub(ll a, ll b, ll m = MOD) { return ((a % m - b % m) % m + m) % m; }
ll mod_mul(ll a, ll b, ll m = MOD) { return (1LL * (a % m) * (b % m)) % m; }
ll mod_inv(ll a, ll m = MOD) { return binpow(a, m - 2, m); } // Fermat for prime m

// ---------------- Factorials & nCr ----------------
vll fac, invfac;
void factorial_precompute(ll n, ll m = MOD)
{
    fac.resize(n + 1);
    invfac.resize(n + 1);
    fac[0] = 1;
    for (ll i = 1; i <= n; i++)
        fac[i] = (fac[i - 1] * i) % m;
    invfac[n] = mod_inv(fac[n], m);
    for (ll i = n - 1; i >= 0; i--)
        invfac[i] = (invfac[i + 1] * (i + 1)) % m;
}
ll nCr(ll n, ll r, ll m = MOD)
{
    if (r < 0 || r > n)
        return 0;
    return fac[n] * invfac[r] % m * invfac[n - r] % m;
}

// ---------------- Prime Utilities ----------------
vector<bool> isprime;
void primecheck(ll n)
{
    isprime.assign(n + 1, true);
    isprime[0] = isprime[1] = false;
    for (ll i = 2; i * i <= n; i++)
        if (isprime[i])
            for (ll j = i * i; j <= n; j += i)
                isprime[j] = false;
}

vll sieve_eratosthenes(ll n)
{
    vector<bool> prime(n + 1, true);
    prime[0] = prime[1] = false;
    for (ll i = 2; i * i <= n; i++)
        if (prime[i])
            for (ll j = i * i; j <= n; j += i)
                prime[j] = false;
    vll primes;
    for (ll i = 2; i <= n; i++)
        if (prime[i])
            primes.push_back(i);
    return primes;
}

vll phi;
void totient_sieve(ll n)
{
    phi.resize(n + 1);
    for (ll i = 0; i <= n; i++)
        phi[i] = i;
    for (ll i = 2; i <= n; i++)
        if (phi[i] == i)
            for (ll j = i; j <= n; j += i)
                phi[j] -= phi[j] / i;
}

vll lpf;
void lpf_sieve(ll n)
{
    lpf.assign(n + 1, 0);
    for (ll i = 2; i <= n; i++)
        if (!lpf[i])
            for (ll j = i; j <= n; j += i)
                lpf[j] = i;
}
void pf(ll n)
{
    while (n > 1)
    {
        cout << lpf[n] << ' ';
        n /= lpf[n];
    }
    cout << '\n';
}

ll sqrtb(ll n)
{
    ll se = 0, en = n;
    while (se <= en)
    {
        ll me = se + (en - se) / 2;
        if (me * me <= n)
            se = me + 1;
        else
            en = me - 1;
    }
    return en;
}

//**************************RANGE QUERIES**********************
struct segtree
{
    vll seg;
    vll lazy;
    ll size;
    ll id;

    ll func(ll a, ll b)
    {
        return a + b;
    }

    void init(ll n)
    {
        size = 1;
        while (size < n)
        {
            size *= 2;
            /* code */
        }

        seg.assign(2 * size, 0);
        lazy.assign(2 * size, 0);
    }
    void buildseg(vll &a, ll v, ll tl, ll tr)
    {
        // First resize seg,lazy to 4*n and assign 0
        // seg[v] gives ans for [tl,tr] 0-indexed
        // Start : v=1,tl=0,tr=n-1
        if (tl == tr)
            seg[v] = a[tl];
        else
        {
            ll tm = (tl + tr) / 2;
            buildseg(a, v * 2, tl, tm);
            buildseg(a, v * 2 + 1, tm + 1, tr);
            seg[v] = func(seg[v * 2], seg[v * 2 + 1]); // change function here
        }
    }

    void push(ll v, ll tl, ll tr)
    {
        // Default : addition operation
        ll tm = (tl + tr) / 2;
        seg[2 * v] += (tm - tl + 1) * lazy[v];
        lazy[2 * v] += lazy[v];
        seg[2 * v + 1] += (tr - tm) * lazy[v];
        lazy[2 * v + 1] += lazy[v];
        lazy[v] = id; // change identity here
    }

    ll queryseg(ll v, ll tl, ll tr, ll l, ll r)
    {
        // Query for [l,r] 0-indexed
        // seg[v] gives ans for [tl,tr]
        // Start : v=1,tl=0,tr=n-1
        if (l > r)
            return id; // change identity here
        if (l == tl && r == tr)
            return seg[v];
        // push(v,tl,tr);
        ll tm = (tl + tr) / 2;
        return func(queryseg(v * 2, tl, tm, l, min(r, tm)), queryseg(v * 2 + 1, tm + 1, tr, max(l, tm + 1), r)); // change function here
    }

    void updateseg(ll v, ll tl, ll tr, ll pos, ll new_val)
    {
        // Update at index pos (0-indexed)
        // seg[v] gives ans for [tl,tr]
        // Start : v=1,tl=0,tr=n-1
        if (tl == tr)
            seg[v] = new_val;
        else
        {
            ll tm = (tl + tr) / 2;
            if (pos <= tm)
                updateseg(v * 2, tl, tm, pos, new_val);
            else
                updateseg(v * 2 + 1, tm + 1, tr, pos, new_val);
            seg[v] = func(seg[v * 2], seg[v * 2 + 1]); // change function here
        }
    }

    void upranseg(ll v, ll tl, ll tr, ll l, ll r, ll addend)
    {
        // Range Update for [l,r] 0-indexed
        // Default: addition update operation, sum query operation
        // seg[v] gives ans for [tl,tr]
        // Start : v=1,tl=0,tr=n-1
        if (l > r)
            return;
        if (l == tl && tr == r)
        {
            seg[v] += (tr - tl + 1) * addend; // change function here
            lazy[v] += addend;                // change function here
        }
        else
        {
            push(v, tl, tr);
            ll tm = (tl + tr) / 2;
            upranseg(v * 2, tl, tm, l, min(r, tm), addend);
            upranseg(v * 2 + 1, tm + 1, tr, max(l, tm + 1), r, addend);
            seg[v] = func(seg[v * 2], seg[v * 2 + 1]); // change function here
        }
    }
};
int main()
{
    // freopen("problemname.in", "r", stdin);
    //  freopen("problemname.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ll t;
    cin >> t;
    while (t--)
    {
        ll n;
        cin >> n;
        vector<pair<ll, pair<ll, ll>>> v, v2;
        for (ll j = 0; j < n; j++)
        {
            ll x, y;
            cin >> x >> y;
            v.push_back({x, {y, j}});
            v2.push_back({y, {x, j}});
        }
        sort(v.begin(), v.end());
        sort(v2.begin(), v2.end());

        ll in = n / 2;
        set<ll> s1, s2, s3, s4;
        for (ll j = 0; j < n / 2; j++)
        {
            s1.insert(v[j].second.second + 1);
            s2.insert(v[in].second.second + 1);
            s3.insert(v2[j].second.second + 1);
            s4.insert(v2[in].second.second + 1);

            in++;
        }
        set<ll> ma1, ma2;

        // case 1
        ma1.clear();
        ma2.clear();

        set_intersection(s1.begin(), s1.end(),
                         s3.begin(), s3.end(),
                         inserter(ma1, ma1.begin()));

        set_intersection(s4.begin(), s4.end(),
                         s2.begin(), s2.end(),
                         inserter(ma2, ma2.begin()));

        auto it = ma2.begin();
        for (ll c : ma1)
        {
            if (it == ma2.end())
                break;
            cout << c << " " << *it << endl;
            ++it;
        }

        // case 2
        ma1.clear();
        ma2.clear();

        set_intersection(s1.begin(), s1.end(),
                         s4.begin(), s4.end(),
                         inserter(ma1, ma1.begin()));

        set_intersection(s3.begin(), s3.end(),
                         s2.begin(), s2.end(),
                         inserter(ma2, ma2.begin()));

        it = ma2.begin();
        for (ll c : ma1)
        {
            if (it == ma2.end())
                break;
            cout << c << " " << *it << endl;
            ++it;
        }
    }
    return 0;
}