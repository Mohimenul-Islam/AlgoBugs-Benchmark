#include <bits/stdc++.h>
using namespace std;
#define vi vector<int>
#define vvi vector<vector<int>>

#define vl vector<ll>
#define vs vector<string>
#define ll long long
#define pb push_back
#define vvl vector<vector<ll>>
#define vpi vector<pair<int, int>>
#define vpl vector<pair<ll, ll>>
#define all(x) x.begin(), x.end()
#define mod 1000000007
#define gcd(a, b) __gcd(a, b)
#define lcm(a, b) ((a) / __gcd(a, b) * (b))
class DSU
{
public:
    vector<int> p, s;

    DSU(int n)
    {
        p.resize(n);
        s.assign(n, 1);
        iota(p.begin(), p.end(), 0);
    }

    int find(int x)
    {
        return p[x] == x ? x : p[x] = find(p[x]);
    }

    bool unite(int a, int b)
    {
        a = find(a);
        b = find(b);
        if (a == b)
            return false;
        if (s[a] < s[b])
            swap(a, b);
        p[b] = a;
        s[a] += s[b];
        return true;
    }
};
const ll MOD = 998244353;

vector<ll> fact, invfact;

ll modpow(ll a, ll e)
{
    ll r = 1 % MOD;
    a %= MOD;
    while (e > 0)
    {
        if (e & 1)
            r = (r * a) % MOD;
        a = (a * a) % MOD;
        e >>= 1;
    }
    return r;
}

void init_nCr(int MAXN)
{
    fact.assign(MAXN + 1, 1);
    invfact.assign(MAXN + 1, 1);

    for (int i = 1; i <= MAXN; i++)
        fact[i] = (fact[i - 1] * i) % MOD;

    invfact[MAXN] = modpow(fact[MAXN], MOD - 2);
    for (int i = MAXN; i >= 1; i--)
        invfact[i - 1] = (invfact[i] * i) % MOD;
}

ll nCr(ll n, ll r)
{
    if (r < 0 || r > n)
        return 0;
    return fact[n] * invfact[r] % MOD * invfact[n - r] % MOD;
}
void solve()
{
int n;
cin>>n;
vvi v;
for(int i=0;i<n;i++){
    int e1,e2;
    cin>>e1>>e2;
    v.pb({e1,e2,i+1});
}
sort(all(v),[](vi &a,vi &b){
    if(a[0]==b[0]){
        return a[1] <b[1];
    }
    return a[0]<b[0];
});
vvi temp1,temp2;
for(int i=0;i<(n/2);i++){
    temp1.pb(v[i]);
}
for(int i=(n/2);i<n;i++){
    temp2.pb(v[i]);
}
sort(all(temp1),[](vi &a,vi &b){
if(a[1]==b[1]){
    return a[0]<b[0];
}
return a[1]<b[1];
});
sort(all(temp2),[](vi &a,vi &b){
if(a[1]==b[1]){
    return a[0]<b[0];
}
return a[1]<b[1];
});
int j=(n/2)-1;
vvi ans;
for(int i=0;i<(n/2);i++){
ans.pb({temp1[i][2],temp2[j][2]});
j--;
}
for(int i=0;i<ans.size();i++){
    cout<<ans[i][0]<<" "<<ans[i][1]<<endl;
}

return ;
}

    int main()
    {
        int t;
        cin >> t;
        init_nCr(70);
        while (t--)
        {
            solve();
        }
        return 0;
    }
