#include <bits/stdc++.h>
using namespace std;
#define vi vector<int>
#define vvi vector<vector<int>>

#define vl vector<ll>
#define vs vector<string>
#define ll long long
#define pb push_back
#define vvl vector<vector<ll>>
#define vpi vector<pair<int, int>>
#define vpl vector<pair<ll, ll>>
#define all(x) x.begin(), x.end()
#define mod 1000000007
#define gcd(a, b) __gcd(a, b)
#define lcm(a, b) ((a) / __gcd(a, b) * (b))
class DSU
{
public:
    vector<int> p, s;

    DSU(int n)
    {
        p.resize(n);
        s.assign(n, 1);
        iota(p.begin(), p.end(), 0);
    }

    int find(int x)
    {
        return p[x] == x ? x : p[x] = find(p[x]);
    }

    bool unite(int a, int b)
    {
        a = find(a);
        b = find(b);
        if (a == b)
            return false;
        if (s[a] < s[b])
            swap(a, b);
        p[b] = a;
        s[a] += s[b];
        return true;
    }
};
const ll MOD = 998244353;

vector<ll> fact, invfact;

ll modpow(ll a, ll e)
{
    ll r = 1 % MOD;
    a %= MOD;
    while (e > 0)
    {
        if (e & 1)
            r = (r * a) % MOD;
        a = (a * a) % MOD;
        e >>= 1;
    }
    return r;
}

void init_nCr(int MAXN)
{
    fact.assign(MAXN + 1, 1);
    invfact.assign(MAXN + 1, 1);

    for (int i = 1; i <= MAXN; i++)
        fact[i] = (fact[i - 1] * i) % MOD;

    invfact[MAXN] = modpow(fact[MAXN], MOD - 2);
    for (int i = MAXN; i >= 1; i--)
        invfact[i - 1] = (invfact[i] * i) % MOD;
}

ll nCr(ll n, ll r)
{
    if (r < 0 || r > n)
        return 0;
    return fact[n] * invfact[r] % MOD * invfact[n - r] % MOD;
}
void solve()
{
int n;
cin>>n;
vector<vector<int>> v;

for(int i=0;i<n;i++){
    int e1,e2;
    cin>>e1>>e2;
    v.pb({e1,e2,i+1});
}
vector<vi> v1=v;
vector<vi> v2=v;
sort(all(v1),[](vi &a,vi  &b){
    if(a[0]==b[0]){
        return a[1]<b[1];
    }
    return a[0]<b[0];
});
sort(all(v2),[](vi &a,vi &b){
    if(a[1]==b[1]){
        return a[0]<b[0];
    }
    return a[1]<b[1];
});
ll t1=0;
int i=0;
int j=(n/2);
vpi ans1,ans2;
while(j<n){
    t1+=abs(v1[i][0]-v1[j][0]) + abs(v1[i][1]-v1[j][1]);
    ans1.pb({v1[i][2],v1[j][2]});
    i++,j++;
}
ll t2=0;
i=0;
j=(n/2);

while(j<n){
    t2+=abs(v2[i][0]-v2[j][0]) + abs(v2[i][1]-v2[j][1]);
    ans2.pb({v2[i][2],v2[j][2]});
    i++;
    j++;
}
if(t1>=t2){
    for(auto j: ans1){
        cout<<j.first<<" "<<j.second<<endl;
    }
}
else{
      for(auto j: ans2){
        cout<<j.first<<" "<<j.second<<endl;
    }
}
}

    int main()
    {
        int t;
        cin >> t;
        init_nCr(70);
        while (t--)
        {
            solve();
        }
        return 0;
    }
