#include "bits/stdc++.h"

#define LL               long long
#define all(a)           a.begin(),a.end()
#define rall(a)          a.rbegin(),a.rend()
#define cy               cout<<"YES\n";
#define cn               cout<<"NO\n";
#define fast             ios::sync_with_stdio(NULL); cin.tie(0); cout.tie(0);

using namespace std;
                    //FUNCTION..

const LL N=3e5+7, mod=1e9+7, oo=0x3f3f3f3f3f3f3f3f;
const long double pi = acos(-1), eps=1e-9 ;


LL n,m,i,j,x,y,z,l,r,q,p,k,f,d;
LL ar[N] ;

void SOLVE(){
    cin >> n;
    vector<pair<pair<int,int>,int>> v,v2;
    for(int i=0;i<n;i++){
        cin >> x >>y;
        v.push_back({{x,y},i+1});
        v2.push_back({{y,x},i+1});
    }
    sort(all(v));
    sort(all(v2));
    LL sm = 0;
    for(int i=0;i<n/2;i++){
        sm += abs(v[i].first.first - v[i+n/2].first.first) + abs(v[i].first.second - v[i+n/2].first.second);
    }
    LL sm2 = 0;
    for(int i=0;i<n/2;i++){
        sm2 += abs(v2[i].first.first - v2[i+n/2].first.first) + abs(v2[i].first.second - v2[i+n/2].first.second);
    }

    for(int i=0;i<n/2;i++){
        if(sm>=sm2)
        cout << v[i].second <<' '<< v[i+n/2].second << endl;
        else
        cout << v2[i].second <<' '<< v2[i+n/2].second << endl;
    }
}


                    //MAINING..
signed main(){
//    freopen("input.txt","r",stdin) ;
//    freopen("output.txt","w",stdout);
    fast
    int T=1;
    cin>>T;
    while(T--)SOLVE();

    return 0;
}
