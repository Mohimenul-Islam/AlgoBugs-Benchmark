#include "bits/stdc++.h"

#define LL               long long
#define all(a)           a.begin(),a.end()
#define rall(a)          a.rbegin(),a.rend()
#define cy               cout<<"YES\n";
#define cn               cout<<"NO\n";
#define fast             ios::sync_with_stdio(NULL); cin.tie(0); cout.tie(0);

using namespace std;
                    //FUNCTION..

const LL N=3e5+7, mod=1e9+7, oo=0x3f3f3f3f3f3f3f3f;
const long double pi = acos(-1), eps=1e-9 ;


LL n,m,i,j,x,y,z,l,r,q,p,k,f,d;
LL ar[N] ;

bool comp(pair<pair<int,int>,int> &a,pair<pair<int,int>,int>&b){
    return (a.first.second <= b.first.second);
}

void SOLVE(){
    cin >> n;
    vector<tuple<int,int,int>> v;
    for(int i=0;i<n;i++){
        cin >> x >>y;
        v.push_back({x,y,i});
    }
    sort(all(v));

    vector<tuple<int,int,int>> one,two;
    for(int i=0;i<n/2;i++){
        auto [x,y,id] = v[i];
        auto [x1,y1,id1] = v[i+n/2];

        one.push_back({y,x,id});
        two.push_back({y1,x1,id1});
    }
    sort(all(one));
    sort(all(two));
    reverse(all(two));

    for(int i=0;i<n/2;i++){
        cout << get<2>(one[i]) + 1 <<' '<< get<2>(two[i]) + 1 << endl;
    }
}


                    //MAINING..
signed main(){
//    freopen("input.txt","r",stdin) ;
//    freopen("output.txt","w",stdout);
    fast
    int T=1;
    cin>>T;
    while(T--)SOLVE();

    return 0;
}
