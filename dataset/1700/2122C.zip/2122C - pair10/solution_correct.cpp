#include <bits/stdc++.h>
#define mygo main
using namespace std;
using ll=long long;
const int INF=0x3f3f3f3f;       
const ll INF_LL=0x3f3f3f3f3f3f3f3f;
const int Soyo=2e5+5;
const ll MOD=1e9+7;
ll fact[Soyo];    
ll invFact[Soyo]; 
ll mod(ll x,ll m){
    ll res = x % m;
    if (res < 0) res += m;
    return res;
}
ll qpow(ll base, ll exp) {
    ll res = 1;
    while (exp > 0) {
        if (exp % 2 == 1) res = res * base;
        base = base * base;
        exp /= 2;
    }
    return res;
}
ll qpow_mod(ll base,ll exp,ll m){
    ll res=1;
    base%=m;
    while(exp>0) {
        if(exp%2==1)res=(res*base)%m;
        base=(base*base)%m;
        exp/=2;
    }
    return res;
}
ll inv(ll x,ll m){
    return qpow_mod(x,m-2,m);
}
// 初始化函数：传入最大范围 n 
void saki_saki(int n) {
    fact[0] = 1;
    for (int i = 1; i <= n; i++) {
        fact[i] = (fact[i - 1] * i) % MOD;
    }
    invFact[n] = inv(fact[n], MOD);
    for (int i = n - 1; i >= 0; i--) {
        invFact[i] = (invFact[i + 1] * (i + 1)) % MOD;
    }
}

// 组合数 C(n, k)
ll C(int n, int k) {
    if (k < 0 || k > n) return 0;
    return fact[n] * invFact[k] % MOD * invFact[n - k] % MOD;
}

// 排列数 A(n, k) 或 P(n, k)
ll P(int n, int k) {
    if (k < 0 || k > n) return 0;
    return fact[n] * invFact[n - k] % MOD;
}
void Crychic(){
    ll n;
    cin>>n;
    vector<tuple<ll,ll,ll>> a(n);
    for(int i=0;i<n;i++){
        auto& [x,y,id]=a[i];
        cin>>x>>y;
        id=i+1;
    }
    sort(a.begin(),a.end());
    //auto& [x1,y1,id1]=a[n/2-1];
    //auto& [x2,y2,id2]=a[n/2];
    //double mid=(x1+x2)/2;
    unordered_set<ll> z;
    for(int i=0;i<n;i++){
        auto& [x,y,id]=a[i];
        //if(i<=n/2-1)continue;
        //else z.insert(id);
        if(i>n/2-1)z.insert(id);
        swap(x,y);
    }
    sort(a.begin(),a.end());
    vector<ll> fir,sec,thi,fou;
    for(int i=0;i<n;i++){
        auto& [y,x,id]=a[i];
        if(i<=n/2-1){
            if(z.count(id))fou.push_back(id);
            else thi.push_back(id);
        }else{
            if(z.count(id))fir.push_back(id);
            else sec.push_back(id);
        }
    }
    for(int i=0;i<fir.size();i++){
        cout<<fir[i]<<" "<<thi[i]<<'\n';
    }
    for(int i=0;i<sec.size();i++){
        cout<<sec[i]<<" "<<fou[i]<<'\n';
    }
}
int mygo(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    //saki_saki(Soyo-1);
    int t=1;
    cin>>t;
    while(t--){
        Crychic();
    }
    return 0;
}