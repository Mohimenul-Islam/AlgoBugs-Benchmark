#include <bits/stdc++.h>
using namespace std;
void solve(){
    int n;
    cin>>n;
    vector<int>x(n),y(n);
    vector<tuple<int,int>>vv(n);
    for (int i=0;i<n;i++){
    cin>>x[i]>>y[i];
    get<0>(vv[i])=x[i];get<1>(vv[i])=y[i];
    }
    sort(x.begin(),x.end());
    sort(y.begin(),y.end());
    int x_cnt=n/2-(lower_bound(x.begin(),x.end(),x[n/2-1])-x.begin()),y_cnt=n/2-(lower_bound(y.begin(),y.end(),y[n/2-1])-y.begin()),y_serhed=y[n/2-1],x_serhed=x[n/2-1];
  //  cout<<endl<<x_serhed<<' '<<y_serhed<<endl;
  //  for (int i=0;i<n;i++)cout<<x[i]<<' ';cout<<endl;
    vector<int>tt,yy,ty,yt;
    for (int i=0;i<n;i++){
        int x_i=get<0>(vv[i]),y_i=get<1>(vv[i]);
        bool first,second;
        if (x_i<x_serhed){
            first=false;

        }
        else if(x_i>x_serhed){
            first=true;
        }
        else{
            if (x_cnt>0){
                first=false;
                x_cnt--;

            }
            else{
                first=true;
            }
        }
        if (y_i<y_serhed){
            second=false;

        }
        else if(y_i>y_serhed){
            second=true;
        }
        else{
            if (y_cnt>0){
                second=false;
                y_cnt--;
                }
                else{
                    second=true;
                }
        }
       // cout<<first<<' '<<second<<endl;
        if (second==false and first==false){
            tt.push_back(i);
        }
        else if(second==true and first==true){
            yy.push_back(i);
        }
        else if(second==true and first==false){
            ty.push_back(i);
        }
        else{
            yt.push_back(i);
        }
        }
        //cout<<ty.size()<<' '<<yt.size()<<endl;
        //cout<<yy.size()<<' '<<tt.size()<<endl;
        for (int i=0;i<tt.size();i++){
            cout<<tt[i]+1<<' '<<yy[i]+1<<endl;
        }
        for (int i=0;i<yt.size();i++){
            cout<<yt[i]+1<<' '<<ty[i]+1<<endl;
        }



}
int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int t;
    cin>>t;
    for (int i=0;i<t;i++){
        solve();

    }

}
