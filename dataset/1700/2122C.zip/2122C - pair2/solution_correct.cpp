#include<bits/stdc++.h>
using namespace std;
//#include<ext/pb_ds/assoc_container.hpp>
//#include<ext/pb_ds/tree_policy.hpp>
//using namespace __gnu_pbds;
// template <typename T>
//using order_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
#define FIO ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0)
#define FOR(i,n) for(int i=0;i<n;i++)
#define eFOR(n) for(int i=1;i<=n;i++)
#define _FOR(n) for(int i=n-1;i>=0;i--)
#define Sort(s) sort(s.begin(),s.end())
#define GSort(s) sort(s.rbegin(),s.rend())
#define Reverse(s) reverse(s.begin(),s.end())
#define Find(v,x) find(v.begin(),v.end(),x)-v.begin()
#define fi first
#define se second
#define pb push_back
#define eb emplace_back
#define endl "\n";
#define Count(v,x) count(v.begin(),v.end(),x)
#define setBits(x) __builtin_popcountll(x)
#define leadingZeros(x) __builtin_ctzll(x)
#define mod 1000000007
#define inf 1e18
#define ps(x,y) fixed<<setprecision(y)<<x


const int N = 2e7+10;


typedef int64_t lli;
typedef long double lld;
typedef vector<int> vi;
typedef vector<lli> vli;
typedef map<int,int> mpi;
typedef map<lli,lli> mpl;


void solve(){
    lli n;
    cin>>n;
    vli x(n),y(n);
    FOR(i,n){
        cin>>x[i]>>y[i];
    }
    vli order(n);
    iota(order.begin(),order.end(),0);
    sort(order.begin(),order.end(),[&](lli i,lli j){
        return x[i]<x[j];
    });
    sort(order.begin(),order.begin()+n/2,[&](lli i,lli j){
        return y[i]<y[j];
    });
    sort(order.begin()+n/2,order.end(),[&](lli i,lli j){
        return y[i]<y[j];
    });
    for(int i=0;i<n/2;i++){
        cout<<order[i]+1<<" "<<order[n-1-i]+1<<endl
    }
}
int main()
{
FIO;
    int t=1;
    cin>>t;
    //for (int i = 2; i <= N; i++){if (!pfac[i].empty())continue;for (int j = i; j <= N; j += i)pfac[j].push_back(i);}
    while(t--){
       solve();
    }
    return 0;
}