#include<bits/stdc++.h>
using namespace std;
#define FIO ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0)
#define FOR(i,n) for(int i=0;i<n;i++)
#define eFOR(n) for(int i=1;i<=n;i++)
#define _FOR(n) for(int i=n-1;i>=0;i--)
#define Sort(s) sort(s.begin(),s.end())
#define GSort(s) sort(s.rbegin(),s.rend())
#define Reverse(s) reverse(s.begin(),s.end())
#define Find(v,x) find(v.begin(),v.end(),x)-v.begin()
#define fi first
#define se second
#define pb push_back
#define eb emplace_back
#define endl "\n";
#define Count(v,x) count(v.begin(),v.end(),x)
#define setBits(x) __builtin_popcountll(x)
#define leadingZeros(x) __builtin_ctzll(x)
#define mod 1000000007
#define inf 1e18
#define ps(x,y) fixed<<setprecision(y)<<x


const int N = 2e7+10;


typedef int64_t lli;
typedef long double lld;
typedef vector<int> vi;
typedef vector<lli> vli;
typedef map<int,int> mpi;
typedef map<lli,lli> mpl;

bool cmp(pair<pair<lli,lli>,lli >pa1,pair<pair<lli,lli>,lli >pa2){
    return max(abs(pa1.fi.fi),abs(pa1.fi.se))<=max(abs(pa2.fi.fi),abs(pa2.fi.se));
    // if(pa1.fi.se!=pa2.fi.se){
    //     return pa1.fi.se<=pa2.fi.se;
    // }
    // else if(pa1.fi.fi!=pa2.fi.fi){
    //     return pa1.fi.fi<=pa2.fi.fi;
    // }
    // else return pa1.se<=pa2.se;
    // return abs(pa1.fi.fi)+abs(pa1.fi.se)<=abs(pa2.fi.fi)+abs(pa2.fi.se);
}
void solve(){
    lli n;
    cin>>n;
    vector<pair<pair<lli,lli>,lli > >pa(n);
    FOR(i,n){
        cin>>pa[i].fi.fi>>pa[i].fi.se;
        pa[i].se=i;
    }
    vector<pair<lli,lli> >cnt;
    lli cnt1=0,cnt2=0,cnt3=0,cnt4=0;
    vector<pair<lli,lli> >pas1,pas2,pas3,pas4;
    sort(pa.begin(),pa.end());
    {
        for(int i=0;i<n/2;i++){
            pas1.pb(make_pair((pa[i].se+1),(pa[i+n/2].se+1)));
            cnt1+=abs(pa[i].fi.fi-pa[i+n/2].fi.fi)+abs(pa[i].fi.se-pa[i+n/2].fi.se);
        }
        cnt.pb(make_pair(cnt1,1));
    }
    {

        lli l=0,r=n-1;
        while(l<=r){
            pas2.pb(make_pair((pa[l].se+1),(pa[r].se+1)));
            // cout<<pa[l].se+1<<" "<<pa[r].se+1<<endl
            cnt2+=abs(pa[l].fi.fi-pa[r].fi.fi)+abs(pa[l].fi.se-pa[r].fi.se);
            l++;
            r--;
        }
        cnt.pb(make_pair(cnt2,2));
    }
    sort(pa.begin(),pa.end(),cmp);
    {
        for(int i=0;i<n/2;i++){
            pas3.pb(make_pair((pa[i].se+1),(pa[i+n/2].se+1)));
            cnt3+=abs(pa[i].fi.fi-pa[i+n/2].fi.fi)+abs(pa[i].fi.se-pa[i+n/2].fi.se);
        }
        cnt.pb(make_pair(cnt3,3));
    }
    {

        lli l=0,r=n-1;
        while(l<=r){
            pas4.pb(make_pair((pa[l].se+1),(pa[r].se+1)));
            // cout<<pa[l].se+1<<" "<<pa[r].se+1<<endl
            cnt4+=abs(pa[l].fi.fi-pa[r].fi.fi)+abs(pa[l].fi.se-pa[r].fi.se);

            l++;
            r--;
        }
        cnt.pb(make_pair(cnt4,4));
    }
    Sort(cnt);
    // cout<<cnt1<<" "<<cnt2<<endl
    lli pos=cnt[cnt.size()-1].se;
    // cout<<pos<<endl
    if(pos==1){
        FOR(i,pas1.size()){
            cout<<pas1[i].fi<<" "<<pas1[i].se<<endl
        }
    }
    else if(pos==2){
        FOR(i,pas2.size()){
            cout<<pas2[i].fi<<" "<<pas2[i].se<<endl
        }
    }
    else if(pos==3){
        FOR(i,pas3.size()){
            cout<<pas3[i].fi<<" "<<pas3[i].se<<endl
        }
    }
    else{
        FOR(i,pas4.size()){
            cout<<pas4[i].fi<<" "<<pas4[i].se<<endl
        }
    }
}
int main()
{
FIO;
    int t=1;
    cin>>t;
    //for (int i = 2; i <= N; i++){if (!pfac[i].empty())continue;for (int j = i; j <= N; j += i)pfac[j].push_back(i);}
    while(t--){
       solve();
    }
    return 0;
}