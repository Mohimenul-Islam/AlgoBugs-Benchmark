#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Point {
    int id;
    int x, y;
    int c, d; // To store the assigned signs for X and Y
};

void solve() {
    int n;
    cin >> n;
    vector<Point> pts(n);
    for (int i = 0; i < n; i++) {
        cin >> pts[i].x >> pts[i].y;
        pts[i].id = i + 1; // 1-based index
    }

    // 1. Sort and assign signs based on X-coordinates
    vector<int> idxX(n);
    for (int i = 0; i < n; i++) idxX[i] = i;
    sort(idxX.begin(), idxX.end(), [&](int i, int j) {
        return pts[i].x < pts[j].x;
    });
    
    for (int i = 0; i < n / 2; i++) pts[idxX[i]].c = -1;
    for (int i = n / 2; i < n; i++) pts[idxX[i]].c = 1;

    // 2. Sort and assign signs based on Y-coordinates
    vector<int> idxY(n);
    for (int i = 0; i < n; i++) idxY[i] = i;
    sort(idxY.begin(), idxY.end(), [&](int i, int j) {
        return pts[i].y < pts[j].y;
    });
    
    for (int i = 0; i < n / 2; i++) pts[idxY[i]].d = -1;
    for (int i = n / 2; i < n; i++) pts[idxY[i]].d = 1;

    // 3. Bucket the points based on their (c, d) signs
    vector<int> pp, mm, pm, mp;
    for (int i = 0; i < n; i++) {
        if (pts[i].c == 1 && pts[i].d == 1) pp.push_back(pts[i].id);
        else if (pts[i].c == -1 && pts[i].d == -1) mm.push_back(pts[i].id);
        else if (pts[i].c == 1 && pts[i].d == -1) pm.push_back(pts[i].id);
        else if (pts[i].c == -1 && pts[i].d == 1) mp.push_back(pts[i].id);
    }

    // 4. Pair matching buckets perfectly
    for (size_t i = 0; i < pp.size(); i++) {
        cout << pp[i] << " " << mm[i] << "\n";
    }
    for (size_t i = 0; i < pm.size(); i++) {
        cout << pm[i] << " " << mp[i] << "\n";
    }
}

int main() {
    // Fast I/O
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int t;
    if (cin >> t) {
        while (t--) {
            solve();
        }
    }
    return 0;
}