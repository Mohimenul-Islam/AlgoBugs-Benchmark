#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Point {
    int x, y, id;
};

bool comparePoints(const Point& a, const Point& b) {
    if (a.x != b.x) return a.x < b.x;
    return a.y < b.y;
}

void solve() {
    int n;
    if (!(cin >> n)) return;

    vector<Point> points(n);
    for (int i = 0; i < n; ++i) {
        cin >> points[i].x >> points[i].y;
        points[i].id = i + 1;
    }

    // Sorting by x-coordinate (and y as tie-break) 
    // is a standard way to facilitate large Manhattan distance pairings.
    sort(points.begin(), points.end(), comparePoints);

    // Pair the first half with the second half to maximize distances
    for (int i = 0; i < n / 2; ++i) {
        cout << points[i].id << " " << points[i + n / 2].id << "\n";
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}