#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <algorithm>
#include <sstream>
#include <queue>
#include <deque>
#include <bitset>
#include <iterator>
#include <list>
#include <stack>
#include <map>
#include <set>
#include <functional>
#include <numeric>
#include <utility>
#include <limits>
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <climits>
#include <random>
#include <chrono>
#include <unordered_set>
#include <unordered_map>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace __gnu_pbds;
using namespace std;

template <class T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;   
template<class T> 
using ordered_multiset = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>;


#define int long long
#define cin std::cin
#define cout std::cout
#define sqrt sqrtl
#define pow powl
#define abs llabs
#define MOD 1000000007LL
#define inf 1000000000000000000LL
#define endl '\n'<<flush
#define all(x) x.begin(), x.end()
#define bitcount() __bultin_popcountll()
int M=998244353ll;
// int M=10007;

vector<int> fact(1e6+7);

int inv(int a, int m) {return a <= 1 ? a : m - (int)(m/a) * inv((m % a), m) % m;}
int binexp(int a,int b,int m){ 
    int ans=1; 
    while(b){ 
        if(b&1){
            ans=(ans*1ll*a)%m;
        } 
        a=(a*1ll*a)%m; 
        b>>=1;
    } 
    return ans;
}
int add(int x, int y,int m) { x+=y; if (x >= m) x-=m; if (x < 0) x+=m; return x; }
bool isprime(int n){ if(n==1) return false; bool flag=true; for(int i=2;i*i<=n;++i){ if(n%i==0) flag=false; } return flag;}
int ncr(int n,int r, int m){ if(n<r) return 0ll; return (fact[n]*binexp((fact[n-r]*fact[r])%m,m-2,m))%m;}
vector<int> sieve(int n) { vector<int> prime(n + 1, 1); prime[0] = prime[1] = 0; for (int i = 2; i <= sqrt(n); ++i) {if (prime[i] == 1) {for (int j = i * i; j <= n; j += i) {prime[j] = 0; }}}vector<int> ans; for (int i = 2; i <= n; ++i) { if (prime[i] == 1) {ans.push_back(i);}}return ans;}

int countAndMerge(vector<int>& arr, int l, int m, int r) {
  
    // Counts in two subarrays
    int n1 = m - l + 1, n2 = r - m;

    // Set up two vectors for left and right halves
    vector<int> left(n1), right(n2);
    for (int i = 0; i < n1; i++)
        left[i] = arr[i + l];
    for (int j = 0; j < n2; j++)
        right[j] = arr[m + 1 + j];

    // Initialize inversion count (or result) and merge two halves
    int res = 0;
    int i = 0, j = 0, k = l;
    while (i < n1 && j < n2) {

        // No increment in inversion count if left[] has a 
        // smaller or equal element
        if (left[i] <= right[j]) 
            arr[k++] = left[i++];
      
        // If right is smaller, then it is smaller than n1-i 
        // elements because left[] is sorted
        else {
            arr[k++] = right[j++];
            res += (n1 - i);
        }
    }

    // Merge remaining elements
    while (i < n1)
        arr[k++] = left[i++];
    while (j < n2)
        arr[k++] = right[j++];

    return res;
}

// Function to count inversions in the array
int countInv(vector<int> &arr, int l, int r){
    int res = 0;
    if (l < r) {
        int m = (r + l) / 2;

        // Recursively count inversions in the left and 
        // right halves
        res += countInv(arr, l, m);
        res += countInv(arr, m + 1, r);

        // Count inversions such that greater element is in 
        // the left half and smaller in the right half
        res += countAndMerge(arr, l, m, r);
    }
    return res;
}

vector<int> prime;
std::uniform_int_distribution<> distribInt(1, 3);
std::random_device rd;
std::mt19937 gen(rd());
mt19937_64 RNG(chrono::steady_clock::now().time_since_epoch().count());

int dirs[4][2]={{1,0},{-1,0},{0,-1},{0,1}};
char d[4]={'D','U','L','R'};
char e[4]={'U','D','R','L'};

bool comp(pair<int,int> &a,pair<int,int> &b){
    if(a.first!=b.first) return a.first<b.first;
    return a.second>b.second;
}

int numset(int x){
    int ans=0;
    for(int i=62;i>=0;i--){
        int num=1ll<<i;
        if(num&x){
            ans=i+1;
            break;
        }
    }
    return ans;
}

class DisjointSet{
public:
    vector<int> par,size;
    int sum=0;
    DisjointSet(int n){
        par.resize(n+1);
        iota(par.begin(),par.end(),0);
        size.resize(n+1,1);
    }
    int find(int u){
        if(u==par[u]) return u;
        return par[u]=find(par[u]);
    }
    void unite(int u,int v){
        int p1=find(u),p2=find(v);
        if(p1==p2) return;
        if(size[p2]>size[p1]) swap(p1,p2);
        par[p2]=p1;
        size[p1]+=size[p2];
        return;
    }
};

// Function to compute SPF (Smallest Prime Factor) for every number up to N
vector<int> computeSPF(int N) {
    vector<int> spf(N + 1);
    for (int i = 0; i <= N; ++i) {
        spf[i] = i;
    }

    for (int i = 2; i * i <= N; ++i) {
        // i is prime
        if (spf[i] == i) { 
            for (int j = i * i; j <= N; j += i) {
                if (spf[j] == j) {
                    spf[j] = i;
                }
            }
        }
    }
    return spf;
}   

// Function to get unique prime factors using precomputed SPF
vector<int> primeFac(int n, const vector<int>& spf) {
    set<int> uniqueFactors;
    while (n > 1) {
        uniqueFactors.insert(spf[n]);
        n /= spf[n];
    }
    return vector<int>(uniqueFactors.begin(), uniqueFactors.end());
}

int mult(int a,int b,int M){
    return (a*b)%M;
}

void solve() {
    //it dont matter which one pairs with which, all that matters is which to take as +ve and which as -ve, we can pair any +ve with any -ve
    //always better in a striaght line variant of the problem to choose a contigous sequence as positive->these sequences should be at the ends
    //this is a 2D problem, so how does the 1D approach generalise here?
    //apply a similar logic->first half largest x values pos, later ones neg, same for y
    //we can pair every combination of sign of x and y with its complement
    int n;
    cin>>n;
    vector<vector<int>> x(n,vector<int>(2)),y(n,vector<int>(2));
    for(int i=0;i<n;++i){
        cin>>x[i][0]>>y[i][0];
        x[i][1]=y[i][1]=i;
    }
    sort(all(x));
    reverse(all(x));
    sort(all(y));
    reverse(all(y));
    set<int> posx,negx,posy,negy;
    int ans=0;
    for(int i=0;i<n;++i){
        if(i<n/2){
            posx.insert(x[i][1]);
            posy.insert(y[i][1]);
        }
        else{
            negx.insert(x[i][1]);
            negy.insert(y[i][1]);
        }
    }
    vector<vector<int>> v(4);
    for(int i=0;i<n;++i){
        if(posx.count(i)){
            if(posy.count(i)){
                v[0].push_back(i);
            }
            else v[1].push_back(i);
        }
        else{
            if(posy.count(i)) v[2].push_back(i);
            else v[3].push_back(i);
        }
    }
    for(int i=0;i<4;++i){
        sort(all(v[i]));
    }
    for(int i=0;i<4;++i){
        for(int j=0;j<v[i].size();++j){
            if(v[i][j]<n/2){
                cout<<v[i][j]+1<<" "<<v[3-i].back()+1<<endl;
                v[3-i].pop_back();
            }
        }
    }
} 

signed main(){
    auto begin = std::chrono::high_resolution_clock::now();
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int t=1;
    cin>>t;
    while (t--){
        solve();
    }
    auto end = std::chrono::high_resolution_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(end - begin);
    cerr << "Time measured: " << elapsed.count() * 1e-9 << " seconds.\n";
}