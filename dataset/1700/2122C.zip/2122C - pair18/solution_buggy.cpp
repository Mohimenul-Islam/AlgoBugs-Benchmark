#include<bits/stdc++.h>
using namespace std;
struct poi{
	int x;
	int y;
	int idx;
};
bool cmpx(poi a,poi b){
	return a.x<b.x;
}
bool cmpy(poi a,poi b){
	return a.y<b.y;
}
void solve(){
	int n;
	cin>>n;
	poi an[n+1];
	long long x,y;
	for(int i=1;i<=n;i++){
		cin>>x>>y;
		an[i].idx=i;
		an[i].x=x;
		an[i].y=y;
	}
	sort(an+1,an+1+n,cmpx);
	sort(an+1,an+1+n/2-1,cmpy);
	sort(an+1+n/2,an+1+n,cmpy);
	for(int i=1;i<=n/2;i++){
		cout<<an[i].idx<<" "<<an[n-i+1].idx<<endl;
	}
}
int main(){
	int t;
	cin>>t;
	while(t--) solve();
}