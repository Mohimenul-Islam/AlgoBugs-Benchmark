#include <bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define lowbit(x) (x & (-x))
#define rep(i, x, y) for (int i = x; i <= y; i++)
#define frep(i, x, y) for (int i = x; i >= y; i--)
#define all(x) (x).begin(), (x).end()
#define all2(x) (x).rbegin(), (x).rend()
#define sz(a) (int)a.size()
#define pii pair<int, int>
#define pll pair<ll, ll>
#define tri tuple<int, int, int>
#define vi vector<int>
#define vl vector<ll>
#define vvi vector<vector<int>>
#define vvl vector<vector<ll>>
#define pq priority_queue
#define umap unordered_map
#define mset multiset
using namespace std;
void solve() {
    int n;
    cin >> n;
    vector<tuple<int, int, int>> ma(n);
    int x, y;
    rep(i, 0, n - 1) {
        cin >> x >> y;
        ma[i] = make_tuple(x, y, i + 1);
    }
    rep(i, 0, n - 1) {
        int tem = get<0>(ma[i]), tem2 = get<1>(ma[i]);
        auto& [x1, y1, z] = ma[i];
        x1 = tem + tem2, y1 = tem - tem2;
    }
    sort(all(ma), [&](const tri& x, const tri& y) {
        if (get<0>(x) == get<0>(y)) return get<1>(x) < get<1>(y);
        return get<0>(x) < get<0>(y);
    });
    vector<pii> res;
    int l = n / 2 - 1, r = n / 2;
    while (true) {
        int tem = abs(get<0>(ma[l]) - get<0>(ma[r])), tem2 = abs(get<1>(ma[l]) - get<1>(ma[r]));
        if (tem > tem2) break;
        l--, r++;
        if (l == -1 && r == n) break;
    }
    sort(ma.begin() + l + 1, ma.begin() + r, [&](const tri& x, const tri& y) {
        if (get<1>(x) == get<1>(y)) return get<0>(x) < get<0>(y);
        return get<1>(x) < get<1>(y);
    });
    ll ans = 0;
    rep(i, 0, n / 2 - 1) {
        res.emplace_back(get<2>(ma[i]), get<2>(ma[n - 1 - i]));
        ans += 1LL * max(abs(get<0>(ma[i]) - get<0>(ma[n - 1 - i])), abs(get<1>(ma[i]) - get<1>(ma[n - 1 - i])));
    }
    sort(all(ma), [&](const tri& x, const tri& y) {
        if (get<1>(x) == get<1>(y)) return get<0>(x) < get<0>(y);
        return get<1>(x) < get<1>(y);
    });
    vector<pii> res2;
    l = n / 2 - 1, r = n / 2;
    while (true) {
        int tem = abs(get<1>(ma[l]) - get<1>(ma[r])), tem2 = abs(get<0>(ma[l]) - get<0>(ma[r]));
        if (tem > tem2) break;
        l--, r++;
        if (l == -1 && r == n) break;
    }
    sort(ma.begin() + l + 1, ma.begin() + r, [&](const tri& x, const tri& y) {
        if (get<0>(x) == get<0>(y)) return get<1>(x) < get<1>(y);
        return get<0>(x) < get<0>(y);
    });
    ll ans2 = 0;
    rep(i, 0, n / 2 - 1) {
        res2.emplace_back(get<2>(ma[i]), get<2>(ma[n - 1 - i]));
        ans2 += 1LL * max(abs(get<0>(ma[i]) - get<0>(ma[n - 1 - i])), abs(get<1>(ma[i]) - get<1>(ma[n - 1 - i])));
    }
    if (ans > ans2) {
        for (auto& p : res) cout << p.first << ' ' << p.second << endl;
    } else {
        for (auto& p : res2) cout << p.first << ' ' << p.second << endl;
    }
    return;
}
int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
