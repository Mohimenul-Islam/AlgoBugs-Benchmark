#include <bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define lowbit(x) (x & (-x))
#define rep(i, x, y) for (int i = x; i <= y; i++)
#define frep(i, x, y) for (int i = x; i >= y; i--)
#define all(x) (x).begin(), (x).end()
#define all2(x) (x).rbegin(), (x).rend()
#define sz(a) (int)a.size()
#define pii pair<int, int>
#define pll pair<ll, ll>
#define tri tuple<int, int, int>
#define vi vector<int>
#define vl vector<ll>
#define vvi vector<vector<int>>
#define vvl vector<vector<ll>>
#define pq priority_queue
#define umap unordered_map
#define mset multiset
using namespace std;
void solve() {
    int n;
    cin >> n;
    vector<tuple<int, int, int>> ma(n);
    int x, y;
    rep(i, 0, n - 1) {
        cin >> x >> y;
        ma[i] = make_tuple(x, y, i + 1);
    }
    sort(all(ma), [&](const tri& x, const tri& y) {
        if (get<0>(x) == get<0>(y)) return get<1>(x) < get<1>(y);
        return get<0>(x) < get<0>(y);
    });
    sort(ma.begin(), ma.begin() + n / 2, [&](const tri& x, const tri& y) { return get<1>(x) < get<1>(y); });
    sort(ma.begin() + n / 2, ma.end(), [&](const tri& x, const tri& y) { return get<1>(x) < get<1>(y); });
    rep(i, 0, n / 2 - 1) cout << get<2>(ma[i]) << ' ' << get<2>(ma[n - 1 - i]) << endl;
    return;
}
int main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
