/* ========================================================================== */
/*                     THINK  ->  PLAN  ->  CODE                              */
/* ========================================================================== */
/*                                                                            */
/*   Improve logic before improving syntax.                                   */
/*   Every problem teaches a pattern.                                         */
/*   Understand the idea, then implement cleanly.                             */
/*                                                                            */
/*   Goal:                                                                    */
/*       - Think clearly                                                      */
/*       - Write simply                                                       */
/*       - Debug calmly                                                       */
/*                                                                            */
/* ========================================================================== */

#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define int long long
const int MOD=1e9+7;
const int N=1e5+1;
using namespace std;
using namespace __gnu_pbds;
template<class T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

int32_t main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int hv;
    cin>>hv;
    while(hv--){
        int n;
        cin>>n;
        vector<pair<int,int>> a(n),b(n);
        vector<int>q1,q2,q3,q4;
        for(int i=0;i<n;i++){
            cin>>a[i].first>>b[i].first;
            a[i].second=i;
            b[i].second=i;
        }
        sort(a.begin(),a.end());
        sort(b.begin(),b.end());
        vector<int> c(n),d(n);
        for(int i=0;i<n;i++){
            c[a[i].second]=i;
            d[b[i].second]=i;
        }
        for(int i=0;i<n;i++){
            if(c[i]<n/2 && d[i]<n/2){
                q1.push_back(i+1);
            }
            else if(c[i]>=n/2 && d[i]<n/2){
                q2.push_back(i+1);
            }
            else if(c[i]>=n/2 && d[i]>=n/2){
                q3.push_back(i+1);
            }
            else{
                q4.push_back(i+1);
            }
        }
        while(!q1.empty()){
            cout<<q1[q1.size()-1]<<" "<<q3[q3.size()-1]<<endl;
            q1.pop_back();
            q3.pop_back();
        }
        while(!q2.empty()){
            cout<<q2[q2.size()-1]<<" "<<q4[q4.size()-1]<<endl;
            q2.pop_back();
            q4.pop_back();
        }

    }
}