/* ========================================================================== */
/*                     THINK  ->  PLAN  ->  CODE                              */
/* ========================================================================== */
/*                                                                            */
/*   Improve logic before improving syntax.                                   */
/*   Every problem teaches a pattern.                                         */
/*   Understand the idea, then implement cleanly.                             */
/*                                                                            */
/*   Goal:                                                                    */
/*       - Think clearly                                                      */
/*       - Write simply                                                       */
/*       - Debug calmly                                                       */
/*                                                                            */
/* ========================================================================== */

#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define int long long
const int MOD=1e9+7;
const int N=1e5+1;
using namespace std;
using namespace __gnu_pbds;
template<class T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

int32_t main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int hv;
    cin>>hv;
    while(hv--){
        int n;
        cin>>n;
        vector<pair<int,pair<int,int>>>bp,op,bn,on;
        for(int i=0;i<n;i++){
            int l,r;
            cin>>l>>r;
            if(l<0 && r<0){
                  bn.push_back({abs(l),{abs(r),i+1}});

            }
            else if(l>=0 && r>=0){
                bp.push_back({abs(l),{abs(r),i+1}});
            }
            else if(l>=0 && r<0){
                op.push_back({abs(l),{abs(r),i+1}});
            }
            else{
                on.push_back({abs(l),{abs(r),i+1}});
            }
        }
        sort(bp.rbegin(),bp.rend());
        sort(op.rbegin(),op.rend());
        sort(bn.rbegin(),bn.rend());
        sort(on.rbegin(),on.rend());
         int l=0,r=0;
         int ans=0;
        
         vector<pair<int,int>>res;
         while(l<bp.size() && r<bn.size()){
            ans+=(bp[l].first+bn[r].first)+(bp[l].second.first+bn[r].second.first);
            res.push_back({bp[l].second.second,bn[r].second.second});
            l++;
            r++;

         }
         int u=0,w=0;
          while(u<op.size() && w<on.size()){
            ans+=(op[u].first+on[w].first)+(op[u].second.first+on[w].second.first);
            res.push_back({op[u].second.second,on[w].second.second});
            u++;
            w++;

         }
         while(l<bp.size() && u<op.size()){
            ans+=abs(bp[l].first-op[u].first)+(bp[l].second.first+op[u].second.first);
            res.push_back({bp[l].second.second,op[u].second.second});
            l++;
            u++;
         }
        while(l<bp.size() && w<on.size()){
            ans+=(bp[l].first+on[w].first)+abs(bp[l].second.first-on[w].second.first);
             res.push_back({bp[l].second.second,on[w].second.second});
            l++;
            w++;
         }
          while(r<bn.size() && u<op.size()){
            ans+=abs(bn[r].first-op[u].first)+(bn[r].second.first+op[u].second.first);
             res.push_back({bn[r].second.second,op[u].second.second});
            r++;
            u++;
         }
        while(r<bn.size() && w<on.size()){
            ans+=abs(bn[r].first-on[w].first)+abs(bn[r].second.first+on[w].second.first);
             res.push_back({bn[r].second.second,on[w].second.second});
            r++;
            w++;
         }
         int k=bp.size()-1;
         while(l<k){
               ans+=abs(bp[l].first-bp[k].first)+abs(bp[l].second.first-bp[k].second.first);
                res.push_back({bp[l].second.second,bp[k].second.second});
               k--;
               l++;
         }
        k=bn.size()-1;
         while(r<k){
               ans+=abs(bn[r].first-bn[k].first)+abs(bn[r].second.first-bn[k].second.first);
                res.push_back({bn[r].second.second,bn[k].second.second});
               k--;
               r++;
         }
        k=on.size()-1;
         while(w<k){
               ans+=abs(on[w].first-on[k].first)+abs(on[w].second.first-on[k].second.first);
                res.push_back({on[w].second.second,on[k].second.second});
               k--;
               w++;
         }
         k=op.size()-1;
         while(u<k){
               ans+=abs(op[u].first-op[k].first)+abs(op[u].second.first-op[k].second.first);
                res.push_back({op[u].second.second,op[k].second.second});
               k--;
               u++;
         }
        // cout<<ans<<endl;
         for(int i=0;i<res.size();i++){
            cout<<res[i].first<<" "<<res[i].second<<endl;
         }


    }
}