#include<bits/stdc++.h>
using namespace std;
 
#define int long long
#define fast1 std::chrono::high_resolution_clock::now()
#define io1 ios_base::sync_with_stdio(0); cin.tie(0)
#define all(v) v.begin(), v.end()
#define ff first
#define ss second
void print() {cout << "------------------------------------\n";}
template<typename T> void print(T a) {cout << a << "\n";}
template<typename T> void print(T a, T b) {cout << a << ", " << b << "\n";}
template<typename T> void print(multiset<T> a) {for(auto i : a) cout << i << " "; cout << "\n";}
template<typename T> void print(pair<T, T> p) {cout << p.ff << " " << p.ss << "\n";}
template<typename T> void print(vector<T> v) {for(auto i : v) cout << i << " "; cout << "\n";}
template<typename T> void print(vector<vector<T>> v) {for(auto i : v) {for(auto j : i) cout << j << " "; cout << "\n";}}
template<typename T> void print(vector<vector<vector<T>>> v) {for(auto i : v) {for(auto j : i) {for(auto k : j) cout << k << " "; cout << "\n";} cout << "#\n";}}
template<typename T> void print(vector<pair<T, T>> v) {for(auto [i, j] : v) cout << i << " " << j << "\n";}
template<typename T> void print(priority_queue<T> pq) {while(!pq.empty()) {cout << pq.top() << " "; pq.pop();} cout << "\n";}
template<typename T> void print(priority_queue<pair<T, T>> pq) {while(!pq.empty()) {cout << "{" << pq.top().ff << ", " << pq.top().ss << "} "; pq.pop();} cout << "\n";}
bool cmp(const pair<int, int>& a, const pair<int, int>& b){
    if(a.ff != b.ff) return a.ff < b.ff;
    return a.ss < b.ss;
}

// const int mod = 1e9 + 7;
const int mod = 998244353;
const int INF = 1e18;
const int MAXN = 2000000;

/*
template<int mod, int MAXN>
struct NCr {
    vector<long long> fact, invfact;

    NCr() {
        fact.resize(MAXN + 1);
        invfact.resize(MAXN + 1);
        init();
    }

    long long modpow(long long a, long long b) {
        long long res = 1;
        while(b) {
            if(b & 1) res = (res * a) % mod;
            a = (a * a) % mod;
            b >>= 1;
        }
        return res;
    }

    void init() {
        fact[0] = 1;
        for(int i = 1; i <= MAXN; i++)
            fact[i] = (fact[i - 1] * i) % mod;

        invfact[MAXN] = modpow(fact[MAXN], mod - 2);
        for(int i = MAXN - 1; i >= 0; i--)
            invfact[i] = (invfact[i + 1] * (i + 1)) % mod;
    }

    long long nCr(int n, int r) {
        if(r < 0 || r > n) return 0;
        return (((fact[n] * invfact[r]) % mod) * invfact[n - r]) % mod;
    }

    
    long long nPr(int n, int r){
        if(r < 0 || r > n) return 0;
        return (fact[n] * invfact[n - r]) % mod;
    }
};

struct mint{
    int x;
    
    mint (){ x = 0;}
    mint (int32_t xx){ x = xx % mod; if (x < 0) x += mod;}
    mint (long long xx){ x = xx % mod; if (x < 0) x += mod;}
    
    int val(){
        return x;
    }
    mint &operator++(){
        x++;
        if (x == mod) x = 0;
        return *this;
    }
    mint &operator--(){
        if (x == 0) x = mod;
        x--;
        return *this;
    }
    mint operator++(int32_t){
        mint result = *this;
        ++*this;
        return result;
    }
    
    mint operator--(int32_t){
        mint result = *this;
        --*this;
        return result;
    }
    mint& operator+=(const mint &b){
        x += b.x;
        if (x >= mod) x -= mod;
        return *this;
    }
    mint& operator-=(const mint &b){
        x -= b.x;
        if (x < 0) x += mod;
        return *this;
    }
    mint& operator*=(const mint &b){
        long long z = x;
        z *= b.x;
        z %= mod;
        x = (int)z;
        return *this;
    }
    mint operator+() const {
        return *this;
    }
    mint operator-() const {
        return mint() - *this;
    }
    mint operator/=(const mint &b){
        return *this = *this * b.inv();
    }
    mint power(long long n) const {
        mint ok = *this, r = 1;
        while (n){
            if (n & 1){
                r *= ok;
            }
            ok *= ok;
            n >>= 1;
        }
        return r;
    }
    mint inv() const {
        return power(mod - 2);
    }
    friend mint operator+(const mint& a, const mint& b){ return mint(a) += b;}
    friend mint operator-(const mint& a, const mint& b){ return mint(a) -= b;}
    friend mint operator*(const mint& a, const mint& b){ return mint(a) *= b;}
    friend mint operator/(const mint& a, const mint& b){ return mint(a) /= b;}
    friend bool operator==(const mint& a, const mint& b){ return a.x == b.x;}
    friend bool operator!=(const mint& a, const mint& b){ return a.x != b.x;}
    mint power(mint a, long long n){
        return a.power(n);
    }
    friend ostream &operator<<(ostream &os, const mint &m) {
        os << m.x;
        return os;
    }
    explicit operator bool() const {
        return x != 0;
    }
};

NCr<mod, MAXN> comb;

struct SegTree{
    int n;
    vector<int> tree;

    SegTree(vector<int>& arr){
        build(arr);
    }

    void build(vector<int>& arr){
        n = arr.size();
        tree.resize(2 * n);
        copy(arr.begin(), arr.end(), tree.begin() + n);
        for(int i = n - 1; i >= 1; --i){
            tree[i] = max(tree[2 * i], tree[2 * i + 1]); // edit build function
        }
    }

    void update(int i, int newval){
        i += n;
        tree[i] = newval;
        while(i > 1){
            i /= 2;
            tree[i] = max(tree[2 * i], tree[2 * i + 1]); // edit function
        }
    }

    int query(int l, int r){
        l += n;
        r += n;
        int ans = -1; // give suiitable initialization
        while(l <= r){
            if(l % 2 == 1){
                ans = max(ans, tree[l]); // edit function
                l++;
            }
            if(r % 2 == 0){
                ans = max(ans, tree[r]); // edit function
                r--;
            }
            
            l /= 2;
            r /= 2;
        }

        return ans;
    }
};

int bitlenll(int n) {return 63 - __builtin_clzll(n);}
int cntsetbitll(int n) {return __builtin_popcountll(n);}

mt19937_64 RNG(chrono::steady_clock::now().time_since_epoch().count());

int rnd(int l, int r) {
    return uniform_int_distribution<int>(l, r)(RNG);
}
*/

// =================================== --- HERE YOU GO --- ========================================================= //
void solve(){
    int n; cin >> n;
    vector<tuple<int, int, int>> points(n);
    for(int i = 0; i < n; ++i){
        cin >> get<0>(points[i]) >> get<1>(points[i]);
        get<2>(points[i]) = i + 1; // 1-based index
    }

    // 1. Tag exactly N/2 points as "Left" using Sorted X-Index
    sort(all(points));
    vector<bool> is_left(n + 1, false);
    for(int i = 0; i < n / 2; ++i) {
        is_left[get<2>(points[i])] = true;
    }

    // 2. Tag exactly N/2 points as "Down" using Sorted Y-Index
    sort(all(points), [](const tuple<int, int, int>& a, const tuple<int, int, int>& b){
        if(get<1>(a) != get<1>(b)) return get<1>(a) < get<1>(b);
        return get<0>(a) < get<0>(b);
    });
    vector<bool> is_down(n + 1, false);
    for(int i = 0; i < n / 2; ++i) {
        is_down[get<2>(points[i])] = true;
    }

    // 3. Populate 4 buckets: 
    // t1: Bottom-Left (L,D) | t2: Top-Left (L,U)
    // t3: Bottom-Right (R,D) | t4: Top-Right (R,U)
    vector<int> t1, t2, t3, t4;
    for(int i = 0; i < n; ++i){
        int id = get<2>(points[i]);
        if(is_left[id] && is_down[id]) t1.push_back(id);      // Bottom-Left
        else if(is_left[id] && !is_down[id]) t2.push_back(id); // Top-Left
        else if(!is_left[id] && is_down[id]) t3.push_back(id); // Bottom-Right
        else t4.push_back(id);                                 // Top-Right
    }

    // 4. Mathematical Guarantee: t1.size == t4.size and t2.size == t3.size
    // This pairs opposites to maximize (|x1-x2| + |y1-y2|)
    for(int i = 0; i < t1.size(); ++i) cout << t1[i] << " " << t4[i] << "\n";
    for(int i = 0; i < t2.size(); ++i) cout << t2[i] << " " << t3[i] << "\n";
}
void sol(){
    int n; cin >> n;
    vector<tuple<int, int, int>> t(n);
    for(int i = 0; i < n; ++i){
        cin >> get<0>(t[i]) >> get<1>(t[i]);
        get<2>(t[i]) = i + 1; // 1-based index
    }

    // 1. Safe Medians
    sort(all(t));
    int xmed = get<0>(t[n / 2]);

    sort(all(t), [](const tuple<int, int, int>& a, const tuple<int, int, int>& b){
        if(get<1>(a) != get<1>(b)) return get<1>(a) < get<1>(b);
        return get<0>(a) < get<0>(b);
    });
    int ymed = get<1>(t[n / 2]);

    vector<int> t1, t2, t3, t4;
    vector<tuple<int, int, int>> waitlist; // Your t5, t6, t7 combined!

    int left_count = 0, bottom_count = 0;

    // 2. The Definitive Pass & Waitlist Assignment
    for(int i = 0; i < n; ++i){
        auto [x, y, id] = t[i];
        
        // If it touches ANY axis, send it to the waiting room to be balanced later
        if(x == xmed || y == ymed){
            waitlist.push_back(t[i]);
        } 
        else {
            // It is strictly off-axis. Route it immediately.
            bool is_left = (x < xmed);
            bool is_bottom = (y < ymed);
            
            if(is_left) left_count++;
            if(is_bottom) bottom_count++;

            if(is_left && is_bottom) t1.push_back(id);
            else if(is_left && !is_bottom) t2.push_back(id);
            else if(!is_left && is_bottom) t3.push_back(id);
            else t4.push_back(id);
        }
    }

    // 3. The Global Deficit (How many points are starving?)
    int needed_left = n / 2 - left_count;
    int needed_bottom = n / 2 - bottom_count;

    // 4. Balance the Waitlist!
    for(auto [x, y, id] : waitlist){
        
        // Resolve X
        bool is_left = false;
        if(x < xmed) is_left = true;
        else if(x == xmed && needed_left > 0){
            is_left = true;
            needed_left--; // Feed the starving left side!
        }

        // Resolve Y
        bool is_bottom = false;
        if(y < ymed) is_bottom = true;
        else if(y == ymed && needed_bottom > 0){
            is_bottom = true;
            needed_bottom--; // Feed the starving bottom side!
        }

        // Route from the waitlist directly to the final buckets
        if(is_left && is_bottom) t1.push_back(id);
        else if(is_left && !is_bottom) t2.push_back(id);
        else if(!is_left && is_bottom) t3.push_back(id);
        else t4.push_back(id);
    }

    // 5. Safe Print. Guaranteed perfectly balanced.
    for(int i = 0; i < t1.size(); ++i){
        cout << t1[i] << " " << t4[i] << "\n";
    }
    for(int i = 0; i < t2.size(); ++i){
        cout << t2[i] << " " << t3[i] << "\n";
    }
}
void solv(){
    int n; cin >> n;
    vector<tuple<int, int, int>> t(n);
    for(int i = 0; i < n; ++i){
        cin >> get<0>(t[i]) >> get<1>(t[i]);
        get<2>(t[i]) = i + 1;
    }

    sort(all(t));

    int xmed = (get<0>(t[(n - 1) / 2]) + get<0>(t[(n - 1) / 2 + 1])) / 2;

    sort(all(t), [](const tuple<int, int, int>& a, const tuple<int, int, int>& b){
            if(get<1>(a) != get<1>(b)){
                return get<1>(a) < get<1>(b);
            }
            return get<0>(a) < get<0>(b);
        });

    int ymed = (get<1>(t[(n - 1) / 2]) + get<1>(t[(n - 1) / 2 + 1])) / 2;

    vector<tuple<int, int, int>> t1, t2, t3, t4, t5;
    for(int i = 0; i < n; ++i){
        auto [x, y, z] = t[i];

        if(x == xmed || y == ymed){
            t5.push_back(t[i]);
        }
        else if(x < xmed && y < ymed){
            t2.push_back(t[i]);
        }
        else if(x < xmed && y > ymed){
            t1.push_back(t[i]);
        }
        else if(x > xmed && y < ymed){
            t3.push_back(t[i]);
        }
        else if(x > xmed && y > ymed){
            t4.push_back(t[i]);
        }
    }

    int lft = t1.size() + t2.size(), rgt = t3.size() + t4.size();
    int up = t1.size() + t4.size(), dn = t2.size() + t3.size();

    while(!t5.empty()){
        auto [x, y, z] = t5.back();
        t5.pop_back();

        bool islft = false;
        if(x < xmed) islft = true;
        else if(x == xmed){
            if(lft < rgt) islft = true;
        }

        bool isdn = false;
        if(y < ymed) isdn = true;
        else if(y == ymed){
            if(dn < up) isdn = true;
        }

        if(islft && isdn){
            t2.push_back({x, y, z});
            lft++, dn++;
        }
        else if(islft && !isdn){
            t1.push_back({x, y, z});
            lft++, up++;
        }
        else if(!islft && isdn){
            t3.push_back({x, y, z});
            rgt++, dn++;
        }
        else if(!islft && !isdn){
            t4.push_back({x, y, z});
            rgt++, up++;
        }
    }

    for(int i = 0; i < min(t3.size(), t1.size()); ++i){
        auto [x1, y1, z1] = t1[i];
        auto [x4, y4, z4] = t3[i];
        cout << z1 << " " << z4 << "\n";
    }
    for(int i = 0; i < min(t4.size(), t2.size()); ++i){
        auto [x2, y2, z2] = t2[i];
        auto [x3, y3, z3] = t4[i];
        cout << z2 << " " << z3 << "\n";
    }
}

int32_t main(){
    fast1; io1;
 
    int tt = 1;
    cin >> tt;
    for(int i = 1; i <= tt; i++){
        solve();
    }
}
