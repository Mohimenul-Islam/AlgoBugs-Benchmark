#include<bits/stdc++.h>
using namespace std;
#define fast_io ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define int long long
#define pb push_back
const int INF = 1e18;
#define setnumber __builtin_popcount
#define endl "\n" 
const int MOD = 1e9 + 7;
void solve()
{
int n;
cin>>n;
vector<tuple<int,int,int>> a(n);
for(int i=0;i<n;i++){
    int x,y;
    cin>>x>>y;
    a[i]={x,y,i+1};
}

int m=n/2;

vector<int> p(n,0);
vector<int> s(n,0);

sort(a.rbegin(),a.rend());


vector<int> y;


set<int> whoplus;
set<int> whominus;
for(int i=0;i<n;i++){
    y.pb(get<1>(a[i]));
}
sort(y.begin(),y.end());


int mid=y[(n/2)];

int midminus=0;
int midplus=0;
for(int i=0;i<(n/2);i++){
    if(y[i]==mid) midminus++;
}

for(int i=(n/2);i<(n);i++){
    if(y[i]==mid) midplus++;
}





for(int i=(n/2);i<n;i++){
    int x=upper_bound(y.begin(),y.end(),get<1>(a[i]))-y.begin();
    if(get<1>(a[i])==mid){
        if(midminus){
            whominus.emplace(get<2>(a[i]));
            midminus--;
        }
        else{
            whoplus.emplace(get<2>(a[i]));
        }
        continue;
    }
    if(x>(n/2)){
        whoplus.emplace(get<2>(a[i]));
    }
    else{
        whominus.emplace(get<2>(a[i]));
    }
}


vector<pair<int,int>> ans;

for(int i=0;i<(n/2);i++){
    int x=upper_bound(y.begin(),y.end(),get<1>(a[i]))-y.begin();
    int y;
    x++;
    if(x>(n/2)){
        y=*whominus.begin();
        whominus.erase(whominus.begin());
    }
    else{
        y=*whoplus.begin();
        whoplus.erase(whoplus.begin());
    }
    
    ans.pb({get<2>(a[i]),y});
}

for(auto x:ans){
    cout<<x.first<<" "<<x.second<<endl;
}
return;


}
int32_t main()
{
fast_io;
int t;
cin >> t;
while (t--)
{
solve();
}
return 0;
}