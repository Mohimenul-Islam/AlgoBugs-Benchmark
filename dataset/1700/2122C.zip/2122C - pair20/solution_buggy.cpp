#include<bits/stdc++.h>
using namespace std;

using i64=long long;
using u64=unsigned long long;
using f80=long double;
using i128=__int128;//-2e127~2e127-1,使用时要用快读快写

constexpr int mxn=5e5+5;
constexpr int inf=1e9;
constexpr i64 infl=1e18;
constexpr i128 infll=i128(1)<<100;


void solve() {
    int n;
    cin>>n;
    vector<array<int,3>> a(n+1);
    for (int i=1;i<=n;i++) {
        int x,y;
        cin>>x>>y;
        a[i]={x,y,i};
    }

    sort(a.begin()+1,a.end());
    sort(a.begin()+n/2,a.end(),greater<>());
    for (int i=1;i<=n/2;i++) {
        cout<<a[i][2]<<" "<<a[i+n/2][2]<<'\n';
    }

}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t=1;
    cin>>t;
    while(t--) {
        solve();
    }
    return 0;
}