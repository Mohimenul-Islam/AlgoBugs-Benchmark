#include <bits/stdc++.h>
using namespace std;
#define yes {cout << "YES\n"; return;}
#define no {cout << "NO\n"; return;}
#define fill(v,n) for(int i=0;i<n;i++) cin >> v[i];
#define loop for(int i=0;i<n;i++)
using ll = long long;
using vll = vector<ll>;
ll mod = 1e9 + 7;

// O(log(min(a,b)))
int gcd(int a, int b) {
    if (b == 0) return a;
    return gcd(b, a % b);
}

// O(r) or O(n) without mod implementation
ll nCr(ll n, ll r) {
    if (r < 0 || r > n) return 0;
    r = min(r, n - r);  // symmetry
    __int128 res = 1;
    for (ll i = 1; i <= r; i++) {
        res = (res * (n - r + i) / i);
    }
    return (ll)res;
}

// modular exponentiation
ll modexp(ll a, ll b) {
    ll res = 1;
    a %= mod;
    while (b) {
        if (b & 1) res = (res * a) % mod;
        a = (a * a) % mod;
        b >>= 1;
    }
    return res;
}

// modular inverse (mod is prime)
ll inv(ll x) {return modexp(x, mod - 2);}

void comp_prime(vector<ll>& p) {
    ll n = p.size();
    p[0] = p[1] = 0;
    for(ll i = 2;i*i<n;i++) {
        if(p[i]) for(ll j = i*i;j<n;j += i) p[j] = 0;
    }
}

vll p(1e5+1,1),prime;

void solve() {
    ll n;
    cin >> n;
    vector<pair<ll,pair<ll,ll>>> v(n);
    loop {
        cin >> v[i].first >> v[i].second.first;
        v[i].second.second = i;
    }
    sort(v.begin(),v.end());
    vll a(n,1);
    for(ll i = 0;i<n/2;i++) a[v[i].second.second] = 0;
    loop swap(v[i].first,v[i].second.first);
    sort(v.begin(),v.end());
    vll big,small;
    vll remb,rems;
    for(ll i = 0;i<n/2;i++) {
        if(a[v[i].second.second] == 0) small.push_back(v[i].second.second);
        else remb.push_back(v[i].second.second);
    }
    for(ll i = n/2;i<n;i++) {
        if(a[v[i].second.second] == 1) big.push_back(v[i].second.second);
        else rems.push_back(v[i].second.second);
    }
    set<ll> s;
    loop s.insert(i);
    for(ll i = 0;i<big.size();i++) cout << small[i]+1 << " " << big[i]+1 << '\n';
    ll c = 0;
    for(ll i = 0;i<rems.size();i++) cout << rems[i]+1 << " " << remb[i]+1 << '\n';
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ll t; cin >> t;
    // ll t = 1;
    while(t--){
        solve();
    }
    return 0;
}