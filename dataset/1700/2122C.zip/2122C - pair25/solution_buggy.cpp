#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
#include <iomanip>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <numeric>
#include <cstdint>
#include <climits>
using namespace std;

#define ll long long
#define int ll
#define vll vector<ll>
#define vpll vector<pair<ll, ll>>
#define srt(v) sort(v.begin(), v.end())
#define rep(i, j, k) for (int i = j; i < k; i++)
#define i(n) \
    int n;   \
    cin >> n
#define vint(v, n) \
    i(n);          \
    vll v(n);      \
    rep(i, 0, n) cin >> v[i]
#define vin(v, n) \
    vll v(n);     \
    rep(i, 0, n) cin >> v[i]
#define pb push_back

struct point
{
    int x, y;
};

void solve()
{
    i(n);
    vector<pair<point, int>> v(n);
    rep(i, 0, n)
    {
        cin >> v[i].first.x >> v[i].first.y;
        v[i].second = i;
    }
    sort(v.begin(), v.end(), [](const pair<point, int> &a, const pair<point, int> &b)
         { return a.first.x < b.first.x; });
    vector<int> x_l, y_l;
    rep(i, 0, n / 2)
    {
        x_l.pb(v[i].second);
    }
    sort(v.begin(), v.end(), [](const pair<point, int> &a, const pair<point, int> &b)
         { return a.first.y < b.first.y; });
    rep(i, 0, n / 2)
    {
        y_l.pb(v[i].second);
    }
    srt(x_l);
    srt(y_l);
    vector<int> groupA, groupB, groupC, groupD;
    int u = 0, c = 0;
    rep(i, 0, n)
    {
        if (x_l[u] == i)
        {
            if (y_l[c] == i)
            {
                groupA.pb(i);
                c++;
            }
            else
            {
                groupC.pb(i);
            }
            u++;
        }
        else
        {
            if (y_l[c] == i)
            {
                groupD.pb(i);
                c++;
            }
            else
            {
                groupB.pb(i);
            }
        }
    }
    rep(i, 0, groupA.size())
    {
        cout << groupA[i] + 1 << " " << groupB[i] + 1 << "\n";
    }
    rep(i, 0, groupC.size())
    {
        cout << groupC[i] + 1 << " " << groupD[i] + 1 << "\n";
    }
}

signed main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
    return 0;
}