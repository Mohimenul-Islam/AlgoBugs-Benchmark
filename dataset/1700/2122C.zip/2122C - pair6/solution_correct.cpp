/*
    +---------------------------------------+
    |  THINK ONCE  |  CODE TWICE  |  WA2 ?? |
    +---------------------------------------+
                \   ^__^
                 \  (oo)\_______
                    (__)\       )\/\
                        ||---wW |
                        ||     ||
*/
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;
#define pb push_back
#define rep(i, a, b) for (int i = a; i < b; ++i)
#define rep0(i, n) for (int i = 0; i < n; ++i)
#define enld endl;
#define sp " ";
#define nl "\n";
typedef long long ll;
typedef tree<
    pair<long long, ll>,
    null_type,
    less<pair<long long, ll>>,
    rb_tree_tag,
    tree_order_statistics_node_update>
    ordered_set;
typedef long double ld;
ll inf = 1e18;
const int MOD = 1e9 + 7;
vector<bool> isp(1e5 + 5, true);
vector<ll> fact(2e5 + 5);
void compfac()
{
    ll n = fact.size();
    fact[0] = 1;
    fact[1] = 1;
    for (int i = 2; i < n; i++)
    {
        fact[i] = i * fact[i - 1];
        fact[i] %= MOD;
    }
}
void compP()
{
    ll n = isp.size();
    isp[0] = false;
    isp[1] = false;
    for (int i = 2; i * i < n; i++)
    {
        if (isp[i])
        {
            for (int j = i * i; j < n; j += i)
            {
                isp[j] = false;
            }
        }
    }
}
void fastIO()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
}
void prinv(const vector<ll> &v)
{
    for (ll ff : v)
        cout << ff << " ";
    cout << endl;
}
ll binpow(ll a, ll b, ll mod = MOD)
{
    a %= mod;
    ll res = 1;
    while (b > 0)
    {
        if (b & 1)
        {
            res = (res * a) % mod;
        }
        a = a * a % mod;
        b >>= 1;
    }
    return res;
}
ll modmul(ll a, ll b, ll mod = MOD)
{
    a %= MOD;
    b %= MOD;
    return ((a * b) % MOD);
}
// const int MAX = 35;
// void init()
// {
//     fact[0] = 1;
//     for (int i = 1; i < MAX; i++)
//         fact[i] = fact[i - 1] * i % MOD;
//     invfact[MAX - 1] = binpow(fact[MAX - 1], MOD - 2);
//     for (int i = MAX - 2; i >= 0; i--)
//         invfact[i] = invfact[i + 1] * (i + 1) % MOD;
// }
// ll nCrComputed(ll n, ll r)
// {
//     if (r < 0 || r > n)
//         return 0;
//     return fact[n] * invfact[r] % MOD * invfact[n - r] % MOD;
// }
ll nCr(ll n, ll r)
{
    if (r > n - r)
        r = n - r;
    ll res = 1;
    for (int i = 1; i <= r; i++)
    {
        res = res * (n - r + i) % MOD;
        res = res * binpow(i, MOD - 2) % MOD;
    }
    return res;
}
long long C[25][25];
void precompute()
{
    for (int i = 0; i <= 20; i++)
    {
        C[i][0] = 1;
        for (int j = 1; j <= i; j++)
        {
            C[i][j] = (C[i - 1][j - 1] + C[i - 1][j]) % MOD;
        }
    }
}
bool cycle(ll node, vector<ll> &seen, vector<ll> &vis, vector<set<ll>> &adj)
{
    bool can = true;
    seen[node] = 1;
    vis[node] = 1;
    for (auto child : adj[node])
    {
        if (seen[child])
        {
            can = false;
            break;
        }
        if (!vis[child])
        {
            seen[child] = 1;
            vis[child] = 1;
            if (!cycle(child, seen, vis, adj))
            {
                can = false;
                break;
            }
        }
    }
    seen[node] = 0;
    return can;
}
vector<ll> spf(1e7 + 5, -1);
void precspf()
{
    ll n = spf.size();
    for (ll i = 2; i < n; i++)
    {
        if (spf[i] == -1)
        {
            spf[i] = i;
            for (ll j = i * i; j < n; j += i)
            {
                if (spf[j] == -1)
                {
                    spf[j] = i;
                }
            }
        }
    }
}
struct thr
{
    ll a, b, ind;
};
void solve()
{
    // DONT KEEP YOURSELF STUCK ON THE SAME APPROACH FOR MORE THAN 20min
    // THINK BINARY SEARCH THINK BITS
    // DONT CHECK THE STANDINGS
    ll n;
    cin >> n;
    vector<thr> v(n);
    for (int i = 0; i < n; i++)
    {
        ll a, b;
        cin >> a >> b;
        v[i] = {a, b, i + 1};
    }
    vector<pair<ll, ll>> ans1;
    vector<pair<ll, ll>> ans2;
    vector<pair<ll, ll>> ans3;
    vector<pair<ll, ll>> ans4;

    sort(v.begin(), v.end(), [](thr &a, thr &b)
         { return a.a < b.a; });
    sort(v.begin() + n / 2, v.end(), [](thr &a, thr &b)
         { return a.b < b.b; });
    sort(v.begin(), v.begin() + n / 2, [](thr &a, thr &b)
         { return a.b > b.b; });
    ll l = 0;
    ll r = n / 2;
    ll maxi1 = 0, maxi2 = 0, maxi3 = 0, maxi4 = 0;
    while (r < n)
    {
        ans1.push_back({v[l].ind, v[r].ind});
        maxi1 += abs(v[l].a - v[r].a) + abs(v[l].b - v[r].b);
        l++;
        r++;
    }
    sort(v.begin(), v.end(), [](thr &a, thr &b)
         { return a.b < b.b; });
    sort(v.begin() + n / 2, v.end(), [](thr &a, thr &b)
         { return a.a < b.a; });
    sort(v.begin(), v.begin() + n / 2, [](thr &a, thr &b)
         { return a.a > b.a; });
    l = 0;
    r = n / 2;
    while (r < n)
    {
        ans2.push_back({v[l].ind, v[r].ind});
        maxi2 += abs(v[l].a - v[r].a) + abs(v[l].b - v[r].b);
        l++;
        r++;
    }
    // cout << maxi1 << " " << maxi2 << endl;
    sort(v.begin(), v.end(), [](thr &a, thr &b)
         { return a.b < b.b; });
    sort(v.begin() + n / 2, v.end(), [](thr &a, thr &b)
         { return a.a < b.a; });
    sort(v.begin(), v.begin() + n / 2, [](thr &a, thr &b)
         { return a.a < b.a; });
    l = 0;
    r = n / 2;
    while (r < n)
    {
        ans3.push_back({v[l].ind, v[r].ind});
        maxi3 += abs(v[l].a - v[r].a) + abs(v[l].b - v[r].b);
        l++;
        r++;
    }
    sort(v.begin(), v.end(), [](thr &a, thr &b)
         { return a.a < b.a; });
    sort(v.begin() + n / 2, v.end(), [](thr &a, thr &b)
         { return a.b < b.b; });
    sort(v.begin(), v.begin() + n / 2, [](thr &a, thr &b)
         { return a.b > b.b; });
    l = 0;
    r = n / 2;
    while (r < n)
    {
        ans4.push_back({v[l].ind, v[r].ind});
        maxi4 += abs(v[l].a - v[r].a) + abs(v[l].b - v[r].b);
        l++;
        r++;
    }
    ll mm = max({maxi1, maxi2, maxi3, maxi4});
    // cout<<"dis: ";
    // cout << maxi1 << " " << maxi2 << " " << maxi3 << " " << maxi4 << endl;
    if (mm == maxi1)
    {
        for (auto it : ans1)
        {
            cout << it.first << " " << it.second << endl;
        }
    }
    else if (mm == maxi2)
    {
        for (auto it : ans2)
        {
            cout << it.first << " " << it.second << endl;
        }
    }
    else if (mm == maxi3)
    {
        for (auto it : ans3)
        {
            cout << it.first << " " << it.second << endl;
        }
    }
    else
    {
        for (auto it : ans4)
        {
            cout << it.first << " " << it.second << endl;
        }
    }
}

int main()
{
    // DONT KEEP YOURSELF STUCK ON THE SAME APPROACH FOR MORE THAN 20min
    // THINK BINARY SEARCH THINK BITS
    // DONT CHECK THE STANDINGS
    fastIO();
    // precompute();
    // precspf();
    int t = 1;
    cin >> t;
    while (t--)
    {
        solve();
    }
    // vis(5);
    return 0;
}
/*
__      __  _____    ________   .__          __                         ._._._.
/  \    /  \/  _  \   \_____  \  |  |   _____/  |_  ______    ____   ____| | | |
\   \/\/   /  /_\  \   /  ____/  |  | _/ __ \   __\/  ___/   / ___\ /  _ \ | | |
\        /    |    \ /       \  |  |_\  ___/|  |  \___ \   / /_/  >  <_> )|\|\|
\__/\  /\____|__  / \_______ \ |____/\___  >__| /____  >  \___  / \____/______
\/         \/          \/           \/          \/  /_____/        \/\/\/
*/