// Author : Coder097

#include <bits/stdc++.h>
#include <iostream>
#include <set>
#include <map>
using namespace std;

#define fastio() ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr)

typedef long long ll;
typedef unsigned long long ull;
typedef long double lld;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;

#define pb push_back
#define ff first
#define ss second
#define all(x) (x).begin(), (x).end()
#define rep(i, a, b) for (int i = a; i < b; i++)
#define per(i, a, b) for (int i = a; i >= b; i--)
#define yes cout << "YES\n"
#define no cout << "NO\n"
#define endl '\n'

const ll MOD = 1e9 + 7;
const ll INF = 1e18;
const double PI = acos(-1);

// Debugging
#ifndef ONLINE_JUDGE
#define debug(x) cerr << #x << " = "; _print(x); cerr << endl
#else
#define debug(x)
#endif

void _print(int x) { cerr << x; }
void _print(ll x) { cerr << x; }
void _print(string x) { cerr << x; }
void _print(char x) { cerr << x; }
void _print(double x) { cerr << x; }
template <class T, class V> void _print(pair<T, V> p) { cerr << "{"; _print(p.ff); cerr << ","; _print(p.ss); cerr << "}"; }
template <class T> void _print(vector<T> v) { cerr << "["; for (T i : v) { _print(i); cerr << " "; } cerr << "]"; }

// Math utilities
ll gcd(ll a, ll b) { return b ? gcd(b, a % b) : a; }

ll power(ll a, ll b, ll m = MOD) {
    ll res = 1;
    a %= m;
    while (b > 0) {
        if (b & 1) res = (res * a) % m;
        a = (a * a) % m;
        b >>= 1;
    }
    return res;
}

/* *****************************************************
 Solutions are simple, just think the right way 
****************************************************** */

void solve() {
    int n;
    cin >> n;
    vector<vector<int>> v(n, vector<int> (3));

    for(int i = 0; i < n; i++){
        cin >> v[i][0] >> v[i][1];
        v[i][2] = i + 1;
    }
    
    sort(all(v));
    sort(v.begin(), v.begin() + n / 2 , [&](vector<int> a, vector<int> b){
        return a[1] <= b[1];
    });

    sort(v.begin() + n / 2, v.end(), [&](vector<int> a, vector<int> b){
        return a[1] <= b[1];
    });

    int i = 0, j = n - 1;

    while(i < n / 2){
        cout << v[i][2] << " " << v[j][2] << endl;
        i++, j--;
    }
}

int main() {
    fastio();
    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}