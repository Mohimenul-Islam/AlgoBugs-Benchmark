#include<iostream>
#include<vector>
#include<map>
#include<algorithm>
using namespace std;
typedef long long ll; 
string hw(vector<ll> ne){
	int l = 0, r = ne.size() - 1;
	while(ne[l] == ne[r] && l < r){
		l++,r--;
	}
	if(l == r || l == r + 1){
		return "YES";
	}
	return "NO";
}
void solve(){
	ll n, k;
	cin >> n >> k;
	vector<ll>a(n + 1);
	map<int, int>m;
	for(int i = 1; i <= n; i++){
		cin >> a[i];
		m[a[i]] ++;
	}
	vector<ll> b = a;
	sort(b.begin() + 1, b.end());
	if(k == 1 || k == 2){
		cout << "YES\n";
		return;
	} 
	vector<ll>ne;
	for(int i = 1; i <= n; i++){
		if(a[i] <= b[k - 1]){
			ne.push_back(a[i]);
		}
	}
//	for(int i = 0; i < ne.size(); i++)cout << ne[i] << " ";cout << endl;
	if(b[k] != b[k - 1]){
		cout << hw(ne) << endl;
		return;
	}
	int idx = 0;
	for(int i = 1; i <= k - 1; i++){	
		if(b[i] == b[k]){
			idx = i;
			break;
		}
	}
	int del= m[b[k]] - (k - idx);
	int l = 0, r = ne.size() - 1;
	int now = 0;
	int cnt = ne.size();
	while (l <= r)
    {
        if (ne[l]!= ne[r]) 
        {
            while (l < r && ne[l] == b[k] && ne[l] != ne[r])
                l++, cnt--;
            while (l < r && ne[r] == b[k] && ne[l] != ne[r])
                r--, cnt--;
        }
        if (ne[r] != ne[r]){
        	cout << "NO\n";
        	return;
		}
        ++l, --r;
    }
	if(cnt >= k - 1){
		cout << "YES\n";
		return;
	}
	cout << "NO\n";
	return;
}
int main(){
	int t;
	cin >> t;
	while(t--)solve();
	return 0;
} 