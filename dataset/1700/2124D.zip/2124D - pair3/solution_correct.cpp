#include<iostream>
#include<vector>
#include<map>
#include<algorithm>
using namespace std;
typedef long long ll; 
// 0-based
bool ispli(vector<int> a)
{
    for (int i = 0, j = a.size() - 1; i < j; ++i, --j)
        if (a[i] != a[j])
            return 0;
    return 1;
}

int delx_ispli(vector<int> a, int x)
{
    int cnt = a.size();
    int i = 0, j = a.size() - 1;
    while (i <= j)
    {
        if (a[i] != a[j]) // x/非x 或者 非x/非x
        {
            while (i < j && a[i] == x && a[i] != a[j])
                i++, cnt--;
            while (i < j && a[j] == x && a[i] != a[j])
                j--, cnt--;
        }
        if (a[i] != a[j])
            return -1;
        ++i, --j;
    }
    return cnt;
}

void solve()
{
    int n, k;
    cin >> n >> k;
    vector<int> a(n + 1);
    for (int i = 1; i <= n; ++i)  cin >> a[i];
    vector<int> ans, buf = a;
    sort(buf.begin() + 1, buf.end());
    int x = buf[k - 1];
    for (int i = 1; i <= n; ++i)
        if (a[i] <= x)
            ans.push_back(a[i]);
    if (buf[k - 1] != buf[k])
        cout << (ispli(ans) ? "YES" : "NO") << endl;
    else
        cout << (delx_ispli(ans, x) >= k - 1 ? "YES" : "NO") << endl;
}

int main(){
	int t;
	cin >> t;
	while(t--)solve();
	return 0;
} 