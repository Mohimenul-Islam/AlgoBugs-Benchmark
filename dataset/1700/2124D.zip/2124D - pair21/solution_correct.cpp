#include<bits/stdc++.h>
using namespace std;      
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
template <typename T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template <typename T>
using ordered_multiset = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>; 
#define int ll
#define ll long long 
#define ld long double
#define mem0(x)        memset(x,0,sizeof x)
#define mem1(x)        memset(x,-1,sizeof x)
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<vi> vvi; 
typedef vector<ll> vll;
typedef vector<ld> vld;
#define pb push_back
#define pob pop_back
#define f first
#define sec second
#define fix(f,n) std::fixed<<std::setprecision(n)<<f
#define all(x) x.begin(), x.end()
#define vpll vector<pair<ll,ll>>
#define check(x)    cout << ((x) ? "YES\n" : "NO\n")
#define REP(i,a,n) for(ll i=a;i<n;i++)
#define REPRE(a,b,i)   for(int i=a-1;i>=b;i--)
#define CASE(x, y) cout << "Case #" << x << ":" << " \n"[y]
#define M_PI 3.14159265358979323846
#define deb(x) cout << #x << "=" << x << endl
#define deb2(x, y) cout << #x << "=" << x << "," << #y << "=" << y << endl
 const int M_1=1e9+7;
 const int M_2=998244353;
 const int INF = 1000000000000000000;
  const int N =10;
   int log2n(ll n) {
return (63-__builtin_clzll(n));
}
  int ask(int x)//for interactive 
{
    cout << "?" << x << endl;
 
    int res;
    cin >> res;
    return res;
}
//****************GRAPHS********************
vll g[N];
vll depth(N,0);
ll LOG=log2n(N)+1;
vvi up(N,vll(log2n(N)+1,0));
int timer;
vll tin, tout;
void reset(ll n)
{
    REP(i,1,n+1)
    {
    g[i].clear();
    depth[i]=0;
    }
}
void dfs_lift(ll a,ll par)//before calling make sure of declaring up[root][0]=root;
{
    tin[a]=++timer;
    for(auto child:g[a])
    {
        if(child==par)continue;
        depth[child]=depth[a]+1;
        up[child][0]=a;//a is direct parent of child
        REP(i,1,LOG)
        {
            up[child][i]=up[up[child][i-1]][i-1]; 
        }
        dfs_lift(child,a);
    }
    tout[a]=++timer;
}
bool is_ancestor(int u, int v)
{
  return tin[u] <= tin[v] && tout[u] >= tout[v];
}
ll lca(ll a,ll b)
{
    if(depth[a]<depth[b])swap(a,b);
    ll use=depth[a]-depth[b];
    ll co=0;
    while(use>0)
    {
        if(use&1)a=up[a][co];
        use/=2;
        co++;
    }
    // now both at same level 
    if(a==b)return a;//IMP.
    for(int j=LOG-1;j>=0;j--)
    {
        if(up[a][j]!=up[b][j])
        {
            a=up[a][j];
            b=up[b][j];
        }
    }
    return up[a][0];
}
void tree_start(ll root,ll n)
{
 up[root][0]=root;
  tin.resize(n+1);
  tout.resize(n+1);
  timer = 0;
  dfs_lift(root,-1);
}
//DSU
// int par[N];
// int siz[N];
// void make(int v)
// {
//     par[v]=v;
//     siz[v]=1;
// }
// int find(int v)
// {
//     if(v==par[v])return v;
//     return (par[v]=find(par[v]));
// }
// void unio(int a,int b)
// {
//     a=find(a);
//     b=find(b);
//     if(a==b)return;
//     if(siz[a]<siz[b])swap(a,b);
//     siz[a]+=siz[b];
//     par[b]=a;// a is larger here 
// }
//**************RMQ'S********************************
struct Sparse{
vector<vll> st; 
void constst(vll& v){
    //Constructing Sparse Table 
    ll n = v.size();
    ll k = log2(n) + 1;
    st.assign(n,vll (k,0));
    for (ll i=0;i<n;i++) st[i][0]=v[i];
    for (ll j=1;j<=k;j++){
        for (ll i=0;i+(1<<j)<=n;i++){
            st[i][j]=max(st[i][j-1],st[i+(1<<(j-1))][j-1]); // change function here
        }
    }
}
 
ll queryst(ll l,ll r){
    // Query for [l,r] 0-indexed
    ll j = log2(r-l+1);
    return max(st[l][j],st[r-(1<<j)+1][j]); //change function here
}
};
struct fen{
vll fenwick;
void init(ll n)
{
    fenwick.assign(n,0);
}
ll sum_fen(ll r)
{
    ll ans=0;
    while(r>0)
    {
        ans+=fenwick[r];
        r-=(r&(-r));
    }
    return ans;
}
void update_fen(ll i,ll x,ll n)
{
    while(i<=n)
    {
        fenwick[i]+=x;
        i+=(i&(-i));
    }
}
};
struct  segtree {//can be built in linear time 
    ll size;
    vector<ll>sums;
    void init(int n)
    {
        size=1;
        while(size<n)size*=2;
        sums.assign(2*size,0);//number of elements would be twice 
    }
     void build(vll &a,ll x,ll lx,ll rx)// x is always needed to get starting point and call recursion 
    {
        if((rx-lx)==1)
        {
            if(lx<a.size())
            {
                sums[x]=a[lx];
            }
            return ;
        }
        ll m=(lx+rx)/2;
        build(a,((2*x)+1),lx,m);
        build(a,((2*x)+2),m,rx);
        sums[x]=sums[(2*x)+1]+sums[(2*x)+2];
    }
    void build(vll &a)
    {
        build(a,0,0,size);
    }
    void set(int i,int v,int x,int lx,int rx)//rx is not included 
    {
        if((rx-lx)==1)
        {
            sums[x]=v;
            return ;
        }
        int m=(lx+rx)/2;
        if(i<m)set(i,v,(2*x)+1,lx,m);// child left range from lx->m (m not included )
        else set(i,v,(2*x)+2,m,rx);
        sums[x]=sums[(2*x)+1]+sums[(2*x)+2];//setting the sum right just as in post order dfs 
    }

    void set(int i,int v)
    {
        set(i,v,0,0,size);// as would start fron root node would have entire array as segment 
    }
    ll sum(ll l,ll r,ll x,ll lx,ll rx)
    {
        if((lx>=r)||(l>=rx)) return 0; //rx not included 
        if((lx>=l)&&(rx<=r))return sums[x];
        ll m=(lx+rx)/2;
        ll use_1=sum(l,r,((2*x)+1),lx,m);
        ll use_2=sum(l,r,((2*x) +2),m,rx);
        return (use_1+use_2);
    }
    ll sum(ll l,ll r)
    {
        return sum(l,r,0,0,size); 
    }
};
 //*************NUMBER THEORY************************
const int MAX=1e5+10;
bool v[MAX];
int len, sp[MAX];
void Sieve(){
for (int i = 2; i < MAX; i += 2)sp[i] = 2;//even numbers have smallest prime factor 2
for (ll i = 3; i < MAX; i += 2){
if (!v[i]){
sp[i] = i;
for (ll j = i; (j*i) < MAX; j += 2){
if(!v[j*i])v[j*i] = true, sp[j*i] = i;
}
}
}
}
//GIVES PRIME FACTORS OF A NUMBER IN log(n)
int primefactor(int x)
{
   map<int,int>m;
    while(x>1)
    {
        int prime_factors=sp[x];
        while(x%prime_factors==0)
        {
            x/=prime_factors;
            m[prime_factors]++;
        }
    }
   return m.size();
}
// Recursive function to return gcd of a and b
long long gcd(long long  a, long long  b)
{
  if (b == 0)
    return a;
  return gcd(b, a % b);
}
ll extgcd(ll a, ll b, ll& x, ll& y) {//extended gcd 
    x = 1, y = 0; //xa+yb=a at all times
    ll q, x1 = 0, y1 = 1; //x1a+y1b=b at all times
    while (a&&b) {
        if(a>b) {
            q = a/b;
            x -= q*x1;
            y -= q*y1;
            a -= q*b;
        } else {
            q = b/a;
            x1 -= q*x;
            y1 -= q*y;
            b -= q*a;
        }
    }
    if(a==0){
        x=x1;
        y=y1;
        return b;
    }
    return a;
}
// Function to return LCM of two numbers
long long lcm(int a, int b)
{
    return (a / gcd(a, b)) * b;
}
ll binexpitr(ll a,ll b,int m)
{
ll ans=1;
while(b)
{
if(b&1)ans=((ans%m)*(a%m))%m;
b>>=1;
a=((a%m)*(a%m))%m;
}
return ans;
}
ll mod_inverse(ll a,ll m)//gives mod-inverse of a number 
{return(binexpitr(a,m-2,m));}
bool is_root_prime(int n)//tells if a number is prime or not O(root n)
{
    for (int i = 2; i <= sqrt(n); i++)
    {
        if (n % i == 0)
        {
            return false;
        }
    }
    return true;
}
long long moduloMultiplication(long long a, long long b,
                               long long mod)
{
    long long res = 0; // Initialize result
 
    // Update a if it is more than
    // or equal to mod
    a %= mod;
 
    while (b) {
        // If b is odd, add a with result
        if (b & 1)
            res = (res + a) % mod;
 
        // Here we assume that doing 2*a
        // doesn't cause overflow
        a = (2 * a) % mod;
 
        b >>= 1; // b = b / 2
    }
 
    return res;
}
/*ll comb(ll a,ll b)// be sure of declaring a fact array before using 
{
ll use=fact[a];
ll use_2=(fact[b]*fact[a-b])%M_1;
ll use_3=binexpitr(use_2,M_1-2,M_1);
return((use*use_3)%M_1);
}*/
//begin
  void solve()
{
    ll n,k;cin>>n>>k;
    vector<ll>pref(n+1,0);
    vector<ll>curr(n+1,0);
    vector<ll>v;
    REP(i,0,n){
        ll x;cin>>x;
        pref[x]++;
        curr[x]++;
        v.push_back(x);
    }
    REP(i,1,n+1)pref[i]+=pref[i-1];
    ll l=0;
    ll r=n-1;
    vll cons;
    while(r>l){
        if(v[r]==v[l]){
            r--;
            l++;
            continue;
        }
        if(v[r]>v[l]){
            cons.push_back(v[r]);
            r--;
        }
        else{
             cons.push_back(v[l]);
             l++;
        }
    }
    sort(all(cons));
    reverse(all(cons));
    for(auto e:cons){
        ll val=pref[e-1]+curr[e];
        if(val<k){
            cout<<"NO"<<endl;
            return;
        }
        curr[e]--;
    }
    cout<<"YES"<<endl;
}
signed main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout<<setprecision(30);
    int t;
    cin>> t;
    while(t--)
    {
      solve();
    }
    return 0;}
//*************POINTS TO REMEMBER *************************
//1)Don't use accumalte/While using inbuilt functions make sure data type is uniform 
//2)CHECK FOR EDGE CASES
//3)CHECK INDEXING /You can't apply sort on an empty vector->would give runtime error
//4)MAKE SURE OF NEGATIVE VALUES
//5)Do not delete elements of a set while iterating it  
//6) Are you using i in all loops? Are the i's conflicting?
//7)In Dijkstra  in the set there can be different distance value for same vertex 