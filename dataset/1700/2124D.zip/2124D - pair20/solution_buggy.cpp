#include<bits/stdc++.h>
using namespace std ;

bool solve_it(vector<int> arr, int n, int k){

    
    vector<int> arr2 = arr; 
    
    sort(arr2.begin(), arr2.end()) ; 
    
    sort(arr2.begin(), arr2.end()) ; 
    
    map<int, int> mp ; 
    
    for(int i = 0; i < k-1; i++){
        mp[arr2[i]]++ ; 
    }
    

    vector<int> arr3;   
    // cout << k << endl; 
    if(mp.size() == 0){

        return true ;
    }
    int maximum = -1; 
    for(int i = 0; i < n; i++){
        if(mp.find(arr[i]) != mp.end()){
            arr3.push_back(arr[i]) ; 
            maximum = max(maximum, arr[i]) ; 
        }
    }
    



    
    int extra = (int)arr3.size() - (k-1) ; 
    
    
    vector<int> ans(k-1) ; 
    
    int i = 0, j = (int)arr3.size() - 1; 
    bool faulty = false ; 
    
    
    int idx = 0 ; 

    int tot_eles = 0 ; 
    while(i <= j){
        if(arr3[i] == arr3[j]){
            if(i != j) tot_eles += 2; 
            else tot_eles += 1; 
            i++ ; 
            j--;
        }
        else if(arr3[i] == maximum){
            i++ ; 
        }
        else if(arr3[j] == maximum){
            j-- ; 
        }
        else{
            faulty = true ;
            break; 
        }
    }
    
    if(faulty || tot_eles != k-1){
        return false; 
    } else{
        return true ; 
    }
}

void solve(){

    int n, k; 
    cin >> n >> k; 
    
    vector<int> arr(n) ; 
    
    for(int i = 0; i < n; i++) cin >> arr[i] ; 
    
    bool ans1 = solve_it(arr, n, k) ; 
    bool ans2 = false; 
    if(k%2 == 1) ans2 = solve_it(arr, n, k+1) ;

    if(ans1 || ans2) cout << "YES" << endl; 
    else cout << "NO" << endl; 
    
}

int main(){
    int t ;
    cin >> t; 
    while(t--){
        solve();  
    }
}