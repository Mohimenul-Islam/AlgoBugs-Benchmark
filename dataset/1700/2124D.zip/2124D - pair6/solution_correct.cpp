//#include <budka>
#include <vector>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <bitset>
#include <iomanip>
#include <complex>
#include <random>
#include <stdio.h>
#include <time.h>
#include <string>
#include <queue>
#include <stack>
#include <map>
#include <cmath>
#include <memory>
#include <set>
#include <deque>
#include <unordered_set>
#include <unordered_map>
#include <functional>
//#include <ext/pb_ds/assoc_container.hpp>

#define all(x) x.begin(), x.end()
#define dall(x) x.rbegin(), x.rend()
#define forv(g, obj) for(auto& g: obj)
#define forn(i, idx, n) for(int i = idx; i <= n; ++i)
#define nforn(i, idx, n) for (int i = idx; i < n; ++i)
#define dforn(i, idx, n) for(int i = idx; i >= n; --i)
#define yes cout << "yes" << endl
#define no  cout << "no" << endl
#define pli pair<ll, int>
#define pil pair<int, ll>
#define vl vector<ll>
#define vvl vector<vector<ll>>
#define vi vector<int>
#define vvi vector<vector<int>>
#define vpii vector<pair<int, int>>
#define vpli vector<pli>
#define vpil vector<pil>
#define vs vector<string>
#define vpll vector<pair<ll, ll>>
#define vvpll vector<vector<pair<ll, ll>>>
#define vvpii vector<vector<pair<int, int>>>
#define vvpil vector<vector<pair<int, ll>>>
#define vvpli vector<vector<pair<ll, int>>>
#define vvvi vector<vector<vector<int>>>
#define vvvl vector<vector<vector<ll>>>
#define print(obj) cerr << obj << endl;

#define pii pair<int, int>
#define fst first
#define piii pair<int, pair<int, int>>
#define sec second
#define pll pair<ll, ll>

#define sz(obj) (int)(obj.size())

#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using namespace std;
using ll = int64_t;
//using namespace __gnu_pbds;

//typedef tree<int,null_type,less<int>, rb_tree_tag,
//tree_order_statistics_node_update> ordered_set;


template<typename T, typename U>
ostream& operator << (ostream& os, const pair<T, U>& a) {
    os << a.first << ' ' << a.second;
    return os;
}

template<typename T, typename U>
istream& operator >> (istream& is, pair<T, U>& a) {
    is >> a.first >> a.second;
    
    return is;
}


const double PI = 3.14159265;
const int iinf = 1e9;
const ll inf = 1e18;
const double eps = 1e-10;
const string abc = "abcdefghijklmnopqrstuvwxyz";

template<typename T>
T gcd(T a, T b)
{
    while(a > 0 && b > 0)
    {
        if(a > b) a %= b;
        else b %= a;
    }

    return a | b;
}

template<typename T>
T nok(T a, T b)
{
    return (a*b)/gcd(a, b);
}

template<typename T>
T binPow(T x, T y, T mod) {
    T ans = 1;
    
    while (y) {
        if (y & 1LL) ans = (ans * x) % mod;
        x = (x * x) % mod;
        y >>= 1LL;
    }
    
    return ans;
}





void solve() {
    int n;
    cin >> n;
    
    vi t(n + 1);
    auto add = [&] (int pos, int val) {
        for (; pos <= n; pos += pos & -pos)
            t[pos] += val;
    };
    
    auto get = [&] (int r) {
        int ans = 0;
        
        for (; r > 0; r -= r & -r)
            ans += t[r];
        
        return ans;
    };
    
    
    int k;
    cin >> k;
    
    vi a(n);
    forv(el, a) {
        cin >> el;
        add(el, 1);
    }
    
    int l = 0, r = n - 1;
    while (l < r) {
        bool ok1 = get(a[l]) >= k, ok2 = get(a[r]) >= k;
        
        if (a[l] == a[r]) {
            ++l;
            --r;
        } else if (ok1 && ok2) {
            if (a[l] < a[r]) {
                --r;
                add(a[r + 1], -1);
            } else {
                ++l;
                add(a[l - 1], -1);
            }
        }else if (ok1) {
            ++l;
            add(a[l - 1], -1);
        } else if (ok2) {
            --r;
            add(a[r + 1], -1);
        } else {
            no;
            return;
        }
    }
    
    yes;
}

    



 


/*   /\_/\
*   (= ._.)
*   / >  \>
*/

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    
 #ifdef _DEBUG
    freopen("input.txt", "rt", stdin);
//    freopen("output.txt", "wt", stdout);
 #endif
    
    int t = 1;
    cin >> t;
    
    while (t --> 0)
        solve();

    return 0;
}
