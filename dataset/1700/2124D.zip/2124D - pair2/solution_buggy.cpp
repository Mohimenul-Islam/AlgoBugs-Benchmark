#include<bits/stdc++.h>
using namespace std;
bool check(vector<int> a)
{
	int n=a.size();
	for(int i=0;i<n/2;i++)
		if(a[i]!=a[n-1-i])
			return false;
	return true;
}
void solve()
{
	int n,k;
	cin>>n>>k;
	vector<int> a(n);
	map<int,int> mp;
	bool ok=false;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		mp[a[i]]++;
		if(mp[a[i]]>=k) 
			ok=true;
	}
	if(ok)
	{
		cout<<"YES\n";
		return;
	}
	if(check(a)) 
	{
		cout<<"YES\n";
		return;
	}
	vector<int> b=a;
	sort(b.begin(),b.end());
	int val=b[k-2];
	int cnt=0;
	for(int i=0;i<n;i++)
		if(a[i]<val) 
			cnt++;
	int need=(k-1)-cnt;
	vector<int> c;
	for(int i=0;i<n;i++)
	{
		if(a[i]<val) 
			c.push_back(a[i]);
		else if(a[i]==val&&need>0)
		{
			c.push_back(a[i]);
			need--;
		}
	}
	if(check(c)) 
		cout<<"YES\n";
	else 
		cout<<"NO\n";
}

signed main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	int t;
	cin>>t;
	while(t--)
		solve();
	return 0;
}