#include<bits/stdc++.h>
using namespace std;

void solve()
{
	int n,k;
	cin>>n>>k;
	vector<int> a(n);
	for(int i=0;i<n;i++) cin>>a[i];
	if(k==1)
	{
		cout<<"YES\n";
		return;
	}
	vector<int> b=a;
	sort(b.begin(),b.end());
	int val=b[k-2];
	vector<int> c;
	for(int x:a)
		if(x<=val)
			c.push_back(x);
	int add=c.size()-k+1;
	int l=0,r=c.size()-1;
	bool ok=true;
	while(l<r)
	{
		if(c[l]!=c[r])
		{
			if(!add)
			{
				ok=false;
				break;
			}
			if(c[l]==val)
			{
				l++;
				add--;
			}
			else if(c[r]==val)
			{
				r--;
				add--;
			}
			else
			{
				ok=false;
				break;
			}
			continue;
		}
		l++,r--;
	}
	if(ok) cout<<"YES\n";
	else cout<<"NO\n";
}

signed main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	int t;
	cin>>t;
	while(t--)
		solve();
	return 0;
}