#include <bits/stdc++.h>
#define ll long long int
using namespace std;

int main() {
    // your code goes here
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    ll t;
    cin>>t;
    
    while(t--){
        ll n,k;
        cin>>n>>k;

        vector<ll> a(n);
        for(int i=0; i<n; i++){
            cin>>a[i];
        }
        
        map<ll,ll> mp;
        priority_queue<ll> pq;
        for(int i=0; i<k; i++){
            pq.push(a[i]);
        }

        mp[pq.top()]++;
        pq.pop();

        for(int i=k; i<n; i++){
            pq.push(a[i]);

            ll x=pq.top();
            pq.pop();

            mp[x]++;
        }

        ll i=0, j=n-1;
        set<ll> st;
        ll c=0;
        while(i<j){
            if(a[i]==a[j]){
                i++;
                j--;
            }
            else{
                if(mp.count(a[i]) && mp.count(a[j])){
                    st.insert(i);
                    st.insert(j);
                    mp[a[i]]--;
                    mp[a[j]]--;
                    if(mp[a[i]]==0){
                        mp.erase(a[i]);
                    }
                    if(mp[a[j]]==0){
                        mp.erase(a[j]);
                    }
                    i++;
                    j--;
                }
                else if(mp.count(a[i])){
                    st.insert(i);
                    mp[a[i]]--;
                    if(mp[a[i]]==0){
                        mp.erase(a[i]);
                    }
                    i++;
                }
                else if(mp.count(a[j])){
                    st.insert(j);
                    mp[a[j]]--;
                    if(mp[a[j]]==0){
                        mp.erase(a[j]);
                    }
                    j--;
                }
                else{
                    c++;
                    break;
                }
            }
        }
        if(c){
            cout<<"NO"<<endl;
        }
        else{
            vector<ll> v;
            for(int i=0; i<n; i++){
                if(!st.count(i)){
                    v.push_back(a[i]);
                }
            }

            ll i=0, j=v.size()-1;
            while(i<j){
                if(v[i]==v[j]){
                    i++;
                    j--;
                }
                else{
                    c++;
                    break;
                }
            }
            if(c){
                cout<<"NO"<<endl;
            }
            else{
                cout<<"YES"<<endl;
            }
        }
    }    
}