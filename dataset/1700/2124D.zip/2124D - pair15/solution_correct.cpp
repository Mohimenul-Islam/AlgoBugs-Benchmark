#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;

typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> pbds; //// find_by_order, order_of_key
typedef long long int ll;

const ll MOD = 1e9 + 7;

// Fast exponentiation (base^exp % MOD)
ll modexp(ll base, ll exp, ll mod = MOD) {
    ll result = 1;
    base %= mod;
    while (exp > 0) {
        if (exp & 1) result = result * base % mod;
        base = base * base % mod;
        exp >>= 1;
    }
    return result;
}

// Modular inverse (works when MOD is prime)
ll modinv(ll x, ll mod = MOD) {
    return modexp(x, mod - 2, mod);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--) {
        ll n,k;
        cin>>n>>k;
        vector<ll>a(n);
        for(int i = 0; i < n; i++) {
            cin>>a[i];
        }
        if(k==1){
            cout<<"Yes"<<endl;
            continue;
        }
        vector<ll>b=a;
        sort(b.begin(),b.end());
        ll cnt=0;
        for(int i=k-1;i<n;i++){
            if(b[i]==b[k-1]){
                cnt++;
            }
        }
        vector<ll>temp;
        for(int i=0;i<n;i++){
            if(a[i]<=b[k-1]){
                temp.push_back(a[i]);
            }
        }
       
        ll check=0;
        ll i=0,j=temp.size()-1;
        
        while(i<=j){
            if(temp[i]==temp[j]){
                i++;
                j--;
            }
            else if(temp[i]==b[k-1]){
                i++;
                cnt--;
            }
            else if(temp[j]==b[k-1]){
                j--;
                cnt--;
            }
            else{
                cnt=-1;
                break;
            }
        }
        
        if(cnt>=0){
            cout<<"Yes";
        }
        else{
            cout<<"No";
        }
        cout<<endl;
        
        
    }
    return 0;
}