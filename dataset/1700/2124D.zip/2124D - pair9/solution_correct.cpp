#include "bits/stdc++.h"
using namespace std;

#define int long long
const int MOD = 998244353;

void solve(){
    int n,k;
    cin >> n >> k;
    vector<int> a(n), a_copy(n);
    for(int i = 0 ; i < n ; i++) cin >> a[i];
    a_copy = a;
    sort(a_copy.begin(), a_copy.end());
    vector<int> b;
    int fuc = a_copy[k-2];
    for(int i = 0 ; i < n ; i++) {
        if(a[i] <= fuc) b.push_back(a[i]);
    }
    if (k == 1) {
        cout << "YES" << endl;
        return;
    }
    // for(auto &x : b) cout << x << " ";
    // cout << endl;
    int si = b.size();
    int l = 0;
    int r = si-1;
    int spar = si-k+1;
    while(l < r){
        if(b[l] != b[r]){

            if(spar == 0){
                cout << "NO" << endl;
                return;
            }
            
            if(b[l] == fuc){
                l++;
                spar--;
            }
            else if(b[r] == fuc){
                r--;
                spar--;
            }
            else{
                cout << "NO" << endl;
                return;
            }
        }
        else{
            l++;
            r--;
        }
    }
    cout << "YES" << endl;
}

int32_t main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin >> t;
    while(t--)
    solve();
}