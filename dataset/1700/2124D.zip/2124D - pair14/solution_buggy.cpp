#include <bits/stdc++.h>

using namespace std;

int main()
{
    int n, k, t;
    cin >> t;
    while(t--){
        cin >> n >> k;
        int sorted_a[n+1]={}, a[n+1]={};
        for(int i=1; i<=n; i++){
            cin >> a[i];
            sorted_a[i]=a[i];
        }
        sort(sorted_a+1, sorted_a+n+1);
        int mark[n+1]={}, onescnt=0, ones[n+1]={}; //1->non-deletable, 0->all deleted, 2->a fixed number of this value must be kept
        if(1<k) mark[1]=1;
        else{
            cout << "YES" << "\n";
            continue;
        }
        //marking
        for(int i=1; i<=n; i++){
            if(sorted_a[i]>sorted_a[k-1]){
                break;
            }
            if(sorted_a[i]!=sorted_a[k-1]){
                mark[sorted_a[i]]=1;
            }
            else{
               mark[sorted_a[i]]=2;
            }
        }
        //saving positions of elements marked as 1 into an array
        for(int i=1; i<=n; i++){
            if(mark[a[i]]==1){
                onescnt++;
                ones[onescnt]=i;
            }
        }
        if(onescnt==0){
            mark[sorted_a[k-1]]=1;
            for(int i=1; i<=n; i++){
                if(mark[a[i]]==1){
                    onescnt++;
                    ones[onescnt]=i;
                }
            }
        }
        //check if the non-deletable (elements marked as 1) form a palindrome
        int pivot, palin=1, l, r;
        if(onescnt%2==0){
            pivot=onescnt/2;
            l=pivot, r=pivot+1;
        }
        else{
            pivot=onescnt/2+1;
            l=pivot, r=pivot;// l, r works on ones[]
        }
        while(palin==1){
            if(a[ones[l]]!=a[ones[r]]){
                palin=0;
                break;
            }
            else{
                if(l-1>=1) l--;
                if(r+1<=onescnt) r++;
            }
            if(l-1<1 && r+1>onescnt){
                break;
            }
        }
        if(palin==0){
            cout << "NO" << "\n";
            continue;
        }
        else{
            //check if with elements marked as 2 we can make a palindrome
            if(onescnt%2==0){
                pivot=onescnt/2;
                l=ones[pivot]; r=ones[pivot+1];
            }
            else{
                pivot=(onescnt/2)+1;
                l=ones[pivot]; r=l; // l, r still works on a[]
            }
            //cout << pivot << " " << l << " " << r << " " << onescnt << "\n";
            int rcnt=0, lcnt=0, keep=k-onescnt-1;
            palin=1;
            for(int i=l+1; i<r; i++){
                if(mark[a[i]]==2){
                    keep=max(0, keep-1);
                }
            }
            if(keep==0){
                cout << "YES" << "\n";
                continue;
            }
            while(palin==1){
                while(l>1 && mark[a[l-1]]!=1){
                    l--;
                    if(mark[a[l]]==2) lcnt++;
                }
                while(r<n && mark[a[r+1]]!=1){
                    r++;
                    if(mark[a[r]]==2) rcnt++;
                }
                keep=max(0, keep-2*min(rcnt, lcnt));
                //cout << rcnt << " " << lcnt << "\n";
                if((r+1>n && l-1<1) || keep==0){
                    palin=0;
                    break;
                }
                rcnt=0;
                lcnt=0;
                l--, r++;
            }
            if(keep>0) cout << "NO" << "\n";
            else cout << "YES" << "\n";
        }
    }
}
