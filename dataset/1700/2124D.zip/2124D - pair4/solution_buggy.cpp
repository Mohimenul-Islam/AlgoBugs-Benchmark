#include <iostream>
#include <vector>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <algorithm>
#include <string>
#include <functional>
using namespace std;
typedef long long ll;
#define PLL pair<ll,ll>
#define fi first
#define se second 
const ll P=998244353;
void Refra1n()
{
    ll n,k;cin>>n>>k;
    vector<ll>a(n+1);
    vector<PLL>b(n+1);
    for(ll i=1;i<=n;i++){
        cin>>a[i];
        b[i].fi=a[i];
        b[i].se=i;
    }
    sort(b.begin()+1,b.end());
    if(b[k-1].fi==b[k].fi){
        for(ll i=1;i<=n;i++){
            if(a[i]>b[k].fi)a[i]=-1;
        }
        ll l=1,r=n,cost=0;
        ll f=1;
        while(l<=r){
            while(a[l]==-1){
                l++;
                if(l>r)break;
            }
            while(a[r]==-1){
                r--;
                if(l>r)break;
            }
            if(l>r)break;
            //cout<<a[l]<<' '<<a[r]<<'\n';
            if(a[l]!=a[r]){
                if(a[l]==b[k].fi){
                    l++;
                    cost++;
                    continue;
                }
                if(a[r]==b[k].fi){
                    r--;
                    cost++;
                    continue;
                }
                f=0;
                break;
            }
            l++,r--;
        }
        if(f&&b[k-1+cost].fi==b[k-1].fi)cout<<"YES"<<'\n';
        else cout<<"NO"<<'\n';
    }else{
        for(ll i=k;i<=n;i++){
            a[b[i].se]=-1;
        }
        ll l=1,r=n;
        ll f=1;
        while(l<=r){
            while(a[l]==-1){
                l++;
                if(l>r)break;
            }
            while(a[r]==-1){
                r--;
                if(l>r)break;
            }
            if(l>r)break;
            //cout<<a[l]<<' '<<a[r]<<'\n';
            if(a[l]!=a[r]){
                f=0;
                break;
            }
            l++,r--;
        }
        if(f)cout<<"YES"<<'\n';
        else cout<<"NO"<<'\n';
    }


}

int main()
{
    ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr);
    int t;cin>>t;
    while(t--)
    Refra1n();
    //cout<<"copyright Refra1n"<<endl;
    return 0;
}