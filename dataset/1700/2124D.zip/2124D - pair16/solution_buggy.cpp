#include <bits/stdc++.h>
using namespace std;
int main() {
  int t;
  cin >> t;
  while (t--) {
    int n, k;
    cin >> n >> k;
    vector<int> a(n);
    for (auto &x : a)
      cin >> x;
    vector<int> b = a;
    sort(b.begin(), b.end());
    int mx = -1;
    mx = b[k - 1];
    vector<int> p;
    for (int i = 0; i < n; i++) {
      if (a[i] <= mx)
        p.push_back(a[i]);
    }
    int l = 0, r = p.size() - 1;
    int fl = 0;
    vector<int> g(p.size(), -1);
    while (l <= r) {
      if (p[l] != mx && p[r] != mx) {
        if (p[l] != p[r]) {
          fl = 1;
          break;
        } else {
          g[l] = p[l];
          g[r] = p[r];
          l++;
          r--;
        }
      } else if (p[l] != mx || p[r] != mx) {
        if (p[l] != mx) {
          while (p[r] == mx)
            r--;
          if (l <= r && p[l] == p[r]) {
            g[l] = p[l];
            g[r] = p[r];
          }
        } else {
          while (p[l] == mx)
            l++;
          if (l <= r && p[l] == p[r]) {
            g[l] = p[l];
            g[r] = p[r];
          }
        }
      } else {
        g[l] = mx;
        g[r] = mx;
        r--;
        l++;
      }
    }
    vector<int> ans;
    for (int i = 0; i < p.size(); i++) {
      if (g[i] != -1)
        ans.push_back(g[i]);
    }
    if (ans.size() >= k - 1) {
      cout << "YES\n";
    } else {
      cout << "NO\n";
    }
  }
}