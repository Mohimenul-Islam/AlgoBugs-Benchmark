#pragma GCC optimize("O2")
#pragma GCC optimize ("unroll-loops")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,avx2,fma")

#include <bits/stdc++.h>
// #include <bits/extc++.h> 
// #include <ext/pb_ds/assoc_container.hpp>
// #include <ext/pb_ds/tree_policy.hpp>

#include <iostream>
#include <vector>
#include <set> 
#include <map> 
#include <unordered_map> 


#define fix(f,n) std::fixed<<std::setprecision(n)<<f

typedef long long ll;

int dx[4] = {1, 0, -1, 0}; 
int dy[4] = {0, -1, 0, 1}; 
char direction[4] = {'D', 'L', 'U', 'R'}; 
 
using namespace std;
// using namespace __gnu_pbds;
 
// template <typename T>
// using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
 
// template <typename T>
// using ordered_multiset = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>; 

#ifdef ADD_TRACE
#include "utils/debug.h"
#define trace(...) cout<<"Line:"<<__LINE__<<" ", __f(#__VA_ARGS__, __VA_ARGS__)
#else
#define trace(...)
#endif

// struct edge{
// 	int u, v, w;

// 	int other(int node) {
// 		return u ^ v ^ node; 
// 	}

// 	bool operator < (edge other) const {
// 		return w < other.w; 
// 	}
// };

// const int RANDOM = chrono::high_resolution_clock::now().time_since_epoch().count();
// struct chash { // To use most bits rather than just the lowest ones:
// 	const uint64_t C = ll(4e18 * acos(0)) | 71; // large odd number
// 	ll operator()(ll x) const { return __builtin_bswap64((x^RANDOM)*C); }
// };

// mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

// ll getRand(ll l, ll r) {
// 	uniform_int_distribution<ll> uid(l, r); 
// 	return uid(rng); 
// }

template<typename T> 
T gcd(T a, T b) {
	return b == 0 ? a: gcd(b, a % b); 
}

void solve() {
	int n, k; 
	cin >> n >> k;
	vector<int> a(n); 
	for(int i = 0; i < n; i++) {
		cin >> a[i]; 
	} 
	if (k == 1 ) {
		cout << "YES\n"; 
		return; 
	}

	auto srt = a; 
	sort(srt.begin(), srt.end()); 
	int bnd = srt[k-2]; 
	vector<int> eff;
	vector<int> with;  
	for(int i = 0; i < n; i++) {
		if(a[i] <= bnd) eff.push_back(a[i]);
		if (a[i] < bnd) with.push_back(a[i]); 
	} 

	bool poss = true; 
	auto rev = with; 
	reverse(rev.begin(), rev.end()); 
	for(int i = 0; i < with.size(); i++) { 
		if (rev[i] != with[i]) {
			poss = false; 
		}
	}

	if(!poss) {
		cout << "NO\n"; 
		return; 
	}

	rev = eff; 
	reverse(rev.begin(), rev.end());
	int revind = -1; 
	int effind = -1; 
	vector<int> revs, effs;  
	for(int i = 0; i < eff.size(); i++) {
		if (eff[i] < bnd) {
			effind++; 
		} else {
			effs.push_back(effind); 
		}

		if (rev[i] < bnd) {
			revind++; 
		} else {
			revs.push_back(revind); 
		}
	} 

	trace(effs); 
	trace(revs); 

	int j = 0;
	int match = 0;  
	for(int i = 0; i < effs.size(); i++) {
		while (j < revs.size() && revs[j] < effs[i]) j++; 

		if (j < revs.size() && revs[j] == effs[i]) {
			match++; 
			j++;
		}
	}

	cout << (match + with.size() >= k-1 ? "YES": "NO") << "\n"; 
}
 
int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	int t = 1;
	cin >> t;
	for (int i = 0; i < t; i++) {
		solve();
	}
	return 0;
}