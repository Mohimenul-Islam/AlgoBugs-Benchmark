#include <bits/stdc++.h>
using namespace std;
#define int long long
void solve(int t,int T) {
    int n,k;
    cin>>n>>k;
    vector<int> v(n);
    for(int i=0;i<n;i++) cin>>v[i];
    vector<int> v1=v;
    sort(v1.begin(),v1.end());
    vector<int> freq(n+1),freq2(n+1);
    for(int i=0;i<n;i++) freq2[v[i]]++;
    for(int i=k-1;i<n;i++) freq[v1[i]]++;
    int l=0,h=n-1;
    while(l<h){
        if(v[l]==v[h]){
            l++,h--;
            freq2[v[l]]--,freq2[v[h]]--;
        }
        else{
            if(!freq[v[l]]&&!freq[v[h]]){
                cout<<"NO";
                return;
            }
            else if(freq[v[l]]&&freq[v[h]]){
                if(freq2[v[l]]>1&&freq2[v[h]]>1){
                    freq[v[l]]--,freq[v[h]]--;
                    freq2[v[l]]--,freq2[v[h]]--;
                    l++,h--;
                }
                else if(freq2[v[l]]>1){
                    h--,freq[v[h]]--,freq2[v[h]]--;
                }
                else if(freq2[v[h]]>1){
                    l++,freq[v[l]]--,freq2[v[l]]--;
                }
                else{
                    freq[v[l]]--,freq[v[h]]--;
                    freq2[v[l]]--,freq2[v[h]]--;
                    l++,h--;
                }
            }
            else if(freq[v[l]]){
                freq[v[l]]--,l++;
                freq2[v[l]]--;
            }
            else{
                freq[v[h]]--,h--;
                freq2[v[h]]--;
            }
        }
    }
    cout<<"YES";
}
signed main() {
    int t;
    cin>>t;
    int T=t;
    while(t--) {
        solve(t,T);
        cout<<endl;
    }
}