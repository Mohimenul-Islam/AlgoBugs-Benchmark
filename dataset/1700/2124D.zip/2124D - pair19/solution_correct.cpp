#include <bits/stdc++.h>
using namespace std;
#define int long long
void solve(int t,int T) {
    int n,k;
    cin>>n>>k;
    vector<int> v(n);
    for(int i=0;i<n;i++) cin>>v[i];
    vector<int> v1=v;
    sort(v1.begin(),v1.end());
    vector<int> freq(n+1),req(n+1);
    for(int i=0;i<k-1;i++) req[v1[i]]++;
    for(int i=k-1;i<n;i++) freq[v1[i]]++;
    int l=0,h=n-1;
    while(l<h){
        if(v[l]==v[h]){
            l++,h--;
        }
        else{
            if(!freq[v[l]]&&!freq[v[h]]){
                cout<<"NO";
                return;
            }
            else if(freq[v[l]]&&freq[v[h]]){
                if(req[v[l]]&&!req[v[h]]){
                    freq[v[h]]--;
                    h--;
                }
                else if(req[v[h]]&&!req[v[l]]){
                    freq[v[l]]--;
                    l++;
                }
                else{
                    freq[v[l]]--;
                    l++;
                }
            }
            else if(freq[v[l]]){
                freq[v[l]]--,l++;
            }
            else{
                freq[v[h]]--,h--;
            }
        }
    }
    cout<<"YES";
}
signed main() {
    int t;
    cin>>t;
    int T=t;
    while(t--) {
        solve(t,T);
        cout<<endl;
    }
}