#include "bits/stdc++.h"
#include<algorithm>
using namespace std;
#include <ext/pb_ds/assoc_container.hpp> 
#include <ext/pb_ds/tree_policy.hpp> 
using namespace __gnu_pbds;
#define int long long
#define all(v) v.begin(), v.end()
#define vin(v,n) vector<int>v(n);for(int i=0;i<n;i++){cin>>v[i];}
mt19937_64 rng(chrono::steady_clock::now().time_since_epoch().count());
// #define ordered_set tree<int, null_type,less<int>, rb_tree_tag,tree_order_statistics_node_update>
typedef tree<pair<int,int>,null_type,less<pair<int,int>>,rb_tree_tag,tree_order_statistics_node_update> ordered_multiset;
// const int MOD = 998244353;
const int MOD = 1000000007;
// const int N = 2e5 + 10;
const int MAX = 10000000;
#define inf LLONG_MAX
int gcd(int a,int b){return b==0?a:gcd(b,a%b);}
void solve(){
    int n,k;
    cin>>n>>k;
    vin(v,n);
    int li = 0,ri = n-1;
    ordered_multiset s;
    int id = 0;
    for(auto ele : v)s.insert({ele,id++});
    while(li < ri){
        if(v[li] == v[ri]){
            li++;
            ri--;
        }else{
            int cnt1 = s.order_of_key({v[li],INT_MAX});
            int cnt2 = s.order_of_key({v[ri],INT_MAX});
            if(cnt1 >= k){
                auto it1 = s.lower_bound({v[li], 0});
                s.erase(it1);
                li++;
            }else if(cnt2 >= k){
                auto it2 = s.lower_bound({v[ri], 0});
                s.erase(it2);
                ri--;
            }else{
                cout<<"NO"<<endl;
                return;
            }

        }
    }
    cout<<"YES"<<endl;
}
int32_t main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int t=1;
    cin>>t;
    while(t--){ 
        solve();
    }
}