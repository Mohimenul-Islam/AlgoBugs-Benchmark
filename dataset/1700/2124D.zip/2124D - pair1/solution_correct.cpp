#include <bits/stdc++.h>
using namespace std;




void solve(){
    int n,k;
    cin>>n>>k;
    vector<int>a(n);
    for(int i=0;i<n;i++) cin>>a[i];
    if(k==1){
        cout<<"Yes"<<endl;
        return;
    }
    vector<int>sorted;
    for(int x:a){
        sorted.push_back(x);
    }
    sort(sorted.begin(),sorted.end());
    map<int,int>mp;
    for(int i=k-1;i<n;i++){
        mp[sorted[i]]++;
    }
    int i=0;
    int j=n-1;
    bool ok=true;
    while(i<j){
        if(a[i]==a[j]){
            i++;
            j--;
        }
        else{
            bool b1=mp.count(a[i]);
            bool b2=mp.count(a[j]);
            if(b1&&b2){
                if(a[i]>a[j]){
                    mp[a[i]]--;
                    if(mp[a[i]]==0) mp.erase(a[i]);
                    i++;
                }
                else{
                    mp[a[j]]--;
                    if(mp[a[j]]==0) mp.erase(a[j]);
                    j--;
                }
            }
            // if(b1&&b2){
            //     mp[a[i]]--;
            //     if(mp[a[i]]==0) mp.erase(a[i]);
            //     i++;
            //     mp[a[j]]--;
            //     if(mp[a[j]]==0) mp.erase(a[j]);
            //     j--;
            // }
            else if(b1){
                mp[a[i]]--;
                if(mp[a[i]]==0) mp.erase(a[i]);
                i++;
            }
            else if(b2){
                 mp[a[j]]--;
                 if(mp[a[j]]==0) mp.erase(a[j]);
                 j--;
            }
            else{
                cout<<"No"<<endl;
                return;
            }
        }
    }
    cout<<"Yes"<<endl;
    
}



int main() {
	// your code goes here
	int t;
	cin>>t;
	while(t--) solve();

}
