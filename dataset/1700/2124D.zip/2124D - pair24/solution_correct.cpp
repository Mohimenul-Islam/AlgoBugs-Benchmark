#include<bits/stdc++.h>

void solve(){
    int n,k;
    std:: cin>>n>>k;
    std:: vector<int> ve(n+1,0);
    for(int i=1;i<=n;i++)
    std:: cin>>ve[i];
    std:: vector<int> temp=ve;
    std:: sort(temp.begin()+1,temp.end());
    int cut=temp[k];
    std:: vector<int> left;
    for(int i=1;i<=n;i++)
    if(ve[i]<=cut)
    left.push_back(ve[i]);
    int spa=left.size()-k+1;
    int l=0,r=left.size()-1,flag=1;
    while(l<=r){
        if(left[l]==left[r])
        l++,r--;
        else if(left[l]!=left[r]){
            if(!spa){
                flag=0;
                break;
            }
            if(left[l]==cut)
            l++,spa--;
            else if(left[r]==cut)
            r--,spa--;
            else{
                flag=0;
                break;
            }
        }
    }
    if(flag)
    std:: cout<<"YES"<<'\n';
    else
    std:: cout<<"NO"<<'\n';
}

int main(){
    int t=1;
    std:: cin>>t;
    while(t--)
    solve();
}