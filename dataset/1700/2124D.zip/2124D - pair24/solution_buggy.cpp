#include<bits/stdc++.h>

#define int long long

void solve(){
   int n,k;
   std:: cin>>n>>k;
   std:: vector<std:: pair<int,int> > ve(n+1);
   for(int i=1;i<=n;i++){
        std:: cin>>ve[i].first;
        ve[i].second=i;
   }
    std:: sort(ve.begin()+1,ve.end());
    auto check=[&] (int tk) -> bool {
        std:: vector<std:: pair<int,int> > pa;
        for(int i=1;i<=tk;i++)
        pa.push_back({ve[i].second,ve[i].first});
        std:: sort(pa.begin(),pa.end());
        int l=0,r=pa.size()-1;
        int flag=1;
        while(l<=r){
            if(pa[l].second!=pa[r].second){
                flag=0;
                break;
            }
            l++,r--;
        }
        return flag;
    };
    for(int i=k-1;i<=k+9&&i<=n;i++){
        if(check(i)){
            std:: cout<<"YES"<<'\n';
            return ;
        }
    }
    std:: cout<<"NO"<<'\n';
}

signed main(){
    int t=1;
    std:: cin>>t;
    while(t--)
    solve();
    return 0;
}