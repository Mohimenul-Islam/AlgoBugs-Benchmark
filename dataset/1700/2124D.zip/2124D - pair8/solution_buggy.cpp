#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define all(a) a.begin(), a.end()
#define allr(a) a.rbegin(), a.rend()
#define ia(a, n)                   \
        ll a[n];                   \
        for (ll i = 0; i < n; ++i) \
                cin >> a[i];
#define iv(v, n)          \
        vector<ll> v(n);  \
        for (auto &i : v) \
                cin >> i;
#define print(a)                    \
        for (auto &val : a)         \
                cout << val << ' '; \
        cout << endl;
#define noRealSolution              \
        {                           \
                cout << -1 << endl; \
                return;             \
        }
#define noYesSolution                 \
        {                             \
                cout << "NO" << endl; \
                return;               \
        }
#define yesSolution                    \
        {                              \
                cout << "YES" << endl; \
                return;                \
        }
#define Yes cout << "Yes\n"
#define No cout << "No\n"
#define YES cout << "YES\n"
#define NO cout << "NO\n"
#define check cout << "CHECK\n"
const ll INF = 1e18, MOD = 1e9 + 7;
const ll ze = 0ll, mod = 998244353;
// const ll ze = 0ll, mod = 676767677;

void printBinary(ll n, ll c)
{
        for (ll i = c; i >= 0; --i)
                cout << ((n >> i) & 1);
        cout << endl;
}

/* Observations
***/

bool solve(vector<ll>& a, vector<ll> &b, ll k) {
        ll n = a.size();
        vector<ll> v; 
        vector<ll> vis(n, 0);
        for (ll i = 0; i < n; ++i) {
                if (a[i] < b[k]) 
                        v.push_back(a[i]),
                        vis[i] = 1;
        }
        for (ll i = 0; i < v.size(); ++i) {
                if (v[i] != v[v.size() - i - 1]) return false;
        }

        ll rem = k - v.size(), tar = b[k];
        if (rem <= 0) return true;
        
        vector<ll> c;
        for (ll i = 0; i < n; ++i) {
                if (a[i] <= b[k]) c.push_back(a[i]);
        }
        ll i = 0, j = c.size() - 1;
        while (j > i && rem > 0) {
                if (c[i] < tar && c[j] < tar) i ++, j --;
                else if (c[i] < tar) j --;
                else if (c[j] < tar) i ++;
                else rem -= 2;
        }
        if (i == j && c[i] >= tar) rem --;
        // print(c);
        return rem <= 0;
}

void main_sol() 
{
        ll n, k; cin >> n >> k;
        iv(a, n);
        if (k <= 2) yesSolution
        vector<ll> b = a;
        sort(all(b));
        if (solve(a, b, k - 1)) YES;
        else NO;
}

// NOTE : Every problem has a solution

int main()
{
        ios_base ::sync_with_stdio(false);
        cin.tie(NULL);
        ll testcase = 1;
        cin >> testcase;
        while (testcase--)
                main_sol();
        return 0;
}