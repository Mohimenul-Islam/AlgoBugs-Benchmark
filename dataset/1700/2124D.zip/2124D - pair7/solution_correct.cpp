#include<bits/stdc++.h>
using namespace std;
const int M=200010;
int t,n,k,p,c[M],id[M],in[M],cnt,d[M];
struct node{int x,i;}a[M],b[M];
int cmp(node x,node y){return x.x<y.x;}
int cmpx(node x,node y){return x.i<y.i;}
int gp(int i){return d[id[i]]-d[id[i-1]];}
int pd(int p,int mx,int k)
{
	sort(b+1,b+p+1,cmpx),cnt=0;
	for(int i=1;i<=p;++i)
		if(b[i].x!=mx)c[++cnt]=b[i].x,id[cnt]=b[i].i;
	if(!cnt&&p>=k)return 1;
	id[0]=0,id[cnt+1]=n+1;
	d[0]=0;
	for(int i=1;i<=n;++i)
		if(in[i]==mx)d[i]=d[i-1]+1;
		else d[i]=d[i-1];
	d[n+1]=d[n];
	int l=(cnt+1)/2,r=((cnt&1)?l:l+1),s=1+min(gp(l),gp(r+1))*2;
	if(l!=r)s+=gp(r)+1;
	if(l!=r&&c[l]!=c[r])return 0;
//	cout<<id[l]<<' '<<id[r]<<' '<<s<<'\n';
	while(l>1&&r<cnt&&c[l-1]==c[r+1])
		--l,++r,s+=2+min(gp(l),gp(r+1))*2;
//	cout<<s<<'\n';
	return l==1&&r==cnt&&s>=k;
}
int main()
{
	std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	cin>>t;
	while(t--)
	{
		cin>>n>>k;
		for(int i=1;i<=n;++i)cin>>a[i].x,a[i].i=i,in[i]=a[i].x;
		sort(a+1,a+n+1,cmp),p=0;
		for(int i=1;i<k;++i)b[++p]=a[i];
		for(int i=k;i<=n;++i)
			if(a[i].x==b[p].x&&i!=1)b[++p]=a[i];
			else break;
		for(int kk=k;kk<=n+1;++kk)
		{
			if(pd(p,b[p].x,kk-1)){cout<<"YES\n";break;}
			else if(p>=kk){cout<<"NO\n";break;}
			else
			{
				b[++p]=a[kk];
				for(int i=kk;i<=n;++i)
					if(a[i].x==b[p].x)b[++p]=a[i];
			}
		}
	}
	return 0;
}