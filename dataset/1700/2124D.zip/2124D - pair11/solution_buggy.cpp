#include <bits/stdc++.h>
using namespace std;
bool check(vector<pair<int, int>> &store, int n, int req, vector<int> &a, int end)
{
    int prev1 = 0, prev2 = n - 1;
    for (auto i : store)
    {
        int x = i.first;
        int y = i.second;
        // cout << x << " "<< y << endl ;
        if (req == 0)
            break;
        int cnt1 = 0, cnt2 = 0;
        for (int j = prev1; j < x; j++)
        {
            if (a[j] == end)
                cnt1++;
        }
        for (int j = prev2; j > y; j--)
        {
            if (a[j] == end)
                cnt2++;
        }
        req -= 2 * min(cnt1, cnt2);
        prev1 = x + 1, prev2 = y - 1;
    }
     if (req == 0)
        return true;
    int cnt1 = 0 ;
    //cout << req << endl ;
    for (int j = prev1 ; j <= prev2 ; j++)
    {
        if (a[j] == end)
            cnt1++;
    }
    req -=  cnt1 ;
    if (req == 0)
        return true;
    return false;
}
int main()
{
    ios ::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--)
    {
        int n, k;
        cin >> n >> k;
        vector<int> a(n), count(n + 1, 0);
        for (int i = 0; i < n; i++)
        {
            cin >> a[i];
            count[a[i]]++;
        }
        int st = 0, end = n;
        int curr = 0, prev = 0, req = 0;
        for (int i = 0; i <= n; i++)
        {
            curr += count[i];
            if (count[i] != 0 && st == 0)
                st = i;
            if (curr >= k)
            {
                req = (k - prev);
                end = i;
                break;
            }
            prev = curr;
        }
       // cout << req << endl ;
        int odd = 0;
        for (int i = st; i < end; i++)
        {
            if (count[i] % 2 != 0)
                odd++;
        }
        if (odd > 1)
        {
            cout << "NO" << endl;
            continue;
        }
        if (st == end)
        {
            cout << "YES" << endl;
            continue;
        }
      //  cout << st <<" "<< end << endl ;
        vector<pair<int, int>> store;
        int high = n - 1, low = 0;
        while (low <= high)
        {
            if (a[low] >= st && a[low] < end && count[a[low]] > 1)
            {
                while (high > low && a[high] != a[low])
                    high--;
                if (high > low && a[high] == a[low])
                {
                    count[a[low]] -= 2;
                    store.push_back({low, high});
                    high--;
                }
            }
            else if (a[low] >= st && a[low] < end && count[a[low]] == 1)
            {   
               // cout << a[low] << endl ;
                while (high >= low && a[high] != a[low])
                    high--;
                if (high >= low && a[high] == a[low])
                {
                    count[a[low]] -= 1;
                    store.push_back({low, high});
                    high--;
                }
            }
            low++;
        }
        bool yes = true;
        for (int i = st ; i < end; i++)
        {
            if (count[i] != 0)
            {
                yes = false;
                break;
            }
        }
       // cout <<end <<" "<<yes  << endl ;
        if (!yes)
        {
            cout << "NO" << endl;
            continue;
        }
        bool possible = false;
        if (odd == 0)
           {
             possible |= check(store, n, req , a, end);
             possible |= check(store, n, req - 1, a, end);
           }
        else{
            if(req % 2 != 0) req -- ;
             possible |= check(store, n, req, a, end);
        }
        // cout << possible << endl ;
        yes = possible;
        if (!yes)
            cout << "NO" << endl;
        else
            cout << "YES" << endl;
    }
}