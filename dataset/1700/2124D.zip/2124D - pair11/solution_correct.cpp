#include <bits/stdc++.h>
using namespace std;
bool check(vector<pair<int, int>> &store, int n, int req, vector<int> &a, int end, vector<int> &pref)
{
    if (req <= 0) return req == 0;
    int prev1 = 0, prev2 = n - 1;
    for (auto i : store)
    {
        int x = i.first;
        int y = i.second;
        if (req <= 0) break;
        int cnt1 = pref[x] - pref[prev1];
        int cnt2 = pref[prev2 + 1] - pref[y + 1];

        req -= 2 * min(cnt1, cnt2);
        prev1 = x + 1, prev2 = y - 1;
    }
    if (req <= 0) return true;
    int cnt1 = 0;
    if (prev1 <= prev2)
        cnt1 = pref[prev2 + 1] - pref[prev1];

    req -= cnt1;
    return req <= 0;
}
int main()
{
    ios ::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while (t--)
    {
        int n, k;
        cin >> n >> k;
        vector<int> a(n), count(n + 1, 0);
        vector<vector<int>> pos(n + 1); 
        for (int i = 0; i < n; i++)
        {
            cin >> a[i];
            count[a[i]]++;
            pos[a[i]].push_back(i);
        }
        int st = 0, end = n;
        int curr = 0, prev = 0, req = 0;
        bool first_val = false;
        for (int i = 0; i <= n; i++)
        {
            if (count[i] != 0 && !first_val) {
                st = i;
                first_val = true;
            }
            curr += count[i];
            if (curr >= k)
            {
                req = (k - prev);
                end = i;
                break;
            }
            prev = curr;
        }
        int odd = 0;
        for (int i = st; i < end; i++)
        {
            if (count[i] % 2 != 0)
                odd++;
        }
        if (odd > 1)
        {
            cout << "NO" << "\n";
            continue;
        }
        if (st == end)
        {
            cout << "YES" << "\n";
            continue;
        }
        vector<pair<int, int>> store;
        vector<int> pos_ptr(n + 1);
        for(int i=0; i<=n; i++) pos_ptr[i] = (int)pos[i].size() - 1;
        int high = n - 1, low = 0;
        vector<int> temp_count = count;
        while (low <= high)
        {
            int val = a[low];
            if (val >= st && val < end && temp_count[val] > 1)
            {
                while (pos_ptr[val] >= 0 && pos[val][pos_ptr[val]] > high)
                    pos_ptr[val]--;
                
                int match = pos[val][pos_ptr[val]];
                if (match > low)
                {
                    temp_count[val] -= 2;
                    store.push_back({low, match});
                    high = match - 1;
                }
            }
            else if (val >= st && val < end && temp_count[val] == 1)
            {
                while (pos_ptr[val] >= 0 && pos[val][pos_ptr[val]] > high)
                    pos_ptr[val]--;
                
                int match = pos[val][pos_ptr[val]];
                if (match >= low)
                {
                    temp_count[val] -= 1;
                    store.push_back({low, match});
                    high = match - 1;
                }
            }
            low++;
        }

        bool yes = true;
        for (int i = st; i < end; i++)
        {
            if (temp_count[i] != 0)
            {
                yes = false;
                break;
            }
        }
        if (!yes)
        {
            cout << "NO" << "\n";
            continue;
        }
        vector<int> pref(n + 1, 0);
        for (int i = 0; i < n; i++)
            pref[i + 1] = pref[i] + (a[i] == end);

        bool possible = false;
        if (odd == 0)
        {
            possible |= check(store, n, req, a, end, pref);
            possible |= check(store, n, req - 1, a, end, pref);
        }
        else
        {
            int r = req;
            if (r % 2 != 0) r--;
            possible |= check(store, n, r, a, end, pref);
        }
        if (!possible)
            cout << "NO" << "\n";
        else
            cout << "YES" << "\n";
    }
}