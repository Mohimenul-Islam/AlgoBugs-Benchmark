#include <bits/stdc++.h>
#include <unordered_map>
#define endl "\n"
#define ls(u) tr[u].l
#define rs(u) tr[u].r
#define v(u) tr[u].v
#define int long long

using namespace std;
using PII = pair<int, int>;
using PIII = pair<int, PII>;
using ll = long long;

const int INF = 0x3f3f3f3f;
const int N = 2e5 + 10;
const int M = 4e5 + 10;

int n, m, k, T;
int dx[4] = {1, 0, -1, 0}, dy[4] = {0, 1, 0, -1};
int e[M], ne[M], h[N], w[M], idx;

void add(int a, int b)
{
    e[idx] = b, ne[idx] = h[a], h[a] = idx++;
}

ll ksm(ll a, ll k)
{
    ll res = 1;

    while (k)
    {
        if (k & 1)
            res = res * a;
        a = a * a;
        k >>= 1;
    }
    return res;
}

ll ssm(ll a, ll k, ll mod)
{
    ll res = 0;
    while (k)
    {
        if (k & 1)
            res = (res + a) % mod;
        a = (a + a) % mod;
        k >>= 1;
    }
    return res;
}

void solve()
{
    cin >> n >> k;
    vector<int> a(n + 1), b(n + 1);
    vector<int> used(n + 1);
    vector<PII> wait;
    for (int i = 1; i <= n; i++)
        cin >> a[i], b[i] = a[i];
    sort(a.begin() + 1, a.end());
    for (int i = k; i <= n; i++)
        used[a[i]] |= 1;
    for (int i = 1; i <= n; i++)
    {
        if (!used[b[i]])
            wait.emplace_back(b[i], i);
    }
    if (wait.empty())
    {
        cout << "YES" << endl;
        return;
    }
    for (int i = 0, j = wait.size() - 1; i <= j; i++, j--)
        if (wait[i].first != wait[j].first)
        {
            cout << "NO" << endl;
            return;
        }
    int val = 0, state = a[k], idx = k - 1;
    while (idx >= 1 && a[idx] == state)
        val++, idx--;
    vector<int> s(n + 1);
    for (int i = 1; i <= n; i++)
        s[i] = s[i - 1] + (b[i] == state);
    int cnt = 0;
    for (int i = 0, j = wait.size() - 1; i <= j; i++, j--)
    {
        auto l = wait[i].second, r = wait[j].second;
        auto L = s[l] - (i == 0 ? 0 : s[wait[i - 1].second]);
        auto R = (j == wait.size() - 1 ? s[n] : s[wait[j + 1].second]) - s[r];
        cnt += 2 * min(L, R);
        if (i + 1 == j)
            cnt += min(s[r] - s[l], 1ll);
    }
    cout << (cnt >= val ? "YES" : "NO") << endl;
}

signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    T = 1;
    cin >> T;
    while (T--)
    {
        // memset(h,-1,sizeof h);
        solve();
    }
    return 0;
}