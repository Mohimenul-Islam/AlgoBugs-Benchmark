//author nagajahnavidann1
#include <bits/stdc++.h>
using namespace std;
#include <cmath> 
#define ll long long int
void solve()
{ 
    int n,k;
    cin>>n>>k;
    vector<int>a(n);
    for(int i=0;i<n;i++)cin>>a[i];
    vector<int>b=a;
    sort(b.begin(),b.end());
    set<int>st;
    for(int i=0;i<k-1&&i<b.size();i++)
    {
        st.insert(b[i]);
    }
    vector<int>fin;
    for(int i=0;i<n;i++)
    {
        if(st.find(a[i])!=st.end())fin.push_back(a[i]);
    }
    int i=0,j=fin.size()-1;
    int nor=fin.size()-(k-1);
    int nov=b[b.size()-1];
    while(i<j)
    {
        if(fin[i]==fin[j]){
            i++;j--;
        }
        else if(fin[i]==nov &&nor>0){
            nor--;i++;
        }
        else if(fin[j]==nov && nor>0){
            j--;nor--;
        }
        else{
            cout<<"NO\n";return;
        }
        
    }
    cout<<"YES\n";
    
}
 
// ------------------------------------------------------------------------------------
 
int main()
{
    ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
    int t;
    cin>>t;
    while(t--)
    solve();
    return 0;
}