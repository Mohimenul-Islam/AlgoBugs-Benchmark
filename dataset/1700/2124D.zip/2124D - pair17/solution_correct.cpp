#include<bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

typedef long long ll;
typedef vector<ll> vi;
typedef pair<ll, ll> pll;
typedef map<ll, ll> mll;

#define INF ((ll)2e+18)
#define MOD ((ll)1e9+7)
#define yes "Yes"
#define no "No"
#define endl '\n'
#define all(x) x.begin(), x.end()
#define rep(i, a, b) for(ll i = a; i <= b; i++)
#define F first
#define S second
#define pb(x) push_back(x)
#define MP(x, y) make_pair(x, y)

#define debug(var){ cerr<<#var<<" -> "; print(var); cerr<<endl;}
template<typename T>void print(T t) {cerr << t << " ";}
template <class T, class V> void print(pair <T, V> p);
template <class T> void print(vector <T> v);
template <class T> void print(set <T> v);
template <class T, class V> void print(map <T, V> v);
template <class T, class V> void print(multimap <T, V> v);
template <class T, class V> void print(unordered_map <T, V> v);
template <class T> void print(multiset <T> v);

template <class T, class V> void print(pair <T, V> p) {cerr << "{"; print(p.F); cerr << ","; print(p.S); cerr << "}";}
template <class T> void print(vector <T> v) {cerr << "[ "; for (T i : v) {print(i); cerr << " ";} cerr << "]";}
template <class T> void print(set <T> v) {cerr << "[ "; for (T i : v) {print(i); cerr << " ";} cerr << "]";}
template <class T> void print(multiset <T> v) {cerr << "[ "; for (T i : v) {print(i); cerr << " ";} cerr << "]";}
template <class T, class V> void print(map <T, V> v) {cerr << "[ "; for (auto i : v) {print(i); cerr << " ";} cerr << "]";}
template <class T, class V> void print(multimap <T, V> v) {cerr << "[ "; for (auto i : v) {print(i); cerr << " ";} cerr << "]";}
template <class T, class V> void print(unordered_map <T, V> v) {cerr << "[ "; for (auto i : v) {print(i); cerr << " ";} cerr << "]";}
template <class T> void print(queue <T> v) {cerr << "[ "; int f = 0; while (!v.empty())cerr << (f++ ? ", " : ""), print(v.front()), v.pop(); cerr << " ]";}
template <class T> void print(stack <T> v) {cerr << "[ "; int f = 0; while (!v.empty())cerr << (f++ ? ", " : ""), print(v.top()), v.pop(); cerr << " ]";}
template <class T> void print(deque <T> v) {cerr << "[ "; int f = 0; while (!v.empty())cerr << (f++ ? ", " : ""), print(v.front()), v.pop_front(); cerr << " ]";}
template<typename... T> void print(T... t) { ((cerr << t << " "), ...); }

typedef tree<pair<ll, ll>, null_type, less<pair<ll, ll>>, rb_tree_tag,tree_order_statistics_node_update>ordered_set;

ll int_sqrt (ll x) {ll ans = 0;for (ll k = 1LL << 30; k != 0; k /= 2) {if ((ans + k) * (ans + k) <= x) {ans += k;}}return ans;}
vi find_bits(ll num){vi bits;rep(i, 0, 62)bits.push_back((num>>i)&1);return bits;}
ll find_power(ll base, ll power, ll mod = LLONG_MAX){if(power==0) return 1;ll val = find_power(base,power/2, mod)%mod;(val*=val)%=mod;if(power&1) (val*=base)%=mod;return val%mod;}
bool isset(ll n, ll j){return n&(1ll<<j);}
void unsetbit(ll& n, ll j){n = n & (~(1ll<<j));}
ll add(ll a, ll b, ll m = MOD) {return((a%m)+(b%m)+m)%m;}
ll sub(ll a, ll b, ll m = MOD) {return((a%m)-(b%m)+m)%m;}
ll mul(ll a, ll b, ll m = MOD) {return ((a%m)*(b%m))%m;}
ll modexp(ll a, ll e, ll m = MOD) {a%=m;ll r=1; while(e){if(e&1) r=mul(r,a,m);a=mul(a, a, m);e>>=1;}return r;}
ll inv(ll a, ll m = MOD) {return modexp(a, m-2, m);}

void solve(ll ttc, ll tc) {
    ll n, k; cin>>n>>k;
    vi v(n); rep(i, 0, n-1) cin>>v[i];
    if(k == 1) {
        cout<<yes<<endl;
        return;
    }
    vi vec = v;
    sort(all(vec));
    vi vv;
    ll last = vec[k-2];
    rep(i, 0, n-1) {
        if(v[i] <= last)
            vv.push_back(v[i]);
    }
    ll spare = vv.size()-k+1;
    ll i=0, j=vv.size()-1;
    bool isOk = true;
    while(i<j) {
        if(vv[i] != vv[j]) {
            if(!spare) {
                isOk = false;
                break;
            }
            if(vv[i] == last) {
                i++;
                spare--;
            } else if(vv[j] == last) {
                j--;
                spare--;
            } else {
                isOk = false;
                break;
            }
            continue;
        }
        i++, j--;
    }
    if(isOk) cout<<yes<<endl;
    else cout<<no<<endl;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    ll t;
    cin >> t;
    cin.ignore();
    rep(i, 0, t-1)
        solve(t, i+1);
    // solve(1, 1);
    return 0;
}