#include<bits/stdc++.h>
#define rep(i,l,r) for(int i=l;i<r;++i)
#define pb push_back
using  namespace std;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int _;
	cin>>_;
	while(_--){
		int n,k;
		cin>>n>>k;
		k--;
		vector<int> a(n);
		for(auto &i:a) cin>>i;
		vector<pair<int,int>> tmp;
		rep(i,0,n) tmp.push_back({a[i],i});
		sort(tmp.begin(), tmp.end());
		vector<pair<int,int>> t2;
		rep(i,0,n-1){
			if((i>0 and tmp[i].first==tmp[i-1].first) or i+1<=k) {
				t2.push_back(tmp[i]);
				continue;
			}
			if(i+1>=k) break;
		}
		for(auto [x,y]:t2) cerr<<y<<" ";
		cerr<<'\n';
		if(k==n) t2.pb({a.back(),n-1});
		if(t2.size()>k){
			while(t2.size()>1 and t2[t2.size()-2].first==t2.back().first) t2.pop_back(),t2.pop_back();
		}
		int l=n,r=-1;
		vector<bool> use(n);
		for(auto [x,y]:t2) {use[y]=true;l=min(l,y);r=max(y,r);}
		
		if(l>r){
			cout<<"YES\n";
			continue;
		}
		for(auto [x,y]:t2) cerr<<y<<" ";
		cerr<<'\n';
		if(t2.size()<k){
		map<int,int> le,ri;
		rep(i,0,n){
			if(a[i]==tmp[k].first){
				le[i-l]=i;
				ri[r-i]=i;
			}
		}
		for(auto [x,y]:le){
			if(t2.size()>=k) break;
			if(x==r-y){
				t2.pb({a[y],y});
				use[y]=true;
				continue;
			}
			if(ri.find(x)!=ri.end()){
				t2.pb({a[y],y});
				use[y]=true;
				
					t2.pb({a[ri[x]],ri[x]});
				    use[ri[x]]=true;
				
			}
		}}
		vector<int> ans;
		rep(i,0,n) if(use[i]) ans.pb(a[i]);
		auto palin=[](auto &a){
			int l=0,r=a.size()-1;
			while(l<r){
				if(a[l]!=a[r]) return false;
				l++;
				r--;
			}
			return true;
		};
		if(ans.size()>=k and palin(ans)) cout<<"YES\n";
		else cout<<"NO\n";
	}
}