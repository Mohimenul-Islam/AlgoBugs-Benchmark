#include <bits/stdc++.h>
#ifndef __DEBUG
#pragma GCC optimize("O3", "unroll-loops")
#endif
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
#define int long long
template <typename Key, typename Mapped = null_type, typename Compare = std::less<Key>>
using itree = tree<Key, Mapped, Compare, rb_tree_tag, tree_order_statistics_node_update>;
using u64 = size_t;
using i128 = __int128_t;
using u128 = __uint128_t;
using dbl = long double;
using vi = vector<int>;
using pii = pair<int, int>;

#define pb push_back
#define all(x) (x).begin(), (x).end()
#define uniquify(x) x.erase(unique(all(x)), x.end())

#define rep(i, l, r) for (int i = (l); i < (r); ++i)
#define rep2(i, r) for (; i < (r); ++i)
#define per(i, r, l) for (int i = (r); i >= (l); --i)
#define per2(i, r) for (; i >= (r); --i)
#define ff first
#define ss second
#define yes(x) cout << ((x) ? "YES" : "NO") << '\n'

template <typename T>
istream &operator>>(istream &is, vector<T> &v)
{
    for (auto &x : v)
        is >> x;
    return is;
}

template <typename T>
ostream &operator<<(ostream &os, const vector<T> &v)
{
    for (size_t i = 0; i < v.size(); ++i)
    {
        os << v[i];
        if (i + 1 != v.size())
            os << ' ';
    }
    return os;
}

const long long inf = 1000000000000000005LL;
#define Testcase \
    int __;      \
    cin >> __;   \
    while (__--)
signed main()
{
#ifndef __DEBUG
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
#endif

    Testcase
    {
        int n, k;
        cin >> n >> k;
        vi a(n);
        cin >> a;
        vi tmp = a;
        sort(all(tmp));
        vector<bool> use(n);
        
        rep(i, 0, n) if (a[i] < tmp[k - 1]) use[i] = true;
        vi pre(n);
        pre[0]=use[0];
        rep(i,1,n) pre[i]=pre[i-1]+use[i];
        stack<int>le;
        rep(i,0,n){
            if(a[i]!=tmp[k-1]) continue;
            int lp=pre[i],rp=pre.back()-lp;
            if(lp==rp){
                use[i]=true;
                continue;
            }
            while(!le.empty() and pre[le.top()]>rp) le.pop();
            if(!le.empty() and pre[le.top()]==rp){
                use[le.top()]=use[i]=true;
                le.pop();
            }else le.push(i);
        }
        auto palin=[&]()
        {
            int l=0,r=n-1;
            while(l<r){
                while(l<r and !use[l]) l++;
                while(r>l and !use[r]) r--;
                if(l>r) break;
                if(a[l]!=a[r]) return false;
                l++;
                r--;
            }
            return true;
        };
        yes(count(all(use),true)>=k-1 and palin());
    }

    return 0;
}