#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define int long long
#define ll long long


using namespace std;
using namespace __gnu_pbds;

void solve() {

    int n; cin >> n;
    int k; cin >> k;
    vector<int> arr(n);

    map<int,int> mp;
    for(int i = 0 ; i < n ; i ++ ){  
    cin >> arr[i];
    mp[arr[i]]++;
    }


    vector<int> cp; cp = arr;
    sort(cp.begin(), cp.end());
    k--;
    for(int i = k  ; i < n ; i ++) mp[cp[i]]--;

    int val = cp[k];
    int keep = 0;
    bool f = true;
    

    vector<int> temp;
    for(int i = 0 ; i < n ; i ++){
        if(arr[i] <= val) temp.push_back(arr[i]);
    }

    n = temp.size();
    vector<int> save(n,0);    

   // for(auto i : temp)cout<<i<<" ";cout<<endl;
   // cout<<val<<endl;
   // cout<<mp[val]<<endl;

    int l = 0;
    int r = n - 1;
    while(l <= r){

        while(temp[l] == val && l < r && mp[val] <= 0 && f) l++;
        while(temp[r] == val && l < r && mp[val] <= 0 && f) r--;


        if(temp[l] == val || temp[r] == val ){

            if(temp[l] == temp[r] ){
                save[l] = 1; save[r] = 1;  


                if(l != r)  
                mp[val] -= 2;
                else mp[val]--;
                
                l++;r--;
            }
            else if(temp[l] == val) l++;
            else r--;
        }
        else{
            if(temp[l] == temp[r]){
            save[l] = 1; save[r] = 1;    
            l++;r--;}
            else{cout<<"NO"<<endl;return;}
        }
    }

    //cout<<mp[val]<<endl;
   // for(auto i : save)cout<<i<<" ";cout<<endl;

    if(mp[val] > 0){cout<<"NO"<<endl;return;}

    vector<int> tp2;
    for(int i = 0 ; i < n ; i ++)
    if(save[i]) tp2.push_back(temp[i]);

    n = tp2.size();
     l = 0;
     r = n - 1;
    // cout<<l<<" "<<r<<endl;
    while(l < r){
        if(tp2[l] == tp2[r]){l++;r--;}
        else {cout<<"NO"<<endl;return;}
    }

    cout<<"YES"<<endl;return;
}               



int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    
    int tt = 1;
   cin >> tt;

    while(tt--) solve();
}