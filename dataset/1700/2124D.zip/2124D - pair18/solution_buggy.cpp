#include <bits/stdc++.h>
#define fir first
#define sec second
using namespace std;
typedef long long ll;
const int N=2e5+10;
ll a[N],b[N];
void solve() {
    ll n,k;cin>>n>>k;
    for(int i=1;i<=n;i++) {
        cin>>a[i];
        b[i]=a[i];
    }
    if(k<=2) {
        cout<<"YES\n";
        return ;
    }
    sort(a+1,a+n+1);
    ll x=a[k];
    ll len=upper_bound(a+1,a+n+1,x)-a-1;
    vector<ll> c,d;
    for(int i=1;i<=n;i++) {
        if(b[i]>x) continue;
        if(b[i]<x) d.push_back(b[i]);
        c.push_back(b[i]);
    }
    ll l2=d.size();
    bool ok=1;
    for(int i=0,j=l2-1;i<j;i++,j--) {
        if(d[i]!=d[j]) {
            ok=0;
            break;
        }
    }
    if(ok==0) {
        cout<<"NO\n";
        return ;
    }
    ll cnt=len-k+1;
    for(int i=0,j=len-1;i<j;) {
        ll ci=0,cj=0;
        while(c[i]==x) {
            ci++;
            i++;
        }
        while(c[j]==x) {
            cj++;
            j--;
        }
        cnt-=abs(ci-cj);
        i++;
        j--;
    }
    if(cnt<0) ok=0;
    if(ok) {
        cout<<"YES\n";
    }else {
        cout<<"NO\n";
    }

}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ll t;cin>>t;
    while(t--) solve();
    return 0;
}