#include <bits/stdc++.h>
using namespace std;
#define int long long
const int MOD = 1e9 + 7;

void solve() {
    int n, m, l;
    cin >> n >> m >> l;

    multiset<int> s;
    vector<int> mp(l + 1, -1);

    for(int i = 0; i < min(m, n + 1); i++)
    {
        s.insert(0);
    }

    for(int i = 0; i < n; i++)
    {
        int k;
        cin >> k;

        mp[k] = i;
    }

    int flag = 0;

    for(int i = 1; i <= l; i++)
    {
        if(flag)
        {
            auto it = prev(s.end());
            int val = *it;
            val++;
            s.erase(it);
            s.insert(val);
            continue; 
        }

        auto it = s.begin();
        int val = *it;
        val++;
        s.erase(it);
        s.insert(val);

        if(mp[i] != -1)
        {
            auto it = prev(s.end());
            s.erase(it);

            if(mp[i] == n - 1)
                flag = 1;

            if(n - mp[i] - 1 <= m - 2)
            {
                continue;
            }

            s.insert(0);
        }

    }

    cout << *s.rbegin() << '\n';
}

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--)
        solve();
    return 0;
}