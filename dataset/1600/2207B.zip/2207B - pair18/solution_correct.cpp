#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using pll = pair<ll,ll>;


void solve()
{
    ll n,m,l;
    cin>>n>>m>>l;
    vector<ll>a(n);
    for(auto &it:a)cin>>it;
    if(m==1)
    {cout<<l-a[n-1]<<"\n";return;}
    ll cur=m,le=0;
    vector<ll>re(m,0);
    ll pr=0;
    for(ll i=1;i<=a[n-1];i++)
    {
        cur=min(cur,n-pr+1);
        re[cur-1]++;
        sort(re.begin(),re.end(),greater<ll>());
        if(i==a[pr])
        {
            pr++;
            re[0]=0;
            sort(re.begin(),re.end(),greater<ll>());
        }
        // cout<<"cur:"<<cur<<endl;
        // for(auto &it:re)cout<<it<<" ";cout<<endl;
    }
    cout<<re[0]+l-a[n-1]<<"\n";
    
}

signed main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    ll t;cin >> t;while (t--)
    solve();
}