#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using pll = pair<ll,ll>;


void solve()
{
    ll n,m,l;
    cin>>n>>m>>l;
    vector<ll>a(n);
    for(auto &it:a)cin>>it;
    if(m==1)
    {cout<<l-a[n-1]<<"\n";return;}
    // if(m==2){
    // ll le=a[0]/2;
    // for(ll i=1;i<n;i++)
    // {
    //     le=(a[i]-a[0]+le)/2;
    // }
    // cout<<le+l-a[n-1]<<"\n";return;}
    ll cur=m,le=0;
    vector<ll>re(m,0);
    for(ll i=0;i<n;i++)
    {
        cur=min(cur,n-i+1);
        // cout<<cur<<endl;
        if(i==0)
        {
            le+=a[i]-(a[i]+cur-1)/cur;
            ll temp=a[0];
            for(ll i=0;i<cur;i++)
            {
                re[i]=(temp+cur-i-1)/cur;
            }
            re[0]=0;
            sort(re.begin(),re.end(),greater<ll>());
        }
        else
        {
            
            if(cur==m)
            {
                // for(auto &it:re)cout<<it<<" ";cout<<endl;
                
                if(a[i]-a[i-1]<re[0]*m-le)
                {
                    le-=re[0];
                    le+=a[i]-a[i-1];
                    ll ta=a[i]-a[i-1];
                    // for(auto &it:re)cout<<it<<" ";cout<<endl;
                    ll pr=m-1;
                    for(;pr>0;pr--)
                    {
                        ta+=re[pr];
                        if(re[pr-1]*(m-pr)>=ta)break;
                    }
                    for(ll j=pr;j<n;j++)
                    {
                        re[j]=(ta+m-j-1)/(m-pr);
                    }
                    re[0]=0;
                    sort(re.begin(),re.end(),greater<ll>());
                    // for(auto &it:re)cout<<it<<" ";cout<<endl;
                    continue;
                }
            }
            le=le+a[i]-a[i-1]-(le+a[i]-a[i-1]+cur-1)/cur;
            ll temp=le;
            for(ll i=0;i<cur;i++)
            {
                re[i]=(temp+cur-i-1)/cur;
            }
            // re[0]=0;
            // sort(re.begin(),re.end(),greater<ll>());
        }
        // cout<<a[i]<<" "<<le<<" "<<cur<<endl;
    }

    cout<<le+l-a[n-1]<<"\n";
    
}

signed main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    ll t;cin >> t;while (t--)
    solve();
}