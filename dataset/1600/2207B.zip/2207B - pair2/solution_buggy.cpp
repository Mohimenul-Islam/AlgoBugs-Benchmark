#include <bits/stdc++.h>
using namespace std;

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;

using ll = long long;
template <class T>
using Tree = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

const int MAX = 51;
const int MOD = 998244353;

long long fact[MAX];
long long invFact[MAX];

long long fast_pow(long long base, long long p)
{
    long long res = 1;
    while (p > 0)
    {
        if (p % 2 == 1)
            res = (res * base) % MOD;
        base = (base * base) % MOD;
        p /= 2;
    }
    return res;
}
long long inverse(long long n)
{
    return fast_pow(n, MOD - 2);
}
void precompute()
{
    fact[0] = 1;
    invFact[0] = 1;
    for (int i = 1; i < MAX; i++)
    {
        fact[i] = (fact[i - 1] * i) % MOD;
    }
    invFact[MAX - 1] = inverse(fact[MAX - 1]);
    for (int i = MAX - 2; i >= 1; i--)
    {
        invFact[i] = (invFact[i + 1] * (i + 1)) % MOD;
    }
}

long long nCr(int n, int k)
{
    if (k < 0 || k > n)
        return 0;
    return (((fact[n] * invFact[k]) % MOD) * invFact[n - k]) % MOD;
}

long long __lcm(long long a, long long b)
{
    return a * b / (__gcd(a, b));
}

void solve()
{
    int n, m, l;
    cin >> n >> m >> l;
    map<int,int> t;
    int sz = 0;
    for(int i = 0; i < n; i++)
    {
        int u;
        cin >> u;
        t[u]++;
        if(t[u] == 1) sz++;
    }
    multiset<int> ms;
    for(int i = 0; i < m; i++)
    {
        ms.insert(0);
    }
    for(int i = 1; i <= l; i++)
    {
        auto it = ms.begin();
        int aux = *it;
        ms.erase(it);
        ms.insert(aux + 1);
        while(t[i])
        {
            auto it = ms.end();
            it--;
            ms.erase(it);
            t[i]--;
            if(!t[i]) sz--;
            if(sz >= (int)ms.size())
            {
                ms.insert(0);
            }
        }
    }
    cout << *ms.rbegin() << "\n";
}

int main()
{
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int tt;
    tt = 1;
    cin >> tt;
    while (tt--)
    {
        solve();
    }
}