#include <bits/stdc++.h>
using namespace std;
#define int long long
void solve()
{
   int n, m, l;
   cin >> n >> m >> l;
   vector<int> a(n + 1, 0);
   for (int i = 1; i <= n; i++)
   {
      cin >> a[i];
   }
   int sum = 0, pre = -1, p = 0;
   for (int i = 1; i <= n; i++)
   {
      pre = min(m, n - i + 2);
      int t = pre - 1;
      if ((a[i] - sum + pre - 1) / pre >= p)
      {
         sum += (a[i] - sum + pre - 1) / pre;
         if (t > 0)
            p = (a[i] - sum + t - 1) / t;
      }
      else
      {
         sum += p;
         if (t - 1 > 0)
            p = (a[i] - sum - (a[i] - a[i - 1]) + t - 2) / (t - 1);
         else if (t > 0)
            p = a[i] - a[i - 1];
      }
      // cout << p << "\n";
      //  cout << sum << "\n";
   }
   cout << l - sum << "\n";
}
signed main()
{
   ios::sync_with_stdio(0);
   cin.tie(0);
#ifndef ONLINE_JUDGE
   freopen("in.txt", "r", stdin);
   freopen("out.txt", "w", stdout);
#endif
   int T = 1;
   cin >> T;
   while (T--)
   {
      solve();
   }
   return 0;
}