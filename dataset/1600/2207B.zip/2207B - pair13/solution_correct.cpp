#include <bits/stdc++.h>
using namespace std;
#define int long long
void solve()
{
   int n, m, l;
   cin >> n >> m >> l;
   vector<int> a(n + 1, 0);
   for (int i = 1; i <= n; i++)
   {
      cin >> a[i];
   }
   map<int, int> mp;
   int tot = 0;
   for (int i = 1; i <= n; i++)
   {
      int k = min(m, n - i + 2);
      int d = a[i] - a[i - 1];
      if (tot < k)
      {
         mp[0] += k - tot;
         tot = k;
      }
      while (d > 0)
      {
         if (mp.size() == 1)
         {
            auto it = mp.begin();
            int val = it->first, cnt = it->second;
            int t1 = d / cnt;
            int t2 = d % cnt;
            mp.erase(it);
            if (t2)
            {
               mp[val + t1 + 1] += t2;
               mp[val + t1] += cnt - t2;
            }
            else
            {
               mp[val + t1] += cnt;
            }
            d = 0;
         }
         else
         {
            auto it1 = mp.begin();
            auto it2 = next(it1);
            int val1 = it1->first, cnt1 = it1->second;
            int val2 = it2->first, cnt2 = it2->second;
            int d1 = val2 - val1;
            if (d >= d1 * cnt1)
            {
               mp.erase(it1);
               it2->second += cnt1;
               d -= d1 * cnt1;
            }
            else
            {
               mp.erase(it1);
               int t1 = d / cnt1;
               int t2 = d % cnt1;
               if (t2)
               {
                  mp[val1 + t1 + 1] += t2;
                  mp[val1 + t1] += cnt1 - t2;
               }
               else
               {
                  mp[val1 + t1] += cnt1;
               }
               d = 0;
            }
         }
      }
      auto it = prev(mp.end());
      it->second--;
      if (it->second == 0)
         mp.erase(it);
      tot--;
   }
   mp[0] = 0;
   auto it = prev(mp.end());
   cout << it->first + l - a[n] << "\n";
}
signed main()
{
   ios::sync_with_stdio(0);
   cin.tie(0);
#ifndef ONLINE_JUDGE
   freopen("in.txt", "r", stdin);
   freopen("out.txt", "w", stdout);
#endif
   int T = 1;
   cin >> T;
   while (T--)
   {
      solve();
   }
   return 0;
}