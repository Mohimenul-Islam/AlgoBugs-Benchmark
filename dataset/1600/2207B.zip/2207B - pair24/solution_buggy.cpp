#include<bits/stdc++.h>
using namespace std;
using ll=long long;
int main(){
  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  ll T;cin>>T;
  while(T--){
    ll n,m,l;cin>>n>>m>>l;
    vector<ll> a(n+1);
    for(ll i=1;i<=n;i++)cin>>a[i];

    ll zz=min(n+1,m),t=n;
    map<ll,ll> mp;
    mp[0]=zz;

    for(ll i=1;i<=n;i++,t--){
      ll d=a[i]-a[i-1];

      while(d&&mp.size()>1){
        auto it=mp.begin();
        ll pos=it->first,cnt=it->second;
        auto it2=next(it);
        ll target=it2->first;
        ll gap=cnt*(target-pos);

        if(d>=gap){
          d-=gap;
          mp[target]+=cnt;
          mp.erase(pos);
        }
        else{
          ll g=d/cnt,res=d%cnt;
          mp[pos+g+1]+=res;
          if(g==0){
            mp[pos]-=res;
            if(mp[pos]==0)mp.erase(pos);
          }
          else{
            mp[pos+g]+=cnt-res;
            mp.erase(pos);
          }
          d=0;
        }
      }

      if(d){
        ll pos=mp.begin()->first,cnt=mp.begin()->second;
        ll g=d/zz,res=d%zz;
        if(res==0){
          mp[pos+g]+=cnt;
          mp.erase(pos);
        }
        else{
          mp[pos+g+1]+=res;
          if(g==0){
            mp[pos]-=res;
            if(mp[pos]==0)mp.erase(pos);
          }
          else{
            mp[pos+g]+=cnt-res;
            mp.erase(pos);
          }
        }
      }

      auto it=prev(mp.end());
      it->second--;
      if(it->second==0)mp.erase(it);

      if(t>=m)mp[0]++;

      zz=min(m,t);
    }

    cout<<mp.begin()->first+l-a[n]<<'\n';
  }
  return 0;
}