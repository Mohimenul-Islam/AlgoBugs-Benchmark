#include<bits/stdc++.h>
using namespace std;
using ll=long long;
int main(){
	ll T;cin>>T;
	while(T--){
		ll n,m,l;cin>>n>>m>>l;
		map<ll,ll> mp;
		for(ll i=1;i<=n;i++){
			ll a;cin>>a;
			mp[a]=1;
		}
		ll zz=min(n+1,m),t=n;
		vector<ll> d(zz);
		for(ll i=1;i<=l;i++){
			sort(d.begin(),d.end());
			d[0]++;
			if(mp[i]==1){
				t--;
				sort(d.begin(),d.end());
				d.pop_back();
				if(t>m-2)d.push_back(0);
//				sort(d.begin(),d.end());
			}
//			cout<<i<<endl;
//			for(auto x:d)cout<<x<<" ";cout<<endl;
		}
		cout<<d[0]<<endl;
	}
	return 0;
}