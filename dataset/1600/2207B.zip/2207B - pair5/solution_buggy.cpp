#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int a[N];
void solve(){
    int n,m,l;cin>>n>>m>>l;
    for(int i=1;i<=n;i++) cin>>a[i];
      int temp1=-1;
        int cnt=m;
                    int diff=0;
        int sum=0;
        for(int i=1;i<=n;i++){
             if(n-i+1<m-1) cnt--;
              sum+=a[i]-a[i-1];

            if(sum%cnt==0){
                diff=max(diff,sum/cnt);
                sum-=diff;
            }
          
            else{
              int temp2=0;
              if(cnt>sum){
                temp2=1;
              }
              else{
                // if(sum%cnt<cnt){
                //     temp2=cnt;
                // }
                // else
                 temp2=sum/cnt+1;
              }
                int temp=max(temp1,temp2);
                if(temp2==1){
                    temp1=1;
                }
                else temp1=sum/cnt;
                sum-=temp;
            }
            
   
        }
        sum+=(l-a[n]);
        if(sum<0) sum=0;
        cout<<sum<<endl;


   
}
int main(){
    int t ;cin>>t;
    while(t--){
        solve();
    }
    return 0;
}