#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int a[N];
void solve(){
    int n,m,l;cin>>n>>m>>l;
    for(int i=0;i<n;i++) cin>>a[i];
    vector<int> ans(m,0);
    int cur=n;
     for(int i=0;i<l;i++){
        ans[min(m,cur+1)-1]++;
        sort(ans.begin(),ans.end(),greater<int> ());
        if(cur>0&&a[n-cur]==i+1){
            ans[0]=0;
            sort(ans.begin(),ans.end(),greater<int>());
            cur--;
        }
     }
     cout<<ans[0]<<endl;
   
}
int main(){
    int t ;cin>>t;
    while(t--){
        solve();
    }
    return 0;
}