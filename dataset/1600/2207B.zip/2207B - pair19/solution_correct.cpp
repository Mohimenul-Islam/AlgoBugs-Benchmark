#include<bits/stdc++.h>
#define ll long long
#define lc id<<1
#define rc id<<1|1
#define lowbit(x) x&-x
#define pii pair<int, int>
#define aii array<int,3>
using namespace std;
const int N=2e5+100;
void solve(){
    ll n,m,k,sum=0;
    cin>>n>>m>>k;
    n++;
    m=min(n,m);
    vector<ll> a(n+1);
    for(ll i=1;i<=n-1;i++)
        cin>>a[i];
    a[n]=k;
    priority_queue<ll> l;
    priority_queue<ll,vector<ll>,greater<>> r;
    for(ll i=1;i<=m;i++)
        r.push(0);
    for(ll i=1;i<=n;i++){
        for(ll j=1;j<=a[i]-a[i-1];j++){
            auto u=r.top();
            r.pop();
            r.push(u+1);
        }
        auto s=min(m,n-i);
        while(r.size()){
            auto u=r.top();
            r.pop();
            l.push(u);
        }
        l.pop();
        while(l.size()){
            auto u=l.top();
            l.pop();
            r.push(u);
        }
        while(r.size()<s)
            r.push(0);
    }
    cout<<l.top()<<endl;
}
int main(){
    ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
    int T=1;
    cin>>T;
    while(T--){
        solve();
    }
}