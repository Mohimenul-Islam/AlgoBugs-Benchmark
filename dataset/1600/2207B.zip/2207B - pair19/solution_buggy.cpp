#include<bits/stdc++.h>
#define ll long long
#define lc id<<1
#define rc id<<1|1
#define lowbit(x) x&-x
#define pii pair<int, int>
#define aii array<int,3>
using namespace std;
const int N=2e5+100;
void solve(){
    ll n,m,l;
    cin>>n>>m>>l;
    vector<ll>a(n+1);
    for(int i=1;i<=n;i++){
         cin>>a[i];
    }
  sort(a.begin(),a.end());
  vector<ll>d(m+1,0);
  ll num=0;
  for(int i=1;i<=n;i++){
      ll t=a[i];
      t-=num;
      if(n-i+2<m){
          ll len=n-i+2;
          ll a=t/len,b=t%len;
          ll mx=a+(b!=0);
          num+=mx;
          for(int j=1;j<=len;j++){
             if(j<=b)d[j]=a+1;
             else d[j]=a;
          }
      }
      else{
         ll a=t/m,b=t%m;
          ll mx=a+(b!=0);
          if(d[1]>mx){
             num+=d[1];
             d[m]=t-(m-1)*d[1];
             continue;
          }
          num+=mx;
          for(int j=1;j<=m;j++){
              if(j<=b)d[j]=a+1;
              else d[j]=a;
          }
      }
  }
  sort(d.begin()+1,d.end(),[&](ll a,ll b){return a>b;});
  if(m==1){
     cout<<l-a[n]<<endl;
     return;
  }
  cout<<d[2]+l-a[n]<<endl;
}
int main(){
    ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
    int T=1;
    cin>>T;
    while(T--){
        solve();
    }
}