#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
int main()
{
    int tt,de=0,an=0,n,m,t,k;
    bool trf;
    vector<int>v;
    vector<int>vv;
    cin>>tt;
    while(tt--)
    {
        v.clear();de=0;an=0;vv.clear();
        cin>>n>>m>>t;
        for(int i=0;i<n;i++)
        {
            cin>>k;
            v.push_back(k);
        }
        vv.resize(m);
        if(m>n+1)
        {
            vv.resize(n+1);
        }
        for(int i=1,vi=0;i<t+1;i++)
        {
            ;int l=0;
            
            for(int r=vv.size()-2;l<=r;)
            {
                int mid=(l+r)/2;
                if(vv[mid]>vv[vv.size()-1])
                {
                    l=mid+1;
                }else
                {
                    r=mid-1;
                }
            }
            vv[l]+=1;
            if(vi<v.size()&&i==v[vi])
            {
                vv[0]=0;
                swap(vv[0],vv[vv.size()-1]);
                if(vv.size()>n-vi)
                {
                    vv.pop_back();
                }
                vi+=1;
            }
            
        }
        cout<<vv[0]<<"\n";

    }
}