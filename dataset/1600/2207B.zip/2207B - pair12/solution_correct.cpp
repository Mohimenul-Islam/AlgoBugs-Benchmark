#include <algorithm>
#include <bitset>
#include <iostream>
#include <math.h>
#include <numeric>
#include <set>
#include <unordered_map>
#include <unordered_set>
#include <vector>

using namespace std;

using ll = long long;

// Marcros
#define pb push_back
#define all(x) (x).begin(), (x).end()
#define sz(x) ((int)(x).size())
#define LOOP(i, a, n) for (int i = a; i < n; i++)
#define RLOOP(i, a, n) for (int i = n - 1; i >= a; i--)

const int INF = 1e9 + 5;
const ll LINF = 1e18;
const int MOD = 1e9 + 7;
const ll E = 1e-9;
const int MAXN = 1; // Set this to max N;

ll fact[MAXN], invFact[MAXN];

typedef vector<ll> v_ll;
typedef vector<vector<ll>> vv_ll;

typedef vector<int> v_i;
typedef vector<vector<int>> vv_i;
typedef pair<int, int> pii;
typedef pair<ll, ll> p_llll;

typedef vector<bool> v_b;

vector<int> prime_factors(int x) {
  vector<int> res;
  if (x % 2 == 0) {
    res.push_back(2);
    while (x % 2 == 0) {
      x /= 2;
    }
  }
  for (int p = 3; p * p <= x; p += 2) {
    if (x % p == 0) {
      res.push_back(p);
      while (x % p == 0) {
        x /= p;
      }
    }
  }
  if (x > 2) {
    res.push_back(x);
  }
  // uncomment if you dont want to include 1
  // if (x > 1) {
  //   res.push_back(x);
  // }
  return res;
}

ll modpow(ll base, ll exp, ll mod) {
  ll result = 1;
  base %= mod;

  while (exp > 0) {
    if (exp & 1)
      result = result * base % mod;

    base = base * base % mod;
    exp >>= 1;
  }

  return result;
}

ll modInverse(ll n) { return modpow(n, MOD - 2, MOD); }

// Call this once in main()
void precompute() {
  fact[0] = 1;
  invFact[0] = 1;
  for (int i = 1; i < MAXN; i++) {
    fact[i] = (fact[i - 1] * i) % MOD;
  }
  invFact[MAXN - 1] = modInverse(fact[MAXN - 1]);
  for (int i = MAXN - 2; i >= 1; i--) {
    invFact[i] = (invFact[i + 1] * (i + 1)) % MOD;
  }
}

ll nCr(int n, int r) {
  if (r < 0 || r > n) {
    return 0;
  };
  return fact[n] * invFact[r] % MOD * invFact[n - r] % MOD;
}

struct UFDS {
  vector<int> p;
  vector<int> r;
  int n;
  int components;

  UFDS(int n) : n(n) {
    p = vector<int>(n);
    r = vector<int>(n);
    components = n;
    LOOP(i, 0, n) {
      p[i] = i;
      r[i] = 1;
    }
  }

  int find(int x) {
    if (p[x] == x) {
      return p[x];
    }
    p[x] = find(p[x]);
    return p[x];
  }

  bool join(int x, int y) {
    int px = find(x);
    int py = find(y);

    if (px == py) {
      return false;
    }

    int rx = r[px];
    int ry = r[py];

    if (rx > ry) {
      p[py] = px;
    } else if (ry > rx) {
      p[px] = py;
    } else {
      p[px] = py;
      r[py]++;
    }
    components--;
    return true;
  }
};

// Meta-th second and sets its danger level back to zero, i.e.
// The animatonics probably wan to play a optimal game against u
//
// animatornics optimal move is probably to spread out the across n animatonics
// then n - 1, n - 2, n - 3. until l, if m > n;
//
// if n < m.
// then we continue the strat? with just max(m, n)
//
// so we have n moves,
// l - n
//
void solve() {
  int n, m, l;
  cin >> n >> m >> l;

  int k = n;
  v_i flash = v_i(n);
  LOOP(i, 0, n) { cin >> flash[i]; }
  v_i bots = v_i(min(m, k + 1), 0);

  int i = 0;
  LOOP(t, 1, l + 1) {
    bots[0]++;
    sort(all(bots));
    if (i < n) {
      // still have flash
      while (flash[i] < t) {
        i++;
      }
      if (flash[i] == t) {
        bots.pop_back();
        k--;
        i++;
      }
      if (bots.size() < min(k + 1, m)) {
        bots.push_back(0);
      }
      sort(all(bots));
    }
  }
  cout << bots[bots.size() - 1] << '\n';

  // solve logic
}

int main() {
  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  int t;
  cin >> t;
  while (t--)
    solve();

  cout.flush();
  return 0;
}
