#include <bits/stdc++.h>
using namespace std;
#define int long long
using pii = pair<int,int>;

void solve(){
    int n, m, l;
    cin >> n >> m >> l;
    vector<int> a(n);
    for(int i = 0; i < n; i++) {
        cin >> a[i];
    }
    multiset<int> mst;
    for(int i = 0; i < min(m, n + 1); i++) {
        mst.insert(0);
    }
    int r = 0, cur = 0;
    for(; cur < l && r < n;) {
        cur++;
        int t = *mst.begin();
        mst.erase(mst.begin());
        mst.insert(t + 1);
        if(a[r] == cur) {
            auto it = mst.end();
            --it;
            mst.erase(it);
            if(mst.size() < n - r) {
                mst.insert(0);
            }
            r++;
        }
    }
    cout << *mst.rbegin() + (l - cur) << '\n';
}

signed main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t = 1;
    cin >> t;
    while(t--) solve();
}