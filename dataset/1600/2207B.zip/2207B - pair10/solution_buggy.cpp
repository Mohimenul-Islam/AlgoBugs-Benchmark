#include<bits/stdc++.h>
#define int long long

using namespace std;

typedef __int128 i128;
typedef pair<int,int> PII;

void solve(void){
	int n,m,l;cin>>n>>m>>l;
	vector<int> arr(n+1);
	for(int i = 1; i <= n; i++){
		cin>>arr[i];
	}
	vector<int> val(m+1,0);
	unordered_map<int,int> ok;
	int index = 1;
	for(int i = 1; i <= l; i++){
		if(index <= n - m + 1){
			int mmin = 0x3f3f3f3f;
			int pos = -1;
			for(int j = 1; j <= m; j++){
				if(val[j] < mmin){
					mmin = val[j];
					pos = j;
				}
			}
			val[pos]++;
			if(index <= n && arr[index] == i){
				int mmax = -1;
				int pos = -1;
				for(int j = 1; j <= m; j++){
					if(mmax < val[j]){
						mmax = val[j];
						pos = j;
					}
				}
				val[pos] = 0;
				index++;
			}
		}else{
			int mmin = 0x3f3f3f3f;
			int pos = -1;
			for(int j = 1; j <= m; j++){
				if(ok[j] == 1){
					continue;
				}
				if(val[j] < mmin){
					mmin = val[j];
					pos = j;
				}
			}
			val[pos]++;
			if(index <= n && arr[index] == i){
				int mmax = -1;
				int pos = -1;
				for(int j = 1; j <= m; j++){
					if(ok[j] == 1){
						continue;
					}
					if(mmax < val[j]){
						mmax = val[j];
						pos = j;
					}
				}
				val[pos] = 0;
				ok[pos] = 1;
				index++;
			}
		}
	}
	int ans = -1;
	for(int i = 1; i <= m; i++){
		ans = max(ans,val[i]);
	}
	cout<<ans<<'\n';
}
signed main(void){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int t;cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
