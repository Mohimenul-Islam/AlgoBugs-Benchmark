#include <bits/stdc++.h>
using namespace std;
#define v vector
#define int long long
#define pb push_back
#define ll long long
#define INF LLONG_MAX
#define NINF LLONG_MIN
#define full(a) a.begin(),a.end()
#define get(a) for(int i=0; i<a.size(); i++){cin>>a[i];}
#define db long double
#define debugm(a) for(int i =0; i<a.size(); i++){for(int j = 0; j<a[i].size(); j++){cout<<a[i][j]<<" ";}cout<<endl;}cout<<endl; 
#define debugl(a) for(int i =0; i<a.size(); i++){cout<<a[i]<<" ";} cout<<endl;


bool cmp(int a,int b){
    return a>b;
}
void solve(){
    int n,m,l;
    cin>>n>>m>>l;
    v<int> stopoints(n);
    get(stopoints);
    v<int> formaq(m,0);
    for(int i=0; i<n; i++){
        int toadd;
        if(i == 0){
            toadd=stopoints[i];
        }else{
            toadd=stopoints[i]-stopoints[i-1];
        }
        int maxv = formaq[0];
        int stopp=min(n+1-i,m);
        int s =0;
        int e =l;
        int best =0;
        while(s <=e){
            int mid = s + (e-s)/2;
            int tot=0;
            for(int i =0; i<stopp; i++){
                tot+=max(mid - formaq[i],(ll)0);
            }
            if(tot <=toadd){
                s=mid+1;
                best=max(best,mid);
            }else{
                e=mid-1;
            }
        }
        for(int i =0; i<stopp; i++){
            toadd-=max((ll)0,best-formaq[i]);
            formaq[i]=max(formaq[i],best);
        }
        for(int i =0; i<stopp; i++){
            if(toadd>0 && formaq[i]==best){
                formaq[i]++;
                toadd--;
            }
        }
        formaq[0]=0;
        sort(full(formaq),cmp);
    }
    formaq[0]+=l-stopoints[n-1];
    cout<<formaq[0]<<endl;
}
signed main() {
    ios_base::sync_with_stdio(false); 
    cin.tie(nullptr);
    int t=1;
    cin>>t;
    for(int i =0; i<t; i++){
        solve();
    }
}