#include <bits/stdc++.h>
using namespace std;
#define v vector
#define int long long
#define pb push_back
#define ll long long
#define INF LLONG_MAX
#define NINF LLONG_MIN
#define full(a) a.begin(),a.end()
#define get(a) for(int i=0; i<a.size(); i++){cin>>a[i];}
#define db long double
#define debugm(a) for(int i =0; i<a.size(); i++){for(int j = 0; j<a[i].size(); j++){cout<<a[i][j]<<" ";}cout<<endl;}cout<<endl; 
#define debugl(a) for(int i =0; i<a.size(); i++){cout<<a[i]<<" ";} cout<<endl;


bool cmp(int a,int b){
    return a>b;
}
void solve(){
    int n,m,l;
    cin>>n>>m>>l;
    v<int> stopoints(n);
    get(stopoints);
    v<int> formaq(m,0);
    for(int i=0; i<n; i++){
        int toadd;
        if(i == 0){
            toadd=stopoints[i];
        }else{
            toadd=stopoints[i]-stopoints[i-1];
        }
        int maxv = formaq[0];
        int stopp=min(n+1-i,m);
        for(int maq=stopp-1; maq>=0; maq--){
            if(formaq[maq]<maxv){
                int chang=maxv-formaq[maq];
                formaq[maq]+= min(toadd,chang);
                toadd-=min(toadd,chang);
            }
        }
        int ind = 0;
        int toeach = toadd/stopp;
        while(toadd >0){
            formaq[ind]+=toeach;
            toadd-=toeach;
            if(toadd-toeach*(stopp-ind-1) > 0){
                formaq[ind]++;
                toadd--;
            }
            ind++;
        }
        formaq[0]=0;
        sort(full(formaq),cmp);
    }
    formaq[0]+=l-stopoints[n-1];
    cout<<formaq[0]<<endl;
}
signed main() {
    ios_base::sync_with_stdio(false); 
    cin.tie(nullptr);
    int t=1;
    cin>>t;
    for(int i =0; i<t; i++){
        solve();
    }
}