#include <bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int tt;
    cin>>tt;
    while(tt--){
        int n,m,l;
        cin>>n>>m>>l;
        
        int sum=0;
        int temp=0;
        int k=n+1;
        vector<int> a(n+2);
        for(int i=1;i<=n;i++){
            cin>>a[i];
            sum+=a[i]-a[i-1];
            int j=min(k,m);
            int val=(sum+j-1)/j;
            sum-=max(temp,val);
            if(j>1){
                temp=(sum+j-2)/(j-1);
            }
            k--;
        }
        cout<<sum+l-a[n];
        cout<<endl;
    }
    return 0;
}