#include <bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int tt;
    cin>>tt;
    while(tt--){
        int n,m,l;
        cin>>n>>m>>l;
        
        vector<bool> a(l+1);
        for(int i=1;i<=n;i++){
            int x;
            cin>>x;
            
            a[x]=1;
        }
        vector<int> an(m);
        int k=1+n;
        for(int i=1;i<=l;i++){
            an[min(k,m)-1]++;
            sort(an.begin(),an.end(),greater<int>());
            if(a[i]){ 
                an[0]=0;
                k--;
            }
            sort(an.begin(),an.end(),greater<int>());
        }
        cout<<an[0];
        cout<<endl;
    }
    return 0;
}