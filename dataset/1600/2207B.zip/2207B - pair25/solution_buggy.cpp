#include <bits/stdc++.h>
using namespace std;
// #define int long long
#define endl '\n'
#define x first
#define y second
const int N = 3e5 + 5;
const int mod = 998244353;
bool cmp(int x, int y)
{
    return x > y;
}
void solve()
{
    int n, m, l;
    cin >> n >> m >> l;
    vector<int> a(n + 10, 0);
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    int cnt = 1;
    vector<int> now(m + 10, 0);
    int q = 1;
    int x = 0;
    if (m > n)
    {
        for (int i = 1; i <= l; i++)
        {
            while (now[cnt] == -1)
            {
                cnt++;
                if (cnt == n + 2)
                {
                    cnt = 1;
                }
            }
            now[cnt]++;
            if (i == a[q])
            {
                now[cnt] = -1;
                q++;
            }
            cnt++;
            if (cnt == n + 2)
            {
                cnt = 1;
            }
        }
        int ans = 0;
        for (int i = 1; i <= m; i++)
        {
            ans = max(ans, now[i]);
        }
        cout << ans << endl;
    }
    else
    {
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq1;
        for (int i = 1; i <= m; i++)
            for (int i = 1; i <= m; i++)
            {
                pq.push({0, i});
            }
        int h = 0;
        for (int i = 1; i <= l; i++)
        {
            int x = pq.top().first;
            int y = pq.top().second;
            pq.pop();
            x++;
            now[y] = x;
            pq.push({x, y});
            if (i == a[q])
            {
                int mx = 0;
                int r = 1;
                q++;
                for (int j = 1; j <= m; j++)
                {
                    if (now[j] > mx)
                    {
                        mx = now[j];
                        r = j;
                    }
                }
                now[r] = 0;
                while (pq.size())
                {
                    pq.pop();
                }
                for (int j = 1; j <= m; j++)
                {
                    pq.push({now[j], j});
                }
                if (n - q + 1 < m)
                {
                    // cout<<i<<" "<<q<<endl;return;
                    n = n - q + 1;
                    sort(now.begin() + 1, now.begin() + 1 + m, cmp);
                    for (int j = 1; j <= n + 1; j++)
                    {
                        pq1.push({now[j], j});
                        // now[j] = -1;
                    }
                    h = i;
                    break;
                }
            }
        }

        for (int i = h + 1; i <= l; i++)
        {
            int x = pq1.top().first;
            int y = pq1.top().second;
            pq1.pop();
            x++;
            now[y] = x;
            pq1.push({x, y});
            if (i == a[q])
            {
                q++;
                while (pq1.size())
                {
                    pq1.pop();
                }
                int mx = 0;
                int r = 1;
                for (int j = 1; j <= n + 1; j++)
                {
                    if (now[j] > mx)
                    {
                        mx = now[j];
                        r = j;
                    }
                }
                now[r] = -1;
                for (int j = 1; j <= n + 1; j++)
                {
                    if (now[j] == -1)
                        continue;
                    pq1.push({now[j], j});
                }
            }
        }
        int ans = 0;
        for (int i = 1; i <= m; i++)
        {
            ans = max(ans, now[i]);
        }
        cout << ans << endl;
    }
}
signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    int T = 1;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}