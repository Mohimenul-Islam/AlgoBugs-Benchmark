#include <bits/stdc++.h>

using namespace std;

using ll = long long;
using vi = vector<int>;
using vll = vector<ll>;
using vvi = vector<vi>;
using vvll = vector<vll>;
using vs = vector<string>;
using vc = vector<char>;
using vb = vector<bool>;
using vf = vector<float>;
using vd = vector<double>;
using pi = pair<int,int>;
using pll = pair<ll,ll>;
using pci = pair<char,int>;
using qi = queue<int>;
using qll = queue<ll>;
using di = deque<int>;
using dll = deque<ll>;
using vpll = vector<pll>;
#define Nfor0(i, N) for(ll i=0; i < N; i++)
#define Nfor1(i, N) for(ll i=1; i <= N; i++)
#define all(v) (v).begin(), (v).end()
#define rall(v) (v).rbegin(), (v).rend()
#define pb push_back
#define pf push_front

const ll inf=LONG_LONG_MAX, mod=1e9+7, LOG=18;
mt19937 rng((unsigned int) chrono::steady_clock::now().time_since_epoch().count());

ll random_num(ll l, ll r) {
    uniform_int_distribution<ll> dist(l, r);
    return dist(rng);
}

ll modinv(ll a){
	ll ans = 1;

	for(ll x=mod-2; x; x >>= 1){
	    if(x & 1) ans = ans * a % mod;
        a = a * a % mod;
    }

	return ans;
}

ll qpow(ll a, ll pow, ll mod){
	ll ans = 1;
    a %= mod;

	for(ll x=pow; x; x >>= 1){
	    if(x & 1) ans = (ans * a) % mod;
        a = (a * a) % mod;
    }

	return ans;
}

ll qpow(ll a, ll pow){
    ll ans = 1;

	for(ll x=pow; x; x >>= 1){
	    if(x & 1) ans = (ans * a);
        a = (a * a);
    }

	return ans;
}

ll fact(ll n, vll &mem){
    if(n == 1) return 1;
    if(mem[n] != -1) return mem[n];
    return mem[n] = (n * fact(n-1, mem)) % mod;
}

ll perm(ll n, ll r, vll &mem){
    return (fact(n, mem) * modinv((fact(n-r, mem)))) % mod;
}

ll comb(ll n, ll r, vll &mem){
    return (fact(n, mem) * modinv(((fact(n-r, mem) * fact(r, mem)) % mod))) % mod;
}

vll get_divisors(ll n){
    vll divisors;

    for(ll i=1; i*i <= n; i++){
        if(n % i == 0){
            divisors.pb(i);
            if(i*i != n) divisors.pb(n/i);
        }
    }

    return divisors;
}

vll sieve(ll n){
    vb marked(n+1, false);
    vll primes;

    for(int i=2; i*i <= n; i++){
        if(!marked[i]){
            for(int j=i*i; j <= n; j += i)
                marked[j] = true;
        }
    }

    for(int i=2; i <= n; i++){
        if(!marked[i]) primes.pb(i);
    }

    return primes;
}

vll prefix_sum(vll v){
    vll Ps(1, 0);
    ll sum=0;

    for(int i=0; i < v.size(); i++){
        sum += v[i];
        Ps.pb(sum);
    }

    return Ps;
}

vll suffix_sum(vll v){
    vll Ss(1, 0);
    ll sum=0;
    
    for(int i=v.size()-1; i >= 0; i--){
        sum += v[i];
        Ss.pb(sum);
    }

    return Ss;
}

vector<pll> get_moves(ll x, ll y, ll N, ll M){
    vector<pll> moves;
    if(x+1 < N) moves.pb({x+1, y});
    if(x-1 >= 0) moves.pb({x-1, y});
    if(y+1 < M) moves.pb({x, y+1});
    if(y-1 >= 0) moves.pb({x, y-1});
    return moves;
}

void BFS(int start, vvll &adj, vb &vis, vll &dis){
    qll q;
    vis[start] = 1;
    dis[start] = 0;
    q.push(start);
    
    while(!q.empty()){
        ll u=q.front();
        q.pop();
        
        for(ll v: adj[u]){
            if(vis[v])continue;
            vis[v] = 1;
            dis[v] = dis[u] + 1;
            q.push(v);
        }
    }
}

void BFS(int startx, int starty, ll N, ll M, vector<vb> &vis, vvll &dis){
    queue<pll> q;
    vis[startx][starty] = 1;
    dis[startx][starty] = 0;
    q.push({startx, starty});
    
    while(!q.empty()){
        pll u=q.front();
        ll ux=u.first, uy = u.second;
        q.pop();

        for(auto [vx, vy]: get_moves(ux, uy, N, M)){
            if(vis[vx][vy])continue;
            vis[vx][vy] = 1;
            dis[vx][vy] = dis[ux][uy] + 1;
            q.push({vx, vy});
        }
    }
}

void DFS(int u, vvll &adj, vb &vis){
    vis[u] = 1;
    
    for(ll v: adj[u]){
        if(!vis[v]) DFS(v, adj, vis);
    }
}

void DFS(int ux, int uy, ll N, ll M, vector<vb> &vis){
    vis[ux][uy] = 1;
    
    for(auto [vx, vy]: get_moves(ux, uy, N, M)){
        if(!vis[vx][vy]) DFS(vx, vy, N, M, vis);
    }
}

void dijkstra(int start, vector<vector<pll>> &adj, vb &vis, vll &dis){
    priority_queue<pll, vector<pll>, greater<pll>> pq;
    dis[start] = 0;
    pq.push({0, start});
    
    while(!pq.empty()){
        int u=pq.top().second;
        pq.pop();
        
        if(vis[u])continue;
        vis[u] = 1;
        
        for(auto [v, w]: adj[u]){
            if(dis[u] + w < dis[v]){
                dis[v] = dis[u] + w;
                pq.push({dis[v], v});
            }
        }
    }
}

class DSU{
    private:
        ll tam;
        vll link;
        vll sise;

    public:
        DSU(ll tam): tam(tam), link(tam+1), sise(tam+1, 1){
            for(int i=0; i <= tam; i++){
                link[i] = i;
            }
        }

        int find(int x){
            if(x != link[x]) link[x] = find(link[x]);
            return link[x];
        }

        bool same(int a, int b){
            return find(a) == find(b);
        }

        void unite(int a, int b){
            if(same(a, b)) return;
            a = find(a);
            b = find(b);
            if(sise[a] < sise[b]) swap(a, b);
            sise[a] += sise[b];
            link[b] = a;
        }

        vll getSize() {return sise;}
        ll getSize(ll pos) {return sise[pos];}
        vll getLink() {return link;}
        ll getLink(ll pos) {return link[pos];}
};

class SegmentTree{
    private:
        ll tam;
        vll segT;
        vll lazy;
        const ll lazy_start = -1; // Nota (Lazy): Revisar en qué empezar y descomentar updates.

    public:
        SegmentTree(ll tam): tam(tam), segT((tam*4)+5, 0), lazy((tam*4)+5, lazy_start) {}

        ll op(ll x, ll y){
            return min(x, y); // Nota: Cambiar la operación.
        }

        void update_lazy(int node, int x, int y){
            if(lazy[node] != lazy_start){
                segT[node] += lazy[node]; // Nota (Lazy): Revisar como cambiar el valor del nodo.
                if(x != y){
                    // Nota (Lazy): Revisar si se reemplazan o se almacenan los valores.
                    lazy[node*2] += lazy[node];
                    lazy[node*2+1] += lazy[node];
                }
                lazy[node] = lazy_start;
            }
        }

        void update(int pos, ll v){
            update(1, 0, tam-1, pos, pos, v);
        }

        void update(int l, int r, ll v){
            update(1, 0, tam-1, l, r, v);
        }

        ll query(int pos){
            return query(1, 0, tam-1, pos, pos);
        }

        ll query(int l, int r){
            return query(1, 0, tam-1, l, r);
        }
        
        ll find(int l, int r, ll v){
            return find(1, 0, tam-1, l, r, v);
        }

        void update(int node, int x, int y, int a, int b, ll v){
            //update_lazy(node, x, y);

            if(x == a && y == b){
                segT[node] = v; // Nota: Revisar si reemplaza o modifica el valor.
                if(x != y){
                    // Nota (Lazy): Revisar si se reemplazan o se almacenan los valores.
                    lazy[node*2] += v;
                    lazy[node*2+1] += v;
                }
                return;
            }

            int m = (x+y)/2;

            if(b <= m) update(node*2, x, m, a, b, v);
            else if(a > m) update(node*2+1, m+1, y, a, b, v);
            else {update(node*2, x, m, a, m, v); update(node*2+1, m+1, y, m+1, b, v);}

            segT[node] = op(segT[node*2], segT[node*2+1]);
        }

        ll query(int node, int x, int y, int a, int b){
            //update_lazy(node, x, y);

            if(x == a && y == b){
                return segT[node];
            }

            int m = (x+y)/2;

            if(b <= m) return query(node*2, x, m, a, b);
            if(a > m) return query(node*2+1, m+1, y, a, b);
            return op(query(node*2, x, m, a, m), query(node*2+1, m+1, y, m+1, b));
        }

        ll walk(int node, int x, int y, ll v){
            if(x == y) return x;
 
            int m = (x+y)/2;
 
            if(segT[node*2] >= v) return walk(node*2, x, m, v);
            if(segT[node*2+1] >= v) return walk(node*2+1, m+1, y, v);
            return -1;
        }
 
        ll find(int node, int x, int y, int a, int b, ll v){
            if(x == a && y == b){
                if(segT[node] >= v) return walk(node, x, y, v);
                else return -1;
            }
 
            int m = (x+y)/2;
 
            if(b <= m) return find(node*2, x, m, a, b, v);
            if(a > m) return find(node*2+1, m+1, y, a, b, v);
 
            ll left = find(node*2, x, m, a, m, v);
            if(left != -1) return left;
            return find(node*2+1, m+1, y, m+1, b, v);
        }
};

template <typename T>
void print1(T &v, int start, int end){
    for(int i=start; i <= end; i++){
        cout<<v[i];
        if(i < end) cout<<' ';
    }
    cout<<endl;
}
template <typename T>
void print1(T &v){
    print1(v, 0, v.size()-1);
}
template <typename T>
void print2(T &v, int start1, int end1, int start2, int end2){
    for(int i=start1; i <= end1; i++){
        for(int j=start2; j <= end2; j++){
            cout<<v[i][j];
            if(i < end2) cout<<' ';
        }
        cout<<endl;
    }
}
template <typename T>
void print2(T &v){
    print2(v, 0, v.size()-1, 0, v[0].size()-1);
}
template<typename... Args>
void println(Args&&... args) {
    bool first = true;
    ((cout << (first ? "" : " ") << args, first = false), ...);
    cout << endl;
}

#define TESTS

#ifdef LOCAL
#include "headers/debug_utils.hpp"
#include "headers/test_utils.hpp"
#define debug(...) debug_out(#__VA_ARGS__, __VA_ARGS__)
#else
#define debug(...)
#endif

ll N,M,K,Q,X,Y,L,R;

void timepass(ll t, ll k, multiset<ll> &animatronics){
    debug(t, k);

    k = min(k, M);
    ll mx = -1 * *animatronics.begin();
    multiset<pll> mst;
    ll i = 0, start_t = t;
    bool flag = false;
    for(auto x: animatronics){
        if(i >= k) break;
        i++;

        if(x == -mx) continue;
        if(t >= mx+x){
            mst.insert({x, -mx});
            t -= mx+x;
        }else{
            flag = true;
            t = start_t;
        }

        if(!t || flag) break;
    }
    if(!flag){
        //debug(mst);
        for(auto [x, y]: mst){
            animatronics.erase(animatronics.find(x));
            animatronics.insert(y);
        }
        //debug(animatronics);
    }else{
        multiset<ll> mst1;
        ll j = 0;
        for(auto x: animatronics){
            if(j >= k) break;
            j++;

            mst1.insert(-x);
        }
        Nfor0(i, t){
            ll aux = *mst1.begin();
            mst1.insert(aux+1);
            mst1.erase(mst1.find(aux));
        }
        t = 0;

        Nfor0(i, mst1.size()) animatronics.erase(animatronics.begin());
        for(auto x: mst1) animatronics.insert(-x);
        //debug(animatronics);
    }

    while(t){
        ll curr = *animatronics.begin();
        ll i = 0;
        Nfor0(j, k){
            animatronics.erase(animatronics.find(curr));
            animatronics.insert(curr-1);

            t--;
            if(!t) break;
        }
    }

    if(animatronics.size()) {animatronics.erase(animatronics.begin()); animatronics.insert(0);}
}

void solve(int testcase){
    debug(testcase);
    ll ans = 0;

    cin>>N>>M>>L;
    vll a(N);
    Nfor0(i, N) cin>>a[i];

    multiset<ll> animatronics;
    Nfor0(i, M) animatronics.insert(0);
    Nfor0(i, N){
        timepass(a[i] - ((i > 0) ? a[i-1] : 0), N-i+1, animatronics);
        debug(animatronics);
    }
    ans = -*animatronics.begin() + L - a[N-1];

    println(ans);
}

int main(){
    #ifdef LOCAL
        freopen("IO_files/input.in", "r", stdin);
        freopen("IO_files/output.out", "w", stdout);
    #else
        //freopen(".in", "r", stdin);
        //freopen(".out", "w", stdout);
    #endif

    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    
    ll T=1;
    #ifdef TESTS
    cin>>T;
    #endif
    
    Nfor1(i, T) solve(i);

    #ifdef LOCAL
        fclose(stdin);
        fclose(stdout);
        freopen("CON", "w", stdout);
        cout<<endl;
        compare_outputs("IO_files/output.out", "IO_files/answer.out");
        cout<<endl;
    #endif
    return 0;
}