#include <bits/stdc++.h>
using namespace std;
#define int long long
void solve(){
    int n, m, l;
    cin >> n >> m >> l;
    vector<int>a(n);
    for(auto & it : a)cin >> it;
    vector<int>d(m, 0);
    int cur = n;
    for(int i =  0; i < l; i++){
        d[min(m, cur + 1) - 1]++;
        sort(d.begin(),d.end(),greater());
        if(cur > 0 && a[n - cur] - 1 == i){
            d[0] = 0;
            sort(d.begin(),d.end(),greater());
            cur--;
        }
    }
    cout << d[0] << '\n';
}
signed main() {
    int t;
    cin >> t;
    while(t--)solve();
}