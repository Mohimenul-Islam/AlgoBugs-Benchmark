#include <bits/stdc++.h>
using namespace std;
int n, m, L, a[200005];
void Solve() {
  cin >> n >> m >> L;
  for (int i = 1, x; i <= n; i++)
    cin >> x, a[x] = 1;
  multiset<int> s;
  for (int i = 1; i <= min(m, n + 1); i++)
    s.insert(0);
  int rem = n;
  for (int i = 1; i <= L; i++) {
    int x = *s.begin();
    s.erase(s.find(x));
    x++;
    s.insert(x);
    if (!a[i])
      continue;
    s.erase(--s.end());
    rem--;
    while (s.size() < min(rem + 1, m))
      s.insert(0);
  }
  cout << *--s.end() << '\n';
  for (int i = 1; i <= L; i++)
    a[i] = 0;
}
int main() {
  int t;
  cin >> t;
  while (t--)
    Solve();
}