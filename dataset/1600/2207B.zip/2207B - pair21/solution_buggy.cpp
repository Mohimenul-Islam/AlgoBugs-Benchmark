#include <bits/stdc++.h>
using namespace std;
int n, m, L, a[200005];
bool Check(int mid) {
  vector<int> is(L + 1), v(m + 1);
  for (int i = 1; i <= n; i++)
    is[a[i]] = 1;
  v[1] = mid;
  for (int i = L; i >= 1; i--) {
    sort(v.begin() + 1, v.end());
    if (is[i]) {
      if (v[1] > 0)
        return 0;
      v[1] = v[m];
      sort(v.begin() + 1, v.end());
    }
    if (v[1] > 0)
      v[1]--;
    else
      v[m] = max(v[m] - 1, 0);
  }
  for (int i = 1; i <= m; i++)
    if (v[i] > 0)
      return 0;
  return 1;
}
void Solve() {
  cin >> n >> m >> L;
  for (int i = 1; i <= n; i++)
    cin >> a[i];
  int l = 0, r = L, ans = -1;
  while (l <= r) {
    int mid = (l + r) / 2;
    if (Check(mid))
      ans = mid, l = mid + 1;
    else
      r = mid - 1;
  }
  cout << ans << '\n';
}
int main() {
  int t;
  cin >> t;
  while (t--)
    Solve();
}