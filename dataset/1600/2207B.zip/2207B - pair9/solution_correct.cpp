#include<cstdio>
#include<vector>
#include<algorithm>
using namespace std;
const int M=2e5+5;
int T,n,m,l;
int tim[M];
vector<int> G;
int min(int a,int b){return a<b?a:b;}
void solve(){
	scanf("%d %d %d",&n,&m,&l);
	for(int i=1;i<=n;i++) scanf("%d",tim+i);
	//tim[++n]=l;
	G.clear();
	int head=1;
	tim[n+1]=0;
	for(int i=1;i<=min(m,n+1);i++) G.push_back(0);
	//G.erase(G.end());
	//printf("%d\n",G.size());
	for(int i=1;i<=l;i++){
		G[0]++;
		sort(G.begin(),G.end());
		if(i!=tim[head]) continue;
		//printf("%d ",i);
		G[G.size()-1]=0;
		if(G.size()>=n-head+2) G.pop_back(); 
		else sort(G.begin(),G.end());
		head++;
	}
	printf("%d\n",G[0]);
	return;
}
int main(){
	scanf("%d",&T);
	while(T--) solve();
	return 0;
}