#include <bits/stdc++.h>
#define int long long
#define PII pair<int,int>
using namespace std;

int T, n, m, l, d[200010], a[200010], idx;
bool cu[200010];

signed main() {
	scanf("%lld", &T);
	while(T--) {
	    scanf("%lld%lld%lld", &n, &m, &l), idx = 0;
	    for(int i = 1; i <= n; i++) scanf("%lld", &a[i]);
	    for(int i = 1; i <= min(n+1, m); i++) cu[i] = 1;
	    for(int i = 1, x = 1; i <= l; i++, x++) {
	    	int p, mp;
	    	if(idx < n) {
				p = 0, mp = 0x3f3f3f3f;
	    		for(int j = 1; j <= m; j++) 
	    			if(d[j] < mp && cu[j]) mp = d[j], p = j;
	    		d[p]++;
	    	}
	    	else {
	    		p = 0, mp = 0;
	    		for(int j = 1; j <= m; j++)
		    		if(d[j] > mp) mp = d[j], p = j;
		    	d[p]++;
			}
	    	if(idx < n && a[idx+1] == i) {
	    		//cout << "out ";
		    	//for(int j = 1; j <= m; j++) cout << d[j] << ' ';
		    	//cout << endl;
	    		p = 0, mp = 0;
		    	for(int j = 1; j <= m; j++)
		    		if(d[j] > mp) mp = d[j], p = j;
		    	d[p] = 0, idx++;
		    	if(m > n-idx+1) cu[p] = 0;
		    }
		}
		for(int i = 1; i <= m; i++) 
			d[0] = max(d[0], d[i]), d[i] = cu[i] = 0;
		printf("%lld\n", d[0]), d[0] = 0;
	}

    return 0;
}