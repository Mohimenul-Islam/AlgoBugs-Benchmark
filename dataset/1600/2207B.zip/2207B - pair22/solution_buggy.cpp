#include <bits/stdc++.h>
using namespace std;

void solve() {
	int n, m, l;
	cin >> n >> m >> l;
	vector<int> a(n);
	for (int &i: a) cin >> i;
	vector<int> d(m, 0);
	
	int nleft = n;
	for (int i = 1; i <= l; i++) {
		sort(d.begin(), d.end());
		reverse(d.begin(), d.end());
		d[min(nleft+1, m)-1]++;

		if (a[n-nleft] == i) {
			sort(d.begin(), d.end());
			reverse(d.begin(), d.end());
			d[0] = 0;
			nleft--;
		}
	}
	cout << *max_element(d.begin(), d.end()) << endl;
}

int main() {
	int t;
	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
}
