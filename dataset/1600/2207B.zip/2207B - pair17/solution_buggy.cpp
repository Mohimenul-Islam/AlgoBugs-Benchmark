#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define pii pair<int,int>
#define fi first
#define se second
const int N = 2e5+10;
int n,m,l,a[N];
void solve() {
	cin >> n >> m >> l;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	priority_queue<int> q, rq;
	for (int i = 0; i < m; ++i) q.push(0);
	int cur = 0, ok = 1;
	for (int i = 1; i <= n; ++i) {
		int d = a[i]-a[i-1];
		while(q.size()) rq.push(-q.top()), q.pop();
		while(d--) {
			int x = rq.top(); rq.pop(); rq.push(x-1);
		}
		while(rq.size()) q.push(-rq.top()), rq.pop();
		q.pop(); 
		if (n-i+1 >= m) q.push(0);
//		if (n-i+1 >= m) {
//			
//		}
//		else {
//			for (int i = 0; i <= n-i+1; ++i) {
//				rq.push(-q.top()); q.pop();
//			}
//			while(d--) {
//				int x = rq.top(); rq.pop(); rq.push(x-1);
//			}
//			while(rq.size()) q.push(-rq.top()), rq.pop();
//			q.pop();
//		}
	}
	cout << q.top()+l-a[n] << '\n';
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	int t = 1; cin >> t;
	while(t--) solve();
	return 0;
}
