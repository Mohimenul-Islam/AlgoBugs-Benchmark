#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m,s;
int now = 0;
int st = 0;
void kmp(int len,int time,int c[],int f)
{
    int dt = time-now;
    sort(c+1,c+len+1);
    while(dt)
    {
    	dt--;
    	c[1] += 1;
    	sort(c+1,c+len+1);
	}
    if(f)c[len] = 0;
    now = time;
}
void solve()
{
    
    cin >>n>>m>>s;
    int a[n+1];
    int b[m+1];
    memset(b,0,sizeof b);
    now = 0;
    st = 0;
    for(int i=1;i<=n;i++)
    {
        cin >>a[i];
    }
    for(int i=1;i<=n;i++)
    {
    	int len = min(m,n-i+2);
        kmp(len,a[i],b,1);
    }
    kmp(1,s,b,0);
    cout <<b[1]<<endl;
}
signed main()
{
    int t;
    cin >>t;
    while(t--)
    {
        solve();
    }
    return 0;
}