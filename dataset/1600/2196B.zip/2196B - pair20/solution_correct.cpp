#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

void solve() {
    int n;
    cin >> n;
    
    // 为了防止任何溢出，直接用 long long 存数组
    vector<long long> a(n + 1);
    for (int i = 1; i <= n; ++i) {
        cin >> a[i];
    }
    
    long long ans = 0;
    long long B = sqrt(n);
    
    // 情况 1: a[i] <= B
    // x 使用 long long，防止下面 x * a[j] 时溢出
    for (long long x = 1; x <= B; ++x) {
        for (int j = 1; j <= n; ++j) {
            long long i = j - x * a[j];
            // 增加严格的边界检查 i <= n （实际上 i < j 更好，因为要求 i < j）
            if (i >= 1 && i < j && a[i] == x) {
                ans++;
            }
        }
    }
    
    // 情况 2: a[i] > B
    for (int i = 1; i <= n; ++i) {
        if (a[i] > B) {
            // k 使用 long long，防止 a[i] * k 溢出
            for (long long k = 1; i + a[i] * k <= n; ++k) {
                long long j = i + a[i] * k;
                // 这里 j 已经被 for 循环条件保证了 <= n，所以绝对安全
                if (a[j] == k) {
                    ans++;
                }
            }
        }
    }
    
    cout << ans << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int t;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}