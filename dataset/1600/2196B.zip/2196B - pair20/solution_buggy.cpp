#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

void solve() {
    int n;
    cin >> n;
    
    // 使用 1-based 索引，所以数组大小开到 n+1
    vector<int> a(n + 1);
    for (int i = 1; i <= n; ++i) {
        cin >> a[i];
    }
    
    long long ans = 0;
    int B = sqrt(n);
    
    // 情况 1: a[i] <= B (枚举 a[i] 的值 x)
    for (int x = 1; x <= B; ++x) {
        for (int j = 1; j <= n; ++j) {
            int i = j - x * a[j];
            // 检查算出的 i 是否合法，且该位置的值确实是 x
            if (i >= 1 && a[i] == x) {
                ans++;
            }
        }
    }
    
    // 情况 2: a[i] > B (遍历 i，枚举 a[j] 的值 k)
    for (int i = 1; i <= n; ++i) {
        if (a[i] > B) {
            // k 就是 a[j] 的值。保证 j = i + a[i] * k <= n
            for (int k = 1; i + a[i] * k <= n; ++k) {
                int j = i + a[i] * k;
                // 检查算出的 j 位置的值确实是 k
                if (a[j] == k) {
                    ans++;
                }
            }
        }
    }
    
    cout << ans << "\n";
}

int main() {
    // 优化输入输出流速度
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int t;
    cin >> t; // 多组测试数据
    while (t--) {
        solve();
    }
    return 0;
}