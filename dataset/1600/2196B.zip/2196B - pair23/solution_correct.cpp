#include <bits/stdc++.h>
using namespace std;

static const int MAXN = 200000 + 5;
static const int B = 450;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int T;
    cin >> T;
    while (T--) {
        int n;
        cin >> n;

        vector<vector<int>> pos(n);
        for (int i = 1; i <= n; i++) {
            int x;
            cin >> x;
            if (x < n) pos[x].push_back(i);
        }

        vector<int> heavyVals;
        vector<int> heavyId(n, -1);

        for (int v = 1; v < n; v++) {
            if ((int)pos[v].size() > B) {
                heavyId[v] = (int)heavyVals.size();
                heavyVals.push_back(v);
            }
        }

        vector< bitset<MAXN> > bits(heavyVals.size());
        for (int id = 0; id < (int)heavyVals.size(); id++) {
            int v = heavyVals[id];
            for (int p : pos[v]) bits[id].set(p);
        }

        long long ans = 0;

        // Process by the value on the right: y = a[j]
        for (int y = 1; y < n; y++) {
            if (pos[y].empty()) continue;

            // light y
            if (heavyId[y] == -1) {
                for (int x = 1; 1LL * x * y < n; x++) {
                    if (pos[x].empty()) continue;
                    int d = x * y;

                    // iterate all j with value y, check i = j - d in pos[x]
                    for (int j : pos[y]) {
                        int i = j - d;
                        if (i <= 0) continue;
                        if (binary_search(pos[x].begin(), pos[x].end(), i)) {
                            ans++;
                        }
                    }
                }
            }
            // heavy y
            else {
                int id = heavyId[y];
                for (int x = 1; 1LL * x * y < n; x++) {
                    if (pos[x].empty()) continue;
                    int d = x * y;

                    // iterate i in pos[x], check j = i + d in bitset(y)
                    for (int i : pos[x]) {
                        int j = i + d;
                        if (j <= n && bits[id].test(j)) {
                            ans++;
                        }
                    }
                }
            }
        }

        cout << ans << '\n';
    }

    return 0;
}