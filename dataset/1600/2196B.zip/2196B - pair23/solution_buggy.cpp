#include <iostream>
#include <vector>
#include <set>

using namespace std;
#define TEST
#define all(x) (x).begin(), (x).end()

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;

        vector<long long> a(n + 1);
        vector<set<int>> S(n + 1);

        for (int i = 1; i <= n; i++) {
            cin >> a[i];
            if (a[i] < n) {
                S[(int)a[i]].insert(i);
            }
        }
        // ai a(i+k) = k;

        long long cnt = 0;

        for (int i = 1; i <= n; i++) {
            for (int m = i; m <= n; m += i) {
                int other = m / i;
                if (other < 1 || other > n) continue;

                if (S[i].size() <= S[other].size()) {
                    for (int j : S[i]) {
                        int need = j - m;
                        if (S[other].find(need) != S[other].end()) {
                            cnt++;
                        }
                    }
                } else {
                    for (int j : S[other]) {
                        int need = j + m;
                        if (S[i].find(need) != S[i].end()) {
                            cnt++;
                        }
                    }
                }
            }
        }

        cout << cnt << '\n';
    }

    return 0;
}