#include <bits/stdc++.h>
using namespace std;

#define int long long
#define endl '\n'
#define pb push_back
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()
#define sz(x) (x).size()
#define fi first
#define se second

const int INF = 1e18;
const int MOD = 998244353;
const int B = 500;

void solve() {
    int n;
    cin >> n;
    int a[n];
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    int ans = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] >= B) {
            for (int j = i % a[i]; j < n; j += a[i]) {
                if (a[j] * a[i] == abs(j - i)) {
                    ans++;
                }
            }
        } else {
            for (int j = i; j < min(n, i + a[i] * B); j += a[i]) {
                if (a[j] * a[i] == j - i) {
                    ans++;
                }
            }
        }
    }
    cout << ans << endl;
}

int32_t main() {
    ios_base::sync_with_stdio(0);
    cin.tie(nullptr); cout.tie(nullptr);
    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
