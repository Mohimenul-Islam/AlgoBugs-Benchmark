// ██╗░░██╗██╗░░██╗██╗███████╗███████╗░█████╗░██████╗░██████╗░
// ██║░░██║██║░░██║██║╚════██║╚════██║██╔══██╗██╔══██╗██╔══██╗
// ╚██╗██╔╝╚██╗██╔╝██║░░███╔═╝░░███╔═╝███████║██████╔╝██║░░██║
// ░╚███╔╝░░╚███╔╝░██║██╔══╝░░██╔══╝░░██╔══██║██╔══██╗██║░░██║
// ░░╚█╔╝░░░░╚█╔╝░░██║███████╗███████╗██║░░██║██║░░██║██████╔╝
// ░░░╚╝░░░░░░╚╝░░░╚═╝╚══════╝╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝╚═════╝░
#include <bits/stdc++.h>
using namespace std;
#define F first
#define S second
#define tos to_string
#define __lcm(x, y) (x * y)/__gcd(x, y)
// #pragma GCC optimize ("O3,unroll-loops")
// #pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
#define int long long
#define abs llabs
#define all(v) v.begin(), v.end()
const int N = 2E5 + 5, M = 1E5 + 5, LOG = 30;
const int inf = 1E18, MOD = 1E9 + 7, MOD1 = 998244353;

void solve() {
    int n;
    cin >> n;
    int a[n + 1]{}, suf[n + 2]{};
    int ans = 0, block = sqrt(n) + 1;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    for (int i = 1; i <= n; i++) {
        if (a[i] < block) {
            for (int j = 1; i + a[i] * j <= n && j < block; j++) {
                if (a[i + a[i] * j] == j) {
                    ans++;
                }
            }
        }
        else {
            for (int j = i + a[i]; j <= n; j += a[i]) {
                if (a[i] * a[j] == j - i) {
                    ans++;
                }
            }
            for (int j = i - a[i]; j >= 1; j -= a[i]) {
                if (a[i] * a[j] == i - j) {
                    ans++;
                }
            }
        }
    }
    cout << ans << "\n";
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int ttt = 1;
    cin >> ttt;
    while(ttt--) {
        solve();
    }
}
/*
*/