#include <iostream>
#include <vector>

int main(){
    int t;
    std::cin >> t;
    const int CONDITION = 500;
    while(t-- > 0){
        int n; std::cin >> n;
        std::vector<int> arr(n);
        int count = 0;
        for(int& val : arr) std::cin >> val;
        for(int i = 0; i < n; i++){
            /*since we want ai * aj = j-i, a valid pair of j and i would mean j-i is a 
            multiple of ai. This means the next j should be a multiple of a[i] away
            from i*/
            if(arr[i] >= CONDITION){
                for(int j = i+arr[i]; j < n; j+=arr[i]){
                    if((long long)arr[i] * arr[j] == j-i) count ++;
                }
                for(int j = i - arr[i]; j >= 0; j-=arr[i]){
                    if((long long)arr[i] * arr[j] == i-j) count ++;
                }
            } else{
                for(int j = 1; i + j * arr[i] < n && j < CONDITION; j++){

                    if((long long)arr[i] * arr[i+j*arr[i]] == (long long)j*arr[i]) count ++;
                }
            }
        }
        std::cout << count << "\n";
    }
    return 0;
}