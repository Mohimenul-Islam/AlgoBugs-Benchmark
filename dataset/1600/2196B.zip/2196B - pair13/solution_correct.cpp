#include<bits/stdc++.h>
using namespace std;
#define int long long
void solve(){
    int n;
    cin >> n;
    vector<int> a(n+1);
    int ans = 0;
    int n1 = sqrt(n);
    for(int i=1;i<=n;i++){
        cin >> a[i];
    }
    for(int i=1;i<n1;i++){
        for(int j=1;j<=n;j++){
            int idx = j - a[j]*i;
            if(idx <= 0) continue;
            ans += (idx < j && a[idx] == i);
        }
    }
    for(int i =1;i<=n;i++){
        if(a[i] < n1) continue;
        for(int j=1;j*a[i] <= n;j++){
            int jdx = i + a[i]*j;
            ans += (jdx <= n && a[jdx] == j);
        }
    }
    cout << ans << endl;

}
signed main(){
    // ios::sync_with_stdio(false);
    // cin.tie(0);
    int t;
    cin >> t;
    while(t--){
        solve();
    }
}