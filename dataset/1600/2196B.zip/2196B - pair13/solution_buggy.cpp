#include<bits/stdc++.h>
using namespace std;
#define int long long
void solve(){
    int n;
    cin >> n;
    vector<int> a(n+1);
    map<pair<int,int>,int> mp;
    map<int,int> mp1;
    int ans = 0;
    for(int i=1;i<=n;i++){
        cin >> a[i];
        mp1[i+a[i]]++;
        mp[{i,a[i]}]++;
        if(a[i] > i) continue;
        if(a[i] == 1){
            ans += mp1[i];
            continue;
        }
        for(int j = i % a[i];j < i;j += a[i]){
            ans += mp[{j,(i-j) / a[i]}];
        }
    }
    cout << ans << endl;

}
signed main(){
    // ios::sync_with_stdio(false);
    // cin.tie(0);
    int t;
    cin >> t;
    while(t--){
        solve();
    }
}