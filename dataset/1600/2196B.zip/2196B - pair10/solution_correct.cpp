#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
using ordered_set = tree<int, null_type, less<>, rb_tree_tag, tree_order_statistics_node_update>;
using ll = long long;
using ld = long double;
using ull = unsigned long long;
constexpr const ll INF = 1e18, MOD = 1e9 + 7;
constexpr const ld EPS = 1e-7;
// #define int long long
#define all(x) x.begin(), x.end()
#ifdef LOCAL
#define _GLIBCXX_DEBUG
#endif
#define debug1d(a)                          \
  cerr << #a << " = [";                     \
  for (int i = 0; i < (int)(a).size(); i++) \
    cerr << (i ? ", " : "") << (a)[i];      \
  cerr << "]\n";
#define debug2d(a)                               \
  cerr << #a << " = [\n";                        \
  for (int i = 0; i < (int)(a).size(); i++)      \
  {                                              \
    cerr << "  [";                               \
    for (int j = 0; j < (int)(a[i]).size(); j++) \
      cerr << (j ? ", " : "") << a[i][j];        \
    cerr << "]\n";                               \
  }                                              \
  cerr << "]\n";
#define debug(x) cerr << "[" << #x << "] = " << (x) << "\n"
static int last_res;

void solve()
{
  int n;
  cin>>n;
  vector<ll> a(n);
  for (int i = 0; i < n; i++)
  {
    cin >> a[i];
  }
  const int B = sqrt(n);
  ll ans = 0;
  // a_i > B,则a_j < B,枚举a_j,
  // a_i <= B ,枚举a_i
  //注意第一种情况存在重复计算了部分a_i <= B,所以第一种情况计算的时候一定要让a_i > B 才计入贡献
  // 似乎是做完了n*sqrt(n)

  for (int x = 1; x <= B; x++)
  {
    for (int j = 0; j < n; j++)
    {
      // x * a_j = j - i => i = j - x * a_j
      ll i = j - x * a[j];
      if (i >= 0 && a[i] == x)
      {
        ans++;
      }
    }
  }
  for (int x = 1; x <= B; x++)
  {
    for (int i = 0; i < n; i++)
    {
      // a_i * x = j - i => j = a_i * x + i
      ll j = a[i] * x + i;
      if (j < n && a[j] == x && a[i] > B)
      {
        ans++;
      }
    }
  }
  cout << ans << "\n";
}

int main()
{
  cin.tie(0)->sync_with_stdio(0);
  int t = 1;
  cin >> t;
  while (t--)
  {
    solve();
  }
  return 0;
}
