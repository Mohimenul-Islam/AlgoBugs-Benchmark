//
//  main.cpp
//  hj
//
//  Created by Goga on 27.04.26.
//

#include <iostream>
using namespace std;
long long t,n;
int main() {
    cin>>t;
    while(t--)
    {
        cin>>n;
        long long a[n];
        for(int i=0;i<n;i++)
        {
            cin>>a[i];
        }
        long long ans=0;
        for(int i=0;i<n;i++)
        {
            if(a[i]>=500)
            {
                for(int j=1;i+(j*a[i])<n;j++)
                {
                    if(a[i+j*a[i]]==j)
                        ans++;
                }
                for(int j=1;i-(j*a[i])>=0;j++)
                {
                    if(a[i-j*a[i]]==j)
                        ans++;
                }
            }else {
                for(int j=1;i+(j*a[i])<n&&j<500;j++)
                {
                    if(a[i+j*a[i]]==j)
                        ans++;
                }
            }
        }
        cout<<ans<<endl;
    }
    return 0;
}
