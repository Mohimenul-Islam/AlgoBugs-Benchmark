#include <bits/stdc++.h>
using namespace std;
 
#define mp make_pair
#define ll long long
#define eb emplace_back
#define pb push_back
#define vec vector
#define nl '\n'
#define uset unordered_set
#define umap unordered_map
#define pb push_back
#define all(A) A.begin() , A.end()
 
inline void no() { cout << "No\n"; }
inline void yes() { cout << "Yes\n"; }
ll MOD = 1e9 + 7;
ll add(ll a,ll b){ a+=b; if(a>=MOD) a-=MOD; return a; }
ll sub(ll a,ll b){ a-=b; if(a<0) a+=MOD; return a; }
ll mul(ll a,ll b){ return (a%MOD)*(b%MOD)%MOD; }
ll modpow(ll a,ll e){ ll r=1,b=a%MOD; while(e>0){ if((e&1)==1) r=r*b%MOD; b=b*b%MOD; e>>=1; } return r; }
int modpow(int a,int e){ ll r=1,b=a%MOD; while(e>0){ if((e&1)==1) r=r*b%MOD; b=b*b%MOD; e>>=1; } return (int)r; }
ll inv(ll a){ return modpow(a,MOD-2); }
ll moddiv(ll a,ll b){ return mul(a,inv(b)); }
 
void november() {
    int n; cin >> n;
    vec<ll> a(n); for(int i = 0;i<n;i++) cin >> a[i];
    
    int B = (int) ceil(sqrt(n));
    
    ll cnt = 0;
    for(int i = 0;i<n;i++){
        if(a[i] >= B){
            for(int k = 0;k<B;k++){
                int j = a[i] * k + i;
                if(j < n && a[j] == k) cnt++;
                j = i - a[i] * k;
                if(j >= 0 && a[j] == k) cnt++; 
            }
        }
        else{
            for(int k = 0;k < B;k++){
                int j = i + a[i] * k;
                if(j < n && a[j] == k) cnt++; 
            }
        }
    }
    
    cout << cnt << nl;
    
}
 
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); 
    int t = 1;
    cin >> t;
    while(t--) november();
}