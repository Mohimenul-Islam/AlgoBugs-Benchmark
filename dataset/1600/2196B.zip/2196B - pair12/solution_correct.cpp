#include<bits/stdc++.h>
using namespace std;
 
#define int long long
const int N = 4e8 + 5;
const int mod7 = 1e9 + 7;

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
 
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif

    int T = 1;
    cin >> T;
    while(T--){
        int n;
        cin>>n;
        int a[n];
        for(int i = 0 ; i < n ; i++){
            cin >> a[i];
        }
        int ans = 0;
        for(int i = 0 ; i < n ; i++){
            if(a[i] >= 500){
                for(int j = 1 ; i + a[i]*j < n ; j++){
                    if(a[i + a[i]*j] == j)ans++;
                }
                for(int j = 1 ; i - a[i]*j >= 0 ; j++){
                    if(a[i - a[i]*j] == j)ans++;
                }
            }
            else{
                for(int j = 1 ; i + a[i]*j < n && j < 500 ; j++){
                    if(a[i + a[i]*j] == j)ans++;
                }
            }
        }
        cout<<ans<<'\n';
    }
    return 0;
}