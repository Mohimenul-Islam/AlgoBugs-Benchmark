#include<bits/stdc++.h>
using namespace std;
 
#define int long long
const int N = 4e8 + 5;
const int mod7 = 1e9 + 7;

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
 
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif

    int T = 1;
    cin >> T;
    while(T--){
        int n;
        cin>>n;
        int a[n];
        map<int,vector<int>> mp;
        for(int i = 0 ; i < n ; i++){
            cin >> a[i];
            mp[a[i]].push_back(i);
        }
        int ans = 0;
        for(int i = 1 ; i <= n ; i++){
            for(int j = 1 ; j*j <= i ; j++){
                if(i%j == 0){
                    for(int k = 0 ; k < mp[j].size() ; k++){
                        int idx = mp[j][k];
                        if(idx - i >= 0 && a[idx - i] == i/j){
                            // cout<<i<<" ";
                            ans++;
                        }
                        if(idx + i < n && a[idx + i] == i/j){
                            // cout<<i<<" ";
                            ans++;
                        }
                    }
                    if(j != i/j){
                        for(int k = 0 ; k < mp[i/j].size() ; k++){
                            int idx = mp[i/j][k];
                            if(idx - i >= 0 && a[idx - i] == j)ans++;
                            if(idx + i < n && a[idx + i] == j)ans++;
                        }
                    }
                }
            }
        }
        cout<<ans/2<<'\n';
    }
    return 0;
}