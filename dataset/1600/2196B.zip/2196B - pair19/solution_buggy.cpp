#include<bits/stdc++.h>
using namespace std;
long long int n,m,k,l,r,t,ans,a[100010],b[200010],j,j2,i,v;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr),cout.tie(nullptr);
    cin>>t;
    while(t--)
    {
        cin>>n;
        for(i=1;i<=n;i++)
        {
            cin>>a[i];
        }
        for(v=1;v*v<=n;v++)
        {
            for(k=1;k<=n;k++)
            {
                if(a[k]>=v)
                {
                    j=k-a[k]*v;
                    if(j>0 && j<=n && a[j]==v)
                    {
                        ans++;
                    }
                    j=k+a[k]*v;
                    if(j<=n && a[k]>v && a[j]==v)
                    {
                        ans++;
                    }
                }
            }
        }
        cout<<ans<<endl;
        ans=0;
    }
}