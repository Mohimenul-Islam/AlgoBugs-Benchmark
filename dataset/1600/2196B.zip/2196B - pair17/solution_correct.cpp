//
// Created by awake on 2026/4/19.
//
// clang-format off
#include <bits/stdc++.h>
using namespace std;
struct { auto operator()(auto &i) { cin >> i; } } IN; // NOLINT
struct { auto operator()(auto &i) { cout << i << ' '; } } OUT; // NOLINT
#define IOS ios::sync_with_stdio(false),cin.tie(nullptr)// NOLINT
using pii=pair<int,int>;//NOLINT
using ll = long long;//NOLINT
#define int long long
#define endl '\n'
// clang-format on
constexpr int INF = 0x3f3f3f3f;
constexpr int MOD = 998244353;
constexpr int N = 1e6 + 5;

void solve()
{
    int n;
    cin >> n;
    vector<int> a(n + 1);
    ranges::for_each(a | views::drop(1), IN);
    int cnt = 0;
    for (const int limit = sqrt(n); auto x : views::iota(1, limit + 1))
    {
        for (const auto j : views::iota(1, n + 1))
        {
            if (const int i1 = j - x * a[j]; i1 >= 1 && x == a[i1]) //枚举小的
                cnt++;

            if (const int i2 = j + x * a[j]; i2 <= n && x == a[i2] && a[j] > limit) //枚举大的
                cnt++;
        }
    }
    cout << cnt << endl;

}

signed main()
{
    IOS;
    int T;
    cin >> T;
    while (T--)
        solve();
    return 0;
}
