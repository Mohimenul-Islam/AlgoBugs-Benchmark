#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;
typedef int64_t ll;
ll mx = INT64_MAX;
ll mn = INT64_MIN;
const ll MOD = 1e9+7;
#define REP(i,j,k) for(ll (i)=(j);(i)<(k);++(i))
#define REV(i,j,k) for(ll (i)=(j);(i)>=(k);--(i))
 
typedef int64_t ll;
typedef tree<ll, null_type, greater<ll>, rb_tree_tag, tree_order_statistics_node_update> PBDS;
 
 
void solved(){
    ll n; cin>>n;
    ll raiz = sqrt(n) + 1;
    vector<ll> a(n + 1);
    REP(i,1,n + 1) cin>>a[i];
    ll ans = 0;
    REP(j,1,n + 1){
        REP(Ai,1,raiz + 1){
            //operacion
            ll i = j - (Ai * a[j]);
            if(i >= 1 && i <= n && a[i] == Ai) ans++;
        }
    }

    REP(i,1,n + 1){
        REP(Aj,1,raiz + 1){
            //operacion
            ll j = i + (Aj * a[i]);
            if(j >= 1 && j <= n && a[j] == Aj && a[j] > raiz) ans++;
        }
    }
    cout<<ans<<"\n";
}
 
int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cout<<fixed;
    ll n; cin>>n;
    while(n--)
    solved();
}