#include <bits/stdc++.h>
using namespace std;
using lll = __int128_t;
using db = long double;

#define int long long

#define vii vector<vector<int>>
#define vi vector<int>
#define lc p << 1
#define rc lc | 1
#define endl "\n"
#define pb push_back
#define pf push_front
#define pob pop_back
#define pof pop_front
#define eb emplace_back
#define ALL(x) (x).begin(), (x).end()
#define ALL1(x) (x).begin() + 1, (x).end()
#define all1(a) (a) + 1, (a) + n + 1
#define all(a) (a), (a) + n
#define bl(x) auto i : x
#define BL(x, y) auto i : x[y]
#define f(z, x, y) for (int z = x; z <= y; z++)
#define fn(z, x, y) for (int z = x; z >= y; z--)
const int N = 5e5 + 5, M = 4e5 + 5;
// 快速读入
inline int read()
{
    int f = 1, x = 0;
    char c = getchar();
    while (!isdigit(c))
    {
        if (c == '-')
            f = -1;
        c = getchar();
    }
    while (isdigit(c))
        x = x * 10 + c - '0', c = getchar();
    return f * x;
}
inline void write(int x)
{
    if (x < 0)
        putchar('-'), x = -x;
    if (x > 9)
        write(x / 10);
    putchar(x % 10 + '0');
}
inline void rtsp(int x)
{
    write(x);
    putchar(' ');
}
inline void rtln(int x)
{
    write(x);
    putchar('\n');
}
//inline int max(int x, int y) { return x > y ? x : y; }
inline int min(int x, int y) { return x > y ? x : y; }
inline void swap(int &x, int &y)
{
    int t = x;
    x = y;
    y = t;
}
inline int gcd(int x, int y) { return y ? gcd(y, x % y) : x; }
inline int lcm(int x, int y) { return x * y / gcd(x, y); }
inline int lowbit(int x) { return x & -x; }
// 树状数组
struct TREE{
    int sz;
    vector<int> tr;
    TREE(const int len)
    {
        tr.assign(len + 10, 0);
        sz = len;
    }

    void updata(int x, int k)
    {
        for (; x <= sz; x += lowbit(x))
            tr[x] += k;
    }
    int query(int x)
    {
        int res = 0;
        for (; x; x -= lowbit(x))
            res += tr[x];
        return res;
    }
};
// 并查集
struct BCJ{
    vector<int> sz, f;
    BCJ(int len)
    {
        f.assign(len + 5, 0);
        sz.assign(len + 5, 1);
        for (int i = 1; i <= len; i++)
            f[i] = i;
    }
    int find(int x)
    {
        return f[x] == x ? x : f[x] = find(f[x]);
    }
    void merge(int x, int y)
    {
        x = find(x), y = find(y);
        if (x == y)
            return;
        if (sz[x] < sz[y])
            swap(x, y);
        f[y] = x;
        sz[x] += sz[y];
    }
};
// 珂朵莉树
int res=0,mx,p,n;
struct ODTnode
{
    int l, r;
    mutable int v;
    ODTnode(int L, int R = 0, int val = 0) { l = L, r = R, v = val; }
    bool operator<(const ODTnode &b) const
    {
        return l < b.l;
    }
};
struct ODT{
#define IT set<ODTnode>::iterator
    set<ODTnode> st;
    IT split(int pos)
    {
        IT it = st.lower_bound(pos);
        if (it != st.end() && it->l == pos)
            return it;
        it--;
        auto [l, r, v] = *it;
        st.erase(it);
        st.insert(ODTnode(l, pos - 1,  v));
        return st.insert(ODTnode(pos, r, v)).first;
    }
    void assign(int l, int r, int v)
    {
        IT itr = split(r + 1), itl = split(l);
        while (itl != itr)
        {
            auto [l1, r1, val] = *itl;
            // 写操作；
            itl = st.erase(itl);
        }
        st.insert(ODTnode(l, r, v));
    }
};

typedef pair<int, int> pii;
typedef tuple<int, int, int> piii;
const int mod = 998244353;
const int inf = 0x7f7f7f7f;
const int INF = (int)2e18 + 10;
const int dx4[] = {-1, 0, 1, 0}, dy4[] = {0, 1, 0, -1};
const int dx8[] = {1, 0, 0, -1, 1, -1, 1, -1}, dy8[] = {0, 1, -1, 0, 1, -1, -1, 1};
/*
void solve(){
    int n=read(),m=read();
    vector<int> a(n+1,0),x(m+1,0);
    f(i,1,n) a[i]=read();
    for(int i=1;i<=m;i++) x[i]=read();

}*/
void solve(){
    int n=read();
    vector<int> a(n+1);
    for(int i=1;i<=n;i++) a[i]=read();
    int s=sqrt(n);
    int num=0;
    for(int i=1;i<=s;i++){
        for(int j=1;j<=n;j++){
            int id=j-a[j]*i;
            if(id<=0) continue;
            if(id<j && a[id]==i) num++;
        }
    }
    for(int j=1;j<=s;j++){
        for(int i=1;i<=n;i++){
            if(a[i]<=s) continue;
            int id=i+a[i]*j;
            if(id<=n && a[id]==j) num++;
        }
    }
    cout<<num<<"\n";
}

signed main()
{
    int T = read();
    while (T--)
    {
        solve();
    }
    return 0;
}