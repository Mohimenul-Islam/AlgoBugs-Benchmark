#include <bits/stdc++.h>
using namespace std;
#define int long long
const int MOD = 1e9 + 7;

void solve() {
    int n;
    cin >> n;

    vector<int> v(n);

    for(int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    int ans = 0;

    for(int i = 0; i < n; i++)
    {

        for(int t = 1; t <= v[i]; t++)
        {   
            int j = t * v[i] + i;

            if(j >= n)
                break;

            if(v[j] == t)
                ans++;
        }

        for(int t = 1; t <= v[i]; t++)
        {
            int j = i - v[i] * t;

            if(j < 0)
                break;

            if(v[i] == v[j])
                continue;
            
            if(v[j] == t)
                ans++;
        }
    }

    cout << ans << '\n';
}

int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--)
        solve();
    return 0;
}