#include <iostream>
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

typedef int64_t ll;
typedef tree<ll, null_type, less<ll>, rb_tree_tag, tree_order_statistics_node_update> PBDS;
ll mx = INT64_MAX;
ll mn = INT64_MIN;

//====================================================================
//                          MAIN
//====================================================================
void solved()
{
    ll n;
    cin >> n;
    vector<ll> v(n);
    for (auto &x : v)
    {
        cin >> x;
    }
    ll a, b, res;
    res = 0;
    for (int i = 1; i <= n - 1; i++)
    {
        a = 0;
        b = i;
        while (b < n)
        {
            if (v[a] * v[b] == i)
            {
                res++;
            }
            a++;
            b++;
        }
    }
    cout << res << "\n";
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cout << fixed;
    // freopen("bcount.in", "r", stdin);
    // freopen("bcount.out", "w", stdout);
    ll n;
    cin >> n;
    while (n--)
        solved();
}