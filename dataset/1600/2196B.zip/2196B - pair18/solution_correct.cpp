#include <iostream>
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

typedef int64_t ll;
typedef tree<ll, null_type, less<ll>, rb_tree_tag, tree_order_statistics_node_update> PBDS;
ll mx = INT64_MAX;
ll mn = INT64_MIN;

//====================================================================
//                          MAIN
//====================================================================
void solved()
{
    ll n, j;
    cin >> n;
    vector<ll> v(n);
    for (auto &x : v)
    {
        cin >> x;
    }
    ll res = 0;
    double b = sqrt(n);
    for (int i = 0; i < n; i++)
    {
        if (v[i] < b)
        {
            // peque
            for (int d = v[i]; (d / v[i]) < b; d += v[i])
            {
                j = i + d;
                if (j < n && v[j] == (d / v[i]))
                {
                    res++;
                    // cout << "1: " << i << " con " << j << endl;
                }
            }
        }
        else
        {
            // grande
            for (int d = v[i]; d < n; d += v[i])
            {
                j = i + d;
                if (j < n && v[j] == (d / v[i]))
                {
                    res++;
                    // cout << "2: " << i << " con " << j << endl;
                }

                j = i - d;
                if (j >= 0 && v[j] == (d / v[i]))
                {
                    res++;
                    // cout << "2: " << i << " con " << j << endl;
                }
            }
        }
    }

    cout << res << "\n";
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cout << fixed;
    // freopen("bcount.in", "r", stdin);
    // freopen("bcount.out", "w", stdout);
    ll n;
    cin >> n;
    while (n--)
        solved();
}