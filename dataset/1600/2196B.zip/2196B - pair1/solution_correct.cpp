#include <bits/stdc++.h>
#define endl '\n'
#define all(a) a.begin(), a.end()
using namespace std;
using ll = long long;
using ld = long double;

ll i, j, _;
const ll N = 2e5+111, SN = 500, M = 1e9+7, INF = 1e18;

ll a[N];
ll n, ans;

void solve() {
	cin >> n;

	for (i = 0; i < n; i++) {
		cin >> a[i];
	}

	ans = 0;

	for (i = 0; i < n; i++) {
		if (a[i] < SN) {
			for (j = 1; j < SN; j++) {
				ll idx = i+(j*a[i]);

				if (idx >= n) break;

				ans += a[idx] == j;
			}
		} else {
			for (j = i % a[i]; j < n; j += a[i]) {
                if (j < i) {
                    ans += a[i]*a[j] == i - j;
                } else {
					ans += a[i]*a[j] == j - i;
                }
			}
		}
	}

	cout << ans << endl;
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);

    //freopen("prom.in", "r", stdin);
    //freopen("prom.out", "w", stdout);

    ll T = 1;

    cin >> T;

    while(T--) solve();

    return 0;
}
