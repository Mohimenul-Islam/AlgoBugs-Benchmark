/*
    author : [Anh tập code]
    Road to 1k6 CF
*/
#include <bits/stdc++.h>
using namespace std;
 
#define int long long
#define el '\n'
#define all(x) begin(x), end(x)
#define sz(s) (int)(s.size())
#define file "test"
 
const int N = 2e5 + 10;
const int MOD = 1e9 + 7; // 111539786;
 
const int B = 500 + 5;

int a[N];
vector<int> id[N];

void sol()
{
    int n; cin >> n;
    for(int i=1; i<=n; i++) 
    {
        cin >> a[i];
        if(a[i] > n) continue;

        id[a[i]].push_back(i);
    }

    int cnt = 0;
    for(int i=1; i<=min(B, n); i++)
    {
        for(int mul = i; mul <= n; mul += i)
        {
            int j = mul / i;

            if(j > n) continue;
            for(auto it : id[j])
            {
                int k = mul + it;
                if(k <=n && a[k] == i) cnt++; 
            }
        }
    }

    for(int i=1; i<=n; i++)
    {
        if(a[i] <= B || a[i] > n) continue;

        for(int mul = a[i]; mul <= n; mul += a[i])
        {
            int f = mul / a[i];
            int j = mul + i;
            if(j <= n && a[j] == f) cnt++;
        }
    }

    cout << cnt << el;
    for(int i=1; i<=n; i++) id[i].clear();
}
 
signed main (){
    ios_base::sync_with_stdio(false);cin.tie(0), cout.tie(0);
    #ifndef ONLINE_JUDGE
        freopen(file ".inp", "r", stdin);
        freopen(file ".out", "w", stdout);
    #endif
        
    int t = 1; 
    cin >> t;
 
    while(t--) sol();
 
    return 0;
}
