#include <bits/stdc++.h>
using namespace std;

#define int long long

void solve() {
    int n;
    cin>>n;

    vector<int> v(n+1);
    for(int i=1;i<=n;i++) cin>>v[i];

    map<int, vector<int>> pos;
    for(int i=1;i<=n;i++) pos[v[i]].push_back(i);

    int ans = 0;

    for(auto &it1 : pos){
        int a = it1.first;
        vector<int> &pa = it1.second;

        for(auto &it2 : pos){
            int b = it2.first;
            vector<int> &pb = it2.second;

            if(a * b > 2*n) continue;

            for(int i : pa){
                for(int j : pb){
                    if(i < j && a * b == j - i){
                        ans++;
                    }
                }
            }
        }
    }
    cout<<ans<<endl;
}

int32_t main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int T;
    cin >> T;
    while (T--) {
        solve();
    }
    return 0;
}