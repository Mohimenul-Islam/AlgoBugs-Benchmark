#include <bits/stdc++.h>
#define ll long long
#define all(a) a.begin(),a.end()
using namespace std;
void sol()
{ 
    int n;
    cin>>n;
    vector<ll>a(n);
    vector<vector<int>>ind(n);
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    int B=ceil(sqrt(n-1));
    ll ans=0;
    for(int i=0;i<n;i++)
    {
        if(a[i]<B)
        {
            for(int k=i+a[i];(k-i)/a[i]<B && k<n;k+=a[i])
            {
                if(a[k]*a[i]==k-i)ans++;
            }
        }
        else
        {
            for(int k=i+a[i];k<n;k+=a[i])
            {
                if(a[k]*a[i]==k-i)ans++;
            }
            for(int k=i-a[i];k>=0;k-=a[i])
            {
                if(a[k]*a[i]==i-k)ans++;
            }
        }
    }
    cout<<ans<<'\n';

    
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int t;
    cin >> t;
    while(t--)
    sol();
    
    return 0;
}