/*----Rahul Nautiyal----*/

#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ld = long double;

#define pb push_back
#define ff first
#define ss second
#define all(x) (x).begin(), (x).end()

const int MOD = 1e9 + 7;
const int MOD1 = 998244353;
const ll INF = 1e18;

#define fastio() ios::sync_with_stdio(false); cin.tie(NULL);

#ifndef ONLINE_JUDGE
#define debug(x) cerr << #x << " = " << x << endl;
#else
#define debug(x)
#endif

ll gcd(ll a, ll b) {
    return b ? gcd(b, a % b) : a;
}

ll power(ll a, ll b, ll mod = MOD) {
    ll res = 1;
    while (b) {
        if (b & 1) res = (res * a) % mod;
        a = (a * a) % mod;
        b >>= 1;
    }
    return res;
}

ll modinv(ll a, ll mod = MOD) {
    return power(a, mod - 2, mod);
}

void solve(){
    int n;
    cin >> n;
    
    vector<ll> a(n + 1);
    for(int i = 1; i <= n; i++) cin >> a[i];

    ll ans = 0;
    int S = sqrt(2 * n);

    for(int x = 1; x <= S; x++){
        for(int i = 1; i <= n; i++){
            ll left_idx = i - (ll)x * a[i];
            if(left_idx >= 1 && a[left_idx] == x){
                ans++;
            }
            
            ll right_idx = i + (ll)x * a[i];
            if(right_idx <= n && a[right_idx] == x && a[i] > S){
                ans++;
            }
        }
    }

    cout << ans << '\n';
}

int main(){
    fastio();

    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }

    return 0;
}