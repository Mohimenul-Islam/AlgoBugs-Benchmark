/*----Rahul Nautiyal----*/

#include <bits/stdc++.h>
using namespace std;

using ll = long long;
using ld = long double;

// Shortcuts
#define pb push_back
#define ff first
#define ss second
#define all(x) (x).begin(), (x).end()

// Constants
const int MOD = 1e9 + 7;
const int MOD1 = 998244353;
const ll INF = 1e18;

// Fast IO
#define fastio() ios::sync_with_stdio(false); cin.tie(NULL);

// Debug (use only locally)
#ifndef ONLINE_JUDGE
#define debug(x) cerr << #x << " = " << x << endl;
#else
#define debug(x)
#endif

// ------------------ Utility Functions ------------------

// GCD
ll gcd(ll a, ll b) {
    return b ? gcd(b, a % b) : a;
}

// Fast exponentiation
ll power(ll a, ll b, ll mod = MOD) {
    ll res = 1;
    while (b) {
        if (b & 1) res = (res * a) % mod;
        a = (a * a) % mod;
        b >>= 1;
    }
    return res;
}

// Modular inverse (only if mod is prime)
ll modinv(ll a, ll mod = MOD) {
    return power(a, mod - 2, mod);
}

// -------------------------------------------------------

void solve(){
    int n;
    cin >> n;
    vector<int> a(n);
    for(int i=0;i<n;i++) cin >> a[i];

    int ans = 0;
    int SQ = 500;

    for(int i=0;i<n;i++){
        if(a[i] >= SQ){
            for(int j=1; i + a[i]*j < n; j++){
                if(a[i + a[i]*j] == j) ans++;
            }
        } else {
            for(int j=1; j < SQ && i + a[i]*j < n; j++){
                if(a[i + a[i]*j] == j) ans++;
            }
        }
    }

    cout << ans << '\n';
}

// ------------------ MAIN ------------------

int main(){
    fastio();

    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }

    return 0;
}