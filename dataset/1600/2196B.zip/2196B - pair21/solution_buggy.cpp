// https://codeforces.com/problemset/problem/2196/B
#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef pair<int, int> PII;

void solve() {
	LL n;
	cin >> n;
	LL B = sqrtl(n) + 1;

	vector<LL> a(n + 1, 0);
	for (int i = 1; i <= n; i ++ ) cin >> a[i];

	LL ans = 0;
	for (int i = 1; i <= n; i ++ ) {
		if (a[i] < B) {
			for (int j = 1; j < B && i + j * a[i] <= n; j ++ ) {
				int u = i + j * a[i];
				if (a[u] < B && a[i] * a[u] == u - i) ans ++ ;
			}
		} else {
			for (int j = 1; i - j * a[i] > 0; j ++ ) {
				int u = i - j * a[i];
				if (a[i] * a[u] == i - u) ans ++ ;
			}

			for (int j = 1; i + j * a[i] <= n; j ++ ) {
				int u = i + j * a[i];
				if (a[i] * a[u] == i - u) ans ++ ;
			}
		}
	}
	cout << ans << endl;
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int tt = 1;
    cin >> tt;
    while (tt--) {
        solve();
    }
    
    return 0;
}