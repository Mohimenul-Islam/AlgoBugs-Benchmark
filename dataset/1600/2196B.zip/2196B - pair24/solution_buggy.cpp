#include<iostream>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<algorithm>
#include<cmath>
using namespace std;
#define int long long

void solve() {
  int n;
  cin >> n;
  vector<int> a(n+1);

  for (int i = 1;i<=n;i++) {
    cin >> a[i];
  }
  int ans = 0;
  for (int i = 1;i<n;i++) {
    int cnt = 1;
    for (int j = a[i];j<=n;j+=a[i],cnt++) {
      if (a[j+i] == cnt) {
        ans++;
      }
    }
  }
  cout << ans << endl;
}


signed main() {
  int t = 1;
  cin >> t;
  while (t--) {
    solve();
  }
  return 0;
}