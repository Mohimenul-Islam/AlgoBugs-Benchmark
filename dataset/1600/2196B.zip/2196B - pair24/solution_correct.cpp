#include<iostream>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<algorithm>
#include<cmath>
using namespace std;
#define int long long

void solve() {
  int n;
  cin >> n;
  vector<int> a(n+1);

  for (int i = 1;i<=n;i++) {
    cin >> a[i];
  }
  int ans = 0;
  for (int i = 1;i<=n;i++) {
    if (a[i] >n)continue;
    for (int j = 1;j<a[i]&&j*j<=n;j++) {
      int x = i-a[i]*j;
      ans+=(x>=1&&a[x] == j);
      x = i+a[i]*j;
      ans+=(x<=n&&a[x] == j);
    }
    int x = i-a[i]*a[i];
    ans+=(x>=1&&a[x] == a[i]);
  }
  cout << ans << endl;
}


signed main() {
  int t = 1;
  cin >> t;
  while (t--) {
    solve();
  }
  return 0;
}