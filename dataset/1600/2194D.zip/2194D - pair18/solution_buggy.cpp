#include <bits/stdc++.h>
#define ll long long
#define int long long
#define IO ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
using namespace std;

void solve() {
    int n, m;
    cin >> n >> m;
    vector<vector<int> > graph(n, vector<int>(m)), pre(n, vector<int>(m));
    int cntr(0);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> graph[i][j];
            if (graph[i][j] == 1) {
                cntr++;
            }
        }
        for (int j = m - 1; j >= 0; j--) {
            if (j == m - 1)pre[i][j] = graph[i][j];
            else pre[i][j] = pre[i][j + 1] + graph[i][j];
        }
    }
    cout << (cntr / 2) * ((cntr + 1) / 2) << endl;

    int targ = cntr / 2, cur(0);
    string s = "";
    bool check = false;
    for (int i = 0; i < n; i++) {
        if (cur + pre[i][0] >= targ) {
            for (int j = 0; j < m; j++) {
                if (cur + pre[i][j] == targ) {
                    s += 'D';
                    while (j < m) {
                        s += 'R';
                        j++;
                    }
                    //cout << i << endl;
                    while (i < n - 1) {
                        s += 'D';
                        i++;
                    }
                    goto endd;
                } else s += 'R';
            }
        } else {
            cur += pre[i][0];
            s += 'D';
        }
    }
endd:
    cout << s << endl;
}

signed main() {
    IO
    int t;
    cin >> t;
    while (t--) solve();
}
