#include<iostream>
#include<vector>
#include<numeric>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t; cin>>t;
    while(t--){
        int n, m;
        cin>>n>>m;
        vector<vector<int>> a(n, vector<int> (m));
        for(auto &i: a) for(auto &j: i) cin>>j;

        vector<int> sum(m);
        for(int i=0; i<m; i++){
            for(int j=0; j<n; j++){
                sum[i] += a[j][i];
            }
        }
        int tot = accumulate(sum.begin(), sum.end(), 0);

        int s = 0, idx = 0;
        while(idx<m && s+sum[idx]<=tot/2) {
            s+=sum[idx];
            idx++;
        }
        string res = "";
        for(int i=0; i<idx; i++) res+='R';

        int j = n;
        while(j>=1 && s+a[j-1][idx]<=tot/2){
            s += a[j-1][idx];
            j--;
        }
        for(int i=0; i<j; i++) res+='D';

        if(m-idx) res+='R';
        for(int i=j; i<n; i++) res+='D';
        for(int i=idx+1; i<m; i++) res+='R';
        cout<<tot/2*(tot-tot/2)<<"\n";
        cout<<res<<"\n";
    }
}