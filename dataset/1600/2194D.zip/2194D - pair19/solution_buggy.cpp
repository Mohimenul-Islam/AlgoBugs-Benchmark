#include<iostream>
#include<vector>
#include<algorithm>
#include<unordered_set>
#include<set>
#include<queue>
#include<string>
#include<cmath>
#include<map>
using namespace std;
typedef long long ll;

ll n,m;
int s[300005];

void solve(){
	cin>>n>>m;
	
	vector<vector<int>> a(n+1,vector<int>(m+1,0));
	ll sum = 0;
	
	for(int i = 1; i<=n; i++)s[i]=0;
	for(int i = 1; i<=n; i++){
		for(int j = 1; j<=m; j++){
			cin>>a[i][j];
			s[i]+=a[i][j];
			sum+=a[i][j];
		}
	}

	ll t = sum/2;
	ll temp = 0;
	ll id = 1;
	for(int i = 1; i<=n; i++){
		if(temp+s[i]>=t){
			id = i;
			break;
		}
		else temp+=s[i];
	}
	int jd = 1;
	for(int j =m ; j>=1; j--){
		if(temp+a[id][j]>=t){
			jd = j;
			break;
		}
		else temp +=a[id][j];
	}
	
	

	if(sum%2==0)
	cout<<t*t<<"\n";
	else cout<<t*(t+1)<<"\n";
	bool ok = true;
	for(int i = 1; i<=m+n; i++){
		
		if(i<=id-1)
			cout<<'D';
		
		else if(i-id<jd-1) cout<<'R';
		
		else if(ok&&id<n){
			cout<<'D';
			ok = false;
		}
		else if(jd<=m){
			cout<<'R';
			jd++;
		}
	    else cout<<'D';
	}
	cout<<"\n";
		return;
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	cout.tie(nullptr);

	ll t;
	cin>>t;
	while(t--){
		
		solve();
		
		
	}
	return 0;
}