// ██╗░░██╗██╗░░██╗██╗███████╗███████╗░█████╗░██████╗░██████╗░
// ██║░░██║██║░░██║██║╚════██║╚════██║██╔══██╗██╔══██╗██╔══██╗
// ╚██╗██╔╝╚██╗██╔╝██║░░███╔═╝░░███╔═╝███████║██████╔╝██║░░██║
// ░╚███╔╝░░╚███╔╝░██║██╔══╝░░██╔══╝░░██╔══██║██╔══██╗██║░░██║
// ░░╚█╔╝░░░░╚█╔╝░░██║███████╗███████╗██║░░██║██║░░██║██████╔╝
// ░░░╚╝░░░░░░╚╝░░░╚═╝╚══════╝╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝╚═════╝░
#include <bits/stdc++.h>
using namespace std;
#define F first
#define S second
#define tos to_string
#define __lcm(x, y) (x * y)/__gcd(x, y)
// #pragma GCC optimize ("O3,unroll-loops")
// #pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
#define int long long
#define abs llabs
#define all(v) v.begin(), v.end()
const int N = 2E5 + 5, M = 1E5 + 5, LOG = 30;
const int inf = 1E18, MOD = 1E9 + 7, MOD1 = 998244353;

void solve() {
    int n, m;
    cin >> n >> m;
    int a[n + 1][m + 1]{}, cnt = 0;
    int row[n + 1]{};
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            cin >> a[i][j];
            cnt += a[i][j];
            row[i] += a[i][j];
        }
    }
    int x = cnt / 2, y = (cnt + 1) / 2, ans1 = x * y;
    int i = 1, j = 1;
    string ans = "";
    while (i <= n && j <= m) {
        if (row[i] <= x) {
            ans += 'D';
            x -= row[i];
            i++;
        }
        else {
            int cnt = row[i] - x;
            while (cnt) {
                cnt -= a[i][j];
                j++;
                ans += 'R';
            }
            ans += 'D';
            i++;
            while (j <= m) {
                ans += 'R';
                j++;
            }
            while (i <= n) {
                ans += 'D';
                i++;
            }
            break;
        }
    }
    while (j <= m) {
        ans += 'R';
        j++;
    }
    while (i <= n) {
        ans += 'D';
        i++;
    }
    cout << ans1 << "\n" << ans << "\n";
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int ttt = 1;
    cin >> ttt;
    while(ttt--) {
        solve();
    }
}
/*
*/