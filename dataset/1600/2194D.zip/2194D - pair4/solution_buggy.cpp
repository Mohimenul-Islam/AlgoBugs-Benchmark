#include <bits/stdc++.h>
using namespace std;
#define ll long long int
#define pii pair<ll, ll>
#define fast_io                  \
    ios::sync_with_stdio(false); \
    cin.tie(NULL);
#define nl "\n"
#define pb push_back
#define py cout << "YES\n";
#define pn cout << "NO\n";
#define sz(x) ((ll)(x).size())
#define all(x) x.begin(), x.end()
#define vlowerB(v, x) lower_bound(v.begin(), v.end(), x)
#define vupperB(v, x) upper_bound(v.begin(), v.end(), x)
#define F first
#define S second
#define rep(i, a, b) for (ll i = a; i <= b; i++)
#define rep2(i, b, a) for (ll i = b; i >= a; i--)
#define vi vector<ll>
#define countBit(x) __builtin_popcountll(x)
#define zrbits(x) __builtin_ctzll(x)
const ll MOD = 1e9 + 7;
const ll N = 2e5 + 9;
ll dx[8] = {1, 0, -1, 0, -1, 1, -1, 1};
ll dy[8] = {0, 1, 0, -1, -1, 1, 1, -1};
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
template <typename T>
using pbds = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>;
bool comp(pair<ll, ll> &p1, pair<ll, ll> &p2)
{
    if (p1.first == p2.first)
        return p1.second < p2.second;
    return p1.first < p2.first;
}
template <typename T>
void print(const T &container)
{
    for (const auto &x : container)
    {
        cout << x << " ";
    }
    cout << '\n';
}
ll power(ll a, ll b)
{
    ll result = 1;
    while (b > 0)
    {
        if (b & 1)
        {
            result = (result * 1ll * a) % MOD;
        }
        a = (a * 1ll * a) % MOD;
        b >>= 1;
    }
    return result;
}
void solve()
{
    ll n, m;
    cin >> n >> m;
    vector<vector<int>> v(n + 2, vector<int>(m + 2));
    vector<vector<ll>> pf(n + 3, vector<ll>(m + 3));
    rep(i, 1, n)
    {
        rep(j, 1, m) cin >> v[i][j];
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = m; j >= 1; j--)
        {
            pf[i][j] = pf[i][j+1] + v[i][j];
        }
    }
    // for (int i = 1; i <= n; i++)
    // {
    //     for (int j = 1; j <=m; j++)
    //     {
    //         cout<<pf[i][j]<<" ";
    //     }
    //     cout<<nl;
    // }
    ll total = 0;
    for (int i = 1; i <= n; i++)
    {
        total += pf[i][1];
    }
    ll tt=total;
    total /= 2;
    ll idx = -1;
    for (int i = n; i >=1; i--)
    {
        if (pf[i][1] <= total)
        {
            total -= pf[i][1];
            idx = n-i+1;
            // cout<<total<<" "<<pf[i][1]<<nl;
        }
        else break;
    }
    if(idx==-1){
        ll k=pf[n][1];
        cout<<1ll*k*(tt-k)<<nl;
        for(int i=1;i<n;i++){
            cout<<"D";
        }
        for(int i=1;i<=m;i++){
            cout<<"R";
        }
        cout<<"D"<<nl;
        return;
    }
    idx++;
    cout << 1ll * (tt / 2) * ((tt + 1) / 2) << nl;
    if(total==0){
        for(int i=idx;i<=n;i++){
            cout<<"D";
        }
        for(int i=1;i<=m;i++) {
            cout<<"R";
        }
        for(int i=1;i<idx;i++){
            cout<<"D";
        }
        cout<<nl;
        return;
    }

    for (int i = idx+1; i <= n; i++)
    {
        cout << "D";
    }
    for(int j=1;j<=m;j++){
        total-=v[idx][j];
        cout<<"R";
        if(total==0) {
            j++;
            cout<<"D";
            while(j<=m){
                cout<<"R";
                j++;
            }
            break;
        }
    }
    for(int i=idx-1;i>=1;i--){
        cout<<"D";
    }
    cout<<nl;
}
int32_t main()
{
    fast_io
        ll t = 1;
    cin >> t;
    // ll tt=t;
    while (t--)
    {
        // cout<<"Case "<<tt-t<<": ";
        solve();
    }
    return 0;
}