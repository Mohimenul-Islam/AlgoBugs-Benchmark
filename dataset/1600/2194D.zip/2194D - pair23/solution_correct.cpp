#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

void solve() {
	int n, m;
	cin >> n >> m;
	
	int sum = 0;
	vector<vector<int>> a(n + 1, vector<int>(m + 1));
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++) {
			cin >> a[i][j];
			sum += a[i][j];
		}
	}
	
	if (sum == 0) {
		cout << 0 << "\n";
		for (int i = 0; i < m; i++) {
			cout << "R";
		}
		for (int i = 0; i < n; i++) {
			cout << "D";
		}
		cout << "\n";
		return;
	}
	
	cout << 1ll * (sum / 2) * (sum - sum / 2) << "\n";
	vector<vector<int>> col(m + 1, vector<int>(n + 1));
	for (int i = 1; i <= m; i++) {
		for (int j = 1; j <= n; j++) {
			col[i][j] = col[i][j - 1] + (a[j][i] == 1);
		}
	}
	
	int cnt = 0, down = 0, right = 0;
	sum /= 2;
	for (int j = 1; j <= m + 1; j++) {
		if (cnt == sum) {
			for (int j = 0; j < n - down; j++) {
				cout << "D";
			}
			for (int j = 0; j < m - right; j++) {
				cout << "R";
			}
			break;
		}
		for (int i = 1; i <= n; i++) {
			int d = col[j][n] - col[j][i - 1];
			if (cnt + d <= sum) {
				cnt += d;
				cout << "R";
				right++;
				break;
			} else {
				down++;
				cout << "D";
			}
		}
	}
	cout << "\n";
}

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);

	int T = 1;
	cin >> T;

	while (T--) {
		solve();
	}

	return 0;
}
