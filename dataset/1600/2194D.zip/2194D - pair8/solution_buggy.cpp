#include <bits/stdc++.h>


using namespace std;
#define sz(x) int((x).size())
#define all(x) begin(x), end(x)
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vll;
#define debug(x) cout << #x << " is " << x << endl;
const long long INF = 1e18;


void solve() {
    int n, m; cin >> n >> m;

    vector<vector<int>> a(n, vector<int>(m, 0));
    int ct = 0;
    vector<int> b(n + 1, 0);
    for(int i = 0; i < n; i++) {
        int cur = 0;
        for(int j = 0; j < m; j++) {
            cin >> a[i][j];
            if (a[i][j] == 1) cur++;
        }
        b[i] = cur;
        ct += cur;
    }

    string ans = "";

    int cur = 0;
    int j = 0;
    int i = 0;
    for(; i < n; i++) {
        if (cur + b[i] > ct/2) {
            int diff = cur + b[i] - ct / 2;
            while (diff > 0) {
                diff -= a[i][j];
                j++;
                ans += 'R';
            }
            if (i < n) {
                i++;
                ans += 'D';
            }
            while(j < m) {
                j++;
                ans += 'R';
            }
            while (i < n) {
                i++;
                ans += 'D';
            }
            cout << (ct / 2) * (ct - ct/2) << endl << ans << endl;
            return;
        }
        cur += b[i];
        ans += 'D';
    }
    while(j < m) {
        j++;
        ans += 'R';
    }
    while(i < n) {
        i++;
        ans += 'D';
    }
    cout << (ct / 2) * (ct - ct/2) << endl << ans << endl;


}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
    
}
    
    