#include<iostream>
#include<vector>
#include<numeric>
#include<algorithm>


#define DEBUGING false


//https://codeforces.com/contest/2194/problem/D
int main(){
    int t;
    std::cin>>t;

    for(int ite=0;ite<t;ite++){

        #if DEBUGING
        std::cout<<"____________________________________________________________________________________________________________";
        std::cout<<"start test: "<<ite<<'\n';
        #endif

        int n,m;
        std::cin>>n>>m;

        std::vector<std::vector<int>> table(n,std::vector<int>(m));

        for(int j=0;j<n;j++){
            for(int i=0;i<m;i++){
                std::cin>>table[j][i];
            }
        }

        for(int j=0;j<n;j++){
            std::partial_sum(table[j].begin(),table[j].end(),table[j].begin());
        }

        int total_ones=0;
        for(int j=0;j<n;j++) total_ones+=table[j][m-1];

        const long long target=total_ones/2;

        std::vector<char> ans;
        int current_count=0;

        #if DEBUGING
        std::cout<<"target: "<<target<<'\n';
        #endif

        for(int j=0;j<n;j++){

            #if DEBUGING
            std::cout<<"current_count: "<<current_count<<'\n';
            #endif

            if(current_count+table[j][m-1]<target){
                #if DEBUGING
                std::cout<<"lesser target\n";
                #endif

                ans.push_back('D');
                current_count+=table[j][m-1];
            }
            else if (current_count+table[j][m-1]>target){
                #if DEBUGING
                std::cout<<"greater target\n";
                #endif

                const int search_target=table[j][m-1]-(target-current_count);
                const int diff_ind=std::lower_bound(table[j].begin(),table[j].end(),search_target)-table[j].begin();

                for(int i=0;i<diff_ind+1;i++) ans.push_back('R');

                ans.push_back('D');

                for(int i=diff_ind+1;i<m;i++) ans.push_back('R');

                for(int x=j+1;x<n;x++) ans.push_back('D');

                break;
            }
            else{
                #if DEBUGING
                std::cout<<"equal target\n";
                #endif

                ans.push_back('D');
                for(int i=0;i<m;i++) ans.push_back('R');
                for(int x=j+1;x<n;x++) ans.push_back('D');
                break;
            }
        }

        std::cout<<(total_ones/2)*(total_ones/2+total_ones%2)<<'\n';

        for(char c: ans) std::cout<<c;
        std::cout<<'\n';
    }
    return 0;
}