#include<bits/stdc++.h>
using namespace std;
#define int long long
void solve(){
    int n,m;cin>>n>>m;
    vector<vector<int>> line(n+1);
    int sum=0;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            int temp;cin>>temp;
            if(temp==1){
                sum++;
            line[i].push_back(j);
            } 
        }
    }
    int x,y;
    if(sum%2==0){
        x=y=sum/2;

    }
    else{
        x=sum/2;
        y=sum/2+1;

    }
    int temp_sum=0;
    string ans;
    int j=1;
    for(int i=1;i<=n;i++){
        // cout<<temp_sum+line[i].size()<<endl;
        if(temp_sum==x){
            while(j!=m+1) {
                j++;
                ans+='R';
            }
              ans+='D';
        }
        else if(temp_sum+line[i].size()<=x){
            
            ans+='D';
            temp_sum+=line[i].size();
        }
        else if(temp_sum+line[i].size()>x){
            int cnt=x-temp_sum;
            int list=line[i].size()-cnt-1;
            int num=line[i][list];
            while(j<=num){
                j++;
                ans+='R';
            }
            ans+='D';
            temp_sum=x;
        }
 
        

    }
    
    while(j!=m+1) {
        j++;
        ans+='R';
    }
    cout<<x*y<<endl;
    cout<<ans<<endl;
}
signed main(){
    int t;cin>>t;
    while(t--) solve();
  
}