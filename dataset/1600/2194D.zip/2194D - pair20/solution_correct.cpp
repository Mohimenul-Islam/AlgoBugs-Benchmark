﻿#define _CRT_SECURE_NO_WARNINGS
#include <numeric>
#include <functional>
#include <iostream>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <string>
#include <sstream>
#include <fstream>
#include <cstring>
#include <array>
#include <bitset>
#include <cmath>
#include <memory>
#include <optional>
#include <ranges>
#include <bit>
#include <iomanip>

using namespace std;

long long gcd(long long a, long long b) {
  while (b) {
    a %= b;
    swap(a, b);
  }
  return a;
}

long long lcm(long long  a, long long  b) {
  return a * b / gcd(a, b);
}

const double pi = 3.14159265358979323846;

const int MOD = 1000'000'007;
//const int MOD = 998244353;
//const int MOD = 1000'000'009;

long long bin_power_mod(long long a, long long n) {
  long long res = 1;
  while (n) {
    if (n & 1) {
      res *= a;
      res %= MOD;
    }
    a *= a;
    a %= MOD;
    n >>= 1;
  }
  return res;
}

long long bin_power(long long a, long long n) {
  long long res = 1;
  while (n) {
    if (n & 1) {
      res *= a;
    }
    a *= a;
    n >>= 1;
  }
  return res;
}

int count_bits(int a) {
  int res = 0;
  while (a) {
    res++;
    a >>= 1;
  }
  return res;
}

long long inverse(long long a) {
  return bin_power_mod(a, MOD - 2);
}

string ans[] = { "NO", "YES" };

bool is_power_of_two(int a) {
  return (a & (a - 1)) == 0;
}

long long productDigits(long long n) {
  long long res = 1;
  while (n) {
    res *= n % 10;
    n /= 10;
  }
  return res;
}

void solve() {
  int n, m; cin >> n >> m;
  long long cnt = 0;
  vector<vector<int>> v(n, vector<int>(m));
  vector<vector<int>> c(n + 1, vector<int>(m));
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < m; ++j) {
      cin >> v[i][j];
      cnt += v[i][j];
      c[i + 1][j] = v[i][j] + c[i][j];
    }
  }
  long long need = cnt / 2;
  string res;
  int i = 0, j = 0;
  while (i < n && j < m) {
    int can = c[n][j] - c[i][j];
    if (need >= can) {
      need -= can;
      j++;
      res += "R";
    }
    else {
      i++;
      res += "D";
    }
  }
  res += string(m - j, 'R');
  res += string(n - i, 'D');
  cout << cnt / 2 * (cnt - cnt / 2) << '\n' << res << '\n';
}

int main() {
  ios::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  int t; cin >> t;
  while (t--) {
    solve();
  }
  return 0;
}