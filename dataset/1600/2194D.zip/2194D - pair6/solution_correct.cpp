#include<iostream>
#include<vector>

using namespace std;

int main(){
    int t; cin >> t;
    while(t--){
        int n; cin >> n;
        int m; cin >> m;
        vector<vector<int>> grid (n, vector<int> (m));
        long long int count = 0;
        for(int i=0; i<n; i++){
            for(int j=0; j<m; j++){
                int temp; cin >> temp;
                if(temp){
                    count++;
                }
                grid[i][j] = temp;
            }
        }
        long long int target = count/2;
        long long int a = 0;
        int endr = 0;
        int endc = 0;
        bool finished = false;
        for(int r=0; r<n; r++){
            for(int c=m-1; c>=0; c--){
                if(grid[r][c]){
                    a++;
                }
                if(a == target){
                    finished = true;
                    endr = r;
                    endc = c;
                    break;
                }
            }
            if(finished){
                break;
            }
        }
        if(count%2 == 0){
            cout << target*target << "\n";
        }
        else{
            cout << target*(target+1) << "\n";
        }
        for(int i=0; i<endr; i++){
            cout << "D";
        }
        for(int i=0; i<endc; i++){
            cout << "R";
        }
        cout << "D";
        for(int i=endc; i<m; i++){
            cout << "R";
        }
        for(int i=endr+1; i<n; i++){
            cout << "D";
        }
        cout << "\n";
    }
}