#include <iostream>
#include <vector>

#define ll long long

using namespace std;

int main(int argc, char* argv[]){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    ll t;
    cin >> t;

    while(t--){
        ll n, m, oneCnt = 0;
        cin >> n >> m;

        vector<vector<ll>> table(n+1, vector<ll>(m, 0));
        for(ll i = 0; i < n; i++){
            for(ll j = 0; j < m; j++){
                cin >> table[i][j];
                oneCnt += table[i][j];
            }
        }

        for(ll j = 0; j < m; j++){
            for(ll i = n-1; i >= 0; i--){
                table[i][j] += table[i+1][j];
            }
        }

        cout << (oneCnt/2)*(oneCnt/2+oneCnt%2) << '\n';
        
        ll counter = oneCnt/2, i = 0;  
        for(ll j = 0; j < m; j++){
            for(; i < n; i++){
                if(counter >= table[i][j]){
                    counter -= table[i][j];
                    break;
                }

                cout << 'D';
            }

            cout << 'R';
        }

        for(; i < n; i++){
            cout << 'D';
        }

        cout << '\n';
    }

    return 0;
}