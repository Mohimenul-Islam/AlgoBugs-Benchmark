#include <iostream>
#include <vector>

using namespace std;

int main(int argc, char* argv[]){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int t;
    cin >> t;

    while(t--){
        int n, m, oneCnt = 0;
        cin >> n >> m;

        vector<vector<int>> table(n+1, vector<int>(m, 0));
        for(int i = 0; i < n; i++){
            for(int j = 0; j < m; j++){
                cin >> table[i][j];
                oneCnt += table[i][j];
            }
        }

        for(int j = 0; j < m; j++){
            for(int i = n-1; i >= 0; i--){
                table[i][j] += table[i+1][j];
            }
        }

        cout << (oneCnt/2)*(oneCnt/2+oneCnt%2) << '\n';
        
        int counter = oneCnt/2, i = 0;  
        for(int j = 0; j < m; j++){
            for(; i < n; i++){
                if(counter >= table[i][j]){
                    counter -= table[i][j];
                    break;
                }

                cout << 'D';
            }

            cout << 'R';
        }

        for(; i < n; i++){
            cout << 'D';
        }

        cout << '\n';
    }

    return 0;
}