#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;

    while (t--) {
        int n, m;
        cin >> n >> m;

        vector<vector<int>> arr(n, vector<int>(m));
        vector<int> row(n, 0);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                cin >> arr[i][j];
                if (arr[i][j] == 1) row[i]++;
            }
        }

        int k = accumulate(row.begin(), row.end(), 0);

        if (k == 0) {
            cout << 0 << "\n";
            if (m == 1) {
                cout << "DR";
                for (int i = 0; i < n - 1; i++) cout << "D";
            } else {
                for (int i = 0; i < m - 1; i++) cout << "R";
                cout << "DR";
                for (int i = 0; i < n - 1; i++) cout << "D";
            }
            cout << "\n";
            continue;
        }

        int val = k / 2;
        string s = "";
        int i = 0;

        while (i < n) {
            if (val >= row[i]) {
                s += 'D';
                val -= row[i];
            } else {
                int cnt = 0;
                for (int j = 0; j < m; j++) {
                    cnt += (arr[i][j] & 1);
                    s += 'R';

                    if (val - (row[i] - cnt) == 0) {
                        val = 0;
                        s += 'D';
                        for (int x = 0; x < m - j - 1; x++) s += 'R';
                        break;
                    }
                }
                break;
            }
            i++;
        }

        cout << (k / 2) * (k - k / 2) << "\n";
        cout << s;

        for (int x = 0; x < n - i - 1; x++) cout << 'D';
        cout << "\n";
    }

    return 0;
}