#include <bits/stdc++.h>
using namespace std;

// helper to print __int128
void print_int128(__int128 x) {
    if (x == 0) {
        cout << 0;
        return;
    }
    if (x < 0) {
        cout << '-';
        x = -x;
    }
    string s;
    while (x > 0) {
        s += char('0' + x % 10);
        x /= 10;
    }
    reverse(s.begin(), s.end());
    cout << s;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;

    while (t--) {
        int n, m;
        cin >> n >> m;

        vector<vector<int>> arr(n, vector<int>(m));
        vector<int> row(n, 0);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                cin >> arr[i][j];
                if (arr[i][j] == 1) row[i]++;
            }
        }

        long long k = accumulate(row.begin(), row.end(), 0LL);

        if (k == 0) {
            cout << 0 << "\n";
            if (m == 1) {
                cout << "DR";
                for (int i = 0; i < n - 1; i++) cout << "D";
            } else {
                for (int i = 0; i < m - 1; i++) cout << "R";
                cout << "DR";
                for (int i = 0; i < n - 1; i++) cout << "D";
            }
            cout << "\n";
            continue;
        }

        long long val = k / 2;
        string s = "";
        int i = 0;

        while (i < n) {
            if (val >= row[i]) {
                s += 'D';
                val -= row[i];
            } else {
                int cnt = 0;
                for (int j = 0; j < m; j++) {
                    cnt += (arr[i][j] & 1);
                    s += 'R';

                    if (val - (row[i] - cnt) == 0) {
                        val = 0;
                        s += 'D';
                        for (int x = 0; x < m - j - 1; x++) s += 'R';
                        break;
                    }
                }
                break;
            }
            i++;
        }

        // SAFE PRODUCT USING __int128
        __int128 half = k / 2;
        __int128 result = half * (k - half);

        print_int128(result);
        cout << "\n";

        cout << s;
        for (int x = 0; x < n - i - 1; x++) cout << 'D';
        cout << "\n";
    }

    return 0;
}