#include <cmath>
#include <cctype>
#include <vector>
#include <string>
#include <algorithm>
#include <string>
#include <deque>
#include <stack>
#include <iostream>
#include <map>
#include <set>
#include <bits/stdc++.h>
#include <queue>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
 
 using namespace __gnu_pbds;
using namespace std;
 typedef tree<int, null_type,less_equal<int>,rb_tree_tag,tree_order_statistics_node_update>orderedset;
#define forn(i, n) for(int i = 0; i < int(n); i++)
typedef long long ll;
ll mod=1e9+7;
ll m;
 
ll powmod (ll a , ll b){
  if(a == 0 )return 0;
  ll ans=1;
  while(b > 0){
    if ( b& 1)ans = (ans * a) % mod;
    b>>=1;
    a = (a * a)%mod;
  } 
  return ans;
}
ll gcd(ll a,ll b){
    if(b==0)return a;
    if(a==0)return b;
    return gcd(b,a%b);
}
bool isprime(ll d){
    for(int i=2;i*i<=d;i++){
        if(d%i==0)return false;
    }
    return true;
 
}
ll getlast(ll a){
    for(ll i=64;i>=0;i--){
     if(a>>i&1)return i;
    }
    return 5;
}
bool isbli(string a){
    string q=a;
    reverse(q.begin(),q.end());
    if(q==a)return true;
    return false;
}
ll btd(ll a,ll b){
ll x=0;
while(a>1){
    a=(a-1)/2+1;
    x+=1;
}
while(b>1){
    b=(b-1)/2+1;
    x+=1;
}
return x;
}
 
  
ll popc(ll a){
    ll v=0;
    for(ll i=32;i>=0;i--){
     if((a>>i)&1)v++;
    }
    return v;
}
string flip(string a){
    string f=a;
    // cout<<f;
    for(int i=0;i<a.size();i++){
        if(f[i]=='0')f[i]='1';
        else f[i]='0';
    }
    return f;
}
const ll inf=1e18+2;
vector<ll>v1={1,1,1,0,0,-1,-1,-1};
vector<ll>v2;
vector<ll>spf(1e6+1,-1);
void fall(){
    ll d=1e6;
    for(int i=2;i<=d;i++){
        if(spf[i]==-1){
            for(int j=i;j<=d;j+=i){
                if(spf[j]==-1){
                    spf[j]=i;
                }
            }
        }
    }
}
vector<vector<ll>>adj;
vector<ll>ves;
vector<ll>ans;
void dfs(int v){
        ves[v]=1;
        for(auto i:adj[v]){
           if(!ves[i]){
            dfs(i);
           } 
        }
        ans.push_back(v);
}
const int N = 2e4+5;
vector<int>f(N);
 
ll solve(string a){
 ll n=a.size();
 ll dp[n+1][2];
 vector<vector<vector<ll>>>con(n+1,vector<vector<ll>>(10,vector<ll>(2,1)));

 for(int i=n-1;i>=0;i--){
    for(int h=0;h<=9;h++){
    for(int c=0;c<2;c++){
        dp[i][c]=0;
        ll en;
        if(c==1)en=(a[i]-'0');
        else en=9;
        for(int f=0;f<=en;f++){
            dp[i][c]+=dp[i+1][c&(f==(a[i]-'0'))];
            
        }
    }
}
 }
 dp[n][1]=1;
 dp[n][0]=1;
 for(int i=n-1;i>=0;i--){
    for(int c=0;c<2;c++){
        dp[i][c]=0;
        ll en;
        if(c==1)en=(a[i]-'0');
        else en=9;
        for(int f=0;f<=en;f++){
            dp[i][c]+=dp[i+1][c&(f==(a[i]-'0'))]*f;
            
        }
    }
 }
 return dp[0][1];
}
void solve(){
ll n,m;cin>>n>>m;
vector<vector<ll>>nums(n,vector<ll>(m,0));
ll x=0;
for(int i=0;i<n;i++){
    for(int j=0;j<m;j++){
    cin>>nums[i][j];
     if(nums[i][j])x++;
    }
}
ll tar=x/2;
cout<<tar*(x-tar)<<"\n";
if(tar==0){
    for(int i=0;i<n;i++)cout<<"D";
    for(int i=0;i<m;i++)cout<<"R";
    // cout<<"fafds";
    return;
}
for(int j=0;j<m;j++){
for(int i=n-1;i>=0;i--){
    tar-=nums[i][j];
    if(tar==0){
        for(int f=0;f<j;f++)cout<<"R";
        for(int f=0;f<i;f++)cout<<"D";
        cout<<"R";
        for(int f=i;f<n;f++)cout<<"D";
        for(int f=j+1;f<m;f++)cout<<"R";
        return;
    }

}
}

}




 
int main(){
   
    ios::sync_with_stdio(0);
    cin.tie(NULL);
 
 
    
    cout.tie(NULL);
    fall();
     ll dd = 1;
 
  cin>>dd;
///
    for(int i =0;i<dd;i++){
        solve();
        cout<<'\n';
    }
 return 0;
 
}