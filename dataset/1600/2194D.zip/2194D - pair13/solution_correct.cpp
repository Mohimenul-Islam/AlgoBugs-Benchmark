#include <bits/stdc++.h>
#define int long long
using namespace std;

int n, m, cnt1;

void solve()
{
	int x = 0, y = 0, num = 0;
	cin >> n >> m;
	cnt1 = 0;
	vector<vector<int>> a(n + 5, vector<int>(m + 5));
	vector<vector<int>> h(n + 5, vector<int>(m + 5));
	for (int i = 1; i <= n; i++)
	for (int j = 1; j <= m; j++)
	{
		cin >> a[i][j];
		if (a[i][j] == 1)
		cnt1++;
	}
	if ((cnt1 & 1) == 1)
	cout << (cnt1 / 2) * (cnt1 / 2 + 1) <<  "\n";
	else
	cout << (cnt1 / 2) * (cnt1 / 2) <<  "\n";
	cnt1 /= 2;
	for (int i = n; i >= 1; i--)
	for (int j = m; j >= 1; j--)
	h[i][j] = h[i][j + 1] + a[i][j];
	while (x+1<=n&&num + h[x + 1][1] <= cnt1)
	{
		num += h[x + 1][1];
		x++;
		cout <<"D";
	}
	while (1)
	{
    if(num<cnt1)
    {
      while(num+h[x+1][y+1]>cnt1)
      {
        y++;
        cout<<"R";
      }
      x++;
      cout<<"D";
    }
		while (y < m)
		{
			y++;
			cout <<"R";
		}
		while (x < n)
		{
			x++;
			cout <<"D";
		}
		cout <<"\n";
		return;
	}
}

signed main()
{
	int T;
	cin >> T;
	while (T--)
	solve();
	return 0;
}