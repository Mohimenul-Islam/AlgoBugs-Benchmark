#include <bits/stdc++.h>
using namespace std;
#define ll long long int
int main() 
{
    ll t;
    cin>>t;
    
    while(t--){
      ll n,m;
      cin>>n>>m;
      
      vector<vector<ll>>a(n+2,vector<ll>(m+2,0));
      vector<ll>col(m+5,0);
      ll tot=0;
      
      for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
          cin>>a[i][j];
          if(a[i][j]==1){
            col[j]+=1;
            tot++;
          } 
        }
      }
      
      
      
      int c=0;
      
      ll s=0;
      
      string ans="";
      while(c<m&&s+col[c+1]<=tot/2+tot%2){
        c++;
        s+=col[c];
        ans.push_back('R');
      }
      
      ll rs=tot-s-col[c+1];
      c++;
      bool ok=true;
      ll lst=c;
      int r=0;
      for(int i=1;i<=n;i++){
        ll add=0;
        if(a[i][c]==1){
          add=1;
        }
        
        if(rs+add<=tot/2){
          ans.push_back('D');
          rs+=add;
          r++;
        }
        
        
        else{
          s+=add;
        }
      }
      
      if(c<=m){
        ans.push_back('R');
        c++;
      }
      
       while(r<n){
         ans.push_back('D');
         r++;
       }
     
     
      
     // cout<<ans<<endl;
      
      while(c<=m){
        ans.push_back('R');
        c++;
      }
      
      cout<<rs*s<<endl;
      cout<<ans<<endl;
      
      
     
     
      
      
    }
    return 0;
}