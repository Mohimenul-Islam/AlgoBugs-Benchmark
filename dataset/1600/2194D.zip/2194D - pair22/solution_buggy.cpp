#include <bits/stdc++.h>
#define ll long long
#define endl "\n"
#define yes cout << "yes" << endl
#define no cout << "no" << endl
#define sq(a) (a)*(a)
#define pb push_back

using namespace std;
ll gcd(ll a, ll b);
ll num_divisors(ll a);

void solve()
{
    ll n, m; 
    cin>>n>>m;
    ll a[m][n];
    ll cn=0;
    ll b[n] ={};
    for(ll i=0; i<n; i++){
        for(ll j=0; j<m; j++){
            cin>>a[j][i];
            if(a[j][i]==1){
            cn++; b[i]++;
        }
        }
    }
    ll g= cn/2;
    cout<<g*(cn-g)<<endl;
    if(g==0){
        for(ll i=0 ; i<n; i++){
            cout<<'D';

        }
        for(ll i=0; i<m; i++){
            cout<<'R';
        }
        return;
    }
    ll up=0;
    ll d=0;
    while(up+b[d]<=g){
        cout<<'D';
        up+=b[d];
        d++;
    }
    ll r=0;
    up+=b[d];
    
    while(up!=g){
        cout<<'R';
        up-=a[r][d];
        r++;
    }

    cout<<'D';

    while(r<m){
        cout<<'R';
        r++;
    }
    while(d+1<n){
        cout<<'D';
        d++;
    }





cout<<endl;
   



}


int main()
{
int tt=1;
if(1) cin>>tt;
while(tt--)
{
solve();
}

}




















ll gcd(ll a, ll b)
{
    return b == 0 ? a : gcd(b, a % b);
}

ll num_divisors(ll a)
{
    ll counter = 0;
    for (ll i = 1; i * i <= a; i++)
    {
        if (a % i == 0)
        {
            a / i == i ? counter++ : counter += 2;
        }
    }
    return counter;
}