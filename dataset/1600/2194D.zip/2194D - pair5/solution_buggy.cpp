/*
Telebe of Adicto && Mamedov yani AzeTurk810
I see humans but no humanity
*/
#include <cassert>
#include <iostream>
#include <vector>

// mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

using ll = long long;
using namespace std;

#define ln '\n'
#define INFi 1e9
#define INFll 1e18

#ifdef ONPC
#include <algo.hpp>
#else
#define dbg(...)
#define dbg_out(...)
#endif

inline void systemd() {
}

char solve() {
    size_t _n, _m;
    if (!(cin >> _n >> _m))
        return 1;
    int cnt = 0;
    vector<vector<int>> G(_n + 1, vector<int>(_m + 1));
    for (size_t i = 1; i <= _n; i++) {
        for (size_t j = 1; j <= _m; j++) {
            cin >> G[i][j];
            if (G[i][j] == 1) {
                cnt++;
            }
        }
    }
    ll ans = (cnt >> 1) * ((cnt >> 1) + (cnt & 1));
    cout << ans << ln;
    ll tar = (cnt >> 1), cur = 0;
    dbg(tar);
    string res;
    for (size_t i = 1; i <= _n; i++) {
        for (size_t j = 1; j <= _m; j++) {
            cur += G[i][j];
        }
        if (cur >= tar) {
            dbg(cur);
            for (size_t j = 1; j <= _m + 1; ++j) {
                if (cur == tar) {
                    dbg(i);
                    dbg(j);
                    for (int _ = 1; _ < i; _++) {
                        res.push_back('D');
                    }
                    for (int _ = 1; _ < j; _++) {
                        res.push_back('R');
                    }
                    res.push_back('D');
                    for (int _ = j; _ <= _m; _++) {
                        res.push_back('R');
                    }
                    for (int _ = i; _ < _n; _++) {
                        res.push_back('D');
                    }
                    break;
                }
                if (j <= _m)
                    cur -= G[i][j];
            }
            break;
        }
    }
    if (_n == 0) {
        for (int i = 0; i < _m; i++) {
            res.push_back('R');
        }
    }
    if (_m == 0) {
        for (int i = 0; i < _n; i++) {
            res.push_back('D');
        }
    }
    dbg(res);
    cout << res << ln;
#ifdef ONPC
    assert(res.size() == _n + _m);
#endif // ONPC
    systemd();
    return 0;
}

// Attack on titan<3

signed main() {
    ios::sync_with_stdio(0);
    cin.tie(nullptr);
    int t = 1e9;
    cin >> t;
    for (int cases = 0; cases < t; cases++) {
        if (solve())
            break;
#ifdef ONPC
        cerr << "__________\n";
#endif
    }
}
// Just Imaginary
/*
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⠀⠀⠀⢀⣴⣾⠀⠀⠀⡀⢀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣦⣾⣿⣿⣿⣿⣿⡆⠁⠀⢀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⡿⠁⠀⡠⠂⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⠠⠔⠚⣿⣿⣿⣿⣿⣦⡄⠀⠁⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⠠⠐⢂⠉⡀⣀⣤⣄⢻⣿⣿⡟⢈⡹⣿⡀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⡀⠄⠂⠈⠀⣶⣤⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠘⣷⡀⠀⡀⠐⠂⠐⢄
⠀⠀⠀⠀⠀⠀⠀⣿⣿⠟⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⣀⣾⣷⠯⠀⠤⠤⠄⠈
⠀⠀⠀⠀⠀⠀⣼⣿⡟⠀⠀⣹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⡀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⣰⣿⠋⠀⠀⢠⣾⣿⣿⣿⣿⣿⣭⠟⢻⣿⣿⣿⣿⡿⠁⠀⠀⠀⠀
⠀⠀⠀⣀⣶⡟⠁⠀⢾⣶⣿⠟⠉⠈⢻⣿⣿⣿⣦⣜⠀⠛⠛⠿⠁⠀⠀⠀⠀⠀
⠚⠻⠿⠿⡿⠁⠀⢠⣿⣿⠁⠀⣠⠖⠋⠉⠻⣿⣿⣿⣶⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣰⣿⡿⠃⠠⠊⠁⠀⠀⠀⠀⠈⢿⣿⣿⠟⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢀⣴⡿⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⣠⣾⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⢀⣴⠾⠟⠛⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
*/
