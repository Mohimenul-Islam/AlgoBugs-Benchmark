#include<iostream>
using namespace std;
#include<vector>

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int T;cin >> T;
	while (T--) {
		int n, m;cin >> n >> m;
		vector<vector<int>>a(n + 1, vector<int>(m + 1));
		int sum = 0;
		vector<vector<int>>s(n + 1, vector<int>(m + 1));
		for (int i = 1;i <= n;i++) {
			for (int j = 1;j <= m;j++) {
				cin >> a[i][j];
				if (a[i][j])sum++;
				s[i][j] = s[i][j - 1] + a[i][j];
			}
		}
		int cur = 0;
		int des = sum / 2;
		string re;
		for (int i = 1;i <= n;i++) {
			if (cur + s[i][m] < des) {
				cur += s[i][m];
				re.push_back('D');
				continue;
			}
			int rest = des - cur;
			int j = 1;
			while (j<=m&&s[i][j] <=s[i][m]- rest) {
				re.push_back('R');
				j++;
			}
			cur = des;
			re.push_back('D');
			i++;
			while (j <= m) {
				re.push_back('R');
				j++;
			}
			while (i <= n) {
				re.push_back('D');
				i++;
			}
		}
		cout << des * (sum - des) << "\n";
		cout << re << "\n";
	}
}