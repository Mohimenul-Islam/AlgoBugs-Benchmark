/*    Arch On ROG forever    */
/* copyright by p0uya3767 and AlRntn */
/*          KAVI orz        */
#include <bits/stdc++.h>
#ifdef ONLINE_JUDGE
#pragma GCC optimize("Ofast")
#pragma GCC optimize("no-stack-protector")
#pragma GCC optimize("unroll-loops")
#pragma GCC target("sse,sse2,sse3,ssse3,popcnt,abm,mmx,tune=native")
#pragma GCC optimize("fast-math")
#pragma GCC target("avx,avx2,fma")
#endif 
#define pub push_back
#define ll long long   
#define vll vector<ll>
#define yes cout << "YES\n"
#define no cout << "NO\n"
#define coutarray(x, y, z) for(ll i=0; i<x; i++) cout << y[i] << z
#define cinarray(x, y) for(ll i=0; i<x; i++) cin >> y[i]
#define all(x) x.begin(), x.end()
using namespace std;



void Solve() {
    ll n,m; cin >> n >> m; vector<vll> a(n, vll (m)); 
    for(ll i=0; i<n; i++) {for(ll j=0; j<m; j++) cin >> a[i][j]; }
    vll row(n,0 ); ll one = 0;
    for(ll i=0; i<n; i++) {
        for(ll j=0; j<m; j++) row[i] += a[i][j];
        one += row[i];
    }
    ll now = 0; string s=""; bool y = 0;
    for(ll i=0; i<n; i++){
        if(now+row[i] > one/2){
            now += row[i]; bool x = 0;
            for(ll j=0; j<m; j++){
                if(now == one/2 && !x) {x=1;s+='D'; } 
                now -= a[i][j]; s += 'R'; y = 1;
            }
            break;
        }
        now += row[i]; s += 'D';
    }
    if(!y){
        for(ll i=0; i<m; i++) s+= 'R';
    }
    ll x = n+m-s.size();
    for(ll i=0; i<x; i++) s += 'D';
    cout << (one/2+one%2) * (one/2) << '\n';
    cout << s << '\n';
}


int main() {
    // freopen("inp.txt", "r", stdin); freopen("out.txt", "w", stdout);
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(NULL);  
    ll t;
    cin >> t;
    while (t--){
        //if(t == 10000-235) {ll n; cin >> n; vll a(n); cinarray(n,a); cout<<n<<':';coutarray(n,a,'*');}
        /*else*/ Solve(); 
    }
}

//??????????????????????????????????????????????????????????????????????//





// :)







// :0
