#include <bits/stdc++.h>
using namespace std;
typedef long long llt;
#define mod 1000000007


int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    llt t;
    cin>>t;
    while(t--){
    
        llt n,m;
        cin>>n>>m;
        vector<vector<llt>> v(n+1,vector<llt> (m+1));
        llt count=0;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=m;j++){
                cin>>v[i][j];
                count+=v[i][j];
            }
        }
        cout<<(count/2*((count+1)/2))<<endl;
        vector<vector<llt>> column=v;
        for(int j=1;j<=m;j++){
            for(int i=1;i<=n;i++){
                column[i][j]+=column[i-1][j];
            }
        }
        llt right=0,down=0,suml=0;
        while(right<m&&down<n){
            if((column[n][right+1]-column[down][right+1])+suml<=count/2){
                right++;
                suml+=(column[n][right]-column[down][right]);
                cout<<"R";
            }
            else{
                down++;
                cout<<"D";
            }
        }
        while(right<m){
            cout<<"R";
            right++;
        }
        while(down<n){
            cout<<"D";
            down++;
        }
        cout<<endl;
    }
    return 0;
}