#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/trie_policy.hpp>
#define int long long
using namespace std;
using namespace __gnu_pbds;
template <typename T> using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
template <typename T> using ordered_multiset = tree<T, null_type, less_equal<T>, rb_tree_tag, tree_order_statistics_node_update>;
// order_of_key (k) : Number of items strictly smaller than k
// find_by_order(k) : K-th element in a set (counting from zero)

const int MOD = 1e9 + 7;

void solve() {
	int n, m;
	cin >> n >> m;
	vector<vector<int>> a(n + 1, vector<int>(m + 1));

	int count_1 = 0;
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++) {
			cin >> a[i][j];
			if (a[i][j]) {
				count_1++;
			}
		}
	}

	if (!count_1) {
		cout << "0\n";
		for (int i = 1; i <= n; i++) {
			cout << 'D';
		}
		for (int i = 1; i <= m; i++) {
			cout << 'R';
		}
		cout << '\n';
		return;
	}

	int need = count_1 / 2;

	vector<vector<int>> pref_row(n + 1, vector<int>(m + 1));
	vector<vector<int>> pref_col(n + 1, vector<int>(m + 1));

	for (int c = 1; c <= m; c++) {
		for (int r = 1; r <= n; r++) {
			pref_col[r][c] = pref_col[r - 1][c] + a[r][c];
		}
	}

	for (int r = 1; r <= n; r++) {
		for (int c = 1; c <= m; c++) {
			pref_row[r][c] = pref_row[r][c - 1] + a[r][c];
		}
	}

	vector<vector<int>> color(n + 1, vector<int>(m + 1));

	int c = 1, r = n, sum = 0;
	while (true) {
		if (sum == need) {
			break;
		}
		int col_here = pref_col[r - 1][c];
		int row_here = pref_row[r][m] - pref_row[r][c - 1];

		if (col_here + row_here + sum <= need) {
			for (int i = 1; i < r; i++) { 
				color[i][c] = 1;
			}
			for (int i = c; i <= m; i++) {
				color[r][i] = 1;
			}
			sum += col_here + row_here;
		} else {
			int j = 0;
			for (int i = 1; i < r; i++) {
				j = i;
				if (pref_col[r - 1][c] - pref_col[i][c] + row_here + sum == need) {
					break;
				}
			}

			sum += pref_col[r - 1][c] - pref_col[j][c];
			for (int i = j + 1; i < r; i++) {
				color[i][c] = 1;
			}
			if (sum == need) {
				break;
			}

			j = m;
			for (int i = m; i >= c; i--) {
				if (sum + pref_row[r][i] - pref_row[r][c - 1] == need) {
					j = i;
					break;
				}
			}

			for (int i = c; i <= j; i++) {
				color[r][i] = 1;
			}
			sum = need;
		}
		r--;
		c++;
	}

	// for (int i = 1; i <= n; i++) {
	// 	for (int j = 1; j <= m; j++) {
	// 		cout << color[i][j] << ' ';
	// 	}
	// 	cout << '\n';
	// }
	// cout << '\n';
	
	int x = 1, y = 1;
	vector<char> ans;
	while (x <= n and y <= m) {
		if (color[x][y] == 0) {
			ans.push_back('D');
			x++;
		} else {
			ans.push_back('R');
			y++;
		}
	}

	if (ans.back() == 'D') {
		while (ans.size() < n + m) {
			ans.push_back('R');
		}
	} else {
		while (ans.size() < n + m) {
			ans.push_back('D');
		}
	}

	cout << need * (count_1 - need) << '\n';
	for (char &c : ans) {
		cout << c;
	}
	cout << '\n';
}

signed main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	int t;
	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
}