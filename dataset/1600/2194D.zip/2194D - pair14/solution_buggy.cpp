/*  
    First of all           I am Vegeta
    Second of all    you're not Vegeta
    Third of all   you wanna be Vegeta
               but you can't be Vegeta
                       bcz I am Vegeta
    1/40
*/
 
#include <bits/stdc++.h>
using namespace std;
 
 
#define int long long 
#define endl '\n' 
#define INF 100
#define N 200001

struct Prefix2D {
    int n, m;  
    vector<vector<int>> grid, pref;  
    Prefix2D (int _n, int _m) : n(_n), m(_m) {
        grid.assign(n + 1, vector<int> (m + 1, 0));
        pref.assign(n + 1, vector<int> (m + 1, 0));
    }
    void set_grid(const vector<vector<int>> &a) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                grid[i][j] = a[i][j];
            }
        }
    }
    void precalculate() {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                pref[i][j] = grid[i][j] + pref[i - 1][j] + pref[i][j - 1] - pref[i - 1][j - 1];
            }
        }
    }
    int area_of_rectangle(int r1, int c1, int r2, int c2) {
        if (r1 > r2) swap(r1, r2); 
        if (c1 > c2) swap(c1, c2);
        return pref[r2][c2] - pref[r1- 1][c2] - pref[r2][c1 - 1] + pref[r1 - 1][c1 - 1];
    }
    int L_area(int r, int c, int rb) {
        int res = area_of_rectangle(1, 1, n, c);   
        if (c < rb) res += area_of_rectangle(r, c + 1, n, rb);
        return res;
    }
};


void soln() {         
    int n, m;  
    cin >> n >> m; 
    vector<vector<int>> a(n + 1, vector<int> (m + 1)); 
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            cin >> a[i][j];
            sum += a[i][j];
        }
    }
    cout << (sum / 2) * ((sum + 1) / 2) << endl;
    Prefix2D pref(n, m);
    pref.set_grid(a); 
    pref.precalculate();
    for (int r = 1; r <= n; r++) {
        for (int c = 1; c <= m; c++) {
            if (pref.L_area(r, c, m) < sum / 2) continue;
            int L = c, R = m, rb = -1;  
            while (L <= R) {
                int mid = (L + R) / 2; 
                int area = pref.L_area(r, c, mid);
                if (area >= sum / 2) {
                    rb = mid;  
                    R = mid - 1;
                }
                else L = mid + 1;
            } 
            if (rb == -1 || pref.L_area(r, c, rb) > (sum + 1) / 2) continue; 
            int i = 0, j = 0;  
            while (j < c) {
                cout << 'R';
                j++;
            }
            while (i < r - 1) {
                cout << 'D'; 
                i++;
            }
            while (j < rb) {
                cout << 'R';  
                j++;
            }
            while (i < n) {
                cout << 'D';  
                i++;
            }
            while (j < m) {
                cout << 'R';  
                j++;
            }
            cout << endl;
            return; 
        }
    }
}       
 
 
signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0); 
    #ifndef ONLINE_JUDGE
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
    #endif
 
 
    
 
    int T = 1; 
    cin >> T; 
    int t = 1;
    while (T--) {
        //cout << "Case #" << (t++) << ": "; 
        soln();  
    }
 
 
    
 
    return 0;
 
}