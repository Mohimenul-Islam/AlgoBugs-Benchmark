/*  
    First of all           I am Vegeta
    Second of all    you're not Vegeta
    Third of all   you wanna be Vegeta
               but you can't be Vegeta
                       bcz I am Vegeta
    1/40
*/
 
#include <bits/stdc++.h>
using namespace std;
 
 
#define int long long 
#define endl '\n' 
#define INF 100
#define N 200001



void soln() {         
    int n, m;  
    cin >> n >> m; 
    vector<vector<int>> a(n + 1, vector<int> (m + 1)); 
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            cin >> a[i][j];
            sum += a[i][j];
        }
    }
    cout << (sum / 2) * ((sum + 1) / 2) << endl;
    int x = sum / 2;  
    int r = 0, c = 0;
    sum = 0;
    for (int i = 1; i <= n; i++) {
        bool found = false;
        for (int j = m; j >= 1; j--) {
            sum += a[i][j];
            if (sum == x) {
                r = i, c = j;
                found = true; 
                break;
            }
        } 
        if (found) break;
    }
    int i = 0, j = 0;  
    while (i < r - 1) {
        cout << 'D'; 
        i++; 
    }
    while (j < c - 1) {
        cout << 'R';  
        j++; 
    } 
    cout << 'D';
    i++;
    while (j < m) {
        cout << 'R';  
        j++;
    }
    while (i < n) {
        cout << 'D'; 
        i++;
    }
    cout << endl;
}       
 
 
signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0); 
    #ifndef ONLINE_JUDGE
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
    #endif
 
 
    
 
    int T = 1; 
    cin >> T; 
    int t = 1;
    while (T--) {
        //cout << "Case #" << (t++) << ": "; 
        soln();  
    }
 
 
    
 
    return 0;
 
}