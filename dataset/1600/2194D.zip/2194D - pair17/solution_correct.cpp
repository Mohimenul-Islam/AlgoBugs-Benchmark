#include <bits/stdc++.h>
#include <iostream>
using namespace std;
#define ll long long int 
#define f(n)for(int i=0;i<n;i++)
#define asc(v) sort(v.begin(),v.end())
#define desc(v) sort(v.begin(),v.end(),greater<ll>())
#define rev(v) reverse((v.begin(),v.end()))
#define all(v) v.begin(),v.end()
#define lb(v,val) lower_bound(v.begin(),v.end(),val)
#define ub(v,val) upper_bound(v.begin(),v.end(),val)
#define vec vector<long long int>
#define pb push_back
#define tp tuple<ll,ll,ll>
#define pr pair<ll,ll>
#define yes cout << "YES" << endl
#define no cout << "NO" << endl
#define nx cout<<endl;
#define sp " "
#define bcnt(x) __builtin_popcountll(x) // Number of set bits int
#define bctz(x) __builtin_ctzll(x) // Ct of trailing zeros in binary
#define bclz(x) __builtin_clzll(x) // Ct of leading zeros in binary -> msb = (31-bclz(x))
#define mll map<ll,ll>
#define fr(l,r) for(ll i=l;i<=r;i++)
const ll mod = 1e9+7;
ll gcd(ll  a, ll b){
    if (b == 0)
        return a;
    return gcd(b, a % b);
}
ll lcm( ll a, ll b){
    return (a*b)/gcd(a,b);
}
// multiplication
ll mul(ll a, ll b) {
    return ( (a % mod) * (b % mod) ) % mod;
}

// binary exponentiation
ll binexp(ll a, ll b) {
    ll res = 1;
    a %= mod;
    while (b) {
        if (b & 1) res = mul(res, a);
        a = mul(a, a);
        b >>= 1;
    }
    return res;
}

// modular inverse (mod must be prime)
ll inv(ll a) {
    return binexp(a, mod - 2);
}

// division (a / b mod m)
ll divide(ll a, ll b) {
    return mul(a, inv(b));
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin >> t;
    while (t--) {
        ll n,m;
        cin>>n>>m;
       ll a[n+1][m+1];
       ll o=0;
      fr(1,n){
        for(ll j=1;j<=m;j++){
            cin>>a[i][j];
            if(a[i][j]==1)o++;
        }
      }
      ll need=o/2;
      string s="";
      vec pref(n+1,0);
      fr(1,n){
        for(ll j=1;j<=m;j++){
            pref[i]+=a[i][j];
        }
      }
      if(o&1){
        cout<<(o/2*(o/2+1))<<endl;
      }
      else cout<<(o/2*o/2)<<endl;
      ll v=1;
      while(true && v<n){
        if(pref[v]<=need){
            s+='D';
            need-=pref[v];
        }
        else break;
        v++;

      }
      ll sum=0;
      ll z;
      for( z=m;z>=1;z--){
         if(sum==need)break;
        sum+=a[v][z];}
    f(z){
        s+='R';
    }
    s+='D';
   
    f(m-z)s+='R';
    f(n-v)s+='D';
    cout<<s<<endl;
      


    }}