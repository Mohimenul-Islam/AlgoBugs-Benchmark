#include <bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define endl '\n'
#define int long long
#define _for(i, a, b) for (int i = (a); i <= (b); i++)
using namespace std;
template <typename T>
ostream &operator<<(ostream &os, const vector<T> &v)
{
    for (int i = 0; i < v.size(); i++)
    {
        os << v[i] << " ";
    }
    return os;
}
template <typename T>
ostream &operator<<(ostream &os, const set<T> &v)
{
    for (typename set<T>::iterator it = v.begin(); it != v.end(); it++)
    {
        os << *it << " ";
    }
    return os;
}
void solve()
{
    int n, ax, ay, bx, by;
    cin >> n >> ax >> ay >> bx >> by;
    map<int, vector<int>> mp;
    vector<int> X(n);
    for (int i = 0; i < n; i++)
    {
        cin >> X[i];
    }
    for (int i = 0; i < n; i++)
    {
        int y;
        cin >> y;

        mp[X[i]].push_back(y);
    }
    mp[bx].push_back(by);
    vector<vector<int>> dp(mp.size() + 2, vector<int>(2));
    dp[0][0] = 0;
    dp[0][1] = 0;
    int j = 1;
    int lastx = ax, lastlow = ay, lasthigh = ay;
    for (auto m : mp)
    {
        int x = m.first;
        vector<int> ty = m.second;
        sort(ty.begin(), ty.end());
        int low = ty.front(), high = ty.back();
        dp[j][0] = min(dp[j - 1][0] + abs(lasthigh - low) + abs(high - low), dp[j - 1][1] + abs(lastlow - low) + abs(high - low)) + x - lastx;
        dp[j][1] = min(dp[j - 1][0] + abs(lasthigh - high) + abs(high - low), dp[j - 1][1] + abs(lastlow - high) + abs(high - low)) + x - lastx;
        lastx = x;
        lasthigh = high;
        lastlow = low;
        j++;
    }
    cout << min(dp[j - 1][0], dp[j - 1][1]) << endl;
}
signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);
    int t;
    cin >> t;
    while (t--)
    {
        solve();
    }
    return 0;
}