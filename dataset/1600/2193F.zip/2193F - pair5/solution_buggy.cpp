/*
 * ------------------------------------------------------------
 * Author    : Saksham
 * Created   : 30-04-2026 15:21:37
 * ------------------------------------------------------------
 */

#include <bits/stdc++.h>

using namespace std;

// ----------- Optimization -----------
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

// ----------- Shortcuts --------------
#define int long long
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
#define pb push_back
#define fi first
#define se second
#define ln '\n'
#define sp ' '
#define yes cout << "YES\n"
#define no cout << "NO\n"
#define Saksham() ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)

int Mid(int l, int r) { return l + (r - l) / 2; }

// ----------- Typedefs --------------
typedef pair<int,int> pii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<pii> vii;

// ----------- Loops -----------------
#define rep2(i, e) for(int i = 0; i < (e); ++i)
#define rep3(i, s, e) for(int i = (s); i <= (e); ++i)
#define GET_MACRO(_1, _2, _3, NAME, ...) NAME
#define rep(...) GET_MACRO(__VA_ARGS__, rep3, rep2)(__VA_ARGS__)

#define rev2(i, e) for(int i = (e); i >= 0; --i)
#define rev3(i, s, e) for(int i = (s); i >= (e); --i)
#define GET_MACRO_REV(_1, _2, _3, NAME, ...) NAME
#define rev(...) GET_MACRO_REV(__VA_ARGS__, rev3, rev2)(__VA_ARGS__)

// ----------- Custom IO -------------
template<typename T1, typename T2>
istream& operator>>(istream& in, pair<T1,T2>& p) { return in >> p.first >> p.second; }
template<typename T>
istream& operator>>(istream& in, vector<T>& v) { for (auto &x : v) in >> x; return in; }

// Print Vector: print(v)
template<typename T>
void print(const vector<T>& v) {
    for(const auto& x : v) cout << x << " ";
    cout << ln;
}

// Print Array: print(arr, n)
template<typename T>
void print(T a[], int n) {
    for(int i = 0; i < n; ++i) cout << a[i] << " ";
    cout << ln;
}

// ----------- Debug -----------------
#ifndef ONLINE_JUDGE
#define dbg(x...) cerr << #x << " = ", _print(x)
void _print() { cerr << '\n'; }
template<typename T, typename... V> void _print(T t, V... v) { cerr << t << " "; _print(v...); }
#else
#define dbg(x...)
#endif

// ----------- Math ------------------
int gcd(int a, int b) { while(b) { a %= b; swap(a,b); } return a; }
int lcm(int a, int b) { return (a/gcd(a,b))*b; }
const int mod = 1e9+7;

int add(int a, int b) { return ( (a%mod) + (b%mod) ) % mod; }
int mul(int a, int b) { return ( (a%mod) * (b%mod) ) % mod; }

int binpow(int a, int b , int mod) {
    int res = 1;
    a = a % mod;
    while(b > 0) {
        if(b & 1) {
            res = mul(res, a);
        }
        a = mul(a, a);
        b >>= 1;
    }
    return res;
}

int modinv(int a , int mod) {
    return binpow(a , mod - 2 , mod);
}

// ----------Sieve of Eratosthenes ---------
const int N = 1e5 + 7;
vector<bool> isPrime(N,1);
vector<int> lp(N,0) , hp(N,0);

void sieve(){
    isPrime[0] = isPrime[1] = 0;
    for(int i = 2 ; i < N ; i++){
        if(isPrime[i] == true){
            hp[i] = lp[i] = i;
            for(int j = 2 * i ; j < N ; j+= i ){
                isPrime[j] = false;
                hp[j] = i;
                if(lp[j] == 0){
                    lp[j] = i;
                }
            }
        }
    }
}

vector<int> getprimefactors(int n){
    vector<int> factors;
    while(n > 1){
        int primefactor = lp[n];
        factors.push_back(primefactor);
        n = n / primefactor;
    }
    return factors;
}

// ----------- DSU ------------------
class DSU {
    vi parent, size;
public:
    DSU(int n) {
        parent.resize(n + 1);
        size.resize(n + 1, 1);
        iota(all(parent), 0);
    }
    int find(int node) {
        if (parent[node] == node) return node;
        return parent[node] = find(parent[node]);
    }
    void unite(int u, int v) {
        int pu = find(u), pv = find(v);
        if (pu == pv) return;
        if (size[pu] > size[pv]) {
            parent[pv] = pu;
            size[pu] += size[pv];
        } else {
            parent[pu] = pv;
            size[pv] += size[pu];
        }
    }
};

// ----------- Segment Tree (Sum) ------------------
struct SegTree {
    int n;
    vi tree;
    SegTree(int n) : n(n), tree(4 * n, 0) {}
    
    void build(const vi &a, int v, int tl, int tr) {
        if (tl == tr) tree[v] = a[tl];
        else {
            int tm = (tl + tr) / 2;
            build(a, 2 * v, tl, tm);
            build(a, 2 * v + 1, tm + 1, tr);
            tree[v] = tree[2 * v] + tree[2 * v + 1];
        }
    }
    void build(const vi &a) { build(a, 1, 0, n - 1); }
    
    void update(int v, int tl, int tr, int pos, int val) {
        if (tl == tr) tree[v] = val;
        else {
            int tm = (tl + tr) / 2;
            if (pos <= tm) update(2 * v, tl, tm, pos, val);
            else update(2 * v + 1, tm + 1, tr, pos, val);
            tree[v] = tree[2 * v] + tree[2 * v + 1];
        }
    }
    void update(int pos, int val) { update(1, 0, n - 1, pos, val); }
    
    int query(int v, int tl, int tr, int l, int r) {
        if (l > tr || r < tl) return 0;
        if (l <= tl && r >= tr) return tree[v];
        int tm = (tl + tr) / 2;
        return query(2 * v, tl, tm, l, r) + query(2 * v + 1, tm + 1, tr, l, r);
    }
    int query(int l, int r) { return query(1, 0, n - 1, l, r); }
};

//-------- SCC (Kosaraju's Algorithm) ------------------
void DFS(int node, vector<bool>& visited, vector<vector<int>>& adjList, stack<int>& st) {
    visited[node] = true;
    for (auto it : adjList[node]) {
        if (!visited[it]) {
            DFS(it, visited, adjList, st);
        }
    }
    st.push(node);
}

void dfs(int node, vector<bool>& visited, vector<vector<int>>& graph, vector<int>& result) {
    visited[node] = true;
    for (auto it : graph[node]) {
        if (!visited[it]) {
            dfs(it, visited, graph, result);
        }
    }
    result.push_back(node);
}

vector<vector<int>> SCC(vector<vector<int>>& adjList) {
    int n = adjList.size();
    vector<vector<int>> ans;
    vector<bool> visited(n, false);
    stack<int> st;
    
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            DFS(i, visited, adjList, st);
        }
    }

    // Transposing the graph
    vector<vector<int>> revGraph(n);
    for (int i = 0; i < n; i++) {
        for (auto it : adjList[i]) {
            revGraph[it].push_back(i);
        }
    }
    
    // Reset visited array for the second pass
    fill(visited.begin(), visited.end(), false);
    
    while (!st.empty()) {
        int node = st.top();
        st.pop();
        if (!visited[node]) {
            vector<int> result;
            dfs(node, visited, revGraph, result);
            ans.push_back(result);
        }
    }
    
    return ans;
}

struct FenwickTree {
private:
    vector<int> tree;
    int n;

public:
    FenwickTree(int size) {
        this->n = size;
        tree.assign(n + 1, 0);
    }

    FenwickTree(const vector<int>& nums) {
        this->n = nums.size();
        tree.assign(n + 1, 0);
        for (int i = 0; i < n; i++) {
            add(i + 1, nums[i]);
        }
    }

    void add(int idx, int delta) {
        while (idx <= n) {
            tree[idx] += delta;
            idx += idx & (-idx);
        }
    }

    int query(int idx) {
        int sum = 0;
        while (idx > 0) {
            sum += tree[idx];
            idx -= idx & (-idx);
        }
        return sum;
    }

    int range_query(int l, int r) {
        if (l > r) return 0;
        return query(r) - query(l - 1);
    }
};

class twoSAT{
public:
    int n;
    vector<int>order, comp;
    vector<vector<int>>adj, adj_t;
    vector<bool>used, assignment;

    twoSAT(int n){
        this->n = n;
        adj.resize(2*n);
        adj_t.resize(2*n);
        used.resize(2*n);
        comp.resize(2*n, -1);
        assignment.resize(n);
    }

    int neg(int x){
        return (x+n)%(2*n);
    }

    void add_edge(int u, int v){
        adj[u].push_back(v);
        adj_t[v].push_back(u);
    }

    void add_clause(int a, int b){
        add_edge(neg(a), b);
        add_edge(neg(b), a);
    }

    void dfs1(int v){
        used[v] = true;
        for(int u: adj[v]){
            if(!used[u]) dfs1(u);
        }
        order.push_back(v);
    }

    void dfs2(int v, int cl){
        comp[v] = cl;
        for(int u: adj_t[v]){
            if(comp[u] == -1) dfs2(u, cl);
        }
    }

    bool solve(){
        used.assign(2*n, false);
        for(int i=0; i<2*n; i++){
            if(!used[i]) dfs1(i);
        }

        int cl = 0;
        for(int i=2*n-1; i>=0; i--){
            if(comp[order[i]] == -1) dfs2(order[i], ++cl);
        }

        for(int i=0;i<n; i++){
            if(comp[i] == comp[neg(i)]){
                return false;
            }
            assignment[i] = comp[i] > comp[neg(i)];
        }
        return true;
    }
};

// ----------- Solve -----------------

int dp[200005][2];
int a;
int n,ax,ay,bx,by;

int f(int i,int flag,vi& vx,map<int,vi>& mp){
    if(i == a){
        return 0;
    }
    if(dp[i][flag] != -1) return dp[i][flag];

    if(i == a-1){
        int ad = 0;
        int tmp = mp[vx[i]][1] - mp[vx[i]][0];
        if(flag){
            ad = abs(bx-vx[i]) + abs(by-mp[vx[i]][0]);
        }
        else{
            ad = abs(bx-vx[i]) + abs(by-mp[vx[i]][1]);
        }
        return dp[i][flag] = tmp + ad;
    }

    if(flag){
        int tmp = mp[vx[i]][1] - mp[vx[i]][0];
        int ry = 0 , xx = 0 , ly = 0;
        if(i != a-1){
            // right mai jaana
            ry = abs(mp[vx[i+1]][1] - mp[vx[i]][0]);
            xx = vx[i+1]-vx[i];
            ly = abs(mp[vx[i+1]][0] - mp[vx[i]][0]);
        }
        int ans = LLONG_MAX;
        ans = min(ans,tmp+xx+ry+f(i+1,1,vx,mp));
        ans = min(ans,tmp+xx+ly+f(i+1,0,vx,mp));
        return dp[i][flag] = ans;
    }
    else{
        int tmp = mp[vx[i]][1] - mp[vx[i]][0];
        int ry = 0 , xx = 0 , ly = 0;
        if(i != a-1){
            ry = abs(mp[vx[i+1]][1] - mp[vx[i]][1]);
            xx = vx[i+1]-vx[i];
            ly = abs(mp[vx[i+1]][0] - mp[vx[i]][1]);
        }
        int ans = LLONG_MAX;
        ans = min(ans,tmp+xx+ry+f(i+1,flag,vx,mp));
        ans = min(ans,tmp+xx+ly+f(i+1,!flag,vx,mp));
        return dp[i][flag] = ans;
    }
}


void solve() {
    cin>>n>>ax>>ay>>bx>>by;
    vi x(n),y(n);
    cin>>x;
    cin>>y;
    vi vx;
    map<int,vi> mp;
    rep(i,n){
        if(mp.count(x[i])){
            int u = mp[x[i]][0] , v =  mp[x[i]][1];
            if(y[i] < u){
                mp[x[i]][0] = y[i];
            }
            else if(y[i] > v){
                mp[x[i]][1] = y[i];
            }
        }
        else{
            vx.pb(x[i]);
            mp[x[i]] = {y[i],y[i]};
        }
    }
    a = vx.size();
    sort(all(vx));
    memset(dp,-1,sizeof(dp));
    int res = LLONG_MAX;
    int db = abs(vx[0]-ax) + abs(mp[vx[0]][0]-ay);
    res = min(res,db+f(0,0,vx,mp));
    int dt = abs(vx[0]-ax) + abs(mp[vx[0]][1]-ay);
    res = min(res,dt+f(0,1,vx,mp));
    cout << res << ln;
}

// ----------- Main ------------------
int32_t main() {
    Saksham();
    // sieve();
    int t = 1;
    cin >> t;
    while(t--) {
        solve();
    }
    return 0;
}