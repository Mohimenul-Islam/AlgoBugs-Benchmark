#include<bits/stdc++.h>
#define INF 0x3f3f3f3f3f3f3f3f
#define FOR(i,a,b) for(int i=(a);i<=(b);i++)
#define RFOR(i,a,b) for(int i=(a);i>=(b);i--)
typedef long long ll;
using namespace std;
template<typename T>
inline T read(){
	T x=0,f=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
	while(isdigit(c)){x=x*10+c-48;c=getchar();}
	return x*f;
}
#define int long long
const int N=2e5+5;
int n,q;
int x[N],y[N],binx[N],l[N],r[N];
int dp[N][2];
int ax,ay,bx,by;
void solve(){
	cin>>n>>ax>>ay>>bx>>by;
	memset(dp,0,sizeof dp);
	for(int i=1;i<=n;i++) cin>>x[i],binx[i]=x[i];
	for(int i=1;i<=n;i++) cin>>y[i];
	for(int i=1;i<=n;i++) l[i]=r[i]=0;
	sort(binx+1,binx+n+1);
	int cnt=unique(binx+1,binx+n+1)-binx-1;
	for(int i=1;i<=n;i++){
		int t=lower_bound(binx+1,binx+cnt+1,x[i])-binx;
		if(l[t]) l[t]=min(l[t],y[i]);
		else l[t]=y[i];
		if(r[t]) r[t]=max(r[t],y[i]);
		else r[t]=y[i];
	}
	n=cnt;
	l[0]=r[0]=ay,l[n+1]=r[n+1]=by;
	binx[0]=ax,binx[n+1]=bx;
	for(int i=1;i<=n+1;i++){
		int need=binx[i]-binx[i-1]+r[i]-l[i];
		dp[i][0]=min(dp[i-1][0]+abs(l[i-1]-r[i]),dp[i-1][1]+abs(r[i-1]-r[i]))+need;
		dp[i][1]=min(dp[i-1][0]+abs(l[i-1]-l[i]),dp[i-1][1]+abs(r[i-1]-l[i]))+need;
	}
	cout<<dp[n+1][0]<<"\n";
}
signed main(){
	ios::sync_with_stdio(0);cin.tie(0),cout.tie(0);
	int T;
	cin>>T;
	while(T--){
		solve();
	}
	return 0;
}
