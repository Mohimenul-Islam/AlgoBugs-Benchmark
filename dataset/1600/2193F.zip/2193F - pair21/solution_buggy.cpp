#include <bits/stdc++.h>
#include <bit>
#define lowbit(x) (x & (-x))
#define pc(x) __builtin_popcount(x)
#define pcl(x) __builtin_popcountll(x)
#define all(v) (v).begin(), (v).end()
#define rall(v) (v).rbegin(), (v).rend()
#define Sort(v) sort(v.begin(), v.end())
#define fo(i, a, b) for (int i = a; i < b; i++)
#define rfo(i, a, b) for (int i = a; i >= b; i--)
#define each(x, a) for (auto &x : a)
#define F first
#define S second
#define pb push_back
#define ob pop_back
#define endl '\n'

using namespace std;
using ll = long long;
using u32 = unsigned int;
using u64 = unsigned long long;
using db = double;
using i128 = __int128_t;
using u128 = __uint128_t;
using PII = pair<int, int>;
using PIIL = pair<long long, long long>;
using TII = tuple<int, int, int>;
using pi = array<int, 2>;
int msb(long long x)
{ //__lg(x)
    if (x == 0)
        return 0;
    return 63 - __builtin_clzll(x);
}
void print(auto &a)
{
    each(x, a) cout << x << " ";
    cout << endl;
}

const int inf = 0x3f3f3f3f;
const int MOD = 1e9 + 7;

void solve()
{
    int n,sx,sy,tx,ty;
    map<int,PII> mp;
    cin >> n >> sx >> sy >> tx >> ty;
    vector<int> xs(n),ys(n);
    fo(i,0,n) cin >> xs[i];
    fo(i,0,n) cin >> ys[i];
    fo(i,0,n){
        int x = xs[i],y = ys[i];
        if(!mp.count(x)) mp[x] = {y,y};
        else{
            mp[x].F = min(mp[x].F,y);
            mp[x].S = max(mp[x].S,y);
        }
    }
    int m = mp.size();
    vector<vector<int>> a;
    int las = sx;
    ll bas = 0;
    for(auto& [x,p] : mp){
        bas += x - las;
        las = x;
        a.pb({p.F,p.S});
    }
    bas += tx - las;
    auto get = [&](vector<int>& p,int y,int k)->int{
        int l = p[0],r = p[1];
        if(k == 0){
            if(y <= r) return r - y + r - l;
            else return y - l;
        }else{
            if(y >= l) return y - l + r - l;
            else return r - y;
        }
    };
    vector f(m,vector<ll>(2,inf));
    f[0][0] = get(a[0],sy,0);
    f[0][1] = get(a[0],sy,1);
    fo(i,1,m){
        fo(j,0,2){
            int y = a[i - 1][j];
            fo(k,0,2){
                f[i][k] = min(f[i][k],f[i - 1][j] + get(a[i],y,k));
            }
        }
    }
    ll ans = bas + min(f[m - 1][0] + abs(ty - a[m - 1][0]),f[m - 1][1] + abs(ty - a[m - 1][1]));
    cout << ans << endl;
}

signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr), cout.tie(nullptr);
    int t;
    cin >> t;
    while (t--)
        solve();
    return 0;
}