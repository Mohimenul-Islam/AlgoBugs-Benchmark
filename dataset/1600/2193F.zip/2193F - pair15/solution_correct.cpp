///////mon777///////
#include <iostream>
#include <iomanip>
#include <array>
#include <string>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <vector>
#include <stack>
#include <queue>
#include <deque>
#include <bitset>
#include <list>
#include <iterator>
#include <numeric>
#include <utility>
#include <random>
#include <cassert>
#include <fstream>
#include <climits>
#include <complex>
#include <chrono>

using namespace std;

// typedefs//
typedef long long ll;
typedef double db;
typedef unsigned long long ull;
typedef long double ldb;

// define//
#define yes cout << "YES\n"
#define no cout << "NO\n"
#define ff first
#define ss second
#define pb push_back
#define ppb pop_back
#define all(o) (o).begin(), (o).end()
#define chkpav cout << -1 << '\n'
#define ppf pop_front
#define pf push_front
#define rall(v) v.rbegin(), v.rend()
#define inf 1e18
#define infint 1e9
#define PII pair<int, int>

const ll N = 1e5 + 2;
const ll mod = 1e9 + 7;

// mt19937 rnd(chrono::system_clock::now().time_since_epoch().count());

void setIO(string name = ""){
    if (!name.empty()){
        freopen((name + ".in").c_str(), "r", stdin);
        freopen((name + ".out").c_str(), "w", stdout);
    }
}

void FastIO()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
}

int reverseDigits(int n)
{
    int revNum = 0;
    int basePos = 1;
    if (n > 0) {
        reverseDigits(n / 10);
        revNum += (n % 10) * basePos;
        basePos *= 10;
    }
    return revNum;
}

void setPrecision(int x)
{
    if (x == 0)
        return;
    cout.setf(ios::fixed);
    cout.precision(x);
}

vector<ll> fibo(int x)
{

    vector<ll> fib(x + 1, 0);

    fib[0] = fib[1] = 1;
    if (x <= 1)
        return fib;

    for (int i = 2; i <= x; ++i)
    {
        fib[i] = fib[i - 1] + fib[i - 2];
        fib[i] %= mod;
    }
    return fib;
}

ll gcd(ll a, ll b)
{
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

ll lcm(ll a, ll b)
{
    return (a * b) / gcd(a, b);
}

/*

     0.1 2 3 4   5  6  7
0    1
1    1 1
2    1 2 1
3    1 3 3 1
4    1 4 6 4 1
5    1 5 10 10 5 1
6    1 6 15 20 15 6 1
7    1 7 21 35 35 21 7 1

c72= 6*7/2=21;

*/

// ll binlen(ll x) {// binarniov nerkayacman erkarutyun
//     if (x == 0) return -1;
//     return 64 - __builtin_clzll(x);
// }

ll C[755][755];

void cnk(){
    C[0][0] = 1;
    for (int i = 1; i < 750; ++i)
    {
        C[i][0] = C[i][i] = 1;
        for (int j = 1; j < i; ++j)
        {
            if (j > i)
                C[i][j] = 0;
            else if (i == j)
                C[i][j] = 1;
            else
                C[i][j] = C[i - 1][j - 1] + C[i - 1][j];
            C[i][j] %= mod;
        }
    }
    return;
}

ll binpow(int x, int y)
{
    if (y == 0)
        return 1;
    ll res = binpow(x, y / 2);
    res *= res;
    res %= mod;
    if (y & 1)
        res *= x;
    res %= mod;
    return res;
}

mt19937 rnd(chrono::system_clock::now().time_since_epoch().count());

///////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////

int n, ax,ay,bx,by;

void solve(){

    vector<pair<int, int>> xy;
    ll dp[200005][2];

    cin>>n;
    cin>>ax>>ay>>bx>>by;
    xy.resize(n);
    for(int i=0;i<n;++i){
        cin>>xy[i].ff;
    }
    for(int i=0;i<n;++i) cin>>xy[i].ss;
    
    map<int,int>mn,mx;
    mn[ax]=mx[ax]=ay;
    mn[bx]=mx[bx]=by;
    for(int i=0;i<=n;++i){
        dp[i][0]=dp[i][1]=0;
    }

    for(int i=0;i<n;++i){
        mx[xy[i].ff]=max(mx[xy[i].ff], xy[i].ss);
        if(!mn.count(xy[i].ff)) mn[xy[i].ff]=xy[i].ss;
        else mn[xy[i].ff]=min(mn[xy[i].ff], xy[i].ss);
    }

    int cur=ax;
    int ind=0;
    for(auto m:mx){
        if(m.ff==ax) {
            dp[0][0]=dp[0][1]=0;
            continue;
        }

        int partadir=(m.ff-cur)+(mx[m.ff]-mn[m.ff]);
        ++ind;
        dp[ind][0] = min(dp[ind-1][0] + abs(mn[m.ff]-mx[cur]), dp[ind-1][1] + abs(mn[m.ff]-mn[cur])) + partadir;
        dp[ind][1] = min(dp[ind-1][0] + abs(mx[m.ff]-mx[cur]), dp[ind-1][1] + abs(mx[m.ff]-mn[cur])) + partadir;
        cur=m.ff;
    }


    cout<<dp[ind][0]<<'\n';

}

int main()
{ // int32_t

    // setIO("fenceplan");
    FastIO();

    // setPrecision(1);

    int test_case = 1;
    cin >> test_case;

    while (test_case--)
    {
        solve();
    }

    return 0;
}
