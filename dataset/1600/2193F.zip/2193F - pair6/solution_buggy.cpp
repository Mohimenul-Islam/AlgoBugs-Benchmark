#include <bits/stdc++.h>
#include <iostream>
using namespace std;
#define ll long long int 
#define f(n)for(int i=0;i<n;i++)
#define asc(v) sort(v.begin(),v.end())
#define desc(v) sort(v.begin(),v.end(),greater<ll>())
#define rev(v) reverse((v.begin(),v.end()))
#define all(v) v.begin(),v.end()
#define lb(v,val) lower_bound(v.begin(),v.end(),val)
#define ub(v,val) upper_bound(v.begin(),v.end(),val)
#define vec vector<long long int>
#define pb push_back
#define tp tuple<ll,ll,ll>
#define pr pair<ll,ll>
#define yes cout << "YES" << endl
#define no cout << "NO" << endl
#define nx cout<<endl;
#define sp " "
#define bcnt(x) __builtin_popcountll(x) // Number of set bits int
#define bctz(x) __builtin_ctzll(x) // Ct of trailing zeros in binary
#define bclz(x) __builtin_clzll(x) // Ct of leading zeros in binary -> msb = (31-bclz(x))
#define mll map<ll,ll>
#define fr(l,r) for(ll i=l;i<=r;i++)
const ll mod = 1e9+7;
ll gcd(ll  a, ll b){
    if (b == 0)
        return a;
    return gcd(b, a % b);
}
ll lcm( ll a, ll b){
    return (a*b)/gcd(a,b);
}
// multiplication
ll mul(ll a, ll b) {
    return ( (a % mod) * (b % mod) ) % mod;
}

// binary exponentiation
ll binexp(ll a, ll b) {
    ll res = 1;
    a %= mod;
    while (b) {
        if (b & 1) res = mul(res, a);
        a = mul(a, a);
        b >>= 1;
    }
    return res;
}

// modular inverse (mod must be prime)
ll inv(ll a) {
    return binexp(a, mod - 2);
}

// division (a / b mod m)
ll divide(ll a, ll b) {
    return mul(a, inv(b));
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin >> t;
    while (t--) {
        ll n,a,b,c,d;
        cin>>n>>a>>b>>c>>d;
      map<ll,vec>mp;
      vec x;
      f(n){ll val;cin>>val;x.pb(val);}
      f(n){
        ll y;
        cin>>y;
        mp[x[i]].pb(y);
      }
      map<ll,pr>mpp;
     for (auto &it : mp) {
    auto &v = it.second;
    sort(v.begin(), v.end());
    mpp[it.first] = {v[0], v.back()};
}
mpp[c]={d,d};
ll ans=c-a;
ll v1=b,v2=b,t1=0,t2=0;
for(auto it:mpp){
    ans+=it.second.second-it.second.first;
    t2=min(t1+abs(v1-it.second.first),t2+abs(v2-it.second.first));
    t1=min(t1+abs(v1-it.second.second),t2+abs(v2-it.second.second));
    v1=it.second.first;
    v2=it.second.second;

}
cout<<ans+min(t1,t2)<<endl;



    }}