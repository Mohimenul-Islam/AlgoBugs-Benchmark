#include <bits/stdc++.h>
using namespace std;

map<pair<int,int>, long long> dp;

long long solve(int i, int x, int y, vector<int> &a, map<int, set<int>> &mp)
{
    if (i >= (int)a.size())
        return 0;

    if (dp.count({i, y})) return dp[{i, y}];

    set<int> &c = mp[a[i]];

    long long niche_y = *c.begin();
    long long upper_y = *c.rbegin();

    long long dx = llabs((long long)a[i] - x);

    long long takeup_y = dx 
        + llabs((long long)y - niche_y) 
        + llabs(upper_y - niche_y)
        + solve(i + 1, a[i], upper_y, a, mp);

    long long takedown_y = dx 
        + llabs((long long)y - upper_y) 
        + llabs(upper_y - niche_y)
        + solve(i + 1, a[i], niche_y, a, mp);

    return dp[{i, y}] = min(takeup_y, takedown_y);
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);

    int t;
    cin >> t;
    while (t--)
    {
        int n, ax, ay, bx, by;
        cin >> n >> ax >> ay >> bx >> by;

        vector<int> a(n + 2), b(n + 2);

        for (int i = 1; i <= n; i++)
            cin >> a[i];

        for (int i = 1; i <= n; i++)
            cin >> b[i];

        a[0] = ax;
        a[n + 1] = bx;
        b[0] = ay;
        b[n + 1] = by;

        map<int, set<int>> mp;
        for (int i = 0; i < n + 2; i++)
            mp[a[i]].insert(b[i]);

        sort(a.begin(), a.end());
        a.erase(unique(a.begin(), a.end()), a.end());

        dp.clear();

        long long ans = solve(1, ax, ay, a, mp);

        cout << ans << "\n";
    }
}