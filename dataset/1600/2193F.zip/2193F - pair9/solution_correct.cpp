#include <bits/stdc++.h>
using namespace std;
#define int long long
#define fi first
#define se second
#define pb push_back

int n, ax, ay, bx, by;
int x[200005];
int tmp;

void sol(){
    cin >> n >> ax >> ay >> bx >> by;

    set<int> st;
    for(int i=1;i<=n;i++) cin >> x[i], st.insert(x[i]);
    
    int k=st.size();
    vector<pair<int,int>> layer(k+5, {-1e18,1e18});
    layer[0]={ay,ay};
    layer[k+1]={by,by};

    map<int,int> mp;
    int ite=1;
    for(int el : st) mp[el]=ite++;

    for(int i=1;i<=n;i++){
        cin >> tmp;

        layer[mp[x[i]]].fi=max(layer[mp[x[i]]].fi, tmp);
        layer[mp[x[i]]].se=min(layer[mp[x[i]]].se, tmp);
    }

    int dp[2][2];
    dp[0][0]=0;
    dp[0][1]=0;

    for(int i=1;i<=k+1;i++){
        dp[i%2][0]=min(dp[(i+1)%2][0]+abs(layer[i-1].fi-layer[i].se), dp[(i+1)%2][1]+abs(layer[i-1].se-layer[i].se)) + layer[i].fi-layer[i].se;
        dp[i%2][1]=min(dp[(i+1)%2][0]+abs(layer[i-1].fi-layer[i].fi), dp[(i+1)%2][1]+abs(layer[i-1].se-layer[i].fi)) + layer[i].fi-layer[i].se;

        dp[(i+1)%2][0]=dp[i%2][0];
        dp[(i+1)%2][1]=dp[i%2][1];
    }

    cout << min(dp[(k+1)%2][0], dp[(k+1)%2][1]) + bx-ax << '\n';
}

signed main(){
    ios_base::sync_with_stdio(false); cin.tie(nullptr);

    int tc=1;
    cin >> tc;
    while(tc--) sol();
}