#include <bits/stdc++.h>
using namespace std;
vector<long long> dp[3];
vector<pair<int, int>> vp;

void solve() {
  int n, ax, ay, bx, by;
  cin >> n >> ax >> ay >> bx >> by;
  [&] {
    map<int, pair<int, int>> mp;
    vector<int> v(n + 3);
    for(int i = 1; i <= n; i++) {
      cin >> v[i];
      mp[v[i]] = {INT_MAX, INT_MIN};
    }
    for(int i = 1, y, y1, y2; i <= n; i++) {
      cin >> y;
      y1 = min(y, mp[v[i]].first), y2 = max(y, mp[v[i]].second);
      mp[v[i]] = {y1, y2};
    }
    n = mp.size();
    dp[0] = dp[1] = vector<long long>(n + 3);
    vp = vector<pair<int, int>>({{0, 0}});
    for(pair<int, pair<int, int>> pp: mp) {
      pair<int, int> p = pp.second;
      vp.push_back(p);
      int id = vp.size() - 1, d = p.second - p.first;
      dp[0][id] = dp[1][id] = d;
    }
  }();
  dp[0][1] += 1LL * abs(ay - vp[1].second), dp[1][1] += 1LL * abs(ay - vp[1].first);
  for(int i = 2, l, r; i <= n; i++) {
    l = vp[i].first, r = vp[i].second;
    dp[0][i] += 1LL * min(dp[0][i - 1] + abs(r - vp[i - 1].first), dp[1][i - 1] + abs(r - vp[i - 1].second));
    dp[1][i] += 1LL * min(dp[0][i - 1] + abs(l - vp[i - 1].first), dp[1][i - 1] + abs(l - vp[i - 1].second));
  }
  dp[0][n] += 1LL * abs(vp[n].first - by), dp[1][n] += 1LL * abs(vp[n].second - by);
  cout << min(dp[0][n], dp[1][n]) + 1LL * (bx - ax) << '\n';
}

signed main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0); cout.tie(0);
  int _;
  cin >> _;
  for(int i = 1; i <= _; i++) {
    solve();
  }
  return 0;
}