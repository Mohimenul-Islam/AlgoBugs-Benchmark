#include <bits/stdc++.h>
using namespace std;
/* (˶˃ ᵕ ˂˶) */

long long solve() {
    pair<int,int> A,B;
    int n;
    cin >> n >> A.first >> A.second >> B.first >> B.second;
    vector<pair<int,int>> N(n);
    map<int,int> H, L;
    for(int i = 0; i < n; i++) cin>>N[i].first;
    for(int i = 0; i < n; i++) {
        cin>>N[i].second;
        H[N[i].first] = max(H[N[i].first], N[i].second);
        if(!L.count(N[i].first)) L[N[i].first] = N[i].second;
        else L[N[i].first] = min(L[N[i].first], N[i].second);
    }
    vector<vector<int>> dp(2,vector<int>(n+2,0));
    L[A.first] = H[A.first] = A.second;
    L[B.first] = H[B.first] = B.second;

    int cnt = 0, last = A.first; // compression ucun
    for(auto p : H) {
        int i = p.first;
        if(i == A.first) {
            dp[0][0] = dp[1][0] = 0;
            continue;
        }
        cnt++;
        dp[0][cnt] = min(dp[0][cnt - 1] + abs(H[i] - L[last]), dp[1][cnt - 1] + abs(H[i] - H[last])) + abs(H[i] - L[i]) + abs(i-last);
        dp[1][cnt] = min(dp[0][cnt - 1] + abs(L[i] - L[last]), dp[1][cnt - 1] + abs(L[i] - H[last])) + abs(H[i] - L[i]) + abs(i-last);
        last = i;
    }
    return dp[0][cnt];
}

int main() {
    cin.tie(0)->sync_with_stdio(0);
    int T;
    cin >> T;
    while(T--) {
        cout<<solve()<<"\n";
    }
}