#pragma GCC optimize("O3,unroll-loops")
#include <bits/stdc++.h>
using namespace std;

#define ll long long

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int t;
    cin >> t;
    while(t--){
        int n;
        ll Ax, Ay, Bx, By;
        cin >> n >> Ax >> Ay >> Bx >> By;

        vector<ll> x(n), y(n);
        for(int i = 0; i < n; i++) cin >> x[i];
        for(int i = 0; i < n; i++) cin >> y[i];

        vector<pair<ll,ll>> v(n);
        for(int i = 0; i < n; i++) v[i] = {x[i], y[i]};

        sort(v.begin(), v.end());

        vector<pair<ll,ll>> a;
        vector<ll> xs;

        for(int i = 0; i < n; i++){
            ll mn = v[i].second, mx = v[i].second;
            ll curx = v[i].first;
            int j = i;
            while(j < n && v[j].first == curx){
                mn = min(mn, v[j].second);
                mx = max(mx, v[j].second);
                j++;
            }
            a.push_back({mn, mx});
            xs.push_back(curx);
            i = j - 1;
        }

        int m = a.size();

        vector<vector<ll>> dp(m, vector<ll>(2, 0));

        ll c = abs(Ax - xs[0]);

        dp[0][0] = abs(Ay - a[0].second) + (a[0].second - a[0].first);
        dp[0][1] = abs(Ay - a[0].first) + (a[0].second - a[0].first);

        for(int i = 1; i < m; i++){
            c += abs(xs[i] - xs[i-1]);

            ll mn = a[i].first, mx = a[i].second;
            ll dist = mx - mn;

            dp[i][0] = min(
                dp[i-1][0] + abs(a[i-1].first - mx) + dist,
                dp[i-1][1] + abs(a[i-1].second - mx) + dist
            );

            dp[i][1] = min(
                dp[i-1][0] + abs(a[i-1].first - mn) + dist,
                dp[i-1][1] + abs(a[i-1].second - mn) + dist
            );
        }

        ll res = min(
            dp[m-1][0] + abs(a[m-1].first - By),
            dp[m-1][1] + abs(a[m-1].second - By)
        );

        res += abs(xs[m-1] - Bx);

        cout << c + res << '\n';
    }
    return 0;
}