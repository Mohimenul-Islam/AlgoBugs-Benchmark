#pragma GCC optimize("O3,unroll-loops")
#include <bits/stdc++.h>
using namespace std;

#define ll long long

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int t; 
    cin >> t;
    while(t--){
        int n;
        ll Ax, Ay, Bx, By;
        cin >> n >> Ax >> Ay >> Bx >> By;

        vector<ll> x(n), y(n);
        for(int i = 0; i < n; i++) cin >> x[i];
        for(int i = 0; i < n; i++) cin >> y[i];

        map<ll, pair<ll,ll>> mp;
        for(int i = 0; i < n; i++){
            if(mp.count(x[i]) == 0) mp[x[i]] = {y[i], y[i]};
            else{
                mp[x[i]].first = min(mp[x[i]].first, y[i]);
                mp[x[i]].second = max(mp[x[i]].second, y[i]);
            }
        }

        vector<pair<ll,ll>> a;
        for(auto &it: mp) a.push_back({it.second.first, it.second.second});

        int m = a.size();

        vector<vector<ll>> dp(m, vector<ll>(2, 0));

        ll curx = Ax, c = 0;

        c += abs(curx - (mp.begin()->first));
        curx = mp.begin()->first;

        ll mn = a[0].first, mx = a[0].second;

        dp[0][0] = abs(Ay - mx) + (mx - mn);
        dp[0][1] = abs(Ay - mn) + (mx - mn);

        for(int i = 1; i < m; i++){
            auto it = mp.begin();
            advance(it, i);
            ll nx = it->first;

            c += abs(nx - curx);
            curx = nx;

            ll nmn = a[i].first, nmx = a[i].second;

            ll dist = nmx - nmn;

            dp[i][0] = min(
                dp[i-1][0] + abs(a[i-1].first - nmx) + dist,
                dp[i-1][1] + abs(a[i-1].second - nmx) + dist
            );

            dp[i][1] = min(
                dp[i-1][0] + abs(a[i-1].first - nmn) + dist,
                dp[i-1][1] + abs(a[i-1].second - nmn) + dist
            );
        }

        ll res = min(
            dp[m-1][0] + abs(a[m-1].first - By),
            dp[m-1][1] + abs(a[m-1].second - By)
        );

        res += abs(curx - Bx);

        cout << c + res << '\n';
    }
    return 0;
}