#include <bits/stdc++.h>
using namespace std;
#define int long long

signed main() {
    cin.tie(0)->sync_with_stdio(0);
    int t; cin >> t;
    while (t--) {
        int n; cin >> n;
        int ax,bx,ay,by;
        cin >> ax >> ay >> bx >> by;
        vector<int>x(n+5),y(n+5),dp[2];
        dp[0]=dp[1]=vector<int>(n+5,0);
        map<int,int>mx,mn;
        for (int i = 0; i < n; i++) {
            cin >> x[i] ;
        }
        for (int i = 0; i < n; i++) {
            cin >> y[i] ;
        }
        mn[ax]=mx[ax]=ay;
        mn[bx]=mx[bx]=by;
        for (int i = 0; i < n; i++) {
            mx[x[i]]=max(mx[x[i]],y[i]);
            if (!mn.count(x[i])) mn[x[i]] = y[i];
            else
                mn[x[i]] = min(mn[x[i]],y[i]);
        }
        int lst = ax ,cnt=0;
        for (auto i :mx) {
            if (i.first==ax ) {
                dp[0][0]=dp[1][0]=0;
                continue;
            }
            int need =(i.first-lst)+(mx[i.first]-mn[i.first]);
            cnt++;
            dp[0][cnt]=min(dp[0][cnt-1]+abs(mx[i.first]-mn[lst]),
                            dp[1][cnt-1]+abs(mx[i.first]-mx[lst])
                )+need;
            dp[1][cnt]=min(dp[0][cnt-1]+abs(mn[i.first]-mn[lst]),
                            dp[1][cnt-1]+abs(mn[i.first]-mx[lst])
                            )+need;
            lst=i.first;
        }
        cout<<dp[0][cnt]<<'\n';
    }
}