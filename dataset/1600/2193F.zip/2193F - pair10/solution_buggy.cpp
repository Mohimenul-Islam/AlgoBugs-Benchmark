#include <bits/stdc++.h>
using namespace std;
#define int long long
map<int,vector<int>>um;
int ax,ay,bx,by;
map<pair<int,int>,int>mp;
unordered_map<int,int>xx;
map<pair<int,int>,bool>vis;
int dp(int i,int x,int y) {
    if (x==bx && y==by) {
        return 0;
    }
    auto &res=mp[{x,y}];
    if (vis[{x,y}]) {
        return res;
    }
    vis[{x,y}]=1;

    int nxtx=xx[i];
    int lst=um[nxtx].size()-1;
    int y0=um[nxtx][0];
    int y1=um[nxtx][lst];
    int difx=abs(x-nxtx);
    res=min({
        difx+abs(y1-y)  +abs(y1-y0)+dp(i+1,nxtx,y0),
        difx+abs(y0-y)+abs(y1-y0)+dp(i+1,nxtx,y1)}
        );
    return res;
}

signed main() {
    cin.tie(0)->sync_with_stdio(0);
    int t; cin >> t;
    while (t--) {
        int n; cin >> n;
        cin >> ax >> ay >> bx >> by;
        um.clear();
        xx.clear();
        vis.clear();
        mp.clear();

        um[bx].push_back(by);
        vector<int> x(n),y(n);
        for (int i = 0; i < n; i++) {
            cin >> x[i] ;
        }
        for (int i = 0; i < n; i++) {
            cin >> y[i] ;
        }

        for (int i = 0; i < n; i++) {
            um[x[i]].push_back(y[i]);
        }

        sort(x.begin(),x.end());
        int j=0;
        for (int i = 0; i < n; i++) {
            if (i and x[i] == x[i-1])continue;
            xx[j]=x[i];
            ++j;
        }
        xx[j]=bx;
        for (int i = 0; i < n; i++) {
            sort(um[x[i]].begin(),um[x[i]].end());
        }
        cout << dp(0,ax,ay) <<'\n';
    }
}