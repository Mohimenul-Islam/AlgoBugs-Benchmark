#include <bits/stdc++.h>
using namespace std;


vector<pair<long long int,long long int>> deliver(vector<long long int>pos , long long int ay){
    sort(pos.begin(),pos.end());

    long long int l = 0;
    long long int n = pos.size();

    for(long long int i=1;i<pos.size();i++){
        l += (pos[i]-pos[i-1]);
    }

    vector<pair<long long int,long long int>> ret;

    ret.push_back({pos[0],l+abs(pos[n-1]-ay)});
    ret.push_back({pos[n-1],l+abs(pos[0]-ay)});

    return ret;
}

void solve(){

    long long int n,ax,ay,bx,by;
    cin>>n>>ax>>ay>>bx>>by;

    vector<pair<long long int,long long int>>cord(n);

    for(long long int i=0;i<n;i++){
        cin>>cord[i].first;
    }

    for(long long int i=0;i<n;i++){
        cin>>cord[i].second;
    }

    sort(cord.begin(),cord.end());

    map<long long int,vector<long long int>>ma;
    ma[cord[0].first] = {cord[0].second};

    for(long long int i=1;i<n;i++){
        if(cord[i].first==cord[i-1].first){
            ma[cord[i].first].push_back(cord[i].second);
        }else{
            ma[cord[i].first] = {cord[i].second};
        }
    }

    vector<pair<long long int,long long int>>v;
    vector<long long int>val;

    for(auto u : ma){
        sort(u.second.begin(),u.second.end());
        long long int x = u.second[0];
        long long int y = u.second[0];
        if(u.second.size()>1){
            y = u.second[u.second.size()-1];
        }
        v.push_back({x,y});
        val.push_back(u.first);
    }

    n = val.size();

    // for(long long int i=0;i<n;i++){
    //     cout<<val[i]<<endl;
    //     cout<<v[i].first<<" "<<v[i].second<<endl;
    // }

    // cout<<endl;

    long long int dp[n][2];

    dp[0][0] = val[0]-ax + abs(v[0].first-ay) + v[0].second-v[0].first;
    dp[0][1] = val[0]-ax + abs(v[0].second-ay)+v[0].second-v[0].first;

    // cout<<dp[0][0]<<" "<<dp[0][1]<<endl;

    for(long long int i=1;i<ma.size();i++){

        long long int lo = v[i].first;
        long long int hi = v[i].second;
        long long int loi = v[i-1].first;
        long long int hii = v[i-1].second;

        long long int consti = val[i]-val[i-1]+ hi-lo ;

        // cout<<consti<<endl;

        // cout<<"dp[i][0] =  consti + min ("<< dp[i-1][0] <<" + abs("<<lo<<"-"<<loi<<"), " <<dp[i-1][1] <<" + abs("<<lo<<"-"<<hii<<"));"<<endl;
        dp[i][0] = consti + min(dp[i-1][1] + abs(lo-loi), dp[i-1][0] + abs(lo-hii));
        // cout<<"dp[i][1] =  consti + min ("<< dp[i-1][0] <<" + abs("<<hi<<"-"<<hii<<"), " <<dp[i-1][1] <<" + abs("<<hi<<"-"<<hii<<"));"<<endl;
        dp[i][1] = consti + min(dp[i-1][1] + abs(hi-loi), dp[i-1][0] + abs(hi-hii));

        // cout<<dp[i][0]<<" "<<dp[i][1]<<endl;
    }

    long long ans = min(dp[n-1][0] + (bx - val[n-1]) + abs(by - v[n-1].second),
                    dp[n-1][1] + (bx - val[n-1]) + abs(by - v[n-1].first));

    cout<< ans<<endl;

}
int main(){

#ifndef ONLINE_JUDGE
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
#endif

    long long int t;
    cin>>t;
    while(t--){
        solve();
    }
}
