#include <bits/stdc++.h>
using namespace std;


vector<pair<int,int>> deliver(vector<int>pos , int ay){
    sort(pos.begin(),pos.end());

    int l = 0;
    int n = pos.size();

    for(int i=1;i<pos.size();i++){
        l += (pos[i]-pos[i-1]);
    }

    vector<pair<int,int>> ret;

    ret.push_back({pos[0],l+abs(pos[n-1]-ay)});
    ret.push_back({pos[n-1],l+abs(pos[0]-ay)});

    return ret;
}

void solve(){

    int n,ax,ay,bx,by;
    cin>>n>>ax>>ay>>bx>>by;

    vector<pair<int,int>>cord(n);

    for(int i=0;i<n;i++){
        cin>>cord[i].first;
    }

    for(int i=0;i<n;i++){
        cin>>cord[i].second;
    }

    sort(cord.begin(),cord.end());

    map<int,vector<int>>ma;
    ma[cord[0].first] = {cord[0].second};

    for(int i=1;i<n;i++){
        if(cord[i].first==cord[i-1].first){
            ma[cord[i].first].push_back(cord[i].second);
        }else{
            ma[cord[i].first] = {cord[i].second};
        }
    }

    vector<pair<int,int>>v;
    vector<int>val;

    for(auto u : ma){
        sort(u.second.begin(),u.second.end());
        int x = u.second[0];
        int y = u.second[0];
        if(u.second.size()>1){
            y = u.second[u.second.size()-1];
        }
        v.push_back({x,y});
        val.push_back(u.first);
    }

    n = val.size();

    // for(int i=0;i<n;i++){
    //     cout<<val[i]<<endl;
    //     cout<<v[i].first<<" "<<v[i].second<<endl;
    // }

    // cout<<endl;

    int dp[n][2];

    dp[0][0] = val[0]-ax + abs(v[0].first-ay) + v[0].second-v[0].first;
    dp[0][1] = val[0]-ax + abs(v[0].second-ay)+v[0].second-v[0].first;

    // cout<<dp[0][0]<<" "<<dp[0][1]<<endl;

    for(int i=1;i<ma.size();i++){

        int lo = v[i].first;
        int hi = v[i].second;
        int loi = v[i-1].first;
        int hii = v[i-1].second;

        int consti = val[i]-val[i-1]+ hi-lo ;

        // cout<<consti<<endl;

        // cout<<"dp[i][0] =  consti + min ("<< dp[i-1][0] <<" + abs("<<lo<<"-"<<loi<<"), " <<dp[i-1][1] <<" + abs("<<lo<<"-"<<hii<<"));"<<endl;
        dp[i][0] = consti + min(dp[i-1][1] + abs(lo-loi), dp[i-1][0] + abs(lo-hii));
        // cout<<"dp[i][1] =  consti + min ("<< dp[i-1][0] <<" + abs("<<hi<<"-"<<hii<<"), " <<dp[i-1][1] <<" + abs("<<hi<<"-"<<hii<<"));"<<endl;
        dp[i][1] = consti + min(dp[i-1][1] + abs(hi-loi), dp[i-1][0] + abs(hi-hii));

        // cout<<dp[i][0]<<" "<<dp[i][1]<<endl;
    }

    long long ans = min(dp[n-1][0] + (bx - val[n-1]) + abs(by - v[n-1].second),
                    dp[n-1][1] + (bx - val[n-1]) + abs(by - v[n-1].first));

    cout<< ans<<endl;

}
int main(){

#ifndef ONLINE_JUDGE
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
#endif

    int t;
    cin>>t;
    while(t--){
        solve();
    }
}
