#include <bits/stdc++.h>
using namespace std;
using ll = long long;
const int INF = 0x3f3f3f3f;
const ll LNF = 0x3f3f3f3f3f3f3f3f;


inline void solve() {
    int n, sx, sy, fx, fy; cin>>n>>sx>>sy>>fx>>fy;
    map<int, vector<int>> mp;
    mp[fx].push_back(fy);
    vector<int> xs(n+1), ys(n+1);
    for (int i=1; i<=n; i++) cin>>xs[i];
    for (int i=1; i<=n; i++) cin>>ys[i];
    for (int i=1; i<=n; i++) {
        int x = xs[i]; int y = ys[i];
        mp[x].push_back(y);
    }
    for (auto&[x, v]: mp) {
        sort(v.begin(), v.end());
    }
    ll res = 0;
    int lstx = sx, lsty = sy;
    int flag = 0; //0走左下 1走右下
    auto tit = mp.begin();
    auto[ytx, ytv] = *tit;
    int yy1 = ytv.front();
    int yy2 = ytv.back();
    if (abs(yy1-lsty) <= abs(yy2-lsty)) flag = 0;
    else flag = 1;
    auto it = mp.begin();
    for (auto&[x, v]: mp) {
        if (!flag) {
            for (int i=0; i<v.size(); i++) {
                int y = v[i];
                if (i == 0) {
                    res += abs(x-lstx) + abs(y-lsty);
                }
                else {
                    res += abs(y - v[i-1]);
                }
                if (i == v.size()-1) {
                    lstx = x;
                    lsty = y;
                }
            }
        }
        else {
            for (int i=v.size()-1; i>=0; i--) {
                int y = v[i];
                if (i == v.size() - 1) {
                    res += abs(x-lstx) + abs(y-lsty);
                }
                else {
                    res += abs(y - v[i+1]);
                }
                if (i == 0) {
                    lstx = x;
                    lsty = y;
                }
            }
        }
        //现在在lstx lsty

        auto t_it = it;
        t_it++;
        if (t_it == mp.end()) break;
        auto[tx, tv] = *t_it;
        int y1 = tv.front(), y2 = tv.back();
        if (abs(y1-lsty) <= abs(y2-lsty)) flag = 0;
        else flag = 1;
        it++;
    }
    cout<<res<<'\n';
}

int main() {
    ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);

    int T; cin>>T;
    while (T--) solve();

    return 0;
}