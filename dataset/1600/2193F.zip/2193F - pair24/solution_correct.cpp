#include <bits/stdc++.h>
using namespace std;
using ll = long long;
const int INF = 0x3f3f3f3f;
const ll LNF = 0x3f3f3f3f3f3f3f3f;

inline int _idx(int x, vector<int>& idxs) {
    return int(lower_bound(idxs.begin()+1, idxs.end(), x) - idxs.begin());
}

inline void solve() {
    int n, sx, sy, fx, fy; cin>>n>>sx>>sy>>fx>>fy;
    vector<int> xs(n+1), ys(n+1);
    vector<int> idxs = {-1, sx, fx};
    for (int i=1; i<=n; i++) {
        cin>>xs[i];
        idxs.push_back(xs[i]);
    }
    for (int i=1; i<=n; i++) cin>>ys[i];
    sort(idxs.begin()+1, idxs.end());
    idxs.erase(unique(idxs.begin()+1, idxs.end()), idxs.end());
    sx = _idx(sx, idxs);
    fx = _idx(fx, idxs);
    for (int i=1; i<=n; i++) xs[i] = _idx(xs[i], idxs);
    int m = idxs.size() - 1;
    vector<vector<int>> arr(m+1);
    arr[sx].push_back(sy);
    arr[fx].push_back(fy);
    for (int i=1; i<=n; i++) {
        arr[xs[i]].push_back(ys[i]);
    }
    for (int i=1; i<=m; i++) sort(arr[i].begin(), arr[i].end());
    ll sum = 0;
    for (int i=1; i<=m; i++) {
        for (int j=0; j+1<arr[i].size(); j++) {
            sum += abs(arr[i][j]-arr[i][j+1]);
        }
    }
    vector<vector<vector<ll>>> dp(m+1, vector<vector<ll>>(2, vector<ll>(2, LNF)));
    dp[1][0][0] = dp[1][0][1] = dp[1][1][0] = dp[1][1][1] = 0;
    for (int i=2; i<=m; i++) {
        int prex = idxs[i-1];
        int prey0 = arr[i-1].front();
        int prey1 = arr[i-1].back();
        int x = idxs[i];
        int y0 = arr[i].front();
        int y1 = arr[i].back();
        dp[i][0][0] = min(dp[i-1][1][0], dp[i-1][1][1]) + abs(x-prex) + abs(y0-prey0);
        dp[i][0][1] = min(dp[i-1][0][0], dp[i-1][0][1]) + abs(x-prex) + abs(y0-prey1);
        dp[i][1][0] = min(dp[i-1][1][0], dp[i-1][1][1]) + abs(x-prex) + abs(y1-prey0);
        dp[i][1][1] = min(dp[i-1][0][0], dp[i-1][0][1]) + abs(x-prex) + abs(y1-prey1);
    }
    cout<<min(min(dp[m][0][0], dp[m][0][1]), min(dp[m][1][0], dp[m][1][1])) + sum<<'\n';
}

int main() {
    ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);

    int T; cin>>T;
    while (T--) solve();

    return 0;
}