#include <bits/stdc++.h>
 
#define F first
#define S second
#define int long long
 
using namespace std;
 
int t, n, ax, ay, bx, by;
 
signed main()
{
    cin >> t;
    
    while( t -- )
    {
        cin >> n >> ax >> ay >> bx >> by;
        vector <int> x(n + 5), y(n + 5), dp[2];
        
        dp[0] = dp[1] = vector <int> (n + 5, 0);
        map <int, int> mx, mn;
        
        mn[ax] = mx[ax] = ay;
        mn[bx] = mx[bx] = by;
        
        for( int i = 0; i < n; i ++ ) cin >> x[i];
        for( int i = 0; i < n; i ++ ) cin >> y[i];
        
        for( int i = 0; i < n; i ++ )
        {
            mx[x[i]] = max(mx[x[i]], y[i]);
            
            if(!mn.count(x[i])) mn[x[i]] = y[i];
            else mn[x[i]] = min(mn[x[i]], y[i]);
        }
        int lst = ax, cnt = 0;
        
        for( auto i : mx )
        {
            if( i.F == ax )
            {
                dp[0][0] = dp[1][0] = 0;
                continue;
            }
            int need = (i.F - lst) + (mx[i.F] - mn[i.F]);
            cnt ++;
            
            dp[0][cnt] = min(dp[0][cnt - 1] + abs(mx[i.F] - mn[lst]), dp[1][cnt - 1] + abs(mx[i.F] - mx[lst])) + need;
            dp[1][cnt] = min(dp[0][cnt - 1] + abs(mn[i.F] - mn[lst]), dp[1][cnt - 1] + abs(mn[i.F] - mx[lst])) + need;
            
            lst = i.F;
        }
        cout << dp[0][cnt] << '\n';
    }
}