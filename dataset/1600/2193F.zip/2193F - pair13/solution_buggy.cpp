#include<bits/stdc++.h>
using namespace std;

using ll = long long;

struct pll {
    ll first = INT_MAX;
    ll second = INT_MIN;
};

void solve() {
    ll n, AX, AY, BX, BY;
    cin >> n >> AX >> AY >> BX >> BY;

    vector<ll> x(n);
    vector<ll> y(n);
    for (int i = 0; i < n; i++) {
        cin >> x[i];
    }
    for (int i = 0; i < n; i++) {
        cin >> y[i];
    }

    map<ll, pll> pos;
    for (int i = 0; i < n; i++) {
        pos[x[i]].first = min(pos[x[i]].first, y[i]);
        pos[x[i]].second = max(pos[x[i]].second, y[i]);
    }
    int m = pos.size();

    vector<vector<ll>> f(m, vector<ll>(2));
    ll d = pos[x[0]].second - pos[x[0]].first;
    f[0][0] = x[0] - AX + abs(pos[x[0]].first - AY) + d;
    f[0][1] = x[0] - AX + abs(pos[x[0]].second - AY) + d;

    // cout << x[0] - AX << ' ' << abs(pos[x[0]].first - AY) << ' ' << d << endl;

    int idx = 1;
    for (int i = 1; i < m; i++) {
        while (idx < n && x[idx] == x[idx - 1]) idx++;
        
        // cout << i << ' ' << x[idx] << endl;

        d = pos[x[idx]].second - pos[x[idx]].first;
        f[i][0] = min(
            f[i - 1][0] + abs(pos[x[idx]].first - pos[x[idx-1]].second) + x[idx] - x[idx-1],
            f[i - 1][1] + abs(pos[x[idx]].first - pos[x[idx-1]].first) + x[idx] - x[idx-1]
        ) + d; 

        f[i][1] = min(
            f[i - 1][0] + abs(pos[x[idx]].second - pos[x[idx-1]].second) + x[idx] - x[idx-1],
            f[i - 1][1] + abs(pos[x[idx]].second - pos[x[idx-1]].first) + x[idx] - x[idx-1]
        ) + d;
        idx++;
    }

    ll ans = min(
        f.back()[0] + abs(pos[x.back()].second - BY) + BX - x.back(),
        f.back()[1] + abs(pos[x.back()].first - BY) + BX - x.back()
    );

    // for (auto v : f) {
    //     cout << v[0] << ' ' << v[1] << endl;
    // }

    cout << ans << endl;
}

int main() {
    int t;
    cin >> t;
    while (t--) solve();
}