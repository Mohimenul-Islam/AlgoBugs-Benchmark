#include <bits/stdc++.h>
using namespace std;

using ll = long long;
#define all(v) (v).begin(), (v).end()

void solve() {
    ll n, ax, ay, bx, by;
    cin >> n >> ax >> ay >> bx >> by;
    vector<ll> x(n + 2), y(n + 2);
    x[0] = ax;
    x[n + 1] = bx;
    y[0] = ay;
    y[n + 1] = by;

    for (ll  i = 1; i <= n; i++) {
        cin >> x[i];
    }

   
    for (ll  i = 1; i <= n; i++) {
        cin >> y[i];
    }

map<ll, pair<ll, ll>> mp;

for (ll i = 0; i < x.size(); i++) {
    if (mp.count(x[i])) {
        ll val = min(mp[x[i]].first, y[i]);
        ll val2 = max({mp[x[i]].second, y[i]});
        mp[x[i]] = {val, val2};
    } else {
        mp[x[i]] = {y[i], y[i]};
    }
 }

 
  vector<pair<ll, ll>> vp;

  for (auto it: mp) {
    vp.push_back(it.second);
  }


  vector<vector<ll>> dp(vp.size() + 1, vector<ll>(2, -1));
  vector<vector<ll>> dp2(vp.size() + 1, vector<ll>(2, -1));


  auto cal = [&](auto&& self, ll currIdx, ll prevChoice) {
    if (currIdx == vp.size()) return 0LL;

    if (dp[currIdx][prevChoice] != -1) return dp[currIdx][prevChoice];
    
    ll maxi = abs(vp[currIdx].second - vp[currIdx - 1].second);
    ll mini = abs(vp[currIdx].first - vp[currIdx - 1].first);

   ll ans = LLONG_MAX;
   if (prevChoice == 1) {
        ans = maxi + self(self, currIdx + 1, 0);
   } else {
       ans = min(mini + self(self, currIdx + 1, 1), ans);
   }
   
   return dp[currIdx][prevChoice] = ans;

  };


  ll val = (cal(cal, 1, 0));
  dp = dp2;

  ll val2  = cal(cal, 1, 1);
  long long ans = 0;
  for (int i = 1; i < vp.size() - 1; i++) {
    ans += (vp[i].second - vp[i].first);
  }
  //cerr << "val " << val  << " ans " << ans << '\n';

  cout << ans + bx - ax + min(val, val2) << '\n'; 
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--) {
        solve();
    }

    return 0;
}