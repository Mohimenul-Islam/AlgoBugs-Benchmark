#include <bits/stdc++.h>
using namespace std;
#define FIO ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
typedef long long int ll;
const ll MOD = 1000000007;

void sieve(){
    ll n;
    vector<bool> is_prime(n+1, true);
    is_prime[0] = is_prime[1] = false;
    for (ll i = 2; i <= n; i++) {
        if (is_prime[i] && (long long)i * i <= n) {
            for (ll j = i * i; j <= n; j += i)
                is_prime[j] = false;
        }
    }
}

ll binpow(ll a,ll b,ll m){
    a%=m;
    ll res=1;
    while(b>0){
        if(b&1) res=res*a%m;
        a=a*a%m;
        b>>=1;
    }
    return res;
}

ll gcd(ll a,ll b){
    while(b){
        a%=b;
        swap(a,b);
    }
    return a;
}

bool is_perfect_square(ll x){
    ll l=1,r=1e9;
    while(l<=r){
        ll m=l+((r-l)/2);
        if(m*m==x) return true;
        if(m*m>x) r=m-1;
        else l=m+1;
    }
    return false;
}


void solve(){
    ll n,ax,ay,bx,by;
    cin>>n>>ax>>ay>>bx>>by;
    vector<ll> v(n);
    for (int i=0;i<n;i++){
        cin>>v[i];
    }
    map<ll,ll> mn;
    map<ll,ll> mx;
    mn[ax]=ay;
    mx[ax]=ay;
    mn[bx]=by;
    mx[bx]=by;
    for (int i=0;i<n;i++){
        ll x;
        cin>>x;
        mx[v[i]]=max(mx[v[i]],x);
        if (!mn[v[i]]){
            mn[v[i]]=x;
        }
        else{
            mn[v[i]]=min(mn[v[i]],x);
        }
    }
    vector<ll> dpl(n+2);
    vector<ll> dph(n+2);
    dpl[0]=0;
    dph[0]=0;
    ll tmp=0;
    ll lst=ax;
    for (auto x:mx){
        if (x.first==ax){
            continue;
        }
        dph[tmp+1]=min(dph[tmp]+abs(mx[x.first]-mn[lst]),dpl[tmp]+abs(mx[x.first]-mx[lst]))+(x.first-lst)+(mx[x.first]-mn[x.first]);
        dpl[tmp+1]=min(dph[tmp]+abs(mn[x.first]-mn[lst]),dpl[tmp]+abs(mn[x.first]-mx[lst]))+(x.first-lst)+(mx[x.first]-mn[x.first]);
        lst=x.first;
        tmp++;
    }
    cout<<dph[tmp]<<'\n';
}

int main(){
    FIO;
    #ifdef CLOCK
        auto _clock_start = chrono::high_resolution_clock::now();
    #endif
    int t;
    cin>>t;
    while(t--){
        solve();
    }
    #ifdef CLOCK
        cerr << "Executed in " << chrono::duration_cast<chrono::milliseconds>(
        chrono::high_resolution_clock::now()
        - _clock_st art).count() << "ms." << endl;
    #endif
}