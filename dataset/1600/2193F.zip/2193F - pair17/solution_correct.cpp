#include<bits/stdc++.h>
using namespace std;

#define int long long 

signed main(){
	int t;cin>>t;
	while(t--){
		int n;cin>>n;
		int ax,ay,bx,by;
		cin>>ax>>ay>>bx>>by;
		vector<int>v(n);
		for(int i = 0;i < n;i++)cin>>v[i];
		map<int,pair<int,int>>mp;
		for(int i = 0;i < n;i++){
			int y;cin>>y;
			if(mp.find(v[i])==mp.end()){
				mp[v[i]].first = y;
				mp[v[i]].second = y;
			}
			else {
				mp[v[i]].first = min(mp[v[i]].first,y);
				mp[v[i]].second = max(mp[v[i]].second,y);
			}
		}

		// for(auto [key,val] : mp){
		// 	cout<<key<<" "<<val.first<<" "<<val.second<<endl;
		// }
		// return 0;
		auto it = mp.begin();

		vector<vector<int>>dp(n+1,vector<int>(2,0));
		dp[0][0] = abs(it->second.first-ay);
		dp[0][1] = abs(it->second.second-ay);

		int i = 1;
		int prevx = ax;
		int prev0 = it->second.first;
		int prev1 = it->second.second;

		// it++;

		while(it != mp.end()){
			int x = it->first;
			int d = it->second.first;
			int u = it->second.second;
			// cout<<x<<d<<u<<endl;
			dp[i][0] = x-prevx+min(dp[i-1][0]+(u-d)+abs(prev0-u),dp[i-1][1]+(u-d)+abs(prev1-u));
			dp[i][1] = x-prevx+min(dp[i-1][0]+(u-d)+abs(prev0-d),dp[i-1][1]+(u-d)+abs(prev1-d));
			i++;it++;
			prevx = x;
			prev0 = d,prev1 = u;
		}
// return 0;
		// for(int j = 0;j < i;j++){
		// 	cout<<dp[j][0]<<" "<<dp[j][1]<<endl;
		// }
		// return 0;

		cout<<min(dp[i-1][0]+bx-prevx+abs(prev0-by),dp[i-1][1]+bx-prevx+abs(prev1-by))<<endl;
	}
}