#include<iostream>
#include<vector>
#include<unordered_map>
#include<map>
#include<algorithm>
using namespace std;
#define ll long long
class node {
public:
	ll x;
	ll shang;
	ll xia;
};
bool cmp(node a, node b) {
	return (a.x) < (b.x);
}


int main() {
	ll t;
	cin >> t;
	while (t--) {
		ll n, a1, a2, b1, b2;
		cin >> n >> a1 >> a2 >> b1 >> b2;
		unordered_map<ll, node> M;
		ll i;
		vector<ll> V(n);
		for (i = 0; i < n; i++) {
			ll x;
			cin >> x;
			M[x].x = x;
			M[x].shang = LLONG_MAX;
			M[x].xia = LLONG_MIN;
			V[i] = x;
		}
		for (i = 0; i < n; i++) {
			ll y;
			cin >> y;
			ll num = V[i];
			if (M[num].shang == LLONG_MAX) {
				M[num].shang = y;
			}
			else {
				M[V[i]].shang = max(y, M[V[i]].shang);
			}
			if (M[num].xia == LLONG_MIN) {
				M[V[i]].xia = y;
			}
			else {
				M[V[i]].xia = min(y, M[V[i]].xia);
			}

			
		}
		vector<node> V1;
		for (auto it : M) {
			V1.push_back(it.second);
		}
		sort(V1.begin(), V1.end(), cmp);
		//dp[0][0] 代表到达第一个x坐标时的终止位置,0代表先到最低点,再到最高点,1则反之
		vector<vector<ll>> dp(V1.size(), vector<ll>(2, 0));
		for (i = 0; i < V1.size(); i++) {
			if (i == 0) {
				dp[0][0] = V1[0].shang - V1[0].xia + abs(V1[0].xia - a2);
				dp[0][1] = V1[0].shang - V1[0].xia + abs(V1[0].shang - a2);
			}
			else {
				ll j;
				ll num0 = V1[i - 1].shang;
				ll num1 = V1[i - 1].xia;
					//分情况,现在这一个要终点在上的时候
					//比较,前一个的终点是上跟是下的两种不同情况
					dp[i][0] = min(dp[i - 1][0] + abs(num0 - V1[i].xia) + V1[i].shang - V1[i].xia, dp[i - 1][1] + abs(num1 - V1[i].xia) + V1[i].shang - V1[i].xia);
					
					dp[i][1] = min(dp[i - 1][0] + abs(num0 - V1[i].shang) + V1[i].shang - V1[i].xia, dp[i - 1][1] + abs(num1 - V1[i].shang) + V1[i].shang - V1[i].xia);

			}
		}
		ll ans = min(dp[V1.size() - 1][0] + abs(V1[V1.size() - 1].shang - b2), dp[V1.size() - 1][1] + abs(V1[V1.size() - 1].xia - b2));
		//cout << "ans = " << ans << endl;
		ll dis = 0;
		for (i = 1; i < V1.size(); i++) {
			dis += (V1[i].x - V1[i - 1].x);
		}
		dis += V1[0].x - a1;
		dis += b1 - V1[V1.size() - 1].x;
		ans += dis;
		cout << ans << endl;




	}



	return 0;
}