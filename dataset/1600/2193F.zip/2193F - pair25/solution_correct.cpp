#include <bits/stdc++.h>
using namespace std;

long long t,n,ax,ay,bx,by;
long long x[200005],y[200005];
long long gmn[200005],gmx[200005];
long long id[200005];

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    if (fopen("thaynguubasau.inp", "r"))
    {
        freopen("thaynguubasau.inp", "r", stdin);
        freopen("thaynguusaubay.out", "w", stdout);
    }

    cin>>t;
    while(t--)
    {
        cin>>n>>ax>>ay>>bx>>by;

        for(int i=1;i<=n;i++) cin>>x[i];
        for(int i=1;i<=n;i++) cin>>y[i];

        for(int i=1;i<=n;i++) id[i]=i;

        sort(id+1,id+n+1,[](int a,int b){
            return x[a]<x[b];
        });

        long long m=0;

        for(int i=1;i<=n;i++)
        {
            long long mn=y[id[i]];
            long long mx=y[id[i]];
            int j=i;

            while(j<=n && x[id[j]]==x[id[i]])
            {
                mn=min(mn,y[id[j]]);
                mx=max(mx,y[id[j]]);
                j++;
            }

            m++;
            gmn[m]=mn;
            gmx[m]=mx;

            i=j-1;
        }

        long long f0=llabs(ay-gmx[1])+(gmx[1]-gmn[1]);
        long long f1=llabs(ay-gmn[1])+(gmx[1]-gmn[1]);

        long long pmn=gmn[1],pmx=gmx[1];

        for(int i=2;i<=m;i++)
        {
            long long mn=gmn[i],mx=gmx[i];

            long long g0=min(
                f0+llabs(pmn-mx)+(mx-mn),
                f1+llabs(pmx-mx)+(mx-mn)
            );

            long long g1=min(
                f0+llabs(pmn-mn)+(mx-mn),
                f1+llabs(pmx-mn)+(mx-mn)
            );

            f0=g0;
            f1=g1;

            pmn=mn;
            pmx=mx;
        }

        long long ans=min(
            f0+llabs(pmn-by),
            f1+llabs(pmx-by)
        );

        ans+=bx-ax;

        cout<<ans<<"\n";
    }
}