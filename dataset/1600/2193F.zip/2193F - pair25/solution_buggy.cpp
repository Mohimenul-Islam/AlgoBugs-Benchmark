#include <bits/stdc++.h>
using namespace std;

long long t,n,ax,ay,bx,by;
long long x[200005],y[200005];
long long gmn[200005],gmx[200005];
bool used[200005];

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    if (fopen("thaynguubasau.inp", "r"))
    {
        freopen("thaynguubasau.inp", "r", stdin);
        freopen("thaynguusaubay.out", "w", stdout);
    }

    cin>>t;
    while(t--)
    {
        cin>>n>>ax>>ay>>bx>>by;

        for(int i=1;i<=n;i++) cin>>x[i];
        for(int i=1;i<=n;i++) cin>>y[i];

        for(int i=ax;i<=bx;i++)
        {
            gmn[i]=1e18;
            gmx[i]=-1e18;
            used[i]=0;
        }

        for(int i=1;i<=n;i++)
        {
            used[x[i]]=1;
            gmn[x[i]]=min(gmn[x[i]],y[i]);
            gmx[x[i]]=max(gmx[x[i]],y[i]);
        }

        long long f0=0,f1=0;
        long long pmn=ay,pmx=ay;
        bool first=1;

        for(int i=ax;i<=bx;i++)
        {
            if(!used[i]) continue;

            long long mn=gmn[i],mx=gmx[i];

            if(first)
            {
                f0=llabs(ay-mx)+(mx-mn);
                f1=llabs(ay-mn)+(mx-mn);
                first=0;
            }
            else
            {
                long long g0=min(
                    f0+llabs(pmn-mx)+(mx-mn),
                    f1+llabs(pmx-mx)+(mx-mn)
                );

                long long g1=min(
                    f0+llabs(pmn-mn)+(mx-mn),
                    f1+llabs(pmx-mn)+(mx-mn)
                );

                f0=g0;
                f1=g1;
            }

            pmn=mn;
            pmx=mx;
        }

        long long ans=min(
            f0+llabs(pmn-by),
            f1+llabs(pmx-by)
        );

        ans+=bx-ax;

        cout<<ans<<"\n";
    }
}