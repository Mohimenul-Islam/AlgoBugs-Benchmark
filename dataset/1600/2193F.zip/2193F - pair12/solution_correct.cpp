#include<bits/stdc++.h>
using namespace std;
#define pii pair<int,int>
#define piii pair<pair<int,int>,int>
#define vvi vector<vector<int>>
#define lowbit(x) ((x)&-(x))
#define int long long
int mod=998244353;
int ksm(int a,int b);
void solve(){
    int n; cin >> n;
    int x1, y1, x2, y2; cin >> x1 >> y1 >> x2 >> y2;
    map<int, vector<int>> mp;
    vector<int> a(n + 1);
    for(int i = 1; i <= n; i++) cin >> a[i];
    for(int i = 1; i <= n; i++) {
        int y; cin >> y;
        mp[a[i]].push_back(y);
    }

    // 统计有多少个不同的x坐标
    int m = mp.size();
    vector<vector<int>> dp(m + 1, vector<int>(2, 1e18));

    for(auto &[x, y] : mp) sort(y.begin(), y.end());

    // 初始状态：从 (x1, y1) 出发
    int prev_l = y1, prev_r = y1;
    dp[0][0] = dp[0][1] = 0;

    int i = 1;
    for(auto const& [x, y] : mp) {
        int ll = y[0];
        int rr = y.back();
        int len = rr - ll;

        // dp[i][0] 表示走完这层并停在 ll
        dp[i][0] = min(dp[i-1][0] + abs(prev_l - rr) + len, 
                       dp[i-1][1] + abs(prev_r - rr) + len);
        
        // dp[i][1] 表示走完这层并停在 rr
        dp[i][1] = min(dp[i-1][0] + abs(prev_l - ll) + len, 
                       dp[i-1][1] + abs(prev_r - ll) + len);

        prev_l = ll;
        prev_r = rr;
        i++;
    }

    // 最后加上水平总距离和到终点的垂直距离
    int horizontal = abs(x2 - x1);
    int res = min(dp[m][0] + abs(prev_l - y2), dp[m][1] + abs(prev_r - y2));
    cout << res + horizontal ;
}
signed main(){
    ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
    int _=1; cin>>_;
    while(_--){
        solve();
        if(_) cout<<"\n";
    }
    return 0;
}
int ksm(int a,int b){
    int res=1;
    a%=mod;
    while(b){
        if(b&1) res=(a*res)%mod;
        b>>=1;
        a=(a*a)%mod;
    }
    return res%mod;
}
