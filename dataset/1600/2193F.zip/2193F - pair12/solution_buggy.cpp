#include<bits/stdc++.h>
using namespace std;
#define pii pair<int,int>
#define piii pair<pair<int,int>,int>
#define vvi vector<vector<int>>
#define lowbit(x) ((x)&-(x))
#define int long long
int mod=998244353;
int ksm(int a,int b);
void solve(){
    int n;cin>>n;
    int x1,x2,y1,y2;cin>>x1>>y1>>x2>>y2;
    map<int,vector<int>>mp;
    int ans=0;
    vvi dp(n+1,vector<int>(2,1e18));
    vector<int>a(1);
    for(int i=1;i<=n;i++){
        int x;
        cin>>x;
        a.push_back(x);
    }
    for(int i=1;i<=n;i++){
        int y;cin>>y;
        mp[a[i]].push_back(y);
    }
    ans=x2-x1;

    int l=y1,r=y1;
    for(auto &[x,y]:mp){
        sort(y.begin(),y.end());
    }
    int i=1;
    dp[0][0]=dp[0][1]=0;
    for(auto &[x,y]:mp){
        int ll =y[0];
        int rr=y.back();
        int len=rr-ll;

        dp[i][0]=min(dp[i][0],dp[i-1][0]+len+abs(ll-r));
        dp[i][0]=min(dp[i][0],dp[i-1][1]+len+abs(rr-r));
        dp[i][1]=min(dp[i][1],dp[i-1][0]+abs(l-ll)+len);
        dp[i][1]=min(dp[i][1],dp[i-1][1]+abs(r-ll)+len);
        l=ll;
        r=rr;i++;
    }
    cout<<ans+min(dp[mp.size()][0]+abs(l-y2),dp[mp.size()][1]+abs(r-y2));
    return ;
}
signed main(){
    ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
    int _=1; cin>>_;
    while(_--){
        solve();
        if(_) cout<<"\n";
    }
    return 0;
}
int ksm(int a,int b){
    int res=1;
    a%=mod;
    while(b){
        if(b&1) res=(a*res)%mod;
        b>>=1;
        a=(a*a)%mod;
    }
    return res%mod;
}
