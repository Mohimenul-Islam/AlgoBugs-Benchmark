﻿#define _CRT_SECURE_NO_WARNINGS
#include <numeric>
#include <functional>
#include <iostream>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <string>
#include <sstream>
#include <fstream>
#include <cstring>
#include <array>
#include <bitset>
#include <cmath>
#include <memory>
#include <optional>
#include <ranges>
#include <bit>
#include <iomanip>

using namespace std;

long long gcd(long long a, long long b) {
  while (b) {
    a %= b;
    swap(a, b);
  }
  return a;
}

long long lcm(long long  a, long long  b) {
  return a * b / gcd(a, b);
}

const double pi = 3.14159265358979323846;

const int MOD = 1000'000'007;
//const int MOD = 998244353;
//const int MOD = 1000'000'009;

long long bin_power_mod(long long a, long long n) {
  long long res = 1;
  while (n) {
    if (n & 1) {
      res *= a;
      res %= MOD;
    }
    a *= a;
    a %= MOD;
    n >>= 1;
  }
  return res;
}

long long bin_power(long long a, long long n) {
  long long res = 1;
  while (n) {
    if (n & 1) {
      res *= a;
    }
    a *= a;
    n >>= 1;
  }
  return res;
}

int count_bits(int a) {
  int res = 0;
  while (a) {
    res++;
    a >>= 1;
  }
  return res;
}

long long inverse(long long a) {
  return bin_power_mod(a, MOD - 2);
}

string ans[] = { "NO", "YES" };

long long mem[30][30] = { 0 };

long long C(int n, int k) {
  if (k < 0 || k > n) return 0;
  if (k == 0 || k == n) return 1;
  if (k > n / 2) k = n - k;

  if (!mem[n][k]) {
    mem[n][k] = C(n - 1, k - 1) + C(n - 1, k);
  }

  return mem[n][k];
}

void solve() {
  int n; cin >> n;
  map<int, pair<int, int>> m;

  int prevx, prevy;
  cin >> prevx >> prevy;
  int prevMiY = prevy, prevMaY = prevy;

  int bx, by;  cin >> bx >> by;
  m[bx] = { by, by };

  vector<int> x(n), y(n);
  for (auto& el : x) cin >> el;
  for (auto& el : y) cin >> el;
  for (int i = 0; i < n; ++i) {
    if (!m.contains(x[i])) {
      m[x[i]] = { y[i], y[i] };
    }
    else {
      m[x[i]].first = min(m[x[i]].first, y[i]);
      m[x[i]].second = max(m[x[i]].second, y[i]);
    }
  }

  int prevA = 0, prevB = 0;
  int totY = 0, totX = m.rbegin()->first - prevx;
  for (const auto& [x, y] : m) {
    totY += y.second - y.first;

    int curA = min(
      prevA + abs(prevMiY - y.second),
      prevB + abs(prevMaY - y.second)
    );
    int curB = min(
      prevA + abs(prevMiY - y.first),
      prevB + abs(prevMaY - y.first)
    );

    prevA = curA;
    prevB = curB;
    prevMiY = y.first;
    prevMaY = y.second;
  }
  cout << min(prevA, prevB) + totX + totY << '\n';
}

int main() {
  ios::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  int t; cin >> t;
  while (t--) {
    solve();
  }
  return 0;
}