#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
using namespace std;
int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int t;
	cin >> t;
	while (--t >= 0)
	{
		int n, ay, ax, by, bx;
		cin >> n >> ax >> ay >> bx >> by;
		map<int, pair<int, int>> pos;
		vector<int> x(n), y(n);
		for (int i = 0; i < n; ++i)
			cin >> x[i];
		for (int i = 0; i < n; ++i)
			cin >> y[i];
		for (int i = 0; i < n; ++i)
		{
			if (pos.find(x[i]) == pos.end())
			{
				pos[x[i]] = {y[i], y[i]};
			}
			else
			{
				pos[x[i]].first = min(y[i], pos[x[i]].first);
				pos[x[i]].second = max(y[i], pos[x[i]].second);
			}
		}
		vector<pair<long long, long long>> dp(pos.size());
		dp[0].first = abs(ay - pos.begin()->second.second) + pos.begin()->second.second - pos.begin()->second.first;
		dp[0].second = abs(ay - pos.begin()->second.first) + pos.begin()->second.second - pos.begin()->second.first;
		for (int i = 1; pos.size() > 1; ++i)
		{
			auto next = ++pos.begin();
			dp[i].first = min(abs(next->second.second - pos.begin()->second.second) + next->second.second - next->second.first + dp[i - 1].second, abs(next->second.second - pos.begin()->second.first) + next->second.second - next->second.first + dp[i - 1].first);
			dp[i].second = min(abs(next->second.first - pos.begin()->second.first) + next->second.second - next->second.first + dp[i - 1].first, abs(next->second.first - pos.begin()->second.second) + next->second.second - next->second.first + dp[i - 1].second);
			pos.erase(pos.begin());
		}

		cout << bx - ax + min(abs(by - pos.begin()->second.first) + dp[dp.size() - 1].first, abs(by - pos.begin()->second.second) + dp[dp.size() - 1].second) << '\n';
	}
}