#include <bits/stdc++.h>
using namespace std;

using ll = int_fast64_t;
using ld = long double;
#define sz(s) (int)(s.size())
#define int ll

int dx[] = {0, 0, 1, -1, 1, 1, -1, -1};
int dy[] = {1, -1, 0, 0, 1, -1, 1, -1};

void testCase() {
    int n; cin >> n;
    int x1, y1, x2, y2; cin >> x1 >> y1 >> x2 >> y2;
    vector<int>x(n), y(n), id(n);
    for (int&xx:x) cin >> xx;
    for (int&xx:y) cin >> xx;
    iota(id.begin(), id.end(), 0);
    sort(id.begin(), id.end(), [&](int a, int b) {
        if (x[a] != x[b]) return x[a] < x[b];
        return y[a] < y[b];
    });
    vector<vector<int>>ys;
    int base = x2 - x1;
    for (int i = 0; i < n; i++) {
        if (i == 0 || x[id[i]] != x[id[i - 1]]) ys.emplace_back();
        if (!ys.back().empty()) base += llabs(y[id[i]] - ys.back().back());
        ys.back().emplace_back(y[id[i]]);
    }
    int xs = sz(ys);
    vector<vector<int>>dp(xs, vector<int>(2));
    dp[0][0] = llabs(ys.front().back() - y1);
    dp[0][1] = llabs(ys.front().front() - y1);
    for (int i = 1; i < xs; i++) {
        dp[i][1] = min(
            dp[i - 1][0] + llabs(ys[i - 1].front() - ys[i].front()),
            dp[i - 1][1] + llabs(ys[i - 1].back() - ys[i].front())
            );
        dp[i][0] = min(
            dp[i - 1][0] + llabs(ys[i - 1].front() - ys[i].back()),
            dp[i - 1][1] + llabs(ys[i - 1].back() - ys[i].back())
            );
    }
    dp.back()[0] += llabs(ys.back().front() - y2);
    dp.back()[1] += llabs(ys.back().back() - y2);
    cout << min(dp.back().front(), dp.back().back()) + base << '\n';
}

signed main(int argc, char **argv) {
    cin.tie(0)->sync_with_stdio(0);
#ifdef LOCAL
    freopen(argv[1], "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    int t = 1;
    cin >> t;
    while (t--) testCase();
    return 0;
}