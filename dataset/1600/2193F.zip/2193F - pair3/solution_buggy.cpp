#include <bits/stdc++.h>
using namespace std;

using ll = int_fast64_t;
using ld = long double;
#define sz(s) (int)(s.size())
#define int ll

int dx[] = {0, 0, 1, -1, 1, 1, -1, -1};
int dy[] = {1, -1, 0, 0, 1, -1, 1, -1};

void testCase() {
    int n; cin >> n;
    int x1, y1, x2, y2; cin >> x1 >> y1 >> x2 >> y2;
    vector<int>x(n), y(n), id(n);
    for (int&xx:x) cin >> xx;
    for (int&xx:y) cin >> xx;
    iota(id.begin(), id.end(), 0);
    sort(id.begin(), id.end(), [&](int a, int b) {
        if (x[a] != x[b]) return x[a] < x[b];
        return y[a] < y[b];
    });
    vector<vector<int>>ys;
    for (int i = 0; i < n; i++) {
        if (i == 0 || x[id[i]] != x[id[i - 1]]) ys.emplace_back();
        ys.back().emplace_back(y[id[i]]);
    }
    int xs = sz(ys);
    vector<vector<int>>prf(xs);
    for (int i = 0; i < xs; i++) {
        prf[i].assign(sz(ys[i]) + 1, 0);
        for (int j = 2; j <= sz(ys[i]); j++) {
            prf[i][j] = prf[i][j - 1] + llabs(ys[i][j - 1] - ys[i][j - 2]);
        }
    }
    auto best = [&](int yy, int idd) -> int {
        int ret = LLONG_MAX;
        auto it = upper_bound(ys[idd].begin(), ys[idd].end(), yy);
        if (it != ys[idd].end()) {
            int op = llabs(yy - *it);
            int idx = it - ys[idd].begin() + 1;
            op += prf[idd].back() - prf[idd][idx] + prf[idd].back();
            ret = min(ret, op);
        }
        if (it != ys[idd].begin()) {
            it = prev(it);
            int op = llabs(yy - *it);
            int idx = it - ys[idd].begin() + 1;
            op += prf[idd].back() - prf[idd][idx];
            ret = min(ret, op);
        }
        return ret;
    };
    vector<vector<int>>dp(xs, vector<int>(2));
    dp[xs - 1][0] = llabs(ys.back()[0] - y2) + prf.back().back();
    dp[xs - 1][1] = llabs(ys.back().back() - y2) + prf.back().back();
    for (int i = xs - 2; i >= 0; i--) {
        dp[i][0] = best(ys[i][0], i + 1) + dp[i + 1][0];
        dp[i][1] = best(ys[i][1], i + 1) + dp[i + 1][0];
        dp[i][0] = min(dp[i][0], dp[i + 1][1] + llabs(ys[i].front() - ys[i + 1].front()));
        dp[i][1] = min(dp[i][1], dp[i + 1][1] + llabs(ys[i].back() - ys[i + 1].front()));
        dp[i][0] += prf[i].back();
        dp[i][1] += prf[i].back();
    }
    dp[0][0] += best(y1, 0);
    cout << min(dp[0][0], dp[0][1] + llabs(y1 - ys[0][0])) + x2 - x1 << '\n';
}

signed main(int argc, char **argv) {
    cin.tie(0)->sync_with_stdio(0);
#ifdef LOCAL
    freopen(argv[1], "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    int t = 1;
    cin >> t;
    while (t--) testCase();
    return 0;
}