#include <bits/stdc++.h>
#define fi first
#define se second
using namespace std;

typedef long long ll;
typedef long double ld;

typedef pair<int,pair<int,int>> node;

const int maxn = 500000 + 100;
const ll mod = 676767677;
const ll inf = 1e9;

void minimize(ll &A, ll B){A = min(A, B);}
void maximize(ll &A, ll B){A = max(A, B);}

int c[100][100];

void solve(){

    int n,k;
    cin >> n>>k;




    int res = 1;

    for (int lg = 1; lg <= __lg(n) - 1; lg++) {
        for (int bitnum = 1; bitnum <= lg + 1; bitnum++) {
            int oper = bitnum + lg;
            if (oper <= k) res += c[lg][bitnum - 1];

        }
    }

    int z = n;

    int cnt = 0;

    while (z) {
        if (z & 1) z-=1;
        else z/=2;
        cnt++;
    }

    cout << n - res - (cnt <= k)<< "\n";


}


void check(){
    for (int i = 1; i <= 100; i++) {
        int z = i;

        int cnt = 0;

        while (z) {
            if (z & 1) z-=1;
            else z/=2;
            cnt++;
        }
        //cout<< i << " " << cnt << "\n";

        //cout << cnt - __builtin_popcount(i) - __lg(i) + 1 << "\n";

    }
}

int main(){
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);

    for (int i = 0; i <= 30;i++) {
        c[i][i] = 1;
        c[i][0] = 1;
    }

    for (int i = 1; i <= 30;i ++) {
        for (int k = 1; k <= i;k++) {
            c[i][k] = c[i-1][k] + c[i-1][k-1];
        }
    }



    int t; cin >> t;
    while (t--) {
        solve();
    }

    return 0;
}
