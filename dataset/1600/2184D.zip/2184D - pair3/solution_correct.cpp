#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define yes cout << "YES" << endl
#define no cout << "NO" << endl
#define pb push_back
#define F  first
#define S  second
#define pii pair<int, int>
#define pll pair<long long, long long>
#define vi  vector<int>
#define vvi vector<vector<int>>
#define vll  vector<ll>
#define vvll vector<vector<long long>>
#define SORT(v) sort(v.begin(),v.end())
#define RSORT(v) sort(v.rbegin(), v.rend())
#define read(a)  for (auto &it : a) cin >> it;
#define print(a)  for (auto i : a) cout << i << " "; cout << endl;
#define put(s) cout << s << endl;

ll xorFromZeroToN(ll n) {
    if (n % 4 == 0) return n;
    if (n % 4 == 1) return 1;
    if (n % 4 == 2) return n + 1;
    return 0;
}

ll fastExpo(ll a, ll b, ll m) {
    ll result = 1;
    a %= m;
    while (b > 0) {
        if (b & 1)
            result = (result * a) % m;
        a = (a * a) % m;
        b >>= 1;
    }
    return result;
}

ll gcd(ll a, ll b) {
    while (b != 0) {
        ll temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

ll lcm(ll a, ll b) {
    return (a / gcd(a, b)) * b;
}

vector<int> sieve(int n) {
    vector<bool> isprime(n + 1, true);
    vi primes;
    isprime[0] = isprime[1] = false;
    for (int i = 2; i * i <= n; i++) {
        if (isprime[i]) {
            for (int j = i * i; j <= n; j += i) {
                isprime[j] = false;
            }
        }
    }
    for (int i = 2; i <= n; i++) {
        if (isprime[i]) primes.pb(i);
    }
    return primes;
}

ll nCr(ll n, ll r) {
    r = min(r, n - r);
    if (r == 0) return 1;

    ll res = 1;
    for (ll i = 1; i <= r; ++i) {
        res = res * (n - r + i) / i;
    }
    return res;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    int t;
    cin >> t;
    while (t--) {
        ll n,k;
        cin>>n>>k;
        
        ll p=1, x=1, ans=0;
        while(x<n){
            ll q=p-1;
            if(p<=k) ans++;
            for(int i=1;i<=q;i++){
                if(p+i>k) break;
                ans+=(nCr(q,i));
            }
            p++;
            x<<=1;
        }
        if(p<=k) ans++;
        cout<<n-ans<<endl;
    }

    return 0;
}