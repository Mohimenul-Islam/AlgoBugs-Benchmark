// #include <iostream>
// #include <vector>
// #include <algorithm>
// #include <map>
// #include <cmath>

// using namespace std;
// using ll = long long;

// int main() {
//     ios::sync_with_stdio(false); cin.tie(nullptr);  
//     ll t;
//     cin >> t;
//     while (t--) {
//         ll n,k;
//         cin >> n >> k;
//         ll ans = 0;
//         const ll eps = 1e-18;
//         ll temp = (ll)(log2(n) + eps);
//         if (k > temp){

//             cout << ans << "\n";
//         }
//         else {
//             ans = 1LL<<(k-1);
//             cout << n - ans << "\n";
//         }
//     }
//     return 0;
// }

#include <bits/stdc++.h>

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace __gnu_pbds;
using namespace std;
using ll = long long;

typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> ordered_set;

#define pb push_back
#define forr(i,a,b) for(ll i = (a); i < (b) ; ++i)
#define roff(i,b,a) for(ll i = (b); i >= (a) ; --i)
#define vl vector<ll>
#define pl pair<ll , ll>
#define vvl vector<vl>
#define vpl vector<pl>
#define all(v) (v).begin() , (v).end()
#define all1(v) (v).begin() + 1, (v).end()
#define vvpl vector<vpl>
#define vstr vector<string>
#define vvvl vector<vvl>
#define ceil_div(a,b) (a+b-1)/b
#define vbl vector<bool>
#define len(x) (ll)x.size()


#define debug(x) cout << #x << " = " << x << "\n";
#define vdebug(a) cout << #a << " = "; for(auto x: a) cout << x << " "; cout << "\n";
#define vprint(a) for(auto x : a) cout << x << ' '; cout << "\n";
#define vpdebug(a) cout << #a << " = "; for(auto x:a) cout << x.first << "-" << x.second << " "; cout << "\n";

vector<ll> pre_computed_fact;

void precompute_fact(ll n , ll m) {

    pre_computed_fact.push_back(1);
    forr (i,1,n+1) {
        pre_computed_fact.push_back((i * pre_computed_fact[i-1]) % m);
    }
    return;
}

// ll fibonacci(ll n) {
//     double x = sqrt(5);
//     double y = (1+x)/2;
//     double z = (1-x)/2;
//     double ans = (pow(y,n) - pow(z,n))/x;
//     return (ll)(ans + 1e-24);
// }

vvl C(33,vl(33));

void calculation() {
    for (int i = 0; i <= 32; i++) {
        C[i][0] = 1;
        for (int j = 1; j <= i; j++) {
            C[i][j] = C[i - 1][j - 1] + C[i - 1][j];
        }
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    ll t = 1;
    cin >> t;
    calculation();
    while (t--) {
        ll n,k;
        cin >> n >> k;
        ll d = -1;
        ll temp = n;
        while (temp > 0) {
            temp/=2;
            d++;
        }
        ll ans = 0;
        for (ll i = 1; i <= d;i++){
            for (ll j = max(k+1-i,(ll)0);j <= d-1;j++) {
                ans += C[i-1][j];
            }
        }
        if (d+1 > k) ans++;
        cout << ans << "\n";
    }
    return 0;
}
