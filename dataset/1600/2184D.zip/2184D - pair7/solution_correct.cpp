#include <bits/stdc++.h>
#define itn int
#define int long long
#define ind long double
#define yes cout << "Yes"
#define no cout << "No"
#define pii pair<long long, long long>
#define all(x) (x).begin(), (x).end()
#define pci pair<char, int>
#define re return;
#define rep(l, i, r) for (int i = l; i <= r; i++)
#define lep(r, i, l) for (int i = r; i >= l; i--)
using namespace std;
const int N = 4e5 + 10;
const int M = 2e3 + 10;
const int mod = 1e9 + 7;
const int inf = 0x3f3f3f3f3f3f3f3f;
int x, y, t, n, z, k, m, sx, sy, u;
char ch1, ch2;
int fx, fy;
int num1, num2, num3, sum1, sum2, sum0, num;
multiset<int> st2, st1, st3;
int dx[4] = {0, -1, 0, 1}, dy[4] = {-1, 0, 1, 0}; // 上下左右
map<int, int> mp1, mp2, mp3;
map<int, int> mp;
string s1, s2, s3;
int a[N], b[N], c[N], d[N];
int maxn, minn, sum, ans, cnt;
vector<pii> e[N];
int fa[N];
int f[200][2000];
int fp(int a, int b)
{
    int ans = 1;
    while (b)
    {
        if (b & 1)
        {
            ans = (ans * a) % mod;
        }
        a = (a * a) % mod;
        b /= 2;
    }
    return ans;
}

int inv(int x)
{
    return fp(x, mod - 2) % mod;
}

int C(int n, int k)
{
    if (k < 0 || k > n)
        return 0;
    k = min(k, n - k);
    int res = 1;
    for (int i = 1; i <= k; i++)
    {
        res = res * (n - i + 1) % mod;
        res = res * inv(i) % mod;
    }
    return res % mod;
}
void solve()
{
    cin >> n >> k;
    if (n == 1)
    {
        cout << 0;
        re;
    }
    x = 63 - __builtin_clzll(n) - 1;
    sum = 0;
    /*  cout << f[1][0]; */
    if (k > 1000)
    {
        cout << 0;
        re;
    }
   
    rep(0, i, k)
    {
        sum += f[x][i];
        /* cout << sum << ' '; */
    }
    if (k >= x + 2)
    {
        sum++;
    }

    cout << max(n - sum, 0ll);
}

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    /* f[0][1] = 1, f[1][2] = 1, f[1][3] = 1; */
    rep(0, i, 32)
    {
        rep(0, j, i)
        {
            f[i][j + i + 1] += C(i, j);
        }
    }
    /* rep(0, i, 6) // 打表发现是杨辉三角
    {
        rep(1, j, 10)
        {
            cout << f[i][j] << " ";
        }
        cout << '\n';
    }
    cout << '\n'; */
    rep(1, i, 32)
    {
        rep(0, j, 100)
        {
            f[i][j] += f[i - 1][j];
        }
    }
    /*  rep(0, i, 6) // 打表发现是杨辉三角
     {
         rep(1, j, 10)
         {
             cout << f[i][j] << " ";
         }
         cout << '\n';
     } */
    int T;
    T = 1;
    cin >> T;
    while (T--)
    {
        solve();
        cout << '\n';
    }

    return 0;
}