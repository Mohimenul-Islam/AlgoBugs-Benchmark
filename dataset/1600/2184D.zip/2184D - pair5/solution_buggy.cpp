#include <bits/stdc++.h>

using namespace std;

template<typename A, typename B> ostream& operator<<(ostream &os, const pair<A, B> &p) { return os << '(' << p.first << ", " << p.second << ')'; }
template<typename T_container, typename T = typename enable_if<!is_same<T_container, string>::value, typename T_container::value_type>::type> ostream& operator<<(ostream &os, const T_container &v) { os << '{'; string sep; for (const T &x : v) os << sep << x, sep = ", "; return os << '}'; }
void dbg_out() { cerr << endl; }
template<typename Head, typename... Tail> void dbg_out(Head H, Tail... T) { cerr << ' ' << H; dbg_out(T...); }
#ifdef LOCAL
#define dbg(...) cerr << "(" << #__VA_ARGS__ << "):", dbg_out(__VA_ARGS__)
#else
#define dbg(...)
#endif

#define ar array
#define ll long long
#define ld long double
#define sza(x) ((int)x.size())
#define all(a) (a).begin(), (a).end()

const int MAX_N = 1e5 + 5;
const ll MOD = 1e9 + 7;
const ll INF = 1e9;
const ld EPS = 1e-9;


void solve() {
    ll n,k;cin>>n>>k;
    ll d = 0;
    ll tmp = n;
    while(tmp > 0){
    	tmp/=2;d++;
    }
    d--;
    vector<vector<ll>> dp(d+1,vector<ll>(d+1));
    dp[0][0] = 1;
    dp[1][1] = 1;
    dp[1][0] = 1;
    for(ll i=2;i<=d;i++){
    	dp[i][0] = 1;
    	for(ll j=1;j<=i;j++){
    		for(ll k=0;k<i;k++){
    			if(k >= j-1) dp[i][j] += dp[k][j-1];
    		}
    	}
    }
    ll cnt = 1;
    if(d+1 <= k) cnt++;
    for(ll bit=d-1;bit>=1;bit--){
    	ll rem = k - (bit+1);
    	if(rem >= 0) cnt++;
    	for(ll i=1;i<=min(rem,bit);i++){
    		cnt+=dp[bit][i];
    	}
    }
    cout<<n-cnt<<endl;
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    ll tc = 1;
    cin >> tc;
    while(tc--){
    	solve();
    }
}