#include <bits/stdc++.h>
using namespace std;
using ll = long long;
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
int getRand(int l, int r) {
    return uniform_int_distribution<int>(l, r)(rng);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int t;
    cin >> t;
    while(t--)
    {
        int n,k;
        cin >> n >> k;
        vector<int> dp(n+1);
        int cnt = 0;
        dp[0] = 0;
        dp[1] = 1;
        for(int i=2;i<=n;i++)
        {
            if (i%2 == 0) dp[i] = dp[i/2] + 1;
            else dp[i] = dp[i-1] + 1;
            if (dp[i] > k) cnt++;
        }
        cout << cnt << endl;
    }

}