/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>
using ll = long long;
using namespace std; 


void solve()
{
    ll comb[33][33];
    int N, K; cin >> N >> K;
    memset(comb, 0, sizeof(comb));
    comb[1][0] = 1;
    comb[1][1] = 1; 
    for (int i = 2; i <= 32; i++)
    {
        comb[i][0] = 1;
        for (int j = 1; j <= i; j++)
        {
            comb[i][j] = comb[i - 1][j - 1] + comb[i - 1][j];
        }
    }
    ll ans = 0;
    for (int i = 0; i <= 31 - __builtin_clz(N); i++)
    {
        //i represents the position of msb
        
        ll movesUsed = i + 1;
        if (i == 31 - __builtin_clz(N))
        {
            if (movesUsed > K) ans++; 
            break;
        }
        for (int j = 0; j <= i; j++)
        {
            ll totalMoves = movesUsed + j;
            if (totalMoves > K)
            {
                ans += comb[i][j];
            }
        }
    }
    cout << ans << "\n";

}

int main()
{
    int T; cin >> T;
    while (T--) solve();
}
