#include <iostream>
#include <vector>
#include <cstring>

using namespace std;

typedef long long ll;

void solve() {
    ll n, k;
    if (!(cin >> n >> k)) return;

    ll comb[65][65];
    memset(comb, 0, sizeof(comb));
    for (int i = 0; i <= 62; i++) {
        comb[i][0] = 1;
        for (int j = 1; j <= i; j++) {
            comb[i][j] = comb[i - 1][j - 1] + comb[i - 1][j];
        }
    }

    int d = 0;
    ll temp_n = n;
    while (temp_n > 1) {
        temp_n >>= 1;
        d++;
    }

    ll ans = 0;
    // Numbers from 1 to n-1
    for (int i = 0; i < d; i++) {
        // MSB is at position i (value 2^i)
        ll moves_msb = i + 1;
        for (int j = 0; j <= i; j++) {
            if (moves_msb + j > k) {
                ans += comb[i][j];
            }
        }
    }
    
    // Number n (which is 2^d)
    if (d + 1 > k) ans++;

    cout << ans << "\n";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    if (!(cin >> t)) return 0;
    while (t--) {
        solve();
    }
    return 0;
}
