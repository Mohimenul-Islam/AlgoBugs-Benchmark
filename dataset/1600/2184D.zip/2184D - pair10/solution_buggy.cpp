#include<bits/stdc++.h>
using namespace std;
using ll=long long int;
#define endl    '\n'
const int mod=1e9+7;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);cout.tie(nullptr);
    vector<ll>fact(33);fact[0]=1;
    for(int i=1;i<=32;i++)fact[i]=fact[i-1]*i;
    int t;cin>>t;
    while(t--)
    {
       ll n,k;cin>>n>>k;
       ll total=0;
       ll fake=n,cnt=0;
       while(fake>0)
       {
         fake/=2;cnt++;
       }
       cnt--;
       for(int i=1;i<=cnt-1;i++)
       {
            for(int j=0;j<=i;j++)
            {
                 ll x=i-j;
                 ll moves=x*2 + j+1;
                 if(moves<=k)total+= fact[i]/(fact[x]*fact[j] );
            }
       }
       if(cnt+1<=k && n>1 )total++;
       if(k>=1)total++;
       cout<<n-total<<endl;
    }

}
