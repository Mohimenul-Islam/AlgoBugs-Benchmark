#include<bits/stdc++.h>
using namespace std;
using ll = long long;
#define endl '\n'

ll nCr(ll n,ll r)
{
    if(r > n) return 0;
    if(r > n-r) r = n-r;

    ll ans = 1;
    for(ll i=1;i<=r;i++)
    {
        ans = ans * (n-r+i) / i;
    }
    return ans;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);

    int t;
    cin >> t;

    while(t--)
    {
        ll n,k;
        cin >> n >> k;

        ll total = 0;

        ll fake = n, cnt = 0;
        while(fake > 0)
        {
            fake /= 2;
            cnt++;
        }

        if(n > 0) cnt--;

        for(ll i=1;i<=cnt-1;i++)
        {
            for(ll j=0;j<=i;j++)
            {
                ll x = i-j;
                ll moves = x*2 + j + 1;

                if(moves <= k)
                    total += nCr(i,j);
            }
        }

        if(cnt+1 <= k && n > 1) total++;
        if(k >= 1) total++;

        cout << n-total << endl;
    }
}