#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;
using ll = long long;
const int MOD = 1000000007;
const int MAXN = 200005;

// Ordered Set (PBDS)
typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> ordered_set;
/* ORDERED SET (PBDS)
    find_by_order(k) -> element at index k
    order_of_key(x)  -> count of elements < x
    insert(x), erase(x)
*/

ll fact[MAXN], invFact[MAXN];

long long power(long long base, long long exp) {
    long long res = 1;
    base %= MOD;
    while (exp > 0) {
        if (exp % 2 == 1) res = (res * base) % MOD;
        base = (base * base) % MOD;
        exp /= 2;
    }
    return res;
}

long long modInverse(long long n) {
    return power(n, MOD - 2);
}

void precomputefactorials() {
    fact[0] = invFact[0] = 1;
    for (int i = 1; i < MAXN; i++) {
        fact[i] = (fact[i - 1] * i) % MOD;
    }
    invFact[MAXN - 1] = modInverse(fact[MAXN - 1]);
    for (int i = MAXN - 2; i >= 1; i--) {
        invFact[i] = (invFact[i + 1] * (i + 1)) % MOD;
    }
}

long long nCr(int n, int r) {
    if (r < 0 || r > n) return 0;
    long long num = fact[n];
    long long den = (invFact[r] * invFact[n - r]) % MOD;
    return (num * den) % MOD;
}

void solve(){
    ll n, k;
    cin >> n >> k;

    if(k >= 35){
        cout << 0 << endl;
    }
    else{
        ll p = pow(2, k);

        ll ans = 0;
        if(p <= n){
            ans += n-p+1;
            ll it = k-1;
            for(ll i=it; i>=0; i--){
                ll x = k-i;
                ll ct = 0;
                for(ll j=x; j<=i; j++){
                    ct += nCr(i, j);
                }
                ans += ct;
            }
        }
        else{
            ll it = log2(n);
            // cout << it << endl;
            for(ll i=it-1; i>=0; i--){
                ll x = k-i;
                ll ct = 0;
                for(ll j=x; j<=i; j++){
                    ct += nCr(i, j);
                }
                ans += ct;
            }
        }

        cout << ans << endl;
    }
}

#define fast ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);

signed main(){
    fast;

    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);

    precomputefactorials();

    int t = 1;
    cin >> t;
    while(t--){
        solve();
    }

    return 0;
}