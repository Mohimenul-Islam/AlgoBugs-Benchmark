#include <bits/stdc++.h>
#define int long long

using namespace std;

const int INF = 1e15;

const int N = 35;

int C[N][N];


void solve()
{
    int a, b;
    cin >> a >> b;
    int tt = a;
    int n = 0;
    while(a != 1)
    {
        n ++;
        a >>= 1;
    }
    int ans = 0; 
    for (int i = 0; i < n; i ++)
    {
        int tmp = b - i - 1;
        for (int j = 0; j <= min(tmp,N - 1); j ++) 
        {
            // cout << i << " " << j << " " << C[i][j] << "\n";
            ans += C[i][j];
        }
        // ans += C[i][tmp];
    }
    // ans ++;
    if (n + 1 <= b) ans ++;
    cout << tt - ans << "\n";
}

signed main()
{
    std::cin.tie(nullptr) -> sync_with_stdio(false);
    for (int i = 0; i < N; i ++) C[i][0] = 1;
    for (int i = 1; i < N; i ++)
        for (int j = 1; j <= i; j ++)
            C[i][j] = C[i - 1][j] + C[i - 1][j - 1];
    int t = 1;
    cin >> t;
    while (t --) solve();
    return 0;
}