#include <bits/stdc++.h>
//#pragma optimize GCC("O4")

using namespace std;

typedef long long ll;
typedef long double ld;
typedef vector<int> vi;
typedef vector<ll> vll;
#define all(x) x.begin(), x.end()

const ll INF = 4e18, mod = 998244353;
const ld ex = 0.0000001;
const int inf = 1e6;

ll gcd(ll a, ll b)
{
    if (b > a)
    {
        swap(a, b);
    }
    while (b > 0)
    {
        ll tmp = a % b;
        a = b;
        b = tmp;
    }
    return a;
}

ll BinaryPow(ll n, ll st, ll m)
{
    if (st <= 0)
    {
        return 1;
    }
    else if (st % 2 == 0)
    {
        ll ans = BinaryPow(n, st / 2, m);
        return ans * ans % m;
    }
    else
    {
        return(BinaryPow(n, st - 1, m) * n % m);
    }
}

int main()
{
    ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
    setlocale(LC_ALL, "RU");
    //freopen("divide.in", "r", stdin);
    //("divide.out", "w", stdout);

    //cout << fixed << setprecision(6);

    ll t;
    cin >> t;
    while (t--)
    {
        ll n, k;
        cin >> n >> k;
        ll d = 0;
        ll tmp = n;
        while (tmp > 1)
        {
            tmp /= 2;
            d++;
        }
        ll ans = 0;
        for (int i = 0; i < d; ++i)
        {
            for (int j = 0; j <= i; ++j)
            {
                int cnt1 = 1;
                for (int x = i; x > 0 and x > i - j; --x)
                {
                    cnt1 *= x;
                }
                int cnt2 = 1;
                for (int x = 1; x <= j; ++x)
                {
                    cnt2 *= x;
                }
                if (j + i + 1 > k)
                {
                    ans += cnt1 / cnt2;
                }
            }
        }
        if (d + 1 > k)
        {
            ans++;
        }
        cout << ans << endl;
    }
    return 0;
}
