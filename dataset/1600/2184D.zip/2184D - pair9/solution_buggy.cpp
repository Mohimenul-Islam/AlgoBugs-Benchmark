#include<bits/stdc++.h>
#define int long long
using namespace std;

int choose(int a, int b)
{
	if(b == 0) return 1;
	int cima = 1;
	for(int i = 1; i <= b; i++) {cima *= a; a--;}
	int baixo = 1;
	for(int i = 1; i <= b; i++) {baixo *= i;}

	return (cima/baixo);
}

void solve()
{
	int N,K; cin >> N >> K;

	int resp = 0;
	
	for(int i = 0; i < log2(N); i++)
	{
		if(2*(i + 1) - 1 <= K) continue;

		int pmenos = K - i;
		int cnt = 0;

		for(int j = max(0LL,pmenos); j <= i; j++)
		{
			cnt += choose(i,j);
		}
		// cerr << i << " " << cnt << " " << pmenos << "||\n";
		resp += cnt;
	}

	if(1 + (int) log2(N) > K) resp++;

	cout << resp << "\n";
}


int32_t main()
{
	cin.tie(0)->sync_with_stdio(0);

	int T; cin >> T;

	while(T--)
		solve();
}